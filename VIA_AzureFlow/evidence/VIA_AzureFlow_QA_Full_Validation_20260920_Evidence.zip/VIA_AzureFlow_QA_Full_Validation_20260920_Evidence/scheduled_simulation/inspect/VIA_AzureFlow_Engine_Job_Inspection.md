# VIA 天青智流 AzureFlow v8 檢查報告

**檢查時間：** 2026-09-19T17:35:05+00:00  
**API：** `http://127.0.0.1:8766`  
**工作區：** `/home/ubuntu/work/reconstruction`  

## 1. 執行摘要

- API health：`ok`；API status：`PASS`。
- 八個核心引擎：`8`；可用輸出格式：`41`。
- Jobs：`4` 個可見，completed=4，running=0，failed=0。
- SSOT registry status：`PROPOSAL_REVIEW_REQUIRED`；請勿將 API PASS 解讀為解除人工審核。

## 2. 八個核心引擎狀態

| ID | 名稱 | 中文名稱 | kind | status | editable surface | legacy aliases |
|---|---|---|---|---|---|---|
| VIA-ENG-022 | VIA Consolidated NLP Orchestrator | VIA 統一 NLP 編排器 | canonical_orchestrator | active_review_required | `facade` | `—` |
| VIA-MOD-001 | Input & Source Ledger | 輸入與來源帳本 | consolidated_module | active_review_required | `source_ledger` | `VIA-ENG-001, VIA-ENG-003, VIA-ENG-013` |
| VIA-MOD-002 | Text & NLP Normalization | 文字與 NLP 正規化 | consolidated_module | active_review_required | `text_nlp` | `VIA-ENG-004, VIA-ENG-018` |
| VIA-MOD-003 | Discussion & Instruction Reconstruction | 討論與指令重建 | consolidated_module | active_review_required | `discussion_commands` | `VIA-ENG-005, VIA-ENG-019, VIA-ENG-020` |
| VIA-MOD-004 | Knowledge & Mind Map | 知識體與心智圖 | consolidated_module | active_review_required | `knowledge_mindmap` | `VIA-ENG-007, VIA-ENG-016, VIA-ENG-021` |
| VIA-MOD-005 | AST & Code Module Intelligence | AST 與程式模組理解 | consolidated_module | active_review_required | `ast_modules` | `VIA-ENG-006, VIA-ENG-012, VIA-ENG-015` |
| VIA-MOD-006 | Governance & Safe Export | 治理與安全輸出 | consolidated_module | active_review_required | `governance` | `VIA-ENG-008, VIA-ENG-009, VIA-ENG-017` |
| VIA-MOD-007 | Acceleration & Runtime Fabric | 加速與執行基礎 | consolidated_module | active_review_required | `runtime` | `VIA-ENG-010, VIA-ENG-011` |

### 2.1 串接拓撲

```text
輸入／Windows I/O／拖曳
        ↓
VIA-ENG-022 統一 NLP 編排器
        ↓
MOD-001 source ledger → MOD-002 text/NLP → MOD-003 discussion/commands
        ↓
MOD-004 knowledge/mind map ──┐
                              └→ MOD-005 AST/static fallback
        ↓
MOD-006 governance/export → MOD-007 runtime/serialization/dashboard
        ↓
AzureFlow UI／artifact endpoint／Downloads
```

### 2.2 引擎責任與安全

- `VIA-MOD-001` 讀取格式、建立 source hash 與 immutable ledger。
- `VIA-MOD-002` 修正空格／斷句／標點並建立 token、Regex、同義字、factor、parameter projection。
- `VIA-MOD-003` 建立 topics、回題、指令與 proposal-only similarity merge。
- `VIA-MOD-004` 產生 SUMMARY、knowledge body、typed graph、Mind Map 與演化紀錄。
- `VIA-MOD-005` 只做 Python AST 靜態分析；非 Python 或不完整片段必須標示 fallback/review。
- `VIA-MOD-006` 套用 source/evidence/conflict/execution gates 並輸出 JSON／MD／HTML／ZIP。
- `VIA-MOD-007` 提供離線 bounded runtime、canonical serialization、cache 與 dashboard snapshot。
- 安全政策：`source_write=false`、`source_delete=false`、`code_execution=false`、`network=false`、`human_review_required=true`。

## 3. Job 總表

| Job ID | status | source | duration | units | topics | commands → merged | AST | source preserved |
|---|---|---|---:|---:|---:|---:|---|---|
| `8b141f0bcada49df` | completed | azureflow_sample.txt | 0.227 s | 4 | 1 | 4 → 4 | not_applicable | True |
| `ba5e3db4df8949dc` | completed | v8_api_fixture.py | 0.233 s | 5 | 1 | 0 → 0 | PASS_WITH_REVIEW | True |
| `c4f48dc0c4e34b46` | completed | azureflow_sample.txt | 0.232 s | 4 | 1 | 4 → 4 | not_applicable | True |
| `fe8289f5f8024d29` | completed | azureflow_sample.txt | 0.388 s | 4 | 1 | 4 → 4 | not_applicable | True |

## 4. 各 Job 詳細執行紀錄與輸出

### 4.1 `8b141f0bcada49df`

- Input：`azureflow_sample.txt`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/app/runs/8b141f0bcada49df`。
- Created／started／completed：`2026-09-15T19:01:56.003000+00:00`／`2026-09-15T19:01:56.003000+00:00`／`2026-09-15T19:01:56.230000+00:00`。
- Source SHA-256：`3a915e34ac1254704519a712fc1a9908fa7b8020f45911c5cdceabc391adcb4f`；bytes=202；characters=108。
- Engine IDs：`VIA-ENG-022`。
- Selected outputs：`corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot, markdown, html, record`。
- Metrics：units=4、topics=1、original_commands=4、merged_groups=4、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`True`、review_required=`True`。
- Summary：title=`azureflow_sample.txt`；key_points=4。
- AST：mode=`text_static_fallback`、parse_status=`not_applicable`、imports=0、functions=0、risk_flags=`["non_python_input_static_fallback"]`、execution_authorized=`False`。
- Local artifacts:

  - `SUMMARY.md` (1071 bytes)
  - `VIA_NLP_Spec.md` (5439 bytes)
  - `VIA_NLP_UI_Spec.html` (6740 bytes)
  - `command_similarity_merge.json` (4333 bytes)
  - `compat_v7_content_roles.json` (20766 bytes)
  - `compat_v7_context_reconstruction.json` (6131 bytes)
  - `compat_v7_function_classification.json` (3482 bytes)
  - `compat_v7_instruction_reconstruction.json` (6880 bytes)
  - `compat_v7_knowledge_body.json` (13120 bytes)
  - `compat_v7_mind_map.json` (38804 bytes)
  - `compat_v7_mind_map.mmd` (3409 bytes)
  - `compat_v7_mind_map_evolution.json` (29636 bytes)
  - `compat_v7_module_composition.json` (10768 bytes)
  - `compat_v7_quality_gates.json` (2677 bytes)
  - `compat_v7_source_ledger.json` (2367 bytes)
  - `compat_v7_summary.json` (11392 bytes)
  - `compat_v7_unified.json` (226386 bytes)
  - `corrected_content.md` (892 bytes)
  - `dashboard_snapshot.json` (6971 bytes)
  - `factor_library_projection.json` (1357 bytes)
  - `mindmap.md` (1614 bytes)
  - `mindmap.mmd` (732 bytes)
  - `mindmap_projection.json` (6620 bytes)
  - `parameter_library_projection.json` (1994 bytes)
  - `program_spec.md` (2435 bytes)
  - `program_structure.json` (1723 bytes)
  - `record.json` (46910 bytes)
  - `regex_projection.json` (1489 bytes)
  - `reusable_prompt.json` (2532 bytes)
  - `source_preserved.txt` (202 bytes)
  - `summary_v5.json` (6231 bytes)
  - `topic_reconstruction.json` (1928 bytes)
  - `v7_content_roles.json` (20766 bytes)
  - `v7_context_reconstruction.json` (6131 bytes)
  - `v7_function_classification.json` (3482 bytes)
  - `v7_instruction_reconstruction.json` (6880 bytes)
  - `v7_knowledge_body.json` (13120 bytes)
  - `v7_mind_map.json` (38804 bytes)
  - `v7_mind_map.mmd` (3409 bytes)
  - `v7_mind_map_evolution.json` (29636 bytes)
  - `v7_module_composition.json` (10768 bytes)
  - `v7_quality_gates.json` (2677 bytes)
  - `v7_source_ledger.json` (2367 bytes)
  - `v7_summary.json` (11392 bytes)
  - `v7_unified.json` (226386 bytes)
  - `v8_ast_modules.json` (1723 bytes)
  - `v8_discussion_commands.json` (12608 bytes)
  - `v8_governance.json` (3031 bytes)
  - `v8_knowledge_mindmap.json` (83535 bytes)
  - `v8_mind_map.mmd` (669 bytes)
  - `v8_module_registry.json` (4375 bytes)
  - `v8_source_ledger.json` (2025 bytes)
  - `v8_text_nlp.json` (1913 bytes)
  - `v8_unified.json` (347657 bytes)

### 4.2 `ba5e3db4df8949dc`

- Input：`v8_api_fixture.py`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/app/runs/ba5e3db4df8949dc`。
- Created／started／completed：`2026-09-15T19:01:55.631000+00:00`／`2026-09-15T19:01:55.632000+00:00`／`2026-09-15T19:01:55.865000+00:00`。
- Source SHA-256：`519ca522a3104eca36f303664c61a886ce391ca3e97de941984998a38ae460f8`；bytes=93；characters=75。
- Engine IDs：`VIA-ENG-022, VIA-MOD-001, VIA-MOD-002, VIA-MOD-003, VIA-MOD-004, VIA-MOD-005, VIA-MOD-006, VIA-MOD-007`。
- Selected outputs：`markdown, html, record, v8_unified, v8_ast_modules, v8_mind_map, v7_unified`。
- Metrics：units=5、topics=1、original_commands=0、merged_groups=0、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`True`、review_required=`True`。
- Summary：title=`v8_api_fixture.py`；key_points=5。
- AST：mode=`python_ast`、parse_status=`PASS_WITH_REVIEW`、imports=0、functions=0、risk_flags=`["syntax_error_or_fragment", "invalid character '。' (U+3002)"]`、execution_authorized=`False`。
- Local artifacts:

  - `SUMMARY.md` (862 bytes)
  - `VIA_NLP_Spec.md` (5584 bytes)
  - `VIA_NLP_UI_Spec.html` (7101 bytes)
  - `command_similarity_merge.json` (4788 bytes)
  - `compat_v7_content_roles.json` (24293 bytes)
  - `compat_v7_context_reconstruction.json` (8533 bytes)
  - `compat_v7_function_classification.json` (7907 bytes)
  - `compat_v7_instruction_reconstruction.json` (5561 bytes)
  - `compat_v7_knowledge_body.json` (10648 bytes)
  - `compat_v7_mind_map.json` (39981 bytes)
  - `compat_v7_mind_map.mmd` (3259 bytes)
  - `compat_v7_mind_map_evolution.json` (35224 bytes)
  - `compat_v7_module_composition.json` (21253 bytes)
  - `compat_v7_quality_gates.json` (5922 bytes)
  - `compat_v7_source_ledger.json` (5510 bytes)
  - `compat_v7_summary.json` (13774 bytes)
  - `compat_v7_unified.json` (228588 bytes)
  - `corrected_content.md` (788 bytes)
  - `dashboard_snapshot.json` (10216 bytes)
  - `factor_library_projection.json` (4602 bytes)
  - `mindmap.md` (916 bytes)
  - `mindmap.mmd` (76 bytes)
  - `mindmap_projection.json` (5832 bytes)
  - `parameter_library_projection.json` (4580 bytes)
  - `program_spec.md` (2421 bytes)
  - `program_structure.json` (4989 bytes)
  - `record.json` (29322 bytes)
  - `regex_projection.json` (4677 bytes)
  - `reusable_prompt.json` (5774 bytes)
  - `source_preserved.txt` (93 bytes)
  - `summary_v5.json` (6316 bytes)
  - `topic_reconstruction.json` (5194 bytes)
  - `v7_content_roles.json` (24293 bytes)
  - `v7_context_reconstruction.json` (8533 bytes)
  - `v7_function_classification.json` (7907 bytes)
  - `v7_instruction_reconstruction.json` (5561 bytes)
  - `v7_knowledge_body.json` (10648 bytes)
  - `v7_mind_map.json` (39981 bytes)
  - `v7_mind_map.mmd` (3259 bytes)
  - `v7_mind_map_evolution.json` (35224 bytes)
  - `v7_module_composition.json` (21253 bytes)
  - `v7_quality_gates.json` (5922 bytes)
  - `v7_source_ledger.json` (5510 bytes)
  - `v7_summary.json` (13774 bytes)
  - `v7_unified.json` (228588 bytes)
  - `v8_ast_modules.json` (4989 bytes)
  - `v8_discussion_commands.json` (10120 bytes)
  - `v8_governance.json` (6276 bytes)
  - `v8_knowledge_mindmap.json` (81178 bytes)
  - `v8_mind_map.mmd` (669 bytes)
  - `v8_module_registry.json` (7620 bytes)
  - `v8_source_ledger.json` (5264 bytes)
  - `v8_text_nlp.json` (5026 bytes)
  - `v8_unified.json` (338433 bytes)

### 4.3 `c4f48dc0c4e34b46`

- Input：`azureflow_sample.txt`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/app/runs/c4f48dc0c4e34b46`。
- Created／started／completed：`2026-09-15T19:00:06.422000+00:00`／`2026-09-15T19:00:06.422000+00:00`／`2026-09-15T19:00:06.654000+00:00`。
- Source SHA-256：`3a915e34ac1254704519a712fc1a9908fa7b8020f45911c5cdceabc391adcb4f`；bytes=202；characters=108。
- Engine IDs：`VIA-ENG-022`。
- Selected outputs：`corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot, markdown, html, record`。
- Metrics：units=4、topics=1、original_commands=4、merged_groups=4、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`True`、review_required=`True`。
- Summary：title=`azureflow_sample.txt`；key_points=4。
- AST：mode=`text_static_fallback`、parse_status=`not_applicable`、imports=0、functions=0、risk_flags=`["non_python_input_static_fallback"]`、execution_authorized=`False`。
- Local artifacts:

  - `SUMMARY.md` (1071 bytes)
  - `VIA_NLP_Spec.md` (5439 bytes)
  - `VIA_NLP_UI_Spec.html` (6740 bytes)
  - `command_similarity_merge.json` (4333 bytes)
  - `compat_v7_content_roles.json` (20766 bytes)
  - `compat_v7_context_reconstruction.json` (6131 bytes)
  - `compat_v7_function_classification.json` (3482 bytes)
  - `compat_v7_instruction_reconstruction.json` (6880 bytes)
  - `compat_v7_knowledge_body.json` (13120 bytes)
  - `compat_v7_mind_map.json` (38804 bytes)
  - `compat_v7_mind_map.mmd` (3409 bytes)
  - `compat_v7_mind_map_evolution.json` (29636 bytes)
  - `compat_v7_module_composition.json` (10768 bytes)
  - `compat_v7_quality_gates.json` (2677 bytes)
  - `compat_v7_source_ledger.json` (2367 bytes)
  - `compat_v7_summary.json` (11392 bytes)
  - `compat_v7_unified.json` (226386 bytes)
  - `corrected_content.md` (892 bytes)
  - `dashboard_snapshot.json` (6698 bytes)
  - `factor_library_projection.json` (1357 bytes)
  - `mindmap.md` (1614 bytes)
  - `mindmap.mmd` (732 bytes)
  - `mindmap_projection.json` (6620 bytes)
  - `parameter_library_projection.json` (1994 bytes)
  - `program_spec.md` (2435 bytes)
  - `program_structure.json` (1723 bytes)
  - `record.json` (46910 bytes)
  - `regex_projection.json` (1489 bytes)
  - `reusable_prompt.json` (2532 bytes)
  - `source_preserved.txt` (202 bytes)
  - `summary_v5.json` (6231 bytes)
  - `topic_reconstruction.json` (1928 bytes)
  - `v7_content_roles.json` (20766 bytes)
  - `v7_context_reconstruction.json` (6131 bytes)
  - `v7_function_classification.json` (3482 bytes)
  - `v7_instruction_reconstruction.json` (6880 bytes)
  - `v7_knowledge_body.json` (13120 bytes)
  - `v7_mind_map.json` (38804 bytes)
  - `v7_mind_map.mmd` (3409 bytes)
  - `v7_mind_map_evolution.json` (29636 bytes)
  - `v7_module_composition.json` (10768 bytes)
  - `v7_quality_gates.json` (2677 bytes)
  - `v7_source_ledger.json` (2367 bytes)
  - `v7_summary.json` (11392 bytes)
  - `v7_unified.json` (226386 bytes)
  - `v8_ast_modules.json` (1723 bytes)
  - `v8_discussion_commands.json` (12608 bytes)
  - `v8_governance.json` (3031 bytes)
  - `v8_knowledge_mindmap.json` (83535 bytes)
  - `v8_mind_map.mmd` (669 bytes)
  - `v8_module_registry.json` (4375 bytes)
  - `v8_source_ledger.json` (2025 bytes)
  - `v8_text_nlp.json` (1913 bytes)
  - `v8_unified.json` (347657 bytes)

### 4.4 `fe8289f5f8024d29`

- Input：`azureflow_sample.txt`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/app/runs/fe8289f5f8024d29`。
- Created／started／completed：`2026-09-15T18:59:51.759000+00:00`／`2026-09-15T18:59:51.760000+00:00`／`2026-09-15T18:59:52.148000+00:00`。
- Source SHA-256：`3a915e34ac1254704519a712fc1a9908fa7b8020f45911c5cdceabc391adcb4f`；bytes=202；characters=108。
- Engine IDs：`VIA-ENG-022`。
- Selected outputs：`corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot, markdown, html, record`。
- Metrics：units=4、topics=1、original_commands=4、merged_groups=4、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`True`、review_required=`True`。
- Summary：title=`azureflow_sample.txt`；key_points=4。
- AST：mode=`text_static_fallback`、parse_status=`not_applicable`、imports=0、functions=0、risk_flags=`["non_python_input_static_fallback"]`、execution_authorized=`False`。
- Local artifacts:

  - `SUMMARY.md` (1071 bytes)
  - `VIA_NLP_Spec.md` (5439 bytes)
  - `VIA_NLP_UI_Spec.html` (6740 bytes)
  - `command_similarity_merge.json` (4333 bytes)
  - `compat_v7_content_roles.json` (20766 bytes)
  - `compat_v7_context_reconstruction.json` (6131 bytes)
  - `compat_v7_function_classification.json` (3482 bytes)
  - `compat_v7_instruction_reconstruction.json` (6880 bytes)
  - `compat_v7_knowledge_body.json` (13120 bytes)
  - `compat_v7_mind_map.json` (38804 bytes)
  - `compat_v7_mind_map.mmd` (3409 bytes)
  - `compat_v7_mind_map_evolution.json` (29636 bytes)
  - `compat_v7_module_composition.json` (10768 bytes)
  - `compat_v7_quality_gates.json` (2677 bytes)
  - `compat_v7_source_ledger.json` (2367 bytes)
  - `compat_v7_summary.json` (11392 bytes)
  - `compat_v7_unified.json` (226388 bytes)
  - `corrected_content.md` (892 bytes)
  - `dashboard_snapshot.json` (6632 bytes)
  - `factor_library_projection.json` (1357 bytes)
  - `mindmap.md` (1614 bytes)
  - `mindmap.mmd` (732 bytes)
  - `mindmap_projection.json` (6620 bytes)
  - `parameter_library_projection.json` (1994 bytes)
  - `program_spec.md` (2435 bytes)
  - `program_structure.json` (1723 bytes)
  - `record.json` (46910 bytes)
  - `regex_projection.json` (1489 bytes)
  - `reusable_prompt.json` (2532 bytes)
  - `source_preserved.txt` (202 bytes)
  - `summary_v5.json` (6231 bytes)
  - `topic_reconstruction.json` (1928 bytes)
  - `v7_content_roles.json` (20766 bytes)
  - `v7_context_reconstruction.json` (6131 bytes)
  - `v7_function_classification.json` (3482 bytes)
  - `v7_instruction_reconstruction.json` (6880 bytes)
  - `v7_knowledge_body.json` (13120 bytes)
  - `v7_mind_map.json` (38804 bytes)
  - `v7_mind_map.mmd` (3409 bytes)
  - `v7_mind_map_evolution.json` (29636 bytes)
  - `v7_module_composition.json` (10768 bytes)
  - `v7_quality_gates.json` (2677 bytes)
  - `v7_source_ledger.json` (2367 bytes)
  - `v7_summary.json` (11392 bytes)
  - `v7_unified.json` (226388 bytes)
  - `v8_ast_modules.json` (1723 bytes)
  - `v8_discussion_commands.json` (12608 bytes)
  - `v8_governance.json` (3031 bytes)
  - `v8_knowledge_mindmap.json` (83535 bytes)
  - `v8_mind_map.mmd` (669 bytes)
  - `v8_module_registry.json` (4375 bytes)
  - `v8_source_ledger.json` (2025 bytes)
  - `v8_text_nlp.json` (1913 bytes)
  - `v8_unified.json` (347659 bytes)

## 5. Artifact 與 API 暴露狀態

每個 job 的 `artifacts` mapping 只代表本次 output selector 選取的 API logical keys；run directory 可以保存更多診斷與相容投影。未選取的 logical key 可能在本地存在，但 API endpoint 回傳 404，不能直接判定為檔案遺失。

| Job ID | downloads enabled | bundle | selected API artifacts | local run exists |
|---|---|---|---|---|
| `8b141f0bcada49df` | False | `None` | `record, markdown, html, corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot` | True |
| `ba5e3db4df8949dc` | False | `None` | `record, markdown, html, v8_unified, v8_ast_modules, v8_mind_map, v7_unified` | True |
| `c4f48dc0c4e34b46` | False | `None` | `record, markdown, html, corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot` | True |
| `fe8289f5f8024d29` | False | `None` | `record, markdown, html, corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot` | True |

## 6. 品質閘門、注意事項與限制

- `8b141f0bcada49df`：source_preserved=True、source_mutated=False、source_deleted=False、coverage=1.0、code_execution=False、network=False、subprocess=False、review_required=True。
- `ba5e3db4df8949dc`：source_preserved=True、source_mutated=False、source_deleted=False、coverage=1.0、code_execution=False、network=False、subprocess=False、review_required=True。
- `c4f48dc0c4e34b46`：source_preserved=True、source_mutated=False、source_deleted=False、coverage=1.0、code_execution=False、network=False、subprocess=False、review_required=True。
- `fe8289f5f8024d29`：source_preserved=True、source_mutated=False、source_deleted=False、coverage=1.0、code_execution=False、network=False、subprocess=False、review_required=True。
- AST 注意：job `8b141f0bcada49df` 有 risk flags `["non_python_input_static_fallback"]`；請視為 static fallback／人工複核，不要宣稱為成功 AST。
- AST 注意：job `ba5e3db4df8949dc` 有 risk flags `["syntax_error_or_fragment", "invalid character '。' (U+3002)"]`；請視為 static fallback／人工複核，不要宣稱為成功 AST。
- AST 注意：job `c4f48dc0c4e34b46` 有 risk flags `["non_python_input_static_fallback"]`；請視為 static fallback／人工複核，不要宣稱為成功 AST。
- AST 注意：job `fe8289f5f8024d29` 有 risk flags `["non_python_input_static_fallback"]`；請視為 static fallback／人工複核，不要宣稱為成功 AST。

## 7. 來源與檢查時間

- SSOT：`/home/ubuntu/work/reconstruction/VIA_SSOT_Engine_Registry_v8.json`。
- Integration map：`/home/ubuntu/work/reconstruction/VIA_Consolidated_NLP_v8_Integration_Map.md`。
- Run roots：`/home/ubuntu/work/reconstruction/app/runs`。
- Report generated at：`2026-09-19T17:35:05+00:00`。
