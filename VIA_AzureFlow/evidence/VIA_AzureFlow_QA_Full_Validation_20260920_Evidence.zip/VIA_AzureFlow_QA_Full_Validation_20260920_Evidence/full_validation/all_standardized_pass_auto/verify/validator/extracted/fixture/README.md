# standardized fixture
