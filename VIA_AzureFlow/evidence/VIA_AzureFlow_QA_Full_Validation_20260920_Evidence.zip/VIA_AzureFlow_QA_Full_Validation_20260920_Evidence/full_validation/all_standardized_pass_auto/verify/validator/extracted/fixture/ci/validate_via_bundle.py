# fixture validator
