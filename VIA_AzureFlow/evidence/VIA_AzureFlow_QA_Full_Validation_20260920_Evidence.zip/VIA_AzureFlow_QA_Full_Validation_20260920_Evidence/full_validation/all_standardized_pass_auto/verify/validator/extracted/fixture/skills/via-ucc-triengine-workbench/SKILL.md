# fixture skill
