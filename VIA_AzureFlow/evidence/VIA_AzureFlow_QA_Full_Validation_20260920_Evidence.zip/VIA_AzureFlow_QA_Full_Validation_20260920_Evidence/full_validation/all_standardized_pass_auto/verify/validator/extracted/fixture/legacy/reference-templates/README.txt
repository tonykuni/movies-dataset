legacy boundary fixture
