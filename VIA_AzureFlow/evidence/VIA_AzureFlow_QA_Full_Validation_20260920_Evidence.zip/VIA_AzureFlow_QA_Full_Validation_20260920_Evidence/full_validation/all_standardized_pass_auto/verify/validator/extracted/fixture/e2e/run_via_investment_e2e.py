#!/usr/bin/env python3
import argparse
import json
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--html', required=True)
parser.add_argument('--out-dir', required=True)
args = parser.parse_args()
out_dir = Path(args.out_dir)
out_dir.mkdir(parents=True, exist_ok=True)
report = {'summary': {'total': 54, 'passed': 54, 'failed': 0}, 'devices': ['desktop-1440', 'tablet-768', 'mobile-390']}
(out_dir / 'report.json').write_text(json.dumps(report) + '\n', encoding='utf-8')
print(json.dumps(report))
