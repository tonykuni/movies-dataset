# fixture analyzer
