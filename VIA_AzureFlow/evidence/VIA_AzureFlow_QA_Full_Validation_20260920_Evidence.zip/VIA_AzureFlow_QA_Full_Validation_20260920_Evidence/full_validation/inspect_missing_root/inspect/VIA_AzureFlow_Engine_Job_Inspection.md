# VIA 天青智流 AzureFlow v8 檢查報告

**檢查時間：** 2026-09-19T17:35:08+00:00  
**API：** `http://127.0.0.1:8766`  
**工作區：** `/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist`  

## 1. 執行摘要

- API health：`ok`；API status：`PASS`。
- 八個核心引擎：`8`；可用輸出格式：`41`。
- Jobs：`4` 個可見，completed=4，running=0，failed=0。
- SSOT registry status：`unavailable`；請勿將 API PASS 解讀為解除人工審核。

## 2. 八個核心引擎狀態

| ID | 名稱 | 中文名稱 | kind | status | editable surface | legacy aliases |
|---|---|---|---|---|---|---|
| VIA-ENG-022 | n/a | n/a | canonical_orchestrator | active_review_required | `facade` | `—` |
| VIA-MOD-001 | n/a | n/a | consolidated_module | active_review_required | `source_ledger` | `—` |
| VIA-MOD-002 | n/a | n/a | consolidated_module | active_review_required | `text_nlp` | `—` |
| VIA-MOD-003 | n/a | n/a | consolidated_module | active_review_required | `discussion_commands` | `—` |
| VIA-MOD-004 | n/a | n/a | consolidated_module | active_review_required | `knowledge_mindmap` | `—` |
| VIA-MOD-005 | n/a | n/a | consolidated_module | active_review_required | `ast_modules` | `—` |
| VIA-MOD-006 | n/a | n/a | consolidated_module | active_review_required | `governance` | `—` |
| VIA-MOD-007 | n/a | n/a | consolidated_module | active_review_required | `runtime` | `—` |

### 2.1 串接拓撲

```text
輸入／Windows I/O／拖曳
        ↓
VIA-ENG-022 統一 NLP 編排器
        ↓
MOD-001 source ledger → MOD-002 text/NLP → MOD-003 discussion/commands
        ↓
MOD-004 knowledge/mind map ──┐
                              └→ MOD-005 AST/static fallback
        ↓
MOD-006 governance/export → MOD-007 runtime/serialization/dashboard
        ↓
AzureFlow UI／artifact endpoint／Downloads
```

### 2.2 引擎責任與安全

- `VIA-MOD-001` 讀取格式、建立 source hash 與 immutable ledger。
- `VIA-MOD-002` 修正空格／斷句／標點並建立 token、Regex、同義字、factor、parameter projection。
- `VIA-MOD-003` 建立 topics、回題、指令與 proposal-only similarity merge。
- `VIA-MOD-004` 產生 SUMMARY、knowledge body、typed graph、Mind Map 與演化紀錄。
- `VIA-MOD-005` 只做 Python AST 靜態分析；非 Python 或不完整片段必須標示 fallback/review。
- `VIA-MOD-006` 套用 source/evidence/conflict/execution gates 並輸出 JSON／MD／HTML／ZIP。
- `VIA-MOD-007` 提供離線 bounded runtime、canonical serialization、cache 與 dashboard snapshot。
- 安全政策：`source_write=false`、`source_delete=false`、`code_execution=false`、`network=false`、`human_review_required=true`。

## 3. Job 總表

| Job ID | status | source | duration | units | topics | commands → merged | AST | source preserved |
|---|---|---|---:|---:|---:|---:|---|---|
| `8b141f0bcada49df` | completed | azureflow_sample.txt | 0.227 s | 4 | 1 | 4 → 4 | not_applicable | None |
| `ba5e3db4df8949dc` | completed | v8_api_fixture.py | 0.233 s | 5 | 1 | 0 → 0 | PASS_WITH_REVIEW | None |
| `c4f48dc0c4e34b46` | completed | azureflow_sample.txt | 0.232 s | 4 | 1 | 4 → 4 | not_applicable | None |
| `fe8289f5f8024d29` | completed | azureflow_sample.txt | 0.388 s | 4 | 1 | 4 → 4 | not_applicable | None |

## 4. 各 Job 詳細執行紀錄與輸出

### 4.1 `8b141f0bcada49df`

- Input：`azureflow_sample.txt`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist/app/runs/8b141f0bcada49df`。
- Created／started／completed：`2026-09-15T19:01:56.003000+00:00`／`2026-09-15T19:01:56.003000+00:00`／`2026-09-15T19:01:56.230000+00:00`。
- Source SHA-256：`n/a`；bytes=n/a；characters=n/a。
- Engine IDs：`VIA-ENG-022`。
- Selected outputs：`corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot, markdown, html, record`。
- Metrics：units=4、topics=1、original_commands=4、merged_groups=4、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`None`、review_required=`None`。
- Summary：title=`n/a`；key_points=n/a。
- Local artifacts:


### 4.2 `ba5e3db4df8949dc`

- Input：`v8_api_fixture.py`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist/app/runs/ba5e3db4df8949dc`。
- Created／started／completed：`2026-09-15T19:01:55.631000+00:00`／`2026-09-15T19:01:55.632000+00:00`／`2026-09-15T19:01:55.865000+00:00`。
- Source SHA-256：`n/a`；bytes=n/a；characters=n/a。
- Engine IDs：`VIA-ENG-022, VIA-MOD-001, VIA-MOD-002, VIA-MOD-003, VIA-MOD-004, VIA-MOD-005, VIA-MOD-006, VIA-MOD-007`。
- Selected outputs：`markdown, html, record, v8_unified, v8_ast_modules, v8_mind_map, v7_unified`。
- Metrics：units=5、topics=1、original_commands=0、merged_groups=0、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`None`、review_required=`None`。
- Summary：title=`n/a`；key_points=n/a。
- Local artifacts:


### 4.3 `c4f48dc0c4e34b46`

- Input：`azureflow_sample.txt`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist/app/runs/c4f48dc0c4e34b46`。
- Created／started／completed：`2026-09-15T19:00:06.422000+00:00`／`2026-09-15T19:00:06.422000+00:00`／`2026-09-15T19:00:06.654000+00:00`。
- Source SHA-256：`n/a`；bytes=n/a；characters=n/a。
- Engine IDs：`VIA-ENG-022`。
- Selected outputs：`corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot, markdown, html, record`。
- Metrics：units=4、topics=1、original_commands=4、merged_groups=4、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`None`、review_required=`None`。
- Summary：title=`n/a`；key_points=n/a。
- Local artifacts:


### 4.4 `fe8289f5f8024d29`

- Input：`azureflow_sample.txt`；mode=`text_copy`；run directory=`/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist/app/runs/fe8289f5f8024d29`。
- Created／started／completed：`2026-09-15T18:59:51.759000+00:00`／`2026-09-15T18:59:51.760000+00:00`／`2026-09-15T18:59:52.148000+00:00`。
- Source SHA-256：`n/a`；bytes=n/a；characters=n/a。
- Engine IDs：`VIA-ENG-022`。
- Selected outputs：`corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot, markdown, html, record`。
- Metrics：units=4、topics=1、original_commands=4、merged_groups=4、deduplicated=0、parameter_conflicts=0。
- Result：status=`completed`、error=`None`、warnings=`None`、source_preserved=`None`、review_required=`None`。
- Summary：title=`n/a`；key_points=n/a。
- Local artifacts:


## 5. Artifact 與 API 暴露狀態

每個 job 的 `artifacts` mapping 只代表本次 output selector 選取的 API logical keys；run directory 可以保存更多診斷與相容投影。未選取的 logical key 可能在本地存在，但 API endpoint 回傳 404，不能直接判定為檔案遺失。

| Job ID | downloads enabled | bundle | selected API artifacts | local run exists |
|---|---|---|---|---|
| `8b141f0bcada49df` | False | `None` | `record, markdown, html, corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot` | False |
  - API probe: `record`=200; `markdown`=200; `html`=200; `corrected_content`=200; `source_preserved`=200; `summary_v5`=200; `summary_markdown`=200; `program_spec`=200; `program_structure`=200; `dashboard_snapshot`=200
| `ba5e3db4df8949dc` | False | `None` | `record, markdown, html, v8_unified, v8_ast_modules, v8_mind_map, v7_unified` | False |
  - API probe: `record`=200; `markdown`=200; `html`=200; `v8_unified`=200; `v8_ast_modules`=200; `v8_mind_map`=200; `v7_unified`=200
| `c4f48dc0c4e34b46` | False | `None` | `record, markdown, html, corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot` | False |
  - API probe: `record`=200; `markdown`=200; `html`=200; `corrected_content`=200; `source_preserved`=200; `summary_v5`=200; `summary_markdown`=200; `program_spec`=200; `program_structure`=200; `dashboard_snapshot`=200
| `fe8289f5f8024d29` | False | `None` | `record, markdown, html, corrected_content, source_preserved, summary_v5, summary_markdown, program_spec, program_structure, dashboard_snapshot` | False |
  - API probe: `record`=200; `markdown`=200; `html`=200; `corrected_content`=200; `source_preserved`=200; `summary_v5`=200; `summary_markdown`=200; `program_spec`=200; `program_structure`=200; `dashboard_snapshot`=200

## 6. 品質閘門、注意事項與限制

- `8b141f0bcada49df`：source_preserved=None、source_mutated=None、source_deleted=None、coverage=None、code_execution=None、network=None、subprocess=None、review_required=None。
- `ba5e3db4df8949dc`：source_preserved=None、source_mutated=None、source_deleted=None、coverage=None、code_execution=None、network=None、subprocess=None、review_required=None。
- `c4f48dc0c4e34b46`：source_preserved=None、source_mutated=None、source_deleted=None、coverage=None、code_execution=None、network=None、subprocess=None、review_required=None。
- `fe8289f5f8024d29`：source_preserved=None、source_mutated=None、source_deleted=None、coverage=None、code_execution=None、network=None、subprocess=None、review_required=None。

## 7. 來源與檢查時間

- SSOT：`/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist/VIA_SSOT_Engine_Registry_v8.json`。
- Integration map：`/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist/VIA_Consolidated_NLP_v8_Integration_Map.md`。
- Run roots：`/home/ubuntu/work/reconstruction/VIA_AzureFlow_QA_Full_Validation_20260920/does-not-exist/app/runs`。
- Report generated at：`2026-09-19T17:35:08+00:00`。
