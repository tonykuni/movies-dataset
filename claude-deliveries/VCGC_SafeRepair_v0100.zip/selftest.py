import codecs, hashlib, json, os, pathlib, shutil, subprocess, sys, tempfile, unittest
from unittest.mock import patch
import importlib.util

HERE = pathlib.Path(__file__).resolve().parent
FILE = HERE / "VCGC_SafeRepair.py"
spec = importlib.util.spec_from_file_location("safe_repair", FILE)
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)
PWSH = shutil.which("pwsh")


def cmd(*args, stdin=None):
    return subprocess.run(
        [sys.executable, "-I", "-B", str(FILE), *map(str, args)],
        input=stdin,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=False,
        timeout=180,
    )


def files(root):
    return {
        str(p.relative_to(root)): app.sha(p.read_bytes())
        for p in root.rglob("*")
        if p.is_file()
    }


class Checks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.base = pathlib.Path(cls.temp.name)
        cls.root = cls.base / "repo"
        cls.root.mkdir()
        cls.tls = (
            codecs.BOM_UTF8
            + 'import requests\r\n# 中文\r\ndef fetch():\r\n    return requests.get("https://example.invalid", verify=False)\r\n'.encode()
        )
        (cls.root / "client.py").write_bytes(cls.tls)
        (cls.root / "bad.ps1").write_bytes(b'Write-Output ("a"\r\n    + "b")\r\n')
        (cls.root / "test_guard.py").write_bytes(cls.tls)
        (cls.root / "bad.json").write_bytes(b'{"a":1,"a":2}')
        (cls.root / "broken.py").write_bytes(b"def (:")
        (cls.root / "copy.py").write_bytes(b"def (:")
        (cls.root / "mixed.py").write_text("x = 1 / 0\n")
        (cls.root / "never.py").write_text("raise SystemExit(31)\n")
        shutil.copy(app.RUNTIME / ".mcp.json", cls.root / ".mcp.json")
        cls.before = files(cls.root)
        cls.call = cmd(
            "scan", "--repo", cls.root, "--out", cls.base / "out", "--candidates", 10
        )
        if cls.call.returncode != 2:
            raise RuntimeError(cls.call.stderr + cls.call.stdout)
        cls.run_dir = next((cls.base / "out").iterdir())
        cls.summary = app.read_json(cls.run_dir / "summary.json")
        cls.rows = app.read_json(cls.run_dir / "candidates.json")

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_read_only(self):
        self.assertEqual(self.before, files(self.root))

    def test_lock_missing(self):
        self.assertTrue(
            all(v["state"] == "MISSING" for v in self.summary["locks"].values())
        )

    def test_bridge(self):
        self.assertEqual(self.summary["backend"], "VeritasCeleritas_v1141.parallel_map")

    def test_duplicate_content(self):
        self.assertGreater(
            self.summary["checked_paths"], self.summary["unique_content_by_language"]
        )

    def test_syntax(self):
        self.assertEqual(self.summary["issues"]["PY.SYNTAX"], 2)

    def test_duplicate_json(self):
        self.assertEqual(self.summary["issues"]["JSON.DUPLICATE_KEY"], 1)

    def test_division(self):
        self.assertEqual(self.summary["issues"]["PY.LITERAL_ZERO_DIVISOR"], 1)

    def test_unchanged_test_files(self):
        self.assertFalse((self.run_dir / "candidates/test_guard.py").exists())

    def test_tls_bytes(self):
        self.assertEqual(
            (self.run_dir / "candidates/client.py").read_bytes(),
            self.tls.replace(b"False", b"True"),
        )

    def test_tls_behavior(self):
        import types

        for path, expected in [
            (self.root / "client.py", False),
            (self.run_dir / "candidates/client.py", True),
        ]:
            with patch.dict(
                sys.modules,
                {"requests": types.SimpleNamespace(get=lambda url, verify: verify)},
            ):
                namespace = {}
                exec(compile(path.read_bytes(), "<owned-fixture>", "exec"), namespace)
                self.assertIs(namespace["fetch"](), expected)

    @unittest.skipUnless(PWSH, "requires PowerShell 7")
    def test_ps_runtime_fixture(self):
        p = self.run_dir / "candidates/bad.ps1"
        actual = subprocess.run(
            [PWSH, "-NoProfile", "-NonInteractive", "-File", str(p)],
            capture_output=True,
            text=True,
            check=True,
        )
        self.assertEqual(actual.stdout.strip(), "ab")
        self.assertIn(b"\r\n", p.read_bytes())

    def test_patch_hashes(self):
        for r in self.rows:
            self.assertEqual(self.before[r["path"]], r["original_sha256"])
            self.assertEqual(
                app.sha((self.run_dir / "diffs" / (r["path"] + ".diff")).read_bytes()),
                r["diff_sha256"],
            )

    def test_mcp_discovery(self):
        self.assertEqual(
            [x["status"] for x in self.summary["mcp"].values()], ["VERIFIED"] * 3
        )

    def test_mcp_disallows_paths(self):
        reqs = [
            dict(jsonrpc="2.0", id=i, method="resources/read", params={"uri": uri})
            for i, uri in enumerate([app.MCP_URI, "file:///private"])
        ]
        resp = cmd(
            "serve",
            "--summary",
            self.run_dir / "summary.json",
            stdin="".join(json.dumps(q) + "\n" for q in reqs),
        )
        a, b = map(json.loads, resp.stdout.splitlines())
        self.assertNotIn("scope", json.loads(a["result"]["contents"][0]["text"]))
        self.assertIn("error", b)

    def test_output_boundary(self):
        self.assertNotEqual(
            cmd("scan", "--repo", self.root, "--out", self.root / "output").returncode,
            0,
        )
        self.assertFalse((self.root / "output").exists())

    def test_no_crossover(self):
        self.assertNotEqual(
            cmd(
                "scan",
                "--scope",
                "..",
                "--repo",
                self.root,
                "--out",
                self.base / "outside",
            ).returncode,
            0,
        )

    def test_ambiguity(self):
        p = self.base / "amb.py"
        p.write_bytes(self.tls + self.tls.split(b"\r\n", 1)[1])
        self.assertIsNone(app.python_candidate(p, app.sha(p.read_bytes())))

    def test_log_categories(self):
        path = self.base / "input.log"
        path.write_text(
            "HTTP 429\nOOMKilled\nZeroDivisionError SECRET-VALUE\nunknown\n"
        )
        output = self.base / "log.json"
        self.assertEqual(cmd("triage", "--log", path, "--out", output).returncode, 0)
        r = app.read_json(output)
        self.assertEqual(len(r["groups"]), 3)
        self.assertEqual(r["unmatched_lines"], 1)
        self.assertNotIn("SECRET-VALUE", output.read_text())
        self.assertNotEqual(cmd("triage", "--log", path, "--out", output).returncode, 0)

    def test_each_log_class(self):
        cases = """NullPointerException
memory leak
IndexError
infinite loop
data race
thread deadlock
TypeError
uncaught exception
SQL injection
cross-site scripting
buffer overflow
unclosed file
ZeroDivisionError
precision loss
quadratic complexity
ReadTimeout
schema mismatch
HTTP 502
HTTP 403
CORS policy
queue backlog
duplicate message
ConnectionRefusedError
unsupported API version
HTTP 429
serialization error
in-doubt transaction
TLS handshake failed
misrouted request
cascading failure
OOMKilled
CPU throttling
disk full
too many open files
connection pool exhausted
database deadlock
CrashLoopBackOff
ImagePullBackOff
packet loss
clock skew
missing environment variable
zombie process
cache stampede
PermissionError
IOPS throttling""".splitlines()
        log = self.base / "all45.log"
        out = self.base / "all45.json"
        log.write_text("\n".join(cases), encoding="utf-8")
        self.assertEqual(cmd("triage", "--log", log, "--out", out).returncode, 0)
        obj = app.read_json(out)
        self.assertEqual(obj["unmatched_lines"], 0)
        self.assertEqual([x["first_line"] for x in obj["groups"]], list(range(1, 46)))
        self.assertEqual(obj["native_digest"]["state"], "NODATA")

    def test_catalog_size(self):
        from collections import Counter

        catalog = app.read_json(HERE / "error_catalog.json")
        self.assertEqual(
            sorted(Counter(r["layer"] for r in catalog).values()), [15, 15, 15]
        )
        self.assertEqual(len(set(r["id"] for r in catalog)), 45)


if __name__ == "__main__":
    unittest.main(verbosity=2)
