"""VCGC 安全修正引擎 v0100 · CLI / MCP。Python 3.11+"""

from __future__ import annotations

import argparse
import ast
import codecs
import difflib
import hashlib
import importlib.util
import io
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import tokenize
import uuid
import warnings
from collections import Counter, defaultdict
from contextlib import redirect_stdout
from pathlib import Path
from typing import Any

# 參數與固定來源
VERSION = "v0100"
REVISION = "e5c5d5c977245dde4185c0a5741d0650bb451f3f"
HOME_DIR = Path(__file__).resolve().parent
RUNTIME = HOME_DIR / "runtime"
VIA = Path("VeritasIntelligenceAnalytics")
SUPPORT = VIA / "supportive modules"
REGISTRY = SUPPORT / "registry"
LOCK = REGISTRY / "VIA_ToolVersion_Lock_v0100.json"
PS_TOOL = REGISTRY / "CGC_MDL146_PsAstRepair_v0104.py"
DEFAULT_WORKERS = 4
HEAVY_BYTES = 4 * 1024 * 1024
MAX_BYTES = 64 * 1024 * 1024
PS_BATCH = 96
TIMEOUT = 90
EXT = {".py", ".ps1", ".psm1", ".json"}
EXCLUDE = {".git", ".venv", "node_modules", "__pycache__", ".pytest_cache"}
PROTECTED = {"ssot", "tests", "test", "fixtures", "archive", "references", "intake"}
PS_CODE = """
$ErrorActionPreference='Stop'
[Console]::InputEncoding=[Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding=[Console]::InputEncoding
$paths=ConvertFrom-Json -InputObject ([Console]::In.ReadToEnd()) -NoEnumerate
$result=foreach ($p in $paths) {
  $tokens=$null
  $errors=$null
  $null=[System.Management.Automation.Language.Parser]::ParseFile($p,[ref]$tokens,[ref]$errors)
  @{path=$p; errors=@(foreach ($e in $errors) {@{line=$e.Extent.StartLineNumber; code=$e.ErrorId}})}
}
ConvertTo-Json -InputObject @($result) -Depth 5 -Compress
"""
MCP_VERSIONS = {
    "vcgc": "2025-06-18",
    "via-agentos": "2025-11-25",
    "via-systemcard": "2025-06-18",
}
MCP_URI = "via://safe-repair/summary"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def dump(path, obj):
    path.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )


def read_json(path):
    return json.loads(path.read_bytes())


def load_exact(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(str(path))
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


# [VIA:ACCEL-BRIDGE] 從包內核對過的原始碼建立私有 runtime；研究目標只作資料讀取。
def stage_runtime(tmp):
    for rel, expected in read_json(HOME_DIR / "runtime.sha256.json").items():
        raw = (RUNTIME / rel).read_bytes()
        if sha(raw) != expected:
            raise ValueError("套件檔案指紋不符 " + rel)
        dest = tmp / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(raw)


def activate(tmp):
    stage_runtime(tmp)
    lock = read_json(tmp / LOCK)["accelerator"]
    if sha((tmp / lock["path"]).read_bytes()) != lock["sha256"]:
        raise ValueError("加速器與工具鎖冊不符")
    sys.path.insert(0, str(tmp / SUPPORT))
    bridge = load_exact(
        tmp / SUPPORT / "VIA_SuperAccel_Module.py", "VIA_SuperAccel_Module"
    )
    cel = bridge.celeritas()
    if not cel or Path(cel.__file__).resolve() != (tmp / lock["path"]).resolve():
        raise RuntimeError("SuperAccel 未載入鎖定 Celeritas")
    return cel, load_exact(tmp / PS_TOOL, "via_ps_repair")


def finding(code, line=0, detail=""):
    return {"code": code, "line": line, "detail": detail}


def python_checks(raw):
    tree = compile(raw, "<input>", "exec", ast.PyCF_ONLY_AST | ast.PyCF_TYPE_COMMENTS)
    compile(tree, "<input>", "exec")
    issues = []
    for n in ast.walk(tree):
        if (
            isinstance(n, ast.BinOp)
            and isinstance(n.op, (ast.Div, ast.FloorDiv, ast.Mod))
            and isinstance(n.right, ast.Constant)
            and type(n.right.value) in (int, float)
            and n.right.value == 0
        ):
            issues.append(finding("PY.LITERAL_ZERO_DIVISOR", n.lineno))
        if isinstance(n, ast.Call):
            name = (
                n.func.id
                if isinstance(n.func, ast.Name)
                else getattr(n.func, "attr", "")
            )
            if name in {"eval", "exec"}:
                issues.append(finding("PY.DYNAMIC_CODE_REVIEW", n.lineno))
            for kw in n.keywords:
                if (
                    kw.arg == "verify"
                    and isinstance(kw.value, ast.Constant)
                    and kw.value.value is False
                ):
                    issues.append(finding("PY.VERIFY_FALSE_REVIEW", kw.value.lineno))
    return issues


def json_checks(raw):
    duplicates = []

    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                duplicates.append(finding("JSON.DUPLICATE_KEY"))
            out[key] = value
        return out

    def reject_constant(value):
        raise ValueError("non-standard numeric constant")

    json.loads(raw, object_pairs_hook=pairs, parse_constant=reject_constant)
    return duplicates


def analyze_file(item):
    ext, path, digest = item
    try:
        raw = path.read_bytes()
        if sha(raw) != digest:
            return [finding("INPUT.CHANGED")]
        if ext == ".py":
            return python_checks(raw)
        return json_checks(raw)
    except SyntaxError as e:
        return [finding("PY.SYNTAX", e.lineno or 0, type(e).__name__)]
    except json.JSONDecodeError as e:
        return [finding("JSON.INVALID", e.lineno)]
    except (ValueError, UnicodeError, OSError, RecursionError) as e:
        return [finding("INPUT.UNREADABLE", detail=type(e).__name__)]


def read_ps(pwsh, paths, cwd):
    try:
        pr = subprocess.run(
            [
                pwsh,
                "-NoLogo",
                "-NoProfile",
                "-NonInteractive",
                "-EncodedCommand",
                codecs.encode(PS_CODE.encode("utf-16-le"), "base64")
                .decode()
                .replace("\n", ""),
            ],
            check=False,
            input=json.dumps([str(p) for p in paths]),
            cwd=cwd,
            encoding="utf-8",
            capture_output=True,
            timeout=TIMEOUT,
        )
        rows = json.loads(pr.stdout)
        if pr.returncode or [r["path"] for r in rows] != [str(p) for p in paths]:
            raise ValueError("parser response")
        return [
            [finding("PS.PARSE", e["line"], e["code"]) for e in row["errors"]]
            for row in rows
        ]
    except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired):
        return [[finding("PS.PARSER_UNAVAILABLE")] for p in paths]


def collect(root):
    groups = defaultdict(list)
    skipped: list[dict] = []
    counts: Counter[str] = Counter()

    def record_error(e):
        skipped.append({"path": str(e.filename), "reason": "OS_ERROR"})

    for folder, dirs, names in os.walk(root, onerror=record_error):
        dirs.sort()
        for d in dirs[:]:
            p = Path(folder) / d
            if (
                d in EXCLUDE
                or p.is_symlink()
                or getattr(p.lstat(), "st_file_attributes", 0)
                & stat.FILE_ATTRIBUTE_REPARSE_POINT
            ):
                dirs.remove(d)
                skipped.append(
                    {
                        "path": p.relative_to(root).as_posix(),
                        "reason": "EXCLUDED_DIRECTORY",
                    }
                )
        for name in sorted(names):
            p = Path(folder) / name
            ext = p.suffix.lower()
            counts[ext or "(none)"] += 1
            if ext not in EXT:
                continue
            rel = p.relative_to(root).as_posix()
            try:
                meta = p.lstat()
                if (
                    not stat.S_ISREG(meta.st_mode)
                    or getattr(meta, "st_file_attributes", 0)
                    & stat.FILE_ATTRIBUTE_REPARSE_POINT
                    or meta.st_size > MAX_BYTES
                ):
                    skipped.append({"path": rel, "reason": "LINK_SPECIAL_OR_SIZE"})
                    continue
                raw = p.read_bytes()
                groups[(ext, sha(raw))].append(p)
            except OSError as e:
                skipped.append({"path": rel, "reason": type(e).__name__})
    return groups, skipped, counts


def protected(path):
    return bool(
        {part.casefold() for part in path.parts} & PROTECTED
        or any(
            x in path.name.casefold()
            for x in ("test", "ssot", "registry", "lock", "manifest")
        )
    )


def make_candidate(path, digest, issues, native, pwsh, tmp):
    raw = path.read_bytes()
    if sha(raw) != digest or path.suffix.lower() not in (".ps1", ".psm1"):
        return None
    lines = [r["line"] for r in issues if r["code"] == "PS.PARSE"]
    if not lines:
        return None
    bom = codecs.BOM_UTF8 if raw.startswith(codecs.BOM_UTF8) else b""
    try:
        source = raw[len(bom) :].decode("utf-8")
    except UnicodeDecodeError:
        return None
    if "# sig # begin signature block" in source.lower() or "\x00" in source:
        return None
    ends = source.replace("\r\n", "")
    if "\r" in ends or ("\r\n" in source and "\n" in ends):
        return None
    fixes = [
        (h, native.fix_f1)
        for h in native.detect_f1(source)
        if any(abs(h["line"] - n) <= 1 for n in lines)
    ]
    fixes.extend(
        (h, native.fix_f1b) for h in native.detect_f1b(source, lines, window=1)
    )
    if len(fixes) != 1:
        return None
    hit, fn = fixes[0]
    updated, count = fn(source, [hit])
    if "\r\n" in source:
        updated = updated.replace("\n", "\r\n")
    if count != 1 or source == updated:
        return None
    new = bom + updated.encode("utf-8")
    temp = tmp / ("candidate" + path.suffix)
    temp.write_bytes(new)
    if read_ps(pwsh, [temp], tmp) != [[]]:
        return None
    return new, hit["line"], hit["kind"]


def python_candidate(path, digest):
    raw = path.read_bytes()
    if sha(raw) != digest:
        return None
    encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
    if encoding.lower().replace("_", "-") not in ("utf-8", "utf-8-sig"):
        return None
    source = raw.decode(encoding)
    tree = ast.parse(source, type_comments=True)
    if not any(
        isinstance(n, ast.Import)
        and any(a.name == "requests" and a.asname is None for a in n.names)
        for n in tree.body
    ):
        return None
    sites: list[ast.Constant] = []
    for n in ast.walk(tree):
        if (
            isinstance(n, ast.Call)
            and isinstance(n.func, ast.Attribute)
            and isinstance(n.func.value, ast.Name)
            and n.func.value.id == "requests"
            and n.func.attr
            in {"get", "post", "put", "delete", "patch", "head", "options", "request"}
        ):
            sites.extend(
                kw.value
                for kw in n.keywords
                if kw.arg == "verify"
                and isinstance(kw.value, ast.Constant)
                and kw.value.value is False
            )
    if len(sites) != 1:
        return None
    node = sites[0]
    lines = source.encode("utf-8").splitlines(keepends=True)
    row = lines[node.lineno - 1]
    if row[node.col_offset : node.end_col_offset] != b"False":
        return None
    lines[node.lineno - 1] = (
        row[: node.col_offset] + b"True" + row[node.end_col_offset :]
    )
    new = b"".join(lines).decode("utf-8").encode(encoding)
    # Reparse the exact resulting bytes and compare to a single-node AST mutation.
    node.value = True
    if ast.dump(
        compile(new, "<candidate>", "exec", ast.PyCF_ONLY_AST | ast.PyCF_TYPE_COMMENTS)
    ) != ast.dump(tree):
        return None
    compile(new, "<candidate>", "exec")
    return new, node.lineno, "REQUESTS_TLS_VERIFY"


def lock_inventory(repo):
    lock = read_json(RUNTIME / LOCK)
    results = {}
    for key, meta in lock.items():
        if not isinstance(meta, dict) or "sha256" not in meta:
            continue
        p = repo / meta["path"]
        state = "MISSING"
        if p.resolve().is_relative_to(repo) and p.is_file():
            state = "MATCH" if sha(p.read_bytes()) == meta["sha256"] else "DRIFT"
        results[key] = {
            "version": meta["version"],
            "state": state,
            "path": meta["path"],
        }
    return results


def discover_mcp(repo, tmp):
    canonical = read_json(tmp / ".mcp.json")["mcpServers"]
    try:
        configured = read_json(repo / ".mcp.json")["mcpServers"]
        if not isinstance(configured, dict):
            raise TypeError("mcpServers")
    except (OSError, ValueError, KeyError, TypeError):
        return {"configuration": {"status": "MISSING_OR_INVALID"}}
    results: dict[str, dict[str, Any]] = {}
    for name in sorted(set(configured) | set(canonical)):
        if name not in canonical or canonical[name] != configured.get(name):
            results[name] = {"status": "CONFIG_DRIFT_OR_UNSUPPORTED"}
            continue
        args = canonical[name]["args"].copy()
        args[0] = str(tmp / args[0])
        if name == "vcgc":
            args[-1] = str(repo / VIA)
        if name == "via-agentos":
            args[-1] = str(repo)
        version = MCP_VERSIONS[name]
        msgs = [
            {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "initialize",
                "params": {
                    "protocolVersion": version,
                    "capabilities": {},
                    "clientInfo": {"name": "vcgc-safe-repair", "version": VERSION},
                },
            },
            {"jsonrpc": "2.0", "method": "notifications/initialized"},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list", "params": {}},
        ]
        if name == "vcgc":
            msgs.append(
                {"jsonrpc": "2.0", "id": 3, "method": "resources/list", "params": {}}
            )
        try:
            res = subprocess.run(
                [sys.executable, "-I", "-B", *args],
                check=False,
                input="".join(json.dumps(m) + "\n" for m in msgs),
                capture_output=True,
                encoding="utf-8",
                cwd=tmp,
                timeout=TIMEOUT,
                env=dict(
                    os.environ, PYTHONUTF8="1", VIA_FROM_VCGC="YES", VIA_NO_OPEN="1"
                ),
            )
            packets = [json.loads(x) for x in res.stdout.splitlines() if x.strip()]
            replies = {p["id"]: p["result"] for p in packets}
            names = [t["name"] for t in replies[2]["tools"]]
            if res.returncode or not names or replies[1]["protocolVersion"] != version:
                raise ValueError("incomplete handshake")
            results[name] = {
                "status": "VERIFIED",
                "server": replies[1]["serverInfo"],
                "protocol": version,
                "tools": names,
                "resources": [
                    r["uri"] for r in replies.get(3, {}).get("resources", [])
                ],
            }
        except (
            ValueError,
            TypeError,
            KeyError,
            OSError,
            subprocess.TimeoutExpired,
        ) as e:
            results[name] = {"status": "FAILED", "error": type(e).__name__}
    return results


def run_scan(repo, scope, run, tmp, workers, limit):
    with redirect_stdout(sys.stderr):
        cel, native = activate(tmp)
    groups, skipped, counts = collect(scope)
    jobs = [
        (ext, paths[0], digest)
        for (ext, digest), paths in groups.items()
        if ext in (".py", ".json")
    ]
    results = {}
    budget = max(1, min(workers, cel.thread_budget()))
    print(
        f"[1/3] {sum(map(len, groups.values()))} files in scope; Python / JSON analysis",
        file=sys.stderr,
        flush=True,
    )
    heavy: list[tuple] = []
    light: list[tuple] = []
    for job in jobs:
        try:
            lane = heavy if job[1].stat().st_size > HEAVY_BYTES else light
            lane.append(job)
        except OSError:
            results[job[0], job[2]] = [finding("INPUT.CHANGED")]
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", SyntaxWarning)
        for job in heavy:
            results[job[0], job[2]] = analyze_file(job)
        for start in range(0, len(light), 256):
            batch = light[start : start + 256]
            values = cel.parallel_map(
                analyze_file, batch, max_workers=budget, mode="thread"
            )
            for (ext, p, digest), value in zip(batch, values, strict=True):
                results[ext, digest] = (
                    value
                    if isinstance(value, list)
                    else [finding("CHECK.ERROR", detail=type(value).__name__)]
                )
    powers = [(k, paths[0]) for k, paths in groups.items() if k[0] in (".ps1", ".psm1")]
    print(
        f"[2/3] PowerShell AST: {len(powers)} unique inputs",
        file=sys.stderr,
        flush=True,
    )
    pwsh = shutil.which("pwsh")
    for start in range(0, len(powers), PS_BATCH):
        ps_batch = powers[start : start + PS_BATCH]
        # Parse a frozen copy of each content blob. Keys cannot be reused across changed bytes.
        ready = []
        for k, p in ps_batch:
            staged = tmp / (k[1] + k[0])
            try:
                raw = p.read_bytes()
                if sha(raw) != k[1]:
                    raise ValueError()
                staged.write_bytes(raw)
                ready.append((k, staged))
            except (ValueError, OSError):
                results[k] = [finding("INPUT.CHANGED")]
        if ready:
            parsed = (
                read_ps(pwsh, [p for _, p in ready], tmp)
                if pwsh
                else [[finding("PS.PARSER_UNAVAILABLE")] for _ in ready]
            )
            for (k, p), value in zip(ready, parsed, strict=True):
                results[k] = value
                p.unlink()
    print(
        "[3/3] Candidate validation, lock inventory and MCP",
        file=sys.stderr,
        flush=True,
    )
    locked_paths = {
        v["path"]
        for v in read_json(RUNTIME / LOCK).values()
        if isinstance(v, dict) and "path" in v
    }
    findings: list[dict] = []
    candidates: list[dict] = []
    for key, paths in groups.items():
        issues = results[key]
        if not issues:
            continue
        for p in paths:
            rel = p.relative_to(scope)
            findings.append(
                {"path": rel.as_posix(), "sha256": key[1], "issues": issues}
            )
            if (
                len(candidates) >= limit
                or p.relative_to(repo).as_posix() in locked_paths
                or protected(rel)
                or protected(p.relative_to(repo))
            ):
                continue
            cand = None
            try:
                if key[0] in (".ps1", ".psm1") and pwsh:
                    cand = make_candidate(p, key[1], issues, native, pwsh, tmp)
                elif key[0] == ".py" and any(
                    i["code"] == "PY.VERIFY_FALSE_REVIEW" for i in issues
                ):
                    cand = python_candidate(p, key[1])
                original = p.read_bytes() if cand else b""
            except OSError:
                skipped.append(
                    {"path": rel.as_posix(), "reason": "CANDIDATE_SOURCE_CHANGED"}
                )
                continue
            if cand:
                new, line, kind = cand
                if sha(original) != key[1]:
                    continue
                dest = run / "candidates" / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(new)
                diff = b"".join(
                    difflib.diff_bytes(
                        difflib.unified_diff,
                        original.splitlines(keepends=True),
                        new.splitlines(keepends=True),
                        ("a/" + rel.as_posix()).encode(),
                        ("b/" + rel.as_posix()).encode(),
                    )
                )
                patch = run / "diffs" / (rel.as_posix() + ".diff")
                patch.parent.mkdir(parents=True, exist_ok=True)
                patch.write_bytes(diff)
                candidates.append(
                    {
                        "path": rel.as_posix(),
                        "scope": str(scope),
                        "line": line,
                        "anchor": kind,
                        "original_sha256": key[1],
                        "candidate_sha256": sha(new),
                        "diff_sha256": sha(diff),
                        "original_findings": len(issues),
                        "candidate_parse_errors": 0,
                        "runtime_test": "NOT_RUN",
                        "decision": "REVIEW",
                    }
                )
    inventory = lock_inventory(repo)
    mcp = discover_mcp(repo, tmp)
    checked = sum(map(len, groups.values()))
    summary = {
        "engine": VERSION,
        "upstream": REVISION,
        "engine_sha256": sha(Path(__file__).read_bytes()),
        "scope": str(scope),
        "workers": budget,
        "backend": "VeritasCeleritas_v1141.parallel_map",
        "files_seen": sum(counts.values()),
        "extension_counts": dict(counts),
        "checked_paths": checked,
        "unique_content_by_language": len(groups),
        "files_with_findings": len(findings),
        "issues": dict(Counter(i["code"] for f in findings for i in f["issues"])),
        "skipped_entries": len(skipped),
        "candidate_count": len(candidates),
        "locks": inventory,
        "mcp": mcp,
        "status": "REVIEW"
        if findings
        or skipped
        or not checked
        or any(v["state"] != "MATCH" for v in inventory.values())
        or any(v["status"] != "VERIFIED" for v in mcp.values())
        else "CHECKS_CLEAR",
        "acceptance": "NOT_RUN",
        "candidate_execution": "NOT_RUN",
    }
    for filename, obj in [
        ("findings.json", findings),
        ("skipped.json", skipped),
        ("candidates.json", candidates),
        ("summary.json", summary),
    ]:
        dump(run / filename, obj)
    return summary


def serve(summary):
    # 固定資源：用戶端不能傳檔案路徑或執行命令。
    public = {
        k: summary[k]
        for k in (
            "engine",
            "upstream",
            "status",
            "acceptance",
            "checked_paths",
            "files_with_findings",
            "issues",
            "candidate_count",
        )
    }
    for line in sys.stdin:
        result: dict[str, Any]
        packet: dict[str, Any]
        request_id = None
        try:
            msg = json.loads(line)
            if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0":
                raise ValueError()
            request_id = msg.get("id")
            if "id" not in msg:
                continue
            method = msg["method"]
            if method == "initialize":
                result = {
                    "protocolVersion": "2025-06-18",
                    "capabilities": {"resources": {}},
                    "serverInfo": {"name": "vcgc-safe-repair", "version": VERSION},
                }
            elif method == "resources/list":
                result = {
                    "resources": [
                        {
                            "uri": MCP_URI,
                            "name": "安全修正摘要",
                            "mimeType": "application/json",
                        }
                    ]
                }
            elif method == "resources/read":
                if msg.get("params", {}).get("uri") != MCP_URI:
                    raise KeyError()
                result = {
                    "contents": [
                        {
                            "uri": MCP_URI,
                            "mimeType": "application/json",
                            "text": json.dumps(public, ensure_ascii=False),
                        }
                    ]
                }
            elif method == "ping":
                result = {}
            else:
                raise NotImplementedError()
            packet = {"result": result}
        except (
            ValueError,
            KeyError,
            TypeError,
            AttributeError,
            NotImplementedError,
        ) as e:
            code = (
                -32700
                if isinstance(e, json.JSONDecodeError)
                else -32601
                if isinstance(e, NotImplementedError)
                else -32602
            )
            packet = {
                "error": {"code": code, "message": "Invalid or unsupported request"}
            }
        print(
            json.dumps(
                {"jsonrpc": "2.0", "id": request_id, **packet}, ensure_ascii=True
            ),
            flush=True,
        )


def native_digest(log, expected):
    if log.stat().st_size > HEAVY_BYTES:
        return {"state": "SKIPPED_SIZE"}
    raw = log.read_bytes()
    if sha(raw) != expected:
        return {"state": "INPUT_CHANGED"}
    with tempfile.TemporaryDirectory(prefix="vcgc-digest-") as temp:
        tmp = Path(temp)
        stage_runtime(tmp)
        meta = read_json(tmp / LOCK)["token"]
        path = tmp / meta["path"]
        if sha(path.read_bytes()) != meta["sha256"]:
            raise ValueError("Token 工具指紋不符")
        with redirect_stdout(sys.stderr):
            module = load_exact(path, "vcgc_native_token")
            d = module.digest_log(raw.decode("utf-8", errors="replace"))
        return {
            "version": meta["version"],
            "state": d["state"],
            "rows": d["rows"],
            "failed": len(d["fails"]),
            "flipped": len(d["flipped"]),
        }


def triage(log, out):
    catalog = read_json(HOME_DIR / "error_catalog.json")
    rules = [(r, re.compile("|".join(r["signals"]), re.IGNORECASE)) for r in catalog]
    counts: Counter[str] = Counter()
    first: dict[str, int] = {}
    digest = hashlib.sha256()
    unmatched = 0
    with log.open("rb") as stream:
        for lineno, raw in enumerate(stream, 1):
            digest.update(raw)
            line = raw.decode("utf-8", errors="replace")
            hits = [r["id"] for r, regex in rules if regex.search(line)]
            unmatched += int(not hits)
            for key in hits:
                counts[key] += 1
                first.setdefault(key, lineno)
    result = {
        "source_sha256": digest.hexdigest(),
        "native_digest": native_digest(log, digest.hexdigest()),
        "unmatched_lines": unmatched,
        "inference": "SIGNAL_ONLY",
        "groups": [
            {
                "id": r["id"],
                "label": r["label"],
                "count": counts[r["id"]],
                "first_line": first[r["id"]],
                "next_step": r["next_step"],
            }
            for r in catalog
            if counts[r["id"]]
        ],
    }
    with out.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    scan = sub.add_parser("scan")
    scan.add_argument("--repo", type=Path, required=True, help="movies-dataset 根目錄")
    scan.add_argument("--scope", type=Path, help="相對 repo 的掃描子目錄，預設整倉")
    scan.add_argument("--out", type=Path, required=True, help="倉外收據父目錄")
    scan.add_argument("--workers", type=int, default=DEFAULT_WORKERS)
    scan.add_argument(
        "--candidates",
        type=int,
        default=0,
        help="最多輸出的獨立候選數，可用 --scope 限定",
    )
    sub.add_parser("serve").add_argument("--summary", type=Path, required=True)
    logs = sub.add_parser("triage", help="從現有 UTF-8 日誌將訊號對照 45 類錯誤")
    logs.add_argument("--log", type=Path, required=True)
    logs.add_argument("--out", type=Path, required=True, help="新的 JSON 檔名")
    args = parser.parse_args()
    if args.command == "triage":
        triage(args.log, args.out)
        return 0
    if args.command == "serve":
        serve(read_json(args.summary))
        return 0
    repo = args.repo.resolve(strict=True)
    scope = (repo / (args.scope or ".")).resolve(strict=True)
    out = args.out.resolve()
    if not scope.is_relative_to(repo) or not scope.is_dir() or out.is_relative_to(repo):
        parser.error("掃描範圍須在倉內，輸出須在倉外。")
    if args.workers < 1 or args.candidates < 0:
        parser.error("workers 須為正整數，candidates 須為非負整數。")
    run = out / ("run-" + uuid.uuid4().hex)
    run.mkdir(parents=True, exist_ok=False)
    with tempfile.TemporaryDirectory(prefix="vcgc-safe-") as temp:
        original = Path.cwd()
        try:
            os.chdir(temp)
            summary = run_scan(
                repo, scope, run, Path(temp).resolve(), args.workers, args.candidates
            )
        finally:
            os.chdir(original)
    print(
        json.dumps(
            {
                "status": summary["status"],
                "checked": summary["checked_paths"],
                "summary": str(run / "summary.json"),
            },
            ensure_ascii=True,
        )
    )
    return 2 if summary["status"] == "REVIEW" else 0


if __name__ == "__main__":
    raise SystemExit(main())
