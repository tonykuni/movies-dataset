@echo off
setlocal
set "viaSource=%USERPROFILE%\OneDrive\Documents\movies-dataset"
set "viaOutput=%LOCALAPPDATA%\VIA\SafeRepair"
if not "%~1"=="" set "viaSource=%~f1"
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 -I -B "%~dp0VCGC_SafeRepair.py" scan --repo "%viaSource%" --out "%viaOutput%" --candidates 10
goto finish
:usepython
python -I -B "%~dp0VCGC_SafeRepair.py" scan --repo "%viaSource%" --out "%viaOutput%" --candidates 10
:finish
set "viaRc=%ERRORLEVEL%"
echo Exit %viaRc% - reports: "%viaOutput%"
pause
exit /b %viaRc%
