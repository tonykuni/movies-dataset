"""比對單一 Python 候選的三種獨立靜態檢查，結果寫成新收據。"""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from contextlib import redirect_stdout
from pathlib import Path
from typing import Any

ENGINE = Path(__file__).with_name("VCGC_SafeRepair.py")
TIMEOUT = 90
TOOLS = ("ruff", "bandit", "mypy")


def run_tool(job):
    name, source, root = job
    executable = shutil.which(name)
    if not executable:
        return {"status": "MISSING", "codes": {}}
    target = root / name
    target.mkdir()
    (target / "subject.py").write_bytes(source)
    args = {
        "ruff": [
            "check",
            "--isolated",
            "--no-cache",
            "--select",
            "E9,F,B,S",
            "--output-format",
            "json",
            "subject.py",
        ],
        "bandit": ["-q", "-f", "json", "subject.py"],
        "mypy": [
            "--config-file",
            "empty.ini",
            "--no-incremental",
            "--check-untyped-defs",
            "--follow-imports",
            "skip",
            "--ignore-missing-imports",
            "--show-error-codes",
            "subject.py",
        ],
    }
    (target / "empty.ini").write_text("[mypy]\n", encoding="ascii")
    try:
        p = subprocess.run(
            [executable, *args[name]],
            cwd=target,
            check=False,
            capture_output=True,
            env=dict(os.environ, PYTHONUTF8="1"),
            encoding="utf-8",
            timeout=TIMEOUT,
        )
        if p.returncode not in (0, 1):
            raise RuntimeError("tool exit")
        if name == "mypy":
            codes = re.findall(
                r"^.*: error: .*?\[([\w-]+)\]\s*$", p.stdout, re.MULTILINE
            )
        elif name == "bandit":
            report = json.loads(p.stdout)
            if report["errors"] or len(report["metrics"]) < 2:
                raise ValueError("incomplete Bandit report")
            codes = [r["test_id"] for r in report["results"]]
        else:
            codes = [r["code"] for r in json.loads(p.stdout)]
        if bool(codes) != bool(p.returncode):
            raise ValueError("inconsistent result")
        return {"status": "CHECKED", "rc": p.returncode, "codes": dict(Counter(codes))}
    except (
        ValueError,
        KeyError,
        RuntimeError,
        OSError,
        subprocess.TimeoutExpired,
    ) as e:
        return {"status": "ERROR", "reason": type(e).__name__, "codes": {}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("before", "after", "out"):
        parser.add_argument("--" + key, type=Path, required=True)
    args = parser.parse_args()
    if args.before.suffix.lower() != ".py" or args.after.suffix.lower() != ".py":
        parser.error("需提供原始與候選 Python 檔")
    spec = importlib.util.spec_from_file_location("safe_repair", ENGINE)
    if spec is None or spec.loader is None:
        raise ImportError(str(ENGINE))
    core = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(core)
    result: dict[str, Any] = {
        "business_regression": "NOT_RUN",
        "scope": "single-file static rule counts",
    }
    raw_before = args.before.read_bytes()
    raw_after = args.after.read_bytes()
    with tempfile.TemporaryDirectory(prefix="vcgc-compare-") as temp:
        root = Path(temp)
        # [VIA:ACCEL-BRIDGE] 使用主引擎同一經驗證的 SuperAccel / Celeritas 橋。
        original = Path.cwd()
        try:
            os.chdir(root)
            with redirect_stdout(sys.stderr):
                accel, _ = core.activate(root)
            for label, raw in [("before", raw_before), ("after", raw_after)]:
                stage = root / label
                stage.mkdir()
                checked = accel.parallel_map(
                    run_tool, [(t, raw, stage) for t in TOOLS], max_workers=3
                )
                if any(not isinstance(r, dict) for r in checked):
                    raise RuntimeError("驗證器工作站失敗")
                result[label] = {
                    "sha256": core.sha(raw),
                    "tools": dict(zip(TOOLS, checked, strict=True)),
                }
        finally:
            os.chdir(original)
    delta = {}
    complete = True
    for tool in TOOLS:
        old, new = (result[s]["tools"][tool] for s in ("before", "after"))
        if old["status"] != "CHECKED" or new["status"] != "CHECKED":
            complete = False
            continue
        delta[tool] = dict(Counter(new["codes"]) - Counter(old["codes"]))
    result["increased_counts"] = delta
    result["status"] = (
        "INCOMPLETE"
        if not complete
        else "REVIEW"
        if any(delta.values())
        else "NO_RULE_COUNT_INCREASE"
    )
    with args.out.open("x", encoding="utf-8") as out:
        json.dump(result, out, ensure_ascii=False, indent=2)
    print(result["status"])
    return 0 if result["status"] == "NO_RULE_COUNT_INCREASE" else 2


if __name__ == "__main__":
    raise SystemExit(main())
