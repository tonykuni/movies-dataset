# VCGC 安全修正引擎 v0100

這是可在倉外執行的候選引擎。固定工具來源為 tonykuni/movies-dataset 的 e5c5d5c977245dde4185c0a5741d0650bb451f3f。適用 Python 3.11 以上，PowerShell 檢查需要命令列能找到 pwsh。先開啟隨附的 Panorama.html 查看本次實測數字、原生紅燈與候選。

## Windows 開始使用

1. 將整包解壓到專案以外的資料夾，保留 runtime 與指紋檔。
2. 雙擊 Start-VCGC-SafeRepair.cmd。預設讀取 %USERPROFILE%\OneDrive\Documents\movies-dataset，在 %LOCALAPPDATA%\VIA\SafeRepair 建立獨立的 run-* 資料夾，最多生成 10 個候選。命令列也可把倉庫根目錄當作第一個參數。
3. 先讀 summary.json。findings.json 依相對路徑給出規則及行號，skipped.json 列出跳過項。candidates.json 記錄原檔、候選及 diff 的 SHA-256。每次執行使用新目錄，可直接丟棄整次候選。解壓後的實測證據在 evidence。

在解壓資料夾開啟 PowerShell 7，可指定範圍與候選上限。

```powershell
$repo = Join-Path $env:USERPROFILE 'OneDrive\Documents\movies-dataset'
$out = Join-Path $env:LOCALAPPDATA 'VIA\SafeRepair'
py -3 -I -B .\VCGC_SafeRepair.py scan --repo $repo --scope 'VeritasIntelligenceAnalytics/supportive modules/registry' --out $out --workers 4 --candidates 3
```

scan 退出碼 0 表示本次檢查範圍內無待查項，2 表示需查閱收據或指令參數錯誤。有收據時以 summary.json 的狀態判讀。候選的業務測試狀態另記。操作臺的中央發號、正式註冊與 Windows 驗收須沿 VCGC 原流程辦理。

## 工具如何參與

| 工具 | 此版實際工作 |
|---|---|
| SuperAccel / Celeritas v1141 | 核對套件與鎖冊指紋，從原生橋取得加速器，使用 thread_budget 和 parallel_map。相同副檔名、相同內容共用一次分析，每個來源路徑保留。大於 4 MiB 的 Python / JSON 逐檔分析。|
| MDL146 v0104、PowerShell 7 Parser | 批次解析 PS1 / PSM1。對解析錯誤附近的單一 F1 或 F1b 錨點生成候選，再次用原生 Parser 驗證。遇到已簽署腳本或混合換行僅列待查。|
| Python AST 與 JSON 讀取器 | 驗證 Python 語法、動態執行、字面零分母、verify=False，並檢查 JSON 語法及重複鍵。單一 requests 呼叫的憑證驗證旗標可產生候選，重新編譯並比對 AST，其他節點須相同。內部 CA 或代理環境仍需整合測試。|
| MDL158 v0119 | triage 呼叫原生 digest_log 判讀 VCGC 測試總表，同時依附件的 45 類訊號聚合日誌。每類列第一次出現行號、命中次數及查證步驟。超過 4 MiB 保留逐行分類，省略原生日誌摘要。|
| VCGC / AgentOS / SystemCard | 核對專案 .mcp.json 登錄的三個入口，以固定版服務在本機 stdio 實跑 initialize、tools/list，VCGC 另列出資源。設定差異與未知服務會列入狀態。|
| Ruff、Bandit、mypy | verify_candidate.py 使用本機已安裝的 CLI 分別檢查複製出的原始及候選 Python 檔，輸出各規則代碼及新增數量。缺項回 INCOMPLETE。|
| 網路、NLP、表格、PDF、OCR、版面 | 全部納入 9 項鎖冊對帳。離線程式碼掃描使用上表對應模組，其餘保留原系統入口。|

候選保留在 candidates/，差異位於 diffs/。掃描包含歷史版、封存品、樣本與引擎。靜態訊號需結合實際入口、呼叫路徑與資料契約判讀。預設每檔上限 64 MiB。根目錄版本、收據日期及 Windows 未提交變更可能與本次 Git 快照不同。此版在單次掃描內按指紋去重，每次新掃描重新取證。

## 驗證與重跑

```powershell
py -3 -I -B .\selftest.py
py -3 -I -B .\VCGC_SafeRepair.py triage --log .\evidence\ps-native.log --out .\my-triage.json
py -3 -I -B .\verify_candidate.py --before 'C:\path\original.py' --after 'C:\path\candidate.py' --out .\candidate-check.json
```

最後一行請換成實際的原檔、候選路徑。驗證器在獨立目錄執行 Ruff、Bandit、mypy，並用規則計數比較。NO_RULE_COUNT_INCREASE 表示所跑規則的計數沒有增加。正式採用前仍需從對應 manager 跑既有業務測試。三方工具需已在 PATH，核心掃描可單獨使用。自測執行兩個自造行為案例，TLS 使用本機替身，PowerShell 執行固定字串運算。

## 讓 MCP 用戶端讀取此次摘要

在支援本機 stdio 與 MCP resources 的用戶端新增服務。以下兩個絕對路徑請換成解壓目錄與本次 run 的 summary.json；command 指向所使用的 Python 執行檔。

```json
{
  "mcpServers": {
    "vcgc-safe-repair": {
      "command": "C:\\Python313\\python.exe",
      "args": ["-I", "-B", "C:\\VIA\\SafeRepair\\VCGC_SafeRepair.py", "serve", "--summary", "C:\\VIA\\SafeRepair\\run-example\\summary.json"]
    }
  }
}
```

透過 resources/list 及 resources/read 讀取 via://safe-repair/summary。回覆提供掃描計數、風險訊號數與驗收狀態。外部 AI 帳號、遠端 Windows 代理與手機連線須有各自的實際連線收據。跨裝置分享不在此版自動啟動範圍。

固定原始碼、工具鎖冊及 Apache 2.0 授權隨包提供。依賴指紋在 runtime.sha256.json。完整工具適用範圍與原生工具卡見 evidence/tools.log 與 evidence/verbs.log。
