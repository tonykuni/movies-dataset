# VIA-FlowSystem · 全球 ETF 資金流向與強度 — 自我驗證系統

把前面所有方法論固化成一個**會自我證明**的可運行系統:參數/資料走 JSON,引擎+測試+系統管理走 PY,一支 PowerShell 啟動並同步前後端 HTML。

## 一鍵啟動
```powershell
.\Activate-VIAFlowSystem.ps1                 # 預設 cmd=all:synth→calibrate→run→ui→開 HTML
.\Activate-VIAFlowSystem.ps1 -Cmd calibrate  # 只跑校準迴圈
.\Activate-VIAFlowSystem.ps1 -PythonExe C:\Users\tonyk\envs\via_plot_basic\Scripts\python.exe
.\Activate-VIAFlowSystem.ps1 -NoOpen         # 不自動開瀏覽器
```
PowerShell 會自動定位 venv(Auto-Locator 掃 `C:\Users\tonyk\envs\`),以 `ProcessStartInfo + ArgumentList.Add` 非同步雙流抽乾跑後端,讀 `calibration.json` 印出 VALID/NOT_VALID,再 `Start-Process` 開 `index.html`。

## 直接用 Python(等效)
```bash
python engines/flow_manager.py all          # 或 synth | calibrate | run | ui
```

## 結構
```
config/
  params.json      # FIS 參數、驗證 gate 門檻、校準 grid、synthetic 設定
  universe.json    # 30 檔 ETF:asset_class/risk_bucket/backing/monitor_role/fidelity
data/
  input/daily_data.json    # 運行/測試資料(JSON);無 live 餵入時由 synth 產生
  output/calibration.json  # 校準迴圈結果 + 驗證報告 + 最佳參數
  output/snapshot.json     # 最新快照:per-ticker FIS、bucket、RORO
  state/run_ledger.jsonl   # append-only 執行紀錄
engines/
  flow_core.py     # FIS 強度 + 雙估計器信任 + 聚合(VDF-FLOW-CORE-11)
  flow_validate.py # IC/decay/quantile/long-short/null + gate 評估(VALIDATE-12)
  flow_calibrate.py# optimize→test→debug→backtest→calibrate 迴圈(CALIBRATE-13)
  flow_ui.py       # 由 JSON 產 Visual Lock index.html(UI-14)
  flow_manager.py  # 系統管理/編排 + synth + CLI(MANAGER-15)
Activate-VIAFlowSystem.ps1  # 單一啟動器(LAUNCHER-16)
index.html        # 前端(生成):驗證徽章 + RORO 單針 + 類別/bucket FIS + per-ETF 表
```

## 校準迴圈如何「證明有效」
1. 依 `train_frac` 切 train/OOS
2. 掃 grid(window × kappa × min_tier),每組:`compute_fis` → `evaluate`(train gates)
3. **DEBUG**:任何組失敗只記錄原因不中斷;記每組卡在哪些 gate
4. 取 train 通過且 objective(ICIR)最高者為 best
5. **OOS 確認**:best 在測試段必須同號且顯著(G009)
6. 全綠 → `PROVED_VALID`(寫入 `calibrated_params`,run 自動採用);否則 `NOT_VALID` 並列出最常失敗的 gate

## 反證保證(這是可信度的地基)
把 `params.json` 的 `synthetic.alpha` 設 0(無 flow→return 結構),系統**必須**回 `NOT_VALID`。實測:0/24 組通過,`G003_icir` 全數失敗。系統在沒訊號時報「沒訊號」,不是橡皮圖章。

## 接真實資料
把 `fetch_global_etf_tracker_v4` 的輸出寫成 `data/input/daily_data.json`(欄位:`snapshot_date, ticker, close, shares_out, aum_reported`),其餘不變。`aum_reported` 提供時自動啟用雙估計器交叉驗證(防 shares 陳舊/申贖假象)。Pillar A(對 ETF.com/COT 真值校準)仍需先接官方流量源。

## Gate 對照
G002 null · G003 IC/ICIR/t · G004 quantile 單調 · G008 LS Sharpe(扣成本)· G009 OOS 確認。
(完整 G001~G021 見 FMEA / Validation Charter。)

---

## v0103 — SOLID 三層驗證(本輪新增)

系統現在要**三層獨立驗證全綠**才算 `SOLID`,任何一層紅 → `NOT_SOLID`:

| 層 | 問題 | 引擎 | Gate |
|---|---|---|---|
| **Pillar A 測量** | 估的流量是真的嗎? | `flow_pillar_a.py` (PILLARA-19) | VAL-G001(對真值的 rank-corr/符號/回歸/lead-lag) |
| **Pillar B 效力** | 能預測未來嗎? | `flow_validate`+`flow_calibrate` | G002~G009 |
| **self-test** | 引擎在邊界情況穩嗎? | `flow_selftest.py` (SELFTEST-20) | 14 項邊界測試 |

新命令:
```bash
python engines/flow_manager.py selftest      # 14 項邊界測試
python engines/flow_manager.py validate-a     # Pillar A 測量校準(需 reference_flows.json)
python engines/flow_manager.py all            # 全鏈:synth→selftest→calibrate→factors→run→validate-a→status→ui
python engines/flow_manager.py live           # 同上但用 bridge 吃真實資料
```
`all`/`live` 末端輸出 `data/output/status.json` 與 UI 頂端的三層狀態橫幅。

### Pillar A 真值來源(上線需接)
`validate-a` 讀 `data/input/reference_flows.json`(schema:`{records:[{snapshot_date,ticker,ref_flow}]}`)。真實上線時由以下免費真值供應:
- **ICI** 週度美國基金流(aggregate)· **issuer/NAV** 每日 AUM(per-ETF)· **CFTC COT** 期貨/FX 持倉(futures-backed 的真值)· **AkShare** 中國申贖
沒有 reference 時 `validate-a` 回 `UNCALIBRATED`,系統狀態自動降為 `NOT_SOLID` 並標「signal indicative only」——不會假裝校準過。

### self-test 涵蓋
正常/單檔/短歷史 FIS、sub-floor AUM 降級、stale-shares CONFLICT、role-gated 聚合、RORO、snapshot、validate、null≈0、factor 剔除 noise、Pillar A good-pass/bad-catch、空輸入安全。

---

## v0104 — 多分頁儀表板(本輪新增)

UI 改為三分頁(`flow_grid.py` / `VDF-FLOW-GRID-22` 從 live snapshot 算出網格資料):
1. **Flow & Validation** — 系統狀態、驗證 verdict、RORO 單針、類別/bucket FIS、因子庫、per-ETF(含 composite)。
2. **Region × Sector** — 全球股票輪動熱圖(7 區 × 11 GICS sector)。US 列為 direct(XL* 直接讀),其餘列為 proxy = 區域錨點 baseline × US-sector tilt;TW 紅=流入綠=流出;proxy cell 標記。
3. **Fidelity** — ETF 流量監控可信度評分卡(10 類):每類中位 fidelity、主要 backing/role、live FIS、建議用法、免費三角驗證來源。weak/blind 類(FX/Vol/futures 商品)明確標示需非 ETF 真值佐證。

新命令 `grid`,已串進 `all`/`live`。`grid.json` 為輸出。
