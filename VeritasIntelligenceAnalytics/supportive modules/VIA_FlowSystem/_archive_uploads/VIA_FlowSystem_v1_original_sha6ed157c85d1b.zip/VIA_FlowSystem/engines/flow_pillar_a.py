# -*- coding: utf-8 -*-
# VDF-FLOW-PILLARA-19 : measurement-accuracy calibration (Pillar A).
# Is our ΔShares/NAV flow ESTIMATE actually right? Compare against an
# INDEPENDENT ground-truth flow series (ICI weekly / issuer daily / CFTC COT
# for futures-backed). Gate VAL-G001. Without this, Pillar B is built on sand.
from __future__ import annotations
import numpy as np
import polars as pl
from flow_validate import _rank, _spear


def _slope_r2(x, y):
    m = np.isfinite(x) & np.isfinite(y)
    if m.sum() < 5:
        return None, None, None
    x, y = x[m], y[m]
    A = np.column_stack([np.ones_like(x), x])
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    yhat = A @ coef
    ss_res = float(((y - yhat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else None
    return round(float(coef[1]), 3), round(float(coef[0]), 1), (round(r2, 3) if r2 is not None else None)


def _lead_lag(est, ref, max_lag=2):
    best, blag = -2, 0
    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            a, b = est[:lag], ref[-lag:]
        elif lag > 0:
            a, b = est[lag:], ref[:-lag]
        else:
            a, b = est, ref
        if len(a) < 6:
            continue
        c = _spear(a, b)
        if np.isfinite(c) and c > best:
            best, blag = c, lag
    return blag, round(float(best), 3)


def measure_ticker(est: np.ndarray, ref: np.ndarray) -> dict:
    rc = _spear(est, ref)
    sign = float((np.sign(est) == np.sign(ref)).mean()) if len(est) else np.nan
    b, a, r2 = _slope_r2(est, ref)
    lag, lag_c = _lead_lag(est, ref)
    return dict(rank_corr=(round(float(rc), 3) if np.isfinite(rc) else None),
                sign_agree=(round(sign, 3) if np.isfinite(sign) else None),
                slope=b, intercept=a, r2=r2, best_lag=lag, lag_corr=lag_c,
                n=int(min(len(est), len(ref))))


def calibrate_measurement(df: pl.DataFrame, reference: dict, gp: dict,
                          freq: str = "weekly") -> dict:
    """df: has snapshot_date, ticker, netflow_est. reference: {records:[{snapshot_date,ticker,ref_flow}]}."""
    est = df.select(["snapshot_date", "ticker", "netflow_est"]).drop_nulls()
    ref = pl.DataFrame(reference["records"]).with_columns(
        pl.col("snapshot_date").str.to_date())
    j = est.join(ref, on=["snapshot_date", "ticker"], how="inner")
    if freq == "weekly":
        j = (j.with_columns(pl.col("snapshot_date").dt.truncate("1w").alias("wk"))
               .group_by(["ticker", "wk"])
               .agg([pl.col("netflow_est").sum().alias("e"),
                     pl.col("ref_flow").sum().alias("r")])
               .rename({"wk": "snapshot_date"}))
    else:
        j = j.rename({"netflow_est": "e", "ref_flow": "r"})

    rows = []
    for tk, g in j.sort(["ticker", "snapshot_date"]).group_by("ticker", maintain_order=True):
        if g.height < 8:
            continue
        m = measure_ticker(g["e"].to_numpy(), g["r"].to_numpy())
        m["ticker"] = tk[0] if isinstance(tk, tuple) else tk
        rows.append(m)

    rc_thr = gp["g001_rank_weekly"] if freq == "weekly" else gp["g001_rank_daily"]

    def passes(m):
        return (m["rank_corr"] is not None and m["rank_corr"] >= rc_thr and
                m["sign_agree"] is not None and m["sign_agree"] >= gp["g001_sign"] and
                m["slope"] is not None and gp["g001_slope_lo"] <= m["slope"] <= gp["g001_slope_hi"] and
                m["r2"] is not None and m["r2"] >= gp["g001_r2"] and
                abs(m["best_lag"]) <= gp["g001_max_lag"])

    for m in rows:
        m["pass"] = bool(passes(m))
    rcs = [m["rank_corr"] for m in rows if m["rank_corr"] is not None]
    pass_frac = (sum(m["pass"] for m in rows) / len(rows)) if rows else 0.0
    med_rc = float(np.median(rcs)) if rcs else None
    g001 = bool(med_rc is not None and med_rc >= rc_thr and pass_frac >= gp["g001_pass_frac"])
    return {"freq": freq, "n_tickers": len(rows),
            "median_rank_corr": (round(med_rc, 3) if med_rc is not None else None),
            "pass_fraction": round(pass_frac, 3),
            "G001_measurement": g001,
            "thresholds": {"rank": rc_thr, "sign": gp["g001_sign"],
                           "slope": [gp["g001_slope_lo"], gp["g001_slope_hi"]],
                           "r2": gp["g001_r2"], "pass_frac": gp["g001_pass_frac"]},
            "per_ticker": sorted(rows, key=lambda m: (m["rank_corr"] is None, -(m["rank_corr"] or 0)))}
