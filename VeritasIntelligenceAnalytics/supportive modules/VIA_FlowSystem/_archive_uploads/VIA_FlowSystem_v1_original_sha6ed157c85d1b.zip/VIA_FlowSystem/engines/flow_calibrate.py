# -*- coding: utf-8 -*-
# VDF-FLOW-CALIBRATE-13 : the optimize->test->debug->calibrate loop.
# Sweeps the param grid, scores each candidate on TRAIN gates, confirms the
# winner OOS, and emits a VALID / NOT_VALID verdict with per-candidate debug.
from __future__ import annotations
import itertools, copy
import polars as pl
from flow_core import compute_fis
from flow_validate import evaluate


def _split(df: pl.DataFrame, train_frac: float):
    dates = df.select("snapshot_date").unique().sort("snapshot_date")["snapshot_date"].to_list()
    cut = dates[int(len(dates)*train_frac)]
    return df.filter(pl.col("snapshot_date") <= cut), df.filter(pl.col("snapshot_date") > cut)


def calibrate(frame: pl.DataFrame, params: dict) -> dict:
    cp = params["calibration"]; grid = cp["grid"]; obj = cp["objective"]
    train, test = _split(frame, cp["train_frac"])
    combos = list(itertools.product(grid["window"], grid["kappa"], grid["min_tier"]))[:cp["max_iters"]]

    trials = []
    for W, K, MT in combos:
        p = copy.deepcopy(params)
        p["intensity"]["window"] = W
        p["intensity"]["kappa"] = K
        p["intensity"]["min_obs"] = max(10, W//3)
        p["aggregation"]["min_tier"] = MT
        try:
            tr = compute_fis(train, p["intensity"])
            rep = evaluate(tr, p)               # TRAIN gates only
            score = rep["ic"].get(obj)
            trials.append({"window": W, "kappa": K, "min_tier": MT,
                           "score": score, "train_pass": rep["train_pass"],
                           "gates": rep["gates"], "ic": rep["ic"]["ic"],
                           "null_ic": rep["null_ic"], "debug": _why(rep["gates"])})
        except Exception as e:                  # DEBUG: never crash the loop
            trials.append({"window": W, "kappa": K, "min_tier": MT,
                           "score": None, "train_pass": False,
                           "debug": f"ERROR:{type(e).__name__}:{e}"})

    passing = [t for t in trials if t["train_pass"] and t["score"] is not None]
    verdict = {"status": "NOT_VALID", "reason": None, "best": None,
               "n_trials": len(trials), "n_train_pass": len(passing)}
    if not passing:
        fails = {}
        for t in trials:
            for g, ok in t.get("gates", {}).items():
                if not ok:
                    fails[g] = fails.get(g, 0)+1
        verdict["reason"] = f"no config passed TRAIN gates; most-failed: {fails}"
        verdict["trials"] = trials
        return verdict

    best = max(passing, key=lambda t: t["score"])
    # CONFIRM winner OOS
    p = copy.deepcopy(params)
    p["intensity"].update(window=best["window"], kappa=best["kappa"],
                          min_obs=max(10, best["window"]//3))
    p["aggregation"]["min_tier"] = best["min_tier"]
    tr = compute_fis(train, p["intensity"]); te = compute_fis(test, p["intensity"])
    full = evaluate(tr, p, oos_df=te)
    verdict["best"] = {"window": best["window"], "kappa": best["kappa"],
                       "min_tier": best["min_tier"], "train_score": best["score"]}
    verdict["validation"] = full
    if full["overall_valid"]:
        verdict["status"] = "PROVED_VALID"
        verdict["reason"] = "best config passes all TRAIN gates and OOS confirmation"
    else:
        verdict["status"] = "NOT_VALID"
        verdict["reason"] = f"best TRAIN config failed OOS: {_why(full['gates'])}"
    verdict["trials"] = trials
    verdict["calibrated_params"] = {"intensity": p["intensity"],
                                    "aggregation": p["aggregation"]}
    return verdict


def _why(gates: dict) -> str:
    failed = [g for g, ok in gates.items() if not ok]
    return "PASS" if not failed else "FAIL:" + ",".join(failed)
