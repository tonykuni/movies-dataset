# -*- coding: utf-8 -*-
# VDF-FLOW-FACTORS-17 : replenish the signal set beyond FIS alone.
# Builds a factor library, then SELF-SELECTS factors by orthogonalized
# incremental IC over the base (FIS): a factor is kept only if, after
# removing its overlap with FIS, it STILL predicts forward returns. Keeps
# the system from stacking redundant proxies. Survivors -> composite signal.
from __future__ import annotations
import numpy as np
import polars as pl
from flow_validate import _rank, _spear, add_fwd_returns, daily_ic, evaluate
from flow_core import _tier_ok, _clean


# ---------------- factor library ----------------
def add_factors(df: pl.DataFrame, fp: dict) -> pl.DataFrame:
    df = df.sort(["ticker", "snapshot_date"])
    al, ms, ml, rw = fp["accel_lag"], fp["mom_short"], fp["mom_long"], fp["rvol_win"]
    df = df.with_columns([
        (pl.col("close") / pl.col("close").shift(1).over("ticker") - 1).alias("ret_1"),
    ]).with_columns([
        # flow acceleration (is the CHANGE in flow, not the level, predictive?)
        (pl.col("fis") - pl.col("fis").shift(al).over("ticker")).alias("flow_accel"),
        # price momentum (the classic factor FIS must beat / complement)
        (pl.col("close") / pl.col("close").shift(ms).over("ticker") - 1).alias("mom_20"),
        (pl.col("close") / pl.col("close").shift(ml).over("ticker") - 1).alias("mom_63"),
        # realized vol (risk / regime factor)
        pl.col("ret_1").rolling_std(window_size=rw, min_samples=rw//2)
          .over("ticker").alias("rvol_20"),
        # control: pure noise -> MUST be rejected by the selector
        pl.lit(None).alias("noise"),
    ])
    # de-overlap: organic flow minus cross-sectional market mean (FM-F fix)
    df = df.with_columns(
        (pl.col("organic_flow") - pl.col("organic_flow").mean().over("snapshot_date"))
        .alias("excess_flow"))
    # smart-money accumulation/distribution: flow IN while price weak (or vice-versa)
    df = df.with_columns((pl.col("organic_flow") * (-pl.col("mom_20"))).alias("accum_div"))
    # fill noise with reproducible random draws
    rng = np.random.default_rng(99)
    df = df.with_columns(pl.Series("noise", rng.standard_normal(df.height)))
    return df


# ---------------- daily partial (orthogonalized) IC ----------------
def _partial_ic(g_sig, g_base, g_ret):
    """IC of (sig residualized on base) vs ret, cross-section for one day."""
    m = np.isfinite(g_sig) & np.isfinite(g_base) & np.isfinite(g_ret)
    if m.sum() < 6:
        return np.nan
    x, b, y = g_sig[m], g_base[m], g_ret[m]
    # OLS residual of x on [1, b]
    A = np.column_stack([np.ones_like(b), b])
    try:
        coef, *_ = np.linalg.lstsq(A, x, rcond=None)
        resid = x - A @ coef
    except Exception:
        return np.nan
    return _spear(resid, y)


def incremental_ic(df, factor, base, ret, min_tier="B"):
    d = df.filter(_tier_ok(min_tier)).select(
        ["snapshot_date", factor, base, ret]).drop_nulls()
    raw, inc = [], []
    for _, gg in d.group_by("snapshot_date", maintain_order=True):
        s = gg[factor].to_numpy(); b = gg[base].to_numpy(); y = gg[ret].to_numpy()
        ic = _spear(s, y)
        if np.isfinite(ic):
            raw.append(ic)
        pic = _partial_ic(s, b, y)
        if np.isfinite(pic):
            inc.append(pic)
    def stats(a):
        a = np.array(a)
        if len(a) < 5:
            return None, None
        m, sd = a.mean(), a.std(ddof=1)
        return round(float(m), 4), (round(float(m/(sd/np.sqrt(len(a)))), 2) if sd > 0 else None)
    ic_m, ic_t = stats(raw)
    inc_m, inc_t = stats(inc)
    return dict(ic=ic_m, ic_t=ic_t, inc_ic=inc_m, inc_t=inc_t, n=len(inc))


# ---------------- self-selection + composite ----------------
def factor_study(df, params) -> dict:
    fp = params["factors"]; vp = params["validation"]
    base = fp["base"]; h = vp["primary_horizon"]; mt = params["aggregation"]["min_tier"]
    keep_t = fp["keep_incremental_t"]
    df = add_factors(df, fp)
    df = add_fwd_returns(df, [h])
    ret = f"fwd_ret_{h}"

    rows, kept = [], []
    for f in fp["library"]:
        r = incremental_ic(df, f, base, ret, mt)
        keep = (r["inc_t"] is not None and abs(r["inc_t"]) >= keep_t and
                r["inc_ic"] is not None)
        r.update(factor=f, kept=bool(keep))
        rows.append(r)
        if keep:
            kept.append((f, np.sign(r["inc_ic"])))

    # composite = sign-aligned cross-sectional z-sum of base + kept factors
    comp_terms = [(base, 1.0)] + [(f, float(s)) for f, s in kept]
    df = _add_composite(df, comp_terms)
    comp_eval = evaluate(df, params) if "composite" in df.columns else None

    base_ic = daily_ic(df, base, ret, mt)
    comp_ic = daily_ic(df, "composite", ret, mt) if "composite" in df.columns else None
    return {
        "base": base, "horizon": h,
        "factors": rows,
        "kept": [f for f, _ in kept],
        "kept_signed": [[f, float(s)] for f, s in kept],
        "base_ic": base_ic,
        "composite_ic": comp_ic,
        "composite_gates": comp_eval["gates"] if comp_eval else None,
        "composite_valid": comp_eval["overall_valid"] if comp_eval else None,
        "verdict": _factor_verdict(base_ic, comp_ic),
    }


def composite_signal(df, fp, kept_signed):
    """Rebuild the validated composite on a panel for live output."""
    df = add_factors(df, fp)
    terms = [(fp["base"], 1.0)] + [(f, float(s)) for f, s in kept_signed]
    return _add_composite(df, terms)


def _add_composite(df, terms):
    # cross-sectional z per day for each term, then sign-weighted sum
    zexprs = []
    for col, sgn in terms:
        mu = pl.col(col).mean().over("snapshot_date")
        sd = pl.col(col).std().over("snapshot_date")
        zexprs.append((sgn * (pl.col(col) - mu) / (sd + 1e-12)).alias(f"_z_{col}"))
    df = df.with_columns(zexprs)
    zcols = [f"_z_{c}" for c, _ in terms]
    return df.with_columns(pl.sum_horizontal(zcols).alias("composite"))


def _factor_verdict(base_ic, comp_ic):
    if not base_ic or not comp_ic or base_ic["icir"] is None or comp_ic["icir"] is None:
        return "INCONCLUSIVE"
    return ("COMPOSITE_BEATS_BASE" if comp_ic["icir"] > base_ic["icir"]
            else "BASE_SUFFICIENT")
