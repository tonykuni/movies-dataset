# -*- coding: utf-8 -*-
# VDF-FLOW-GRID-22 : region x sector rotation matrix + fidelity board,
# computed from the live snapshot so the dashboard tabs are data-driven.
from __future__ import annotations
import statistics as st

# US Select-Sector ETF -> GICS sector (the only sector ETFs in this universe)
US_SECTOR = {"XLK": "Tech", "XLC": "Comm", "XLY": "Discretionary", "XLF": "Financials",
             "XLI": "Industrials", "XLB": "Materials", "XLE": "Energy",
             "XLRE": "RealEstate", "XLV": "Health", "XLP": "Staples", "XLU": "Utilities"}
SECTORS = ["Tech", "Comm", "Discretionary", "Financials", "Industrials", "Materials",
           "Energy", "RealEstate", "Health", "Staples", "Utilities"]
# region anchor ETF (broad equity) -> region baseline FIS
REGION_ANCHOR = {"US": "SPY", "Global": "ACWI", "Europe": "VGK", "Japan": "EWJ",
                 "EM": "EEM", "China": "MCHI", "Taiwan": "EWT"}
REGION_ORDER = ["US", "Global", "Europe", "Japan", "EM", "China", "Taiwan"]
REGION_ZH = {"US": "美國", "Global": "全球", "Europe": "歐洲", "Japan": "日本",
             "EM": "新興市場", "China": "中國", "Taiwan": "台灣"}

# static per-asset-class fidelity guidance (data-driven score merged at runtime)
GUIDANCE = {
    "Equity":    ("flow_signal (FX-adj non-US)", "ICI / MSCI"),
    "Sector":    ("flow_signal (excess)", "sector breadth"),
    "Bond":      ("flow_signal", "CFTC COT (UST futs)"),
    "Cash":      ("cash-parking gauge", "MMF AUM"),
    "REIT":      ("flow_signal", "—"),
    "Commodity": ("spot:flow / futures:positioning", "CFTC COT / LBMA"),
    "Crypto":    ("flow_signal (net of GBTC)", "on-chain / GBTC net"),
    "FX":        ("fx_basis / sentiment only", "CFTC COT FX / DXY / BIS"),
    "HedgedEq":  ("FX-hedging demand", "vs unhedged"),
    "Vol":       ("descriptive only", "VIX spot / term struct"),
}


def region_sector_matrix(snapshot: dict) -> dict:
    fis = {t["ticker"]: t["fis"] for t in snapshot.get("per_ticker", [])}
    # US sector cells (direct) + the US sector tilt used to proxy other regions
    us_cells = {sec: fis.get(tk) for tk, sec in US_SECTOR.items()}
    vals = [v for v in us_cells.values() if v is not None]
    tilt_mean = (sum(vals) / len(vals)) if vals else 0.0
    tilt = {sec: (us_cells[sec] - tilt_mean) if us_cells.get(sec) is not None else None
            for sec in SECTORS}

    rows = []
    for region in REGION_ORDER:
        base = fis.get(REGION_ANCHOR.get(region))
        cells = []
        for sec in SECTORS:
            if region == "US" and us_cells.get(sec) is not None:
                cells.append({"sector": sec, "fis": round(us_cells[sec], 1), "cover": "direct"})
            elif base is not None and tilt.get(sec) is not None:
                v = max(-100.0, min(100.0, base + tilt[sec]))
                cells.append({"sector": sec, "fis": round(v, 1), "cover": "proxy"})
            else:
                cells.append({"sector": sec, "fis": None, "cover": "gap"})
        rows.append({"region": region, "zh": REGION_ZH[region],
                     "cover": "direct" if region == "US" else "proxy", "cells": cells})
    return {"sectors": SECTORS, "rows": rows}


def fidelity_board(universe: dict, snapshot: dict) -> list[dict]:
    by_class = {}
    for t in universe["tickers"]:
        by_class.setdefault(t["asset_class"], []).append(t)
    live = {b["k"]: b["fis"] for b in snapshot.get("by_asset_class", [])}
    board = []
    for cls, ts in by_class.items():
        fids = [t["fidelity"] for t in ts]
        backings = [t["backing"] for t in ts]
        roles = [t["monitor_role"] for t in ts]
        use, tri = GUIDANCE.get(cls, ("—", "—"))
        board.append({
            "asset_class": cls,
            "fidelity": round(st.median(fids), 1),
            "backing": st.mode(backings),
            "role": st.mode(roles),
            "n": len(ts),
            "use": use, "triangulate": tri,
            "live_fis": live.get(cls),
        })
    return sorted(board, key=lambda r: -r["fidelity"])


def build_grid(universe: dict, snapshot: dict) -> dict:
    return {"region_sector": region_sector_matrix(snapshot),
            "fidelity": fidelity_board(universe, snapshot)}
