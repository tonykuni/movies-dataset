# -*- coding: utf-8 -*-
# VDF-FLOW-UI-14 : build front-end index.html from output JSON (Visual Lock).
from __future__ import annotations
import json
from pathlib import Path


def build_html(snapshot: dict, verdict: dict, out_path: str | Path,
               study: dict | None = None, status: dict | None = None,
               grid: dict | None = None) -> None:
    from flow_core import _sanitize
    payload = json.dumps(_sanitize({"snapshot": snapshot, "verdict": _slim(verdict),
                          "factors": _slim_factors(study), "status": status,
                          "grid": grid}),
                         ensure_ascii=False, allow_nan=False)
    html = _TEMPLATE.replace("/*__DATA__*/", payload)
    Path(out_path).write_text(html, encoding="utf-8")  # No-BOM


def _slim_factors(s):
    if not s:
        return None
    return {"kept": s.get("kept"), "verdict": s.get("verdict"),
            "base_ic": s.get("base_ic"), "composite_ic": s.get("composite_ic"),
            "composite_valid": s.get("composite_valid"),
            "factors": s.get("factors")}


def _slim(v: dict) -> dict:
    out = {k: v.get(k) for k in ("status", "reason", "best", "n_trials", "n_train_pass")}
    val = v.get("validation", {})
    out["gates"] = val.get("gates", {})
    out["ic"] = val.get("ic", {})
    out["ic_decay"] = val.get("ic_decay", [])
    out["quantile"] = val.get("quantile", {})
    out["long_short"] = val.get("long_short", {})
    out["null_ic"] = val.get("null_ic")
    out["oos"] = val.get("oos", {})
    return out


_TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-Hant"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VIA · Global Flow System</title>
<style>
:root{--bg:#f5f4f0;--sf:#fff;--bd:#dbd9d3;--ink:#1e1d1a;--ink2:#6b6860;
--gr:#9c9890;--up:#c96b5a;--dn:#5a9e6f;--bl:#4c78a8;--tl:#439a9a;--amber:#c4943a;}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--ink);font-family:"Noto Sans CJK TC","Noto Sans TC",
"DM Sans",-apple-system,system-ui,sans-serif;padding:28px;max-width:1180px;margin:0 auto}
h1{font-size:20px;font-weight:800;letter-spacing:.3px}
.sub{color:var(--gr);font-size:12px;margin-top:4px}
.card{background:var(--sf);border:1px solid var(--bd);border-radius:10px;padding:18px 20px;margin-top:18px}
.row{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
.badge{display:inline-block;padding:6px 14px;border-radius:20px;font-weight:800;font-size:13px;color:#fff}
.valid{background:var(--dn)} .invalid{background:var(--up)}
.k{font-size:11px;color:var(--ink2);text-transform:uppercase;letter-spacing:.5px}
.big{font-size:30px;font-weight:800;font-family:"DM Mono",monospace}
.bar-wrap{position:relative;height:26px;margin:7px 0}
.bar-mid{position:absolute;left:50%;top:0;bottom:0;width:1px;background:var(--gr)}
.bar{position:absolute;top:3px;height:20px;border-radius:3px;opacity:.85}
.lab{position:absolute;top:4px;font-size:11px;font-weight:700;font-family:"DM Mono",monospace}
.rowlab{font-size:12px;color:var(--ink);width:96px;display:inline-block}
table{width:100%;border-collapse:collapse;font-size:12px;font-family:"DM Mono",monospace}
th,td{text-align:right;padding:5px 8px;border-bottom:1px solid var(--bd)}
th{color:var(--ink2);font-weight:600;font-size:10px;text-transform:uppercase}
td.l,th.l{text-align:left}
.gate{display:inline-block;padding:3px 9px;border-radius:5px;font-size:11px;font-weight:700;margin:3px 4px 0 0;font-family:"DM Mono",monospace}
.gp{background:#e7f0ea;color:var(--dn)} .gf{background:#f6e7e3;color:var(--up)}
.needle{position:relative;height:48px;margin-top:8px}
.needle .track{position:absolute;left:0;right:0;top:18px;height:14px;border-radius:7px;
background:linear-gradient(90deg,#cfe2d5,#eee,#eccfc8)}
.needle .pin{position:absolute;top:8px;font-size:18px;transform:translateX(-50%)}
.muted{color:var(--gr);font-size:11px}
.chip{font-size:10px;padding:1px 6px;border-radius:4px;background:#efeee9;color:var(--ink2)}
.tabs{display:flex;gap:6px;margin:16px 0 4px}
.tab{padding:8px 16px;border-radius:8px 8px 0 0;font-weight:700;font-size:13px;cursor:pointer;
color:var(--ink2);background:transparent;border:1px solid transparent}
.tab.on{background:var(--sf);border:1px solid var(--bd);border-bottom-color:var(--sf);color:var(--ink)}
.tabpane{display:none} .tabpane.on{display:block}
.gcell{position:relative;border:2px solid var(--bg);border-radius:3px;height:46px;
display:flex;align-items:center;justify-content:center;font-weight:700;font-size:12px;font-family:"DM Mono",monospace}
.gcell .px{position:absolute;bottom:2px;right:4px;font-size:7px;font-style:italic;opacity:.7;font-weight:400}
.gridwrap{display:grid;gap:0;margin-top:8px;overflow-x:auto}
.ghead{font-size:9px;color:var(--ink2);text-align:center;padding:4px 0;font-weight:700}
.grlab{font-size:11px;color:var(--ink);display:flex;align-items:center;padding-right:8px;justify-content:flex-end;font-weight:700}
</style></head><body>
<h1>VIA · Global ETF Flow — Direction &amp; Intensity</h1>
<div class="sub" id="sub"></div>

<div class="card" id="statuscard">
  <div class="k">System Status — three independent layers must all pass</div>
  <div style="margin-top:10px;display:flex;gap:14px;align-items:center;flex-wrap:wrap">
    <span id="sysbadge" class="badge" style="font-size:15px"></span>
    <span id="layA" class="gate"></span>
    <span id="layB" class="gate"></span>
    <span id="layS" class="gate"></span>
    <span class="muted" id="statusnote"></span>
  </div>
</div>

<div class="tabs">
  <div class="tab on" data-tab="flow">Flow &amp; Validation</div>
  <div class="tab" data-tab="grid">Region × Sector</div>
  <div class="tab" data-tab="fid">Fidelity</div>
</div>

<div id="tab-flow" class="tabpane on">
<div class="card">
  <div class="k">System Validation Verdict</div>
  <div style="margin-top:8px"><span id="badge" class="badge"></span>
    <span class="muted" id="reason"></span></div>
  <div id="gates" style="margin-top:10px"></div>
  <div class="muted" id="metrics" style="margin-top:10px"></div>
</div>

<div class="card">
  <div class="k">RORO Needle — where the money is going</div>
  <div class="needle"><div class="track"></div><div class="pin" id="pin">▼</div></div>
  <div style="display:flex;justify-content:space-between" class="muted">
    <span style="color:var(--dn)">◀ FLIGHT TO SAFETY −100</span>
    <span class="big" id="roro" style="font-size:22px"></span>
    <span style="color:var(--up)">+100 RISK-ON ▶</span></div>
</div>

<div class="row">
  <div class="card"><div class="k">Flow Intensity by Asset Class</div><div id="byclass"></div></div>
  <div class="card"><div class="k">Flow Intensity by Risk Bucket</div><div id="bybucket"></div></div>
</div>

<div class="card" id="factorcard">
  <div class="k">Factor Library — orthogonalized self-selection (incremental IC over FIS)</div>
  <div class="muted" id="factor-verdict" style="margin:6px 0"></div>
  <table id="ftbl"><thead><tr>
    <th class="l">Factor</th><th>IC</th><th>incremental IC vs FIS</th><th>inc t</th><th class="l">Decision</th>
  </tr></thead><tbody></tbody></table>
</div>

<div class="card">
  <div class="k">Per-ETF (latest snapshot)</div>
  <table id="tbl"><thead><tr>
    <th class="l">Ticker</th><th class="l">Class</th><th class="l">Bucket</th>
    <th>FIS</th><th>NetFlow $M</th><th>COMPOSITE</th><th>pct</th><th class="l">Tier</th><th class="l">Trust</th><th>Fid</th>
  </tr></thead><tbody></tbody></table>
</div>

<div class="sub" style="margin-top:18px">Generated by VIA-FlowSystem · params &amp; data JSON-driven · synthetic unless live-fed</div>
</div>

<div id="tab-grid" class="tabpane">
  <div class="card">
    <div class="k">Global Equity Rotation — Flow Intensity by Region × Sector</div>
    <div class="muted" style="margin:6px 0">cell = FIS (−100 outflow … +100 inflow, TW red=in) · US row = direct sector ETFs · others = proxy (region baseline × US-sector tilt)</div>
    <div id="rsgrid" class="gridwrap"></div>
  </div>
</div>

<div id="tab-fid" class="tabpane">
  <div class="card">
    <div class="k">ETF-Flow Monitoring Fidelity — where the flow lens is trustworthy</div>
    <div class="muted" style="margin:6px 0">fidelity 3 strong · 2 moderate · 1 weak/biased · 0 blind · weak/blind classes need non-ETF triangulation</div>
    <table id="fidtbl"><thead><tr>
      <th class="l">Asset Class</th><th>Fidelity</th><th class="l">Backing</th><th class="l">Role</th>
      <th>Live FIS</th><th class="l">Recommended Use</th><th class="l">Triangulate (free)</th><th>n</th>
    </tr></thead><tbody></tbody></table>
  </div>
</div>

<script>
const D = /*__DATA__*/;
const S = D.snapshot, V = D.verdict, ST = D.status;
const fmt = (x,d=1)=> (x==null?"—":(x>=0?"+":"")+Number(x).toFixed(d));
const col = x => x==null?"var(--gr)":(x>=0?"var(--up)":"var(--dn)"); // TW red=in

// system status banner
if(ST){
  const solid = ST.system_status==="SOLID";
  const sb=document.getElementById("sysbadge");
  sb.textContent=ST.system_status; sb.className="badge "+(solid?"valid":"invalid");
  const lay=(el,name,v)=>{const e=document.getElementById(el);
    const good=v==="PASS"; e.className="gate "+(good?"gp":"gf");
    e.textContent=name+": "+v+(good?" ✓":(v==="UNCALIBRATED"?" ◐":" ✗"));};
  lay("layA","Pillar A measurement",ST.pillar_a_measurement);
  lay("layB","Pillar B efficacy",ST.pillar_b_efficacy);
  lay("layS","robustness",ST.robustness);
  document.getElementById("statusnote").textContent="  "+(ST.robustness_detail?ST.robustness_detail+" · ":"")+(ST.note||"");
} else { document.getElementById("statuscard").style.display="none"; }

document.getElementById("sub").textContent =
  "snapshot "+(S.snapshot_date||"—")+"  ·  "+(S.per_ticker?.length||0)+" ETFs  ·  "
  +"calibrated "+(V.best?`W=${V.best.window} κ=${V.best.kappa} tier=${V.best.min_tier}`:"—");

// verdict
const valid = V.status==="PROVED_VALID";
const b=document.getElementById("badge");
b.textContent=V.status||"—"; b.className="badge "+(valid?"valid":"invalid");
document.getElementById("reason").textContent="  "+(V.reason||"");
const gates=V.gates||{};
document.getElementById("gates").innerHTML=Object.entries(gates).map(
  ([k,v])=>`<span class="gate ${v?'gp':'gf'}">${k} ${v?'✓':'✗'}</span>`).join("");
const ic=V.ic||{}, q=V.quantile||{}, ls=V.long_short||{}, oos=(V.oos||{}).ic||{};
document.getElementById("metrics").innerHTML=
  `IC=${fmt(ic.ic,4)} · ICIR=${fmt(ic.icir,2)} · t=${fmt(ic.t,1)} · `
  +`mono=${fmt(q.mono,2)} · LS Sharpe=${ls.sharpe??"—"} · null IC=${fmt(V.null_ic,4)} · `
  +`OOS IC=${fmt(oos.ic,4)} (t=${fmt(oos.t,1)})`;

// RORO needle
const rr=S.roro_score;
document.getElementById("roro").textContent=fmt(rr,0);
document.getElementById("roro").style.color=col(rr);
document.getElementById("pin").style.left=((Number(rr||0)+100)/200*100)+"%";
document.getElementById("pin").style.color=col(rr);

// bar lists
function bars(el, rows){
  const max=Math.max(60,...rows.map(r=>Math.abs(r.fis||0)));
  el.innerHTML=rows.map(r=>{
    const v=r.fis||0, w=Math.abs(v)/100*48, left=v>=0?50:50-(Math.abs(v)/100*48);
    return `<div style="display:flex;align-items:center;gap:8px">
      <span class="rowlab">${r.k}</span>
      <div class="bar-wrap" style="flex:1"><div class="bar-mid"></div>
        <div class="bar" style="left:${left}%;width:${w}%;background:${col(v)}"></div>
        <div class="lab" style="${v>=0?'left:'+(50+w)+'%':'right:'+(50+w)+'%'};color:${col(v)}">${fmt(v)}</div>
      </div>
      <span class="chip">$${((r.netflow_usd||0)/1e9).toFixed(2)}B · n${r.n}</span></div>`;
  }).join("");
}
bars(document.getElementById("byclass"), S.by_asset_class||[]);
bars(document.getElementById("bybucket"), S.by_risk_bucket||[]);

// factor library
const F = D.factors;
if(F){
  const bi=(F.base_ic||{}).icir, ci=(F.composite_ic||{}).icir;
  document.getElementById("factor-verdict").innerHTML=
    `verdict: <b>${F.verdict}</b> · base(FIS) ICIR=${fmt(bi,2)} · composite ICIR=${fmt(ci,2)}`
    +` · kept: ${(F.kept||[]).join(", ")||"—"} · composite ${F.composite_valid?'<span style="color:var(--dn)">passes gates ✓</span>':'<span style="color:var(--up)">fails gates</span>'}`;
  const ftb=document.querySelector("#ftbl tbody");
  ftb.innerHTML=(F.factors||[]).map(r=>{
    const dec=r.kept?'<span style="color:var(--dn);font-weight:700">KEEP</span>'
      :'<span style="color:var(--gr)">drop</span>';
    return `<tr><td class="l"><b>${r.factor}</b></td><td>${fmt(r.ic,4)}</td>
      <td style="color:${r.kept?'var(--dn)':'var(--ink2)'}">${fmt(r.inc_ic,4)}</td>
      <td>${fmt(r.inc_t,1)}</td><td class="l">${dec}</td></tr>`;
  }).join("");
} else { document.getElementById("factorcard").style.display="none"; }

// table — sort by composite (validated predictive signal) when present
const rows=(S.per_ticker||[]).slice();
const hasComp=rows.some(r=>r.composite!=null);
if(hasComp) rows.sort((a,b)=>(b.composite??-1e9)-(a.composite??-1e9));
const tb=document.querySelector("#tbl tbody");tb.innerHTML=rows.map(r=>{
  const trust=r.est_trust==="OK"?'<span style="color:var(--dn)">OK</span>'
    :'<span style="color:var(--up)">'+r.est_trust+'</span>';
  const comp=r.composite==null?'—':`<b style="color:${col(r.composite)}">${fmt(r.composite,2)}</b>`;
  const pct=r.composite_pct==null?'—':Math.round(r.composite_pct);
  return `<tr><td class="l"><b>${r.ticker}</b></td><td class="l">${r.asset_class}</td>
    <td class="l">${r.risk_bucket}</td>
    <td style="color:${col(r.fis)};font-weight:700">${fmt(r.fis)}</td>
    <td>${r.netflow_usd==null?'—':(r.netflow_usd/1e6).toFixed(1)}</td>
    <td>${comp}</td><td class="muted">${pct}</td>
    <td class="l">${r.confidence}</td><td class="l">${trust}</td><td>${r.fidelity}</td></tr>`;
}).join("");
if(hasComp){
  const kept=(S.composite_kept||[]);
  const note=document.createElement("div"); note.className="muted"; note.style.marginTop="6px";
  note.innerHTML="COMPOSITE = validated multi-factor signal (FIS + "+kept.join(" + ")
    +"), cross-sectional z-sum · table sorted by it · pct = cross-sectional percentile";
  document.querySelector("#tbl").parentNode.appendChild(note);
}

// ---- tabs ----
document.querySelectorAll(".tab").forEach(t=>t.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.remove("on"));
  document.querySelectorAll(".tabpane").forEach(x=>x.classList.remove("on"));
  t.classList.add("on");
  document.getElementById("tab-"+t.dataset.tab).classList.add("on");
}));

// ---- Region × Sector grid ----
const G = D.grid;
function fisCellColor(v){
  if(v==null) return "#eceae6";
  const t=Math.max(-100,Math.min(100,v))/100, a=Math.pow(Math.abs(t),0.75);
  const base=[0.965,0.957,0.941];
  const tip=t>=0?[0.788,0.420,0.353]:[0.353,0.620,0.435];
  const c=base.map((b,i)=>Math.round((b+(tip[i]-b)*a)*255));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}
if(G&&G.region_sector){
  const rs=G.region_sector, secs=rs.sectors;
  const el=document.getElementById("rsgrid");
  el.style.gridTemplateColumns=`120px repeat(${secs.length}, minmax(60px,1fr))`;
  let html=`<div></div>`+secs.map(s=>`<div class="ghead">${s}</div>`).join("");
  rs.rows.forEach(r=>{
    html+=`<div class="grlab">${r.region} ${r.zh}${r.cover==='proxy'?' ·p':''}</div>`;
    r.cells.forEach(c=>{
      const v=c.fis, txt=v==null?'·':(v>=0?'+':'')+Math.round(v);
      const tc=(v!=null&&Math.abs(v)>55)?'#fff':'var(--ink)';
      html+=`<div class="gcell" style="background:${fisCellColor(v)};color:${tc}">${txt}`
        +(c.cover==='proxy'?'<span class="px">proxy</span>':'')+`</div>`;
    });
  });
  el.innerHTML=html;
}

// ---- Fidelity board ----
if(G&&G.fidelity){
  const fc={3:"var(--dn)",2:"var(--tl)",1:"var(--amber)",0:"var(--up)"};
  const fl={3:"STRONG",2:"MODERATE",1:"WEAK",0:"BLIND"};
  const ftb=document.querySelector("#fidtbl tbody");
  ftb.innerHTML=G.fidelity.map(r=>{
    const fk=Math.round(r.fidelity), c=fc[fk]||"var(--gr)";
    const bcol=r.backing==="spot_physical"?"var(--dn)":(r.backing==="futures"?"var(--up)":"var(--amber)");
    return `<tr><td class="l"><b>${r.asset_class}</b></td>
      <td><span style="background:${c};color:#fff;padding:2px 8px;border-radius:4px;font-size:10px;font-weight:700">${r.fidelity} ${fl[fk]||''}</span></td>
      <td class="l" style="color:${bcol};font-weight:700">${r.backing}</td>
      <td class="l muted">${r.role}</td>
      <td style="color:${col(r.live_fis)};font-weight:700">${r.live_fis==null?'—':fmt(r.live_fis)}</td>
      <td class="l">${r.use}</td><td class="l muted">${r.triangulate}</td><td>${r.n}</td></tr>`;
  }).join("");
}
</script></body></html>"""
