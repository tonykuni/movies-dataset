# -*- coding: utf-8 -*-
# VDF-FLOW-AUTOTEST-21 : adversarial + determinism + strict-JSON + perf battery.
# Drives the engines with degenerate/hostile inputs to harden to "perfect".
from __future__ import annotations
import json, time, math, copy, datetime as dt
from pathlib import Path
import numpy as np
import polars as pl

from flow_core import compute_fis, bucket_fis, roro, latest_snapshot, save_json, load_json, _sanitize
from flow_validate import add_fwd_returns, evaluate
from flow_factors import factor_study, composite_signal
from flow_pillar_a import calibrate_measurement
from flow_selftest import _mini, IP, AP, VP, FP, PARAMS

ROOT = Path(__file__).resolve().parent.parent
DOUT = ROOT / "data/output"


def _t(name, fn):
    try:
        ok, d = fn(); return (name, bool(ok), d)
    except Exception as e:
        return (name, False, f"EXC {type(e).__name__}: {e}")


def _finite_fis(df):
    f = df["fis"].drop_nulls().to_numpy()
    return np.all(np.isfinite(f)) and (np.abs(f).max() <= 100 if len(f) else True)


def run_all() -> dict:
    T = []

    # --- adversarial data ---
    def _inject(df, mods):
        cols = {}
        for name, arr in mods.items():
            cols[name] = pl.Series(name, arr)
        return df.with_columns(list(cols.values()))

    def nan_inject():
        df = _mini(seed=1)
        close = df["close"].to_numpy().copy(); sh = df["shares_out"].to_numpy().copy()
        idx = np.random.default_rng(0).choice(len(close), 30, replace=False)
        close[idx] = np.nan; sh[idx[:10]] = np.inf
        out = compute_fis(_inject(df, {"close": close, "shares_out": sh}), IP)
        return _finite_fis(out), "NaN/Inf in close/shares handled, FIS finite&bounded"
    T.append(_t("adv_nan_inf_inject", nan_inject))

    def neg_zero_price():
        df = _mini(seed=2)
        close = df["close"].to_numpy().copy()
        close[5:9] = 0.0; close[9:12] = -3.0
        out = compute_fis(_inject(df, {"close": close}), IP)
        return _finite_fis(out), "zero/negative price did not break FIS"
    T.append(_t("adv_zero_neg_price", neg_zero_price))

    def zero_variance():
        df = _mini(seed=3).with_columns(pl.lit(1.0e8).alias("shares_out"))
        out = compute_fis(df, IP)
        return _finite_fis(out), "zero-variance flow -> FIS finite (no div-by-zero blowup)"
    T.append(_t("adv_zero_variance", zero_variance))

    def extreme_outlier():
        df = _mini(seed=4)
        sh = df["shares_out"].to_numpy().copy(); sh[80] *= 1000.0
        out = compute_fis(_inject(df, {"shares_out": sh}), IP)
        return _finite_fis(out), "1000x share spike winsorized, FIS<=100"
    T.append(_t("adv_extreme_outlier", extreme_outlier))

    def dup_unordered():
        df = _mini(seed=5)
        df2 = pl.concat([df, df.head(50)]).sample(fraction=1.0, shuffle=True, seed=1)
        out = compute_fis(df2, IP)
        return out.height > 0 and _finite_fis(out), "duplicate + shuffled rows handled"
    T.append(_t("adv_dup_unordered", dup_unordered))

    # --- numerical invariants ---
    def fis_bounded():
        out = compute_fis(_mini(n_days=200, seed=6), IP)
        f = out["fis"].drop_nulls().to_numpy()
        org = out["organic_flow"].drop_nulls().to_numpy()
        return (np.abs(f).max() <= 100 and np.all(np.isfinite(org))), \
               f"max|FIS|={np.abs(f).max():.1f} organic all finite"
    T.append(_t("inv_fis_bounded", fis_bounded))

    # --- determinism ---
    def deterministic():
        a = compute_fis(_mini(seed=7, n_days=160), IP)
        b = compute_fis(_mini(seed=7, n_days=160), IP)
        fa = np.nan_to_num(a["fis"].to_numpy(), nan=-999)
        fb = np.nan_to_num(b["fis"].to_numpy(), nan=-999)
        return np.array_equal(fa, fb), "same seed -> identical FIS"
    T.append(_t("determinism", deterministic))

    def factor_determinism():
        df = compute_fis(_mini(seed=8, n_days=200), IP)
        s1 = factor_study(df, PARAMS)["kept"]
        s2 = factor_study(df, PARAMS)["kept"]
        return s1 == s2, f"factor selection stable: {s1}"
    T.append(_t("determinism_factors", factor_determinism))

    # --- strict JSON validity (the NaN-token bug) ---
    def strict_json_outputs():
        bad = []
        for f in sorted(DOUT.glob("*.json")):
            txt = f.read_text(encoding="utf-8")
            try:
                obj = json.loads(txt)
                json.dumps(obj, allow_nan=False)        # raises if NaN/Inf present
            except ValueError:
                bad.append(f.name)
        return len(bad) == 0, f"non-strict JSON files: {bad or 'none'}"
    T.append(_t("strict_json_outputs", strict_json_outputs))

    def sanitizer_roundtrip():
        obj = {"a": float("nan"), "b": [float("inf"), 1.0, np.float64("nan")],
               "c": {"d": np.int64(3), "e": np.bool_(True)}}
        s = json.dumps(_sanitize(obj), allow_nan=False)
        r = json.loads(s)
        return (r["a"] is None and r["b"][0] is None and r["c"]["d"] == 3), "nan/inf -> null"
    T.append(_t("json_sanitizer", sanitizer_roundtrip))

    # --- composite with zero kept factors ---
    def composite_empty():
        df = compute_fis(_mini(n_days=180, seed=9), IP)
        df = composite_signal(df, FP, [])               # no kept factors
        return "composite" in df.columns and df["composite"].drop_nulls().len() > 0, \
               "composite = pure FIS-z when no factors kept"
    T.append(_t("composite_zero_factors", composite_empty))

    # --- calibration boundary ---
    def calib_too_few_days():
        df = compute_fis(_mini(n_days=30, seed=10), IP)
        rep = evaluate(df, PARAMS)
        return rep["overall_valid"] is False, "too-few-days -> NOT valid, no crash"
    T.append(_t("calib_too_few_days", calib_too_few_days))

    # --- pillar A no overlap ---
    def pillarA_no_overlap():
        df = compute_fis(_mini(n_days=160, seed=11), IP)
        ref = {"records": [{"snapshot_date": "1999-01-01", "ticker": "ZZZ", "ref_flow": 1.0}]}
        gp = {"g001_rank_weekly": 0.6, "g001_rank_daily": 0.4, "g001_sign": 0.7,
              "g001_slope_lo": 0.7, "g001_slope_hi": 1.3, "g001_r2": 0.4,
              "g001_max_lag": 2, "g001_pass_frac": 0.6}
        rep = calibrate_measurement(df, ref, gp, "weekly")
        return rep["n_tickers"] == 0 and rep["G001_measurement"] is False, "no-overlap handled"
    T.append(_t("pillarA_no_overlap", pillarA_no_overlap))

    # --- performance ---
    def perf():
        df = _mini(n_tk=65, n_days=500, seed=12)
        t0 = time.time(); out = compute_fis(df, IP)
        _ = latest_snapshot(out, AP); dtm = time.time() - t0
        return dtm < 8.0, f"fis+snapshot on 65x500 in {dtm:.2f}s"
    T.append(_t("perf_fis_snapshot", perf))

    np_ = sum(1 for _, ok, _ in T if ok)
    return {"n_tests": len(T), "n_pass": np_, "all_green": np_ == len(T),
            "tests": [{"name": n, "ok": ok, "detail": d} for n, ok, d in T]}


if __name__ == "__main__":
    r = run_all()
    for t in r["tests"]:
        print(f"  [{'PASS' if t['ok'] else 'FAIL'}] {t['name']:<26} {t['detail']}")
    print(f"\n{r['n_pass']}/{r['n_tests']} green -> {'PERFECT' if r['all_green'] else 'NEEDS DEBUG'}")
