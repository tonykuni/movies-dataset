# -*- coding: utf-8 -*-
# VDF-FLOW-MANAGER-15 : system manager / orchestrator.
# CLI: synth | calibrate | run | ui | all     (params & data via JSON)
from __future__ import annotations
import argparse, json, sys, datetime as dt
from pathlib import Path
import numpy as np
import polars as pl

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "engines"))
from flow_core import (load_json, save_json, build_frame, compute_fis,  # noqa
                       latest_snapshot)
from flow_calibrate import calibrate                                    # noqa
from flow_factors import factor_study, composite_signal                 # noqa
from flow_pillar_a import calibrate_measurement                         # noqa
from flow_selftest import run_all as run_selftest                       # noqa
from flow_autotest import run_all as run_autotest                       # noqa
from flow_grid import build_grid                                        # noqa
from flow_ui import build_html                                          # noqa

CFG = ROOT / "config"; DIN = ROOT / "data/input"
DOUT = ROOT / "data/output"; DSTATE = ROOT / "data/state"


# ---------------- synthetic data (for testing without live feed) -------
def gen_synth(params: dict, universe: dict) -> dict:
    sp = params["synthetic"]; rng = np.random.default_rng(sp["seed"])
    n_days, alpha = sp["n_days"], sp["alpha"]
    beta = sp.get("beta", 0.0)                              # momentum injection
    ref_noise = sp.get("ref_noise", 0.0)                   # ground-truth measurement noise
    tickers = [t["ticker"] for t in universe["tickers"]]
    d0 = dt.date(2024, 1, 1)
    dates = [(d0 + dt.timedelta(days=i)).isoformat() for i in range(n_days)]
    recs = []; ref_recs = []
    for tk in tickers:
        g = np.zeros(n_days)
        for t in range(1, n_days):
            g[t] = 0.85*g[t-1] + rng.normal(0, 0.010)          # persistent flow
        px = np.empty(n_days); px[0] = 100.0
        r = np.zeros(n_days)
        for t in range(1, n_days):
            mom = (px[t-1]/px[max(0, t-21)] - 1) if t > 21 else 0.0
            r[t] = 0.0002 + alpha*g[t-1] + beta*mom + rng.normal(0, 0.012)
            px[t] = px[t-1]*(1+r[t])
        aum0 = float(rng.choice([5e9, 20e9, 80e9, 300e9]))
        sh = np.empty(n_days); sh[0] = aum0/px[0]
        aum_rep = np.empty(n_days); aum_rep[0] = sh[0]*px[0]
        true_flow = np.zeros(n_days)
        for t in range(1, n_days):
            flow = g[t]*(sh[t-1]*px[t-1])
            true_flow[t] = flow
            sh[t] = sh[t-1] + flow/px[t]
            aum_rep[t] = sh[t-1]*px[t-1]*(1+(px[t]/px[t-1]-1)) + flow
        # ground-truth reference = true flow + realistic measurement noise
        scale = np.abs(true_flow).mean() + 1.0
        ref_flow = true_flow + rng.normal(0, ref_noise*scale, n_days)
        for i in range(n_days):
            recs.append({"snapshot_date": dates[i], "ticker": tk,
                         "close": round(float(px[i]), 4),
                         "shares_out": round(float(sh[i]), 2),
                         "aum_reported": round(float(aum_rep[i]), 2)})
            ref_recs.append({"snapshot_date": dates[i], "ticker": tk,
                             "ref_flow": round(float(ref_flow[i]), 2)})
    save_json({"meta": {"mode": "synthetic_ref", "ref_noise": ref_noise},
               "records": ref_recs}, DIN / "reference_flows.json")
    return {"meta": {"generated": dt.datetime.now().isoformat(timespec="seconds"),
                     "mode": "synthetic", "alpha": alpha, "beta": beta,
                     "n_tickers": len(tickers), "n_days": n_days}, "records": recs}


# ---------------- run ledger (append-only) -----------------------------
def ledger(entry: dict):
    p = DSTATE / "run_ledger.jsonl"
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


# ---------------- commands ---------------------------------------------
def cmd_synth(params, universe):
    data = gen_synth(params, universe)
    save_json(data, DIN / "daily_data.json")
    print(f"[synth] wrote {len(data['records'])} records "
          f"({data['meta']['n_tickers']}x{data['meta']['n_days']}) alpha={data['meta']['alpha']}")
    return data


def cmd_calibrate(params, universe):
    data = load_json(DIN / "daily_data.json")
    frame = build_frame(data, universe)
    verdict = calibrate(frame, params)
    save_json(verdict, DOUT / "calibration.json")
    print(f"[calibrate] status={verdict['status']}  "
          f"trials={verdict['n_trials']} train_pass={verdict['n_train_pass']}")
    if verdict.get("best"):
        b = verdict["best"]; print(f"  best: W={b['window']} k={b['kappa']} "
                                   f"tier={b['min_tier']} score={b['train_score']}")
    print(f"  reason: {verdict['reason']}")
    ledger({"ts": dt.datetime.now().isoformat(timespec="seconds"),
            "step": "calibrate", "status": verdict["status"],
            "best": verdict.get("best")})
    return verdict


def cmd_run(params, universe, verdict=None):
    data = load_json(DIN / "daily_data.json")
    frame = build_frame(data, universe)
    if verdict is None and (DOUT / "calibration.json").exists():
        verdict = load_json(DOUT / "calibration.json")
    # use calibrated params if available
    ip = params["intensity"]; ap = params["aggregation"]
    if verdict and verdict.get("calibrated_params"):
        ip = verdict["calibrated_params"]["intensity"]
        ap = verdict["calibrated_params"]["aggregation"]
    df = compute_fis(frame, ip)
    # overlay the validated multi-factor composite, if a factor study exists
    fstudy = DOUT / "factors.json"
    if fstudy.exists():
        st = load_json(fstudy)
        if st.get("kept_signed"):
            df = composite_signal(df, params["factors"], st["kept_signed"])
    snap = latest_snapshot(df, ap)
    snap["composite_kept"] = (load_json(fstudy).get("kept") if fstudy.exists() else None)
    save_json(snap, DOUT / "snapshot.json")
    print(f"[run] snapshot {snap['snapshot_date']}  RORO={snap['roro_score']}  "
          f"classes={len(snap['by_asset_class'])}  composite={'yes' if fstudy.exists() else 'no'}")
    return snap, verdict


def cmd_factors(params, universe, verdict=None):
    from flow_core import compute_fis
    data = load_json(DIN / "daily_data.json")
    frame = build_frame(data, universe)
    if verdict is None and (DOUT / "calibration.json").exists():
        verdict = load_json(DOUT / "calibration.json")
    ip = params["intensity"]
    if verdict and verdict.get("calibrated_params"):
        ip = verdict["calibrated_params"]["intensity"]
    df = compute_fis(frame, ip)
    study = factor_study(df, params)
    save_json(study, DOUT / "factors.json")
    kept = study["kept"]; bic = study["base_ic"]["icir"]; cic = (study["composite_ic"] or {}).get("icir")
    print(f"[factors] kept={kept}")
    print(f"  base ICIR={bic}  composite ICIR={cic}  verdict={study['verdict']}")
    for r in study["factors"]:
        flag = "KEEP" if r["kept"] else "drop"
        print(f"    {r['factor']:<11} inc_IC={r['inc_ic']} (t={r['inc_t']})  -> {flag}")
    ledger({"ts": dt.datetime.now().isoformat(timespec="seconds"),
            "step": "factors", "kept": kept, "verdict": study["verdict"]})
    return study


def cmd_validate_a(params, universe, verdict=None):
    from flow_core import compute_fis
    pa = params.get("pillar_a")
    if not pa:
        print("[validate-a] no pillar_a config"); return None
    ref_path = ROOT / pa["reference"]
    if not ref_path.exists():
        print(f"[validate-a] reference not found: {ref_path} (supply ICI/COT/issuer truth)")
        rep = {"G001_measurement": None, "reason": "no reference series"}
        save_json(rep, DOUT / "pillar_a.json"); return rep
    data = load_json(DIN / "daily_data.json")
    frame = build_frame(data, universe)
    if verdict is None and (DOUT / "calibration.json").exists():
        verdict = load_json(DOUT / "calibration.json")
    ip = params["intensity"]
    if verdict and verdict.get("calibrated_params"):
        ip = verdict["calibrated_params"]["intensity"]
    df = compute_fis(frame, ip)
    rep = calibrate_measurement(df, load_json(ref_path), pa, pa.get("freq", "weekly"))
    save_json(rep, DOUT / "pillar_a.json")
    print(f"[validate-a] G001={rep['G001_measurement']}  median_rank_corr={rep['median_rank_corr']}"
          f"  pass_frac={rep['pass_fraction']}  ({rep['n_tickers']} tickers, {rep['freq']})")
    ledger({"ts": dt.datetime.now().isoformat(timespec="seconds"),
            "step": "validate-a", "G001": rep["G001_measurement"]})
    return rep


def cmd_selftest(params, universe):
    rep = run_selftest()
    save_json(rep, DOUT / "selftest.json")
    for t in rep["tests"]:
        if not t["ok"]:
            print(f"  [FAIL] {t['name']}: {t['detail']}")
    print(f"[selftest] {rep['n_pass']}/{rep['n_tests']} green -> "
          f"{'SOLID' if rep['all_green'] else 'NOT SOLID'}")
    return rep


def cmd_harden(params, universe):
    rep = run_autotest()
    save_json(rep, DOUT / "autotest.json")
    for t in rep["tests"]:
        if not t["ok"]:
            print(f"  [FAIL] {t['name']}: {t['detail']}")
    print(f"[harden] {rep['n_pass']}/{rep['n_tests']} green -> "
          f"{'PERFECT' if rep['all_green'] else 'NEEDS DEBUG'}")
    return rep


def compute_status(verdict, pillar_a, selftest, harden=None):
    pb = verdict.get("status") == "PROVED_VALID" if verdict else False
    pa = pillar_a.get("G001_measurement") if pillar_a else None
    st = selftest.get("all_green") if selftest else False
    hd = harden.get("all_green") if harden else True
    robust = bool(st and hd)
    solid = bool(pb and (pa is True) and robust)
    rob_detail = (f"selftest {selftest.get('n_pass')}/{selftest.get('n_tests')}"
                  if selftest else "selftest n/a")
    if harden:
        rob_detail += f" · autotest {harden.get('n_pass')}/{harden.get('n_tests')}"
    status = {"system_status": "SOLID" if solid else "NOT_SOLID",
              "pillar_b_efficacy": "PASS" if pb else "FAIL",
              "pillar_a_measurement": ("PASS" if pa is True else
                                       ("FAIL" if pa is False else "UNCALIBRATED")),
              "robustness": "PASS" if robust else "FAIL",
              "robustness_detail": rob_detail,
              "note": ("all layers green" if solid else
                       "measurement uncalibrated -> treat signal as indicative"
                       if pa is None else "see failing layer")}
    save_json(status, DOUT / "status.json")
    return status


def cmd_grid(params, universe, snap=None):
    if snap is None:
        snap = load_json(DOUT / "snapshot.json")
    grid = build_grid(universe, snap)
    save_json(grid, DOUT / "grid.json")
    nr = len(grid["region_sector"]["rows"]); nf = len(grid["fidelity"])
    print(f"[grid] region×sector {nr} regions x {len(grid['region_sector']['sectors'])} sectors"
          f"  ·  fidelity board {nf} classes")
    return grid


def cmd_ui(params, universe, snap=None, verdict=None, study=None, status=None, grid=None):
    if snap is None:
        snap = load_json(DOUT / "snapshot.json")
    if verdict is None:
        verdict = load_json(DOUT / "calibration.json")
    if study is None and (DOUT / "factors.json").exists():
        study = load_json(DOUT / "factors.json")
    if status is None and (DOUT / "status.json").exists():
        status = load_json(DOUT / "status.json")
    if grid is None and (DOUT / "grid.json").exists():
        grid = load_json(DOUT / "grid.json")
    out = ROOT / "index.html"
    build_html(snap, verdict, out, study, status, grid)
    print(f"[ui] wrote {out}")
    return out


def cmd_all(params, universe):
    cmd_synth(params, universe)
    selftest = cmd_selftest(params, universe)
    harden = cmd_harden(params, universe)
    verdict = cmd_calibrate(params, universe)
    study = cmd_factors(params, universe, verdict)
    snap, verdict = cmd_run(params, universe, verdict)
    pillar_a = cmd_validate_a(params, universe, verdict)
    status = compute_status(verdict, pillar_a, selftest, harden)
    grid = cmd_grid(params, universe, snap)
    cmd_ui(params, universe, snap, verdict, study, status, grid)
    print(f"\n[all] DONE — SYSTEM STATUS: {status['system_status']}  "
          f"(B={status['pillar_b_efficacy']} A={status['pillar_a_measurement']} "
          f"robust={status['robustness']})")
    return verdict


def cmd_bridge(params, universe):
    from flow_bridge import run_bridge
    bp = params.get("bridge")
    if not bp:
        print("[bridge] no 'bridge' config in params.json"); return
    tickers = [t["ticker"] for t in universe["tickers"]]
    meta = run_bridge(bp["source"], bp["format"], bp["colmap"], tickers,
                      DIN / "daily_data.json")
    ledger({"ts": dt.datetime.now().isoformat(timespec="seconds"),
            "step": "bridge", "n_records": meta["n_records"],
            "degenerate_aum": meta["aum_reported_degenerate"]})
    return meta


def cmd_live(params, universe):
    cmd_bridge(params, universe)
    selftest = cmd_selftest(params, universe)
    harden = cmd_harden(params, universe)
    verdict = cmd_calibrate(params, universe)
    study = cmd_factors(params, universe, verdict)
    snap, verdict = cmd_run(params, universe, verdict)
    pillar_a = cmd_validate_a(params, universe, verdict)
    status = compute_status(verdict, pillar_a, selftest, harden)
    grid = cmd_grid(params, universe, snap)
    cmd_ui(params, universe, snap, verdict, study, status, grid)
    print(f"\n[live] DONE — SYSTEM STATUS: {status['system_status']}")
    return verdict


def main():
    ap = argparse.ArgumentParser(prog="flow_manager")
    ap.add_argument("cmd", choices=["synth", "bridge", "calibrate", "run",
                                    "factors", "validate-a", "selftest", "harden",
                                    "grid", "ui", "all", "live"])
    ap.add_argument("--params", default=str(CFG / "params.json"))
    ap.add_argument("--universe", default=str(CFG / "universe.json"))
    a = ap.parse_args()
    params = load_json(a.params); universe = load_json(a.universe)
    {"synth": cmd_synth, "bridge": cmd_bridge, "calibrate": cmd_calibrate,
     "run": cmd_run, "factors": cmd_factors, "validate-a": cmd_validate_a,
     "selftest": cmd_selftest, "harden": cmd_harden, "grid": cmd_grid, "ui": cmd_ui,
     "all": cmd_all, "live": cmd_live}[a.cmd](params, universe)


if __name__ == "__main__":
    main()
