# -*- coding: utf-8 -*-
# VDF-FLOW-SELFTEST-20 : edge-case hardening. Each test returns (name, ok, detail).
# Run until all green -> system is solid.
from __future__ import annotations
import datetime as dt
import numpy as np
import polars as pl

from flow_core import compute_fis, bucket_fis, roro, latest_snapshot
from flow_validate import add_fwd_returns, daily_ic, evaluate, null_ic
from flow_factors import add_factors, factor_study
from flow_pillar_a import measure_ticker, calibrate_measurement


def _mini(n_tk=8, n_days=140, seed=0, corrupt=None, tiny=False):
    rng = np.random.default_rng(seed)
    d0 = dt.date(2024, 1, 1)
    dates = [d0 + dt.timedelta(days=i) for i in range(n_days)]
    frames = []
    for j in range(n_tk):
        g = rng.normal(0, 0.01, n_days)
        px = 100 * np.cumprod(1 + rng.normal(0.0003, 0.011, n_days))
        aum0 = 1e7 if (tiny and j == 0) else float(rng.choice([5e9, 50e9]))
        sh = np.empty(n_days); sh[0] = aum0 / px[0]
        aum_rep = np.empty(n_days); aum_rep[0] = sh[0] * px[0]
        for t in range(1, n_days):
            flow = g[t]*(sh[t-1]*px[t-1])
            sh[t] = sh[t-1] + flow/px[t]
            aum_rep[t] = sh[t-1]*px[t-1]*(1+(px[t]/px[t-1]-1)) + flow  # independent of shares corruption
        sh_out = sh.copy()
        if corrupt == "stale" and j == 0:
            sh_out[40:70] = sh[39]                     # freeze ONLY the shares feed
        frames.append(pl.DataFrame({
            "snapshot_date": dates, "ticker": [f"T{j}"]*n_days,
            "asset_class": ["Equity"]*n_days, "region": ["US"]*n_days,
            "risk_bucket": ["RISK"]*n_days,
            "backing": ["spot_physical"]*n_days, "monitor_role": ["flow_signal"]*n_days,
            "fidelity": [3]*n_days, "close": px, "shares_out": sh_out,
            "aum_reported": aum_rep}))
    return pl.concat(frames)


IP = {"window": 40, "min_obs": 12, "kappa": 3.0, "aum_floor": 50e6,
      "winsor_z": 8.0, "ewma_span": 5}
AP = {"min_tier": "B", "roro_kappa": 40.0, "flow_roles": ["flow_signal", "cash_parking"]}
VP = {"horizons": [1, 5], "ls_top_frac": 0.2, "ls_cost_bps": 8.0, "primary_horizon": 5,
      "gates": {"ic_min": 0.03, "icir_min": 0.30, "t_min": 2.0,
                "quantile_mono_min": 0.80, "ls_sharpe_min": 0.50,
                "null_ic_max": 0.015, "oos_t_min": 1.5}}
FP = {"library": ["mom_20", "noise"], "base": "fis", "accel_lag": 5,
      "mom_short": 20, "mom_long": 63, "rvol_win": 20,
      "keep_incremental_t": 2.0, "compose": "zsum"}
PARAMS = {"intensity": IP, "aggregation": AP, "validation": VP, "factors": FP}


def _t(name, fn):
    try:
        ok, detail = fn()
        return (name, bool(ok), detail)
    except Exception as e:
        return (name, False, f"EXC {type(e).__name__}: {e}")


def run_all() -> dict:
    tests = []

    def normal_fis():
        df = compute_fis(_mini(), IP)
        fin = df["fis"].drop_nulls().drop_nans()
        return (fin.len() > 0 and df["fis"].abs().max() <= 100), f"max|FIS|={df['fis'].abs().max()}"
    tests.append(_t("fis_normal", normal_fis))

    def single_ticker():
        df = compute_fis(_mini(n_tk=1), IP)
        return df.height > 0, f"rows={df.height}"
    tests.append(_t("fis_single_ticker", single_ticker))

    def short_history():
        df = compute_fis(_mini(n_days=15), IP)  # < window
        # FIS should be mostly null but must not crash; confidence D/C
        return True, f"rows={df.height} A/B={df.filter(pl.col('confidence').is_in(['A','B'])).height}"
    tests.append(_t("fis_short_history", short_history))

    def tiny_aum():
        df = compute_fis(_mini(tiny=True), IP)
        t0 = df.filter(pl.col("ticker") == "T0")
        bad = t0.filter(pl.col("confidence") == "A").height
        return bad == 0, f"T0 A-tier rows (should be 0 for sub-floor)={bad}"
    tests.append(_t("fis_tiny_aum_downgraded", tiny_aum))

    def stale_caught():
        df = compute_fis(_mini(corrupt="stale"), IP)
        conf = df.filter((pl.col("ticker") == "T0") &
                         (pl.col("est_trust") == "CONFLICT")).height
        return conf > 0, f"CONFLICT days on stale T0={conf}"
    tests.append(_t("dualest_stale_flagged", stale_caught))

    def agg_roles():
        df = compute_fis(_mini(), IP)
        b = bucket_fis(df, "risk_bucket", "B", AP["flow_roles"])
        return b.height > 0, f"bucket rows={b.height}"
    tests.append(_t("aggregation_roles", agg_roles))

    def roro_ok():
        df = compute_fis(_mini(), IP)
        rr = roro(df, AP)
        return rr.height > 0 and "roro_score" in rr.columns, "roro built"
    tests.append(_t("roro_builds", roro_ok))

    def snapshot_ok():
        df = compute_fis(_mini(), IP)
        s = latest_snapshot(df, AP)
        return ("per_ticker" in s and len(s["per_ticker"]) > 0), f"n={len(s['per_ticker'])}"
    tests.append(_t("snapshot_emits", snapshot_ok))

    def validate_runs():
        df = compute_fis(_mini(n_days=160), IP)
        rep = evaluate(df, PARAMS)
        return "gates" in rep, f"valid={rep['overall_valid']}"
    tests.append(_t("validate_runs", validate_runs))

    def null_zero_on_random():
        # random signal vs random returns -> null IC near 0
        df = compute_fis(_mini(n_days=160, seed=3), IP)
        df = add_fwd_returns(df, [5]).with_columns(
            pl.Series("rnd", np.random.default_rng(5).standard_normal(df.height)))
        nic = null_ic(df, "rnd", "fwd_ret_5", "B")
        return (nic is None or abs(nic) < 0.05), f"null IC={nic}"
    tests.append(_t("null_near_zero", null_zero_on_random))

    def factors_drop_noise():
        df = compute_fis(_mini(n_days=180), IP)
        st = factor_study(df, PARAMS)
        noise_row = [r for r in st["factors"] if r["factor"] == "noise"]
        return (noise_row and not noise_row[0]["kept"]), "noise correctly dropped"
    tests.append(_t("factors_drop_noise", factors_drop_noise))

    def pillar_a_good():
        # est ~ ref + small noise -> high rank corr
        rng = np.random.default_rng(2)
        true = rng.normal(0, 1e7, 200)
        m = measure_ticker(true, true + rng.normal(0, 0.3e7, 200))
        return (m["rank_corr"] is not None and m["rank_corr"] > 0.7), f"rc={m['rank_corr']}"
    tests.append(_t("pillarA_good_passes", pillar_a_good))

    def pillar_a_bad():
        # est unrelated to ref -> low rank corr (must be caught)
        rng = np.random.default_rng(2)
        m = measure_ticker(rng.normal(0, 1e7, 200), rng.normal(0, 1e7, 200))
        return (m["rank_corr"] is None or abs(m["rank_corr"]) < 0.3), f"rc={m['rank_corr']}"
    tests.append(_t("pillarA_bad_caught", pillar_a_bad))

    def empty_safe():
        empty = _mini(n_tk=8).head(0)
        try:
            compute_fis(empty, IP)
            return True, "empty handled"
        except Exception as e:
            # acceptable to raise a clean error, not crash silently
            return True, f"clean raise: {type(e).__name__}"
    tests.append(_t("empty_input_safe", empty_safe))

    n_pass = sum(1 for _, ok, _ in tests if ok)
    return {"n_tests": len(tests), "n_pass": n_pass,
            "all_green": n_pass == len(tests),
            "tests": [{"name": n, "ok": ok, "detail": d} for n, ok, d in tests]}


if __name__ == "__main__":
    r = run_all()
    for t in r["tests"]:
        print(f"  [{'PASS' if t['ok'] else 'FAIL'}] {t['name']:<28} {t['detail']}")
    print(f"\n{r['n_pass']}/{r['n_tests']} green  -> {'SOLID' if r['all_green'] else 'NOT SOLID'}")
