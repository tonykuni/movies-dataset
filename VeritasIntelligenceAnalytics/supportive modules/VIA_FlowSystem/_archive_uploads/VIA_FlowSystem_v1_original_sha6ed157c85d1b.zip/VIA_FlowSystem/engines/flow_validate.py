# -*- coding: utf-8 -*-
# VDF-FLOW-VALIDATE-12 : Pillar-B efficacy tests + gate evaluation.
from __future__ import annotations
import numpy as np
import polars as pl
from flow_core import _tier_ok, _clean


def _rank(a):
    r = np.empty(len(a)); r[a.argsort()] = np.arange(len(a))
    _, inv, cnt = np.unique(a, return_inverse=True, return_counts=True)
    s = np.zeros(len(cnt)); np.add.at(s, inv, r)
    return (s/cnt)[inv]


def _spear(x, y):
    m = np.isfinite(x) & np.isfinite(y)
    if m.sum() < 4:
        return np.nan
    rx, ry = _rank(x[m]), _rank(y[m]); rx -= rx.mean(); ry -= ry.mean()
    d = math_sqrt((rx**2).sum()*(ry**2).sum())
    return float((rx*ry).sum()/d) if d > 0 else np.nan


def math_sqrt(v):
    return float(np.sqrt(v))


def add_fwd_returns(df, horizons):
    df = df.sort(["ticker", "snapshot_date"])
    return df.with_columns([
        (pl.col("close").shift(-h).over("ticker")/pl.col("close")-1).alias(f"fwd_ret_{h}")
        for h in horizons])


def daily_ic(df, signal, ret, min_tier="B"):
    d = df.filter(_tier_ok(min_tier)).select(["snapshot_date", signal, ret]).drop_nulls()
    ics = []
    for _, g in d.group_by("snapshot_date", maintain_order=True):
        ic = _spear(g[signal].to_numpy(), g[ret].to_numpy())
        if np.isfinite(ic):
            ics.append(ic)
    ics = np.array(ics)
    if len(ics) < 5:
        return dict(ic=None, icir=None, t=None, n_days=len(ics), hit=None)
    m, sd = ics.mean(), ics.std(ddof=1)
    return dict(ic=round(float(m), 4), icir=round(float(m/sd), 3) if sd > 0 else None,
                t=round(float(m/(sd/np.sqrt(len(ics)))), 2) if sd > 0 else None,
                n_days=len(ics), hit=round(float((ics > 0).mean()), 3))


def ic_decay(df, signal, horizons, min_tier="B"):
    return [dict(h=h, **daily_ic(df, signal, f"fwd_ret_{h}", min_tier)) for h in horizons]


def quantile_mono(df, signal, ret, q=5, min_tier="B"):
    d = df.filter(_tier_ok(min_tier)).select(["snapshot_date", signal, ret]).drop_nulls()
    buckets = {k: [] for k in range(q)}
    for _, g in d.group_by("snapshot_date"):
        if g.height < q*2:
            continue
        s, r = g[signal].to_numpy(), g[ret].to_numpy()
        qi = np.clip((_rank(s)/len(s)*q).astype(int), 0, q-1)
        for k in range(q):
            if (qi == k).any():
                buckets[k].append(r[qi == k].mean())
    means = [float(np.mean(buckets[k])) if buckets[k] else np.nan for k in range(q)]
    mono = _spear(np.arange(q, dtype=float), np.array(means))
    tb = means[-1]-means[0] if np.isfinite(means[-1]) and np.isfinite(means[0]) else np.nan
    return dict(q_means=[_clean(round(m, 5)) for m in means],
                mono=_clean(round(float(mono), 3)), top_minus_bottom=_clean(round(float(tb), 5)))


def long_short(df, signal, ret, top_frac, cost_bps, min_tier="B"):
    d = df.filter(_tier_ok(min_tier)).select(
        ["snapshot_date", "ticker", signal, ret]).drop_nulls().sort("snapshot_date")
    prev, daily = {}, []
    for _, g in d.group_by("snapshot_date", maintain_order=True):
        if g.height < 6:
            continue
        s, r, tks = g[signal].to_numpy(), g[ret].to_numpy(), g["ticker"].to_list()
        k = max(1, int(len(s)*top_frac)); idx = np.argsort(s)
        w = {t: 0.0 for t in tks}
        for t in [tks[j] for j in idx[-k:]]:
            w[t] = 0.5/k
        for t in [tks[j] for j in idx[:k]]:
            w[t] = -0.5/k
        gross = sum(w[t]*r[tks.index(t)] for t in tks)
        turn = sum(abs(w.get(t, 0)-prev.get(t, 0)) for t in set(w) | set(prev))
        daily.append(gross - turn*cost_bps/1e4); prev = w
    daily = np.array(daily)
    if len(daily) < 5:
        return dict(sharpe=None, ann_ret=None, n=len(daily))
    ann, vol = daily.mean()*252, daily.std(ddof=1)*np.sqrt(252)
    return dict(sharpe=round(float(ann/vol), 2) if vol > 0 else None,
                ann_ret=round(float(ann), 4), n=len(daily))


def null_ic(df, signal, ret, min_tier="B", k=15):
    """Permutation null: average IC over K within-day shuffles so a single
    accidental permutation can't fail the gate. -> ~0 when no leakage."""
    vals = []
    for s in range(k):
        sh = df.with_columns(pl.col(signal).shuffle(seed=1000+s).over("snapshot_date").alias("_z"))
        ic = daily_ic(sh, "_z", ret, min_tier)["ic"]
        if ic is not None:
            vals.append(ic)
    if not vals:
        return None
    return round(float(np.mean(vals)), 4)


# -------------- gate evaluation --------------
def evaluate(df, params, oos_df=None) -> dict:
    vp = params["validation"]; gp = vp["gates"]; h = vp["primary_horizon"]
    mt = params["aggregation"]["min_tier"]
    df = add_fwd_returns(df, vp["horizons"])
    ic_h = daily_ic(df, "fis", f"fwd_ret_{h}", mt)
    qm = quantile_mono(df, "fis", f"fwd_ret_{h}", 5, mt)
    ls = long_short(df, "fis", f"fwd_ret_{h}", vp["ls_top_frac"], vp["ls_cost_bps"], mt)
    nic = null_ic(df, "fis", f"fwd_ret_{h}", mt)
    decay = ic_decay(df, "fis", vp["horizons"], mt)

    def ok(cond):
        return bool(cond)
    gates = {
        "G003_ic":   ok(ic_h["ic"] is not None and abs(ic_h["ic"]) >= gp["ic_min"]),
        "G003_icir": ok(ic_h["icir"] is not None and ic_h["icir"] >= gp["icir_min"]),
        "G003_t":    ok(ic_h["t"] is not None and abs(ic_h["t"]) >= gp["t_min"]),
        "G004_mono": ok(qm["mono"] is not None and qm["mono"] >= gp["quantile_mono_min"]),
        "G008_ls":   ok(ls["sharpe"] is not None and ls["sharpe"] >= gp["ls_sharpe_min"]),
        "G002_null": ok(nic is not None and abs(nic) <= gp["null_ic_max"]),
    }
    rep = {"horizon": h, "ic": ic_h, "quantile": qm, "long_short": ls,
           "null_ic": _clean(nic), "ic_decay": decay, "gates": gates,
           "train_pass": all(gates.values())}
    if oos_df is not None:
        oos = add_fwd_returns(oos_df, [h])
        oic = daily_ic(oos, "fis", f"fwd_ret_{h}", mt)
        same_sign = (oic["ic"] is not None and ic_h["ic"] is not None and
                     np.sign(oic["ic"]) == np.sign(ic_h["ic"]))
        g_oos = ok(oic["t"] is not None and abs(oic["t"]) >= gp["oos_t_min"] and same_sign)
        rep["oos"] = {"ic": oic, "G009_oos": g_oos}
        rep["gates"]["G009_oos"] = g_oos
        rep["overall_valid"] = all(rep["gates"].values())
    else:
        rep["overall_valid"] = rep["train_pass"]
    return rep
