# -*- coding: utf-8 -*-
# VDF-FLOW-CORE-11 : intensity + dual-estimator trust + aggregation.
# All functions embedded here. Params/data via JSON. UTF-8 No-BOM.
from __future__ import annotations
import json, math
from pathlib import Path
import numpy as np
import polars as pl

EPS = 1e-12
TIER = {"A": 3, "B": 2, "C": 1, "D": 0}


# ---------------- JSON helpers (No-BOM) ----------------
def load_json(p: str | Path) -> dict:
    return json.loads(Path(p).read_text(encoding="utf-8"))


def save_json(obj, p: str | Path) -> None:
    # strict: never emit NaN/Infinity tokens (would break JSON.parse in the UI)
    Path(p).write_text(json.dumps(_sanitize(obj), ensure_ascii=False, indent=2,
                                  allow_nan=False), encoding="utf-8")


def _sanitize(o):
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    if isinstance(o, dict):
        return {k: _sanitize(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_sanitize(v) for v in o]
    if isinstance(o, np.floating):
        f = float(o); return f if math.isfinite(f) else None
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, np.ndarray):
        return _sanitize(o.tolist())
    return o


def _clean(x):
    return None if (x is None or (isinstance(x, float) and not math.isfinite(x))) else x


# ---------------- build frame from data + universe ----------------
def build_frame(data: dict, universe: dict) -> pl.DataFrame:
    recs = pl.DataFrame(data["records"]).with_columns(
        pl.col("snapshot_date").str.to_date())
    uni = pl.DataFrame(universe["tickers"]).select(
        ["ticker", "asset_class", "region", "risk_bucket", "backing",
         "monitor_role", "fidelity"])
    return recs.join(uni, on="ticker", how="left").sort(["ticker", "snapshot_date"])


# ---------------- FIS intensity ----------------
def compute_fis(df: pl.DataFrame, ip: dict) -> pl.DataFrame:
    W, mo, kap = ip["window"], ip["min_obs"], ip["kappa"]
    floor, winz = ip["aum_floor"], ip["winsor_z"]
    # input guard: non-finite / non-positive price and non-finite shares -> null
    # (prevents Inf/NaN from propagating into FIS); then stable per-ticker sort
    df = df.with_columns([
        pl.when(pl.col("close").is_finite() & (pl.col("close") > 0))
          .then(pl.col("close")).otherwise(None).alias("close"),
        pl.when(pl.col("shares_out").is_finite() & (pl.col("shares_out") >= 0))
          .then(pl.col("shares_out")).otherwise(None).alias("shares_out"),
    ]).sort(["ticker", "snapshot_date"])
    df = df.with_columns([
        (pl.col("shares_out") * pl.col("close")).alias("aum_est"),
        pl.col("shares_out").diff().over("ticker").alias("d_shares"),
    ]).with_columns([
        (pl.col("d_shares") * pl.col("close")).alias("shares_flow"),
        (pl.col("aum_est").shift(1).over("ticker")).alias("aum_lag"),
    ])
    # dual-estimator (if aum_reported present) -> est_trust + flow_best
    if "aum_reported" in df.columns:
        df = df.with_columns([
            (pl.col("close")/pl.col("close").shift(1).over("ticker")-1).alias("nav_ret"),
            (pl.col("aum_reported").shift(1).over("ticker")).alias("aum_rep_lag"),
        ]).with_columns(
            (pl.col("aum_reported") - pl.col("aum_rep_lag")*(1+pl.col("nav_ret")))
            .alias("nav_flow")
        ).with_columns(
            (((pl.col("shares_flow")*pl.col("nav_flow")) < 0) |
             ((pl.col("shares_flow")-pl.col("nav_flow")).abs() >
              0.5*pl.max_horizontal(pl.col("shares_flow").abs(),
                                    pl.col("nav_flow").abs())+1.0)).alias("flow_conflict")
        ).with_columns([
            pl.when(pl.col("flow_conflict")).then(pl.lit("CONFLICT"))
              .otherwise(pl.lit("OK")).alias("est_trust"),
            pl.when(pl.col("flow_conflict")).then(pl.col("nav_flow"))
              .otherwise(pl.col("shares_flow")).alias("netflow_est"),
        ])
    else:
        df = df.with_columns([pl.lit("OK").alias("est_trust"),
                              pl.col("shares_flow").alias("netflow_est")])

    df = df.with_columns(
        pl.when(pl.col("aum_lag") > 0)
          .then(pl.col("netflow_est")/pl.col("aum_lag"))
          .otherwise(None).alias("organic_flow"))

    g_lag = pl.col("organic_flow").shift(1).over("ticker")
    df = df.with_columns(
        g_lag.rolling_median(window_size=W, min_samples=mo).over("ticker").alias("org_med"))
    df = df.with_columns(
        (g_lag - pl.col("org_med")).abs().alias("_ad"))
    df = df.with_columns(
        pl.col("_ad").rolling_median(window_size=W, min_samples=mo).over("ticker").alias("org_mad"))
    df = df.with_columns([
        (1.4826*pl.col("org_mad")).alias("org_sigma"),
        g_lag.is_not_null().cast(pl.Int32).rolling_sum(window_size=W, min_samples=1)
             .over("ticker").alias("win_obs"),
    ]).with_columns(
        ((pl.col("organic_flow")-pl.col("org_med"))/(pl.col("org_sigma")+EPS))
        .clip(-winz, winz).alias("flow_z")
    ).with_columns(
        (100.0*(pl.col("flow_z")/kap).tanh()).round(1).alias("fis")
    ).with_columns(
        pl.when((pl.col("aum_lag") >= floor) & (pl.col("win_obs") >= mo) &
                (pl.col("org_sigma") > 0)).then(pl.lit("A"))
          .when((pl.col("aum_lag") >= floor*0.4) & (pl.col("win_obs") >= mo*0.6) &
                (pl.col("org_sigma") > 0)).then(pl.lit("B"))
          .when((pl.col("aum_lag") > 0) & (pl.col("win_obs") >= 5)).then(pl.lit("C"))
          .otherwise(pl.lit("D")).alias("confidence")
    ).drop("_ad")
    return df


# ---------------- aggregation ----------------
def _tier_ok(min_tier):
    return pl.col("confidence").replace_strict(TIER, default=0) >= TIER[min_tier]


def bucket_fis(df: pl.DataFrame, group_col: str, min_tier="B",
               flow_roles=None) -> pl.DataFrame:
    keep = df.filter(_tier_ok(min_tier) & pl.col("fis").is_not_null() &
                     (pl.col("aum_est") > 0))
    # only ETFs whose flow maps to real SPOT capital movement feed the sum
    if flow_roles is not None and "monitor_role" in keep.columns:
        keep = keep.filter(pl.col("monitor_role").is_in(flow_roles))
    return (keep.group_by(["snapshot_date", group_col])
            .agg([((pl.col("fis")*pl.col("aum_est")).sum()/pl.col("aum_est").sum())
                  .round(1).alias("bucket_fis"),
                  pl.col("netflow_est").sum().alias("netflow_usd"),
                  pl.len().alias("n")])
            .sort(["snapshot_date", group_col]))


def roro(df: pl.DataFrame, ap: dict) -> pl.DataFrame:
    fr = ap.get("flow_roles")
    b = bucket_fis(df, "risk_bucket", ap["min_tier"], fr)
    w = b.pivot(values="bucket_fis", index="snapshot_date", on="risk_bucket",
                aggregate_function="first")
    for c in ("RISK", "SAFE"):
        if c not in w.columns:
            w = w.with_columns(pl.lit(None, dtype=pl.Float64).alias(c))
    return w.with_columns(
        (100.0*((pl.col("RISK").fill_null(0)-pl.col("SAFE").fill_null(0))/ap["roro_kappa"]).tanh())
        .round(1).alias("roro_score")).sort("snapshot_date")


# ---------------- snapshot emit ----------------
def latest_snapshot(df: pl.DataFrame, ap: dict) -> dict:
    last = df["snapshot_date"].max()
    cur = df.filter(pl.col("snapshot_date") == last)
    fr = ap.get("flow_roles")
    has_comp = "composite" in cur.columns
    if has_comp:
        cv = cur.select(["ticker", "composite"]).drop_nulls()
        n = cv.height
        ranks = {r["ticker"]: round(100.0*i/max(n-1, 1), 1)
                 for i, r in enumerate(cv.sort("composite").iter_rows(named=True))}
    per = []
    for r in cur.iter_rows(named=True):
        row = {"ticker": r["ticker"], "asset_class": r["asset_class"],
               "region": r.get("region"), "risk_bucket": r["risk_bucket"], "fis": _clean(r["fis"]),
               "confidence": r["confidence"], "est_trust": r["est_trust"],
               "netflow_usd": _clean(r["netflow_est"]), "fidelity": r["fidelity"],
               "monitor_role": r["monitor_role"]}
        if has_comp:
            row["composite"] = _clean(round(r["composite"], 2)) if r["composite"] is not None else None
            row["composite_pct"] = ranks.get(r["ticker"])
        per.append(row)
    bclass = bucket_fis(df, "asset_class", ap["min_tier"], fr).filter(
        pl.col("snapshot_date") == last)
    bbucket = bucket_fis(df, "risk_bucket", ap["min_tier"], fr).filter(
        pl.col("snapshot_date") == last)
    rr = roro(df, ap).filter(pl.col("snapshot_date") == last)
    return {
        "snapshot_date": str(last),
        "per_ticker": sorted(per, key=lambda x: (x["fis"] is None, -(x["fis"] or 0))),
        "by_asset_class": [{"k": r["asset_class"], "fis": _clean(r["bucket_fis"]),
                            "netflow_usd": _clean(r["netflow_usd"]), "n": r["n"]}
                           for r in bclass.iter_rows(named=True)],
        "by_risk_bucket": [{"k": r["risk_bucket"], "fis": _clean(r["bucket_fis"]),
                            "netflow_usd": _clean(r["netflow_usd"]), "n": r["n"]}
                           for r in bbucket.iter_rows(named=True)],
        "roro_score": _clean(rr["roro_score"][0]) if rr.height else None,
    }
