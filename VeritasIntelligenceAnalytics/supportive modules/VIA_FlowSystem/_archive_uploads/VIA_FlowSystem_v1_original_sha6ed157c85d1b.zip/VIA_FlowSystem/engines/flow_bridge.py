# -*- coding: utf-8 -*-
# VDF-FLOW-BRIDGE-18 : fetch_global_etf_tracker_v4 -> daily_data.json
# Maps the v4 warehouse output (CSV or Parquet) into the system input schema:
#   snapshot_date, ticker, close, shares_out, aum_reported
# colmap (in params.json -> bridge.colmap) maps SYSTEM_FIELD -> SOURCE_COLUMN
# so you only edit JSON when v4's column names differ. UTF-8 No-BOM out.
from __future__ import annotations
import datetime as dt
from pathlib import Path
import polars as pl

REQUIRED = ["snapshot_date", "ticker", "close", "shares_out"]


def run_bridge(source: str, fmt: str, colmap: dict,
               universe_tickers: list[str], out_path: str | Path) -> dict:
    src = Path(source)
    if not src.exists():
        raise SystemExit(f"[bridge] source not found: {src}")
    if fmt == "parquet":
        df = pl.read_parquet(src)
    elif fmt == "csv":
        df = pl.read_csv(src, infer_schema_length=2000)
    else:
        raise SystemExit(f"[bridge] unsupported fmt: {fmt}")

    # rename SOURCE_COLUMN -> SYSTEM_FIELD (only those present)
    ren = {srccol: field for field, srccol in colmap.items() if srccol in df.columns}
    df = df.rename(ren)

    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise SystemExit(f"[bridge] missing required columns after mapping: {missing}\n"
                         f"  available: {df.columns}\n"
                         f"  -> fix params.json bridge.colmap")

    degenerate = False
    if "aum_reported" not in df.columns:
        # no independent AUM source -> derive (dual-estimator becomes degenerate)
        df = df.with_columns((pl.col("shares_out") * pl.col("close")).alias("aum_reported"))
        degenerate = True

    # normalize date to ISO yyyy-mm-dd string
    df = df.with_columns(
        pl.col("snapshot_date").cast(pl.Utf8).str.slice(0, 10).alias("snapshot_date"))

    # keep only universe tickers, drop incomplete rows, sort
    df = (df.filter(pl.col("ticker").is_in(universe_tickers))
            .select(REQUIRED + ["aum_reported"])
            .drop_nulls(["close", "shares_out"])
            .sort(["ticker", "snapshot_date"]))

    recs = df.to_dicts()
    n_tk = df["ticker"].n_unique()
    n_dy = df["snapshot_date"].n_unique()
    covered = sorted(set(df["ticker"].to_list()))
    missing_tk = [t for t in universe_tickers if t not in covered]

    meta = {"generated": dt.datetime.now().isoformat(timespec="seconds"),
            "mode": "live_bridge", "source": str(src), "format": fmt,
            "n_records": len(recs), "n_tickers": n_tk, "n_days": n_dy,
            "aum_reported_degenerate": degenerate,
            "tickers_missing_from_source": missing_tk}
    import json
    Path(out_path).write_text(
        json.dumps({"meta": meta, "records": recs}, ensure_ascii=False, indent=2),
        encoding="utf-8")

    print(f"[bridge] wrote {len(recs)} records  {n_tk} tickers x {n_dy} days -> {out_path}")
    if degenerate:
        print("[bridge] WARN: no aum_reported in source -> dual-estimator degenerate "
              "(shares-flow only). Log issuer/NAV AUM daily to enable CONFLICT detection.")
    if missing_tk:
        print(f"[bridge] NOTE: {len(missing_tk)} universe tickers absent in source: "
              f"{missing_tk[:8]}{'...' if len(missing_tk) > 8 else ''}")
    return meta


# standalone self-test: synthesize a v4-style CSV and bridge it
if __name__ == "__main__":
    import numpy as np
    out = Path("_v4_sample.csv")
    rng = np.random.default_rng(1)
    rows = []
    for tk in ["SPY", "QQQ", "XLK", "TLT", "GLD"]:
        px = 100.0; sh = 1e9
        for i in range(40):
            d = (dt.date(2026, 1, 1) + dt.timedelta(days=i)).isoformat()
            px *= 1 + rng.normal(0.0004, 0.01); sh += rng.normal(0, 2e6)
            rows.append({"Date": d, "Ticker": tk, "Close": round(px, 4),
                         "SharesOut": round(sh, 1), "AUM_est": round(sh*px, 1)})
    pl.DataFrame(rows).write_csv(out)
    cm = {"snapshot_date": "Date", "ticker": "Ticker", "close": "Close",
          "shares_out": "SharesOut", "aum_reported": "AUM_est"}
    run_bridge(str(out), "csv", cm, ["SPY", "QQQ", "XLK", "TLT", "GLD", "EWT"],
               "_bridge_out.json")
    out.unlink(missing_ok=True)
