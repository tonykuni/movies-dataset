# -*- coding: utf-8 -*-
"""Retention planner. Default = plan only. Protected canon side-cars never deleted."""
from __future__ import annotations
import argparse,json,shutil
from datetime import datetime,timedelta
from pathlib import Path
from workops_gapfill_common import *
PARAM=WORKOPS/"config"/"retention_params.json"; PLAN=OUT/"retention_plan.json"
def plan():
    p=loadj(PARAM,{})
    cutoff=datetime.now()-timedelta(days=int(p.get("derived_run_days",90)))
    protected=set(p.get("protected",[]));candidates=[]
    for f in OUT.rglob("*"):
        if not f.is_file():continue
        if f.name in protected:continue
        # only derived run/report/cache paths, never arbitrary out files
        rel=str(f.relative_to(OUT)).replace("\\","/")
        if not any(x in rel.lower() for x in ("run_","deep/scanrange","reports","cache","tmp")):continue
        if datetime.fromtimestamp(f.stat().st_mtime)<cutoff:
            candidates.append({"path":rel,"bytes":f.stat().st_size})
    doc={"version":"v0200","engine":"workops_retention_manager","generated_at":now(),"gate":"REVIEW_REQUIRED",
         "cutoff":cutoff.isoformat(timespec="seconds"),"candidate_count":len(candidates),"candidates":candidates,
         "protected":sorted(protected),"canonical_mutation":False}
    atomic_json(PLAN,doc);return doc
def apply(confirm=False):
    if not confirm: raise SystemExit("explicit --confirm required")
    d=plan()
    # require existing verified backup from canonical ENG-031; this manager does not duplicate backup logic
    bks=list((OUT/"backups").glob("*.zip"))
    if not bks: raise SystemExit("no backup zip found; run via-workops backup first")
    deleted=[]
    for x in d["candidates"]:
        p=OUT/x["path"]
        if p.exists() and p.is_file():p.unlink();deleted.append(x["path"])
    return {"gate":"PASS","deleted":deleted,"protected_count":len(d["protected"])}
def main():
    ap=argparse.ArgumentParser();ap.add_argument("command",choices=["plan","apply"]);ap.add_argument("--confirm",action="store_true");a=ap.parse_args()
    o=plan() if a.command=="plan" else apply(a.confirm);print(json.dumps(o,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
