# -*- coding: utf-8 -*-
"""Structured lesson candidates. Human confirmation required."""
from __future__ import annotations
import argparse,json,csv
from workops_gapfill_common import *
CAND=OUT/"lesson_candidates.json"; REG=OUT/"lesson_registry.jsonl"
def build():
    rows=[]
    for e in loadjl(OUT/"closure_events.jsonl"):
        if e.get("event")=="CLOSE_CONFIRMED":
            rows.append({"trigger":"CLOSE_CONFIRMED","source_id":e.get("closure_id"),"wop_id":e.get("wop_id"),
                         "situation":"Project/case closed","root_cause":"","prevention":"","reuse_rule":"","evidence":e.get("evidence"),
                         "human_confirmation_required":True})
    rs=loadj(OUT/"reply_status.json",{})
    for thr,f in (rs.get("flags",{}) or {}).items():
        if (f or {}).get("risk"):
            rows.append({"trigger":"RISK_SIGNAL","source_id":thr,"wop_id":"","situation":"Risk-sentiment escalation detected",
                         "root_cause":"","prevention":"","reuse_rule":"","evidence":thr,"human_confirmation_required":True})
    doc={"version":"v0200","engine":"workops_lesson_learned","generated_at":now(),"items":rows}
    atomic_json(CAND,doc);return doc
def confirm(index,root_cause,prevention,reuse_rule=""):
    d=loadj(CAND,{"items":[]})
    if index<0 or index>=len(d["items"]): raise SystemExit("candidate index out of range")
    if not root_cause or not prevention: raise SystemExit("root cause and prevention required")
    x=d["items"][index]
    e={**x,"event":"LESSON_CONFIRMED","lesson_id":next_id("LLN"),"root_cause":root_cause,"prevention":prevention,
       "reuse_rule":reuse_rule,"ts":now(),"human_confirmed":True}
    append_jsonl(REG,e);return e
def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest="cmd",required=True);sub.add_parser("build")
    c=sub.add_parser("confirm");c.add_argument("index",type=int);c.add_argument("--root-cause",required=True);c.add_argument("--prevention",required=True);c.add_argument("--reuse-rule",default="")
    a=ap.parse_args();o=build() if a.cmd=="build" else confirm(a.index,a.root_cause,a.prevention,a.reuse_rule);print(json.dumps(o,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
