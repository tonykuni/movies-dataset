# -*- coding: utf-8 -*-
"""Run-local milestone manager for existing WOP IDs. No project renumbering."""
from __future__ import annotations
import argparse,json
from collections import defaultdict
from pathlib import Path
from workops_gapfill_common import *
REG=OUT/"milestone_events.jsonl"; SUMMARY=OUT/"milestone_summary.json"

def current():
    cur={}
    for e in loadjl(REG):
        mid=e.get("milestone_id")
        if not mid: continue
        x=cur.get(mid,{})
        typ=e.get("event")
        if typ=="CREATE": x.update(e)
        elif typ=="STATUS": x["status"]=e.get("status");x["status_reason"]=e.get("reason");x["updated_at"]=e.get("ts")
        elif typ=="TARGET": x["target_date"]=e.get("target_date");x["target_reason"]=e.get("reason");x["updated_at"]=e.get("ts")
        elif typ=="COMPLETE": x["status"]="COMPLETED";x["actual_date"]=e.get("actual_date");x["evidence"]=e.get("evidence");x["updated_at"]=e.get("ts")
        cur[mid]=x
    return cur
def build():
    by=defaultdict(list)
    for x in current().values(): by[x.get("wop_id","UNASSIGNED")].append(x)
    projects=[]
    for wop,ms in by.items():
        total=sum(float(x.get("weight") or 1) for x in ms)
        done=sum(float(x.get("weight") or 1) for x in ms if x.get("status")=="COMPLETED")
        projects.append({"wop_id":wop,"total":len(ms),"completed":sum(x.get("status")=="COMPLETED" for x in ms),
                         "weighted_progress_pct":round(100*done/max(1,total),1),"milestones":sorted(ms,key=lambda z:z.get("target_date") or "9999")})
    doc={"version":"v0200","engine":"workops_milestone_manager","generated_at":now(),"projects":projects}
    atomic_json(SUMMARY,doc);return doc
def create(wop_id,name,target_date,owner="",weight=1.0):
    if not str(wop_id).startswith("WOP-"): raise SystemExit("wop_id must be existing WOP-####")
    e={"event":"CREATE","milestone_id":next_id("MLS"),"wop_id":wop_id,"name":name,"target_date":target_date,
       "owner":owner,"weight":weight,"status":"OPEN","ts":now(),"human_confirmed":True}
    append_jsonl(REG,e);build();return e
def complete(mid,evidence,actual_date=""):
    if mid not in current(): raise SystemExit("unknown milestone")
    if not evidence: raise SystemExit("evidence required")
    e={"event":"COMPLETE","milestone_id":mid,"evidence":evidence,"actual_date":actual_date or now()[:10],"ts":now(),"human_confirmed":True}
    append_jsonl(REG,e);build();return e
def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest="cmd",required=True)
    sub.add_parser("build")
    c=sub.add_parser("create");c.add_argument("wop_id");c.add_argument("name");c.add_argument("target_date");c.add_argument("--owner",default="");c.add_argument("--weight",type=float,default=1)
    d=sub.add_parser("complete");d.add_argument("milestone_id");d.add_argument("--evidence",required=True);d.add_argument("--actual-date",default="")
    a=ap.parse_args()
    o=build() if a.cmd=="build" else create(a.wop_id,a.name,a.target_date,a.owner,a.weight) if a.cmd=="create" else complete(a.milestone_id,a.evidence,a.actual_date)
    print(json.dumps(o,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
