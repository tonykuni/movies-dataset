# -*- coding: utf-8 -*-
"""Run-local onboarding state + trilingual static UI generator."""
from __future__ import annotations
import argparse,json,html
from workops_gapfill_common import *
CFG=WORKOPS/"config"/"onboarding_steps.json";STATE=OUT/"onboarding_state.json";HTML=OUT/"WorkOps_Onboarding.html"
def status():
    steps=loadj(CFG,{}).get("steps",[]);st=loadj(STATE,{"completed":[]});done=set(st.get("completed",[]))
    return {"steps":[{**x,"completed":x["key"] in done} for x in steps],"completed":len(done),"total":len(steps),"ready":"READY" in done}
def complete(step):
    valid={x["key"] for x in loadj(CFG,{}).get("steps",[])}
    if step not in valid:raise SystemExit("unknown step")
    st=loadj(STATE,{"completed":[]});st["completed"]=list(dict.fromkeys(st.get("completed",[])+[step]));st["updated_at"]=now();atomic_json(STATE,st);return build()
def build():
    s=status();rows=[]
    for x in s["steps"]:
        rows.append(f"<div class='step {'done' if x['completed'] else ''}'><b>{html.escape(x['key'])}</b><span data-tw='{html.escape(x['zh-TW'])}' data-cn='{html.escape(x['zh-CN'])}' data-en='{html.escape(x['en'])}'>{html.escape(x['zh-TW'])}</span><em>{'✓' if x['completed'] else '○'}</em></div>")
    body="".join(rows)
    page=f"""<!doctype html><meta charset='utf-8'><title>WorkOps Onboarding</title>
<style>body{{font:14px Segoe UI,system-ui;background:#f5f3ee;color:#263238;max-width:900px;margin:30px auto}}header{{display:flex;justify-content:space-between}}button{{padding:7px 10px}}.step{{background:white;border:1px solid #ddd;padding:14px;margin:8px 0;border-radius:10px;display:grid;grid-template-columns:90px 1fr 30px}}.done{{border-left:5px solid #4C72B0}}</style>
<header><div><b>VERITAS WORKOPS</b><br>Onboarding</div><div><button onclick="lang('tw')">繁中</button><button onclick="lang('cn')">简中</button><button onclick="lang('en')">EN</button></div></header>
<p>State: {s['completed']}/{s['total']} · {'READY' if s['ready'] else 'IN PROGRESS'}</p>{body}
<script>function lang(k){{document.querySelectorAll('.step span').forEach(x=>x.textContent=x.dataset[k])}}</script>"""
    HTML.parent.mkdir(parents=True,exist_ok=True);HTML.write_text(page,encoding="utf-8")
    return s
def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest="cmd",required=True);sub.add_parser("build");sub.add_parser("status")
    c=sub.add_parser("complete");c.add_argument("step");sub.add_parser("reset");a=ap.parse_args()
    if a.cmd=="reset":
        if STATE.exists():STATE.unlink()
        o=build()
    elif a.cmd=="complete":o=complete(a.step)
    else:o=build() if a.cmd=="build" else status()
    print(json.dumps(o,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
