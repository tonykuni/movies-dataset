# -*- coding: utf-8 -*-
"""CPU-light search across WorkOps side-cars. Read-only."""
from __future__ import annotations
import argparse,json,csv,sqlite3
from pathlib import Path
from workops_gapfill_common import *
def rows_csv(p):
    try:
        with Path(p).open("r",encoding="utf-8-sig",errors="replace",newline="") as f:return list(csv.DictReader(f))
    except Exception:return []
def search(q,limit=50):
    q=q.strip().lower()
    if not q:return []
    sources=[
      ("WOP_REGISTRY",[loadj(OUT/"wop_registry.json",{})]),
      ("NAMING",[loadj(OUT/"workops_naming.json",{})]),
      ("REPLY",[loadj(OUT/"reply_status.json",{})]),
      ("MILESTONE",loadj(OUT/"milestone_summary.json",{"projects":[]}).get("projects",[])),
      ("CLOSURE",loadjl(OUT/"closure_events.jsonl")),
      ("LESSON",loadjl(OUT/"lesson_registry.jsonl")),
      ("DECISION",rows_csv(OUT/"decision_log.csv")),
      ("MAIL",rows_csv(OUT/"mails.csv"))
    ]
    out=[]
    for typ,rows in sources:
        for r in rows:
            text=json.dumps(r,ensure_ascii=False,default=str).lower()
            if q in text:
                exact=any(str(v).lower()==q for v in (r.values() if isinstance(r,dict) else []))
                out.append({"type":typ,"score":2 if exact else 1,"record":r})
    out.sort(key=lambda x:-x["score"])
    return out[:limit]
def main():
    ap=argparse.ArgumentParser();ap.add_argument("query");ap.add_argument("--limit",type=int,default=50);a=ap.parse_args()
    print(json.dumps({"query":a.query,"items":search(a.query,a.limit)},ensure_ascii=False,indent=2))
if __name__=="__main__":main()
