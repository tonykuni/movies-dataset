# -*- coding: utf-8 -*-
"""Closure candidates from existing WOP + reply + milestone + decision side-cars. Never auto-closes."""
from __future__ import annotations
import argparse,json,csv
from collections import defaultdict
from workops_gapfill_common import *
PARAM=WORKOPS/"config"/"closure_params.json"; CAND=OUT/"closure_candidates.json"; EV=OUT/"closure_events.jsonl"

def registry():
    d=loadj(OUT/"wop_registry.json",{})
    projects=d.get("projects",{})
    # projects may be dict keyed by WOP
    return projects if isinstance(projects,dict) else {x.get("wop_id"):x for x in projects if x.get("wop_id")}
def reply_status():
    d=loadj(OUT/"reply_status.json",{})
    return d.get("status",{}) if isinstance(d,dict) else {}
def thr2wop():
    d=loadj(OUT/"wop_registry.json",{})
    return d.get("thr2wop",{}) if isinstance(d,dict) else {}
def closed():
    return {e.get("wop_id") for e in loadjl(EV) if e.get("event")=="CLOSE_CONFIRMED" and e.get("wop_id")}
def open_decisions():
    rows=[]
    p=OUT/"decision_log.csv"
    if p.exists():
        with p.open("r",encoding="utf-8-sig",errors="replace",newline="") as f: rows=list(csv.DictReader(f))
    out=defaultdict(int)
    for r in rows:
        st=(r.get("Status") or r.get("status") or "").upper()
        if st not in ("DONE","COMPLETED","CLOSED","CANCELLED"):
            w=r.get("WOP") or r.get("wop_id")
            if w: out[w]+=1
    return out
def build():
    p=loadj(PARAM,{})
    proj=registry(); rstat=reply_status(); mapping=thr2wop(); done=closed(); decisions=open_decisions()
    ms=loadj(OUT/"milestone_summary.json",{"projects":[]})
    mp={x.get("wop_id"):x for x in ms.get("projects",[])}
    by=defaultdict(list)
    for thr,s in rstat.items():
        w=mapping.get(thr)
        if w: by[w].append((thr,s))
    items=[]
    for wop,meta in proj.items():
        if wop in done: continue
        statuses=[str((s or {}).get("status") or "") for _,s in by.get(wop,[])]
        any_done=any(x.upper() in {y.upper() for y in p["done_statuses"]} for x in statuses)
        any_block=any(x.upper() in {y.upper() for y in p["block_statuses"]} for x in statuses)
        m=mp.get(wop,{})
        milestones_ok=(m.get("total",0)==0 or m.get("completed",0)==m.get("total",0))
        open_dec=int(decisions.get(wop,0))
        evidence=""
        for _,s in reversed(by.get(wop,[])):
            evidence=(s or {}).get("evidence") or (s or {}).get("mail_id") or ""
            if evidence:break
        ready=bool(any_done and not any_block and milestones_ok and open_dec==0 and evidence)
        items.append({"wop_id":wop,"project_name":meta.get("display_name") or meta.get("name") or wop,
                      "reply_done_signal":any_done,"blocking_signal":any_block,"milestones_ready":milestones_ok,
                      "open_decisions":open_dec,"evidence":evidence,"ready_for_human_confirmation":ready,
                      "gate":"READY_TO_CONFIRM" if ready else "NOT_READY"})
    doc={"version":"v0200","engine":"workops_closure_intelligence","generated_at":now(),"items":items}
    atomic_json(CAND,doc);return doc
def confirm(wop,reason):
    p=loadj(PARAM,{})
    if reason not in p["allowed_reasons"]: raise SystemExit("invalid reason")
    d=loadj(CAND,{"items":[]});x=next((z for z in d["items"] if z.get("wop_id")==wop),None)
    if not x or not x.get("ready_for_human_confirmation"): raise SystemExit("closure not ready")
    if wop in closed(): return {"gate":"ALREADY_CLOSED","wop_id":wop}
    e={"event":"CLOSE_CONFIRMED","closure_id":next_id("CLS"),"wop_id":wop,"reason":reason,"evidence":x.get("evidence"),"ts":now(),"human_confirmed":True}
    append_jsonl(EV,e);return e
def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest="cmd",required=True);sub.add_parser("build")
    c=sub.add_parser("confirm");c.add_argument("wop_id");c.add_argument("--reason",required=True);a=ap.parse_args()
    o=build() if a.cmd=="build" else confirm(a.wop_id,a.reason);print(json.dumps(o,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
