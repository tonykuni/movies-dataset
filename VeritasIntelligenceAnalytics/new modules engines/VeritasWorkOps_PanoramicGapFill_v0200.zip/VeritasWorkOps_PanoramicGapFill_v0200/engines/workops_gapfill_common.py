# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, tempfile
from datetime import datetime
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORKOPS=HERE.parent
OUT=WORKOPS/"out"
LEDGER=OUT/"gapfill_id_ledger.json"

def loadj(p,d):
    try:return json.loads(Path(p).read_text(encoding="utf-8-sig"))
    except Exception:return d
def loadjl(p):
    rows=[]
    p=Path(p)
    if not p.exists(): return rows
    for ln in p.read_text(encoding="utf-8",errors="replace").splitlines():
        try: rows.append(json.loads(ln))
        except Exception: pass
    return rows
def atomic_json(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
    tmp.replace(p)
def append_jsonl(p,obj):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("a",encoding="utf-8") as f:f.write(json.dumps(obj,ensure_ascii=False)+"\n")
def now(): return datetime.now().astimezone().isoformat(timespec="seconds")
def next_id(prefix,width=4):
    state=loadj(LEDGER,{})
    key="seq_"+prefix.lower()
    n=int(state.get(key,0))+1
    state[key]=n
    atomic_json(LEDGER,state)
    return f"{prefix}-{n:0{width}d}"
