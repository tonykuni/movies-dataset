# -*- coding: utf-8 -*-
"""Append-only work dependency links + downstream impact + project timeline."""
from __future__ import annotations
import argparse,json,csv
from collections import defaultdict,deque
from workops_gapfill_common import *
LINK=OUT/"work_dependency_events.jsonl";IMPACT=OUT/"dependency_impact.json";TIMELINE=OUT/"project_timeline.json"
def link(parent,child,wop=""):
    e={"event":"LINK","parent":parent,"child":child,"wop_id":wop,"ts":now(),"human_confirmed":True};append_jsonl(LINK,e);return e
def build():
    edges=[];active=set()
    for e in loadjl(LINK):
        k=(e.get("parent"),e.get("child"))
        if e.get("event")=="LINK":active.add(k)
        elif e.get("event")=="UNLINK":active.discard(k)
    adj=defaultdict(list)
    for a,b in active:adj[a].append(b)
    # blocker sources from reply flags / milestone blocked status
    blocked=set()
    rs=loadj(OUT/"reply_status.json",{})
    for thr,s in (rs.get("status",{}) or {}).items():
        if str((s or {}).get("status","")).upper() in ("BLOCKED","卡關","需要協助","NEED_HELP"):blocked.add(thr)
    ms=loadj(OUT/"milestone_summary.json",{"projects":[]})
    for pr in ms.get("projects",[]):
        for m in pr.get("milestones",[]):
            if str(m.get("status","")).upper()=="BLOCKED":blocked.add(m.get("milestone_id"))
    impacts=[]
    for src in sorted(blocked):
        seen=set();q=deque(adj.get(src,[]))
        while q:
            x=q.popleft()
            if x in seen:continue
            seen.add(x);q.extend(adj.get(x,[]))
        impacts.append({"source":src,"downstream_count":len(seen),"downstream":sorted(seen)})
    atomic_json(IMPACT,{"version":"v0200","generated_at":now(),"items":impacts})
    # timeline from events
    by=defaultdict(list)
    wr=loadj(OUT/"wop_registry.json",{}).get("thr2wop",{})
    for e in loadjl(OUT/"reply_events.jsonl"):
        thr=e.get("thr") or e.get("thread_id");w=wr.get(thr)
        if w:by[w].append({"ts":e.get("mail_date") or e.get("ts"),"type":"REPLY","source":thr,"label":e.get("status")})
    for e in loadjl(OUT/"milestone_events.jsonl"):
        by[e.get("wop_id","UNASSIGNED")].append({"ts":e.get("ts"),"type":"MILESTONE_"+e.get("event",""),"source":e.get("milestone_id"),"label":e.get("name") or e.get("status")})
    for e in loadjl(OUT/"closure_events.jsonl"):
        by[e.get("wop_id","UNASSIGNED")].append({"ts":e.get("ts"),"type":"CLOSE","source":e.get("closure_id"),"label":e.get("reason")})
    projects=[]
    for w,evs in by.items():projects.append({"wop_id":w,"events":sorted(evs,key=lambda z:z.get("ts") or "")})
    atomic_json(TIMELINE,{"version":"v0200","generated_at":now(),"projects":projects})
    return {"dependency_sources":len(impacts),"timeline_projects":len(projects)}
def main():
    ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest="cmd",required=True);sub.add_parser("build")
    l=sub.add_parser("link");l.add_argument("parent");l.add_argument("child");l.add_argument("--wop",default="");a=ap.parse_args()
    o=build() if a.cmd=="build" else link(a.parent,a.child,a.wop);print(json.dumps(o,ensure_ascii=False,indent=2))
if __name__=="__main__":main()
