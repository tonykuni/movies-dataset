import json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
SRC=Path(__file__).resolve().parents[1]
def run(root,script,*args):
    env=os.environ.copy();env["PYTHONPATH"]=str(root/"engines")
    print("RUN",script,args,flush=True); r=subprocess.run([sys.executable,"-S",str(root/"engines"/script),*args],cwd=root,env=env,text=True,capture_output=True,timeout=10)
    assert r.returncode==0,(script,r.stdout,r.stderr)
    return json.loads(r.stdout)
def main():
    t=Path(tempfile.mkdtemp())/"w";shutil.copytree(SRC,t);out=t/"out";out.mkdir(exist_ok=True)
    (out/"wop_registry.json").write_text(json.dumps({"projects":{"WOP-0001":{"display_name":"India Transfer"}},"thr2wop":{"THR-00001":"WOP-0001"}}))
    (out/"reply_status.json").write_text(json.dumps({"status":{"THR-00001":{"status":"COMPLETED","evidence":"EML-001"}},"flags":{}}))
    (out/"decision_log.csv").write_text("WOP,Status\nWOP-0001,DONE\n",encoding="utf-8")
    m=run(t,"workops_milestone_manager.py","create","WOP-0001","DV Complete","2026-08-15","--owner","Tony")
    mid=m["milestone_id"];assert mid.startswith("MLS-")
    run(t,"workops_milestone_manager.py","complete",mid,"--evidence","EML-DV")
    c=run(t,"workops_closure_intelligence.py","build");x=next(z for z in c["items"] if z["wop_id"]=="WOP-0001");assert x["ready_for_human_confirmation"]
    cc=run(t,"workops_closure_intelligence.py","confirm","WOP-0001","--reason","DELIVERABLE_RECEIVED");assert cc["closure_id"].startswith("CLS-")
    l=run(t,"workops_lesson_learned.py","build");assert l["items"]
    lc=run(t,"workops_lesson_learned.py","confirm","0","--root-cause","Late fixture","--prevention","T-2 checkpoint");assert lc["lesson_id"].startswith("LLN-")
    s=run(t,"workops_unified_search.py","India");assert s["items"]
    o=run(t,"workops_onboarding.py","build");assert o["total"]==8
    d=run(t,"workops_timeline_dependency.py","build");assert d["timeline_projects"]>=1
    r=run(t,"workops_retention_manager.py","plan");assert r["gate"]=="REVIEW_REQUIRED"
    print(json.dumps({"gate":"PASS","milestone":mid,"closure":cc["closure_id"],"lesson":lc["lesson_id"],"onboarding_steps":o["total"]},ensure_ascii=False))
if __name__=="__main__":main()
