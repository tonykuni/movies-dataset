# ALL v0106 stage proposal — review only

Recommended insertion after existing `[2g]` board refresh, before final summary:

- `3a milestones build`
- `3b closure build`
- `3c lessons build`
- `3d dependency build`
- `3e retention plan`
- `3f onboarding build`

Do **not** run `retention apply`, `closure confirm`, or lesson confirmation automatically.
Unified search remains an on-demand verb and should not be in every ALL run.
