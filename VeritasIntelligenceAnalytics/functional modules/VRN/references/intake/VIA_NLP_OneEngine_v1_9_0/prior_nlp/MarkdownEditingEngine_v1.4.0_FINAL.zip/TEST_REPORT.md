# MarkdownEditingEngine v1.4.0 測試報告

日期：2026-09-12。環境：Linux、Python、Node.js。本報告取代 v1.3 的測試計數。

| 驗證 | 結果 | 範圍 |
| --- | --- | --- |
| Python unittest | 49 項：48 通過、1 略過 | 原有 34 項與新增 15 項防錯測試 |
| JavaScript UI 狀態測試 | 3/3 通過 | 改路徑清除確認、繞過 input 事件仍拒絕舊預覽、未執行階段標示 |
| JavaScript 語法 | 通過 | node --check ui/app.js |
| 真實 CLI 往返 | 通過 | fix → 第二次 unchanged → 還原 bytes 與原稿相同 |
| 本機 HTTP API | 通過 | health、capture、preview、restore；非法 Host／Origin／JSON 拒絕 |

合計自動測試 51 項通過、1 項略過、0 失敗；另有 CLI 往返與語法檢查。JS 使用 Node VM 與模擬 DOM，未完成真實瀏覽器視覺及互動驗收。

## 新增故障注入

- 重複快照無法覆寫第一次保存的原稿。
- 快照相對路徑穿越、絕對路徑、非法 schema、hash、size 被拒絕。
- 還原到快照 manifest／blob 自身被拒絕，即使 force 也不例外。
- Symlink 目標拒絕；目標原先不存在、預覽後卻出現新檔時拒絕覆蓋。
- 還原寫入暫存檔時修改目標：拒絕提交且清除暫存檔。
- 修復期間來源被其他程序修改：保留新內容並回報 failed。
- restore 的 force + dry-run 不寫回。
- 固定時鐘下產生 1,000 個 run ID 均不同。
- doctor／capture 沒有執行的驗證階段不顯示 passed。
- UI 原稿與候選預覽使用不同內容；不跨文件配對。
- API 拒絕字串布林值、不合範圍 workers 與非物件 JSON。

## 可重跑命令

```bash
python3 -m unittest discover -s tests -v
node --test tests/ui-state.test.mjs
node --check ui/app.js
```

## 已知限制與邊界

1. 略過項目為 markdown-it-py 解析堆疊，原因是本環境未安裝。沒有重跑全部第三方套件；Windows／PowerShell、Rust、Go、mdBook 亦未做動態驗收。
2. 原貌還原依靠保存的原始 bytes。若原始輸入已經缺字、錯誤合併、缺格，無法推斷不可見的原稿；仍應標記 REVIEW 並提供原始 HTML、PDF 或其他證據。
3. 原稿 hash 在提交前重查，可攔截已偵測的競爭修改；檔案系統沒有跨外部程序的通用 compare-and-swap，最後檢查到 replace 之間仍有很短的競爭窗口。不要讓多個編輯器同時寫入同一目標。
4. 快照防覆寫由應用程式執行，並非作業系統唯讀儲存或數位簽章；能同時修改 manifest 與 blob 的人仍能替換內容。
5. 函式盤點是名稱與靜態分類，不是呼叫圖、覆蓋率或全部第三方功能均通過的證明。階段 completed 也不等於每個外部 validator 均通過，應查逐工具結果。
6. BOM、換行與空白的精確回復由 original.bin 保證；行級 role 是輔助分類，不是原貌還原的資料來源。
7. 沒有新增第三方依賴；原有 adapters、固定依賴檔、多語言入口與 20+20 失敗因素目錄保留。
