#!/usr/bin/env python3
"""Local-only HTML phase console for MarkdownEditingEngine."""

from __future__ import annotations

import ast
import json
import mimetypes
import re
import secrets
import subprocess
import sys
import urllib.parse
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

try:
    from engine.appearance_reconstruction import (
        def_preview_appearance_restore,
        def_restore_appearance_snapshot,
    )
except ModuleNotFoundError:
    from appearance_reconstruction import (
        def_preview_appearance_restore,
        def_restore_appearance_snapshot,
    )


# =============================================================================
# 參數區：UI、API、安全限制與 Phase SSOT。
# =============================================================================

ENGINE_ROOT = Path(__file__).resolve().parent.parent
UI_ROOT = ENGINE_ROOT / "ui"
REPORT_ROOT = ENGINE_ROOT / "reports" / "ui"
ENGINE_SCRIPT = ENGINE_ROOT / "engine" / "markdown_engine.py"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 8765
MAX_REQUEST_BYTES = 1_000_000
MAX_PREVIEW_CHARACTERS = 200_000
ALLOWED_ACTIONS = {
    "doctor",
    "check",
    "analyze-structure",
    "capture-appearance",
    "fix",
    "reorganize",
    "build-book",
    "all",
}
ALLOWED_FORMATTERS = {"prettier", "mdformat", "rumdl", "pandoc", "none"}
PHASES = [
    {"id": "P01", "name": "Intake", "purpose": "讀取來源、UTF-8 與 SHA-256"},
    {"id": "P02", "name": "Original Lock", "purpose": "逐位元原檔與外觀帳本"},
    {"id": "P03", "name": "Protect", "purpose": "鎖定 code、HTML、URL 與 front matter"},
    {"id": "P04", "name": "Segment", "purpose": "區塊、句界、標題路徑與表格 shape"},
    {"id": "P05", "name": "Reconstruct", "purpose": "零猜接、零造字、零造格修復"},
    {"id": "P06", "name": "Validate", "purpose": "AST、句子、表格矩陣與多解析器守門"},
    {"id": "P07", "name": "Review / Restore", "purpose": "PASS／REVIEW／FAIL 與安全回復原貌"},
    {"id": "P08", "name": "Export", "purpose": "JSON、HTML、CSV、SSOT 與證據鏈"},
]
JAVASCRIPT_FUNCTION_PATTERN = re.compile(r"\bfunction\s+(def[A-Za-z0-9_]+)\s*\(")
POWERSHELL_FUNCTION_PATTERN = re.compile(r"^\s*function\s+(def[A-Za-z0-9_-]+)\b", re.MULTILINE | re.IGNORECASE)


def def_json_bytes(payload: Any) -> bytes:
    return (json.dumps(payload, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def def_assign_function_phase(name: str, relative_path: str) -> str:
    folded = f"{relative_path} {name}".casefold()
    if "appearance" in folded and any(term in folded for term in ("capture", "ledger", "snapshot", "split_lines")):
        return "P02"
    if any(term in folded for term in ("restore", "quarantine", "backup")):
        return "P07"
    if any(term in folded for term in ("classify", "sentence", "table", "information", "heading_context", "analyze")):
        return "P04"
    if any(term in folded for term in ("repair", "mutator", "normalize", "reorganize", "toc")):
        return "P05"
    if any(term in folded for term in ("validate", "verify", "signature", "compare", "guard", "assert")):
        return "P06"
    if any(term in folded for term in ("report", "csv", "html", "json", "write", "serve", "send", "render", "request")):
        return "P08"
    if any(term in folded for term in ("protect", "fence", "frontmatter", "no_touch")):
        return "P03"
    return "P01"


def def_function_inventory() -> dict[str, Any]:
    records: list[dict[str, str]] = []
    for path in sorted((ENGINE_ROOT / "engine").glob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("def_"):
                relative = path.relative_to(ENGINE_ROOT).as_posix()
                records.append({"language": "python", "file": relative, "name": node.name, "phase": def_assign_function_phase(node.name, relative)})
    for path in sorted((ENGINE_ROOT / "ui").glob("*.js")):
        relative = path.relative_to(ENGINE_ROOT).as_posix()
        for name in JAVASCRIPT_FUNCTION_PATTERN.findall(path.read_text(encoding="utf-8")):
            records.append({"language": "javascript", "file": relative, "name": name, "phase": def_assign_function_phase(name, relative)})
    for path in sorted(ENGINE_ROOT.glob("*.ps1")):
        relative = path.relative_to(ENGINE_ROOT).as_posix()
        for name in POWERSHELL_FUNCTION_PATTERN.findall(path.read_text(encoding="utf-8-sig")):
            records.append({"language": "powershell", "file": relative, "name": name, "phase": def_assign_function_phase(name, relative)})
    records.sort(key=lambda item: (item["phase"], item["language"], item["file"], item["name"].casefold()))
    phase_counts = {phase["id"]: sum(item["phase"] == phase["id"] for item in records) for phase in PHASES}
    language_counts = {language: sum(item["language"] == language for item in records) for language in sorted({item["language"] for item in records})}
    return {"summary": {"total": len(records), "phase_counts": phase_counts, "language_counts": language_counts}, "functions": records}


def def_safe_static_path(request_path: str) -> Path | None:
    relative = request_path.lstrip("/") or "index.html"
    candidate = (UI_ROOT / relative).resolve()
    try:
        candidate.relative_to(UI_ROOT.resolve())
    except ValueError:
        return None
    return candidate if candidate.is_file() else None


def def_first_markdown_file(input_path: Path) -> Path | None:
    if input_path.is_file():
        return input_path
    for suffix in ("*.md", "*.markdown", "*.mdown", "*.mkd"):
        candidate = next(iter(sorted(input_path.rglob(suffix))), None)
        if candidate:
            return candidate
    return None


def def_read_text_preview(path: Path | None) -> dict[str, Any] | None:
    if path is None or not path.is_file():
        return None
    data = path.read_bytes()
    text = data.decode("utf-8-sig", errors="replace")
    return {
        "path": str(path),
        "text": text[:MAX_PREVIEW_CHARACTERS],
        "truncated": len(text) > MAX_PREVIEW_CHARACTERS,
        "size_bytes": len(data),
    }


def def_original_preview_from_report(report: dict[str, Any]) -> dict[str, Any] | None:
    for item in report.get("files", [])[:1]:
        manifest_value = item.get("appearance_snapshot_path")
        if not manifest_value:
            continue
        manifest_path = Path(manifest_value)
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        blob_path = manifest_path.parent / manifest["original_blob"]
        preview = def_read_text_preview(blob_path)
        if preview:
            preview["path"] = manifest.get("source_path", str(blob_path))
            preview["appearance"] = manifest.get("appearance", {})
        return preview
    return None


def def_current_preview_from_report(report: dict[str, Any], input_path: Path | None) -> dict[str, Any] | None:
    for item in report.get("files", [])[:1]:
        candidate_value = item.get("candidate_path")
        if candidate_value:
            return def_read_text_preview(Path(candidate_value))
    return def_read_text_preview(def_first_markdown_file(input_path)) if input_path else None


def def_phase_results(report: dict[str, Any]) -> list[dict[str, Any]]:
    files = report.get("files", [])
    states = {phase["id"]: "not-run" for phase in PHASES}
    if files:
        states["P01"] = "completed"
    if any(item.get("appearance_snapshot_valid") for item in files):
        states["P02"] = "passed"
    if any(item.get("reconstruction_report_path") for item in files):
        states["P03"] = states["P04"] = "completed"
    if report.get("action") in {"fix", "reorganize", "all"} and files:
        states["P05"] = "completed" if not any(item.get("errors") for item in files) else "failed"
    if any(item.get("tool_results") for item in files):
        states["P06"] = "completed"
    gates = {item.get("reconstruction_source_gate") for item in files}
    if "FAIL" in gates:
        states["P07"] = "failed"
    elif "REVIEW" in gates:
        states["P07"] = "review"
    elif "PASS" in gates:
        states["P07"] = "passed"
    return [{**phase, "state": states[phase["id"]]} for phase in PHASES]


def def_run_engine_job(payload: dict[str, Any]) -> dict[str, Any]:
    for key in ("strict", "dry_run", "toc"):
        if key in payload and type(payload[key]) is not bool:
            raise ValueError(f"{key} must be a boolean")
    if "workers" in payload and (type(payload["workers"]) is not int or not 1 <= payload["workers"] <= 16):
        raise ValueError("workers must be an integer between 1 and 16")
    action = str(payload.get("action", "analyze-structure"))
    formatter = str(payload.get("formatter", "prettier"))
    if action not in ALLOWED_ACTIONS:
        raise ValueError("Unsupported UI action")
    if formatter not in ALLOWED_FORMATTERS:
        raise ValueError("Unsupported formatter")
    input_value = str(payload.get("input", "")).strip()
    if action != "doctor" and not input_value:
        raise ValueError("Input path is required")
    input_path = Path(input_value).expanduser().resolve() if input_value else None
    if input_path is not None and not input_path.exists():
        raise FileNotFoundError(input_path)
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    job_id = secrets.token_hex(8)
    report_path = REPORT_ROOT / f"job-{job_id}.json"
    command = [sys.executable, str(ENGINE_SCRIPT), action, "--report", str(report_path)]
    if input_path is not None:
        command.extend(["--input", str(input_path)])
    if action in {"fix", "reorganize", "all"}:
        command.extend(["--formatter", formatter])
    if bool(payload.get("strict", True)):
        command.append("--strict")
    if bool(payload.get("dry_run", True)) and action in {"fix", "reorganize", "all"}:
        command.append("--dry-run")
    if bool(payload.get("toc", False)):
        command.append("--toc")
    workers = max(1, min(int(payload.get("workers", 4)), 16))
    command.extend(["--workers", str(workers)])
    before_preview = def_read_text_preview(def_first_markdown_file(input_path)) if input_path else None
    completed = subprocess.run(
        command,
        cwd=str(ENGINE_ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
        timeout=3600,
        check=False,
    )
    if not report_path.is_file():
        raise RuntimeError(completed.stderr.strip() or "Engine did not produce a report")
    report = json.loads(report_path.read_text(encoding="utf-8"))
    preview_files = [item for item in report.get("files", []) if before_preview and item.get("path") == before_preview["path"]]
    preview_report = {"files": preview_files}
    current_preview = def_current_preview_from_report(preview_report, input_path)
    original_preview = def_original_preview_from_report(preview_report)
    return {
        "job_id": job_id,
        "exit_code": completed.returncode,
        "stdout": completed.stdout[-4000:],
        "stderr": completed.stderr[-4000:],
        "report_path": str(report_path),
        "report": report,
        "phases": def_phase_results(report),
        "function_inventory": def_function_inventory(),
        "preview": {"original": original_preview or before_preview, "current": current_preview},
    }


def def_create_handler(api_token: str) -> type[BaseHTTPRequestHandler]:
    class MarkdownEditingHandler(BaseHTTPRequestHandler):
        server_version = "MarkdownEditingEngineUI/1.3"

        def def_send_bytes(self, payload: bytes, content_type: str, status: int = HTTPStatus.OK) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'")
            self.end_headers()
            self.wfile.write(payload)

        def def_send_json(self, payload: Any, status: int = HTTPStatus.OK) -> None:
            self.def_send_bytes(def_json_bytes(payload), "application/json; charset=utf-8", status)

        def def_read_json(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > MAX_REQUEST_BYTES:
                raise ValueError("Invalid request size")
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            if not isinstance(payload, dict):
                raise ValueError("JSON object required")
            return payload

        def def_authorized(self) -> bool:
            return secrets.compare_digest(self.headers.get("X-MDE-Token", ""), api_token)

        def def_local_request(self) -> bool:
            authority = self.headers.get("Host", "")
            allowed = {f"127.0.0.1:{self.server.server_port}", f"localhost:{self.server.server_port}", f"[::1]:{self.server.server_port}"}
            origin = self.headers.get("Origin")
            return authority in allowed and (origin is None or origin == f"http://{authority}")

        def do_GET(self) -> None:
            if not self.def_local_request():
                self.def_send_json({"error": "invalid_host_or_origin"}, HTTPStatus.FORBIDDEN)
                return
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path == "/api/health":
                self.def_send_json({"ok": True, "version": "1.4.0", "bind": "loopback"})
                return
            if parsed.path == "/api/config":
                self.def_send_json({"token": api_token, "phases": PHASES, "function_inventory": def_function_inventory(), "defaults": {"strict": True, "dry_run": True, "workers": 4}})
                return
            if parsed.path == "/api/inventory":
                self.def_send_json({"function_inventory": def_function_inventory()})
                return
            static_path = def_safe_static_path(parsed.path)
            if static_path is None:
                self.def_send_json({"error": "not_found"}, HTTPStatus.NOT_FOUND)
                return
            content_type = mimetypes.guess_type(static_path.name)[0] or "application/octet-stream"
            self.def_send_bytes(static_path.read_bytes(), f"{content_type}; charset=utf-8" if content_type.startswith("text/") else content_type)

        def do_POST(self) -> None:
            if not self.def_local_request() or not self.def_authorized():
                self.def_send_json({"error": "unauthorized"}, HTTPStatus.FORBIDDEN)
                return
            try:
                payload = self.def_read_json()
                if self.path == "/api/run":
                    result = def_run_engine_job(payload)
                elif self.path == "/api/restore-preview":
                    result = def_preview_appearance_restore(
                        Path(payload["manifest"]).expanduser().resolve(),
                        Path(payload["destination"]).expanduser().absolute(),
                    )
                elif self.path == "/api/restore":
                    if payload.get("confirmation") != "RESTORE ORIGINAL":
                        raise ValueError("Restore confirmation is required")
                    result = def_restore_appearance_snapshot(
                        Path(payload["manifest"]).expanduser().resolve(),
                        Path(payload["destination"]).expanduser().absolute(),
                        expected_current_sha256=payload.get("expected_current_sha256"),
                        force=False,
                    )
                else:
                    self.def_send_json({"error": "not_found"}, HTTPStatus.NOT_FOUND)
                    return
                self.def_send_json({"ok": True, "result": result})
            except (OSError, KeyError, TypeError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
                self.def_send_json({"ok": False, "error": f"{type(error).__name__}: {error}"}, HTTPStatus.BAD_REQUEST)

        def log_message(self, format_string: str, *args: Any) -> None:
            sys.stderr.write(f"[MDE-UI] {self.address_string()} {format_string % args}\n")

    return MarkdownEditingHandler


def def_serve_ui(host: str = DEFAULT_HOST, port: int = DEFAULT_PORT, open_browser: bool = True) -> int:
    if host not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError("UI server only permits loopback binding")
    if not 1 <= int(port) <= 65535:
        raise ValueError("Port must be between 1 and 65535")
    token = secrets.token_urlsafe(32)
    server = ThreadingHTTPServer((host, int(port)), def_create_handler(token))
    url = f"http://{host}:{port}/"
    print(f"MarkdownEditingEngine UI: {url}")
    if open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0
