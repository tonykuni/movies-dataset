@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File ".\MarkdownEditingEngine.ps1" serve-ui -WaitForKey
set "MDE_EXIT=%ERRORLEVEL%"
if not "%MDE_EXIT%"=="0" pause
exit /b %MDE_EXIT%
