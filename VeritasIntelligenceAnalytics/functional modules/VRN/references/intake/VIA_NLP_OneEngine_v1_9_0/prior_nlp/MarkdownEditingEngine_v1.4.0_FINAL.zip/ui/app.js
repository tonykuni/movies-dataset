"use strict";

// =============================================================================
// 參數區：UI 狀態與固定顯示欄位。
// =============================================================================

const API_CONFIG = "/api/config";
const API_RUN = "/api/run";
const API_RESTORE_PREVIEW = "/api/restore-preview";
const API_RESTORE = "/api/restore";
const DEFAULT_PHASE_STATE = "not-run";
let apiToken = "";
let restorePreview = null;

function defElement(id) {
  return document.getElementById(id);
}

function defEscape(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function defRequest(path, payload = null) {
  const options = payload
    ? { method: "POST", headers: { "Content-Type": "application/json", "X-MDE-Token": apiToken }, body: JSON.stringify(payload) }
    : { method: "GET" };
  const response = await fetch(path, options);
  const body = await response.json();
  if (!response.ok || body.ok === false) throw new Error(body.error || `HTTP ${response.status}`);
  return body;
}

function defRenderPhases(phases, inventory = {}) {
  const phaseCounts = inventory.summary?.phase_counts || {};
  defElement("phase-grid").innerHTML = phases.map((phase) => `
    <article class="phase ${defEscape(phase.state || DEFAULT_PHASE_STATE)}">
      <em>${defEscape(phase.id)} · ${Number(phaseCounts[phase.id] || 0)} functions</em><strong>${defEscape(phase.name)} · ${defEscape(phase.state || DEFAULT_PHASE_STATE)}</strong><p>${defEscape(phase.purpose)}</p>
    </article>`).join("");
}

function defRenderMetrics(summary = {}) {
  const fields = ["functions", "files", "changed", "captured", "appearance_snapshots", "reconstruction_pass", "failed"];
  defElement("metrics").innerHTML = fields.map((field) => `<article class="metric"><span>${defEscape(field)}</span><strong>${Number(summary[field] || 0)}</strong></article>`).join("");
}

function defStatusClass(value) {
  const text = String(value || "").toLowerCase();
  if (text.includes("fail")) return "status-fail";
  if (text.includes("review") || text.includes("warning")) return "status-review";
  return "status-pass";
}

function defRenderResults(files = []) {
  defElement("result-body").innerHTML = files.length ? files.map((item) => {
    const messages = [...(item.warnings || []), ...(item.errors || [])].join("; ") || "—";
    const snapshot = item.appearance_snapshot_valid ? item.appearance_snapshot_path : (item.candidate_path ? `candidate: ${item.candidate_path}` : "—");
    return `<tr><td>${defEscape(item.path)}</td><td class="${defStatusClass(item.status)}">${defEscape(item.status)}</td><td>${defEscape(item.semantic_guard)}</td><td class="${defStatusClass(item.reconstruction_source_gate)}">${defEscape(item.reconstruction_source_gate)}</td><td>${defEscape(item.reconstruction_confidence)}</td><td>${defEscape(snapshot)}</td><td>${defEscape(messages)}</td></tr>`;
  }).join("") : '<tr><td colspan="7">尚無結果</td></tr>';
}

function defRenderPreview(preview = {}) {
  const original = preview.original || {};
  const current = preview.current || {};
  defElement("original-preview").textContent = original.text || "—";
  defElement("current-preview").textContent = current.text || "—";
  defElement("original-meta").textContent = original.path ? `${original.path} · ${original.size_bytes} bytes` : "尚未載入";
  defElement("current-meta").textContent = current.path ? `${current.path} · ${current.size_bytes} bytes` : "尚未載入";
}

async function defRun() {
  const button = defElement("run-button");
  button.disabled = true;
  defElement("job-status").textContent = "執行中…";
  try {
    const body = await defRequest(API_RUN, {
      input: defElement("input-path").value,
      action: defElement("action").value,
      formatter: defElement("formatter").value,
      workers: Number(defElement("workers").value),
      strict: defElement("strict").checked,
      dry_run: defElement("dry-run").checked,
      toc: defElement("toc").checked,
    });
    const result = body.result;
    defRenderPhases(result.phases, result.function_inventory);
    defRenderMetrics({ ...result.report.summary, functions: result.function_inventory.summary.total });
    defRenderResults(result.report.files);
    defRenderPreview(result.preview);
    const snapshot = result.report.files.find((item) => item.appearance_snapshot_path);
    defInvalidateRestore();
    if (snapshot) {
      defElement("restore-manifest").value = snapshot.appearance_snapshot_path;
      defElement("restore-destination").value = snapshot.path;
    }
    defElement("job-status").textContent = `完成 · exit ${result.exit_code} · ${result.report_path}`;
  } catch (error) {
    defElement("job-status").textContent = `失敗：${error.message}`;
  } finally {
    button.disabled = false;
  }
}

async function defPreviewRestore() {
  try {
    defInvalidateRestore();
    const binding = {manifest: defElement("restore-manifest").value, destination: defElement("restore-destination").value};
    const body = await defRequest(API_RESTORE_PREVIEW, binding);
    if (binding.manifest !== defElement("restore-manifest").value || binding.destination !== defElement("restore-destination").value) throw new Error("路徑已變更，請重新預覽");
    restorePreview = {...body.result, binding};
    defElement("restore-sha").value = restorePreview.current_sha256 || "";
    defElement("restore-status").textContent = restorePreview.snapshot_valid ? `快照有效；${restorePreview.would_change ? "將變更" : "目前已是原貌"}` : "快照無效";
    defElement("restore-button").disabled = !restorePreview.snapshot_valid || !restorePreview.would_change;
  } catch (error) {
    restorePreview = null;
    defElement("restore-button").disabled = true;
    defElement("restore-status").textContent = `預覽失敗：${error.message}`;
  }
}

function defInvalidateRestore() {
  restorePreview = null;
  defElement("restore-button").disabled = true;
  defElement("restore-sha").value = "";
  defElement("restore-confirmation").value = "";
}

async function defRestore() {
  try {
    if (!restorePreview || restorePreview.binding.manifest !== defElement("restore-manifest").value || restorePreview.binding.destination !== defElement("restore-destination").value) throw new Error("請重新預覽還原");
    defElement("restore-button").disabled = true;
    const body = await defRequest(API_RESTORE, {
      manifest: defElement("restore-manifest").value,
      destination: defElement("restore-destination").value,
      expected_current_sha256: restorePreview?.current_sha256,
      confirmation: defElement("restore-confirmation").value,
    });
    defElement("restore-status").textContent = body.result.exact_match ? "已精確回復原始外觀" : "還原雜湊不一致";
    defElement("restore-button").disabled = true;
  } catch (error) {
    defElement("restore-status").textContent = `還原失敗：${error.message}`;
  }
}

async function defInitialize() {
  try {
    const config = await defRequest(API_CONFIG);
    apiToken = config.token;
    defRenderPhases(config.phases, config.function_inventory);
    defRenderMetrics({ functions: config.function_inventory.summary.total });
    defElement("health-dot").style.background = "#36b59f";
    defElement("health-text").textContent = "LOCAL READY";
  } catch (error) {
    defElement("health-text").textContent = `OFFLINE · ${error.message}`;
  }
}

defElement("run-button").addEventListener("click", defRun);
defElement("preview-restore").addEventListener("click", defPreviewRestore);
defElement("restore-button").addEventListener("click", defRestore);
["restore-manifest", "restore-destination"].forEach((id) => defElement(id).addEventListener("input", defInvalidateRestore));
defInitialize();
