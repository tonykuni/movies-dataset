"""v1.4 regression tests: preserve originals under failure and stale state."""
import json
import subprocess
import sys
import tempfile
import threading
import unittest
import urllib.request
import urllib.error
from pathlib import Path
from unittest import mock
from engine import appearance_reconstruction as A
from engine import ui_server as U
from engine import markdown_engine as M

ROOT = Path(__file__).resolve().parents[1]

class UpgradeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'source.md'
        self.source.write_bytes(b'# Original\r\n\r\nText  \r\n')
        self.snapshot = A.def_capture_appearance(self.source, self.root/'snapshots', Path('source.md'))
        self.manifest = Path(self.snapshot['manifest_path'])

    def test_repeated_capture_cannot_overwrite_original(self):
        self.source.write_text('changed')
        with self.assertRaises(FileExistsError):
            A.def_capture_appearance(self.source, self.root/'snapshots', Path('source.md'))
        self.assertTrue(A.def_verify_appearance_snapshot(self.manifest)['valid'])
        self.assertEqual(Path(self.snapshot['blob_path']).read_bytes(), b'# Original\r\n\r\nText  \r\n')

    def test_snapshot_traversal_rejected(self):
        for path in (Path('../escape.md'), Path('/absolute.md')):
            with self.subTest(path=path), self.assertRaises(ValueError):
                A.def_capture_appearance(self.source, self.root/'snapshots', path)

    def test_malformed_manifests_rejected(self):
        original = json.loads(self.manifest.read_text())
        for field, value in [('original_blob','../../source.md'),('original_blob',str(self.source)),('source_size_bytes',True),('source_sha256','oops'),('schema_version','9')]:
            self.manifest.write_text(json.dumps({**original,field:value}))
            with self.subTest(field=field,value=value), self.assertRaises(ValueError):
                A.def_verify_appearance_snapshot(self.manifest)

    def test_snapshot_self_overwrite_rejected_even_force(self):
        for target in [self.manifest, Path(self.snapshot['blob_path'])]:
            with self.subTest(target=target), self.assertRaises(ValueError):
                A.def_restore_appearance_snapshot(self.manifest,target,force=True)
        self.assertTrue(A.def_verify_appearance_snapshot(self.manifest)['valid'])

    def test_destination_symlink_rejected(self):
        link = self.root/'link.md'
        link.symlink_to(self.source)
        with self.assertRaises(ValueError):
            A.def_restore_appearance_snapshot(self.manifest,link,force=True)

    def test_missing_destination_preview_detects_new_file(self):
        destination = self.root/'new.md'
        preview = A.def_preview_appearance_restore(self.manifest,destination)
        self.assertEqual(preview['current_sha256'],'MISSING')
        destination.write_text('new user work')
        with self.assertRaises(ValueError):
            A.def_restore_appearance_snapshot(self.manifest,destination,preview['current_sha256'])
        self.assertEqual(destination.read_text(),'new user work')

    def test_missing_destination_can_be_restored_explicitly(self):
        target = self.root/'new.md'
        result = A.def_restore_appearance_snapshot(self.manifest,target,'MISSING')
        self.assertTrue(result['exact_match'])
        self.assertEqual(target.read_bytes(),self.source.read_bytes())

    def test_concurrent_edit_during_restore_rejected_and_temp_removed(self):
        real_fsync = A.os.fsync
        def edit_then_sync(fd):
            self.source.write_text('concurrent edit')
            real_fsync(fd)
        with mock.patch.object(A.os,'fsync',side_effect=edit_then_sync), self.assertRaises(ValueError):
            A.def_restore_appearance_snapshot(self.manifest,self.source,self.snapshot['source_sha256'])
        self.assertEqual(self.source.read_text(),'concurrent edit')
        self.assertEqual(list(self.root.glob('.*.restore-*')),[])

    def test_dry_run_restore_never_writes_even_force(self):
        self.source.write_text('keep this')
        proc = subprocess.run([sys.executable,str(ROOT/'engine/markdown_engine.py'),'restore-appearance','--input',str(self.manifest),'--restore-destination',str(self.source),'--force','--dry-run'],capture_output=True,text=True)
        self.assertEqual(proc.returncode,0,proc.stderr)
        self.assertFalse(json.loads(proc.stdout)['restored'])
        self.assertEqual(self.source.read_text(),'keep this')

    def test_run_ids_unique_under_fixed_clock(self):
        with mock.patch.object(M.dt,'datetime') as clock:
            clock.now.return_value.strftime.return_value = 'fixed-time'
            ids = {M.def_now_run_id() for _ in range(1000)}
        self.assertEqual(len(ids),1000)

    def test_unexecuted_phases_not_reported_passed(self):
        for action in ('doctor','capture-appearance'):
            result=U.def_phase_results({'action':action,'files':[]})
            self.assertTrue(all(row['state']=='not-run' for row in result))
        phases={row['id']:row['state'] for row in U.def_phase_results({'action':'capture-appearance','files':[{'appearance_snapshot_valid':True}]})}
        self.assertEqual(phases['P02'],'passed')
        self.assertEqual(phases['P06'],'not-run')

    def test_ui_rejects_wrong_parameter_types(self):
        for payload in ({'strict':'false'},{'workers':True},{'workers':0},{'dry_run':[]},{'toc':1}):
            with self.subTest(payload=payload), self.assertRaises(ValueError):
                U.def_run_engine_job(payload)

    def test_ui_dry_run_original_and_candidate_are_distinct(self):
        candidate=self.root/'candidate.md';candidate.write_text('# Candidate\n')
        def fake_run(command,**kwargs):
            report_path=Path(command[command.index('--report')+1])
            report_path.write_text(json.dumps({'action':'fix','dry_run':True,'files':[{'path':str(self.source),'candidate_path':str(candidate)}]}))
            return subprocess.CompletedProcess(command,0,'','')
        with mock.patch.object(U,'REPORT_ROOT',self.root/'reports'),mock.patch.object(U.subprocess,'run',side_effect=fake_run):
            result=U.def_run_engine_job({'input':str(self.source),'action':'fix'})
        self.assertIn('Original',result['preview']['original']['text'])
        self.assertIn('Candidate',result['preview']['current']['text'])

    def test_source_edit_during_processing_is_not_overwritten(self):
        config=json.loads((ROOT/'tests/fixtures/offline_engine.json').read_text())
        def mutate(staged,*args,**kwargs):
            staged.write_text('# Original\n\nText  \n')
            self.source.write_text('new user edit')
            return []
        with mock.patch.object(M,'def_apply_mutators',side_effect=mutate):
            result=M.def_process_file(source=self.source,input_root=self.source,action='fix',formatter='none',add_toc=False,dry_run=False,strict=True,config=config,registry=M.def_tool_registry(),backup_root=self.root/'backup',quarantine_root=self.root/'quarantine',timeout_seconds=10,appearance_root=self.root/'appearance')
        self.assertEqual(result.status,'failed')
        self.assertIn('Source changed', ' '.join(result.errors))
        self.assertEqual(self.source.read_text(),'new user edit')

    def test_http_rejects_foreign_host_origin_and_json_array(self):
        server=U.ThreadingHTTPServer(('127.0.0.1',0),U.def_create_handler('test-token'))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            for path,headers,data,status in [('/api/config',{'Host':'evil.example'},None,403),('/api/config',{'Origin':'https://evil.example'},None,403),('/api/run',{'X-MDE-Token':'test-token'},b'[]',400)]:
                request=urllib.request.Request(f'http://127.0.0.1:{server.server_port}'+path,headers=headers,data=data)
                with self.subTest(path=path,headers=headers),self.assertRaises(urllib.error.HTTPError) as error:
                    urllib.request.urlopen(request)
                self.assertEqual(error.exception.code,status)
        finally:
            server.shutdown();server.server_close();thread.join()

if __name__=='__main__':
    unittest.main()
