# HTML Phaser UI 與原貌重建規格

## 設計目標

文字修正與「回到原來外觀」是兩個不同問題。修正流程可以統一 Markdown 語法，但不能用整理後的文字猜回原始 BOM、換行、縮排、空白或行序。v1.3 因此保留三條互不覆蓋的 worldline：

| Worldline | 內容 | 是否可改 |
| --- | --- | --- |
| Original | `original.bin`，進入引擎時的逐位元原檔 | 永不改寫 |
| Candidate | dry-run 或暫存修復結果 | 可丟棄、不可直接當原文 |
| Accepted | 全部守門通過後的正式文件 | 原子替換，可由 Original 還原 |

## P01–P08 Phaser

| Phase | 功能 | 必要證據 | 失敗處置 |
| --- | --- | --- | --- |
| P01 Intake | 路徑、編碼、大小、SHA-256 | source path＋hash | 停止 |
| P02 Original Lock | 保存 bytes 與 line-style ledger | original.bin＋manifest | 禁止寫回 |
| P03 Protect | 鎖定 front matter、code、HTML、URL | no-touch ranges | REVIEW／FAIL |
| P04 Segment | 區塊、句界、標題路徑、表格 shape | stable IDs＋source lines | REVIEW |
| P05 Reconstruct | 安全空白、delimiter、TOC 與 formatter | zero merge／zero fabrication | quarantine |
| P06 Validate | AST、句子、表格矩陣、多解析器 | before/after signatures | FAIL |
| P07 Review / Restore | 審核或精確還原 | snapshot hash＋current hash | 衝突即拒絕 |
| P08 Export | HTML／JSON／CSV／SSOT／hash chain | artifacts manifest | 保留報告 |

## Original Appearance Manifest

每個 manifest 記錄：

- 原檔 SHA-256 與 bytes 大小。
- UTF-8 BOM 是否存在及解碼替代字數。
- CRLF、LF、CR 各自數量、主要換行及最後一行是否換行。
- 每行的角色、內容雜湊、前導空白、尾端空白、換行形式及字元長度。
- 原始 blob 相對位置與還原政策。

真正的內容保存在 `original.bin`，line ledger 是檢查與 UI 顯示證據，不用來重新拼出原文。這避免 ledger 程式日後改版時產生近似還原。

## 安全還原協議

1. 驗證 manifest、blob 大小及 SHA-256。
2. Preview 讀取目標檔目前 SHA-256，但不寫入。
3. 使用者輸入 `RESTORE ORIGINAL`。
4. API 必須收到 Preview 的 current SHA-256。
5. 若目標檔在 Preview 後變動，拒絕還原。
6. 將原始 blob 寫入同目錄暫存檔、同步磁碟，再原子替換。
7. 重新計算 SHA-256，必須與 snapshot 完全相同。

## HTML UI 功能

- 本機路徑、動作、formatter、1–16 workers、strict、dry-run、TOC 控制。
- 八階段狀態卡及每階段實際 `def` 函式數。
- 檔案數、修改數、快照數、重建 PASS、FAIL 等即時摘要。
- Original 與 Candidate／Current 的等寬字型並排預覽。
- 逐檔語意守門、重建守門、信心、snapshot 與錯誤矩陣。
- Capture、Restore Preview、current-hash lock、確認文字及精確 Restore。
- Doctor、Check、Analyze、Capture、Fix、Reorganize、All、Build Book 全入口。

## 安全邊界

- UI 只允許 `127.0.0.1`、`localhost` 或 `::1`，不提供區網公開模式。
- 寫入 API 需要隨伺服器啟動產生的 session token。
- 靜態檔案解析後必須仍位於 `ui/`，阻擋 `../` 路徑穿越。
- 使用固定 action／formatter 白名單及 argument list，不使用 shell command 字串。
- 預設 strict＋dry-run；Restore 不接受無預覽、無 hash 或確認文字錯誤。
- UI 預覽上限為 200,000 字元；完整內容仍保留在 snapshot 與報告。

## Word／PDF 原版面限制

本引擎可 100% 回復進入系統時的 Markdown／TXT bytes。若輸入只剩抽取後文字，原始 Word／PDF 的字型、字級、圖片、頁碼、欄位與 BBox 已不在文字中，任何工具都不能可靠猜回。要支援文件級原版面，前一個轉換引擎必須一併保存：

- 原始 DOCX／PDF；
- page、BBox、reading order；
- font family、size、weight、color；
- paragraph／table／figure IDs；
- 圖片與 caption 關聯；
- layout sidecar 的 SHA-256。

這些證據到齊後，才能在未來版本增加 DOCX／PDF renderer；沒有證據時維持 REVIEW，絕不假造原版面。

## v1.4 還原協定補充

目標不存在時 preview 回傳 `current_sha256: "MISSING"`，還原必須帶同一個值。已存在的目標必須帶目前 hash。CLI `--force` 可省略預期 hash，但不略過快照驗證、路徑限制或寫入期間變動检查；`--dry-run` 始終只預覽還原。

同一快照目錄不允許再次 capture，請使用新的 run ID／目錄。UI 更換快照或目標時清除確認，需重新預覽。P01–P08 面板反映取得的執行證據；`not-run`、`completed`、`passed`、`review` 與 `failed` 不可互換。函式數僅為靜態分類盤點。
