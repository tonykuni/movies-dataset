import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs';

const source = fs.readFileSync(new URL('../ui/app.js', import.meta.url), 'utf8');
function defHarness() {
  const elements = new Map();
  const document = {getElementById(id) {
    if (!elements.has(id)) elements.set(id, {value:'',disabled:false,textContent:'',innerHTML:'',style:{},listeners:{},addEventListener(event,fn){this.listeners[event]=fn;}});
    return elements.get(id);
  }};
  const calls=[];
  const context=vm.createContext({document,fetch:async(path,options)=>{
    calls.push({path,options});
    return {ok:true,json:async()=>path==='/api/config'?{token:'test',phases:[],function_inventory:{summary:{total:0}}}:{result:{snapshot_valid:true,would_change:true,current_sha256:'MISSING'}}};
  }});
  vm.runInContext(source,context);
  document.getElementById('restore-manifest').value='snapshot.json';
  document.getElementById('restore-destination').value='source.md';
  return {context,document,calls};
}

test('editing a path clears preview, hash and confirmation',async()=>{
  const {context,document}=defHarness();
  await vm.runInContext('defPreviewRestore()',context);
  assert.equal(document.getElementById('restore-button').disabled,false);
  document.getElementById('restore-confirmation').value='RESTORE ORIGINAL';
  document.getElementById('restore-destination').listeners.input();
  assert.equal(document.getElementById('restore-button').disabled,true);
  assert.equal(document.getElementById('restore-sha').value,'');
  assert.equal(document.getElementById('restore-confirmation').value,'');
});

test('changed path blocks restore even without DOM input event',async()=>{
  const {context,document,calls}=defHarness();
  await vm.runInContext('defPreviewRestore()',context);
  document.getElementById('restore-destination').value='different.md';
  await vm.runInContext('defRestore()',context);
  assert.equal(calls.filter(c=>c.path==='/api/restore').length,0);
  assert.match(document.getElementById('restore-status').textContent,/重新預覽/);
});

test('phase output displays not-run instead of implicit success',()=>{
  const {context,document}=defHarness();
  vm.runInContext('defRenderPhases([{id:"P06",name:"Validate",purpose:"test",state:"not-run"}])',context);
  assert.match(document.getElementById('phase-grid').innerHTML,/Validate · not-run/);
});
