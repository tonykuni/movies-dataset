#!/bin/bash
# 使用者機器情境:Downloads 是 v0133 啟動器(上次跑的)· 發行 v0133 放在 GitHub 分支 · 貼「一行」(-EncodedCommand)→ ③ 下載 v0133 · 雜湊核對 · ④ ①~⑫ · ⑤ 摘要
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v134; T=$W/t134oc
OCRPY=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/bin/python
OCRBR=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/VRN2_OCRBridge_v0100.py
cd /tmp && $S/tools/mktree.sh $T /tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v133/ActivateVRN-2_v0133.py > $W/scen_setup.log 2>&1
B=$T.br; rm -rf $B; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0134; mkdir -p $D
cp $W/release134/ActivateVRN-2_v0134.zip $W/release134/VRN2_Release_v0134.json $W/release134/VRN2_OneClick_v0134.md $D/
cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1
B64=$(cut -d' ' -f6 $W/release134/oneline134.txt)
cd "$T/Downloads" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VIA_VRN_INPUT="$T/samples" VRN2_SOURCE="$T/samples" VIA_ENVS_HOME="$T/envs" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$OCRBR" PYTHONDONTWRITEBYTECODE=1 \
  VRN2_ROOT="$T/VIA" VRN2_LAUNCHER="$T/Downloads/ActivateVRN-2.py" VRN2_PY="$S/venv_vrn2/bin/python" VRN2_LAUNCHER_ARGS="--no-install" VIA_VRN1_ROOT=/home/user/via-vdf-vrn \
  timeout 3500 "$S/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -EncodedCommand "$B64" > $W/scen_oneclick.log 2>&1
echo "rc $?" > $W/scen.rc
sed -i 's/\x1b\[[0-9;]*m//g' $W/scen_oneclick.log
