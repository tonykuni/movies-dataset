"""一鍵 v0134:Run-VRN2-v0134.ps1(= v0133 最終版換版號 · $Want = 啟動器 v0134 SHA-256)+ VRN2_OneClick_v0134.md + boot134.ps1 + oneline134.txt(冪等)。
用法:python oneclick134.py <ActivateVRN-2 v0134 SHA-256> <輸出夾>"""
import base64, hashlib, re, sys
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v133/release133/")
want, out = sys.argv[1], Path(sys.argv[2]); assert re.fullmatch(r"[0-9a-f]{64}", want); out.mkdir(parents=True, exist_ok=True)
ps = (W / "Run-VRN2-v0133.ps1").read_text(encoding="utf-8").rstrip("\n")
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); ps = ps.replace(old_want, want)
n = ps.count("v0133"); ps = ps.replace("v0133", "v0134")
n2 = ps.count("VRN2_UIAction_v0103"); assert n2 >= 3, n2; ps = ps.replace("VRN2_UIAction_v0103", "VRN2_UIAction_v0104")   # 啟動器 v0134 註冊的是處理器 v0104 → ⑤b 要認 v0104
ps = ps.replace("指向 v0103", "指向 v0104")
def rep(a, b):
    global ps; assert ps.count(a) == 1, (ps.count(a), a[:80]); ps = ps.replace(a, b)
rep("# ===== VRN-2 一鍵 v0134(啟動器 v0134 · 前後端連結:", "# ===== VRN-2 一鍵 v0134(啟動器 v0134 整合一支:處理器 v0104 · 驗證器 v0103 · U/I 開不開只認 VRN2_NO_UI · ⑨ 交接不回退;一鍵的 ⑤b / ⑤c 留著當備援 · v0133 前後端連結:")
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = (W / "boot133.ps1").read_text(encoding="utf-8")
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1); boot = boot.replace(h_old, cs).replace("v0133", "v0134")
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
md = (W / "VRN2_OneClick_v0133.md").read_text(encoding="utf-8")
old_code = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); old_boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); old_one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
md = md.replace(old_code, "@PS@").replace(old_boot, "@BOOT@").replace(old_one, "@ONE@")
md = re.sub(r"[0-9a-f]{64}", want, md, count=1)
md = md.replace("v0133", "v0134").replace("VRN2_UIAction_v0103", "VRN2_UIAction_v0104").replace("處理器 v0103", "處理器 v0104")
md = md.replace("# VRN-2 一鍵 v0134(cmd / PowerShell 都能貼 · 啟動器 v0134 · 前後端連結 · U/I 用 window I/O 選輸入)",
                "# VRN-2 一鍵 v0134(cmd / PowerShell 都能貼 · 啟動器 v0134 整合一支:處理器 v0104 · 驗證器 v0103 · U/I 自己跳出 · ⑨ 交接不回退)")
md = re.sub(r"程式碼 SHA-256\(本文 · 一行核對的就是這個\):`[0-9a-f]{12}", "程式碼 SHA-256(本文 · 一行核對的就是這個):`" + cs[:12], md)
md = md.replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n")).replace("@ONE@", one)
assert re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) == ps and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot
(out / "VRN2_OneClick_v0134.md").write_text(md, encoding="utf-8", newline="\n"); (out / "boot134.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline134.txt").write_text(one + "\n", encoding="utf-8"); (out / "Run-VRN2-v0134.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("launcher %s · code %s · one-liner %d 字 · md %d · 換版號 %d 處 · 處理器名 %d 處" % (want[:12], cs[:12], len(one), len(md), n, n2))
