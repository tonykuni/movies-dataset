"""VRN2_Handover_v0134.md = v0133 交接報告 + v0134(整合一支:處理器 v0104 · 驗證器 v0103 · U/I 開不開只認 VRN2_NO_UI · ⑨ 不回退)· 逐行錨點替換 · 冪等。
用法:python make_handover_v0134.py <v0133.md> <結果 json> <輸出 md>"""
import json
import sys
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
R = json.loads(res_p.read_text(encoding="utf-8"))
lines = src.read_text(encoding="utf-8").split("\n")


def one(prefix):
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    assert len(hits) == 1, (prefix[:40], len(hits))
    return hits[0]


def sub(prefix, new):
    i = one(prefix)
    lines[i] = new(lines[i]) if callable(new) else new


def after(prefix, extra):
    i = one(prefix)
    lines[i + 1:i + 1] = extra


sub("# VRN-2 交接報告 · ActivateVRN-2 v0133 · 2026-10-21(",
    "# VRN-2 交接報告 · ActivateVRN-2 v0134 · 2026-10-21(整合一支:操作員 Windows 實跑抓到的事全部進啟動器 —— U/I 處理器 v0104(檔名規則取最新版管理器)· 獨立驗證器 v0103(標籤旁看前 4 頁 · 字距拆開的數字 · "
    "上漲空間推算 · 覆蓋率去標點 · 科目名去 * $ · 空值記號 NILVAL 不算錯值)· U/I 開不開只認 --no-open / VRN2_NO_UI=1 · ⑨ 不再用內嵌交接蓋掉倉裡較新的交接 · v0133:前後端連結 + U/I window I/O 輸入 · 四系統各自獨立)")
sub("> **本輪(v0133 · 啟動器 + U/I 處理器 VRN2_UIAction_v0103", lambda l: (
    "> **操作員令(2026-10-21 · 第二段)**:「integrate into one code to handle all above」—— 把 Windows 實跑(`C:\\測試樣本報告` · 534 檔 · 個股 55)抓到的事全部整進同一支啟動器,不再靠一鍵補。\n"
    "> **本輪(v0134 · 啟動器 + 處理器 VRN2_UIAction_v0104 + 獨立驗證器 VRN2_IndependentVerifier_v0103 · 交接報告 v0134 · 管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋一個位元組都不動)**:"
    "① 處理器 v0104:個股範圍外的檔名規則取**最新版**管理器的 `_SK_EXCL`(Windows 上整條鏈 v0154~v0239 都在,v0103 取到最舊的 v0210;與 ⑥b 用的尾版同一條)。"
    "② 驗證器 v0103(⑪ 自動取最新版 · v0102 留著):標籤旁檢查看前 4 頁、一列裡被字距拆開的數字(「3, 190.00」)也對得到(MS / GS 的現價 · 目標價印在第 3 頁或拆字);"
    "一標題四重點的「報告上漲空間」原文沒有上漲空間標籤 → 用基本資料目標價 ÷ 現價 − 1 重算相符就過(註記推算 · GS ×5 / 兆豐 / MS-8210 那 7 筆);"
    "原文句 / 標題覆蓋率兩邊去標點再量一次取高者(摘要器用「、」接的句子 · 標題的「|」不再被扣分);科目名去 * † $ 括號再比(MS ModelWare「(NT $ mn)」「EPS (NT$)**」那 23 筆 BADITEM);"
    "空值記號(n.a. / - / NM)原文找不到 → NILVAL 不算錯值(Daiwa PBR n.a. 那 1 筆)。"
    "③ U/I 開不開只認 `--no-open` / `VRN2_NO_UI=1`:VIA 設定檔(Register-VIA-Commands)設的 `VIA_NO_OPEN=1` 是給別的 VIA 工具的,VRN-2 一鍵的目的就是跳出 U/I。"
    "④ ⑨ 上船的交接落地改成「不回退」:內嵌的 `VRN2_Handover_v0134.md` 只在倉裡沒有時寫;`VRN2_Handover_latest.md` = 倉裡版號最高那份(Windows 實跑的 ⑨ 曾把內嵌舊版蓋掉 Codex 兩輪與 GitHub 報告連結 → 以後不會)。"
    "⑤ 沒動的(照實說):DUPKEY 82 筆(同鍵不同值 · 要看原文兩張表)· 現價 / 目標價旁邊標籤對調的 3 筆 · MS-6669 POINT_2 的 ModelWare EPS —— 是擷取 / 摘要器的下一輪,本輪驗證器不假裝它們過。\n"
    + l.replace("> **本輪(v0133", "> **前一輪(v0133", 1)))
sub("> **前一輪(v0132 · 工具橋 VRN2_ToolBridge_v0101", lambda l: l.replace("> **前一輪(v0132", "> **v0132(", 1))
sub("| **啟動器(MAIN)** |", lambda l: l.replace("v0133", "v0134"))
sub("| **U/I 處理器** |", "| **U/I 處理器** | `<ROOT>\\functional modules\\VRN\\VRN2_UIAction_v0104.py` | v0134 落地(v0102 / v0103 照舊留著 · 只增不改)· 檔名規則取最新版管理器 · 其餘同 v0103(`vrn2://pick` · `--set-source` · `--audit <路徑>` · `--refresh-ui`)|")
after("| **U/I 處理器** |", ["| **獨立驗證器** | `<ROOT>\\functional modules\\VRN\\VRN2_IndependentVerifier_v0103.py` | v0134 落地(v0102 留著 · ⑪ 取最新版)· 標籤旁前 4 頁 · 字距拆開的數字 · 上漲空間推算 · 覆蓋率去標點 · 科目名去 * $ · NILVAL |"])
sub("| **交接報告** |", lambda l: l.replace("VRN2_Handover_v0133.md", "VRN2_Handover_v0134.md") + "(⑨ v0134 起不回退:同版已在不蓋 · latest = 最高版號)")
sub("| 本輪證據 |", lambda l: l.replace("`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0133\\`(", "`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0134\\`(v0133:`vrn2_release_v0133\\` · "))
sub("### 3.1 現役版本(v0133 內嵌", "### 3.1 現役版本(v0134 內嵌 · 依序自動落地)")
sub("| ActivateVRN-2.py | **v0133** |", "| ActivateVRN-2.py | **v0134** | 見發行清單 | 見發行清單(本檔內嵌在啟動器裡,不寫啟動器自己的雜湊)| 新(內嵌處理器 v0104 + 驗證器 v0103 · U/I 開不開只認 VRN2_NO_UI · ⑨ 不回退)|")
sub("| **VRN2_IndependentVerifier** | **v0102** |", "| **VRN2_IndependentVerifier** | **v0103**(v0102 留著)| 81,822 | `%s` | **新**(v0102 + 標籤旁前 4 頁 · 字距拆開的數字 · 上漲空間推算 · 覆蓋率去標點 · 科目名去 * $ · NILVAL · 自測 %s)|" % (R.get("iv_sha12", "見發行清單"), R["selftest_iv"].split("(")[0].strip()))
sub("| VRN2_UIAction · VRN2_OCRBridge · rule_catalog |", "| VRN2_UIAction · VRN2_OCRBridge · rule_catalog | **v0104**(v0102 / v0103 留著)· v0100 · — | — | `%s` · `4b21f0694d0e` · `e5b881716c84` | **新**:處理器 v0104 檔名規則取最新版管理器(自測 %s)· 其餘未變 |" % (R.get("ua_sha12", "見發行清單"), R["selftest_ua"].split("(")[0].strip()))
sub("| **v0133** | 同 v0239 |", lambda l: l.replace("| **v0133** |", "| v0133 |", 1) + "\n| **v0134** | 同 v0239 | v0127 | v0114 | 整合一支:處理器 v0104 · 驗證器 v0103 · U/I 開不開只認 VRN2_NO_UI · ⑨ 交接不回退 · 主體不動 |")
sub("## 7. 本輪修正(v0132 → v0133 · 前後端連結 · U/I window I/O 輸入)",
    "## 7. 本輪修正(v0133 → v0134 · 整合一支)\n\n"
    "| # | Windows 實跑抓到的 | 做法(都在啟動器 v0134 內嵌的元件裡) | 實測 |\n|---|---|---|---|\n"
    "| 1 | 一鍵才處理 `VIA_NO_OPEN=1`,啟動器自己仍不開 U/I | 啟動器 `no_open` 只認 `--no-open` / `VRN2_NO_UI=1` | 自測:no_open 那行沒有 VIA_NO_OPEN |\n"
    "| 2 | ⑨ 把內嵌舊版交接蓋掉倉裡較新的 | `_handover_land`:同版已在不蓋 · latest = 最高版號 | 自測:同版不蓋 · latest 跟 v0199 · 空夾落地內嵌版 |\n"
    "| 3 | 處理器檔名規則取到最舊管理器 v0210 | 處理器 v0104 由大到小找 | 處理器自測 %s |\n"
    "| 4 | ⑪ 基本資料「前兩頁沒有這個數」(MS / GS 現價 · 目標價印在第 3 頁或被字距拆開)| 驗證器 v0103 標籤旁看前 4 頁 · 一列去空白再找數字並映回位置 | 驗證器自測 · 容器回歸 %s |\n"
    "| 5 | ⑪ 一標題四重點「報告上漲空間不在原文標籤旁」×7 | 原文沒有上漲空間標籤 → 基本資料目標價 ÷ 現價 − 1 重算(容忍 0.6 點)相符就過 · 註記推算 | 驗證器自測 |\n"
    "| 6 | ⑪ 原文句覆蓋 78 ~ 83%% · 標題 75%% | 兩邊去標點再量一次取高者(字本身仍要在原文) | 驗證器自測 |\n"
    "| 7 | ⑪ BADITEM 23(MS ModelWare 科目寫法 `(NT $ mn)` · `EPS (NT$)**`)| 科目名去 * † $ 括號引號再比(BADITEM 與科目列兩處) | 驗證器自測 |\n"
    "| 8 | ⑪ FAIL 1(Daiwa PBR n.a.)| 空值記號原文找不到 → NILVAL 不算錯值 | 容器回歸 |\n"
    "| 9 | 沒動(照實說)| DUPKEY 82(同鍵不同值)· 標籤對調 3 筆 · MS-6669 ModelWare EPS → 擷取 / 摘要器下一輪 | — |\n\n"
    "一鍵 v0134:%s\n\n"
    "## 7.0c v0132 → v0133(前後端連結 · U/I window I/O 輸入)" % (R["selftest_ua"].split("(")[0].strip(), R["verifier_regress"].split(":")[0], R["oneclick"]))
sub("| 0 | **使用者用 v0133 的一行跑**", lambda l: "| 0 | **使用者用 v0134 的一行跑**(`vrn2_release_v0134/VRN2_OneClick_v0134.md`)| 待執行 | 預期:U/I 自己跳出(不用再管 VIA_NO_OPEN)· ⑪ 基本資料 / 一標題四重點 FAIL 從 9 + 12 降(現價 / 目標價頁位 · 上漲空間推算 · 覆蓋去標點)· BADITEM 23 → 0 · NILVAL 1 · DUPKEY 82 照舊待看原文 · ⑨ 不蓋交接。貼回 ⑪ 驗證摘要 + ②b / ⑤b。 |\n" + l.replace("| 0 |", "| 0b |", 1))
sub("一鍵(取得 v0133 → 驗雜湊", lambda l: l.replace("v0133", "v0134"))
after("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)", [
    "",
    "- **全部整進一支**:操作員實跑抓到的事(U/I 不開 · ⑨ 回退 · 規則取錯版 · 驗證器的頁位 / 字距 / 標點 / 科目名 / 空值)都改在啟動器內嵌的元件裡(處理器 v0104 · 驗證器 v0103 · 啟動器 v0134),一鍵只是取啟動器 + 摘要 + 備援;下一輪也這樣,不要靠一鍵補主體的洞。",
    "- **驗證器放寬只放「讀法」不放「值」**:前 4 頁、字距、標點、科目符號、空值記號都是讀法;值對不上(標籤對調 · DUPKEY 不同值 · ModelWare EPS)仍是 FAIL,照實留給擷取 / 摘要器。",
    "- **⑨ 交接只增不回退**:內嵌交接同版已在就不蓋,latest 永遠指倉裡最高版號;要更新交接就出新版號檔。",
])
out.write_text("\n".join(lines), encoding="utf-8", newline="\n")
print("[計] %s · %d 字" % (out.name, sum(len(l) for l in lines)))
