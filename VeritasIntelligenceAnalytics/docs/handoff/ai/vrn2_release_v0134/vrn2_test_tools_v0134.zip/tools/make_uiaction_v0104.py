"""VRN2_UIAction_v0104 = v0103 + 檔名規則取「最新」的管理器(操作員機器有 v0154~v0239 整條鏈 · v0103 取到最舊的 v0210)。錨點替換 · 只增。
用法:python make_uiaction_v0104.py <v0103.py> <輸出 v0104.py>"""
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:80])
    s = s.replace(a, b)


rep('"""VRN2_UIAction v0103 — VRN-2 U/I 操作協定 vrn2:// 的處理器', '"""VRN2_UIAction v0104 — VRN-2 U/I 操作協定 vrn2:// 的處理器(v0104:個股範圍外的檔名規則取最新版管理器的 _SK_EXCL · 其餘同 v0103)')
rep('VERSION = "VRN2_UIAction v0103"', 'VERSION = "VRN2_UIAction v0104"')
rep('''    """個股範圍外的檔名規則 = 管理器 v0231 的 _SK_EXCL(從檔案文字讀同一條 · 不 import VRN-2 程式)· 找不到 → 內建備援。回 (regex, 來源)。"""
    for p in sorted(Path(vrn).glob("VRN_SystemManager_v[0-9][0-9][0-9][0-9].py")):
''', '''    """個股範圍外的檔名規則 = 最新版管理器的 _SK_EXCL(從檔案文字讀同一條 · 不 import VRN-2 程式 · v0104:版號由大到小找 · 與 ⑥b 用的尾版同一條)· 找不到 → 內建備援。回 (regex, 來源)。"""
    for p in sorted(Path(vrn).glob("VRN_SystemManager_v[0-9][0-9][0-9][0-9].py"), key=lambda q: int(re.search(r"_v(\\d{4})", q.name).group(1)), reverse=True):
''')
rep('''        chk("v0231 不在 → 內建備援規則", excl_rule(t)[1] == "內建備援")
''', '''        chk("v0231 不在 → 內建備援規則", excl_rule(t)[1] == "內建備援")
        (vrn / "VRN_SystemManager_v0210.py").write_text('_SK_EXCL = re.compile(r"(?i)舊規則只排晨會")\\n', encoding="utf-8")
        chk("v0104 檔名規則取最新版管理器(v0231 > v0210 · 不是檔名排序最前的)", excl_rule(vrn)[1] == "VRN_SystemManager_v0231.py" and excl_rule(vrn)[0].search("產業專題"))
        (vrn / "VRN_SystemManager_v0210.py").unlink()
''')
rep('prefix="uia103-"', 'prefix="uia104-"')
out.write_text(s, encoding="utf-8", newline="\n")
compile(s, out.name, "exec")
print("[計] %s · %d 位元組" % (out.name, len(s.encode("utf-8"))))
