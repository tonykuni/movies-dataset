"""VRN2_IndependentVerifier_v0103 = v0102 + 操作員 Windows 實跑 2026-10-21 的 ⑪ 待核對分類(錨點替換 · 原檔不動 · 只增)。
用法:python make_verifier_v0103.py <v0102.py> <輸出 v0103.py>
  ① 標籤旁檢查看前 4 頁(現價 / 目標價印在第 3 頁以後的券商)· 一列的數字被字距拆開(3, 190.00)也對得到
  ② 一標題四重點的「報告上漲空間」原文沒有上漲空間標籤 → 用基本資料 目標價 ÷ 現價 − 1 重算相符 → 過(註記推算)
  ③ 原文句 / 標題覆蓋率:去掉標點(、,;:|括號引號)再量一次取高者(摘要器用「、」接的句子不再被標點扣分)
  ④ 科目名正規化(去 * $ 括號引號):MS ModelWare 科目「(NT $ mn)」「EPS (NT$)**」對得到原文
  ⑤ 空值記號(n.a. / - / NM)在原文找不到 → NILVAL(不算錯值 · 照實記)"""
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:80])
    s = s.replace(a, b)


rep('"""VRN2_IndependentVerifier_v0102 — VRN-2 輸出值獨立驗證(v0100 + 表頭列 HDRVAL + 段落標題 SECFAIL',
    '"""VRN2_IndependentVerifier_v0103 — VRN-2 輸出值獨立驗證(v0103:標籤旁看前 4 頁 + 字距拆開的數字 · 上漲空間推算相符 · 覆蓋率去標點 · 科目名去 * $ · 空值記號 NILVAL 不算錯值;'
    'v0102:v0100 + 表頭列 HDRVAL + 段落標題 SECFAIL')
rep('VERSION = "VRN2_IndependentVerifier_v0102"', 'VERSION = "VRN2_IndependentVerifier_v0103"')

# ③ 覆蓋率去標點
rep('''def src_score(v, raw_sq):
    """原文覆蓋率:值壓縮後每 6 字一窗(步距 3)有幾成在原文(兩讀取器聯集)· 跨欄交錯的標題也量得到。"""
    sv = squash(v)
    if len(sv) <= 6:
        return 1.0 if sv in raw_sq else 0.0
    wins = [sv[i:i + 6] for i in range(0, len(sv) - 5, 3)]
    return sum(1 for w in wins if w in raw_sq) / len(wins)
''', '''def src_score(v, raw_sq):
    """原文覆蓋率:值壓縮後每 6 字一窗(步距 3)有幾成在原文(兩讀取器聯集)· 跨欄交錯的標題也量得到。"""
    sv = squash(v)
    if len(sv) <= 6:
        return 1.0 if sv in raw_sq else 0.0
    wins = [sv[i:i + 6] for i in range(0, len(sv) - 5, 3)]
    return sum(1 for w in wins if w in raw_sq) / len(wins)


_PUN = re.compile(r"[、,，;；:：|()（）\\[\\]【】「」『』'\\"“”‘’·•\\-–—/…]")


def src_score2(v, raw_sq):
    """v0103 覆蓋率取「原樣」與「兩邊都去掉標點」的高者:摘要器用「、」「;」接起來的句子、標題裡的「|」不再被標點扣分(字本身仍要在原文)。"""
    a = src_score(v, raw_sq)
    if a >= 0.85:
        return a
    v2, r2 = _PUN.sub("", nfk(v)), _PUN.sub("", raw_sq)
    return max(a, src_score(v2, r2)) if v2 and r2 else a


_INM = re.compile(r"[*†‡$,.'’\\"\\u2018\\u2019()（）\\[\\]]")


def _inm(t):
    """v0103 科目名正規化(比對用):去 * † $ , . 引號 括號 → 「ModelWare net inc (NT $ mn)」=「ModelWare net inc (NT$ mn)」·「EPS (NT$)**」=「EPS (NT$)」。"""
    return _INM.sub("", t)


def _upside_recalc(z, basic):
    """v0103 報告上漲空間原文沒有標籤 → 基本資料 目標價 ÷ 現價 − 1 重算(容忍 0.6 個百分點:原文印整數或一位小數)。回 (相符, 說明)。"""
    try:
        tp = float(re.sub(r"[^\\d.]", "", str((basic or {}).get("TARGET_PRICE", ""))))
        cp = float(re.sub(r"[^\\d.]", "", str((basic or {}).get("CURRENT_PRICE_REPORT", ""))))
        zz = float(z)
    except (TypeError, ValueError):
        return False, ""
    if cp <= 0 or tp <= 0:
        return False, ""
    calc = (tp / cp - 1) * 100
    return abs(calc - zz) <= 0.6, "目標價 %s ÷ 現價 %s − 1 重算 %.1f%%%s" % (basic.get("TARGET_PRICE"), basic.get("CURRENT_PRICE_REPORT"), calc, "(相符 · 已標推算)" if abs(calc - zz) <= 0.6 else "(對不上)")


def _num_cands(s_, fv):
    """v0103 一列字串裡等於 fv 的數字位置 [(start, end)]:原樣 · 加上去掉空白後再找(字距把 3,190.00 拆成「3, 190.00」也對得到 · 位置映回原字串)。"""
    out = [(m.start(), m.end()) for m in re.finditer(r"\\d[\\d,]*(?:\\.\\d+)?", s_) if _numv(m.group()) == fv]
    s2 = s_.replace(" ", "")
    if s2 != s_:
        pos = [i for i, ch in enumerate(s_) if ch != " "]
        for m in re.finditer(r"\\d[\\d,]*(?:\\.\\d+)?", s2):
            if _numv(m.group()) == fv and pos:
                st, en = pos[m.start()], pos[m.end() - 1] + 1
                if (st, en) not in out:
                    out.append((st, en))
    return sorted(out)
''')

# ① 標籤旁:前 4 頁 · 字距拆開的數字
rep('def near_label(pdf, v, field, pages=(1, 2)):', 'def near_label(pdf, v, field, pages=(1, 2, 3, 4)):')
rep('''        for i, (y, s_, labs, xat) in enumerate(info):
            for m in re.finditer(r"\\d[\\d,]*(?:\\.\\d+)?", s_):
                if _numv(m.group()) != fv:
                    continue
                vx = xat(m.start())
                bef = [l_ for l_ in labs if l_[1] <= m.start()]
''', '''        for i, (y, s_, labs, xat) in enumerate(info):
            for st_, en_ in _num_cands(s_, fv):                              # v0103 字距拆開的數字也對得到
                vx = xat(st_)
                bef = [l_ for l_ in labs if l_[1] <= st_]
''')
rep('''                if kind == want:
                    return True, "第 %d 頁 · 標籤旁(%s)" % (pg, s_[max(0, m.start() - 40):m.end()].strip()[-60:])
    names = {0: "沒有標籤", 1: "目標價標籤", 2: "股價標籤", 3: "上漲空間標籤"}
    return False, ("前兩頁沒有這個數" if not seen else "前兩頁有這個數 · 但旁邊是%s" % "、".join(sorted({names[k] for k in seen})))
''', '''                if kind == want:
                    return True, "第 %d 頁 · 標籤旁(%s)" % (pg, s_[max(0, st_ - 40):en_].strip()[-60:])
    names = {0: "沒有標籤", 1: "目標價標籤", 2: "股價標籤", 3: "上漲空間標籤"}
    return False, ("前 %d 頁沒有這個數" % len(pages) if not seen else "前 %d 頁有這個數 · 但旁邊是%s" % (len(pages), "、".join(sorted({names[k] for k in seen}))))
''')

# ② 上漲空間推算
rep('''                elif pdf is not None and not near_label(pdf, mu.group(1), "UPSIDE_PCT")[0]:
                    bad.append("報告上漲空間 %s%% 不在原文上漲空間標籤旁" % mu.group(1))
''', '''                elif pdf is not None and not near_label(pdf, mu.group(1), "UPSIDE_PCT")[0]:
                    okr, whyr = _upside_recalc(mu.group(1), basic)                 # v0103 原文沒有上漲空間標籤 → 目標價 ÷ 現價 重算相符就過(註記推算)
                    if okr:
                        notes.append("上漲空間 %s%% 原文沒有標籤 · %s" % (mu.group(1), whyr))
                    else:
                        bad.append("報告上漲空間 %s%% 不在原文上漲空間標籤旁%s" % (mu.group(1), (" · " + whyr) if whyr else ""))
''')

# ③ 覆蓋率:句子與標題都用 src_score2
rep('''        sc = src_score(sg, rsq)
        if sc < 0.85:                                                    # 標題 + 句子黏在一起''', '''        sc = src_score2(sg, rsq)
        if sc < 0.85:                                                    # 標題 + 句子黏在一起''')
rep('''            sc = src_score(tt, squash(ta))
            put("TITLE", sc >= 0.8''', '''            sc = src_score2(tt, squash(ta))
            put("TITLE", sc >= 0.8''')
rep('''            sc = src_score(x["TITLE"], rsq)
            chk["TITLE"] = ("PASS" if sc >= 0.8''', '''            sc = src_score2(x["TITLE"], rsq)
            chk["TITLE"] = ("PASS" if sc >= 0.8''')

# ④ 科目名正規化:BADITEM 與科目列比對
rep('''        if verdict in ("ALIGNED", "PRESENT") and si not in squash(ptxt) and not wrapped:
            verdict, note = "BADITEM", "科目 %r 本頁原文沒有 · %s" % (item, note)
''', '''        if verdict in ("ALIGNED", "PRESENT") and si not in squash(ptxt) and _inm(si) not in _inm(squash(ptxt)) and not wrapped:   # v0103 去 * $ 括號再比
            verdict, note = "BADITEM", "科目 %r 本頁原文沒有 · %s" % (item, note)
        if kind == "NIL" and verdict in ("FAIL", "PRESENT"):                   # v0103 空值記號找不到 → 不算錯值
            verdict, note = "NILVAL", "空值記號 %r 原文該格可能是空白 / 別的記號 · 不算錯值 · %s" % (val, note)
''')
rep('''def _lab_ok(lab, isq):
    """v0100 這一列的科目字就是這個科目(不是只「含」:EPS ≠ EPS growth · Revenue ≠ Total revenue):相同 · 折行(科目開頭 · 後半在下一列)· 原文多印單位(括號)''',
    '''def _lab_ok(lab, isq):
    """v0100 這一列的科目字就是這個科目(不是只「含」:EPS ≠ EPS growth · Revenue ≠ Total revenue):相同 · 折行(科目開頭 · 後半在下一列)· 原文多印單位(括號)
    v0103:兩邊先去掉 * † $ 與括號引號(註腳星號 · 「NT $ mn」寫法差異)再比。''')
rep('''    lab, isq = re.sub(r"^[•·\\-–—*]+", "", lab), re.sub(r"^[•·\\-–—*]+", "", isq)   # 開頭的項目符號(- · •)兩邊都去掉
    if lab == isq:
        return "同"
''', '''    lab, isq = re.sub(r"^[•·\\-–—*]+", "", lab), re.sub(r"^[•·\\-–—*]+", "", isq)   # 開頭的項目符號(- · •)兩邊都去掉
    if lab == isq or (_inm(lab) and _inm(lab) == _inm(isq)):
        return "同"
''')

# 自測
rep('''    print("[計] %s 自測 %d/%d · %s" % (VERSION, p, p + f, "PASS" if f == 0 else "FAIL"))
    return 0 if f == 0 else 1
''', '''    raw3 = squash("展望4Q26,雖藍牙音訊營收恐因淡季而小幅季減,且消費性產品\\n需求回溫 AirTAC International | Asia Pacific")
    chk("v0103 覆蓋率去標點:「、」「;」接起來的句子 ≥ 0.85 · 字不在原文仍低",
        src_score2("展望4Q26、雖藍牙音訊營收恐因淡季而小幅季減、且消費性產品需求回溫", raw3) >= 0.85 and src_score2("AirTAC International Asia Pacific", raw3) >= 0.85
        and src_score2("完全不同的一句話在這裡沒有出現過", raw3) < 0.5)
    chk("v0103 科目名正規化:ModelWare net inc (NT $ mn) = (NT$ mn) · EPS (NT$)** = EPS (NT$) · EPS ≠ EPS growth",
        _lab_ok("modelwarenetinc(nt$mn)", "modelwarenetinc(nt$mn)") == "同" and _lab_ok("eps(nt$)", "eps(nt$)**") == "同" and _inm("eps(nt$)**") == _inm("eps(nt$)")
        and not _lab_ok("epsgrowth", "eps") and _inm("modelwarenetinc(nt$mn)") in _inm(squash("ModelWare net inc (NT $ mn) 4,396")))
    chk("v0103 上漲空間推算:目標價 400 ÷ 現價 231 − 1 = 73.2%(相符)· 50% 對不上 · 沒有基本資料 → 不過",
        _upside_recalc("73.2", {"TARGET_PRICE": "400.00", "CURRENT_PRICE_REPORT": "231.0"})[0] and not _upside_recalc("50", {"TARGET_PRICE": "400", "CURRENT_PRICE_REPORT": "231"})[0]
        and not _upside_recalc("73.2", {})[0])
    chk("v0103 字距拆開的數字:「close NT$ 3, 190.00」對得到 3190 · 位置映回原字串 · 原本連著的也在",
        _num_cands("close (Dec 3, 2025) NT$ 3, 190.00", 3190.0) and all(_numv(re.sub(r"\\s", "", "close (Dec 3, 2025) NT$ 3, 190.00"[a:b])) == 3190.0 for a, b in _num_cands("close (Dec 3, 2025) NT$ 3, 190.00", 3190.0))
        and _num_cands("Price target NT$4,388.00", 4388.0) == [(16, 24)] and not _num_cands("Price target NT$4,388.00", 3190.0))
    chk("v0103 標籤旁預設看前 4 頁 · 訊息寫「前 4 頁」", near_label.__defaults__ == ((1, 2, 3, 4),) and "前 %d 頁" in inspect.getsource(near_label))
    print("[計] %s 自測 %d/%d · %s" % (VERSION, p, p + f, "PASS" if f == 0 else "FAIL"))
    return 0 if f == 0 else 1
''')
if "import inspect" not in s.split("def selftest")[1][:400]:
    rep("def selftest():\n", "def selftest():\n    import inspect\n")
out.write_text(s, encoding="utf-8", newline="\n")
compile(s, out.name, "exec")
print("[計] %s · %d 位元組" % (out.name, len(s.encode("utf-8"))))
