"""ActivateVRN-2 v0133 → v0134 組裝(錨點替換 · 每個錨點只准出現一次 · 不改 v0133 原檔)。
用法:python build_v0134.py <v0133 啟動器> <new 夾> <輸出 v0134 啟動器>
  new 夾:VRN2_UIAction_v0104.py · VRN2_IndependentVerifier_v0103.py · VRN2_Handover_v0134.md
v0134 = 操作員 2026-10-21「integrate into one code to handle all above」:把 Windows 實跑抓到的事全部整進啟動器:
  ① 內嵌 U/I 處理器 v0104(檔名規則取最新版管理器)· 獨立驗證器 v0103(標籤旁看前 4 頁 · 字距拆開的數字 · 上漲空間推算 · 覆蓋率去標點 · 科目名去 * $ · NILVAL)· v0102 / v0103 留著(只增)
  ② U/I 開不開只認 --no-open / VRN2_NO_UI=1(VIA 設定檔的 VIA_NO_OPEN=1 不再讓一鍵不開 U/I)
  ③ ⑨ 上船不再用內嵌的交接蓋掉倉裡較新的同版 / 更新版交接(只在沒有時落地 · latest = 倉裡最高版號那份)
  管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋 一個位元組都不動。"""
import base64
import hashlib
import sys
from pathlib import Path

src_p, new_d, out_p = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src_p.read_text(encoding="utf-8")


def b64(raw: bytes) -> str:
    t = base64.b64encode(raw).decode("ascii")
    return "\n".join(t[i:i + 120] for i in range(0, len(t), 120))


def rep(a: str, b: str) -> None:
    global s
    assert s.count(a) == 1, (s.count(a), a[:90])
    s = s.replace(a, b)


ua = (new_d / "VRN2_UIAction_v0104.py").read_bytes()
iv = (new_d / "VRN2_IndependentVerifier_v0103.py").read_bytes()
hand = (new_d / "VRN2_Handover_v0134.md").read_bytes()
usha, isha, hsha = hashlib.sha256(ua).hexdigest(), hashlib.sha256(iv).hexdigest(), hashlib.sha256(hand).hexdigest()

rep('r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0133 前後端連結 · window I/O 輸入:',
    'r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0134 整合一支:U/I 處理器 v0104(檔名規則取最新版管理器)· 獨立驗證器 v0103(標籤旁看前 4 頁 · 字距拆開的數字 · 上漲空間推算 · 覆蓋率去標點 · 科目名去 * $ · 空值記號 NILVAL 不算錯值)· '
    'U/I 開不開只認 --no-open / VRN2_NO_UI=1(VIA 設定檔的 VIA_NO_OPEN=1 不再讓一鍵不開 U/I)· ⑨ 不再用內嵌交接蓋掉倉裡較新的交接 · 其餘同 v0133 · VRN-2 主體一個位元組都不動)\n'
    'v0133 前後端連結 · window I/O 輸入:')
rep('VERSION = "ActivateVRN-2 v0133"', 'VERSION = "ActivateVRN-2 v0134"')

rep('UI_HANDLER_NAME = "VRN2_UIAction_v0103.py"\n',
    'EXTRAS.append(("VRN2_UIAction_v0104.py", "%s", """\n%s\n"""))   # v0134 U/I 處理器 v0104(檔名規則取最新版管理器)· v0102 / v0103 留著(只增不改)\n'
    'EXTRAS.append(("VRN2_IndependentVerifier_v0103.py", "%s", """\n%s\n"""))   # v0134 獨立驗證器 v0103(⑪ 取最新版 · v0102 留著)\n'
    'UI_HANDLER_NAME = "VRN2_UIAction_v0104.py"\n' % (usha, b64(ua), isha, b64(iv)))

i = s.index('HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0133.md"')
j = s.index('"""', s.index('HANDOVER_B64 = """') + len('HANDOVER_B64 = """')) + 3
s = s[:i] + 'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0134.md", "%s"\nHANDOVER_B64 = """\n%s\n"""' % (hsha, b64(hand)) + s[j:]

# ② U/I 開不開
rep('    no_open = "--no-open" in argv or os.environ.get("VIA_NO_OPEN") == "1"   # v0127 U/I 由本支在 ⑪ 之後開(⑦ 一律 --no-open)\n',
    '    no_open = "--no-open" in argv or os.environ.get("VRN2_NO_UI") == "1"   # v0134 只認 --no-open / VRN2_NO_UI=1(VIA 設定檔的 VIA_NO_OPEN=1 是給別的 VIA 工具的 · VRN-2 一鍵的目的就是跳出 U/I)· v0127 U/I 由本支在 ⑪ 之後開(⑦ 一律 --no-open)\n')

# ③ ⑨ 交接不回退
rep('''    hd = root / "docs" / "handoff" / "ai"
    hd.mkdir(parents=True, exist_ok=True)
    hb = base64.b64decode(HANDOVER_B64)
    for n_ in (HANDOVER_NAME, "VRN2_Handover_latest.md"):
        p_ = hd / n_
        if not p_.exists() or p_.read_bytes() != hb:
            p_.write_bytes(hb)
    rc, top = _git(vrn, "rev-parse", "--show-toplevel")''', '''    hd = root / "docs" / "handoff" / "ai"
    _handover_land(hd)                                                     # v0134 不回退:同版已在就不蓋 · latest = 倉裡最高版號那份
    rc, top = _git(vrn, "rev-parse", "--show-toplevel")''')
rep('''def git_ship(vrn, root, comp: dict) -> tuple:''', '''def _handover_land(hd) -> str:
    """v0134 交接報告落地(⑨ 之前):內嵌的 VRN2_Handover_v0134.md 只在倉裡沒有時寫(倉裡同版可能已被後續 PR 更新 · 不蓋);
    VRN2_Handover_latest.md = 倉裡版號最高的 VRN2_Handover_v####.md(有更新版就跟著走 · 不再被舊的內嵌版蓋回去)。回說明。"""
    hd = _cb_Path(hd)
    hd.mkdir(parents=True, exist_ok=True)
    hb = base64.b64decode(HANDOVER_B64)
    mine = hd / HANDOVER_NAME
    wrote = []
    if not mine.exists():
        mine.write_bytes(hb)
        wrote.append(HANDOVER_NAME)
    vers = sorted(hd.glob("VRN2_Handover_v[0-9][0-9][0-9][0-9].md"), key=_vnum)
    top_ = vers[-1] if vers else mine
    lat = hd / "VRN2_Handover_latest.md"
    if not lat.exists() or lat.read_bytes() != top_.read_bytes():
        lat.write_bytes(top_.read_bytes())
        wrote.append("latest ← " + top_.name)
    return "交接 %s(最高版 %s%s)" % (HANDOVER_NAME, top_.name, " · 寫 " + "、".join(wrote) if wrote else " · 都已是最新")


def git_ship(vrn, root, comp: dict) -> tuple:''')

# 自測:v0133 的內嵌處理器檢查 → v0104 · 加 v0134 三條
rep('''    chk("v0133 內嵌 U/I 處理器 %s(vrn2://pick · 三類只開個股 · --set-source / --refresh-ui · 帶加速器橋 · 不 import VRN-2 程式)· v0102 留著" % UI_HANDLER_NAME,
        bool(uab) and UI_HANDLER_NAME.endswith("v0103.py") and all(x in uasrc for x in ("def pick(", "def audit(", "def patch_ui(", "--set-source", "--refresh-ui", "個股報告/訊息", "產業報告/展望", "其他投資報告", "[VIA:ACCEL-BRIDGE:v0111]"))
        and "import VRN_" not in uasrc and "from VRN_" not in uasrc and any(e[0] == "VRN2_UIAction_v0102.py" for e in EXTRAS))''',
    '''    chk("v0134 內嵌 U/I 處理器 %s(vrn2://pick · 三類只開個股 · --set-source / --refresh-ui · 檔名規則取最新版管理器 · 帶加速器橋 · 不 import VRN-2 程式)· v0102 / v0103 留著" % UI_HANDLER_NAME,
        bool(uab) and UI_HANDLER_NAME.endswith("v0104.py") and all(x in uasrc for x in ("def pick(", "def audit(", "def patch_ui(", "--set-source", "--refresh-ui", "個股報告/訊息", "產業報告/展望", "其他投資報告", "[VIA:ACCEL-BRIDGE:v0111]", "reverse=True"))
        and "import VRN_" not in uasrc and "from VRN_" not in uasrc and all(any(e[0] == n_ for e in EXTRAS) for n_ in ("VRN2_UIAction_v0102.py", "VRN2_UIAction_v0103.py")))
    ivn_ = [e[0] for e in EXTRAS if e[0].startswith("VRN2_IndependentVerifier_v")]
    iv3_ = next((e for e in EXTRAS if e[0] == "VRN2_IndependentVerifier_v0103.py"), None)
    iv3src = base64.b64decode("".join(iv3_[2].split())).decode("utf-8") if iv3_ else ""
    with tempfile.TemporaryDirectory(prefix="act134iv-") as td_:
        p_ = _cb_Path(td_) / "VRN2_IndependentVerifier_v0103.py"
        p_.write_bytes(base64.b64decode("".join(iv3_[2].split())) if iv3_ else b"")
        rc_iv3, ln_iv3 = run([sys.executable, "-W", "ignore", str(p_), "--selftest"], 600, {"VIA_NO_OPEN": "1"}, cwd=td_, silent_max=600)
    chk("v0134 內嵌獨立驗證器 v0103(v0102 留著 · ⑪ 取最新版):標籤旁前 4 頁 · _num_cands · _upside_recalc · src_score2 · _inm · NILVAL · 自測 → %s"
        % next((l.strip() for l in reversed(ln_iv3) if "自測" in l), "rc %d" % rc_iv3)[-40:],
        ivn_ == ["VRN2_IndependentVerifier_v0102.py", "VRN2_IndependentVerifier_v0103.py"] and all(x in iv3src for x in ("def _num_cands(", "def _upside_recalc(", "def src_score2(", "def _inm(", "NILVAL", "pages=(1, 2, 3, 4)"))
        and rc_iv3 == 0)
    chk("v0134 U/I 開不開只認 --no-open / VRN2_NO_UI(VIA_NO_OPEN 不再擋)", 'os.environ.get("VRN2_NO_UI") == "1"' in _ms and 'os.environ.get("VIA_NO_OPEN") == "1"' not in _ms.split("no_open = ")[1].split("\\n")[0])
    with tempfile.TemporaryDirectory(prefix="act134hd-") as td_:
        hd_ = _cb_Path(td_)
        (hd_ / HANDOVER_NAME).write_bytes(b"newer same-version content\\n")
        (hd_ / "VRN2_Handover_v0199.md").write_bytes(b"even newer version\\n")
        (hd_ / "VRN2_Handover_latest.md").write_bytes(b"stale\\n")
        _w1 = _handover_land(hd_)
        _ok1 = (hd_ / HANDOVER_NAME).read_bytes() == b"newer same-version content\\n" and (hd_ / "VRN2_Handover_latest.md").read_bytes() == b"even newer version\\n"
        for q_ in list(hd_.glob("*.md")):
            q_.unlink()
        _w2 = _handover_land(hd_)
        _ok2 = (hd_ / HANDOVER_NAME).read_bytes() == base64.b64decode(HANDOVER_B64) and (hd_ / "VRN2_Handover_latest.md").read_bytes() == base64.b64decode(HANDOVER_B64)
    chk("v0134 ⑨ 交接不回退:倉裡同版已在 → 不蓋 · latest = 最高版號(v0199)· 空夾 → 落地內嵌版 + latest", _ok1 and _ok2 and "v0199" in _w1)''')

out_p.write_text(s, encoding="utf-8", newline="\n")
compile(s, out_p.name, "exec")
print("[計] %s · %d 位元組 · 處理器 %s · 驗證器 %s · 交接 %s · sha256 %s" % (out_p.name, len(s.encode("utf-8")), usha[:12], isha[:12], hsha[:12], hashlib.sha256(s.encode("utf-8")).hexdigest()[:12]))
