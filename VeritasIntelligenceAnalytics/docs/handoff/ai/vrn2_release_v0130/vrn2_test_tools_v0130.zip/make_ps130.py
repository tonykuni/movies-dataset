"""Run-VRN2-v0130.ps1 = v0129 一鍵 + Codex 三處(PR #534):① ⑪ 報告判決看三段(基本資料 / 一標題四重點 / 年度數據)· ② PS 自驗只驗本輪寫的輸出冊 · ③ 成功看本輪 ⑧ 完成燈(不只啟動器 rc)。啟動器 v0129 不動。"""
S = "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"
ps = open(S + "/Run-VRN2-v0129.ps1", encoding="utf-8").read()
def rep(a, b, n=1):
    global ps
    assert ps.count(a) == n, (ps.count(a), a[:80])
    ps = ps.replace(a, b)
rep("# ===== VRN-2 v0129 一鍵全流程(", "# ===== VRN-2 一鍵 v0130(啟動器 v0129 不變 · 一鍵只改判定:⑪ 報告三段都看 · PS 自驗只驗本輪的冊 · 成功看本輪 ⑧ 完成燈)· v0129 一鍵全流程(")
rep("  $Br     = 'claude/optimistic-goodall-yhalc5'                                    # v0129 發行所在的 GitHub 分支(只讀取 · 不切換分支)\n",
    "  $Br     = 'claude/optimistic-goodall-yhalc5'                                    # v0129 發行所在的 GitHub 分支(只讀取 · 不切換分支 · 讀不到 → 改讀 main)\n")
rep("  $t0 = Get-Date; $tmp = Join-Path ([IO.Path]::GetTempPath()) (\"vrn2_v0129_\"", "  $t0 = Get-Date; $tmp = Join-Path ([IO.Path]::GetTempPath()) (\"vrn2_v0130_\"")
rep("""    # ③ 取得 v0129:先看本機那份 · 不是 → 從 GitHub 分支讀發行夾(git fetch + git archive · 不切換分支)· 雜湊對才換 · 舊版改名備份""",
    """    # ③ 取得啟動器 v0129:先看本機那份 · 不是 → 從 GitHub 分支(讀不到 → main)讀發行夾(git fetch + git archive · 不切換分支)· 雜湊對才換 · 舊版改名備份""")
rep("""    if ($top) {
      $ok = $false
      foreach ($w in 0, 2, 4, 8, 16) { if ($w) { Start-Sleep -Seconds $w }; git -C $top fetch -q origin $Br 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { $ok = $true; break } }
      if ($ok) {
        $z = Join-Path $tmp 'vrn2_release_v0129.zip'
        git -C $top archive --format=zip -o $z "origin/${Br}:$RelP" 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $z)) { $rel = Join-Path $tmp 'rel'; Expand-Archive -LiteralPath $z -DestinationPath $rel -Force }
      }
    }
""", """    if ($top -and $have -ne $Want) {
      foreach ($b in $Br, 'main') {
        $ok = $false
        foreach ($w in 0, 2, 4, 8, 16) { if ($w) { Start-Sleep -Seconds $w }; git -C $top fetch -q origin $b 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { $ok = $true; break } }
        if (-not $ok) { continue }
        $z = Join-Path $tmp 'vrn2_release_v0129.zip'
        git -C $top archive --format=zip -o $z "origin/${b}:$RelP" 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $z)) { $rel = Join-Path $tmp 'rel'; Expand-Archive -LiteralPath $z -DestinationPath $rel -Force; break }
      }
    }
""")
rep("""Say RED "③ 本機啟動器不是 v0129,且讀不到 GitHub 分支 $Br(網路 / git)""", """Say RED "③ 本機啟動器不是 v0129,且讀不到 GitHub 分支 $Br 或 main(網路 / git)""")
rep("""Say GREEN "③ 啟動器 v0129 就位(SHA-256 $($Want.Substring(0,12)) · 來源 GitHub $Br)→ $A\"""", """Say GREEN "③ 啟動器 v0129 就位(SHA-256 $($Want.Substring(0,12)) · 來源 GitHub $b)→ $A\"""")
rep("""    Write-Host ("[計] VRN-2 · ActivateVRN-2 v0129 · {0}" -f""", """    Write-Host ("[計] VRN-2 一鍵 v0130 · ActivateVRN-2 v0129 · {0}" -f""")
# ② PS 自驗只驗本輪寫的輸出冊(同啟動器 ⑪ 的 t0 - 5 秒門檻)
rep("""    # ⑤ 摘要 · 獨立驗證:啟動器 ⑪ 本輪已驗(報告時間 ≥ 開始)→ 直接用;沒有 → PS 用落地的驗證器自己驗(與摘要同時跑 · 只讀 · 判決也寫回 U/I)
    $v2 = [IO.Path]::Combine($R, 'VIA_Reports', 'vrn2'); $od = Join-Path $v2 'output'
""", """    # ⑤ 摘要 · 獨立驗證:啟動器 ⑪ 本輪已驗(報告時間 ≥ 開始)→ 直接用;沒有 → 輸出冊是本輪寫的(≥ 開始 - 5 秒 · 同啟動器 ⑪)才由 PS 用落地的驗證器自己驗(與摘要同時跑 · 只讀 · 判決也寫回 U/I)· 舊冊不驗
    $v2 = [IO.Path]::Combine($R, 'VIA_Reports', 'vrn2'); $od = Join-Path $v2 'output'
    $fdj = Join-Path $od 'VRN2_FinancialData_latest.json'
    $fdNew = (Test-Path -LiteralPath $fdj) -and ((Get-Item -LiteralPath $fdj).LastWriteTime -ge $t0.AddSeconds(-5))
""")
rep("""    elseif ($Verify -and (Test-Path -LiteralPath (Join-Path $od 'VRN2_FinancialData_latest.json'))) {""", """    elseif ($Verify -and $fdNew) {""")
rep("""        Say GRAY "啟動器本輪沒有驗證報告 → PS 用 $($ver.Name) 自己驗(只讀 · 判決寫回 U/I)"
      }
    }
""", """        Say GRAY "啟動器本輪沒有驗證報告 → PS 用 $($ver.Name) 自己驗本輪的輸出冊(只讀 · 判決寫回 U/I)"
      }
    }
    elseif ($Verify -and (Test-Path -LiteralPath $fdj)) { Say YELLOW "獨立驗證不跑 · 輸出冊不是本輪寫的($((Get-Item -LiteralPath $fdj).LastWriteTime.ToString('yyyy-MM-dd HH:mm:ss')) · ⑦ 沒跑完)· 不驗舊冊、不把舊冊判決寫進 U/I" }
""")
# 摘要:輸出冊不是本輪寫的 → 黃
rep('''print("GREEN|輸出冊 · 基本資料 %d · 年度數據 %d 筆''', '''import os as _os
_fd = od / "VRN2_FinancialData_latest.json"
_new = _fd.exists() and datetime.datetime.fromtimestamp(_fd.stat().st_mtime) >= t0 - datetime.timedelta(seconds=5)
print(("GREEN|" if _new else "YELLOW|(不是本輪寫的舊冊)") + "輸出冊 · 基本資料 %d · 年度數據 %d 筆''')
# ① ⑪ 報告判決看三段:照驗證器自己的 rc 規則(基本資料 / 一標題四重點 任一欄 FAIL · 或年度數據有錯值列 fin_bad)· 讀不到報告 = 沒過
rep("""    } elseif ($vr) { $vok = -not ((Get-Content -Encoding UTF8 -LiteralPath $vlog -ErrorAction SilentlyContinue) -match '^\\[驗證\\] 年度數據 .*(FAIL|MISALIGNED|BADVALUE|BADITEM|SUBFAIL|TRANSFAIL|DUPKEY|QTRCOL|DUPROW)') }
""", """    } elseif ($vr) {
      # 啟動器 ⑪ 的報告:照驗證器自己的結束碼規則看三段(基本資料 / 一標題四重點 任一欄 FAIL · 年度數據錯值列 fin_bad)+ 日誌的 [FAIL] 行 · 讀不到 = 沒過
      $vok = $false
      try {
        $vj = Get-Content -Raw -Encoding UTF8 -LiteralPath $vr | ConvertFrom-Json
        if (-not $vj.version -or $null -eq $vj.basic -or $null -eq $vj.summary -or $null -eq $vj.fin_bad) { throw '報告缺欄位' }
        $nf = (@($vj.basic) + @($vj.summary) | Where-Object { $_ } | ForEach-Object { $_.checks.PSObject.Properties | Where-Object { "$($_.Value)" -like 'FAIL*' } } | Measure-Object).Count
        $nb = ($vj.fin_bad | Measure-Object).Count
        $lt = Get-Content -Encoding UTF8 -LiteralPath $vlog -ErrorAction SilentlyContinue
        $vok = ($nf -eq 0) -and ($nb -eq 0) -and -not ($lt -match '^\\s+\\[FAIL\\]') -and -not ($lt -match '^\\[驗證\\] 年度數據 .*(FAIL|MISALIGNED|BADVALUE|BADITEM|SUBFAIL|TRANSFAIL|DUPKEY|QTRCOL|DUPROW|HDRVAL|SECFAIL)')
        if (-not $vok) { Say YELLOW ("獨立驗證報告:基本資料 / 一標題四重點 FAIL 欄 {0} · 年度數據錯值 {1} 筆 · {2}" -f $nf, $nb, $vr) }
      } catch { Say YELLOW "獨立驗證報告讀不到或不完整($vr · $($_.Exception.Message))· 當作沒過" }
    }
""")
rep("""      if (($ve -join ' ') -match 'ModuleNotFoundError') { Say GRAY "獨立驗證跳過 · 缺 pdfplumber / pypdfium2(不補裝)" }""",
    """      if (($ve -join ' ') -match 'ModuleNotFoundError') { $vok = $null; Say GRAY "獨立驗證跳過 · 缺 pdfplumber / pypdfium2(不補裝)" }""")
# ③ 成功看本輪 ⑧ 完成燈 + 啟動器 rc + 驗證判決(啟動器 v0129 不論 ⑧ 都回 0)
rep("""    $d = [int]((Get-Date) - $t0).TotalSeconds
    Write-Host ("NEXT: {0} · 交接報告 {1} · 啟動器 rc {2} · {3} 秒" -f $(if ($rcL -eq 0) { 'VRN-2 v0129 跑完 · U/I 已開在「驗證過的輸出」· 把上面 [RED]/[YELLOW] 行 + ⑨ / ⑪ 兩行 + 驗證摘要貼回' } else { 'VRN-2 有紅燈 · 把貼包(≤300 行 · 結尾 NEXT)貼回' }), ([IO.Path]::Combine($R, 'docs', 'handoff', 'ai', 'VRN2_Handover_latest.md')), $rcL, $d) -ForegroundColor Cyan
""", """    $d = [int]((Get-Date) - $t0).TotalSeconds
    # 成功 = 啟動器 rc 0 且 本輪 ⑧ 完成燈綠(VRN2_Completion_latest.json 是本輪寫的 · 完成 · 紅 0)· 啟動器 v0129 不論 ⑧ 都回 0 → 不能只看 rc
    $ok8 = [bool]($sumOut | Where-Object { "$_" -like 'GREEN|⑧ 完成判定*' } | Select-Object -First 1)
    $lamp = if ($rcL -ne 0 -or -not $ok8) { 'RED' } elseif ($vok -eq $true) { 'GREEN' } else { 'YELLOW' }
    $msg = @{ RED = 'VRN-2 有紅燈(⑧ 完成判定不是本輪的綠 或 啟動器 rc 不是 0)· 把貼包(≤300 行 · 結尾 NEXT)貼回'
              GREEN = 'VRN-2 一鍵 v0130 跑完 · ⑧ 本輪完成 · 獨立驗證錯值 0 · U/I 已開在「驗證過的輸出」· 把 ⑨ / ⑪ 兩行 + 驗證摘要貼回'
              YELLOW = $(if ($vok -eq $false) { 'VRN-2 ⑧ 本輪完成 · 獨立驗證有待核對 → U/I「驗證過的輸出」看 ✗ 格 · 把驗證摘要貼回' } else { 'VRN-2 ⑧ 本輪完成 · 獨立驗證沒跑完 / 沒寫回 → 把 ⑪ 那行貼回' }) }[$lamp]
    Write-Host ("NEXT: [{0}] {1} · 交接報告 {2} · 啟動器 rc {3} · {4} 秒" -f $lamp, $msg, ([IO.Path]::Combine($R, 'docs', 'handoff', 'ai', 'VRN2_Handover_latest.md')), $rcL, $d) -ForegroundColor $(@{ RED = 'Red'; GREEN = 'Cyan'; YELLOW = 'Yellow' }[$lamp])
    $global:LASTEXITCODE = @{ GREEN = 0; YELLOW = 2; RED = 1 }[$lamp]
""")
rep("""    } elseif ($Verify) { Say GRAY "獨立驗證跳過 · 啟動器沒驗、也找不到落地的驗證器或輸出冊" }""",
    """    } elseif ($Verify -and ($fdNew -or -not (Test-Path -LiteralPath $fdj))) { Say GRAY "獨立驗證跳過 · 啟動器沒驗、也找不到落地的驗證器或輸出冊" }""")
open(S + "/Run-VRN2-v0130.ps1", "w", encoding="utf-8", newline="\n").write(ps)
print("ok", len(ps))
