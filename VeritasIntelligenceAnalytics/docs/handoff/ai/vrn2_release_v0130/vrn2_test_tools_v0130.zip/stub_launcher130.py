"""測試用假啟動器(只在 t130s 樹 · 由 pyshim130.sh 代替真啟動器跑):依 SCEN 造出啟動器 v0129 跑完後的幾種狀態 · 一律回 0(同 v0129 不論 ⑧ 都回 0)。"""
import datetime, json, os, shutil, sys, time
from pathlib import Path
T = Path(os.environ["T130"]); v2 = T / "VIA" / "VIA_Reports" / "vrn2"; pr = T / "pristine"; sc = os.environ["SCEN"]
for n in ("output", "verify_independent"):
    shutil.rmtree(v2 / n, ignore_errors=True); shutil.copytree(pr / n, v2 / n)
shutil.copy2(pr / "VRN2_Completion_latest.json", v2 / "VRN2_Completion_latest.json"); shutil.copy2(pr / "VRN2_UI_latest.html", v2 / "VRN2_UI_latest.html")
old = time.time() - 86400
for p in list((v2 / "output").rglob("*")) + list((v2 / "verify_independent").glob("*")):
    os.utime(p, (old, old))                                       # 先全部當上一輪的檔
src = sorted((v2 / "verify_independent").glob("VRN2_IndependentVerify_*.json"))[-1]
now = datetime.datetime.now()
print("[stub] 假啟動器 · 情境 %s" % sc, flush=True)
if sc != "stale":                                                 # ⑦ 本輪寫了輸出冊 + ⑧ 完成判定
    for p in (v2 / "output").glob("VRN2_*_latest.*"):
        os.utime(p, None)
    c = json.loads((v2 / "VRN2_Completion_latest.json").read_text(encoding="utf-8"))
    c["ts"] = now.isoformat(timespec="seconds")
    if sc == "red8":
        c["verdict"], c["red"] = "未完成", 1
    (v2 / "VRN2_Completion_latest.json").write_text(json.dumps(c, ensure_ascii=False, indent=1), encoding="utf-8")
    if sc == "noreport":                                         # ⑪ 沒跑(例:中斷)→ 一鍵 PS 自己驗本輪的冊
        print("[stub] 完成 · rc 0 · 沒有驗證報告", flush=True); sys.exit(0)
    rep = v2 / "verify_independent" / ("VRN2_IndependentVerify_%s.json" % now.strftime("%Y%m%d_%H%M%S"))
    j = json.loads(src.read_text(encoding="utf-8")); log = src.with_suffix(".txt").read_text(encoding="utf-8")
    if sc in ("basicfail", "basicfail_jsononly"):
        j["basic"][0]["checks"]["TICKER"] = "FAIL · 測試:代號不在檔名或首頁"
        if sc == "basicfail":
            log = log.replace("[驗證] 一標題四重點", "  [FAIL] %s · TICKER FAIL · 測試\n[驗證] 一標題四重點" % j["basic"][0]["FILENAME"][:40], 1)
    if sc == "summaryfail":
        j["summary"][1]["checks"]["POINT_2"] = "FAIL · 測試:重點不在原文"
        log = log.replace("[驗證] 年度數據", "  [FAIL] %s · POINT_2 FAIL · 測試\n[驗證] 年度數據" % j["summary"][1]["FILENAME"][:40], 1)
    txt = json.dumps(j, ensure_ascii=False, indent=1)
    rep.write_text(txt[: len(txt) // 2] if sc == "corrupt" else txt, encoding="utf-8")
    rep.with_suffix(".txt").write_text(log, encoding="utf-8")
    shutil.copy2(str(src) + ".digest.txt", str(rep) + ".digest.txt")
print("[stub] 完成 · rc 0", flush=True)
sys.exit(0)
