#!/bin/bash
# $1 = 版本(0129 / 0130)· $2 = 情境 → 日誌 st130/<情境>_v<版本>.log
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; T=$S/t130s
cd "$T/Downloads" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" T130="$T" SCEN="$2" PYTHONDONTWRITEBYTECODE=1 \
  VRN2_ROOT="$T/VIA" VRN2_LAUNCHER="$T/Downloads/ActivateVRN-2.py" VRN2_PY="$S/tools/pyshim130.sh" VRN2_LAUNCHER_ARGS="--no-install" \
  timeout 900 "$S/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -File "$T/code_v$1.ps1" > "$S/st130/$2_v$1.log" 2>&1
sed -i 's/\x1b\[[0-9;]*m//g' "$S/st130/$2_v$1.log"
