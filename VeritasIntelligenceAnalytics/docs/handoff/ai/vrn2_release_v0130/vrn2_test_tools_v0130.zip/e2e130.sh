#!/bin/bash
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
for m in branch main; do
  T=$S/t130$m; $S/tools/scen130u.sh $T $m > $S/st130/e2e_$m.setup.log 2>&1
  for i in 1 2; do $S/tools/run_boot_test130.sh $T > $S/st130/e2e_${m}_run$i.log 2>&1; sed -i 's/\x1b\[[0-9;]*m//g' $S/st130/e2e_${m}_run$i.log; done
done
echo done > $S/st130/e2e.done
