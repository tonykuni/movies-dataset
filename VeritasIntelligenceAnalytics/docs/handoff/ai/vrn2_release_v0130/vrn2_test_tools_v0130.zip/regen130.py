"""一鍵 v0130 md / 一行重算(冪等):程式碼區塊 = Run-VRN2-v0130.ps1 · 一行 = boot130.ps1(-EncodedCommand · 分支讀不到 → main)· 啟動器仍是 v0129(雜湊不變)。"""
import base64, hashlib, re
S = "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"
sha = lambda t: hashlib.sha256(t.encode("utf-8")).hexdigest()
ps = open(S + "/Run-VRN2-v0130.ps1", encoding="utf-8").read().rstrip("\n")
want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1)
cs = sha(ps)
boot = r"""$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$R  = if ($env:VRN2_ROOT) { $env:VRN2_ROOT } else { 'C:\Users\tonyk\OneDrive\Documents\movies-dataset\VeritasIntelligenceAnalytics' }
$Br = 'claude/optimistic-goodall-yhalc5'
$P  = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0130'
$H  = '@CS@'
Write-Host ('[VRN-2] PowerShell ' + $PSVersionTable.PSVersion + ' · 從 GitHub 讀一鍵 v0130 程式碼(核對 SHA-256 後執行)') -ForegroundColor Yellow
$top = git -C $R rev-parse --show-toplevel 2>$null
if (-not $top) { Write-Host "[RED] $R 不是 git 倉或找不到 git" -ForegroundColor Red; return }
$top = "$top".Trim()
$t = Join-Path ([IO.Path]::GetTempPath()) ('vrn2_boot_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Force -Path $t | Out-Null
$z = Join-Path $t 'oneclick.zip'; $okz = $false
foreach ($b in $Br, 'main') {
  foreach ($w in 0, 2, 4, 8, 16) { if ($w) { Start-Sleep -Seconds $w }; git -C $top fetch -q origin $b 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { break } }
  git -C $top archive --format=zip -o $z ('origin/' + $b + ':' + $P) VRN2_OneClick_v0130.md 2>&1 | Out-Null
  if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $z)) { $okz = $true; Write-Host ('[計] 一鍵程式碼來源 GitHub ' + $b) -ForegroundColor DarkGray; break }
}
if (-not $okz) { Write-Host "[RED] 讀不到 GitHub 分支 $Br 或 main 的一鍵程式碼(網路 / git)" -ForegroundColor Red; return }
Expand-Archive -LiteralPath $z -DestinationPath $t -Force
$md = [IO.File]::ReadAllText((Join-Path $t 'VRN2_OneClick_v0130.md'), [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code = [regex]::Match($md, '(?s)```powershell\n(.*?)\n```').Groups[1].Value
$sha = -join ([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($code)) | ForEach-Object { $_.ToString('x2') })
if ($sha -ne $H) { Write-Host "[RED] 一鍵程式碼 SHA-256 不對($sha)· 不執行" -ForegroundColor Red; return }
Write-Host ('[GREEN] 一鍵程式碼 SHA-256 ' + $H.Substring(0, 12) + ' 相符 → 在 PowerShell 裡執行') -ForegroundColor Green
& ([scriptblock]::Create($code))
""".replace("@CS@", cs)
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii")
assert len(one) < 8191, len(one)
md = """# VRN-2 一鍵 v0130(cmd / PowerShell 都能貼 · 啟動器 v0129 不變 · 判定改正三處)

v0130 只改一鍵 PowerShell 的**判定**(PR #534 的 Codex 審查三處 · 啟動器 `ActivateVRN-2.py` 仍是 **v0129**,SHA-256 `@WANT@`,從 `vrn2_release_v0129` 取):

| # | v0129 的問題 | v0130 |
|---|---|---|
| 1 | 啟動器 ⑪ 的驗證報告只掃「年度數據」那一行 → 基本資料 / 一標題四重點有 `FAIL` 也印綠「錯值 0」 | 讀報告 JSON,照驗證器自己的結束碼規則看**三段**:基本資料 / 一標題四重點任一欄 `FAIL*` · 年度數據錯值列 `fin_bad`(+ 日誌的 `[FAIL]` 行與錯值類別)· 報告讀不到或缺欄位 = **沒過** |
| 2 | 啟動器本輪沒驗證報告時,PS 拿**任何**舊的 `VRN2_FinancialData_latest.json` 來驗 → 上一輪的判決蓋上本輪時間、寫進 U/I | 輸出冊是**本輪寫的**(修改時間 ≥ 開始 − 5 秒 · 與啟動器 ⑪ 同一門檻)才驗;舊冊 → 黃「不驗舊冊、不把舊冊判決寫進 U/I」· 摘要的輸出冊行也標「不是本輪寫的舊冊」 |
| 3 | 啟動器 v0129 不論 ⑧ 都回 0 → 一鍵只看 rc 就宣告「跑完」 | 成功 = 啟動器 rc 0 **且** 本輪 ⑧ 完成燈綠(`VRN2_Completion_latest.json` 本輪寫的 · 完成 · 紅 0)· 結尾 `NEXT: [GREEN/YELLOW/RED]` · `$LASTEXITCODE` 0 綠 / 2 黃(驗證有待核對或沒跑完)/ 1 紅 |

其他照 v0129(③ 取得啟動器:分支讀不到改讀 `main`;本機已是 v0129 就不連網 · ③b 定位 · ④ 啟動器 ①~⑪ · ⑤ 摘要)。容器實測見 `VRN2_Verification_v0130.md`。

開關:檔頭 `$NoPush = $true` 只實測不上船 · `$Verify = $false` 啟動器沒驗到時 PS 也不補驗 · `$env:VIA_VRN2_NO_VERIFY = '1'` 啟動器不跑 ⑪ · `$env:VRN2_VERIFY_PAR = '2'` 驗證平行路數 · `$env:VIA_VRN2_VERIFY_WAIT = '3600'` ⑪ 等待上限(秒)。

## 在「命令提示字元(cmd)」或 PowerShell 都能貼的一行(建議用這個)

這一行在 cmd 或 PowerShell 貼上都可以:它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)讀本檔的一鍵程式碼 → **核對 SHA-256 `@CS@`** → 相符才在 PowerShell 裡執行(不相符就停 · 不執行)。內容是本檔最後「一行的原始碼」用 UTF-16LE 編成 Base64(`-EncodedCommand`)。**不要把下面整段程式碼貼進 cmd**(cmd 不認得 PowerShell)。

```bat
@ONE@
```

或:在 cmd 先輸入 `powershell` 按 Enter(提示字元變成 `PS C:\\Users\\tonyk>`),再貼下面整段程式碼。

程式碼 SHA-256(本文 · 一行核對的就是這個):`@CS12@`

```powershell
@PS@
```

## 一行的原始碼(`-EncodedCommand` 解碼後 · 只讀取並核對 · 不改任何檔)

```text
@BOOT@
```
"""
md = md.replace("@WANT@", want).replace("@CS12@", cs[:12]).replace("@CS@", cs).replace("@ONE@", one).replace("@BOOT@", boot.rstrip("\n")).replace("@PS@", ps)
FENCE = r"(?s)```powershell\n(.*?)\n```"
assert re.search(FENCE, md).group(1) == ps and md.count("```powershell\n") == 1
assert base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot
assert re.search(r"(?s)```text\n(.*?)\n```", md).group(1) == boot.rstrip("\n")
open(S + "/release130/VRN2_OneClick_v0130.md", "w", encoding="utf-8", newline="\n").write(md)
open(S + "/boot127/boot130.ps1", "w", encoding="utf-8", newline="\n").write(boot)
open(S + "/boot127/oneline130.txt", "w").write(one + "\n")
print("launcher %s · code %s · one-liner %d 字 · md %d" % (want[:12], cs[:12], len(one), len(md)))
