#!/bin/bash
# 測試用 python:第一個參數是啟動器 → 跑假啟動器;其他照常用 venv_vrn2 的 python
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
if [ "$1" = "$VRN2_LAUNCHER" ]; then shift; exec python3 "$S/tools/stub_launcher130.py" "$@"; fi
exec "$S/venv_vrn2/bin/python" "$@"
