#!/bin/bash
# 使用者機器情境(同 scen129u):上次成功 v0125 · Downloads 已被 v0127 一行換成 v0127 · VIA_ROOT 指錯 · $2 = branch(發行放分支)或 main(分支不在 · 發行在 main)· $1 = 樹
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
T="$1"; MODE="$2"
cd /tmp && $S/tools/mktree.sh $T $S/new/ActivateVRN-2_v0125.py 2>&1 | grep -v -e negotiat -e acknowledg
PY=$S/venv_vrn2/bin/python $S/tools/runl.sh $T > $T.pre_v0125.log 2>&1; sed -i 's/\x1b\[[0-9;]*m//g' $T.pre_v0125.log
cp $S/new/ActivateVRN-2_v0127.py $T/Downloads/ActivateVRN-2.py
B=$T.br; rm -rf $B
if [ "$MODE" = main ]; then git clone -q -b main $T/remote.git $B >/dev/null 2>&1; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai; else mkdir -p $B; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai; fi
mkdir -p $D/vrn2_release_v0129 $D/vrn2_release_v0130
cp $S/release129/ActivateVRN-2_v0129.zip $S/release129/VRN2_Release_v0129.json $S/release129/VRN2_OneClick_v0129.md $D/vrn2_release_v0129/
cp $S/release130/VRN2_OneClick_v0130.md $D/vrn2_release_v0130/
if [ "$MODE" = main ]; then
  cd $B && git add -A && git -c user.email=o@o -c user.name=o commit -qm "release on main(合併後 · 分支已刪)" && git push -q origin main >/dev/null 2>&1
else
  cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1
fi
echo "scenario ok($MODE)· $(grep -E '→ GREEN ⑨' $T.pre_v0125.log | cut -c1-60) · Downloads = $(grep -o 'VERSION = "ActivateVRN-2 v[0-9]*"' $T/Downloads/ActivateVRN-2.py) · remote heads: $(git -C $T/remote.git for-each-ref --format='%(refname:short)' refs/heads | tr '\n' ' ')"
