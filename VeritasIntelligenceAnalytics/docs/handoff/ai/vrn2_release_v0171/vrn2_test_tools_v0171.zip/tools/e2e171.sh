#!/bin/bash
# v0170 e2e(RoundAll v0126 · Handle-All v0118 · 套件 v0170:Workbench v0105 + ConsensusJoin v0106):沙盒(桌機 v0153 狀態 + 髒增量庫)+ 三份原文(只在沙盒)
# + 合成共識快照(consensus/factset_yfinance_consensus_matrix.csv · 形狀同引擎矩陣 · 數字合成 · ASOF 2026-11-01)
# → auto(收據 v0153 < v0170 → 整輪 · 啟動器 v0170 · ⑥f 閘未開 DENY → v0106 快照補位 → Combined 共識欄有值 → Workbench v0105)
# → --confirm list → auto 第二次(收據 v0170 → repair)→ 竄改不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v171; W4=/home/user/vrn2_work/v164; T=$W/t171a; P=$S2/venv_vrn2/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
REL=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
cp /home/user/vrn2_work/v165/pdfs/daiwa6278.pdf "$T/samples/Daiwa-6278 20260521.pdf"; cp /home/user/vrn2_work/v165/pdfs/ctbc3264.pdf "$T/samples/欣銓(3264,B_買進)-CTBC260918.pdf"; cp /home/user/vrn2_work/v168/pdfs/hn6143.pdf "$T/samples/華南投顧-6143-振曜-1141128.pdf"; for f in "$T/VIA/VIA_Reports/vrn2/VRN2_Input_latest.json" "$T/VIA/functional modules/VRN2/SSOT/"*.json; do sed -i "s|$S/v153/t153d/samples|$T/samples|g; s|$S/v151/t151/samples|$T/samples|g" "$f"; done
$P -I $W4/seed164.py $T $W4/rt > $W/seed171.log 2>&1; tail -2 $W/seed171.log
$P - "$T" <<'PYEOF' >> $W/seed171.log 2>&1
# 合成共識快照:沙盒 BasicInfo 前 6 檔代號 · 形狀同引擎矩陣 · 數字合成(不是任何原文 / 桌機值)· ASOF = 台北 2026-11-01
import csv, json, re, sys
from pathlib import Path
v2 = Path(sys.argv[1]) / "VIA" / "VIA_Reports" / "vrn2"
basic = json.loads((v2 / "output" / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
codes = []
for r in basic if isinstance(basic, list) else []:
    c = str(r.get("TICKER") or r.get("ticker") or "").strip()
    if re.fullmatch(r"[1-9]\d{3}", c) and c not in codes:
        codes.append(c)
codes = codes[:6]
head = ["code", "symbol", "company_name", "fetched_at_utc", "current_price", "target_median", "target_mean", "target_analyst_count", "target_rate_date",
        "yf_target_median", "yf_target_mean", "yf_target_analyst_count", "yf_current_price", "eps_2026_median", "eps_2026_forward_pe", "source_agreement_gate", "source_page", "source_yfinance"]
out = v2 / "consensus"
out.mkdir(parents=True, exist_ok=True)
with (out / "factset_yfinance_consensus_matrix.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(head)
    for i, c in enumerate(codes):
        base = 100.0 + 10 * i
        w.writerow([c, "TWS:%s:STOCK" % c, "合成快照%d" % i, "2026-11-01T01:19:00+00:00", base, round(base * 1.2, 2), round(base * 1.21, 2), 5 + i,
                    "2026-10-30", round(base * 1.1, 2), round(base * 1.12, 2), 7 + i, base, round(9.5 + i, 2), round(14.0 + i, 2), "PASS", "https://example.invalid/%s" % c, "yfinance"])
print("seed snapshot codes", codes)
PYEOF
B=$T.br; D0=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170; D1=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0171; mkdir -p $D0 $D1
cp $REL/vrn2_release_v0170/VRN2_Release_v0170.json $REL/vrn2_release_v0170/VRN2_Closeout_v0170.zip $D0/
cp $W/release171/VRN2_RoundAll_v0127.py $W/release171/VRN2_RoundAll_v0127.md $W/release171/VRN2_HandleAll_v0119.md $W/release171/VRN2_HandleAll_v0119_boot.txt $W/release171/VRN2_Release_v0171.json $D1/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release171/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2)
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 6000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny171.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; cp -a $V2/output $W/out_$N 2>/dev/null; cp $V2/VRN2_Workbench_latest.html $W/wb_$N.html 2>/dev/null; cp $V2/consensus/VRN2_Consensus_latest.json $W/cons_$N.json 2>/dev/null; }
rm -rf "${W:?}/out_auto1" "${W:?}/out_auto2" "${W:?}/out_tamper"; rm -f $W/tiny171.rc
run auto1
RA=$T/home/Downloads/VRN2_RoundAll_v0127.py
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm list > $W/confirm_list.log 2>&1; echo "confirm list rc $?" >> $W/tiny171.rc
run auto2
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0171/VRN2_HandleAll_v0119_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny171.rc
