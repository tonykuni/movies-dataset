"""VRN2_RoundAll_v0127.py = 本線 v0126(倉裡 vrn2_release_v0170)+ 貼回包逐檔清單去重(移植已合併 PR #585 另一線 v0126 的修法 · 防沿用前版收據時同名寫兩次)。
套件仍是 v0170(雜湊照釘)。版號說明:v0126 兩條線相撞(main 的 vrn2_release_v0169 有另一線的 VRN2_RoundAll_v0126.py · 套件 v0169),
本線下一版直接取 v0127(兩線都沒用過);此後出任何 VRN-2 版號前先查本分支與 main 兩邊。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v171")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0170/VRN2_RoundAll_v0126.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0126')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0126 — ', '"""VRN2_RoundAll v0127 — ', 1)
at = doc.index("v0126(")
doc = doc[:at] + '''v0127(操作員 2026-11-02:「很多問題昨天就已經解決但又出現了 · 查 GITHUB 已經整合的 PR 將問題全部解決」· 桌機 15:18 v0170 整輪
  閘開 · ⑥f 真抓 41/41 · Combined 共識欄補滿 · Workbench v0105 over v0104 · 收尾 REVIEW(VRN-2 0 · VCGC 0 · 人工 1 · 資料源 3)):
  · 根因(為什麼「又出現」):VRN-2 有兩條工作線,v0124 之後各自編號 —— main(經 PR #584 / #585 併入)的 VRN2_RoundAll_v0124–v0126 /
    Handle-All v0116–v0118 / runtime v0160 / 套件 v0169 是另一線(Workbench v0103 / v0104 · 印章 logo)的正本,與本線同名不同內容;
    桌機倉又落後 GitHub 甚多(另一線收尾報告:719 個提交 · pull --ff-only 一直不成功),已合併的修正到不了桌機本地樹。
  · 本輪:origin/main 已整併進本分支(衝突一律保留本線正本 · 另一線與 VDF / VCGC 檔原樣帶入);本檔移植另一線 v0126 的
    貼回包逐檔清單去重(先後照舊 · 防沿用前版收據時同名寫兩次 UserWarning: Duplicate name);其他一字不改 · 套件照舊 v0170(雜湊照釘)。
  · 版號規則(交接 v0172 也記):出任何 VRN-2 新版號前先查本分支與 main;本線 RoundAll 下一版 v0128+ · Handle-All v0120+ ·
    Workbench v0107+(桌機加速器已自動生成 v0106 = v0105 + 標記;新版要自帶 [VIA:ACCEL-BRIDGE:v0111] 標記)· runtime 下一版 v0162+。
  · 自測 94 項(v0126 的 93 項 + 92)。共用 MarketFetch 與 VDF 引擎照舊只讀不改。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0126.py", "用法:python VRN2_RoundAll_v0127.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0126"', 'VERSION = "v0127"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0126.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0126.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0127.py"', n_dl)
rep('"VRN2_RoundAll_v0126.py" in html_', '"VRN2_RoundAll_v0127.py" in html_')
rep("· v0125 起 91 項 · v0126 起 93 項。", "· v0125 起 91 項 · v0126 起 93 項 · v0127 起 94 項。")
rep('''            for rel in PASTE_FILES + extra:''',
    '''            for rel in dict.fromkeys(PASTE_FILES + extra):                 # v0127 逐檔清單去重(先後照舊 · 移植已合併 PR #585 另一線 v0126 的修法)''')
rep('''        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''',
    '''        import warnings as _w92
        with tempfile.TemporaryDirectory() as td92:
            v92 = Path(td92) / "VIA_Reports" / "vrn2"
            v92.mkdir(parents=True)
            (v92 / RECEIPT).write_text("{}", encoding="utf-8")
            (v92 / "VRN2_RoundAll_latest.json").write_text("{}", encoding="utf-8")
            t92 = Path(td92) / "t.txt"
            t92.write_text("x", encoding="utf-8")
            pf92 = globals()["PASTE_FILES"]
            globals()["PASTE_FILES"] = ("VRN2_RoundAll_latest.json", "VRN2_RoundAll_latest.json", RECEIPT)   # 人為重複(重現另一線 04:24 的 Duplicate name 形狀)
            try:
                with _w92.catch_warnings(record=True) as warns92:
                    _w92.simplefilter("always")
                    zp92 = step_pasteback(Path(td92), t92, Path(td92) / "pb.zip")
            finally:
                globals()["PASTE_FILES"] = pf92
            with zipfile.ZipFile(zp92) as z92:
                names92 = z92.namelist()
        chk("92 v0127:貼回包逐檔清單去重(先後照舊)· 人為重複也只寫一次 · 無 Duplicate name 警告(移植已合併 PR #585 另一線 v0126 的修法)",
            names92.count("vrn2/VRN2_RoundAll_latest.json") == 1 and names92.count("vrn2/" + RECEIPT) == 1
            and not [w for w in warns92 if "Duplicate name" in str(w.message)])
        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''')
out = W / "new"
out.mkdir(exist_ok=True)
(out / "VRN2_RoundAll_v0127.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0127 lines", s.count("\n"))
