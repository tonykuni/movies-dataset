"""v0171 收尾:驗證紀錄 · 交接 v0172(從 v0171 抄 · 只增 · 兩線版號對照)· 放進倉 vrn2_release_v0171 · logs / 工具 zip。桌機主控台的值不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v171"); rel = W / "release171"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


R = json.loads((rel / "VRN2_Release_v0171.json").read_text(encoding="utf-8"))
H = R["handleall"]
ra = [l for l in lines(W / "rall127_selftest.log") if re.search(r"^\[PASS\] 92 |^\[FAIL\]|--selftest · ", l)]
assert any("94 項 · 不過 0" in l for l in ra), ra[-1:]
ps = json.loads((W / "pscheck171.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
assert [x["e"] for x in ps] == [0, 0, 0, 0, 0] and ps[0]["h"] == ps[1]["h"] and ps[2]["h"] == ps[3]["h"]
rc = [l for l in lines(W / "tiny171.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
states = {}
for n in ("auto1", "auto2"):
    d = json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))
    states[n] = {"state": d["state"], "per_owner": d["per_owner"]}
with zipfile.ZipFile(sorted((W / "t171a/home/Downloads").glob("VRN2_PasteBack_*.zip"))[-1]) as z:
    names = z.namelist()
assert len(names) == len(set(names)), "貼回包有重複名"
wb1 = (W / "wb_auto1.html").read_text(encoding="utf-8")
assert wb1.count('id="wb105"') == 1
R["results"] = {"roundall_v0127_selftest": ra[-1:], "pwsh_parse": pparse, "e2e_rc": rc, "closeout_states": states,
                "pasteback_names_unique": True,
                "merge": "origin/main(PR #578–#585)merged into this branch · 19 conflicts all resolved keeping this line's published artifacts · 0 files deleted · this line's vrn2_release_v0170 untouched",
                "not_run": "the desktop itself (one line · auto = repair, minutes) · the operator's own --confirm (H-fd2ea35f) · the desktop repo sync (shared repo matter; one-liner in main VRN2_Handover_latest.md section 13)"}
(rel / "VRN2_Release_v0171.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0171 驗證紀錄(2026-11-02 · 已合併 PR 整併 · 兩線版號對照 · 貼回包去重 · 套件 v0170 不動 · RoundAll v0127 · Handle-All v0119)

## 1. 桌機 2026-11-02 15:18(v0170 整輪 · 閘開)——「開閘共識欄」做到了

| 項目 | 結果 |
|---|---|
| ⑥f 共識 | 真抓 **41 / 41**(兩輪重試後,只剩 404 的 4171 / 6933 依 v0102 規則不納入閘 → PASS_WITH_WARNINGS)· rc 0 |
| Combined 共識欄 | 52 列:FactSet 中位數 **49** · Yahoo 中位數 **48** · 調整後目標價 42 · EPS 格 137(空格全是來源面:404 兩檔 · AAPL 非台股 · 原文沒目標價)|
| Workbench | **v0105(前版 v0104)** 渲染成功 —— 動態前版尾在桌機接上另一線的 v0104,緊湊 / 白字 / 欄寬自動 / 資料驗證燈 / 共識面板都上線 |
| 快照補位 | 這輪**用不到**(閘開 · 真抓);它仍是閘關輪次的後備 |
| 收尾 | REVIEW · **VRN-2 0 · VCGC 0** · 人工 1(MQ-1560 四點 `--confirm H-fd2ea35f`)· 資料源 3(VDF rc 2 PARTIAL · 404 / AAPL / 原文沒目標價)|

## 2. 「很多問題昨天就已經解決但又出現了」——全景根因

1. **VRN-2 有兩條工作線,v0124 之後各自編號。** main(經 PR #584 / #585 併入 · 分支 claude/vrn2-closeout-authorization-y4ixl7)上的
   `VRN2_RoundAll_v0124–v0126`、`Handle-All v0116–v0118`、`runtime v0160`、`套件 v0169` 是**另一線**(Workbench v0103 / v0104 ·
   VeritasReportNova 標題 · 印章 logo)的正本——跟本線**同名不同內容**。兩線各修各的,操作員貼到哪一線的一行,就只帶那一線的修法
   → 另一線已解決的,換線跑就「又出現」(例:Handle-All REVIEW 顏色紅字,本線 v0116 修過、另一線 v0117 當時還沒修,04:24 跑到另一線的就又見到)。
2. **桌機倉落後 GitHub 甚多**(另一線收尾報告原文:719 個提交 · 另有 2 個沒推 · `pull --ff-only` 一直不成功)→ 已合併的 VDF / VCGC /
   Workbench 修正到不了桌機本地樹(VDF 尾版停在 v0162,GitHub 已 v0166+)→ VDF 紅字(04:35 rc 1)這類問題反覆出現。
   本線取檔用 `git fetch + git show`(不靠本地樹)所以不受影響。

## 3. 本輪整併(操作員:「查 GITHUB 已經整合的 PR 將問題全部解決」)

- **origin/main 併入本分支**(commit 見 git log):19 個衝突(本線 v0168 / v0169 發行夾 + 交接 v0169 / v0170 被另一線同名改寫)
  **一律保留本線正本**;另一線的檔(含 Workbench v0103 / v0104 原始碼 · 套件 v0169 · SettleAll v0100 / v0101 · FreezeLock v0100–v0103)
  與 VDF / VCGC 的已合併修正**原樣帶入** · 刪 0 檔 · 本線 vrn2_release_v0170 未動。
- **RoundAll v0127**:移植另一線 v0126 的貼回包逐檔去重(先後照舊 · 防 Duplicate name 警告)· 版號直接跳過兩線相撞的 v0126 · 自測 94 項全過。
- **Handle-All v0119**:指到 v0127 · 其餘不動。套件 v0170 不動(雜湊照釘)。
- **版號規則(以後都照)**:出任何 VRN-2 新版號前先查本分支與 main 兩邊;本線下一版 RoundAll v0128+ · Handle-All v0120+ ·
  **Workbench v0107+**(桌機加速器已自動生成 v0106 = v0105 + 標記;本線新版要自帶 `[VIA:ACCEL-BRIDGE:v0111]` 標記)· runtime v0162+。
- 另一線 v0104 的 `render(root, out_path, logo, assets_zip)` 簽章與本線 v0102 相同(已從 main 取原始碼核對;桌機 15:18 實跑也已證明)。

## 4. 測試

| 項目 | 結果 |
|---|---|
| RoundAll v0127 自測 | %s |
| PowerShell 剖析 | %s |
| e2e(最短一行 · 沙盒)| %s · auto 整輪 → repair → 竄改開機檔不執行 · 收尾狀態 %s · 貼回包檔名無重複 · Workbench v0105 面板在 |

## 5. 桌機下一步(收尾只剩兩件 · 都在操作員手上)

1. 貼 `vrn2_release_v0171/VRN2_HandleAll_v0119.md` 的最短一行(auto = repair · 幾分鐘)→ 收尾頁應維持 REVIEW(VRN-2 0 · VCGC 0)。
2. 看過 MQ-1560 原圖四點後:`python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0127.py" --confirm H-fd2ea35f --note "…"`(只有操作員打才算)
   → 收尾轉 **DATA_GAP(只剩資料源)= VRN-2 側終點**。
3. (共用倉 · 非 VRN-2)桌機要吃到已合併的 VDF / VCGC 修正:照 main `VRN2_Handover_latest.md` 第 13 節 SettleAll v0101 的一行做合併式同步。

## 6. 沒做 / 待辦

- 操作員的 `--confirm` 不代打(v0165 規則)· 同意閘不代設。
- 3014TT 四點(第 2 點從句中開始 · 第 1 / 3 點重複)與 MQ-1560 OCR 字詞錯(chi players 應為 chip layers)照舊等操作員點頭(要改摘要器 + 整輪)。
""" % (" · ".join(x[:90] for x in ra[-1:]), pparse, " · ".join(rc), json.dumps(states, ensure_ascii=False))
(rel / "VRN2_Verification_v0171.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0171.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0170 + VRN2_RoundAll_v0126 + VRN2_HandleAll_v0118 · 2026-11-02(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0170 + VRN2_RoundAll_v0127 + VRN2_HandleAll_v0119 · 2026-11-02(已合併 PR 整併 · 兩線版號對照 · "
        "桌機 15:18 閘開整輪:共識欄補滿 · Workbench v0105 over v0104 · 收尾 REVIEW:VRN-2 0 · VCGC 0)")
src = "\n".join(L)
once("> **本輪(v0170)**",
     "> **本輪(v0171)**:桌機 15:18 跑 v0170 整輪(閘開):⑥f 真抓 41/41 · Combined 共識欄補滿(FactSet 49 · Yahoo 48)· Workbench v0105(前版 v0104)· "
     "收尾 REVIEW(VRN-2 0 · VCGC 0 · 人工 1 = MQ-1560 四點 `--confirm H-fd2ea35f` · 資料源 3)。操作員:「很多問題昨天就已經解決但又出現了 · 查 GITHUB 已經整合的 PR」→ "
     "根因 = **兩條 VRN-2 線 v0124 後各自編號**(main 經 PR #584/#585 載另一線的 RoundAll v0124–v0126 / Handle-All v0116–v0118 / runtime v0160 / 套件 v0169 · 同名不同內容)+ "
     "**桌機倉落後 main 甚多**(另一線報告:719 個提交 · pull --ff-only 不成功 → 已合併的 VDF/VCGC/Workbench 修正到不了桌機)。本輪:origin/main 併入本分支(衝突保留本線正本 · 刪 0 檔)· "
     "**RoundAll v0127**(貼回去重 · 移植 PR #585 另一線修法 · 版號跳過相撞的 v0126 · 自測 94)· **Handle-All v0119** · 套件 v0170 不動。\n"
     "> **本輪(v0170)**")
r170 = json.loads((REPO / "vrn2_release_v0170/VRN2_Release_v0170.json").read_text(encoding="utf-8"))
once("| **VRN2_HandleAll_v0118.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0118** | `vrn2_release_v0170` |",
     "| **VRN2_HandleAll_v0119.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0119** | `vrn2_release_v0171` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0127)|\n"
     "| **VRN2_RoundAll_v0127.py**(發行夾 · 一支入口 · 不在套件內)| **v0127** | `vrn2_release_v0171` | `%s` | **新**(貼回去重 · 版號跳過兩線相撞的 v0126 · 自測 94 項 · 套件 v0170 照釘)|\n"
     "| **VRN2_HandleAll_v0118.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0118** | `vrn2_release_v0170` |"
     % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12]))
once("| 0 | **(v0170)**",
     "| 0 | **(v0171)** 貼 `vrn2_release_v0171/VRN2_HandleAll_v0119.md` 的最短一行(auto = repair · 幾分鐘)→ 收尾應 REVIEW(VRN-2 0 · VCGC 0)· MQ-1560 四點看過原圖後操作員自己打 "
     "`python \"%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0127.py\" --confirm H-fd2ea35f --note \"…\"` → DATA_GAP = VRN-2 側終點 · 桌機吃 VDF / VCGC 已合併修正:main `VRN2_Handover_latest.md` 第 13 節 SettleAll v0101 一行(共用倉 · 非 VRN-2)| 貼回 / 人工 |\n"
     "| 0 | **(v0170)**")
once("**v0170(2026-11-02)**:", "**v0171(2026-11-02)**:桌機 15:18 閘開整輪(共識欄補滿 · Workbench v0105 over v0104)→ 操作員「問題又出現 · 查已合併 PR」→ origin/main 併入(兩線對照 · 衝突保留本線)· RoundAll v0127(貼回去重)· Handle-All v0119 · 套件 v0170 不動。\n\n**v0170(2026-11-02)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0171)** **VRN-2 有兩條工作線 · 版號先查兩邊再出**:main(PR #584 / #585 · 分支 claude/vrn2-closeout-authorization-y4ixl7)的 RoundAll v0124–v0126 /"
     " Handle-All v0116–v0118 / runtime v0160 / 套件 v0169 / 啟動器 v0169 是另一線的正本(Workbench v0103 / v0104 · 印章 logo),與本線同名不同內容。"
     "本線已把 origin/main 併進來(衝突保留本線正本 · 另一線檔在 vrn2_release_v0169 夾內原樣保留);本線下一版:RoundAll v0128+ · Handle-All v0120+ · "
     "Workbench v0107+(帶 [VIA:ACCEL-BRIDGE:v0111] 標記 · 桌機加速器已自動生成 v0106 = v0105 + 標記)· runtime v0162+ · 出號前先查本分支與 main。\n"
     "- **(v0171)** **「已解決又出現」先想兩個根因**:① 兩線同名不同內容(對方修了自己那線 · 你貼的是另一線的一行);② 桌機倉落後 main(pull --ff-only 失敗 → "
     "已合併修正到不了本地樹;本線取檔 git fetch + git show 不受影響,但 VDF / VCGC / Workbench 資產讀本地樹會)。桌機同步一行在 main VRN2_Handover_latest.md 第 13 節(SettleAll v0101 · 共用倉的事)。\n\n")
(REPO / "VRN2_Handover_v0172.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0171"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0127.py", "VRN2_RoundAll_v0127.md", "VRN2_HandleAll_v0119.md", "VRN2_HandleAll_v0119_boot.txt", "VRN2_Release_v0171.json", "VRN2_Verification_v0171.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 2, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t171a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0171.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall127_selftest.log", "pscheck171.log", "tiny171.rc", "seed171.log", "confirm_list.log")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0171.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall127.py", "build171.py", "finalize171.py", "e2e171.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0172", src.count("\n"))
