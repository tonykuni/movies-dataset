"""v0171(冪等):套件 v0170 不動(雜湊照釘)→ RoundAll v0127(貼回去重 · 版號跳開兩線相撞區)→ Handle-All v0119(指到 v0127)
→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0171)。vrn2_release_v0170 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v171"); rel = W / "release171"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v170/release170")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0170/VRN2_Release_v0170.json").read_text(encoding="utf-8"))
want = r170["package"]["sha256"]
ra = (W / "new/VRN2_RoundAll_v0127.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0170"' in ra and 'VERSION = "v0127"' in ra
assert 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170"' in ra            # 套件 zip 照舊從 v0170 發行夾取
(rel / "VRN2_RoundAll_v0127.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0171'")
rep("$F = 'VRN2_RoundAll_v0126.py'", "$F = 'VRN2_RoundAll_v0127.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0118", "Handle-All v0119", ha.count("Handle-All v0118"))
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if re.search(r"Handle-All v0118|v0126\.py", l) and not l.lstrip().startswith("#")]
assert re.search(r"\$col = @\{[^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0170", "vrn2_release_v0171"), ("VRN2_HandleAll_v0118.md", "VRN2_HandleAll_v0119.md"), ("Handle-All v0118 SHA-256 OK", "Handle-All v0119 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0119_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0171/VRN2_HandleAll_v0119_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0119(2026-11-02 · 已合併 PR 整併 · 兩線版號對照 · 貼回包去重 · 套件 v0170 不動 · RoundAll v0127)

桌機 2026-11-02 15:18(v0170 整輪 · 閘開):**⑥f 真抓 41 / 41 · Combined 共識欄補滿(FactSet 中位數 49 · Yahoo 48)· Workbench v0105(前版 v0104)· 收尾 REVIEW(VRN-2 0 · VCGC 0 · 人工 1 · 資料源 3)**。

操作員:「很多問題昨天就已經解決但又出現了 · 查 GITHUB 已經整合的 PR 將問題全部解決」→ 根因與對策:

| 根因 | 對策(本輪) |
|---|---|
| VRN-2 有兩條工作線,v0124 後各自編號:main(PR #584 / #585)的 RoundAll v0124–v0126 / Handle-All v0116–v0118 / runtime v0160 / 套件 v0169 是另一線(Workbench v0103 / v0104 · 印章)的,與本線同名不同內容 | origin/main 已整併進本分支(衝突保留本線正本 · 另一線檔原樣帶入)· 本線新版號跳開:RoundAll **v0127** · Handle-All **v0119** · 以後出號先查兩邊 |
| 桌機倉落後 GitHub 甚多(另一線收尾報告:719 個提交 · `pull --ff-only` 一直不成功)→ 已合併的 VDF / VCGC / Workbench 修正到不了桌機本地樹 | 桌機同步是共用倉的事:照 main `VRN2_Handover_latest.md` 第 13 節的 SettleAll v0101 一行(合併式 · 不 rebase · 不強推 · 失敗自動還原);本線的取檔是 `git fetch + git show`,不受影響 |
| 另一線 04:24 發現的貼回包 Duplicate name 警告 | 本線 RoundAll v0127 也移植去重(先後照舊)· 自測 94 項含人為重複重現 |

| 項目 | 現在 |
|---|---|
| 套件 | 照舊 `vrn2_release_v0170/VRN2_Closeout_v0170.zip`(SHA-256 `%s`)|
| 一支 Python | `VRN2_RoundAll_v0127.py`(SHA-256 `%s` · 自測 94 項)|
| 自動選模式 | 收據已是 v0170 → **repair**(幾分鐘);閘開會重抓 ⑥f 共識 |

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0119 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0127 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0127.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0127.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0119.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0127.py(套件 v0170 不動 · 貼回去重 · 版號跳開兩線相撞區)

`VRN2_RoundAll_v0127.py`(只用 Python 標準庫 · SHA-256 `%s`)= 本線 v0126 +:

| 改了什麼 | 說明 |
|---|---|
| 貼回包 | 逐檔清單先去重(先後照舊)· 防沿用前版收據時同名寫兩次(移植已合併 PR #585 另一線 v0126 的修法)|
| 版號 | v0126 兩條線相撞(main 的 vrn2_release_v0169 有另一線的同名檔)→ 本線直接取 v0127;此後出號先查本分支與 main 兩邊 |
| 自測 | 94 項(v0126 的 93 項 + 92 人為重複重現 · 無 Duplicate name 警告)|

套件 `vrn2_release_v0170/VRN2_Closeout_v0170.zip`(SHA-256 `%s` · 本檔內已釘 · 不動)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0127.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0127 + VRN2_HandleAll_v0119 (package v0170 unchanged) + origin/main merged", "date": "2026-11-02",
        "trigger": "操作員 2026-11-02 15:18 貼回 + 4 份歷史貼回包 + VIA_Settle_v0100.zip:「很多問題昨天就已經解決但又出現了 · 查 GITHUB 已經整合的 PR 將問題全部解決 · 自測實測自修正直到收尾成功 · 全景式檢視分析」",
        "desktop_1518": {"result": "launcher v0170 full round with the consent gate OPEN: step 6f fetched 41/41 (two retry passes then the 404-only codes 4171/6933 excluded per the v0102 rule · gate PASS_WITH_WARNINGS) · Combined consensus columns filled (FactSet median 49 · Yahoo 48 of 52 rows) · Workbench v0105 rendered over the desktop's v0104 · closeout REVIEW: VRN-2 0 · VCGC 0 · 人工 1 (MQ-1560 four points await the operator's --confirm) · 資料源 3 (VDF rc 2 PARTIAL · 404/AAPL/no-TP-in-original gaps)",
                         "note": "the ConsensusJoin v0106 snapshot backfill was NOT needed this round (gate open · fresh fetch); it remains the gate-closed fallback"},
        "two_lines": {"root_cause": "two VRN-2 work lines numbered independently after v0124: main (via merged PRs #584/#585, branch claude/vrn2-closeout-authorization-y4ixl7) carries ITS OWN RoundAll v0124–v0126 · HandleAll v0116–v0118 · runtime v0160 · package v0169 (Workbench v0103/v0104 + seal logo) — same names, different content than this line's artifacts",
                      "resolution": "origin/main merged into this branch (conflicts resolved keeping this line's published artifacts; the other line's and VDF/VCGC files brought in verbatim) · this line's new numbers skip the collision range: RoundAll v0127 · HandleAll v0119 · next Workbench v0107+ (desktop accelfix auto-generated a v0106 copy of v0105 because v0105 lacked the accel marker; future versions carry it) · next runtime v0162+ · always check BOTH this branch and main before minting a VRN-2 version number",
                      "desktop_sync": "the desktop repo lags GitHub main badly (the other line's closure report: 719 commits behind · pull --ff-only keeps failing) → merged VDF/VCGC/Workbench fixes don't reach the desktop's local tree; the merge-style sync one-liner lives in main VRN2_Handover_latest.md section 13 (SettleAll v0101); this line's boot uses git fetch + git show and is unaffected"},
        "fixes": {"RoundAll_v0127": "pasteback per-file list dedup (order kept · ports the merged-PR #585 fix from the other line's v0126) · selftest 94 items incl. an artificial-duplicate reproduction"},
        "package": {"name": r170["package"]["name"], "sha256": want, "release_folder": "vrn2_release_v0170", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0126.py (this line)", "sha256": r170["roundall"]["sha256"], "status": "superseded 2026-11-02; file kept in vrn2_release_v0170"},
                              {"name": "VRN2_RoundAll_v0126.py (other line · vrn2_release_v0169 · package v0169)", "status": "the other work line's artifact, merged from main; NOT this line's lineage"}],
        "roundall": {"name": "VRN2_RoundAll_v0127.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0127.md"},
        "handleall": {"name": "VRN2_HandleAll_v0119.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0119_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "results": {"status": "see VRN2_Verification_v0171.md"}}
(rel / "VRN2_Release_v0171.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
