VRN2_Closeout_v0158 — VRN-2 closeout package (2026-10-31 · steps 3 and 3b install nothing themselves)

Entry: python ActivateVRN-2_v0158.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0114.py · PowerShell 7 'handle all': VRN2_HandleAll_v0106.md (same release folder; tiny paste line inside).
Runtime: VRN2_Runtime_v0156.zip unchanged.

v0158 (operator 2026-10-31 '依照你的建議進行'): step 3b OCR isolated environment follows step 3 — a ready or assigned OCR environment is used
 as before; not ready -> no venv, no pip from VRN-2; YELLOW with the build commands for VCGC (VCGC's install gate installs into the calling
 Python only, so the isolated venv is handed to VCGC like via_tw_fetch); OCR stays queued. --pip-install / VIA_VRN2_PIP_INSTALL=1: old behaviour.
v0157: step 3 check-only · missing packages one by one through VCGC's CGC_MDL056_InstallGate (highest version) · 24 h ledger.
Verification: see VRN2_Verification_v0158.md. Hashes: PACKAGE_SHA256.json.
