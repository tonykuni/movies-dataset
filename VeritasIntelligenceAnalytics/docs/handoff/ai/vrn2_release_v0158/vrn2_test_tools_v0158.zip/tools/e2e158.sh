#!/bin/bash
# v0158 最短一行 e2e:沙盒 VIA(桌機 v0153 狀態 · t153d)+ 倉的 VIA 網路工具 + 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設(AI 不代設)
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v158; T=$W/t158a; P=$S2/venv_vrn2/bin/python; REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$T/VIA/supportive modules/registry/"
$P -m pip freeze > $W/freeze_before.txt 2>/dev/null
B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158; mkdir -p $D
cp $W/release158/VRN2_Closeout_v0158.zip $W/release158/VRN2_Release_v0158.json $W/release158/VRN2_RoundAll_v0114.py $W/release158/VRN2_RoundAll_v0114.md $W/release158/VRN2_HandleAll_v0106.md $W/release158/VRN2_HandleAll_v0106_boot.txt $D/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release158/tiny_line.txt)
run() { N=$1; shift; cd "$T/home" && env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 \
  VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P --no-open" "$@" timeout 2400 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny158.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; }
rm -f $W/tiny158.rc; run report VRN2_MODE=report; run auto; run full VRN2_MODE=full
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158/VRN2_HandleAll_v0106_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny158.rc
$P -m pip freeze > $W/freeze_after.txt 2>/dev/null; cmp -s $W/freeze_before.txt $W/freeze_after.txt && echo "venv unchanged" >> $W/tiny158.rc || echo "venv CHANGED" >> $W/tiny158.rc
[ -e "$T/home/envs/vrn2_ocr" ] && echo "ocr venv CREATED" >> $W/tiny158.rc || echo "ocr venv not created" >> $W/tiny158.rc
