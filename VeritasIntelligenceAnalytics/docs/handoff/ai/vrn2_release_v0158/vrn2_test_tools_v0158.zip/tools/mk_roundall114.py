"""VRN2_RoundAll_v0114.py = v0113 + 套件 v0158(啟動器 v0158:③b OCR 隔離環境也不 pip)+ ③b 沒就緒 → VCGC。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v157/new/VRN2_RoundAll_v0113.py").read_text(encoding="utf-8")
assert '"@PACKAGE_SHA256@"' in src
d0 = src.index('"""VRN2_RoundAll v0113'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0113 — ', '"""VRN2_RoundAll v0114 — ', 1)
at = doc.index("v0113(操作員 2026-10-31:「預設關掉 ③ 的 pip 補裝")
doc = doc[:at] + r'''v0114(操作員 2026-10-31:「依照你的建議進行」):
  · 套件 v0158(啟動器 v0158 · runtime 沿用 v0156)。③b OCR 隔離環境也不 pip:已就緒(envs\\vrn2_ocr 匯入得到 rapidocr + wordninja)或有指定
    (VIA_VRN2_OCR_PY + VIA_VRN2_OCR_BRIDGE)照用;沒就緒 → 不建 venv、不裝,黃燈列出建法交 VCGC(同 via_tw_fetch)· OCR 照舊排佇列。
  · 收尾頁:③b OCR 隔離環境沒就緒 → VCGC(以前沒有規則 · 落到預設 VRN-2)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0113.py", "用法:python VRN2_RoundAll_v0114.py")
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
keep = {"沙盒整輪 v0157 實錄": "@K1@"}
for a, b in keep.items():
    assert body.count(a) == 1, a
    body = body.replace(a, b)
body = body.replace("v0157", "v0158")
for a, b in keep.items():
    body = body.replace(b, a)
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0113"', 'VERSION = "v0114"')
assert 'RUNTIME_ZIP = "VRN2_Runtime_v0156.zip"' in s and 'PACKAGE = "VRN2_Closeout_v0158"' in s and 'LAUNCHER = "ActivateVRN-2_v0158.py"' in s
rep('''    if step.startswith("② 磁碟"):                                            # v0113 磁碟空間是這台機器的事(VRN-2 不刪檔)''',
    '''    if "③b OCR" in step:                                                      # v0114 啟動器 v0158 不建 OCR venv · 不 pip
        return "VCGC", "OCR 隔離環境沒就緒 → VCGC 建(環境工具 · 隔離境 · 建法在這列)· VRN-2 不建不 pip · OCR 照舊排佇列"
    if step.startswith("② 磁碟"):                                            # v0113 磁碟空間是這台機器的事(VRN-2 不刪檔)''')
rep('''        chk("57 收尾頁:② 磁碟可用不到 2 GB → 人工(清空間 · 不是 VRN-2 要改碼;沙盒整輪 v0157 實錄被算成 VRN-2 2 項)", o57[0] == "人工")
''', '''        chk("57 收尾頁:② 磁碟可用不到 2 GB → 人工(清空間 · 不是 VRN-2 要改碼;沙盒整輪 v0157 實錄被算成 VRN-2 2 項)", o57[0] == "人工")
        o58 = owner_of({"lamp": "YELLOW", "step": "⑥ 步驟 ③b OCR 隔離環境", "detail": "OCR 隔離環境沒就緒(C:/envs/vrn2_ocr)· VRN-2 不建、不 pip → 交 VCGC 建"}, cx10)
        chk("58 收尾頁:③b OCR 隔離環境沒就緒(啟動器 v0158 不建不 pip)→ VCGC(以前落到預設 VRN-2)", o58[0] == "VCGC")
''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0113.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0114.py"').replace('"VRN2_RoundAll_v0113.py" in html_', '"VRN2_RoundAll_v0114.py" in html_')
(S / "v158/new").mkdir(parents=True, exist_ok=True)
(S / "v158/new/VRN2_RoundAll_v0114.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0114 lines", s.count("\n"), "· RoundAll_v0113 refs after doc:", len(re.findall("RoundAll_v0113", s[d1:])))
