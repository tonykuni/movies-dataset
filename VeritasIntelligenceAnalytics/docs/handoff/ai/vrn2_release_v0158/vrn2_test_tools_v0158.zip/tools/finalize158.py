"""v0158 收尾:測試結果 → 發行清單 · 驗證紀錄 v0158 · 交接 v0159(從 v0158 抄 · 只增)· 放進倉 vrn2_release_v0158 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); W = S / "v158"; rel = W / "release158"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
def lines(p): return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()
def short(x):
    x = re.sub(r"/tmp/claude-0/[^ ·)(/]+/[0-9a-f-]{36}/scratchpad/(venv_vrn2|pwsh)", r"<scratch>/\1", x)
    x = re.sub(r"/tmp/claude-0/[^ ·)(]*?/(t158a|v158|v157|lst)/", r"<\1>/", x)
    return re.sub(r"/tmp/claude-0/[^ ·)(]*", "<scratch>", x)
def pick(n):
    pat = r"boot|③b VIA|④ 自動選模式|===== 收尾|^  \[(VRN-2|VCGC|人工|資料源)\] \d|Handle-All 結束"
    return [short(l)[:240] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)]
R = json.loads((rel / "VRN2_Release_v0158.json").read_text(encoding="utf-8"))
st_ra = [l for l in lines(W / "rall114_selftest.log") if re.search(r"^\[PASS\] 5[78] |^\[FAIL\]|--selftest · ", l)]
st_l = [l[:220] for l in lines(W / "launcher158_selftest.log") if re.search(r"^\[PASS\] v015[78]|^\[FAIL\]", l)]
rc = lines(W / "tiny158.rc")
full3 = []
for l in lines(W / "tiny_full.log"):
    l = re.sub(r"\x1b\[[0-9;]*m", "", l)
    if re.search(r"→ (GREEN|YELLOW|RED|GRAY) ③b? |^    · .*③b|③b OCR 隔離環境 ·", l):
        full3.append(short(l)[:260])
full3 = list(dict.fromkeys(full3))[:8]
R["results"] = {"roundall_selftest": st_ra, "launcher_selftest": st_l, "pwsh_parse": "pwsh 7.4.6 剖析 0 錯 · Handle-All 一行 = 可讀版 · 開機行 = 可讀版 · 最短一行 0 錯",
                "e2e_rc": rc, "e2e": {n: pick(n) for n in ("report", "auto", "full", "tamper")}, "full_step3": full3}
(rel / "VRN2_Release_v0158.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
E = R["results"]["e2e"]
md = """# VRN-2 v0158 驗證紀錄(2026-10-31 · ③b OCR 隔離環境也不 pip · 套件 v0158 · RoundAll v0114 · Handle-All v0106)

## 1. 要求與桌機狀態

操作員 2026-10-31:「依照你的建議進行」(v0157 回覆:③b OCR 隔離環境還在自己的 venv 裡 pip · 要不要也預設關掉)。
桌機 04:55 Handle-All v0105 repair:③b 同意閘 `VIA_SCRAPE_CONSENT` 未設 → **BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2**(跟預期一樣)。

## 2. 做了什麼

| 檔 | 版本 | SHA-256 | 說明 |
|---|---|---|---|
| 啟動器 | v0158 | `%s` | ③b:就緒 / 有指定的 OCR 環境照用;沒就緒 → 不建 venv、不 pip · 黃燈附建法交 VCGC · OCR 照舊排佇列 · 舊行為只有 `--pip-install` / `VIA_VRN2_PIP_INSTALL=1` |
| RoundAll | v0114 | `%s` | 收尾頁 ③b 沒就緒 → VCGC(以前落到預設 VRN-2)· 自測 58 項 |
| Handle-All | v0106 | 一行 `%s` | 指向 RoundAll v0114 |
| 套件 | VRN2_Closeout_v0158.zip | `%s` | runtime v0156 原樣 |

VCGC 安裝閘只裝進呼叫它的 Python(`pip --user`),裝不進另一個 venv,所以 ③b 的隔離環境照 via_tw_fetch 的方式交 VCGC 建(VRN-2 只印建法)。

## 3. 自測

```text
%s
%s
%s
e2e 結束碼 / 環境檢查:%s
```

## 4. 沙盒整輪的 ③ / ③b(沙盒沒有 envs/vrn2_ocr)

```text
%s
```

## 5. 最短一行 e2e(沙盒 = 桌機 v0153 狀態 · pwsh 7.4.6)

```text
%s
```

## 6. 桌機預期

貼 `VRN2_HandleAll_v0106.md` 最上面那行 → auto → repair(③ / ③b 不跑)→ 閘照舊 = BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2;先設 `VIA_SCRAPE_CONSENT` → 人工 2。
整輪才跑 ③b:桌機的 OCR 隔離環境以前建好了 → 照用;不在了 → 黃 · 收尾頁 VCGC 一項(建法在那一列)。
""" % (R["launcher"]["sha256"][:12], R["roundall"]["sha256"][:12], R["handleall"]["line_sha256"][:12], R["package"]["sha256"][:12],
       "\n".join(st_ra), "\n".join(st_l), R["results"]["pwsh_parse"], " · ".join(rc), "\n".join(full3) or "(沒有 ③b 列)",
       "\n".join("[%s] " % n + l for n in ("report", "auto", "full", "tamper") for l in E[n]))
(rel / "VRN2_Verification_v0158.md").write_text(md, encoding="utf-8", newline="\n")
src = (REPO / "VRN2_Handover_v0158.md").read_text(encoding="utf-8")
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80]); src = src.replace(a, b)
L = src.split("\n"); assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0157 + VRN2_RoundAll_v0113 + VRN2_HandleAll_v0105 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0114 + VRN2_HandleAll_v0106 · 2026-10-31(③ / ③b 都不由 VRN-2 pip:③ 缺的經 VCGC 安裝閘;"
        "③b OCR 隔離環境就緒照用 · 沒就緒交 VCGC 建;收尾頁 ③b → VCGC;runtime v0156 原樣;桌機 04:55 v0105 repair = BLOCKED · 人工 3(閘二未設))")
src = "\n".join(L)
H = R["handleall"]
once("> **本輪(v0157)**",
     "> **本輪(v0158)**:操作員「依照你的建議進行」→ **啟動器 v0158**:③b OCR 隔離環境就緒(`envs\\vrn2_ocr` 匯入得到 rapidocr + wordninja)或有指定(`VIA_VRN2_OCR_PY` + `VIA_VRN2_OCR_BRIDGE`)照用;"
     "沒就緒 → 不建 venv、不 pip · 黃燈附建法交 VCGC · OCR 照舊排佇列;**RoundAll v0114**(收尾頁 ③b → VCGC · 自測 58 項)· **Handle-All v0106**(最短一行 %d 字元 · `vrn2_release_v0158/VRN2_HandleAll_v0106_boot.txt`)。"
     "桌機 04:55 v0105 repair:閘二 `VIA_SCRAPE_CONSENT` 仍未設 → BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2(預期內)。\n"
     "> **本輪(v0157)**" % H["tiny_line_chars"])
once("| **VRN2_HandleAll_v0105.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0105** |",
     "| **VRN2_HandleAll_v0106.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0106** | `vrn2_release_v0158` | 一行版 `%s` · 開機檔 `%s` | **新**(RoundAll v0114 · 最短一行 %d 字元)|\n"
     "| **VRN2_RoundAll_v0114.py**(發行夾 · 一支入口 · 不在套件內)| **v0114** | `vrn2_release_v0158` | `%s` | **新**(套件 v0158 · 收尾頁 ③b → VCGC · 自測 58 項)|\n"
     "| ActivateVRN-2_v0158.py(套件 · 底座 v0136 · runtime v0156)| **v0158** | 見發行清單 | `%s` | **新**(③b 不建不 pip · 沒就緒交 VCGC · 收據 v0158 · 自測多一段 v0158)|\n"
     "| **VRN2_HandleAll_v0105.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0105** |"
     % (H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0113.py**(發行夾 · 一支入口 · 不在套件內)| **v0113** | `vrn2_release_v0157` | `891df58a576e` | **新**(",
     "| **VRN2_RoundAll_v0113.py**(發行夾 · 一支入口 · 不在套件內)| **v0113** | `vrn2_release_v0157` | `891df58a576e` | 被 v0114 取代(③b 還會 pip)· (")
once("| 0 | **(v0157)**",
     "| 0 | **(v0158)** 桌機 PowerShell 7 貼 `vrn2_release_v0158/VRN2_HandleAll_v0106.md` **最上面那行(%d 字元)**→ auto → repair → 閘照舊預期 BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2;"
     "要經網路工具抓共識 → 操作員先設 `$env:VIA_SCRAPE_CONSENT='YES'` → 人工 2;整輪時 ③b 沒就緒 → 收尾頁 VCGC 一項(建法在那一列)| 貼回 |\n"
     "| 0 | **(v0157)**" % H["tiny_line_chars"])
once("**v0157(2026-10-31)**:", "**v0158(2026-10-31)**:③b OCR 隔離環境也不由 VRN-2 pip(就緒照用 · 沒就緒交 VCGC 建)· 啟動器 v0158 · RoundAll v0114 · Handle-All v0106 · runtime v0156 原樣。\n\n**v0157(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0158)** **隔離環境(OCR venv / via_tw_fetch)VRN-2 只檢查、只印建法**:VCGC 安裝閘只裝進呼叫它的 Python,裝不進別的 venv;隔離環境交 VCGC 建(收尾頁 VCGC)。新加的步驟要有收尾頁負責方規則,不然會落到預設 VRN-2。\n\n")
(REPO / "VRN2_Handover_v0159.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0158"; D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0158.zip", "VRN2_Release_v0158.json", "VRN2_RoundAll_v0114.py", "VRN2_RoundAll_v0114.md", "VRN2_HandleAll_v0106.md", "VRN2_HandleAll_v0106_boot.txt", "VRN2_Verification_v0158.md"):
    shutil.copy(rel / n, D / n)
SCR = re.compile(rb"/tmp/claude-0/[^ \"'\n)(]*?/(t158a|v158|v157|v156|lst)/")
SCR2 = re.compile(rb"/tmp/claude-0/[^ \"'\n)(/]+/[0-9a-f-]{36}/scratchpad/")
def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; z.writestr(zi, SCR2.sub(rb"<scratch>/", SCR.sub(rb"<\1>/", data)))
with zipfile.ZipFile(D / "logs_v0158.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall114_selftest.log", "launcher158_selftest.log", "pscheck158.log", "tiny158.rc", "freeze_before.txt", "freeze_after.txt")] + sorted(W.glob("tiny_*.log")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0158.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [S / "v157/mk_launcher158.py"] + [W / n for n in ("mk_roundall114.py", "build158.py", "finalize158.py", "e2e158.sh", "ha_md_tpl.md", "ra_md_tpl.md", "ps7/handleall_src.ps1", "ps7/boot_src.ps1", "ps7/join_ps.py")] + [rel / "tiny_line.txt", rel / "boot_line.txt", rel / "boot_cmd.txt"]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0159", src.count("\n"))
