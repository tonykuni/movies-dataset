"""ActivateVRN-2_v0158.py = v0157 + ③b OCR 隔離環境預設也不 pip:就緒照用 · 沒就緒不建不裝 · 列指令交 VCGC(同 via_tw_fetch 的交辦)· runtime 沿用 v0156。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v157/new/ActivateVRN-2_v0157.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0157: v0156 entry + the operator decision of 2026-10-31',
    '"""VRN-2 v0158: v0157 entry + step 3b (OCR isolated environment) follows the same rule (operator 2026-10-31 "依照你的建議進行").\n\n'
    ' - step 3b: an OCR environment that is already set (VIA_VRN2_OCR_PY + VIA_VRN2_OCR_BRIDGE) or ready (envs/vrn2_ocr imports\n'
    '   rapidocr_onnxruntime / rapidocr and wordninja) is used as before. Not ready -> this entry no longer creates the venv or pip-installs\n'
    '   into it (the base did, with numpy>=1.24,<2.0); the step is YELLOW with the exact commands for VCGC to build it, and OCR stays queued.\n'
    '   VCGC\'s install gate installs into the calling Python only (pip --user), so it cannot fill another venv; the isolated environment is\n'
    '   handed to VCGC the same way as via_tw_fetch. --pip-install / VIA_VRN2_PIP_INSTALL=1 keeps the old behaviour (operator\'s choice only).\n\n'
    'v0157: v0156 entry + the operator decision of 2026-10-31')
for a, b in (('VERSION = "ActivateVRN-2 v0157"', 'VERSION = "ActivateVRN-2 v0158"'), ('RECEIPT_NAME = "VRN2_Closeout_v0157.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0158.json"'),
             ('launcher = root / "package" / "ActivateVRN-2_v0157.py"', 'launcher = root / "package" / "ActivateVRN-2_v0158.py"'),
             ('return lamp, detail + " · launcher v0157"', 'return lamp, detail + " · launcher v0158"'), ('print("NEXT: [%s] VRN-2 v0157 · rc %s', 'print("NEXT: [%s] VRN-2 v0158 · rc %s'),
             ('exact ship v0156 (launcher v0157); manager v0257 (over v0255); consensus join v0104 + engine v0122 via VIA network tool; step 3 installs via VCGC; shared VRN retained"',
              'exact ship v0156 (launcher v0158); manager v0257 (over v0255); consensus join v0104 + engine v0122 via VIA network tool; step 3 installs via VCGC; step 3b no pip; shared VRN retained"')):
    rep(a, b)
rep('''def main(argv: list | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments == ["--selftest"]:
        return selftest()
''', r'''# ===== v0158 ③b OCR 隔離環境:就緒照用 · 沒就緒不建不裝 · 交 VCGC =====
OCR_CHECK = ("import importlib\nok=0\nfor n in ('rapidocr_onnxruntime','rapidocr'):\n    try:\n        importlib.import_module(n); ok=1; break\n"
             "    except Exception: pass\nimportlib.import_module('wordninja')\nraise SystemExit(0 if ok else 1)\n")


def ocr_venv(env=None) -> tuple:
    """底座 ocr_env 用的同一個位置:VIA_ENVS_HOME(或 ~/envs)/vrn2_ocr · 回 (夾, python)。"""
    env = os.environ if env is None else env
    vdir = Path(env.get("VIA_ENVS_HOME") or (Path.home() / "envs")) / "vrn2_ocr"
    return vdir, vdir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def ocr_ready(env=None, runner=None) -> bool:
    env = os.environ if env is None else env
    if env.get("VIA_VRN2_OCR_PY") and env.get("VIA_VRN2_OCR_BRIDGE"):
        return True
    _vdir, py = ocr_venv(env)
    if not py.exists():
        return False
    runner = runner or (lambda cmd: subprocess.run(cmd, capture_output=True, text=True, timeout=180).returncode)
    try:
        return runner([str(py), "-c", OCR_CHECK]) == 0
    except Exception:  # noqa: BLE001
        return False


def ocr_handoff(env=None) -> str:
    """沒就緒時給 VCGC 的建法(VRN-2 不建、不 pip)。"""
    vdir, py = ocr_venv(env)
    if os.name == "nt":
        build = 'py -3.11 -m venv "%s"' % vdir
    else:
        build = 'python3 -m venv "%s"' % vdir
    return ("OCR 隔離環境沒就緒(%s)· VRN-2 不建、不 pip(VCGC 安裝閘只裝進呼叫它的 Python · 裝不進別的 venv)→ 交 VCGC 建:%s ; "
            '"%s" -m pip install "numpy>=1.24,<2.0" rapidocr_onnxruntime wordninja · OCR 照舊排佇列' % (vdir, build, py))


def main(argv: list | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments == ["--selftest"]:
        return selftest()
''')
rep('''    def ocr_environment(environment=None):
        lamp, detail = original_ocr_environment(environment)''', '''    def ocr_environment(environment=None):
        if not legacy_pip and not ocr_ready(os.environ if environment is None else {**os.environ, **environment}):
            return "YELLOW", ocr_handoff(os.environ if environment is None else {**os.environ, **environment})    # v0158 不建不裝 · 交 VCGC
        lamp, detail = original_ocr_environment(environment)''')
rep('''    print("[PASS] v0157: step 3 runs envcheck check-only''', r'''    ocr_src = selftest_source(BASE_NAME).read_text(encoding="utf-8")
    assert 'rc, _ = run(pipx + ["rapidocr_onnxruntime", "wordninja"], 2400)' in ocr_src and 'vdir = _cb_Path(os.environ.get("VIA_ENVS_HOME") or (_cb_Path.home() / "envs")) / "vrn2_ocr"' in ocr_src
    with tempfile.TemporaryDirectory(prefix="vrn2-v0158-check-") as temporary:
        envs = {"VIA_ENVS_HOME": temporary}
        vdir158, py158 = ocr_venv(envs)
        assert vdir158 == Path(temporary) / "vrn2_ocr" and not ocr_ready(envs, runner=lambda cmd: 0)                                     # no venv → not ready
        py158.parent.mkdir(parents=True)
        py158.write_text("", encoding="utf-8")
        seen = []
        assert ocr_ready(envs, runner=lambda cmd: seen.append(cmd) or 0) and seen[0][:2] == [str(py158), "-c"] and "wordninja" in seen[0][2]
        assert not ocr_ready(envs, runner=lambda cmd: 1)                                                                                   # venv without the packages
        assert ocr_ready({"VIA_VRN2_OCR_PY": "/x/python", "VIA_VRN2_OCR_BRIDGE": "/x/bridge.py"}, runner=lambda cmd: 1)                     # an assigned OCR env is used as is
        hand = ocr_handoff(envs)
        assert "VRN-2 不建、不 pip" in hand and "交 VCGC 建" in hand and str(vdir158) in hand and "rapidocr_onnxruntime wordninja" in hand and "OCR 照舊排佇列" in hand
    print("[PASS] v0158: step 3b uses a ready / assigned OCR environment as before · not ready → no venv, no pip from VRN-2 · YELLOW with the build commands for VCGC · "
          "OCR stays queued · old behaviour only with --pip-install / VIA_VRN2_PIP_INSTALL=1")
    print("[PASS] v0157: step 3 runs envcheck check-only''')
(S / "v157/new/ActivateVRN-2_v0158.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0158 lines", s.count("\n"))
