# VRN-2 · PowerShell 7 一行處理全部 · VRN2_HandleAll_v0106(2026-10-31 · 套件 v0158 · RoundAll v0114)

v0106 = v0105 + 套件 **v0158**:操作員 2026-10-31「依照你的建議進行」→ ③b OCR 隔離環境也跟 ③ 一樣,**VRN-2 自己不 pip**。

| 步驟 | 現在 |
|---|---|
| ③ 環境檢查 | 只檢查 · 缺的一個一個交 VCGC 安裝閘 `CGC_MDL056_InstallGate` 最高版號 · 裝完再檢查 · 裝不起來 24 小時不重試(v0157 起) |
| ③b OCR 隔離環境 | 已就緒(`%USERPROFILE%\envs\vrn2_ocr` 匯入得到 rapidocr + wordninja)或有指定(`VIA_VRN2_OCR_PY` + `VIA_VRN2_OCR_BRIDGE`)→ 照用;**沒就緒 → 不建 venv、不裝** · 黃燈列出建法交 VCGC · OCR 照舊排佇列(**v0158**) |
| 為什麼 ③b 不用 VCGC 安裝閘 | 安裝閘只裝進呼叫它的那個 Python(`pip --user`),裝不進另一個 venv → 隔離環境照 via_tw_fetch 的方式交 VCGC 建 |
| 收尾頁 | ③b 沒就緒 → **VCGC**(以前沒有規則,落到預設 VRN-2) |
| 舊行為 | 只有操作員明說:`--pip-install` 或 `$env:VIA_VRN2_PIP_INSTALL = '1'`(③ 和 ③b 一起) |
| 一支 Python | `VRN2_RoundAll_v0114.py`(SHA-256 `@RA12@`)· 套件 `VRN2_Closeout_v0158.zip`(SHA-256 `@WANT12@` · runtime v0156 原樣) |

## PowerShell 7 貼這一行(@TLEN@ 字元 · 4 行內)

```powershell
@TINY@
```

第一行應是 `[GREEN] boot: Handle-All v0106 SHA-256 OK`(開機檔 SHA-256 `@BT12@` · Handle-All 那一行 `@HA12@`)。

## 同意閘(操作員決定 · VRN-2 只讀 · 不代設)

桌機 04:55 那輪 ③b 印的還是 `VIA_NET_CONSENT=YES · VIA_SCRAPE_CONSENT=(未設)` → 閘二沒開 → ⑥f 不經網路工具重抓 · 收尾頁「人工」多一項。
要經網路工具抓共識:在同一個視窗先貼下面這行,再貼最上面那一行。

```powershell
$env:VIA_SCRAPE_CONSENT = 'YES'
```

## 這次桌機貼下去會怎樣

上一輪收據 `VRN2_Closeout_v0153.json`、輸出冊在 → auto 選 **repair**(不跑啟動器 · ③ / ③b 這輪都不跑):

- 閘照舊 → 跟 04:55 一樣 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2**。
- 先設 `VIA_SCRAPE_CONSENT` → ⑥f 經 VIA 網路工具重抓 → 預期 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2**。

整輪(`$env:VRN2_MODE = 'full'`)才跑 ③ / ③b:桌機的 OCR 隔離環境以前建好了 → ③b 照用(綠);如果它不見了 → ③b 黃 · 收尾頁 VCGC 一項(建法在那一列)。

## 開機行(@BTLEN@ 字元)

```powershell
@BOOT@
```

## cmd 視窗

```bat
@CMD@
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
@LINE@
```

## 可讀版 · Handle-All

```powershell
@SRC@
```

## 可讀版 · 開機行

```powershell
@BTSRC@
```
