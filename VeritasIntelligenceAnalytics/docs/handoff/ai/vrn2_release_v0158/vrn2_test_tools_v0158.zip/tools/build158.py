"""v0158 整包重建(冪等):pkg158 → 套件 VRN2_Closeout_v0158.zip → VRN2_RoundAll_v0114.py(填套件雜湊)→ Handle-All v0106 → 開機行 + 開機檔 + 最短一行 + cmd 一行
→ md · 發行清單。vrn2_release_v0157 及更早的發行夾不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v158"; out, rel, new = W / "pkg158", W / "release158", W / "new"
rel.mkdir(exist_ok=True)
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402

REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
r157 = json.loads((REPO / "vrn2_release_v0157/VRN2_Release_v0157.json").read_text(encoding="utf-8"))
rt = json.loads((out / "VRN2_Runtime_v0156.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == r157["runtime"]["zip_sha256"] == hashlib.sha256((out / "VRN2_Runtime_v0156.zip").read_bytes()).hexdigest()   # runtime v0156 原樣
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0158.py", "VRN2_Runtime_v0156.zip", "VRN2_Runtime_v0156.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0158 — VRN-2 closeout package (2026-10-31 · steps 3 and 3b install nothing themselves)\n\n"
  "Entry: python ActivateVRN-2_v0158.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0114.py · PowerShell 7 'handle all': VRN2_HandleAll_v0106.md (same release folder; tiny paste line inside).\n"
  "Runtime: VRN2_Runtime_v0156.zip unchanged.\n\n"
  "v0158 (operator 2026-10-31 '依照你的建議進行'): step 3b OCR isolated environment follows step 3 — a ready or assigned OCR environment is used\n"
  " as before; not ready -> no venv, no pip from VRN-2; YELLOW with the build commands for VCGC (VCGC's install gate installs into the calling\n"
  " Python only, so the isolated venv is handed to VCGC like via_tw_fetch); OCR stays queued. --pip-install / VIA_VRN2_PIP_INSTALL=1: old behaviour.\n"
  "v0157: step 3 check-only · missing packages one by one through VCGC's CGC_MDL056_InstallGate (highest version) · 24 h ledger.\n"
  "Verification: see VRN2_Verification_v0158.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0158.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0158", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0158.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0158/" + n, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (new / "VRN2_RoundAll_v0114.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0158"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158"' in ra and 'RUNTIME_ZIP = "VRN2_Runtime_v0156.zip"' in ra
(rel / "VRN2_RoundAll_v0114.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ps7 = (S / "v151/ps7/line_ps7_tpl.txt").read_text(encoding="utf-8").strip("\n").replace("vrn2_release_v0151", "vrn2_release_v0158").replace("@F@", "VRN2_RoundAll_v0114.py").replace("@H@", ra_sha)
assert ("$H = '%s'" % ra_sha) in ps7
(rel / "oneline_roundall_ps7.txt").write_text(ps7 + "\n", encoding="utf-8")
ha_src = (W / "ps7/handleall_src.ps1").read_text(encoding="utf-8").replace("@H@", ra_sha)
assert ha_src.count(ra_sha) == 1 and "vrn2_release_v0158" in ha_src and "VRN2_RoundAll_v0114.py" in ha_src and "exit" not in ha_src.replace("Exception", "")
ha_line = join(ha_src); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha_src, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt_src = (W / "ps7/boot_src.ps1").read_text(encoding="utf-8").replace("@HA@", ha_sha)
bt_line = join(bt_src); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800 and ha_sha in bt_line
(rel / "boot_src.ps1").write_text(bt_src, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0106_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(bt_line.encode("utf-16-le")).decode("ascii"); assert len(cmd_line) < 8191
(rel / "boot_cmd.txt").write_text(cmd_line + "\n", encoding="utf-8")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158/VRN2_HandleAll_v0106_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
md = (W / "ha_md_tpl.md").read_text(encoding="utf-8")
for k, v in (("@TINY@", tiny), ("@TLEN@", str(len(tiny))), ("@BT12@", bt_sha[:12]), ("@HA12@", ha_sha[:12]), ("@RA12@", ra_sha[:12]), ("@WANT12@", want[:12]), ("@BOOT@", bt_line),
             ("@BTLEN@", "{:,}".format(len(bt_line))), ("@CMD@", cmd_line), ("@LINE@", ha_line), ("@SRC@", ha_src.rstrip("\n")), ("@BTSRC@", bt_src.rstrip("\n"))):
    md = md.replace(k, v)
assert not re.search(r"@[A-Z0-9]+@", md)
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == bt_line
(rel / "VRN2_HandleAll_v0106.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = (W / "ra_md_tpl.md").read_text(encoding="utf-8").replace("@RA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PS7@", ps7)
assert not re.search(r"@[A-Z0-9]+@", ra_md)
(rel / "VRN2_RoundAll_v0114.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0158 (step 3b OCR environment: no pip from VRN-2 · not ready → VCGC) + VRN2_RoundAll_v0114 + VRN2_HandleAll_v0106", "date": "2026-10-31",
        "trigger": "操作員 2026-10-31:「依照你的建議進行」(v0157 回覆:③b OCR 隔離環境還在自己的 venv 裡 pip · 要不要也預設關掉)· 桌機 04:55 Handle-All v0105 repair = BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2",
        "base_package": {"name": "VRN2_Closeout_v0157 (launcher v0157 · runtime v0156)", "retained": "runtime v0156 zip byte-identical; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0157 package for the closeout entry; VRN2_RoundAll v0113 → v0114; VRN2_HandleAll v0105 → v0106",
        "install_route": dict(r157["install_route"], step3b="ready / assigned OCR env used as before · not ready → no venv, no pip from VRN-2 · YELLOW with build commands for VCGC · OCR stays queued · --pip-install / VIA_VRN2_PIP_INSTALL=1 keeps the old behaviour",
                              not_changed="VDF's via_tw_fetch build commands are printed for VCGC as before (VRN-2 never ran them)"),
        "fixes": {"launcher_v0158": "receipt VRN2_Closeout_v0158.json · ocr_environment wrapper: ocr_ready() (assigned env or envs/vrn2_ocr imports rapidocr + wordninja) → base ocr_env; else ocr_handoff() YELLOW · selftest block v0158",
                  "RoundAll_v0114": "package v0158 · close-out: '③b OCR' rows → VCGC (no rule before → default VRN-2) · selftest 58",
                  "HandleAll_v0106": "v0105 pointed at RoundAll v0114 (vrn2_release_v0158)"},
        "not_fixed_here": r157["not_fixed_here"],
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0156.json inside the package", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0113.py", "sha256": r157["roundall"]["sha256"], "status": "superseded 2026-10-31 (package v0157 · step 3b pip in its own venv); file kept in vrn2_release_v0157"}],
        "roundall": {"name": "VRN2_RoundAll_v0114.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0114.md"},
        "handleall": {"name": "VRN2_HandleAll_v0106.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0106_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · sandbox VIA with no OCR venv (step 3b not ready → handed to VCGC)", "results": {"status": "see VRN2_Verification_v0158.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0158/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0158.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0158.py"]).hexdigest()},
        "test_tools_zip": "vrn2_test_tools_v0158.zip", "logs_zip": "logs_v0158.zip"}
(rel / "VRN2_Release_v0158.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
for k, v in (("zip_sha.txt", want), ("ra_sha.txt", ra_sha), ("ha_sha.txt", ha_sha), ("bt_sha.txt", bt_sha)):
    (rel / k).write_text(v)
print("built", sorted(p.name for p in rel.iterdir()))
