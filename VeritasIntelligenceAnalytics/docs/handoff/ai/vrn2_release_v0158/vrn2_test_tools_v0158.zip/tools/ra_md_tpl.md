# VRN-2 一支 Python · VRN2_RoundAll_v0114.py(套件 v0158 · ③b 也不 pip)

`VRN2_RoundAll_v0114.py`(只用 Python 標準庫 · SHA-256 `@RA12@`)= v0113 + 套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `@WANT12@`,本檔內已釘死):

| 改了什麼 | 說明 |
|---|---|
| 套件 v0158 | 啟動器 v0158:③b OCR 隔離環境就緒 / 有指定 → 照用;沒就緒 → 不建 venv、不 pip · 黃燈附建法交 VCGC · OCR 照舊排佇列 · runtime v0156 原樣 |
| 收尾頁 | ③b OCR 隔離環境沒就緒 → VCGC(以前沒有規則 · 落到預設 VRN-2) |

自測 58 項(v0113 的 57 項 + 58)。**最省事:`VRN2_HandleAll_v0106.md` 最上面那一行**。前版 v0113 的說明見 `vrn2_release_v0157/VRN2_RoundAll_v0113.md`。

## 在 PowerShell 7 視窗直接貼(約 2,300 字元)

```powershell
@PS7@
```

## 已經有這個檔時

```bat
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0114.py" --only package,fix,report,closeout,pasteback
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0114.py"
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0114.py" --launcher-args "--no-install"
```

第 1 行 = 只修 + 收尾頁 · 第 2 行 = 整輪(③ 缺的經 VCGC 安裝閘 · ③b 沒就緒交 VCGC)· 第 3 行 = 整輪但 ③ 只檢查、不裝。PowerShell 把 `%USERPROFILE%` 換成 `$env:USERPROFILE`。
