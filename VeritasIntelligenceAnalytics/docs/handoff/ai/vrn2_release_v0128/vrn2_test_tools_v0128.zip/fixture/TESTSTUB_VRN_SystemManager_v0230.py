"""VRN_SystemManager v0230 — TEST STUB(只在沙盒測試樹 · 代替使用者機器上的 VRN-2 薄尾鏈 v0154–v0230 · 不上船 · 不進 repo)。

只提供 v0231 經 _resolve / PRIOR 取用的名稱:_home · _rep · input_dir · p1loop(ENG397 擷取 + 簡化鎖 / 退步)· accel_kind · latest_accel · selftest · main。
"""
# [VIA:ACCEL-BRIDGE:v0111] test stub(橋標記;不改行為)
import importlib.util
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
TAG = "v0230"


def _home():
    return HERE.parent.parent


def _rep():
    import os
    return Path(os.environ.get("VIA_VRN_HEALTH_OUT") or (_home() / "VIA_Reports" / "vrn2"))


def input_dir():
    cf = sorted((HERE / "SSOT").glob("VRN_Config_v[0-9][0-9][0-9][0-9].json"), key=lambda p: int(re.search(r"_v(\d{4})", p.name).group(1)))
    return Path(json.loads(cf[-1].read_text(encoding="utf-8"))["input_dir"]) if cf else Path(r"C:\測試樣本報告")


def latest_accel(h):
    return "VeritasCeleritas_v1141"


def accel_kind(src, ext, latest):
    import re as _re
    if "[VIA:ACCEL-BRIDGE:v0111]" in src:
        return ("", "GREEN")
    head = src[:4000]
    if _re.search(r"(?m)^(?:VERSION|__version__)\s*=", src) and ("Celeritas" in head or "AegisNexus" in head) and not _re.search(r"import\s+VeritasCeleritas_v\d+", src):
        return ("", "GREEN")                                             # 正本加速器 / 網路工具本身
    return ("", "OP-300")


def p1loop(one=""):
    engs = sorted(HERE.glob("VRN_ENG397_P1Segment_v[0-9][0-9][0-9][0-9].py"), key=lambda p: int(re.search(r"_v(\d{4})", p.name).group(1)))
    sp = importlib.util.spec_from_file_location("stub_eng397", str(engs[-1]))
    m = importlib.util.module_from_spec(sp)
    sp.loader.exec_module(m)
    rep = _rep()
    o = m.run(input_dir(), rep, one)
    pv = rep / "p1view"
    res = json.loads((pv / "P1VIEW_latest.json").read_text(encoding="utf-8"))
    lk_p = pv / "VRN_P1View_Lock_latest.json"
    lock = json.loads(lk_p.read_text(encoding="utf-8")) if lk_p.exists() else {}
    cur = {r["file"]: r["lamp"] for r in res}
    reg = ["%s(綠→%s)" % (f, cur[f]) for f, l in lock.items() if l == "GREEN" and f in cur and cur[f] != "GREEN"]
    for f, l in cur.items():
        if l == "GREEN":
            lock[f] = "GREEN"
    lk_p.write_text(json.dumps(lock, ensure_ascii=False, indent=1), encoding="utf-8")
    rp = pv / "VRN_P1View_Rounds.jsonl"
    rnd = 1 + (len([x for x in rp.read_text(encoding="utf-8").splitlines() if x.strip()]) if rp.exists() else 0)
    with rp.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps({"round": rnd, "regress": len(reg), "reasons": o.get("reasons"), "locked": len(lock), "lamps": o.get("lamps")}, ensure_ascii=False) + "\n")
    L = ["[計] p1loop(test stub)· 第 %d 輪 · %d 份 · 燈 %s · 鎖 %d · 退步 %d" % (rnd, o.get("n", 0), o.get("lamps"), len(lock), len(reg))]
    if reg:
        L.append("[RED] 鎖定過的檔案退步 %d:%s" % (len(reg), " | ".join(reg)))
    return (0 if not reg else 1), L


def selftest():
    print("[計] VRN_SystemManager v0230 test stub 自測 1/1 PASS")
    return 0


def main(args=None):
    args = list(sys.argv[1:] if args is None else args)
    if "--selftest" in args:
        return selftest()
    print("[計] test stub · 動詞 %s 不在 stub 範圍" % (args[:1] or ["—"])[0])
    return 0


import types as _types
PRIOR = _types.ModuleType("stub_v0194")                                  # 代表鏈中的 v0194(v0231 經 _mod_v0214("v0194") 取 main)
PRIOR.TAG = "v0194"
PRIOR.main = main


if __name__ == "__main__":
    sys.exit(main())
