import ast, base64, hashlib, sys, pathlib
src = pathlib.Path(sys.argv[1]).read_text(encoding="utf-8")
out = pathlib.Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
t = ast.parse(src)
items = []
consts = {}
for n in t.body:
    if isinstance(n, ast.Assign):
        try:
            v = ast.literal_eval(n.value)
        except Exception:
            continue
        for tg in n.targets:
            if isinstance(tg, ast.Name): consts[tg.id] = v
            elif isinstance(tg, ast.Tuple):
                for e, vv in zip(tg.elts, v): consts[e.id] = vv
    elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and getattr(n.value.func, "attr", "") == "append":
        items.append(ast.literal_eval(n.value.args[0]))
pairs = [(consts["MGR_NAME"], consts["MGR_SHA"], consts["MGR_B64"]),
         (consts["OCR_BRIDGE_NAME"], consts["OCR_BRIDGE_SHA"], consts["OCR_BRIDGE_B64"]),
         (consts["HANDOVER_NAME"], consts["HANDOVER_SHA"], consts["HANDOVER_B64"])]
pairs += list(consts["ENGINES"]) + list(consts["EXTRAS"]) + items
for name, sha, b64 in pairs:
    raw = base64.b64decode("".join(b64.split()))
    ok = hashlib.sha256(raw).hexdigest() == sha
    (out / name).write_bytes(raw)
    print("%-45s %9d sha_ok=%s %s" % (name, len(raw), ok, sha[:12]))
