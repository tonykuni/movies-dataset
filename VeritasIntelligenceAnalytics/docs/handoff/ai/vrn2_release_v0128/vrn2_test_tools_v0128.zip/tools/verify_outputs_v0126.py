"""VRN-2 輸出值獨立驗證(不 import 任何 VRN-2 程式 · 讀法 = pypdfium2 字元框 · 與擷取用的 pdfplumber 不同讀取器)。

用法:python verify_outputs.py <output 夾> <PDF 夾> <報告 .json>
  基本資料:每欄值必須在 PDF 原文找得到(或可由原文重算)· 推算值要標推算
  年度數據:每筆 VALUE 必須在該頁 · 同列有 ITEM · 數值落在 PERIOD 表頭那一欄(x 對齊)
  子欄(SUBCOL · 一格多值拆開):PyMuPDF 字詞框另查(沒有 PyMuPDF → pdfplumber)· 整列序列 · 最近表頭 · 標籤不重複 · 表頭在組內 · 最近子表頭字(verify_subcol)
  v3(v0126):DUPKEY 一致性(同檔 · 表 · 列 · 科目 · 期間 · 子欄只能一個值)· 轉置表(年份在第一欄 · VERIFY 有「轉置」)用 PyMuPDF 另查(verify_trans)· v2(v0125):影像頁(文字層沒有字)→ OCR(人工核對 · 不算 FAIL)· 日期多種寫法 · 引號 / 破折號正規化 · Email 帳號推算且已標「推算」的分析師 → EST ·
  依檔分片平行(子行程 · 路數依 CPU / RAM · VRN2_VERIFY_PAR)· 另寫 <報告>.digest.txt(≤150 行 · 貼給 AI 用)
"""
import json
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import pypdfium2 as pdfium


def nfk(t):
    return unicodedata.normalize("NFKC", t or "")


_QD = str.maketrans({"\u2018": "'", "\u2019": "'", "\u201b": "'", "\u2032": "'", "\u201c": '"', "\u201d": '"', "\u2033": '"',
                     "\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2013": "-", "\u2014": "-", "\u2015": "-", "\u2212": "-", "\ufe63": "-"})


def squash(t):
    return re.sub(r"\s+", "", nfk(t).translate(_QD)).lower()


_PAGES = {}


def page_lines(pdf, pno):
    """回 [(y, [(x0, x1, token)])] · 依字元框分列分詞(列 = 字元垂直中心差 < 0.5 字高)。"""
    key = (str(pdf), pno)
    if key in _PAGES:
        return _PAGES[key]
    doc = pdfium.PdfDocument(str(pdf))
    out = []
    if 1 <= pno <= len(doc):
        tp = doc[pno - 1].get_textpage()
        chars = []
        for i in range(tp.count_chars()):
            ch = tp.get_text_range(i, 1)
            l, b, r, t = tp.get_charbox(i, loose=True)
            if ch in ("\r", "\n") or r <= l:
                chars.append(None)
                continue
            chars.append((ch, l, b, r, t))
        rows = []
        for c in chars:
            if c is None:
                continue
            ch, l, b, r, t = c
            yc, h = (b + t) / 2, max(t - b, 1.0)
            row = next((rw for rw in rows if abs(rw[0] - yc) < 0.5 * max(h, rw[1])), None)
            if row is None:
                row = [yc, h, []]
                rows.append(row)
            row[2].append((l, r, ch, h))
        for yc, h, cs in rows:
            cs.sort(key=lambda x: x[0])
            toks, cur = [], None
            for l, r, ch, hh in cs:
                if ch.isspace():
                    cur = None
                    continue
                if cur is not None and l - cur[1] <= 0.25 * hh:
                    cur[1], cur[2] = r, cur[2] + ch
                else:
                    cur = [l, r, ch]
                    toks.append(cur)
            out.append((yc, [(a, b_, nfk(s)) for a, b_, s in toks]))
        out.sort(key=lambda x: -x[0])
    doc.close()
    _PAGES[key] = out
    return out


def page_text(pdf, pno):
    return "\n".join(" ".join(t for _, _, t in toks) for _, toks in page_lines(pdf, pno))


_IMG = {}


def is_image(pdf, pno=1):
    """這頁沒有文字層(影像 PDF · 要 OCR):兩個讀取器都 < 40 個非空白字。"""
    key = (str(pdf), pno)
    if key not in _IMG:
        n = len(re.sub(r"\s+", "", page_text(pdf, pno)))
        if n < 40:
            try:
                import pdfplumber
                with pdfplumber.open(str(pdf)) as d:
                    n = max(n, len(re.sub(r"\s+", "", (d.pages[pno - 1].extract_text() or "") if pno <= len(d.pages) else "")))
            except Exception:  # noqa: BLE001
                pass
        _IMG[key] = n < 40
    return _IMG[key]


def all_text(pdf, pages=(1, 2, 3, 4, 5, 6, 7, 8)):
    """兩個讀取器聯集(pypdfium2 字元框 + pdfplumber 文字層)· 去掉字母間的字型雜訊 %(To%mmy → Tommy)。"""
    import pdfplumber
    t = [page_text(pdf, p) for p in pages]
    try:
        with pdfplumber.open(str(pdf)) as d:
            t += [(d.pages[p - 1].extract_text() or "") for p in pages if p <= len(d.pages)]
    except Exception:  # noqa: BLE001
        pass
    return re.sub(r"(?<=[A-Za-z\u4e00-\u9fff])%(?=[A-Za-z\u4e00-\u9fff])", "", nfk("\n".join(t)))


def num_in(v, text):
    """數值回原文:字面 · 字距拆開 · 千分位 · 小數位不同(4200 = 4,200.00)都算同值。"""
    v = nfk(v).strip().lstrip("+")
    if not v:
        return True
    pat = r"(?<![\d,])(?<!\d\.)" + re.escape(v) + r"(?![\d])"
    if re.search(pat, text):
        return True
    t = re.sub(r"(?<=[\d.,])\s+(?=[\d.,])", "", nfk(text))
    if re.search(pat, t):
        return True
    vv = v.replace(",", "").rstrip("%")
    try:
        fv = float(vv)
    except ValueError:
        return False
    for tt in (nfk(text), t):                                            # 原樣 + 字距接回 兩種都比(接回會把換行兩邊的數字黏住)
        t2 = re.sub(r"(?<=\d),(?=\d{3}(?!\d))", "", tt)
        if any(abs(float(x) - fv) < 1e-9 for x in re.findall(r"(?<![\d.])\d+(?:\.\d+)?(?![\d.])", t2)):
            return True
    return False


RATING_ONLY = re.compile(r"(?i)^(?:中立|買進|買入|賣出|持有|增加持股|減碼|區間操作|未評等|neutral|buy|sell|hold|outperform|underperform|overweight|underweight|equal[- ]?weight|not rated|nr)(?:\s*[(（][^)）]{1,14}[)）])?$")


def src_score(v, raw_sq):
    """原文覆蓋率:值壓縮後每 6 字一窗(步距 3)有幾成在原文(兩讀取器聯集)· 跨欄交錯的標題也量得到。"""
    sv = squash(v)
    if len(sv) <= 6:
        return 1.0 if sv in raw_sq else 0.0
    wins = [sv[i:i + 6] for i in range(0, len(sv) - 5, 3)]
    return sum(1 for w in wins if w in raw_sq) / len(wins)


def verify_fin(rows, pdfdir):
    res = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        lines = page_lines(pdf, int(x["PAGE"]))
        item, per, val = nfk(x["ITEM"]).strip(), nfk(x["PERIOD"]).strip(), nfk(x["VALUE"]).strip()
        sv = squash(val)
        # 1) 值在該頁
        ptxt = "\n".join(" ".join(t for _, _, t in tk) for _, tk in lines)
        present = num_in(val, ptxt) or sv in squash(ptxt)
        # 2) 科目那一列(科目前 14 字壓縮比對 · 允許科目折行:取科目起點所在列與下一列)
        key = squash(item)[:14]
        cand = []
        for k, (y, tk) in enumerate(lines):
            lt = squash("".join(t for _, _, t in tk))
            if key and key in lt:
                cand.append(k)
        # 3) 表頭期間欄 x(取在科目列上方、最近的那一個表頭)
        verdict, note = ("PRESENT" if present else "FAIL"), ("值在該頁 · 驗證器對不到期間欄" if present else "值不在該頁(驗證器讀法)")
        kind = "NUM" if re.search(r"\d", val) else ("NIL" if re.fullmatch(r"(?i)[-–—]+|n\.?a\.?|nm|n/?m|n/?a|na|nil|neg\.?|ns|--", val) else "TEXT")
        best = None
        for k in cand:
            y = lines[k][0]
            row_toks = [tt for kk in (k, k + 1) if kk < len(lines) and abs(lines[kk][0] - y) < 14 for tt in lines[kk][1]]
            hits = [((a + b) / 2, a, b, t) for a, b, t in row_toks if squash(t) == sv or squash(t) == sv.replace(",", "")]
            if not hits:
                continue
            for yy, tk in lines:                                 # 每個在上方、同期間字樣的表頭都試 · 取 x 最近(並排表各自的表頭)
                if not (y - 1 < yy < y + 520):
                    continue
                for a, b, t in tk:
                    if t != per:
                        continue
                    hx = (a + b) / 2
                    colw = min([abs((aa + bb) / 2 - hx) for aa, bb, tt in tk if tt != per and re.match(r"^(?:FY)?\d{2,4}[AEFP]?$|^\d{1,2}/\d{2}[AEFe]?$|^[A-Z][a-z]{2}-\d{2}[AEF]$", tt)] + [60])
                    for vx, va, vb, vt in hits:
                        dx = abs(vx - hx)
                        if best is None or dx < best[0]:
                            best = (dx, colw, hx, vx, b - a, yy)
        if best:
            dx, colw, hx, vx, hw, hy = best
            if dx <= max(0.55 * colw, hw * 0.9, 12):
                verdict, note = "ALIGNED", "dx %.1f · 欄寬 %.0f" % (dx, colw)
            else:
                verdict, note = "MISALIGNED", "值 x %.0f · 表頭 %s x %.0f · dx %.1f · 欄寬 %.0f" % (vx, per, hx, dx, colw)
        if kind == "TEXT" and not re.fullmatch(r"(?i)net\s*cash|淨現金", val):
            verdict, note = "BADVALUE", "VALUE 不是數字 / 空值記號(科目或底線混進數值欄)· " + note
        elif len([t for t in val.split() if re.search(r"\d", t) or re.fullmatch(r"(?i)[-–—]+|n\.?a\.?|n/a|nm|n\.m\.|nil", t)]) >= 2:
            verdict, note = "BADVALUE", "一格多值 · %s" % note
        si = squash(item)
        rows_sq = [squash("".join(t for _, _, t in tk)) for _, tk in lines]
        wrapped = any(si[:k] in rows_sq[i] and si[k:] in "".join(rows_sq[i + 1:i + 3]) for i in range(len(rows_sq)) for k in range(6, len(si) - 2))   # 科目折行
        if verdict in ("ALIGNED", "PRESENT") and si not in squash(ptxt) and not wrapped:
            verdict, note = "BADITEM", "科目 %r 本頁原文沒有 · %s" % (item, note)
        if verdict in ("FAIL", "MISALIGNED", "BADITEM") and is_image(pdf, int(x["PAGE"])):
            verdict, note = "OCR", "影像頁(文字層沒有字)· 人工核對 · " + note
        res.append(dict(x, _V=verdict, _N=note))
    return res


_PL = {}
_VTOK = re.compile(r"(?i)^(?:\(?-?\d[\d,]*\.?\d*\)?%?|\(?-?\.\d+\)?%?|\d+(?:\.\d+)?pp|n\.?a\.?|n/a|nm|n\.m\.|[-–—]+)$")
_PERTOK = re.compile(r"(?i)^(?:FY)?(?:19|20)?\d{2}[AEFP]?$|^[1-4]Q\d{2}[AEFP]?$|^(?:19|20)\d{2}\([AEFP]\)$")


def plumber_lines(pdf, pno):
    """第三種讀法(pdfplumber 字詞框 · 跟 VRN-2 子欄拆分用的 pypdfium2 不同):回 [(top, [(x0, x1, 字)])] 由上到下。"""
    key = (str(pdf), pno)
    if key not in _PL:
        import pdfplumber
        out = []
        with pdfplumber.open(str(pdf)) as d:
            if 1 <= pno <= len(d.pages):
                ws = d.pages[pno - 1].extract_words(keep_blank_chars=False)
                rows = []
                for w in sorted(ws, key=lambda w: w["top"]):
                    rw = next((r for r in rows if abs(r[0] - w["top"]) < 3.0), None)
                    if rw is None:
                        rw = [w["top"], []]
                        rows.append(rw)
                    rw[1].append((w["x0"], w["x1"], nfk(w["text"])))
                out = [(t, sorted(tk)) for t, tk in sorted(rows, key=lambda r: r[0])]
        _PL[key] = out
    return _PL[key]


_MU = {}


def mupdf_lines(pdf, pno):
    """第四種讀法(PyMuPDF 字詞框 · VRN-2 v0235 的閘用 pdfplumber · 拆分用 pypdfium2 → 驗證器用別的):回 [(top, [(x0, x1, 字)])] 由上到下 · 沒有 PyMuPDF → pdfplumber。"""
    key = (str(pdf), pno)
    if key not in _MU:
        try:
            import pymupdf as fitz  # noqa: WPS433
        except Exception:  # noqa: BLE001
            try:
                import fitz  # noqa: WPS433
            except Exception:  # noqa: BLE001
                _MU[key] = plumber_lines(pdf, pno)
                return _MU[key]
        out = []
        with fitz.open(str(pdf)) as d:
            if 1 <= pno <= len(d):
                rows = []
                for w in sorted(d[pno - 1].get_text("words"), key=lambda w: w[1]):
                    rw = next((r for r in rows if abs(r[0] - w[1]) < 3.0), None)
                    if rw is None:
                        rw = [w[1], []]
                        rows.append(rw)
                    rw[1].append((w[0], w[2], nfk(w[4])))
                out = [(t, sorted(tk)) for t, tk in sorted(rows, key=lambda r: r[0])]
        _MU[key] = out
    return _MU[key]


def verify_subcol(rows, pdfdir):
    """子欄(一格多值拆開)逐列查 · PyMuPDF 字詞框(沒有 → pdfplumber):
    ① 整列數值序列 = 原文那一列(不漏 · 不多 · 順序同)② 期間 = 數據列上方最近的期間表頭
    ③ 同一期間內子欄標籤不重複 ④ 期間表頭的 x 落在該期間那組值的範圍內 ⑤ 子欄標籤 = 子表頭裡離這個值最近的那個字。"""
    grp = defaultdict(list)
    for x in rows:
        grp[(x["FILENAME"], x["TABLE"], int(x["PAGE"]), x["ITEM"])].append(x)
    res = []
    for (fn, tb, pno, item), xs in grp.items():
        lines = mupdf_lines(Path(pdfdir) / fn, pno)
        vals = [squash(x["VALUE"]) for x in xs]
        pers = list(dict.fromkeys(x["PERIOD"] for x in xs))
        bad = []
        cand = []
        for k, (top, tk) in enumerate(lines):
            vt = [(a, b, t) for a, b, t in tk if _VTOK.match(t) and squash(t) != squash(item)]   # 科目「NM」(淨利率)不是空值記號
            sq = [squash(t) for _, _, t in vt]
            for i in range(0, len(sq) - len(vals) + 1):
                if sq[i:i + len(vals)] == vals:
                    cand.append((k, vt[i:i + len(vals)], len(sq) == len(vals)))
        hit = None
        for k, vt, full in cand:                                         # 上方最近的期間表頭要含全部期間
            hk = next((kk for kk in range(k - 1, -1, -1) if sum(bool(_PERTOK.match(t)) for _, _, t in lines[kk][1]) >= 2), None)
            if hk is not None and all(any(t == p for _, _, t in lines[hk][1]) for p in pers):
                hit = (k, vt, full, hk)
                break
        if not hit:
            why = "原文找不到同序列的一列" if not cand else "數據列上方最近的期間表頭不是 %s" % "/".join(pers)
            res += [dict(x, _V="SUBFAIL", _N="① ② " + why) for x in xs]
            continue
        k, vt, full, hk = hit
        if not full:
            bad.append("① 原文那一列還有別的值(拆分不完整)")
        hdr = lines[hk][1]
        hx = {p: next(((a + b) / 2 for a, b, t in hdr if t == p)) for p in pers}
        x0_all = min(a for a, _, _ in vt)
        labw = [(a, b, t) for kk in range(hk + 1, k) for a, b, t in lines[kk][1]
                if not re.fullmatch(r"\(?%\)?", t) and not _VTOK.match(t) and (a + b) / 2 > x0_all - 25]
        by_p = defaultdict(list)
        for x, (a, b, t) in zip(xs, vt):
            by_p[x["PERIOD"]].append((x, a, b))
        for p, g in by_p.items():
            labs = [squash(x["SUBCOL"]) for x, _, _ in g]
            if len(set(labs)) != len(labs) or any(re.search(r"#\d+$", x["SUBCOL"]) for x, _, _ in g):
                bad.append("③ %s 子欄標籤重複 %s" % (p, [x["SUBCOL"] for x, _, _ in g]))
            ga, gb = min(a for _, a, _ in g), max(b for _, _, b in g)
            if not (ga - 14 <= hx[p] <= gb + 14):
                bad.append("④ %s 表頭 x %.0f 不在值的範圍 %.0f–%.0f" % (p, hx[p], ga, gb))
            for x, a, b in g:
                if not labw:
                    bad.append("⑤ 找不到子表頭")
                    break
                vx = (a + b) / 2
                nb = min(labw, key=lambda w: abs((w[0] + w[1]) / 2 - vx))
                first = squash(re.sub(r"\s*\(%\)$|\s*#\d+$", "", x["SUBCOL"]).split()[0] if x["SUBCOL"].split() else x["SUBCOL"])
                if squash(re.sub(r"\(%\)$", "", nb[2])) != re.sub(r"\(%\)$", "", first):
                    bad.append("⑤ %s %s 值 %s 最近的子表頭字是 %r" % (p, x["SUBCOL"], x["VALUE"], nb[2]))
        v = "SUBFAIL" if bad else "SUBALIGNED"
        res += [dict(x, _V=v, _N=" | ".join(bad[:3]) if bad else "PyMuPDF 子欄對位 · 表頭 %s" % "/".join(pers)) for x in xs]
    return res


_CJ = "\u4e00-\u9fff\u3000-\u303f\uff00-\uffef"


def verify_trans(rows, pdfdir):
    """轉置表(年份在第一欄 · 科目在表頭)· PyMuPDF 字詞框另查:每個年份一行(年份後面緊接著同序列的值)· 各年份欄位置一致 ·
    欄界內的表頭字(數據上方相連 · 間距 ≤ 行距 + 2pt · 空行不算)接起來 = 科目。"""
    grp = defaultdict(list)
    for x in rows:
        grp[(x["FILENAME"], x["TABLE"], int(x["PAGE"]))].append(x)
    res = []
    for (fn, tb, pno), xs in grp.items():
        lines = mupdf_lines(Path(pdfdir) / fn, pno)
        pers = list(dict.fromkeys(x["PERIOD"] for x in xs))
        items = list(dict.fromkeys(x["ITEM"] for x in xs))
        val = {(x["PERIOD"], x["ITEM"]): x["VALUE"] for x in xs}
        why, hit = "", []
        for pe in pers:
            want = [squash(val.get((pe, it), "")) for it in items]
            found = []
            for k, (top, tk) in enumerate(lines):
                for i, (a, b, t) in enumerate(tk):
                    nxt = tk[i + 1:i + 1 + len(want)]
                    if squash(t) == squash(pe) and len(nxt) == len(want) and [squash(tt) for _, _, tt in nxt] == want:
                        found.append((k, (a + b) / 2, [(aa + bb) / 2 for aa, bb, _ in nxt]))
            if len(found) != 1:
                why = "%s 這一年原文找不到唯一一行同序列的值(%d)" % (pe, len(found))
                break
            hit.append(found[0])
        if not why:
            n = len(items)
            cx = [sorted(h[2][j] for h in hit)[len(hit) // 2] for j in range(n)]
            if any(abs(h[2][j] - cx[j]) > 10 for h in hit for j in range(n)):
                why = "各年份欄位置不一致"
        if not why:
            yx = hit[0][1]
            sp = (cx[-1] - cx[0]) / max(1, n - 1) if n > 1 else 40.0
            edges = [(yx + cx[0]) / 2] + [(cx[j] + cx[j + 1]) / 2 for j in range(n - 1)] + [cx[-1] + sp / 2]
            ks = sorted(h[0] for h in hit)
            gaps = sorted(abs(lines[ks[i + 1]][0] - lines[ks[i]][0]) for i in range(len(ks) - 1)) or [14]
            lim = min(gaps[len(gaps) // 2] + 2, 24)
            hdr, k, py = [], ks[0] - 1, lines[ks[0]][0]
            while k >= 0 and len(hdr) < 6:
                top, tk = lines[k]
                inr = [(a, b, t) for a, b, t in tk if edges[0] <= (a + b) / 2 < edges[-1]]
                if not inr:
                    k -= 1
                    continue
                if abs(py - top) > lim or any(re.search(r"\d", t) and _VTOK.match(t) for _, _, t in inr) or any("::" in t or re.match(r"(?i)^(?:單位|units?\b)", t) for _, _, t in tk):
                    break
                hdr.insert(0, inr)
                py, k = top, k - 1
            labs = [re.sub(r"(?<=[%s])\s+|\s+(?=[%s])" % (_CJ, _CJ), "", " ".join(t for r in hdr for a, b, t in sorted(r) if edges[j] <= (a + b) / 2 < edges[j + 1])).strip() for j in range(n)]
            if [squash(l_) for l_ in labs] != [squash(it) for it in items]:
                why = "表頭接出 %s ≠ 科目" % " / ".join(labs)
        res += [dict(x, _V="TRANSFAIL" if why else "TRANSALIGNED", _N=why or "PyMuPDF 轉置表對位 · %d 年 × %d 科目" % (len(pers), len(items))) for x in xs]
    return res


_BROKER = [(r"(?i)^CLST|clsa|cl-sec", "CLSA"), (r"(?i)^Citi|citi\.com", "Citi"), (r"(?i)^Daiwa|daiwa", "Daiwa"), (r"(?i)^GS-|gs\.com", "Goldman Sachs"),
           (r"(?i)^JP-|jpmorgan", "J.P. Morgan"), (r"(?i)^MQ-|macquarie", "Macquarie"), (r"(?i)^MS-|morganstanley", "Morgan Stanley"),
           (r"凱基|KGI", "凱基"), (r"中信|CTBC", "中信"), (r"華南", "華南"), (r"兆豐", "兆豐"), (r"台新", "台新")]


_MON = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]


def date_in(d, fname, t1):
    """REPORT_DATE(YYYY-MM-DD)在檔名或首頁:西元 / 民國 · 8 碼 / 6 碼 · / . - 年月日 · 英文月份(全名 / 縮寫 · 日月 / 月日)· 壓縮比對。"""
    try:
        y, m, dd = (int(z) for z in d.split("-"))
    except ValueError:
        return False
    roc = y - 1911
    fq = squash(fname)
    if any(s in fq for s in ("%04d%02d%02d" % (y, m, dd), "%03d%02d%02d" % (roc, m, dd), "%02d%02d%02d" % (y % 100, m, dd))):
        return True
    mn, ma = _MON[m - 1], _MON[m - 1][:3]
    cands = ["%04d-%02d-%02d" % (y, m, dd)]
    for yy in ("%04d" % y, "%d" % roc):
        for mm, de in (("%02d" % m, "%02d" % dd), ("%d" % m, "%d" % dd)):
            cands += [yy + sep + mm + sep + de for sep in ("/", ".", "-")] + ["%s年%s月%s日" % (yy, mm, de)]
    cands += ["%s %d, %d" % (mn, dd, y), "%s %d, %d" % (ma, dd, y), "%s. %d, %d" % (ma, dd, y), "%d %s %d" % (dd, mn, y), "%d %s %d" % (dd, ma, y),
              "%02d-%s-%02d" % (dd, ma, y % 100), "%d-%s-%d" % (dd, ma, y), "%02d %s %d" % (dd, ma, y)]
    tq = squash(t1)
    return any(squash(c) in tq for c in cands)


def verify_basic(rows, pdfdir):
    out = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        t1 = all_text(pdf, (1,))
        ta = all_text(pdf)
        st = x.get("_STATUS") or {}
        chk = {}
        def put(k, ok, why=""):
            chk[k] = ("PASS" if ok else "FAIL") + ((" · " + why) if why else "")
        f = x["FILENAME"]
        tk = x.get("TICKER", "")
        put("TICKER", bool(tk) and (tk in f or tk in t1), "檔名或首頁")
        d = x.get("REPORT_DATE", "")
        if d:
            put("REPORT_DATE", date_in(d, f, t1), "檔名 / 首頁(多種日期寫法)")
        tt = x.get("TITLE", "")
        if tt:
            sc = src_score(tt, squash(ta))
            put("TITLE", sc >= 0.8 and not RATING_ONLY.match(nfk(tt).strip()), "原文覆蓋 %.0f%% · 不是只有評等" % (100 * sc))
        for k in ("YFINANCE_TICKER", "ENGLISH_NAME", "RATING"):
            v = nfk(x.get(k, "")).strip()
            if v:
                put(k, squash(v) in squash(t1) or squash(v) in squash(ta), "原文")
        v = x.get("BLOOMBERG_TICKER", "")
        if v:
            put("BLOOMBERG_TICKER", squash(v) in squash(ta) or st.get("BLOOMBERG_TICKER", "").startswith("推算"), "原文或標推算")
        if x.get("NAME"):
            put("NAME", x["NAME"] in f or x["NAME"] in ta, "檔名 / 原文")
        for e in [e for e in (x.get("EMAIL") or "").split("、") if e]:
            put("EMAIL:" + e, e.lower() in re.sub(r"\s+", "", nfk(ta)).lower(), "原文")
        tel = x.get("TEL", "")
        if tel:
            digits = re.sub(r"\D", "", tel)
            put("TEL", len(digits) >= 8 and digits[-8:] in re.sub(r"\D", "", ta), "原文數字")
        accts = [" ".join(w.capitalize() for w in re.split(r"[._]", e.split("@")[0]) if w.isalpha()) for e in (x.get("EMAIL") or "").split("、") if e]
        for nm in [a for a in (x.get("ANALYST") or "").split("、") if a]:
            okn = squash(nm) in squash(ta) and not re.search(r"信箱|電話|郵件|傳真|地址|研究員|分析師|聯絡|日期", nm)
            if not okn and nm in accts and "推算" in (st.get("ANALYST") or ""):
                chk["ANALYST:" + nm] = "EST · 推算(已標示 · Email 帳號 · 原文沒印這個寫法)"
                continue
            put("ANALYST:" + nm, okn, "原文(姓名照原文印 · 不是欄位標籤)")
        b = x.get("BROKER", "")
        if b:
            exp = next((name for rx, name in _BROKER if re.search(rx, f) or re.search(rx, x.get("EMAIL", ""))), None)
            put("BROKER", exp is None or squash(exp)[:4] in squash(b) or squash(b)[:4] in squash(exp), "檔名 / 網域 → %s" % exp)
        for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
            v = x.get(k, "")
            if v:
                put(k, num_in(v, ta), "原文")
        up = x.get("UPSIDE_PCT", "")
        if up:
            if (st.get("UPSIDE_PCT") or "").startswith("計算"):
                try:
                    calc = (float(x["TARGET_PRICE"].replace(",", "")) / float(x["CURRENT_PRICE_REPORT"].replace(",", "")) - 1) * 100
                    put("UPSIDE_PCT", abs(calc - float(up)) < 0.06, "重算 %.2f" % calc)
                except (ValueError, ZeroDivisionError, KeyError):
                    put("UPSIDE_PCT", False, "無法重算")
            else:
                put("UPSIDE_PCT", num_in(up, ta) or num_in(up.lstrip("+"), ta), "原文")
        if is_image(pdf, 1):
            chk = {k: ("OCR · 影像頁(文字層沒有字)· 人工核對" if v.startswith("FAIL") else v) for k, v in chk.items()}
        out.append({"FILENAME": f, "checks": chk})
    return out


def _nums_raw(text):
    """原文數字(兩種讀法聯集:原樣 · 字距拆開接回)· 千分位去掉。原樣那份不接空白(表格相鄰數字不會黏在一起)。"""
    out = []
    for t in (nfk(text), re.sub(r"(?<=[\d.,])\s+(?=[\d.,])", "", nfk(text))):
        t = re.sub(r"(?<=\d),(?=\d{3}(?!\d))", "", t)
        out += [float(x) for x in re.findall(r"(?<![\d.])\d+(?:\.\d+)?(?![\d.])", t)]
    return out


def verify_point(v, text, rsq):
    """一個重點 → 逐段檢查:原文句(覆蓋 ≥85% · 數字在原文)· 摘要器組句(評價句 / EPS 序列:輸入數字在原文 · 「計算」的值重算對得上)。回 (PASS/FAIL, 說明)。"""
    v = nfk(v)
    segs = [x.strip(" ,，。") for x in re.split(r"[；;⚫•]", v) if x.strip(" ,，。")]
    nums = None
    bad, notes, eps = [], [], []
    for sg in segs:
        m = re.match(r"^(\d{4}) 年 .*?EPS.*?\s([\-\d.,]+)(?: TWD)?(?:\s*[（(]計算 YoY ([\-\d.]+)%[）)])?$", sg)
        if m:
            eps.append((int(m.group(1)), float(m.group(2).replace(",", "")), float(m.group(3)) if m.group(3) else None))
            if not num_in(m.group(2), text):
                bad.append("EPS %s 不在原文" % m.group(2))
            continue
        if sg.startswith("目標價 ") or "上漲空間" in sg or sg.startswith(("原目標價", "目標價依據", "報告潛在")):
            for k_, val in re.findall(r"(目標價|原目標價|倍)\s*([\d.,]+)", sg) + [("倍", x) for x in re.findall(r"([\d.]+)\s*倍", sg)]:
                if not num_in(val, text):
                    bad.append("%s %s 不在原文" % (k_, val))
            mu = re.search(r"上漲空間\s*(-?[\d.]+)%", sg)
            if mu:
                if "計算" in sg:
                    tp = re.search(r"目標價\s*([\d.,]+)", v)
                    nums = nums if nums is not None else _nums_raw(text)
                    z = float(mu.group(1))
                    okz = tp is not None and any(n > 0 and abs((float(tp.group(1).replace(",", "")) / n - 1) * 100 - z) <= 0.06 for n in nums)
                    notes.append("上漲空間重算%s" % ("對" if okz else "對不上"))
                    if not okz:
                        bad.append("上漲空間 %s%% 重算對不上" % mu.group(1))
                elif not num_in(mu.group(1), text):
                    bad.append("上漲空間 %s%% 不在原文" % mu.group(1))
            continue
        sc = src_score(sg, rsq)
        if sc < 0.85:                                                    # 標題 + 句子黏在一起(原文中間隔著圖表字)→ 兩段各自在原文也算
            q = squash(sg)
            if any(q[:k] in rsq and src_score(q[k:], rsq) >= 0.9 for k in range(4, min(len(q) - 4, 24))):
                sc = 0.9
        nb = [n for n in re.findall(r"\d[\d,]*\.?\d*", sg) if len(n.strip(",.")) >= 2 and not num_in(n.strip(",."), text)]
        if sc < 0.85 or nb:
            bad.append("原文句覆蓋 %.0f%%%s「%s」" % (100 * sc, (" · 數字不在原文 " + "、".join(nb[:3])) if nb else "", sg[:30]))
    for i, (y, x, yoy) in enumerate(eps):
        if yoy is None:
            continue
        prev = eps[i - 1][1] if i and eps[i - 1][0] == y - 1 else None
        if prev is not None:
            ok_ = prev and abs((x / prev - 1) * 100 - yoy) <= 0.06
        else:
            nums = nums if nums is not None else _nums_raw(text)
            ok_ = any(n and abs((x / n - 1) * 100 - yoy) <= 0.06 for n in nums)
        notes.append("%d YoY 重算%s" % (y, "對" if ok_ else "對不上"))
        if not ok_:
            bad.append("%d YoY %.1f%% 重算對不上" % (y, yoy))
    return ("FAIL" if bad else "PASS"), " · ".join(bad or notes)[:200]


def verify_summary(rows, pdfdir):
    out = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        text = all_text(pdf)
        rsq = squash(text)
        chk = {}
        if x.get("TITLE"):
            sc = src_score(x["TITLE"], rsq)
            chk["TITLE"] = ("PASS" if sc >= 0.8 and not RATING_ONLY.match(nfk(x["TITLE"]).strip()) else "FAIL") + " · 原文覆蓋 %.0f%%" % (100 * sc)
        for i in range(1, 5):
            v = x.get("POINT_%d" % i) or ""
            if v:
                r_, n_ = verify_point(v, text, rsq)
                chk["POINT_%d" % i] = r_ + " · " + n_
        if is_image(pdf, 1):
            chk = {k: ("OCR · 影像頁(文字層沒有字)· 人工核對" if v.startswith("FAIL") else v) for k, v in chk.items()}
        out.append({"FILENAME": x["FILENAME"], "checks": chk, "points_ok": x.get("POINTS_OK")})
    return out


BADV = ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM", "SUBFAIL", "TRANSFAIL", "DUPKEY")


def dupkey(vf):
    """一致性(跟讀法無關):同檔 · 同表 · 同一列(ROW · 沒有就用段落)· 同科目 · 同期間 · 同子欄 只能有一個值 → 兩個以上不同的值 = DUPKEY(兩種讀法一致地讀錯欄也抓得到)。"""
    g = defaultdict(set)
    k_ = lambda r: (r["FILENAME"], r.get("TABLE"), r.get("ROW") or ("S", r.get("SECTION", "")), r.get("ITEM"), r.get("PERIOD"), r.get("SUBCOL", ""))   # noqa: E731
    for r in vf:
        g[k_(r)].add(squash(r.get("VALUE", "")))
    out = []
    for r in vf:
        vs = g[k_(r)]
        if len(vs) > 1:
            r = dict(r, _V="DUPKEY", _N="同一列同科目同期間有 %d 個不同的值:%s" % (len(vs), " / ".join(sorted(vs))[:80]))
        out.append(r)
    return out


def run_files(od, pdfdir, files):
    """指定的檔(None = 全部)→ (基本資料, 年度數據, 一標題四重點) 驗證結果。"""
    od = Path(od)
    pick = (lambda r: True) if files is None else (lambda r, fs=set(files): r["FILENAME"] in fs)
    basic = [r for r in json.loads((od / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8")) if pick(r)]
    fin = [r for r in json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8")) if pick(r)]
    sp = od / "VRN2_Summary_latest.json"
    summ = [r for r in json.loads(sp.read_text(encoding="utf-8")) if pick(r)] if sp.exists() else []
    vb = verify_basic(basic, pdfdir)
    tr = lambda x: "轉置" in str(x.get("VERIFY", ""))                       # noqa: E731
    vf = (verify_fin([x for x in fin if not x.get("SUBCOL") and not tr(x)], pdfdir) + verify_subcol([x for x in fin if x.get("SUBCOL")], pdfdir)
          + verify_trans([x for x in fin if tr(x)], pdfdir))
    vs = verify_summary(summ, pdfdir)
    return vb, vf, vs


def _workers(n_files):
    """平行路數:CPU − 1(上限 6)· 可用 RAM < 2 GB → 2 · VRN2_VERIFY_PAR=1 序跑 / 數字 = 手動。"""
    import os
    env = os.environ.get("VRN2_VERIFY_PAR", "")
    if env.isdigit():
        return max(1, min(int(env), n_files))
    w = max(1, min(6, (os.cpu_count() or 2) - 1, n_files))
    try:
        import psutil
        if psutil.virtual_memory().available < 2 * 1024 ** 3:
            w = min(w, 2)
    except Exception:  # noqa: BLE001
        pass
    return w


def run_parallel(od, pdfdir):
    """依檔分片 · 子行程平行(每路自己的快取 · 依年度數據筆數 LPT 分配)· 子行程先接加速器(VRN2_ACCEL_WRAP + VRN2_VIA_ROOT 有給就經包裝執行)。"""
    import os
    import subprocess
    import tempfile
    from collections import Counter as _C
    od = Path(od)
    fin = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
    basic = json.loads((od / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
    load = _C(r["FILENAME"] for r in fin)
    files = sorted({r["FILENAME"] for r in basic} | set(load), key=lambda f_: -load.get(f_, 0))
    w = _workers(len(files))
    if w <= 1:
        return run_files(od, pdfdir, None) + (1,)
    shards = [[] for _ in range(w)]
    tot = [0] * w
    for f_ in files:
        i = tot.index(min(tot))
        shards[i].append(f_)
        tot[i] += load.get(f_, 0) + 30
    td = Path(tempfile.mkdtemp(prefix="vrn2_verify_"))
    head = [sys.executable]
    if os.environ.get("VRN2_ACCEL_WRAP") and os.environ.get("VRN2_VIA_ROOT"):
        head += [os.environ["VRN2_ACCEL_WRAP"], os.environ["VRN2_VIA_ROOT"]]
    procs = []
    for i, sh in enumerate(shards):
        (td / ("in_%d.json" % i)).write_text(json.dumps(sh, ensure_ascii=False), encoding="utf-8")
        procs.append(subprocess.Popen(head + [str(Path(__file__).resolve()), "--shard", str(od), str(pdfdir), str(td / ("in_%d.json" % i)), str(td / ("out_%d.json" % i))],
                                      stdout=subprocess.DEVNULL, stderr=open(td / ("err_%d.txt" % i), "w", encoding="utf-8")))
    vb, vf, vs = [], [], []
    for i, pr in enumerate(procs):
        pr.wait()
        op = td / ("out_%d.json" % i)
        if pr.returncode != 0 or not op.exists():
            raise RuntimeError("驗證分片 %d 失敗:%s" % (i, (td / ("err_%d.txt" % i)).read_text(encoding="utf-8")[-600:]))
        d = json.loads(op.read_text(encoding="utf-8"))
        vb += d["basic"]
        vf += d["fin"]
        vs += d["summary"]
    return vb, vf, vs, w


def write_digest(path, vb, vf, vs, w):
    """貼給 AI 的摘要(≤150 行):各冊計數 · 不過的類別與理由 · 每類最多 12 筆例子(檔 · 表 · 科目 · 期間 · 子欄 · 值 · 理由)。"""
    from collections import Counter as _C
    L = ["[驗證摘要] VRN-2 獨立驗證 v2 · 平行 %d 路" % w]
    bc = _C(v.split(" ·")[0] for r in vb for v in r["checks"].values())
    sc = _C(v.split(" ·")[0] for r in vs for v in r["checks"].values())
    fc = _C(r["_V"] for r in vf)
    L += ["基本資料 %d 份 %s" % (len(vb), dict(bc)), "一標題四重點 %d 份 %s" % (len(vs), dict(sc)), "年度數據 %d 筆 %s" % (len(vf), dict(fc))]
    for nm, rs in (("基本資料", vb), ("一標題四重點", vs)):
        bad = [(r["FILENAME"], k, v) for r in rs for k, v in r["checks"].items() if not v.startswith("PASS")]
        for f_, k, v in bad[:25]:
            L.append("  %s %s · %s · %s" % (nm, f_[:44], k, v[:110]))
    for cat in BADV + ("OCR", "PRESENT"):
        xs = [r for r in vf if r["_V"] == cat]
        if not xs:
            continue
        why = _C(re.sub(r"[\d.,]+", "#", r["_N"])[:40] for r in xs)
        L.append("年度數據 %s %d 筆 · 理由前 3:%s" % (cat, len(xs), " | ".join("%s ×%d" % kv for kv in why.most_common(3))))
        byf = _C(r["FILENAME"] for r in xs)
        L.append("  檔:%s" % " · ".join("%s ×%d" % (f_[:30], n) for f_, n in byf.most_common(6)))
        for r in xs[:12 if cat in BADV else 4]:
            L.append("  %s | %s | %s | %s | %s | %s | %s" % (r["FILENAME"][:30], r.get("TABLE", ""), str(r.get("ITEM", ""))[:22], r.get("PERIOD", ""), r.get("SUBCOL", ""), r.get("VALUE", ""), r["_N"][:90]))
    Path(path).write_text("\n".join(L[:150]) + "\n", encoding="utf-8")
    return L[:150]


def main(od, pdfdir, rep):
    vb, vf, vs, w = run_parallel(od, pdfdir)
    vf = dupkey(vf)
    sc_ = Counter(v.split(" ·")[0] for r in vs for v in r["checks"].values())
    bc = Counter(v.split(" ·")[0] for r in vb for v in r["checks"].values())
    fc = Counter(r["_V"] for r in vf)
    per_file = defaultdict(Counter)
    for r in vf:
        per_file[r["FILENAME"]][r["_V"]] += 1
    Path(rep).write_text(json.dumps({"basic": vb, "summary": vs, "summary_counts": dict(sc_), "fin_counts": dict(fc), "fin_per_file": {k: dict(v) for k, v in per_file.items()},
                                     "fin_bad": [r for r in vf if r["_V"] in BADV], "fin_ocr": [r for r in vf if r["_V"] == "OCR"]}, ensure_ascii=False, indent=1), encoding="utf-8")
    write_digest(str(rep) + ".digest.txt", vb, vf, vs, w)
    print("[驗證] 基本資料 %d 份 · 欄位檢查 %s" % (len(vb), dict(bc)))
    for r in vb:
        bad = {k: v for k, v in r["checks"].items() if v.startswith("FAIL")}
        if bad:
            print("  [FAIL] %s · %s" % (r["FILENAME"][:40], " | ".join("%s %s" % kv for kv in bad.items())[:300]))
    print("[驗證] 一標題四重點 %d 份 · 欄位檢查 %s" % (len(vs), dict(sc_)))
    for r in vs:
        bad = {k: v for k, v in r["checks"].items() if v.startswith("FAIL")}
        if bad:
            print("  [FAIL] %s · %s" % (r["FILENAME"][:40], " | ".join("%s %s" % kv for kv in bad.items())[:300]))
    print("[驗證] 年度數據 %d 筆 · %s" % (len(vf), dict(fc)))
    for f, c in sorted(per_file.items()):
        print("  %-46s %s" % (f[:46], dict(c)))
    print("[驗證] 摘要 %s.digest.txt(貼給 AI 用)· 平行 %d 路" % (rep, w))
    return 0 if not any(v.startswith("FAIL") for r in vb + vs for v in r["checks"].values()) and not any(fc.get(k) for k in BADV) else 1


if __name__ == "__main__":
    if sys.argv[1:2] == ["--shard"]:
        _od, _pd, _in, _out = sys.argv[2:6]
        _vb, _vf, _vs = run_files(_od, _pd, json.loads(Path(_in).read_text(encoding="utf-8")))
        Path(_out).write_text(json.dumps({"basic": _vb, "fin": _vf, "summary": _vs}, ensure_ascii=False), encoding="utf-8")
        sys.exit(0)
    sys.exit(main(*sys.argv[1:4]))
