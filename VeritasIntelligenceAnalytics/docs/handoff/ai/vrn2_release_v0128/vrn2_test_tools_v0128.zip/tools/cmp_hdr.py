"""v0101 表頭列(HDRVAL)反向測試:v0237 輸出裡真的出現過的 3 列表頭(11 筆 · 凱基 2637 / JP 2330 / GS 6415)放回年度數據 → v0101 必須全抓到 · v0100 對照(漏抓)。
用法:python cmp_hdr.py <output 夾> <PDF 夾> [fixture/HDRROWS_v0237_output.json]"""
import collections
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs as V  # noqa: E402
import verify_outputs_v0100 as V0  # noqa: E402

od, pd = Path(sys.argv[1]), sys.argv[2]
fx = Path(sys.argv[3]) if len(sys.argv) > 3 else Path(__file__).resolve().parent.parent / "fixture" / "HDRROWS_v0237_output.json"
fin = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
hdr = json.loads(fx.read_text(encoding="utf-8"))
cnt = lambda rs: dict(collections.Counter(r["_V"] for r in rs))  # noqa: E731
base = V.hdrval([dict(r, _V="ALIGNED", _N="") for r in fin])
print("原樣(值的種類)%s %s · 表頭列 %d 筆" % (V.VERSION[-5:], cnt(base), sum(1 for r in base if r["_V"] == "HDRVAL")))
old = V0.dupkey(V0.verify_fin(hdr, pd))
print("對照 v0100 表頭列放回(%d 筆)→ %s(表頭字本來就在期間那一欄 → 判對位 = 漏抓)" % (len(hdr), cnt(old)))
new = V.hdrval(V.dupkey(V.verify_fin(hdr, pd)))
print("反向 表頭列放回(%d 筆)%s 仍 ALIGNED %d · %s" % (len(hdr), V.VERSION[-5:], sum(1 for r in new if r["_V"] == "ALIGNED"), cnt(new)))
mix = V.hdrval(V.dupkey([dict(r, _V="ALIGNED", _N="") for r in fin] + [dict(r, _V="ALIGNED", _N="") for r in hdr]))
print("反向 表頭列混進整本冊(%d + %d 筆)%s 仍過 %d · 一般列被誤標 %d" % (len(fin), len(hdr), V.VERSION[-5:], sum(1 for r in mix[len(fin):] if r["_V"] != "HDRVAL"), sum(1 for r in mix[:len(fin)] if r["_V"] == "HDRVAL")))
ok = cnt(base).get("HDRVAL", 0) == 0 and all(r["_V"] == "HDRVAL" for r in new) and all(r["_V"] == "HDRVAL" for r in mix[len(fin):]) and not any(r["_V"] == "HDRVAL" for r in mix[:len(fin)])
print("[計] 表頭列反向測試 %s" % ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 1)
