"""tools/verify_outputs.py(v3)→ VRN2_IndependentVerifier_v0100.py(啟動器內嵌 · 背景跑 · 結果寫回 U/I)。
用法:python make_verifier_v0100.py <verify_outputs.py v3> <_bridge_block.txt> <輸出 .py>"""
import sys
from pathlib import Path

src = Path(sys.argv[1]).read_text(encoding="utf-8")
bridge = Path(sys.argv[2]).read_text(encoding="utf-8")
out_p = Path(sys.argv[3])


def rep(old, new, n=1):
    global src
    assert src.count(old) == n, ("錨點", old[:80], src.count(old))
    src = src.replace(old, new)


# 1) 檔頭:說明 + 版號 + 加速器橋
head_end = src.index('"""', 3) + 3
doc = '''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VRN2_IndependentVerifier_v0100 — VRN-2 輸出值獨立驗證(由 tools/verify_outputs v3 升版 · 啟動器 v0127 內嵌 · ⑦ 之後背景跑 · 只讀)。
  不 import 任何 VRN-2 程式 · 讀法與擷取不同(年度數據 pypdfium2 字元框 · 子欄 / 轉置表 PyMuPDF · 擷取用 pdfplumber)。

用法:python VRN2_IndependentVerifier_v0100.py <output 夾> <PDF 夾> <報告 .json> [--ui <VRN2_UI_latest.html>]
      python VRN2_IndependentVerifier_v0100.py --selftest
  基本資料:每欄值必須在 PDF 原文找得到(或可由原文重算)· 推算值要標推算
  年度數據:每筆 VALUE 必須在該頁 · 同列有 ITEM · 數值落在 PERIOD 表頭那一欄(x 對齊)
  子欄(SUBCOL):PyMuPDF 字詞框另查 · 轉置表(VERIFY 有「轉置」)另查 · DUPKEY 一致性(同檔 · 表 · 列 · 科目 · 期間 · 子欄只能一個值)
  v0100:① 每筆帶冊內序號(_I)· 報告多 fin_rows(每筆判決)與冊指紋(fp)· --ui 把判決寫回 U/I「驗證過的輸出」分頁(指紋不同 → U/I 不套用)
        ② 值列與科目列上下錯開(值比科目高半行:凱基首頁 EV/EBITDA · 淨負債比率)→ 只在本列找不到值時看上下鄰列(互為最近 · 鄰列科目欄沒有別的字)
        ③ 兩個字詞的值(Net cash)整組比對
  依檔分片平行(子行程 · 路數依 CPU / RAM · VRN2_VERIFY_PAR)· 另寫 <報告>.digest.txt(≤150 行 · 貼給 AI 用)
"""
VERSION = "VRN2_IndependentVerifier_v0100"


'''
src = doc + bridge.strip("\n") + "\n\n\n" + src[head_end:].lstrip("\n")
rep("import json\nimport re\nimport sys\n", "import hashlib\nimport json\nimport re\nimport sys\n")

# 2) 年度數據:值的比對抽成函式(兩個字詞的值 · 每列各自比)+ 對表頭抽成函式 + 先定列再找值
rep('''def verify_fin(rows, pdfdir):
    res = []''', '''def _hits(tk, sv, xmin=-1e9, xmax=1e9):
    """一列字詞裡等於值的 [(中心 x, x0, x1, 字)](xmin < x0 < xmax)· v0100 相鄰兩個字詞(字距 < 4)合起來等於值也算(Net cash)。"""
    tk = sorted(tk)
    out = [((a + b) / 2, a, b, t) for a, b, t in tk if xmin < a < xmax and (squash(t) == sv or squash(t) == sv.replace(",", ""))]
    for (a1, b1, t1), (a2, b2, t2) in zip(tk, tk[1:]):
        if xmin < a1 < xmax and 0 <= a2 - b1 < 4 and squash(t1 + t2) == sv:
            out.append(((a1 + b2) / 2, a1, b2, t1 + " " + t2))
    return out


_MONI = {m: i for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"))}


def _mi(t):
    """「月-年」期間(Dec-27F)→ 月序號 · 不是 → None。"""
    m = re.match(r"^([A-Za-z]{3})-(\\d{2})[AEFP]?$", t)
    return int(m.group(2)) * 12 + _MONI[m.group(1).lower()] if m and m.group(1).lower() in _MONI else None


def _qtr_x(tk):
    """v0100 表頭一列裡相鄰兩個「月-年」期間差 3 個月 = 季度欄 → 回這些字的 x0(差 12 個月 = 年度欄)。"""
    ms = [(a, _mi(t)) for a, b, t in sorted(tk) if _mi(t) is not None]
    q = set()
    for (a1, m1), (a2, m2) in zip(ms, ms[1:]):
        if m2 - m1 == 3:
            q.update((a1, a2))
    return q


def _align(lines, y, per, hits, best=None):
    """每個在上方、同期間字樣的表頭都試 · 取 x 最近(並排表各自的表頭)· 回 (dx, 欄寬, 表頭 x, 值 x, 表頭寬, 表頭 y, 是否季度欄)。
    v0100 同一列表頭同一個期間印兩次(季度段 Dec-27F · 年度段 Dec-27F)→ 只用年度那個(年度數據冊)。"""
    for yy, tk in lines:
        if not (y - 1 < yy < y + 520):
            continue
        qx = _qtr_x(tk)
        dup = sum(1 for a, b, t in tk if t == per) >= 2 and any(a not in qx for a, b, t in tk if t == per)
        for a, b, t in tk:
            if t != per or (dup and a in qx):
                continue
            hx = (a + b) / 2
            colw = min([abs((aa + bb) / 2 - hx) for aa, bb, tt in tk if tt != per and re.match(r"^(?:FY)?\\d{2,4}[AEFP]?$|^\\d{1,2}/\\d{2}[AEFe]?$|^[A-Z][a-z]{2}-\\d{2}[AEF]$", tt)] + [60])
            oth = [(aa + bb) / 2 for aa, bb, tt in tk if (aa, tt) != (a, t) and re.match(r"^(?:FY)?\\d{2,4}[AEFP]?$|^\\d{1,2}/\\d{2}[AEFe]?$|^[A-Z][a-z]{2}-\\d{2}[AEFP]$", tt)]
            for vx, va, vb, vt in hits:
                dx = abs(vx - hx)
                if any(abs(c - vx) < dx for c in oth):              # v0100 值離別的期間表頭更近 → 不是這一欄
                    continue
                if best is None or dx < best[0]:
                    best = (dx, colw, hx, vx, b - a, yy, a in qx)
    return best


_NILT = re.compile(r"(?i)^(?:[-–—]+|n\\.?a\\.?|nm|n/?m|n/?a|nil|neg\\.?|ns)$")


def _isval(t):
    """數值或空值記號(- · n.a. · NM …)。"""
    return bool(re.search(r"\\d", t)) or bool(_NILT.match(t))


def _lab_block(tk, key):
    """這一列含科目前 14 字的那段科目字(從科目開頭起 · 左右接同一詞組的非數值字詞 · 字距 < 6)→ (x0, x1, 壓縮字) · 沒有 → None。"""
    tk = sorted(tk)
    sp = None
    for i in range(len(tk)):
        s = ""
        for j in range(i, len(tk)):
            s += squash(tk[j][2])
            if key in s:
                sp = (i, j)
                break
            if len(s) > len(key) + 40:
                break
        if sp:
            break
    if not sp:
        return None
    i, j = sp
    while i < j and key in "".join(squash(t) for _, _, t in tk[i + 1:j + 1]):   # 從科目開頭那個字起(不帶左邊別欄的字)
        i += 1
    while i > 0 and not _isval(tk[i - 1][2]) and tk[i][0] - tk[i - 1][1] < 6:    # 同一詞組的字距 ≤ 4 pt · 別欄 / 並排表 ≥ 7 pt(實測)
        i -= 1
    while j + 1 < len(tk) and not _isval(tk[j + 1][2]) and tk[j + 1][0] - tk[j][1] < 6:
        j += 1
    return tk[i][0], tk[j][1], "".join(squash(t) for _, _, t in tk[i:j + 1])


def _lab_ok(lab, isq):
    """v0100 這一列的科目字就是這個科目(不是只「含」:EPS ≠ EPS growth · Revenue ≠ Total revenue):相同 · 折行(科目開頭 · 後半在下一列)· 原文多印單位(括號)。"""
    lab, isq = re.sub(r"^[•·\\-–—*]+", "", lab), re.sub(r"^[•·\\-–—*]+", "", isq)   # 開頭的項目符號(- · •)兩邊都去掉
    if lab == isq:
        return "同"
    if isq.startswith(lab) and len(lab) >= min(len(isq), 6):
        return "折行"
    if lab.startswith(isq) and re.fullmatch(r"[(\\[(].*[)\\])]|[:：]", lab[len(isq):]):
        return "單位"
    return ""


def _seg_end(tk, lx1):
    """v0100 並排表:科目右邊的值之後又出現別的科目字(另一張表)→ 這張表到那個字之前為止。"""
    seen = False
    ts = [z for z in sorted(tk) if z[0] > lx1 + 2]
    for i, (a, b, t) in enumerate(ts):
        pair = (squash(t) == "net" and i + 1 < len(ts) and squash(ts[i + 1][2]) == "cash" and ts[i + 1][0] - b < 4) or (squash(t) == "cash" and i > 0 and squash(ts[i - 1][2]) == "net")
        if _isval(t) or pair or squash(t) in ("x", "%"):
            seen = True
        elif seen and len(squash(t)) >= 2:
            return a - 1
    return 1e9


def _wrap_ok(lines, k, lb, isq):
    """v0100 折行要真的折行:下一列(16 pt 內)科目欄的字 = 科目剩下的那段(不然 Gross profit 那列會被當成 Gross profit margin)。"""
    lab, isq = re.sub(r"^[•·\\-–—*]+", "", lb[2]), re.sub(r"^[•·\\-–—*]+", "", isq)
    rest = isq[len(lab):]
    j = k + 1
    if not rest or j >= len(lines) or abs(lines[j][0] - lines[k][0]) >= 16:     # 折行那段可能在兩列中間(MS ModelWare net inc (NT / $ bn) 差 14.0 pt)
        return False
    nx = "".join(squash(t) for a, b, t in sorted(lines[j][1]) if lb[0] - 3 <= a <= lb[1] + 60 and not _isval(t))
    return bool(nx) and (rest.startswith(nx) or nx.startswith(rest))


def _lab_only(tk, lx0, lx1):
    """只有科目、沒有數值的列:科目欄起點有字 · 科目右邊沒有數值。"""
    return any(abs(a - lx0) <= 3 and not _isval(t) for a, b, t in tk) and not any(_isval(t) for a, b, t in tk if a > lx1 + 2)


def _row_hits(lines, k, lb, isq, sv):
    """v0100 這個科目那一列的值(先定列 · 再找值 → 別列的值不會被當成這一列的):
    科目列右邊有數值 → 只看科目列;沒有 → 上下鄰列中最近、有數值、科目欄不是別的科目(是科目接續可以)的那一列 · 那列不能離另一個只有科目的列更近(互為最近)。
    回 (hits, dy) · 定不出列 → None。"""
    y, tk = lines[k]
    lx0, lx1 = lb[0], lb[1]
    if any(_isval(t) for a, b, t in tk if a > lx1 + 2):
        return _hits(tk, sv, lx1 + 2, _seg_end(tk, lx1)), 0.0
    nb = []
    for j in (k - 1, k + 1):
        if 0 <= j < len(lines) and abs(lines[j][0] - y) < 14:
            tj = lines[j][1]
            labj = "".join(squash(t) for a, b, t in sorted(tj) if not _isval(t) and a < lx1 and b > lx0)
            if labj and labj not in isq:
                continue
            if any(_isval(t) for a, b, t in tj if a > lx1 + 2):
                nb.append((abs(lines[j][0] - y), j))
    if not nb:
        return None
    d, j = min(nb)
    if any(abs(lines[j][0] - lines[k2][0]) < d for k2 in (j - 1, j + 1) if k2 != k and 0 <= k2 < len(lines) and _lab_only(lines[k2][1], lx0, lx1)):
        return None
    return _hits(lines[j][1], sv, lx1 + 2, _seg_end(lines[j][1], lx1)), lines[j][0] - y


def verify_fin(rows, pdfdir, allrows=None):
    res = []
    occ = defaultdict(set)                                       # v0100 同一張表同名科目出現幾次(依 ROW · allrows = 整本冊的這幾檔 · 預設 rows)
    for z in (rows if allrows is None else allrows):
        if z.get("ROW"):
            occ[(z["FILENAME"], int(z["PAGE"]), z.get("TABLE"), nfk(z["ITEM"]).strip())].add(int(z["ROW"]))''')
rep('''        best = None
        for k in cand:
            y = lines[k][0]
            row_toks = [tt for kk in (k, k + 1) if kk < len(lines) and abs(lines[kk][0] - y) < 14 for tt in lines[kk][1]]
            hits = [((a + b) / 2, a, b, t) for a, b, t in row_toks if squash(t) == sv or squash(t) == sv.replace(",", "")]
            if not hits:
                continue
            for yy, tk in lines:                                 # 每個在上方、同期間字樣的表頭都試 · 取 x 最近(並排表各自的表頭)
                if not (y - 1 < yy < y + 520):
                    continue
                for a, b, t in tk:
                    if t != per:
                        continue
                    hx = (a + b) / 2
                    colw = min([abs((aa + bb) / 2 - hx) for aa, bb, tt in tk if tt != per and re.match(r"^(?:FY)?\\d{2,4}[AEFP]?$|^\\d{1,2}/\\d{2}[AEFe]?$|^[A-Z][a-z]{2}-\\d{2}[AEF]$", tt)] + [60])
                    for vx, va, vb, vt in hits:
                        dx = abs(vx - hx)
                        if best is None or dx < best[0]:
                            best = (dx, colw, hx, vx, b - a, yy)
        if best:
            dx, colw, hx, vx, hw, hy = best
            if dx <= max(0.55 * colw, hw * 0.9, 12):
                verdict, note = "ALIGNED", "dx %.1f · 欄寬 %.0f" % (dx, colw)''', '''        best, shift, how = None, None, ""
        si_ = squash(item)
        labs = []
        for k in cand:                                           # v0100 先定「這個科目那一列」:科目字相同(或折行 / 單位)· 值只從那一列找
            lb = _lab_block(lines[k][1], key)
            how_ = _lab_ok(lb[2], si_) if lb else ""
            if how_ == "折行" and not _wrap_ok(lines, k, lb, si_):
                how_ = ""
            if how_:
                labs.append((k, lb, how_))
        rk = sorted(occ.get((x["FILENAME"], int(x["PAGE"]), x.get("TABLE"), item), ()))
        if len(rk) >= 2 and len(labs) == len(rk) and x.get("ROW") and int(x["ROW"]) in rk and max(lb[0] for _, lb, _ in labs) - min(lb[0] for _, lb, _ in labs) < 10:
            labs = [labs[rk.index(int(x["ROW"]))]]               # 同名科目印了幾次就有幾列(同一欄 · 並排表不算)→ 第 n 次出現的那一列(由上往下)才是這一列
        for k, lb, how_ in labs:
            rh = _row_hits(lines, k, lb, si_, sv)
            if rh and rh[0]:
                b2 = _align(lines, lines[k][0], per, rh[0])
                if b2 and (best is None or b2[0] < best[0]):
                    best, shift, how = b2, rh[1], how_
        if best:
            dx, colw, hx, vx, hw, hy, qq = best
            if dx <= max(0.55 * colw, hw * 0.9, 12):
                verdict, note = "ALIGNED", "dx %.1f · 欄寬 %.0f · 科目列%s%s" % (dx, colw, how, (" · 值列在科目列%s %.1f pt(鄰列 · 互為最近)" % ("上" if shift > 0 else "下", abs(shift))) if shift else "")
                if qq:
                    verdict, note = "QTRCOL", "年度數據冊的值落在季度欄(表頭相鄰期間差 3 個月)· " + note''')

rep('''BADV = ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM", "SUBFAIL", "TRANSFAIL", "DUPKEY")''', '''BADV = ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM", "SUBFAIL", "TRANSFAIL", "DUPKEY", "QTRCOL")   # v0100 + 季度欄''')

# 2b) 子欄:那一列的科目要是這個科目(v3 只比數值序列 · 別列的值也會過)
rep('''def verify_subcol(rows, pdfdir):''', '''def _sub_lab(lines, k, x0, isq):
    \"\"\"v0100 子欄那一列(值從 x0 起)左邊的科目字 = 這個科目(相同 / 折行兩列接起來 / 原文多印單位)· 值那一列沒有科目字 → 上下 14 pt 內只有科目的列。回 (是否相同, 讀到的科目)。\"\"\"
    def run(tk):
        ts = [(a, b, t) for a, b, t in sorted(tk) if b <= x0 + 1 and (not _isval(t) or squash(t) == isq)]   # 科目本身是 NM(淨利率)也算科目字
        if not ts:
            return ""
        r = [ts[-1]]
        for a, b, t in reversed(ts[:-1]):
            if r[0][0] - b < 6:
                r.insert(0, (a, b, t))
            else:
                break
        return "".join(squash(t) for _, _, t in r)
    lab = run(lines[k][1])
    if lab and _lab_ok(lab, isq) in ("同", "單位"):
        return True, lab
    for j in (k - 1, k + 1):
        if 0 <= j < len(lines) and abs(lines[j][0] - lines[k][0]) < 14 and not any(_isval(t) for a, b, t in lines[j][1] if a > x0 - 2):
            lj = run(lines[j][1])
            if lj and ((lab and _lab_ok(lj + lab if j < k else lab + lj, isq) in ("同", "單位")) or (not lab and _lab_ok(lj, isq) in ("同", "單位"))):
                return True, (lj + lab if j < k else lab + lj)
    return False, lab


def verify_subcol(rows, pdfdir):''')
rep('''        hit = None
        for k, vt, full in cand:                                         # 上方最近的期間表頭要含全部期間
            hk = next((kk for kk in range(k - 1, -1, -1) if sum(bool(_PERTOK.match(t)) for _, _, t in lines[kk][1]) >= 2), None)
            if hk is not None and all(any(t == p for _, _, t in lines[hk][1]) for p in pers):
                hit = (k, vt, full, hk)
                break
        if not hit:
            why = "原文找不到同序列的一列" if not cand else "數據列上方最近的期間表頭不是 %s" % "/".join(pers)
            res += [dict(x, _V="SUBFAIL", _N="① ② " + why) for x in xs]
            continue''', '''        hit, hdr_ok, labs_ = None, False, []
        for k, vt, full in cand:                                         # 上方最近的期間表頭要含全部期間
            hk = next((kk for kk in range(k - 1, -1, -1) if sum(bool(_PERTOK.match(t)) for _, _, t in lines[kk][1]) >= 2), None)
            if hk is not None and all(any(t == p for _, _, t in lines[hk][1]) for p in pers):
                hdr_ok = True
                okl, lab_ = _sub_lab(lines, k, min(a for a, _, _ in vt), squash(item))   # v0100 ⑥ 那一列的科目 = 這個科目
                labs_.append(lab_)
                if okl:
                    hit = (k, vt, full, hk)
                    break
        if not hit:
            why = ("⑥ 同序列那一列的科目是 %s · 不是 %r(值是別列的)" % (" / ".join(repr(l_) for l_ in labs_[:3]) or "(沒有科目字)", item)) if hdr_ok else ("① ② " + ("原文找不到同序列的一列" if not cand else "數據列上方最近的期間表頭不是 %s" % "/".join(pers)))
            res += [dict(x, _V="SUBFAIL", _N=why) for x in xs]
            continue''')

# 2c) 基本資料:目標價 / 報告日股價 / 上漲空間要在自己的標籤旁 · 評等在前兩頁(v3 只查「原文有這個數」→ 目標價和股價對調也會過)
rep('''def verify_basic(rows, pdfdir):''', '''_LABRX = re.compile(r"(?i)(target\\s*price|price\\s*target|(?<![a-z])tp(?![a-z])|(?<![a-z])pt(?![a-z])|目標價|目標股價)"
                    r"|(share\\s*price|shr\\s*price|(?<![a-z])price(?![a-z])|(?<![a-z])close(?![a-z])|收盤價|股價|現價)"
                    r"|(up/downside(?:\\s*to\\s*price\\s*target)?|upside(?:\\s*to\\s*(?:price\\s*)?target)?|潛在漲幅|上漲空間|隱含漲幅|漲幅)")   # Up/downside to price target (%) 是上漲空間
_KIND = {"TARGET_PRICE": 1, "CURRENT_PRICE_REPORT": 2, "UPSIDE_PCT": 3}


def _numv(t):
    try:
        return float(t.replace(",", ""))
    except ValueError:
        return None


def near_label(pdf, v, field, pages=(1, 2)):
    \"\"\"v0100 數值要在自己的標籤旁:同一列值左邊最近的標籤是這一種 · 同一列左邊沒有標籤 → 上下兩列內(30 pt · 標籤 x 與值相距 < 160)最近的標籤是這一種。
    標籤三種:目標價(Target price / Price target / TP / PT / 目標價)· 股價(Share price / Price / Close / 收盤價)· 上漲空間(Upside / 潛在漲幅)。回 (是否, 說明)。\"\"\"
    fv = _numv(re.sub(r"[^\\d.,]", "", str(v)).strip(".,"))
    if fv is None:
        return False, "不是數字"
    want, seen = _KIND[field], []
    for pg in pages:
        L = page_lines(pdf, pg)
        info = []
        for y, tk in L:
            s_, xs = "", []
            for a, b, t in sorted(tk):
                xs.append((len(s_), a, b))
                s_ += t + " "
            def xat(off, xs=xs):
                return next((a for o, a, b in reversed(xs) if o <= off), xs[0][1] if xs else 0)
            labs = [(m.start(), m.end(), 1 if m.group(1) else (2 if m.group(2) else 3), xat(m.start())) for m in _LABRX.finditer(s_)]
            info.append((y, s_, labs, xat))
        for i, (y, s_, labs, xat) in enumerate(info):
            for m in re.finditer(r"\\d[\\d,]*(?:\\.\\d+)?", s_):
                if _numv(m.group()) != fv:
                    continue
                vx = xat(m.start())
                bef = [l_ for l_ in labs if l_[1] <= m.start()]
                if bef:
                    kind = max(bef, key=lambda l_: l_[1])[2]
                else:
                    near = [(abs(info[j][0] - y), abs(l_[3] - vx), l_[2]) for j in range(max(0, i - 2), min(len(info), i + 3)) if j != i and abs(info[j][0] - y) < 30
                            for l_ in info[j][2] if abs(l_[3] - vx) < 160]
                    kind = min(near)[2] if near else 0
                seen.append(kind)
                if kind == want:
                    return True, "第 %d 頁 · 標籤旁(%s)" % (pg, s_[max(0, m.start() - 40):m.end()].strip()[-60:])
    names = {0: "沒有標籤", 1: "目標價標籤", 2: "股價標籤", 3: "上漲空間標籤"}
    return False, ("前兩頁沒有這個數" if not seen else "前兩頁有這個數 · 但旁邊是%s" % "、".join(sorted({names[k] for k in seen})))


def verify_basic(rows, pdfdir):''')
rep('''        for k in ("YFINANCE_TICKER", "ENGLISH_NAME", "RATING"):
            v = nfk(x.get(k, "")).strip()
            if v:
                put(k, squash(v) in squash(t1) or squash(v) in squash(ta), "原文")''', '''        for k in ("YFINANCE_TICKER", "ENGLISH_NAME"):
            v = nfk(x.get(k, "")).strip()
            if v:
                put(k, squash(v) in squash(t1) or squash(v) in squash(ta), "原文")
        v = nfk(x.get("RATING", "")).strip()
        if v:                                                    # v0100 評等在前兩頁(後面的評等定義頁每種評等都有)
            put("RATING", squash(v) in squash(all_text(pdf, (1, 2))), "前兩頁原文")''')
rep('''        for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
            v = x.get(k, "")
            if v:
                put(k, num_in(v, ta), "原文")''', '''        for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
            v = x.get(k, "")
            if v:                                                # v0100 要在自己的標籤旁(目標價 / 股價對調會被抓到)
                okl, why = near_label(pdf, v, k)
                put(k, okl, why)''')
rep('''            else:
                put("UPSIDE_PCT", num_in(up, ta) or num_in(up.lstrip("+"), ta), "原文")''', '''            else:
                okl, why = near_label(pdf, up.lstrip("+"), "UPSIDE_PCT")
                put("UPSIDE_PCT", okl, why)''')

# 2d) 一標題四重點:組句裡的數字對到自己的位置(v3 只查「原文有這個數」)
rep('''def verify_point(v, text, rsq):
    \"\"\"一個重點 → 逐段檢查:原文句(覆蓋 ≥85% · 數字在原文)· 摘要器組句(評價句 / EPS 序列:輸入數字在原文 · 「計算」的值重算對得上)。回 (PASS/FAIL, 說明)。\"\"\"
    v = nfk(v)''', '''_PREV = re.compile(r"(?i)target|(?<![a-z])tp(?![a-z])|(?<![a-z])pt(?![a-z])|目標價|from|prior|previous|原|前次|上調|調升|下修|調降|raise|lift|cut|lower")
_EPSL = re.compile(r"(?i)eps|每股盈餘|每股純益|稅後eps")


def _line_with(pdf, val, rx, pages=(1, 2, 3)):
    \"\"\"v0100 這個數在前幾頁某一列 · 而且那一列有 rx 的字(原目標價要在「目標價 / from / 原 / 前次 …」那一列)。\"\"\"
    fv = _numv(str(val).strip(".,"))
    for pg in pages:
        for y, tk in page_lines(pdf, pg):
            s_ = " ".join(t for _, _, t in sorted(tk))
            if rx.search(s_) and any(_numv(m) == fv for m in re.findall(r"\\d[\\d,]*(?:\\.\\d+)?", s_)):
                return True
    return False


def _eps_ok(val, year, pdf, fin):
    \"\"\"v0100 EPS 序列:年度數據冊同檔 EPS 科目、同年度期間有這個值(年度數據每筆另外驗過)· 冊裡沒有 → 原文有 EPS 字樣的那一列有這個數。\"\"\"
    fv = _numv(str(val))
    yy = str(year)
    eps_rows = [r for r in fin or () if _EPSL.search(str(r.get("ITEM", "")))]
    for r in eps_rows:
        if _EPSL.search(str(r.get("ITEM", ""))) and (yy in str(r.get("PERIOD", "")) or re.search(r"(?<!\\d)%s(?!\\d)" % yy[2:], str(r.get("PERIOD", "")))) and _numv(re.sub(r"[^\\d.,-]", "", str(r.get("VALUE", "")))) == fv:
            return True, "年度數據 %s %s" % (r.get("ITEM"), r.get("PERIOD"))
    if eps_rows:                                                 # 年度數據有 EPS → 一定要同年度那一格(別年的 EPS 也在原文 EPS 那一列 · 不能用來過)
        return False, ""
    return (True, "原文 EPS 列") if _line_with(pdf, val, _EPSL, pages=tuple(range(1, 9))) else (False, "")


def verify_point(v, text, rsq, pdf=None, basic=None, fin=None):
    \"\"\"一個重點 → 逐段檢查:原文句(覆蓋 ≥85% · 數字在原文)· 摘要器組句(評價句 / EPS 序列:輸入數字在原文 · 「計算」的值重算對得上)。回 (PASS/FAIL, 說明)。
    v0100(pdf 有給):目標價 = 基本資料目標價 · 原目標價在「目標價 / from / 原 / 前次」那一列 · 倍數原文印成「16x / 16 倍」· 報告上漲空間在上漲空間標籤旁 · EPS = 年度數據同年度 EPS(或原文 EPS 那一列)。\"\"\"
    v = nfk(v)''')
rep('''        m = re.match(r"^(\\d{4}) 年 .*?EPS.*?\\s([\\-\\d.,]+)(?: TWD)?(?:\\s*[（(]計算 YoY ([\\-\\d.]+)%[）)])?$", sg)
        if m:
            eps.append((int(m.group(1)), float(m.group(2).replace(",", "")), float(m.group(3)) if m.group(3) else None))
            if not num_in(m.group(2), text):
                bad.append("EPS %s 不在原文" % m.group(2))
            continue''', '''        m = re.match(r"^(\\d{4}) 年 .*?EPS.*?\\s([\\-\\d.,]+)(?: TWD)?(?:\\s*[（(]計算 YoY ([\\-\\d.]+)%[）)])?$", sg)
        if m:
            eps.append((int(m.group(1)), float(m.group(2).replace(",", "")), float(m.group(3)) if m.group(3) else None))
            if not num_in(m.group(2), text):
                bad.append("EPS %s 不在原文" % m.group(2))
            elif pdf is not None:
                ok_e, why_e = _eps_ok(m.group(2), m.group(1), pdf, fin)
                if not ok_e:
                    bad.append("%s 年 EPS %s 不是年度數據 / 原文 EPS 那一列的值" % (m.group(1), m.group(2)))
            continue''')
rep('''            for k_, val in re.findall(r"(目標價|原目標價|倍)\\s*([\\d.,]+)", sg) + [("倍", x) for x in re.findall(r"([\\d.]+)\\s*倍", sg)]:
                if not num_in(val, text):
                    bad.append("%s %s 不在原文" % (k_, val))''', '''            for k_, val in re.findall(r"(目標價|原目標價|倍)\\s*([\\d.,]+)", sg) + [("倍", x) for x in re.findall(r"([\\d.]+)\\s*倍", sg)]:
                if not num_in(val, text):
                    bad.append("%s %s 不在原文" % (k_, val))
                elif pdf is None:
                    continue
                elif k_ == "目標價" and basic and basic.get("TARGET_PRICE") and _numv(val.strip(".,")) != _numv(re.sub(r"[^\\d.,]", "", basic["TARGET_PRICE"]).strip(".,")):
                    bad.append("目標價 %s 與基本資料目標價 %s 不同" % (val, basic["TARGET_PRICE"]))
                elif k_ == "原目標價" and not _line_with(pdf, val, _PREV):
                    bad.append("原目標價 %s 不在原文「目標價 / from / 原 / 前次」那一列" % val)
                elif k_ == "倍" and not re.search(r"(?<![\\d.])%s(?:\\.0+)?\\s*(?:x|X|倍|times)" % re.escape(val.strip(".,").rstrip("0").rstrip(".") if "." in val else val.strip(".,")), nfk(text)):
                    bad.append("倍數 %s 原文沒有印成「%sx / %s 倍」" % (val, val, val))''')
rep('''                elif not num_in(mu.group(1), text):
                    bad.append("上漲空間 %s%% 不在原文" % mu.group(1))''', '''                elif not num_in(mu.group(1), text):
                    bad.append("上漲空間 %s%% 不在原文" % mu.group(1))
                elif pdf is not None and not near_label(pdf, mu.group(1), "UPSIDE_PCT")[0]:
                    bad.append("報告上漲空間 %s%% 不在原文上漲空間標籤旁" % mu.group(1))''')
rep('''def verify_summary(rows, pdfdir):
    out = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]''', '''def verify_summary(rows, pdfdir, basic=None, fin=None):
    out = []
    bmap = {b["FILENAME"]: b for b in (basic or [])}
    fmap = defaultdict(list)
    for r in fin or ():
        fmap[r["FILENAME"]].append(r)
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]''')
rep('''                r_, n_ = verify_point(v, text, rsq)''', '''                r_, n_ = verify_point(v, text, rsq, pdf, bmap.get(x["FILENAME"]), fmap.get(x["FILENAME"]))''')
rep('''    vs = verify_summary(summ, pdfdir)
    return vb, vf, vs''', '''    vs = verify_summary(summ, pdfdir, basic, fin)                     # v0100 組句數字對基本資料 / 年度數據(兩本冊各自另外驗過)
    return vb, vf, vs''')

# 2e) 標題 / 重點太短不算
rep('''            chk["TITLE"] = ("PASS" if sc >= 0.8 and not RATING_ONLY.match(nfk(x["TITLE"]).strip()) else "FAIL") + " · 原文覆蓋 %.0f%%" % (100 * sc)''',
    '''            chk["TITLE"] = ("PASS" if sc >= 0.8 and len(squash(x["TITLE"])) >= 4 and not RATING_ONLY.match(nfk(x["TITLE"]).strip()) else "FAIL") + " · 原文覆蓋 %.0f%%%s" % (100 * sc, "" if len(squash(x["TITLE"])) >= 4 else " · 太短")   # v0100 一兩個字的覆蓋率沒有意義''')
rep('''                r_, n_ = verify_point(v, text, rsq, pdf, bmap.get(x["FILENAME"]), fmap.get(x["FILENAME"]))''',
    '''                r_, n_ = verify_point(v, text, rsq, pdf, bmap.get(x["FILENAME"]), fmap.get(x["FILENAME"]))
                if len(squash(v)) < 8:                           # v0100 太短的重點不算
                    r_, n_ = "FAIL", "太短(%d 字)" % len(squash(v))''')

# 3) 冊內序號 _I(分片也一樣:每片讀整本冊 · 先編號再挑檔)
rep('''    fin = [r for r in json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8")) if pick(r)]''',
    '''    fin = [dict(r, _I=i) for i, r in enumerate(json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))) if pick(r)]   # v0100 冊內序號''')

# 2f) 一致性:完全重複的列(同列同期間同值兩筆)= DUPROW(年度數據冊同一格只能一筆 · DUPKEY 只抓「不同值」)
rep('''        if len(vs) > 1:
            r = dict(r, _V="DUPKEY", _N="同一列同科目同期間有 %d 個不同的值:%s" % (len(vs), " / ".join(sorted(vs))[:80]))
        out.append(r)
    return out''', '''        if len(vs) > 1:
            r = dict(r, _V="DUPKEY", _N="同一列同科目同期間有 %d 個不同的值:%s" % (len(vs), " / ".join(sorted(vs))[:80]))
        elif cnt[k_(r)] > 1:
            r = dict(r, _V="DUPROW", _N="同一列同科目同期間同值出現 %d 次(年度數據冊同一格只能一筆 · 多半是季度段同期間字的那一格)" % cnt[k_(r)])
        out.append(r)
    return out''')
rep('''    for r in vf:
        g[k_(r)].add(squash(r.get("VALUE", "")))''', '''    cnt = Counter()
    for r in vf:
        g[k_(r)].add(squash(r.get("VALUE", "")))
        cnt[k_(r)] += 1''')
rep('''BADV = ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM", "SUBFAIL", "TRANSFAIL", "DUPKEY", "QTRCOL")   # v0100 + 季度欄''', '''BADV = ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM", "SUBFAIL", "TRANSFAIL", "DUPKEY", "QTRCOL", "DUPROW")   # v0100 + 季度欄 · 完全重複''')

# 2g) 摘要第一行寫實際版本
rep('''    L = ["[驗證摘要] VRN-2 獨立驗證 v2 · 平行 %d 路" % w]''', '''    L = ["[驗證摘要] %s · 平行 %d 路" % (VERSION, w)]''')

# 4) 指紋 · 寫回 U/I · main 帶 --ui · 自測 · 指令列
rep('''def main(od, pdfdir, rep):
    vb, vf, vs, w = run_parallel(od, pdfdir)''', '''FP_KEYS = ("FILENAME", "PAGE", "TABLE", "ITEM", "PERIOD", "SUBCOL", "VALUE")


def book_fp(rows):
    """年度數據冊指紋(與 VRN-2 SystemManager v0237 U/I 同一算法 · 各自實作 · 不 import):逐筆 7 欄串接 → SHA-256 前 16 碼。"""
    h = hashlib.sha256()
    for r in rows:
        h.update(("\\x1f".join(str(r.get(k, "")) for k in FP_KEYS) + "\\x1e").encode("utf-8"))
    return h.hexdigest()[:16]


def ui_payload(vb, vf, vs, fp, n, w, ok, ts):
    """寫回 U/I 的判決(每筆年度數據依冊內序號 · 基本資料 / 一標題四重點依檔)。"""
    fin = [None] * n
    for r in vf:
        i = r.get("_I")
        if isinstance(i, int) and 0 <= i < n:
            fin[i] = [r["_V"], r["_N"][:120]]
    return {"ver": VERSION, "ts": ts, "fp": fp, "n": n, "w": w, "ok": ok,
            "counts": {"basic": dict(Counter(v.split(" ·")[0] for r in vb for v in r["checks"].values())),
                       "summary": dict(Counter(v.split(" ·")[0] for r in vs for v in r["checks"].values())),
                       "fin": dict(Counter(r["_V"] for r in vf))},
            "basic": {r["FILENAME"]: r["checks"] for r in vb}, "summary": {r["FILENAME"]: r["checks"] for r in vs}, "fin": fin}


_IV_RE = re.compile(r'<script id="vrn2-iv">window\\.VRN2_IV=.*?;</script>', re.S)


def inject_ui(html_path, payload):
    """把判決寫進 U/I 的 <script id="vrn2-iv"> 佔位(先寫暫存檔再換 · 「<」一律跳脫 → 值裡的 </script> 不會截斷頁面)。回 (成功, 說明)。"""
    p = Path(html_path)
    if not p.is_file():
        return False, "找不到 U/I %s" % p
    page = p.read_text(encoding="utf-8")
    if not _IV_RE.search(page):
        return False, "U/I 沒有驗證佔位(不是 v0237 以後的管理器產生的頁)"
    js = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).replace("<", "\\\\u003c")
    page = _IV_RE.sub(lambda m: '<script id="vrn2-iv">window.VRN2_IV=%s;</script>' % js, page, count=1)
    tmp = p.with_name(p.name + ".iv.tmp")
    tmp.write_text(page, encoding="utf-8")
    tmp.replace(p)
    return True, "已寫回 U/I %s(指紋 %s · %d 筆)" % (p, payload["fp"], payload["n"])


def main(od, pdfdir, rep, ui=None):
    import datetime
    vb, vf, vs, w = run_parallel(od, pdfdir)''')
rep('''    Path(rep).write_text(json.dumps({"basic": vb, "summary": vs, "summary_counts": dict(sc_), "fin_counts": dict(fc), "fin_per_file": {k: dict(v) for k, v in per_file.items()},
                                     "fin_bad": [r for r in vf if r["_V"] in BADV], "fin_ocr": [r for r in vf if r["_V"] == "OCR"]}, ensure_ascii=False, indent=1), encoding="utf-8")''',
    '''    book = json.loads((Path(od) / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
    fp = book_fp(book)
    rc = 0 if not any(v.startswith("FAIL") for r in vb + vs for v in r["checks"].values()) and not any(fc.get(k) for k in BADV) else 1
    Path(rep).write_text(json.dumps({"version": VERSION, "fp": fp, "n": len(book), "basic": vb, "summary": vs, "summary_counts": dict(sc_), "fin_counts": dict(fc), "fin_per_file": {k: dict(v) for k, v in per_file.items()},
                                     "fin_bad": [r for r in vf if r["_V"] in BADV], "fin_ocr": [r for r in vf if r["_V"] == "OCR"],
                                     "fin_rows": sorted([r.get("_I"), r["_V"], r["_N"]] for r in vf if isinstance(r.get("_I"), int))}, ensure_ascii=False, indent=1), encoding="utf-8")''')
rep('''    print("[驗證] 摘要 %s.digest.txt(貼給 AI 用)· 平行 %d 路" % (rep, w))
    return 0 if not any(v.startswith("FAIL") for r in vb + vs for v in r["checks"].values()) and not any(fc.get(k) for k in BADV) else 1''',
    '''    print("[驗證] 摘要 %s.digest.txt(貼給 AI 用)· 平行 %d 路 · 冊指紋 %s · 每筆判決 %d / %d" % (rep, w, fp, sum(1 for r in vf if isinstance(r.get("_I"), int)), len(book)))
    if ui:
        ok_, msg = inject_ui(ui, ui_payload(vb, vf, vs, fp, len(book), w, rc == 0, datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
        print("[驗證] U/I %s · %s" % ("寫回" if ok_ else "未寫回", msg))
    return rc


def selftest():
    """不需 PDF:指紋 · 寫回 U/I(跳脫 · 重寫)· DUPKEY · 兩個字詞的值 · 先定列再找值(鄰列互為最近)· 科目字相同。"""
    import tempfile
    p = f = 0

    def chk(name, cond):
        nonlocal p, f
        p, f = (p + 1, f) if cond else (p, f + 1)
        print("  [%s] %s" % ("OK" if cond else "FAIL", name))
    rows = [{"FILENAME": "a.pdf", "PAGE": 1, "TABLE": "T", "ITEM": "Revenue", "PERIOD": "2026E", "VALUE": "100"},
            {"FILENAME": "a.pdf", "PAGE": 1, "TABLE": "T", "ITEM": "Revenue", "PERIOD": "2027E", "VALUE": "</script>"}]
    fp1, fp2 = book_fp(rows), book_fp([rows[1], rows[0]])
    chk("指紋:16 碼 · 次序不同 → 指紋不同 · 同內容 → 相同", len(fp1) == 16 and fp1 != fp2 and fp1 == book_fp([dict(r) for r in rows]))
    chk("指紋算法固定(與管理器 v0237 同一組欄位與分隔字元)", FP_KEYS == ("FILENAME", "PAGE", "TABLE", "ITEM", "PERIOD", "SUBCOL", "VALUE") and
        book_fp([{"FILENAME": "x", "VALUE": "1"}]) == hashlib.sha256("x\\x1f\\x1f\\x1f\\x1f\\x1f\\x1f1\\x1e".encode()).hexdigest()[:16])
    td = Path(tempfile.mkdtemp(prefix="vrn2iv-"))
    hp = td / "VRN2_UI_latest.html"
    hp.write_text('<html><body><h2>x</h2><script id="vrn2-iv">window.VRN2_IV=null;</script><p>tail</p></body></html>', encoding="utf-8")
    vf = [dict(rows[0], _I=0, _V="ALIGNED", _N="dx 1"), dict(rows[1], _I=1, _V="BADVALUE", _N="</script><b>")]
    pl = ui_payload([], vf, [], fp1, 2, 1, False, "t")
    ok1, _ = inject_ui(hp, pl)
    t1 = hp.read_text(encoding="utf-8")
    seg = t1.split('<script id="vrn2-iv">window.VRN2_IV=', 1)[1].split(";</script>", 1)[0]
    chk("寫回 U/I:佔位換成判決 · 值裡的 </script> 已跳脫 · 頁尾還在", ok1 and "</script><b>" not in seg and t1.endswith("<p>tail</p></body></html>") and json.loads(seg)["fin"][1][0] == "BADVALUE")
    ok2, _ = inject_ui(hp, dict(pl, ts="t2"))
    t2 = hp.read_text(encoding="utf-8")
    chk("再寫一次 → 取代上一次(只留一份)", ok2 and t2.count('id="vrn2-iv"') == 1 and '"ts":"t2"' in t2)
    hp2 = td / "old.html"
    hp2.write_text("<html><body>舊版頁</body></html>", encoding="utf-8")
    chk("沒有佔位的舊頁 → 不寫(回說明)", inject_ui(hp2, pl)[0] is False and hp2.read_text(encoding="utf-8") == "<html><body>舊版頁</body></html>")
    d = dupkey([dict(rows[0], _V="ALIGNED", _N=""), dict(rows[0], VALUE="101", _V="ALIGNED", _N="")])
    chk("DUPKEY:同列同科目同期間兩個值 → 兩筆都標", [r["_V"] for r in d] == ["DUPKEY", "DUPKEY"])
    d2 = dupkey([dict(rows[0], _V="ALIGNED", _N=""), dict(rows[0], _V="ALIGNED", _N=""), dict(rows[1], _V="ALIGNED", _N="")])
    chk("DUPROW:同列同科目同期間同值兩筆 → 兩筆都標 · 別的期間不動", [r["_V"] for r in d2] == ["DUPROW", "DUPROW", "ALIGNED"])
    chk("兩個字詞的值:Net + cash(字距 < 4)= Net cash · 字距太大不算", len(_hits([(345, 358, "Net"), (360, 376, "cash")], "netcash")) == 1 and not _hits([(345, 358, "Net"), (380, 396, "cash")], "netcash"))
    L = [(122.0, [(232, 280, "每股盈餘成長率"), (358, 370, "76.9")]), (101.7, [(232, 260, "股價淨值比"), (280, 288, "(x)"), (358, 370, "10.4")]),
         (95.3, [(358, 370, "38.0"), (401, 413, "25.1")]), (90.7, [(232, 271, "EV/EBITDA"), (275, 288, "(x)")]),
         (84.7, [(345, 358, "Net"), (360, 376, "cash"), (406, 417, "4.5")]), (79.7, [(232, 275, "淨負債比率"), (280, 292, "(%)")]), (74.6, [])]
    def rh(k, item, v):
        lb = _lab_block(L[k][1], squash(item)[:14])
        return _row_hits(L, k, lb, squash(item), v) if lb and _lab_ok(lb[2], squash(item)) else None
    a, b_ = rh(3, "EV/EBITDA (x)", "38.0"), rh(5, "淨負債比率 (%)", "4.5")
    chk("先定列再找值:EV/EBITDA 的值在上一列(+4.6)· 淨負債比率的值在上一列(+5.0)", bool(a and a[0]) and round(a[1], 1) == 4.6 and bool(b_ and b_[0]) and round(b_[1], 1) == 5.0)
    chk("別列的值不算:淨負債比率拿 EV/EBITDA 的 38.0 · EV/EBITDA 拿淨負債比率的 4.5 · 股價淨值比拿下一列 38.0 → 都找不到",
        not (rh(5, "淨負債比率 (%)", "38.0") or (None,))[0] and not (rh(3, "EV/EBITDA (x)", "4.5") or (None,))[0] and not (rh(1, "股價淨值比 (x)", "38.0") or (None,))[0])
    chk("科目字要相同(不是只含):EPS ≠ EPS growth · Revenue ≠ Total revenue · 折行 / 原文多印單位可以",
        not _lab_ok("epsgrowth", "eps") and not _lab_ok("totalrevenue", "revenue") and _lab_ok("salesgrowthof", "salesgrowthofambusiness(%)") == "折行" and _lab_ok("revenue(nt$m)", "revenue") == "單位" and _lab_ok("revenue", "revenue") == "同")
    hq = [(175, 200, "Sep-27F"), (416, 440, "Dec-27F"), (450, 474, "Dec-26F"), (487, 511, "Dec-27F"), (524, 548, "Dec-28F")]
    a1 = _align([(700.0, hq)], 690.0, "Dec-27F", [(500.0, 495, 505, "(40)")])
    chk("季度 / 年度表頭同一個期間印兩次 → 只對年度那個 · 值在季度那欄 → 不算 · 只有季度欄 → 標季度", _qtr_x(hq) == {175, 416} and bool(a1) and a1[2] == 499.0 and
        _align([(700.0, hq)], 690.0, "Dec-27F", [(430.0, 425, 435, "-")]) is None and (_align([(700.0, hq[:2])], 690.0, "Dec-27F", [(428.0, 425, 431, "1")]) or [0] * 7)[6] is True)
    chk("值離別的期間表頭更近 → 不是這一欄(期間錯一欄)", _align([(700.0, [(400, 424, "2025A"), (440, 464, "2026E")])], 690.0, "2025A", [(445.0, 440, 450, "9")]) is None)
    W = [(500.0, [(50, 110, "Gross"), (113, 140, "profit"), (200, 220, "1,000")]), (490.0, [(50, 110, "Gross"), (113, 140, "profit"), (143, 170, "margin"), (200, 220, "33.0")]),
         (480.0, [(50, 90, "Sales"), (93, 120, "growth"), (123, 130, "of"), (200, 220, "5.0")]), (470.0, [(50, 80, "AM"), (83, 130, "business"), (133, 150, "(%)")])]
    chk("折行要真的折行:Gross profit 那列不當 Gross profit margin · Sales growth of + 下一列 AM business (%) 才算",
        not _wrap_ok(W, 0, _lab_block(W[0][1], "grossprofit"), "grossprofitmargin") and _wrap_ok(W, 2, _lab_block(W[2][1], "salesgrowthof"), "salesgrowthofambusiness(%)"))
    chk("子欄科目:Net profit 的 Net 不當值 · 科目就叫 NM 也認得 · 單列只認相同 / 單位(Gross profit ≠ Gross profit margin)",
        _sub_lab([(1.0, [(10, 20, "Net"), (22, 40, "profit"), (60, 70, "1")])], 0, 60, "netprofit")[0] and _sub_lab([(1.0, [(10, 20, "NM"), (60, 70, "1")])], 0, 60, "nm")[0]
        and not _sub_lab([(1.0, [(10, 30, "Gross"), (32, 50, "profit"), (60, 70, "1")])], 0, 60, "grossprofitmargin")[0])
    sbs = [(43, 60, "Income"), (67, 80, "tax"), (171, 190, "1,362"), (208, 225, "1,137"), (319, 340, "Change"), (344, 350, "of"), (441, 460, "1,748"), (491, 497, "0")]
    chk("並排表:科目列右邊另一張表(Change of …)的值不算這一列 · Net cash 不當成別的科目", not _hits(sbs, "0", 82, _seg_end(sbs, 80)) and len(_hits(sbs, "1,137", 82, _seg_end(sbs, 80))) == 1
        and _seg_end([(345, 358, "Net"), (360, 376, "cash"), (406, 417, "4.5"), (429, 441, "Net"), (444, 460, "cash")], 292) == 1e9)
    print("[計] %s 自測 %d/%d · %s" % (VERSION, p, p + f, "PASS" if f == 0 else "FAIL"))
    return 0 if f == 0 else 1''')
rep('''    sys.exit(main(*sys.argv[1:4]))''', '''    if sys.argv[1:2] == ["--selftest"]:
        sys.exit(selftest())
    _a = sys.argv[1:]
    _ui = _a[_a.index("--ui") + 1] if "--ui" in _a and _a.index("--ui") + 1 < len(_a) else None
    _pos = [x for i, x in enumerate(_a) if x != "--ui" and not (i > 0 and _a[i - 1] == "--ui")]
    sys.exit(main(*_pos[:3], ui=_ui))''')
compile(src, out_p.name, "exec")
out_p.write_text(src, encoding="utf-8", newline="")
print("[計] %s · %d 行" % (out_p, src.count("\n")))
