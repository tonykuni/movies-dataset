"""v0128 一鍵 md 重算:程式碼區塊 = Run-VRN2-v0128.ps1 · 啟動器雜湊 / 程式碼雜湊 / 一行(-EncodedCommand)/ 一行的原始碼 全部跟著換。"""
import base64, hashlib, re, sys
S = "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"
sha = lambda t: hashlib.sha256(t.encode("utf-8")).hexdigest()
md_p, boot_p, one_p = S + "/release128/VRN2_OneClick_v0128.md", S + "/boot127/boot128.ps1", S + "/boot127/oneline128.txt"
md = open(md_p, encoding="utf-8").read()
ps = open(S + "/Run-VRN2-v0128.ps1", encoding="utf-8").read().rstrip("\n")
FENCE = r"(?s)```powershell\n(.*?)\n```"
old_code = re.search(FENCE, md).group(1)
old_cs, new_cs = sha(old_code), sha(ps)
WANT = r"\$Want   = '([0-9a-f]{64})'"
old_l, new_l = re.search(WANT, old_code).group(1), re.search(WANT, ps).group(1)
boot = open(boot_p, encoding="utf-8").read()
assert boot.count(old_cs) == 1
boot2 = boot.replace(old_cs, new_cs)
one_old = open(one_p).read().strip()
one_new = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot2.encode("utf-16-le")).decode("ascii")
assert md.count(old_code) == 1 and md.count(one_old) == 1 and md.count(boot.rstrip("\n")) == 1
md = md.replace(old_code, ps).replace(one_old, one_new).replace(boot.rstrip("\n"), boot2.rstrip("\n"))
md = md.replace(old_cs, new_cs).replace(old_cs[:12], new_cs[:12]).replace(old_l, new_l).replace(old_l[:12], new_l[:12])
assert re.search(FENCE, md).group(1) == ps and md.count("```powershell\n") == 1
assert old_cs[:12] not in md and old_l[:12] not in md
assert base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot2
assert re.search(r"(?s)```text\n(.*?)\n```", md).group(1) == boot2.rstrip("\n")
open(md_p, "w", encoding="utf-8", newline="\n").write(md)
open(boot_p, "w", encoding="utf-8", newline="\n").write(boot2)
for p_ in (one_p, S + "/boot127/oneline.txt"):
    open(p_, "w").write(one_new + "\n")
print("launcher %s → %s · code %s → %s · one-liner %d 字" % (old_l[:12], new_l[:12], old_cs[:12], new_cs[:12], len(one_new)))
