"""基本資料:原樣 + 反向(目標價 ↔ 股價對調 · 目標價換成首頁別的數 · 評等換成定義頁才有的評等)。用法:python cmp_basic.py <output> <pdfdir>"""
import collections, copy, json, re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs as V
od, pd = sys.argv[1], sys.argv[2]
b = json.loads(Path(od, "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
r = V.verify_basic(b, pd)
print("原樣", dict(collections.Counter(v.split(" ·")[0] for x in r for v in x["checks"].values())))
for x in r:
    for k, v in x["checks"].items():
        if not v.startswith("PASS") or k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT", "UPSIDE_PCT"):
            print("  ", x["FILENAME"][:26], k, v[:120])
m = []
for x in b:
    if x.get("TARGET_PRICE") and x.get("CURRENT_PRICE_REPORT"):
        y = copy.deepcopy(x)
        y["TARGET_PRICE"], y["CURRENT_PRICE_REPORT"], y["UPSIDE_PCT"] = x["CURRENT_PRICE_REPORT"], x["TARGET_PRICE"], ""
        m.append(y)
rm = V.verify_basic(m, pd)
esc = [x["FILENAME"][:20] for x in rm if x["checks"].get("TARGET_PRICE", "").startswith("PASS") or x["checks"].get("CURRENT_PRICE_REPORT", "").startswith("PASS")]
print("反向 目標價 ↔ 股價對調 %d 份 · 仍過 %d %s" % (len(rm), len(esc), esc))
m2 = []
for x in b:
    if not x.get("TARGET_PRICE"):
        continue
    L = V.page_lines(Path(pd) / x["FILENAME"], 1)
    nums = [n for _, tk in L for _, _, t in tk for n in re.findall(r"\d[\d,]*\.\d+|\d{2,}[\d,]*", t)]
    fv = V._numv(re.sub(r"[^\d.,]", "", x["TARGET_PRICE"]))
    cp = V._numv(re.sub(r"[^\d.,]", "", x.get("CURRENT_PRICE_REPORT") or "x") or "x")
    alt = next((n for n in nums if V._numv(n) not in (None, fv, cp) and V._numv(n) > 5), None)
    if alt:
        m2.append(dict(copy.deepcopy(x), TARGET_PRICE=alt, UPSIDE_PCT=""))
rm2 = V.verify_basic(m2, pd)
esc2 = [(x["FILENAME"][:20], y["TARGET_PRICE"]) for x, y in zip(rm2, m2) if x["checks"].get("TARGET_PRICE", "").startswith("PASS")]
print("反向 目標價換成首頁別的數 %d 份 · 仍過 %d %s" % (len(rm2), len(esc2), esc2))
m3 = []
for x in b:
    rt = x.get("RATING") or ""
    ta = V.squash(V.all_text(Path(pd) / x["FILENAME"]))
    t12 = V.squash(V.all_text(Path(pd) / x["FILENAME"], (1, 2)))
    alt = next((w for w in ("Neutral", "Underweight", "Sell", "Underperform", "Hold", "中立", "減碼", "賣出") if V.squash(w) in ta and V.squash(w) not in t12 and V.squash(w) != V.squash(rt)), None)
    if alt:
        m3.append(dict(copy.deepcopy(x), RATING=alt))
rm3 = V.verify_basic(m3, pd)
esc3 = [(x["FILENAME"][:20], y["RATING"]) for x, y in zip(rm3, m3) if x["checks"].get("RATING", "").startswith("PASS")]
print("反向 評等換成定義頁才有的評等 %d 份 · 仍過 %d %s" % (len(rm3), len(esc3), esc3))
