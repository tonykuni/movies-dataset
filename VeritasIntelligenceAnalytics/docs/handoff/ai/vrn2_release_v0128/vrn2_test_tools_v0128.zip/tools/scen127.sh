#!/bin/bash
# 情境:先跑 v0126(上船)→ 遠端被別台機器推新提交 → 本機有別的系統提交(未推)→ 遠端放 v0127 發行分支 · $1 = 樹
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
T="$1"; R=$S/release127
cd /tmp && $S/tools/mktree.sh $T $S/new/ActivateVRN-2_v0126.py 2>&1 | grep -v -e negotiat -e acknowledg
PY=$S/venv_vrn2/bin/python $S/tools/runl.sh $T > $T.pre_v0126.log 2>&1; sed -i 's/\x1b\[[0-9;]*m//g' $T.pre_v0126.log
O=$T.other; rm -rf $O; git clone -q -b main $T/remote.git $O >/dev/null 2>&1; echo "remote newer" > $O/README_other.md
git -C $O -c user.email=o@o -c user.name=o add -A; git -C $O -c user.email=o@o -c user.name=o commit -qm "remote newer (另一台機器)"; git -C $O push -q origin main >/dev/null 2>&1
echo "other system" > $T/VIA/VCGC_local_only.md; git -C $T/VIA add VCGC_local_only.md; git -C $T/VIA -c user.email=t@t -c user.name=t commit -qm "VCGC 本機提交(未推送)"
B=$T.br; rm -rf $B; mkdir -p $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0127; cp $R/ActivateVRN-2_v0127.zip $R/VRN2_Release_v0127.json $R/vrn2_test_tools_v0127.zip $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0127/
cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1
echo "scenario ok · $(grep -E '→ GREEN ⑨' $T.pre_v0126.log | cut -c1-60)"
