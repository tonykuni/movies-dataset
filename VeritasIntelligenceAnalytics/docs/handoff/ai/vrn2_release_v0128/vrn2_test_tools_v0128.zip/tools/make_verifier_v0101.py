"""VRN2_IndependentVerifier v0100 → v0101(整檔複本 + 補丁 · v0100 原檔不動)。
用法:python make_verifier_v0101.py <VRN2_IndependentVerifier_v0100.py> <輸出 v0101>
v0101:HDRVAL(跟讀法無關的一致性):年度數據的值是期間字(Dec-23A · FY24A · 2024E · 12/25 · Jan-26 …)· 科目整個是期間字 · 一整列的值都等於期間的年份 → 這一列是表頭,不是數據。
  實例(v0237 輸出 · v0100 判 ALIGNED → 漏抓):凱基 2637 現金流量表表頭「NT$百萬 Dec-23A …」5 筆 · JP 2330「Balance Sheet & Cash Flow Statement FY24A …」4 筆 · GS 6415「Jul-25 Oct-25」Jan-26 / Apr-26 2 筆。"""
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:70])
    s = s.replace(a, b)


rep('"""VRN2_IndependentVerifier_v0100 — VRN-2 輸出值獨立驗證(由 tools/verify_outputs v3 升版 · 啟動器 v0127 內嵌',
    '"""VRN2_IndependentVerifier_v0101 — VRN-2 輸出值獨立驗證(v0100 + 表頭列檢查 HDRVAL · 由 tools/verify_outputs v3 升版 · 啟動器 v0128 內嵌')
rep("用法:python VRN2_IndependentVerifier_v0100.py <output 夾>", "用法:python VRN2_IndependentVerifier_v0101.py <output 夾>")
rep("      python VRN2_IndependentVerifier_v0100.py --selftest", "      python VRN2_IndependentVerifier_v0101.py --selftest")
rep("  依檔分片平行(子行程", "  v0101:HDRVAL(跟讀法無關):值是期間字(Dec-23A · FY24A · 2024E · 12/25 · Jan-26 …)· 科目整個是期間字 · 一整列的值都等於期間的年份 → 這一列是表頭不是數據(整列都標)\n"
    "        (v0100 漏抓:表頭字本來就印在期間那一欄 → 對位 ALIGNED · 凱基 2637 現金流量表表頭 · JP 2330 資產負債 / 現金流量表表頭 · GS 6415 月份列)\n  依檔分片平行(子行程")
rep('VERSION = "VRN2_IndependentVerifier_v0100"', 'VERSION = "VRN2_IndependentVerifier_v0101"')
rep('BADV = ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM", "SUBFAIL", "TRANSFAIL", "DUPKEY", "QTRCOL", "DUPROW")   # v0100 + 季度欄 · 完全重複',
    'BADV = ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM", "SUBFAIL", "TRANSFAIL", "DUPKEY", "QTRCOL", "DUPROW", "HDRVAL")   # v0100 + 季度欄 · 完全重複 · v0101 表頭列')
rep('''        out.append(r)
    return out


def run_files(od, pdfdir, files):''', '''        out.append(r)
    return out


_PERV = re.compile(r"(?i)^(?:(?:FY|CY)['’]?\\d{2,4}[AEFPCTH]?|\\d{4}(?:[AEFPH]|CT)|\\d{1,2}/\\d{2,4}[AEF]?|[A-Z][a-z]{2}-\\d{2}[AEF]?|[1-4][QH]\\d{2}[AEF]?)$")


def _perv(t):
    """期間字(Dec-23A · FY24A · 2024E · 2025CT · 12/25 · Jan-26 · 2Q26E · 1H26)· 純數字(2024)不算。"""
    return bool(_PERV.match(nfk(str(t or "")).strip()))


def _peryr(per):
    """期間的西元年(2024E → 2024 · FY24A / Dec-24A → 2024 · 12/25 → 2025)· 沒有 → ""。"""
    t = nfk(str(per or ""))
    m = re.search(r"(?:19|20)\\d{2}", t)
    if m:
        return m.group(0)
    m = re.search(r"(?<!\\d)(\\d{2})(?:[AEFPH]|CT)?$", t)
    return "20" + m.group(1) if m else ""


def hdrval(vf):
    """v0101 一致性(跟讀法無關):年度數據的一列若是表頭(值是期間字 · 科目整個是期間字 · 一整列的值都等於期間的年份)→ 整列 HDRVAL。
    表頭字本來就印在期間那一欄 → 位置檢查會判對位(v0100 漏抓 11 筆)· 所以另查值的種類。"""
    k_ = lambda r: (r["FILENAME"], r.get("TABLE"), r.get("ROW") or ("S", r.get("SECTION", "")), r.get("ITEM"), r.get("SUBCOL", ""))   # noqa: E731
    g = defaultdict(list)
    for r in vf:
        g[k_(r)].append(r)
    why = {}
    for k, rs in g.items():
        it = nfk(str(k[3] or "")).split()
        pv = [str(r.get("VALUE", "")) for r in rs if _perv(r.get("VALUE"))]
        if pv:
            why[k] = "值是期間字 %s(這一列是表頭 · 不是數據)" % " / ".join(pv[:5])
        elif it and all(_perv(t) for t in it):
            why[k] = "科目整個是期間字 %s(這一列是表頭 · 不是數據)" % k[3]
        elif len(rs) >= 2 and all(_peryr(r.get("PERIOD")) and re.sub(r"[,\\s]", "", str(r.get("VALUE", ""))) == _peryr(r.get("PERIOD")) for r in rs):
            why[k] = "一整列的值都等於期間的年份(這一列是表頭 · 不是數據)"
    return [dict(r, _V="HDRVAL", _N=why[k_(r)]) if k_(r) in why else r for r in vf]


def run_files(od, pdfdir, files):''')
rep('''    vf = dupkey(vf)
    sc_ = Counter(''', '''    vf = hdrval(dupkey(vf))                                              # v0101 表頭列(跟讀法無關)
    sc_ = Counter(''')
rep('''    """不需 PDF:指紋 · 寫回 U/I(跳脫 · 重寫)· DUPKEY · 兩個字詞的值''', '''    """不需 PDF:指紋 · 寫回 U/I(跳脫 · 重寫)· DUPKEY · v0101 HDRVAL · 兩個字詞的值''')
rep('''    chk("兩個字詞的值:Net + cash''', '''    hr = [{"FILENAME": "k.pdf", "TABLE": "P5", "ROW": 70, "ITEM": "NT$百萬", "PERIOD": p_, "VALUE": p_, "_V": "ALIGNED", "_N": ""} for p_ in ("Dec-23A", "Dec-24A", "Dec-25A")]
    hr += [{"FILENAME": "j.pdf", "TABLE": "P20", "ROW": 20, "ITEM": "Balance Sheet & Cash Flow Statement", "PERIOD": p_, "VALUE": p_, "_V": "ALIGNED", "_N": ""} for p_ in ("FY24A", "FY25E")]
    hr += [{"FILENAME": "g.pdf", "TABLE": "P2", "ROW": 39, "ITEM": "Jul-25 Oct-25", "PERIOD": p_, "VALUE": v_, "_V": "ALIGNED", "_N": ""} for p_, v_ in (("12/25", "Jan-26"), ("12/27E", "Apr-26"))]
    hr += [{"FILENAME": "y.pdf", "TABLE": "P3", "ROW": 2, "ITEM": "(NT$m)", "PERIOD": p_, "VALUE": v_, "_V": "ALIGNED", "_N": ""} for p_, v_ in (("2024A", "2024"), ("2025E", "2025"))]
    ok_rows = [{"FILENAME": "y.pdf", "TABLE": "P3", "ROW": 3, "ITEM": "Revenue", "PERIOD": p_, "VALUE": v_, "_V": "ALIGNED", "_N": ""} for p_, v_ in (("2024A", "2,024"), ("2025E", "2,310"))]
    ok_rows += [{"FILENAME": "y.pdf", "TABLE": "P3", "ROW": n_, "ITEM": it_, "PERIOD": "2025E", "VALUE": v_, "_V": "ALIGNED", "_N": ""}
                for n_, it_, v_ in ((4, "Net debt", "Net cash"), (5, "Margin chg", "0.4pp"), (6, "Interest cover", "NM"), (7, "Dividend", "-"), (8, "EPS", "(4.38)"))]
    hv_ = hdrval(hr + ok_rows)
    chk("v0101 HDRVAL:表頭列(值是期間字 7 · 科目是月份 2 · 整列等於年份 2)→ 全標 · 一般值(2,024 · Net cash · 0.4pp · NM · - · (4.38))不動 → %s" % dict(Counter(r["_V"] for r in hv_)),
        [r["_V"] for r in hv_[:len(hr)]] == ["HDRVAL"] * len(hr) and all(r["_V"] == "ALIGNED" for r in hv_[len(hr):]) and "HDRVAL" in BADV
        and _perv("2Q26E") and _perv("1H26") and _perv("2025CT") and not _perv("2024") and not _perv("4.38") and _peryr("Dec-24A") == "2024" and _peryr("12/25") == "2025")
    chk("兩個字詞的值:Net + cash''')
out.write_text(s, encoding="utf-8", newline="\n")
compile(s, out.name, "exec")
print("[計] %s · %d 位元組" % (out.name, len(s.encode())))
