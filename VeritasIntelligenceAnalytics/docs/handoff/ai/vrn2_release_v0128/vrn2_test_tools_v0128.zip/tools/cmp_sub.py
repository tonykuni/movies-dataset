"""子欄 / 轉置表反向測試:別列的值(子欄:同表同期間同子欄的下一列 / 上一列 · 轉置:同科目別的年份)→ 不能過。用法:python cmp_sub.py <output> <pdfdir>"""
import collections, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs as V
od, pd = sys.argv[1], sys.argv[2]
fin = json.loads(Path(od, "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
sub = [x for x in fin if x.get("SUBCOL")]
tr = [x for x in fin if "轉置" in x["VERIFY"]]
r0 = V.verify_subcol(sub, pd)
print("子欄原樣", dict(collections.Counter(x["_V"] for x in r0)))
items = collections.defaultdict(list)                 # (檔, 表) → 科目次序(依 ROW)
for x in sub:
    k = (x["FILENAME"], x["TABLE"])
    if (x.get("ROW"), x["ITEM"]) not in items[k]:
        items[k].append((x.get("ROW"), x["ITEM"]))
for nm, dr in (("下一列", 1), ("上一列", -1)):
    esc = tot = 0
    ex = []
    for k, its in items.items():
        its = sorted(its, key=lambda z: (z[0] or 0))
        for i, (rw, it) in enumerate(its):
            j = i + dr
            if not 0 <= j < len(its):
                continue
            src = {(x["PERIOD"], x["SUBCOL"]): x["VALUE"] for x in sub if (x["FILENAME"], x["TABLE"]) == k and x["ITEM"] == its[j][1] and x.get("ROW") == its[j][0]}
            xs = [x for x in sub if (x["FILENAME"], x["TABLE"]) == k and x["ITEM"] == it and x.get("ROW") == rw]
            m = [dict(x, VALUE=src.get((x["PERIOD"], x["SUBCOL"]), x["VALUE"])) for x in xs]
            if [x["VALUE"] for x in m] == [x["VALUE"] for x in xs]:
                continue
            tot += 1
            r = V.verify_subcol(m, pd)
            if all(x["_V"] == "SUBALIGNED" for x in r):
                esc += 1
                ex.append((k[0][:20], k[1], it, its[j][1]))
    print("子欄 反向 %s的值:%d 組 · 仍過 %d %s" % (nm, tot, esc, ex[:6]))
t0 = V.verify_trans(tr, pd)
print("轉置原樣", dict(collections.Counter(x["_V"] for x in t0)))
g = collections.defaultdict(dict)
for x in tr:
    g[(x["FILENAME"], x["TABLE"], x["ITEM"])][x["PERIOD"]] = x["VALUE"]
esc = tot = 0
for (f, t, it), d in g.items():
    ps = list(d)
    for i, p in enumerate(ps[:-1]):
        if d[ps[i + 1]] == d[p]:
            continue
        m = [dict(x, VALUE=d[ps[i + 1]]) if (x["FILENAME"], x["TABLE"], x["ITEM"], x["PERIOD"]) == (f, t, it, p) else x for x in tr if (x["FILENAME"], x["TABLE"]) == (f, t)]
        tot += 1
        r = V.verify_trans(m, pd)
        if all(x["_V"] == "TRANSALIGNED" for x in r):
            esc += 1
print("轉置 反向 下一年的值:%d 筆 · 仍過 %d" % (tot, esc))
