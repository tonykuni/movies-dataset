"""⑨ 上船 / ⑩ 封存 對照實測:載入指定版啟動器的函式,對測試樹執行(假完成判定)。用法:ship_test.py <啟動器> <樹>"""
import importlib.util, json, os, sys
from pathlib import Path
L, T = Path(sys.argv[1]), Path(sys.argv[2])
os.environ["VIA_ROOT"] = str(T / "VIA")
sp = importlib.util.spec_from_file_location("act", str(L)); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
vrn = T / "VIA" / "functional modules" / "VRN"
print("⑨", m.git_ship(vrn, T / "VIA", {"verdict": "完成", "red": 0, "yellow": 1}))
print("⑩", m.consolidate(vrn))
