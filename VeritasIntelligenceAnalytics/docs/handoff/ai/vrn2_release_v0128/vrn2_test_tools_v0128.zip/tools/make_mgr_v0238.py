"""組 VRN_SystemManager_v0238.py = 檔頭說明 + 加速器橋(_bridge_block.txt)+ mgr_v0238_body.py。用法:python make_mgr_v0238.py <new 夾>"""
import hashlib
import sys
from pathlib import Path

N = Path(sys.argv[1])
doc = ('"""VRN-2 SystemManager v0238 — 薄尾(邊測邊修:輸出驗證找到表頭列當數據):年度數據的一列若是表頭 —— 值是期間字(凱基 2637 現金流量表「NT$百萬 Dec-23A … Dec-27F」5 筆 · '
       'JP 2330「Balance Sheet & Cash Flow Statement FY24A … FY27E」4 筆)· 科目整個是期間字(GS 6415「Jul-25 Oct-25」Jan-26 / Apr-26 2 筆)· 一整列的值都等於期間的年份 —— '
       '整列移出年度數據 · 進剔除冊(帶理由);其餘一筆都不動。獨立驗證器 v0100 判這 11 筆對位(表頭字本來就印在期間那一欄)→ v0101 另查值的種類(HDRVAL)。\n'
       '  零替換:前版函式一個都不改;前版輸出冊(v0237)整段照跑後再補(直接叫前版包裝)· vrn2 / 成功登記用同一段程式碼重新綁定 · 前版必須是 v0237 · 其餘動詞照前版鏈。\n"""\n')
src = "#!/usr/bin/env python3\n# -*- coding: utf-8 -*-\n" + doc + "from __future__ import annotations\n\n\n" + (N / "_bridge_block.txt").read_text(encoding="utf-8").rstrip("\n") + "\n\n\n" + (N / "mgr_v0238_body.py").read_text(encoding="utf-8").lstrip("\n")
compile(src, "VRN_SystemManager_v0238.py", "exec")
(N / "VRN_SystemManager_v0238.py").write_text(src, encoding="utf-8", newline="\n")
print("[計] VRN_SystemManager_v0238.py · %d 位元組 · sha %s" % (len(src.encode()), hashlib.sha256(src.encode()).hexdigest()[:12]))
