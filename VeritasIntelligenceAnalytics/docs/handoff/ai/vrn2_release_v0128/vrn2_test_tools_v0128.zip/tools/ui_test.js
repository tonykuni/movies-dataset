// VRN-2 U/I 真瀏覽器實測(Chromium · Playwright)· 用法:node ui_test.js <VRN2_UI_latest.html> <截圖夾> [output 夾(比對頁面值 = 年度數據冊)]
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
  const file = path.resolve(process.argv[2]);
  const shots = path.resolve(process.argv[3]);
  fs.mkdirSync(shots, { recursive: true });
  const res = [];
  const ok = (name, cond, extra) => { res.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra).slice(0, 160) }); };
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--allow-file-access-from-files'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  try { await ctx.grantPermissions(['clipboard-read', 'clipboard-write']); } catch (e) { }
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  const dialogs = [];
  let dialogMode = 'dismiss';
  page.on('dialog', async d => { dialogs.push({ type: d.type(), msg: d.message().slice(0, 80) }); if (dialogMode === 'accept') await d.accept(); else await d.dismiss(); });
  await page.goto('file://' + file);
  await page.waitForLoadState('load');

  // 1) 左側操作面板
  ok('左側操作面板可見', await page.isVisible('#vrn2panel'));
  const hrefs = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('4 個 vrn2:// 動作', JSON.stringify(hrefs) === JSON.stringify(['vrn2://run', 'vrn2://run?nopush=1', 'vrn2://run-clean', 'vrn2://restore-archive']), hrefs.join(' | '));
  ok('頁面沒有 via://', !(await page.content()).includes('via://'));
  const opens = await page.$$eval('#vrn2panel a[target=_blank]', as => as.map(a => a.textContent.trim() + '=' + a.getAttribute('href').slice(0, 8)));
  ok('開啟連結(輸出冊 / 切割檢視 / 範圍夾 / 備份夾)', opens.length >= 3 && opens.every(x => x.includes('file:///')), opens.join(' · '));

  // 2) 這次不上船 → 改寫連結
  await page.check('#vnopush');
  const h2 = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('勾「這次不上船」→ 重跑類都帶 nopush=1 · 還原不變', h2[0] === 'vrn2://run?nopush=1' && h2[1] === 'vrn2://run?nopush=1' && h2[2] === 'vrn2://run-clean?nopush=1' && h2[3] === 'vrn2://restore-archive', h2.join(' | '));
  await page.uncheck('#vnopush');
  const h3 = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('取消勾選 → 連結還原', h3[0] === 'vrn2://run' && h3[2] === 'vrn2://run-clean', h3.join(' | '));

  // 3) 分頁
  const tabs = await page.$$eval('#vrn2tabs button', bs => bs.map(b => b.textContent));
  ok('右側分頁數 ≥ 9', tabs.length >= 9, tabs.length + ':' + tabs.join('/'));
  let allOne = true;
  for (let i = 0; i < tabs.length; i++) {
    await page.click(`#vrn2tabs button >> nth=${i}`);
    const vis = await page.$$eval('.vtab', ps => ps.filter(p => p.style.display !== 'none').length);
    const sel = await page.$$eval('#vrn2tabs button', bs => bs.findIndex(b => b.getAttribute('aria-selected') === 'true'));
    if (vis !== 1 || sel !== i) allOne = false;
  }
  ok('每個分頁點下去只顯示那一頁 · aria-selected 跟著走', allOne);
  const compVisible = await page.evaluate(() => { const d = [...document.querySelectorAll('div')].find(x => (x.textContent || '').startsWith('VRN-2 完成判定')); return !!d && d.offsetParent !== null && !d.closest('.vtab'); });
  ok('完成判定面板永遠可見(不在分頁裡)', compVisible);
  await page.screenshot({ path: path.join(shots, 'ui_tab_last.png'), fullPage: false });

  // 4) 記住上次分頁
  await page.click('#vrn2tabs button >> nth=2');
  await page.reload();
  await page.waitForLoadState('load');
  const selAfter = await page.$$eval('#vrn2tabs button', bs => bs.findIndex(b => b.getAttribute('aria-selected') === 'true'));
  ok('重新整理後停在上次分頁(第 3 頁)', selAfter === 2, selAfter);
  await page.click('#vrn2tabs button >> nth=0');

  // 5) 按鈕送出狀態 / 還原確認
  await page.evaluate(() => document.querySelectorAll('a.vact').forEach(a => a.addEventListener('click', e => e.preventDefault())));   // 測試時不真的開外部協定
  await page.click('a.vact[data-a="run"]');
  const st1 = await page.textContent('#vstat');
  ok('按「▶ 完整重跑」→ 顯示已送出 + 協定未註冊時的提示', st1.includes('已送出 vrn2://run') && st1.includes('複製執行指令'), st1);
  dialogMode = 'dismiss';
  await page.click('a.vact[data-a="restore-archive"]');
  const st2 = await page.textContent('#vstat');
  ok('按「↩ 還原封存」→ 先跳確認 · 取消就不送', dialogs.length === 1 && dialogs[0].type === 'confirm' && st2.includes('已取消'), st2);
  dialogMode = 'accept';
  await page.click('a.vact[data-a="restore-archive"]');
  const st3 = await page.textContent('#vstat');
  ok('確認後才送出 vrn2://restore-archive', st3.includes('已送出 vrn2://restore-archive'), st3);

  // 6) 備援:複製執行指令
  const c0 = await page.getAttribute('#vcopy', 'data-c0');
  const c1 = await page.getAttribute('#vcopy', 'data-c1');
  ok('備援指令第一步升優先權 → 再接 PS 加速器 → 才跑啟動器', c0.indexOf('PriorityClass') >= 0 && c0.indexOf('PriorityClass') < c0.indexOf('VIA_PS_Accel_Module') && c0.indexOf('VIA_PS_Accel_Module') < c0.indexOf('& $py $A'), c0.slice(0, 120));
  ok('不上船版指令帶 VIA_VRN2_NO_PUSH = 1 · 一般版會清掉', c1.includes("$env:VIA_VRN2_NO_PUSH = '1'") && c0.includes('Remove-Item Env:\\VIA_VRN2_NO_PUSH'));
  ok('指令用啟動器實際路徑(VRN2_UIAction_Config.json)', /\$A = '.*ActivateVRN-2\.py'/.test(c0), (c0.match(/\$A = '[^']*'/) || [''])[0]);
  dialogMode = 'dismiss';
  await page.click('#vcopy');
  await page.waitForTimeout(300);
  let clip = '';
  try { clip = await page.evaluate(() => navigator.clipboard.readText()); } catch (e) { clip = ''; }
  const btn = await page.textContent('#vcopy');
  const viaPrompt = dialogs.some(d => d.type === 'prompt');
  ok('⧉ 複製執行指令:剪貼簿拿到一般版指令(或剪貼簿不可用時跳對話框)', (clip === c0 && btn.includes('已複製')) || viaPrompt, clip ? 'clipboard' : (viaPrompt ? 'prompt' : 'none'));
  await page.check('#vnopush');
  await page.click('#vcopy');
  await page.waitForTimeout(300);
  try { clip = await page.evaluate(() => navigator.clipboard.readText()); } catch (e) { clip = ''; }
  ok('勾不上船後複製 → 拿到不上船版指令', clip === c1 || dialogs.filter(d => d.type === 'prompt').length >= 2);

  // 7) 錯誤 / 截圖
  ok('沒有頁面腳本錯誤', errors.length === 0, errors.join(' | '));
  await page.uncheck('#vnopush');
  await page.click('#vrn2tabs button >> nth=0');
  await page.screenshot({ path: path.join(shots, 'ui_overview.png'), fullPage: false });
  const outTab = tabs.findIndex(t => t.includes('剔除冊'));
  if (outTab >= 0) { await page.click(`#vrn2tabs button >> nth=${outTab}`); await page.screenshot({ path: path.join(shots, 'ui_rejected.png'), fullPage: false }); }
  ok('剔除冊有自己的分頁', outTab >= 0, outTab);
  const subTab = tabs.findIndex(t => t.includes('子欄拆分'));
  let subRows = 0;
  if (subTab >= 0) {
    await page.click(`#vrn2tabs button >> nth=${subTab}`);
    subRows = await page.$$eval('h2', hs => { const h = hs.find(x => x.textContent.includes('子欄拆分')); const t = h && h.nextElementSibling; return t && t.offsetParent !== null ? t.querySelectorAll('tr').length - 1 : -1; });
    await page.screenshot({ path: path.join(shots, 'ui_subcol.png'), fullPage: false });
  }
  ok('v0124 子欄拆分總表(自己的分頁 · 可見 · 每張表一列)', subTab >= 0 && subRows >= 1, 'tab ' + subTab + ' · 列 ' + subRows);

  // 8) v0127「驗證過的輸出」分頁(管理器 v0237 · 獨立驗證器寫回)
  const book = process.argv[4] ? JSON.parse(fs.readFileSync(path.join(process.argv[4], 'VRN2_FinancialData_latest.json'), 'utf8')) : null;
  const basicBook = process.argv[4] ? JSON.parse(fs.readFileSync(path.join(process.argv[4], 'VRN2_BasicInfo_latest.json'), 'utf8')) : null;
  const voTab = tabs.findIndex(t => t.includes('驗證過的輸出'));
  ok('v0127「驗證過的輸出」是第一個分頁', voTab === 0, 'tab ' + voTab + ' · ' + tabs[0]);
  await page.click(`#vrn2tabs button >> nth=${Math.max(voTab, 0)}`);
  const vo = await page.evaluate(() => { const V = window.VRN2_VO; if (!V) return null; return { ivOk: V.ivOk, n: V.data.n, nf: V.data.F.length, fp: V.data.fp, bar: document.getElementById('vo-ivbar').textContent, cls: document.getElementById('vo-ivbar').className,
    rows: V.data.F.reduce((s, F) => s + F.r.length, 0), vals: [].concat(...V.data.F.map(F => F.r.map(r => [r[0], r[8], V.data.S[r[5]], V.data.S[r[6]]]))) }; });
  ok('獨立驗證已寫回且冊指紋與本頁相同 → 套用(狀態列說明指紋相同與計數)', vo && vo.ivOk && vo.bar.includes('與本頁相同') && vo.bar.includes('年度數據'), vo ? vo.bar.slice(0, 150) : 'no VRN2_VO');
  ok('狀態列無「不過」→ 綠色', vo && vo.cls.includes('ivg') && vo.bar.includes('✗ 不過 0'), vo ? vo.cls : '');
  let same = !!(vo && book);
  if (vo && book) { if (vo.rows !== book.length || vo.n !== book.length) same = false; for (const [i, v, it, pe] of vo.vals) { const b = book[i]; if (!b || String(b.VALUE) !== v || b.ITEM !== it || b.PERIOD !== pe) { same = false; break; } } }
  ok('頁面上的每一格 = 年度數據冊的那一筆(值 · 科目 · 期間逐筆相同)', same, vo ? vo.rows + ' 格 / 冊 ' + (book ? book.length : '?') : '');
  const ovRows = await page.$$eval('#vo-ov tr[data-i]', trs => trs.length);
  ok('全部檔案總表(每份一列)', vo && ovRows === vo.nf && ovRows >= 1, ovRows);
  const pickIdx = await page.evaluate(() => window.VRN2_VO.data.F.findIndex(F => F.f.indexOf('凱基投顧_2637') === 0));
  if (pickIdx >= 0) {
    await page.selectOption('#vo-file', String(pickIdx));
    const one = await page.evaluate(() => { const t = document.getElementById('vo-one'); const tds = [...t.querySelectorAll('.vo-grid td')]; const it = [...t.querySelectorAll('.vo-grid td.it')].map(x => x.textContent);
      const tp = [...t.querySelectorAll('table')][0]; const tpr = [...tp.querySelectorAll('tr')].find(r => r.cells[0] && r.cells[0].textContent === 'TARGET_PRICE');
      const cr = [...t.querySelectorAll('.vo-grid tr')].find(r => r.cells[0] && r.cells[0].textContent.indexOf('流動比率') === 0);
      return { g: tds.filter(x => x.className === 'g').length, y: tds.filter(x => x.className === 'y').length, r: tds.filter(x => x.className === 'r').length, items: it.length,
        tp: tpr ? [tpr.cells[1].textContent, tpr.cells[1].className, tpr.cells[3].textContent] : null, cr: cr ? [...cr.cells].slice(1).map(c => c.textContent + '|' + c.className) : null, tip: cr ? cr.cells[1].title : '' }; });
    ok('選凱基 2637 → 基本資料目標價 104.0 · 綠 · 獨立驗證寫「標籤旁」', one.tp && one.tp[0].startsWith('104.0') && one.tp[1] === 'g' && one.tp[2].includes('標籤旁'), JSON.stringify(one.tp));
    ok('v0237 一格整列拆開的「流動比率 (x)」五期都在 · 每格綠 ✓✓', one.cr && one.cr.length >= 5 && one.cr.filter(c => c.endsWith('|g')).length === 5 && one.cr[0].startsWith('0.6'), JSON.stringify(one.cr));
    ok('格子滑鼠提示:值 · 頁 · 表 · 列 · VRN-2 驗證 · 獨立驗證判決', one.tip.includes('VRN-2:') && one.tip.includes('獨立驗證:ALIGNED') && one.tip.includes('第 5 頁'), one.tip.replace(/\n/g, ' / ').slice(0, 140));
    ok('年度數據格子沒有紅 / 黃(全部 ✓✓)', one.g > 0 && one.r === 0 && one.y === 0, 'g ' + one.g + ' · y ' + one.y + ' · r ' + one.r);
    await page.fill('#vo-q', '每股淨值');
    const qi = await page.$$eval('#vo-one .vo-grid td.it', ts => ts.map(t => t.textContent));
    ok('搜尋「每股淨值」→ 只剩含這個字的科目', qi.length >= 1 && qi.every(t => t.includes('每股淨值')), qi.join(' / '));
    await page.fill('#vo-q', '');
    await page.check('#vo-bad');
    const bad = await page.textContent('#vo-one');
    ok('勾「只看待核對」→ 全部 ✓✓ 時顯示沒有符合條件的列', bad.includes('沒有符合條件的列'));
    await page.uncheck('#vo-bad');
    const [dl] = await Promise.all([page.waitForEvent('download', { timeout: 8000 }), page.click('#vo-csv')]);
    const dp = path.join(shots, 'vo_download.csv'); await dl.saveAs(dp);
    const csv = fs.readFileSync(dp, 'utf8').replace(/^\ufeff/, '').trim().split(/\r?\n/);
    const nRows = await page.evaluate(i => window.VRN2_VO.data.F[i].r.length, pickIdx);
    ok('⤓ 下載本檔 CSV:表頭含 IV_VERDICT · 列數 = 本檔年度數據筆數 · 判決 ALIGNED', csv[0].includes('IV_VERDICT') && csv.length - 1 === nRows && csv.slice(1).every(l => l.includes('ALIGNED')), (csv.length - 1) + ' / ' + nRows);
    await page.screenshot({ path: path.join(shots, 'ui_verified.png'), fullPage: false });
    await page.evaluate(() => { const g = [...document.querySelectorAll('#vo-one .vo-tb')].find(x => x.textContent.indexOf('P5·F·02') >= 0) || document.getElementById('vo-one'); g.scrollIntoView({ block: 'start' }); });
    await page.screenshot({ path: path.join(shots, 'ui_verified_grid.png'), fullPage: false });
    await page.evaluate(() => document.getElementById('vo-one').scrollIntoView({ block: 'start' }));
    await page.screenshot({ path: path.join(shots, 'ui_verified_basic.png'), fullPage: false });
  } else { ok('選凱基 2637(測試檔不在這一輪)', false, 'not found'); }
  // 9) 指紋不同(別一輪的驗證結果)→ 不套用
  const html2 = fs.readFileSync(file, 'utf8').replace(/("fp":")([0-9a-f]{16})(","n":\d+,"w")/, (m, a, b, c) => a + '0000000000000000' + c);
  const f2 = path.join(shots, 'ui_fp_mismatch.html'); fs.writeFileSync(f2, html2);
  const p2 = await ctx.newPage(); const e2 = []; p2.on('pageerror', e => e2.push(e.message));
  await p2.goto('file://' + f2); await p2.waitForLoadState('load');
  const mm = await p2.evaluate(() => ({ ok: window.VRN2_VO && window.VRN2_VO.ivOk, bar: document.getElementById('vo-ivbar').textContent, u: document.querySelectorAll('#vo-one td.u').length, g: document.querySelectorAll('#vo-one td.g').length }));
  ok('驗證結果指紋不同 → 不套用(狀態列寫別一輪 · 格子只顯示 VRN-2 驗證 ✓)', html2 !== fs.readFileSync(file, 'utf8') && mm.ok === false && mm.bar.includes('別一輪') && mm.u > 0 && mm.g === 0, mm.bar.slice(0, 80) + ' · u ' + mm.u + ' · g ' + mm.g);
  ok('新分頁沒有頁面腳本錯誤', errors.length === 0 && e2.length === 0, errors.concat(e2).join(' | '));
  await browser.close();
  const pass = res.filter(r => r.ok).length;
  for (const r of res) console.log(`  [${r.ok ? 'OK' : 'FAIL'}] ${r.name}${r.extra ? ' · ' + r.extra : ''}`);
  console.log(`[計] U/I 真瀏覽器實測 ${pass}/${res.length} · ${pass === res.length ? 'PASS' : 'FAIL'}`);
  process.exit(pass === res.length ? 0 : 1);
})().catch(e => { console.error('[RED] ' + e.stack); process.exit(2); });
