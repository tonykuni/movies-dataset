#!/bin/bash
# 打包 v0127 發行夾(啟動器 zip · 測試工具 zip · 發行清單)+ 一鍵 PS 填雜湊
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
R=$S/release127; N=$S/new; T=$S/tools
rm -rf $S/pkg127; mkdir -p $R $S/pkg127/zl $S/pkg127/tools/src $S/pkg127/tools/tools $S/pkg127/tools/fixture
cp $N/ActivateVRN-2_v0127.py $S/pkg127/zl/ActivateVRN-2.py
cp $N/VRN_SystemManager_v0237.py $N/mgr_v0237_body.py $N/VRN_SystemManager_v0236.py $N/mgr_v0236_body.py $N/VRN2_IndependentVerifier_v0100.py $N/_bridge_block.txt $N/launcher_v0127_doc.txt $N/launcher_v0127_funcs.py $S/pkg127/tools/src/
cp $T/build_v0127.py $T/mktree.sh $T/runl.sh $T/ship_test.py $T/ui_test.js $T/verify_outputs.py $T/verify_outputs_v0126.py $T/make_verifier_v0100.py $T/cmp_fin.py $T/cmp_sub.py $T/cmp_basic.py $T/cmp_summ.py \
   $T/verify_mutation_suite.py $T/subcol_mutation_test.py $T/upgrade_test.sh $T/run_ps_test.sh $T/scen127.sh $T/pack127.sh $T/extract.py $S/pkg127/tools/tools/
cp $S/fixture/VRN_SystemManager_v0230.py $S/pkg127/tools/fixture/TESTSTUB_VRN_SystemManager_v0230.py
python3 - $S $R $N <<'PY'
import zipfile, sys, os, json, hashlib
S, R, N = sys.argv[1:4]
def dz(out, root):
    files = sorted(os.path.relpath(os.path.join(dp, f), root) for dp, _, fs in os.walk(root) for f in fs)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in files:
            zi = zipfile.ZipInfo(f.replace(os.sep, "/"), (2026, 10, 19, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
            z.writestr(zi, open(os.path.join(root, f), "rb").read())
dz(R + "/ActivateVRN-2_v0127.zip", S + "/pkg127/zl"); dz(R + "/vrn2_test_tools_v0127.zip", S + "/pkg127/tools")
def meta(p, name=None):
    b = open(p, "rb").read(); return {"file": name or os.path.basename(p), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}
rp = R + "/VRN2_Release_v0127.json"
if os.path.exists(rp):
    rel = json.load(open(rp, encoding="utf-8"))
else:
    old = json.load(open("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0126/VRN2_Release_v0126.json", encoding="utf-8"))
    order = [c for c in old["embedded_components_landing_order"] if c["file"] != "VRN2_Handover_v0126.md"]
    i = [c["file"] for c in order].index("VRN_SystemManager_v0236.py")
    order.insert(i + 1, {"file": "VRN_SystemManager_v0237.py"})
    order += [{"file": "VRN2_IndependentVerifier_v0100.py"}, {"file": "VRN2_Handover_v0127.md"}]
    rel = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0127", "date": "2026-10-19", "operator_decision": old["operator_decision"],
           "operator_order_2026_10_19": "開閘 授權 + 完成一切測試修正工作 並生成 HTML U/I 上有驗證過的 OUTPUT",
           "supersedes": "ActivateVRN-2 v0126(docs/handoff/ai/vrn2_release_v0126)", "embedded_components_landing_order": order,
           "tested_in": old["tested_in"], "results": {"draft": True}}
rel["launcher"] = meta(N + "/ActivateVRN-2_v0127.py"); rel["launcher_zip"] = meta(R + "/ActivateVRN-2_v0127.zip"); rel["test_tools_zip"] = meta(R + "/vrn2_test_tools_v0127.zip")
rel["embedded_components_landing_order"] = [meta(N + "/" + c["file"]) if c["file"] in ("VRN_SystemManager_v0237.py", "VRN2_IndependentVerifier_v0100.py", "VRN2_Handover_v0127.md") else c for c in rel["embedded_components_landing_order"]]
json.dump(rel, open(rp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("launcher", rel["launcher"]["sha256"][:12])
PY
H=$(sha256sum $N/ActivateVRN-2_v0127.py | cut -d' ' -f1); sed -i "s/\$Want   = '[0-9a-f]\{64\}'/\$Want   = '$H'/" $S/Run-VRN2-v0127.ps1
