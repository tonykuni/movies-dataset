#!/bin/bash
# v0128 終版 E2E:z = 從 v0126 升級(VIA_ROOT 指錯 → 再跑一次)· u = 使用者機器情境(v0125 · Downloads v0127 · VIA_ROOT 指錯)· 結果在 v128run/
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; L=$S/v128run
strip() { sed -i 's/\x1b\[[0-9;]*m//g' "$1"; }
case "$1" in
 z) bash $S/tools/scen128b.sh $S/t128z > $L/scen_z.log 2>&1
    bash $S/tools/run_boot_test_badroot.sh $S/t128z > $L/boot_z1_wrongroot.log 2>&1; echo "rc=$?" >> $L/boot_z1_wrongroot.log; strip $L/boot_z1_wrongroot.log
    bash $S/tools/run_boot_test.sh $S/t128z > $L/boot_z2.log 2>&1; echo "rc=$?" >> $L/boot_z2.log; strip $L/boot_z2.log ;;
 u) bash $S/tools/scen128u.sh $S/t128u > $L/scen_u.log 2>&1
    bash $S/tools/run_boot_test_badroot.sh $S/t128u > $L/boot_u1_wrongroot.log 2>&1; echo "rc=$?" >> $L/boot_u1_wrongroot.log; strip $L/boot_u1_wrongroot.log ;;
esac
