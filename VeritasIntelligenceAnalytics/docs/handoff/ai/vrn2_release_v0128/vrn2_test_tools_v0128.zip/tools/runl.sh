#!/bin/bash
# 在沙盒測試樹跑啟動器:$1 = 樹 · 其餘參數傳給啟動器
T="$1"; shift
cd "$T/Downloads" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VIA_VRN_INPUT="$T/samples" VIA_ENVS_HOME="$T/envs" \
  VIA_VRN2_OCR_PY="$(command -v python3)" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 \
  timeout 3500 "${PY:-python3}" ActivateVRN-2.py --no-install "$@"
