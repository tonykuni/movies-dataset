#!/bin/bash
# 建沙盒測試樹:$1 = 目標夾 · $2 = 啟動器檔
set -e
T="$1"; L="$2"
rm -rf "$T"; mkdir -p "$T/VIA/functional modules/VRN/SSOT" "$T/VIA/supportive modules/network" "$T/samples" "$T/Downloads" "$T/home" "$T/tmp" "$T/envs/vrn2_ocr"
cp "/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules/VeritasCeleritas_v1141.py" "$T/VIA/supportive modules/"
cp "/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules/network/"VeritasAegisNexus*.py "$T/VIA/supportive modules/network/"
V="$T/VIA/functional modules/VRN"
cp "/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN/VRN_SystemManager_v0153.py" "$V/"          # GitHub 上 VCGC-VRN 尾版(tracked)
cp "/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN/VRN_ENG062_SummarizerV1_v0103.py" "$V/"    # repo 既有 ENG062(tracked)
P="/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN/intake/VRN_v0108_Annual/VRN_v0108_Complete_Handover/pack"
for f in "$P"/engine/fixtures/REAL_TEST_INPUT/*.pdf "$P"/inputs/*.pdf; do b=$(basename "$f"); [ -e "$T/samples/$b" ] || cp "$f" "$T/samples/$b"; done
echo '{"input_dir": "'"$T/samples"'"}' > "$V/SSOT/VRN_Config_v1000.json"
cp "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/emb/VRN2_OCRBridge_v0100.py" "$T/envs/vrn2_ocr/"
git -C "$T" init -q --bare remote.git 2>/dev/null || git init -q --bare "$T/remote.git"
cd "$T/VIA" && git init -q -b main && git config user.email t@t && git config user.name t && printf 'VIA_Reports/\n__pycache__/\n' > .gitignore && git add -A && git commit -qm base && git remote add origin "$T/remote.git" && git push -q -u origin main
cp "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/fixture/VRN_SystemManager_v0230.py" "$V/"                         # VRN-2 鏈代表(untracked · 如使用者機器)
cp "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/emb/VRN_ENG062_SummarizerV1_v0112.py" "$V/VRN_ENG062_SummarizerV1_v0111.py"   # VRN-2 舊版代表(untracked)
cp "$L" "$T/Downloads/ActivateVRN-2.py"
echo "tree ok: $(ls "$T/samples" | wc -l) PDF"
