"""VRN2_IndependentVerifier v0101 反向測試總表(每類錯放回輸出 → 驗證器必須抓到 · 原樣必須全過)。
用法:python verify_mutation_suite.py <output 夾> <PDF 夾> [樣本數 · 預設 3000]
  cmp_fin.py   年度數據:下一列 / 上一列的值 · 同列鄰欄的值 · 季度值標成年度期間(v3 與 v0100 並列)
  cmp_sub.py   子欄:下一列 / 上一列的值 · 轉置表:下一年的值
  cmp_basic.py 基本資料:目標價 ↔ 股價 · 目標價換成首頁別的數 · 評等換成定義頁才有的評等
  cmp_summ.py  一標題四重點:目標價換股價 · 原目標價 / 倍數換成原文別的數 · EPS 兩年對調 · 跨檔對調 · 太短
  cmp_hdr.py   v0101 表頭列:v0237 輸出真的出現過的 3 列表頭(11 筆)放回 → 全抓到 · 混進整本冊 → 一般列不誤標
  subcol_mutation_test.py  子欄 ①~④ · 分析師 ⑤ · 日期 ⑥ · 影像頁 ⑦ · DUPKEY ⑧ · 轉置 ⑨ · 值列錯開 ⑩"""
import re
import subprocess
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
od, pd = sys.argv[1], sys.argv[2]
n = sys.argv[3] if len(sys.argv) > 3 else "3000"
bad, rows = [], []
for sc, extra in (("cmp_fin.py", [n]), ("cmp_sub.py", []), ("cmp_basic.py", []), ("cmp_summ.py", []), ("cmp_hdr.py", []), ("subcol_mutation_test.py", [])):
    p = subprocess.run([sys.executable, "-W", "ignore", str(here / sc), od, pd] + extra, capture_output=True, text=True, encoding="utf-8")
    out = [l for l in p.stdout.splitlines() if l.strip()]
    for l in out:
        print("  " + l)
        if l.startswith("原樣"):
            body = re.split(r"v01\d\d", l)[-1]
            if re.search(r"'(FAIL|MISALIGNED|BADVALUE|BADITEM|SUBFAIL|TRANSFAIL|DUPKEY|QTRCOL|DUPROW|HDRVAL|PRESENT)'", body):
                bad.append("%s 原樣有不過:%s" % (sc, l[:120]))
        if l.startswith("反向") and "v3" not in l:
            k = re.search(r"仍(?:過| ALIGNED) (\d+)", l)
            if not k and "→" in l:
                k = re.search(r"\[(.*)\]$", l)
                if k and "ALIGNED'" in k.group(1).replace("TRANSALIGNED", "").replace("SUBALIGNED", ""):
                    bad.append("%s %s" % (sc, l[:120]))
                continue
            if k and int(k.group(1)) > 0:
                bad.append("%s %s" % (sc, l[:120]))
    if p.returncode not in (0, 1) or (sc in ("subcol_mutation_test.py", "cmp_hdr.py") and p.returncode != 0):
        bad.append("%s rc %d %s" % (sc, p.returncode, p.stderr[-300:]))
print("[計] 驗證器反向測試總表 %s%s" % ("PASS" if not bad else "FAIL", "" if not bad else " · " + " | ".join(bad)))
sys.exit(0 if not bad else 1)
