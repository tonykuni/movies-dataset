#!/bin/bash
# 升級路徑:同一棵樹先跑 v0123(完成 · 上船)→ 換成 v0124 再跑 · $1 = 樹 · $2 = v0123 啟動器 · $3 = v0124 啟動器
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
T="$1"
cd /tmp && $S/tools/mktree.sh "$T" "$2" 2>&1 | grep -v -e negotiat -e acknowledg
PY=$S/venv_vrn2/bin/python $S/tools/runl.sh "$T" > "$T.v0123.log" 2>&1
cp "$3" "$T/Downloads/ActivateVRN-2.py"
PY=$S/venv_vrn2/bin/python $S/tools/runl.sh "$T" > "$T.v0124.log" 2>&1
sed -i 's/\x1b\[[0-9;]*m//g' "$T.v0123.log" "$T.v0124.log"
echo "upgrade done"
