"""一標題四重點:原樣 + 反向(目標價換股價 · 原目標價換別的數 · 倍數換別的數 · EPS 年度對調 · 重點 / 標題跨檔對調)。用法:python cmp_summ.py <output> <pdfdir>"""
import collections, copy, json, re, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs as V
od, pd = sys.argv[1], sys.argv[2]
L_ = lambda n: json.loads(Path(od, "VRN2_%s_latest.json" % n).read_text(encoding="utf-8"))   # noqa: E731
b, f, s = L_("BasicInfo"), L_("FinancialData"), L_("Summary")
bm = {x["FILENAME"]: x for x in b}
r = V.verify_summary(s, pd, b, f)
print("原樣", dict(collections.Counter(v.split(" ·")[0] for x in r for v in x["checks"].values())))
for x in r:
    for k, v in x["checks"].items():
        if not v.startswith("PASS"):
            print("  ", x["FILENAME"][:26], k, v[:150])
def run(nm, ms, key):
    rr = V.verify_summary([m for m, _ in ms], pd, b, f)
    esc = [(m["FILENAME"][:18], why) for (m, why), x in zip(ms, rr) if x["checks"].get(key, "").startswith("PASS")]
    print("反向 %s %d 份 · 仍過 %d %s" % (nm, len(ms), len(esc), esc[:4]))
ms = []
for x in s:
    p1, bb = x.get("POINT_1") or "", bm.get(x["FILENAME"], {})
    m = re.match(r"目標價 ([\d.,]+) TWD", p1)
    if m and bb.get("CURRENT_PRICE_REPORT"):
        ms.append((dict(x, POINT_1=p1.replace(m.group(0), "目標價 %s TWD" % bb["CURRENT_PRICE_REPORT"], 1)), bb["CURRENT_PRICE_REPORT"]))
run("目標價換成股價", ms, "POINT_1")
ms = []
for x in s:
    p1 = x.get("POINT_1") or ""
    m = re.search(r"原目標價 ([\d.,]+)", p1)
    if m:
        txt = V.nfk(V.all_text(Path(pd) / x["FILENAME"]))
        alt = next((n for n in re.findall(r"(?<![\d.,])\d{2,4}(?![\d.,])", txt) if n != m.group(1) and not V._line_with(Path(pd) / x["FILENAME"], n, V._PREV)), None)
        if alt:
            ms.append((dict(x, POINT_1=p1.replace(m.group(0), "原目標價 %s" % alt, 1)), alt))
run("原目標價換成原文別的數", ms, "POINT_1")
ms = []
for x in s:
    p1 = x.get("POINT_1") or ""
    m = re.search(r"([\d.]+) 倍", p1)
    if m:
        txt = V.nfk(V.all_text(Path(pd) / x["FILENAME"]))
        alt = next((n for n in re.findall(r"(?<![\d.,])\d{2}(?![\d.,%])", txt) if n != m.group(1) and not re.search(r"(?<![\d.])%s\s*(?:x|X|倍)" % n, txt)), None)
        if alt:
            ms.append((dict(x, POINT_1=p1.replace(m.group(0), "%s 倍" % alt, 1)), alt))
run("倍數換成原文別的數", ms, "POINT_1")
ms = []
for x in s:
    for k in ("POINT_2", "POINT_3"):
        p_ = x.get(k) or ""
        e = re.findall(r"(\d{4}) 年 EPS[^；]*?\s([\-\d.,]+) TWD", p_)
        if len(e) >= 2 and e[0][1] != e[1][1]:
            q = p_.replace(" %s TWD" % e[0][1], " @@A", 1).replace(" %s TWD" % e[1][1], " %s TWD" % e[0][1], 1).replace(" @@A", " %s TWD" % e[1][1], 1)
            q = re.sub(r"（計算 YoY [\-\d.]+%）", "", q)
            ms.append((dict(x, **{k: q}), "%s↔%s" % (e[0][0], e[1][0])))
            run("EPS 兩年對調(%s)" % k, [ms[-1]], k)
ms = [(dict(x, POINT_3=s[(i + 1) % len(s)]["POINT_3"]), "跨檔") for i, x in enumerate(s) if s[(i + 1) % len(s)].get("POINT_3") and s[(i + 1) % len(s)]["POINT_3"] != (x.get("POINT_3") or "")]
run("重點 3 跨檔對調", ms, "POINT_3")
ms = [(dict(x, TITLE=s[(i + 1) % len(s)]["TITLE"]), "跨檔") for i, x in enumerate(s) if s[(i + 1) % len(s)].get("TITLE") and s[(i + 1) % len(s)]["TITLE"] != (x.get("TITLE") or "")]
run("標題跨檔對調", ms, "TITLE")
run("標題只剩一個字", [(dict(x, TITLE=(x.get("TITLE") or "x")[:1]), "1 字") for x in s if x.get("TITLE")], "TITLE")
