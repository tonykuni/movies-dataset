// VRN-2 U/I 真瀏覽器實測(Chromium · Playwright)· 用法:node ui_test.js <VRN2_UI_latest.html> <截圖夾>
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
  const file = path.resolve(process.argv[2]);
  const shots = path.resolve(process.argv[3]);
  fs.mkdirSync(shots, { recursive: true });
  const res = [];
  const ok = (name, cond, extra) => { res.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra).slice(0, 160) }); };
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--allow-file-access-from-files'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  try { await ctx.grantPermissions(['clipboard-read', 'clipboard-write']); } catch (e) { }
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  const dialogs = [];
  let dialogMode = 'dismiss';
  page.on('dialog', async d => { dialogs.push({ type: d.type(), msg: d.message().slice(0, 80) }); if (dialogMode === 'accept') await d.accept(); else await d.dismiss(); });
  await page.goto('file://' + file);
  await page.waitForLoadState('load');

  // 1) 左側操作面板
  ok('左側操作面板可見', await page.isVisible('#vrn2panel'));
  const hrefs = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('4 個 vrn2:// 動作', JSON.stringify(hrefs) === JSON.stringify(['vrn2://run', 'vrn2://run?nopush=1', 'vrn2://run-clean', 'vrn2://restore-archive']), hrefs.join(' | '));
  ok('頁面沒有 via://', !(await page.content()).includes('via://'));
  const opens = await page.$$eval('#vrn2panel a[target=_blank]', as => as.map(a => a.textContent.trim() + '=' + a.getAttribute('href').slice(0, 8)));
  ok('開啟連結(輸出冊 / 切割檢視 / 範圍夾 / 備份夾)', opens.length >= 3 && opens.every(x => x.includes('file:///')), opens.join(' · '));

  // 2) 這次不上船 → 改寫連結
  await page.check('#vnopush');
  const h2 = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('勾「這次不上船」→ 重跑類都帶 nopush=1 · 還原不變', h2[0] === 'vrn2://run?nopush=1' && h2[1] === 'vrn2://run?nopush=1' && h2[2] === 'vrn2://run-clean?nopush=1' && h2[3] === 'vrn2://restore-archive', h2.join(' | '));
  await page.uncheck('#vnopush');
  const h3 = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('取消勾選 → 連結還原', h3[0] === 'vrn2://run' && h3[2] === 'vrn2://run-clean', h3.join(' | '));

  // 3) 分頁
  const tabs = await page.$$eval('#vrn2tabs button', bs => bs.map(b => b.textContent));
  ok('右側分頁數 ≥ 9', tabs.length >= 9, tabs.length + ':' + tabs.join('/'));
  let allOne = true;
  for (let i = 0; i < tabs.length; i++) {
    await page.click(`#vrn2tabs button >> nth=${i}`);
    const vis = await page.$$eval('.vtab', ps => ps.filter(p => p.style.display !== 'none').length);
    const sel = await page.$$eval('#vrn2tabs button', bs => bs.findIndex(b => b.getAttribute('aria-selected') === 'true'));
    if (vis !== 1 || sel !== i) allOne = false;
  }
  ok('每個分頁點下去只顯示那一頁 · aria-selected 跟著走', allOne);
  const compVisible = await page.evaluate(() => { const d = [...document.querySelectorAll('div')].find(x => (x.textContent || '').startsWith('VRN-2 完成判定')); return !!d && d.offsetParent !== null && !d.closest('.vtab'); });
  ok('完成判定面板永遠可見(不在分頁裡)', compVisible);
  await page.screenshot({ path: path.join(shots, 'ui_tab_last.png'), fullPage: false });

  // 4) 記住上次分頁
  await page.click('#vrn2tabs button >> nth=2');
  await page.reload();
  await page.waitForLoadState('load');
  const selAfter = await page.$$eval('#vrn2tabs button', bs => bs.findIndex(b => b.getAttribute('aria-selected') === 'true'));
  ok('重新整理後停在上次分頁(第 3 頁)', selAfter === 2, selAfter);
  await page.click('#vrn2tabs button >> nth=0');

  // 5) 按鈕送出狀態 / 還原確認
  await page.evaluate(() => document.querySelectorAll('a.vact').forEach(a => a.addEventListener('click', e => e.preventDefault())));   // 測試時不真的開外部協定
  await page.click('a.vact[data-a="run"]');
  const st1 = await page.textContent('#vstat');
  ok('按「▶ 完整重跑」→ 顯示已送出 + 協定未註冊時的提示', st1.includes('已送出 vrn2://run') && st1.includes('複製執行指令'), st1);
  dialogMode = 'dismiss';
  await page.click('a.vact[data-a="restore-archive"]');
  const st2 = await page.textContent('#vstat');
  ok('按「↩ 還原封存」→ 先跳確認 · 取消就不送', dialogs.length === 1 && dialogs[0].type === 'confirm' && st2.includes('已取消'), st2);
  dialogMode = 'accept';
  await page.click('a.vact[data-a="restore-archive"]');
  const st3 = await page.textContent('#vstat');
  ok('確認後才送出 vrn2://restore-archive', st3.includes('已送出 vrn2://restore-archive'), st3);

  // 6) 備援:複製執行指令
  const c0 = await page.getAttribute('#vcopy', 'data-c0');
  const c1 = await page.getAttribute('#vcopy', 'data-c1');
  ok('備援指令第一步升優先權 → 再接 PS 加速器 → 才跑啟動器', c0.indexOf('PriorityClass') >= 0 && c0.indexOf('PriorityClass') < c0.indexOf('VIA_PS_Accel_Module') && c0.indexOf('VIA_PS_Accel_Module') < c0.indexOf('& $py $A'), c0.slice(0, 120));
  ok('不上船版指令帶 VIA_VRN2_NO_PUSH = 1 · 一般版會清掉', c1.includes("$env:VIA_VRN2_NO_PUSH = '1'") && c0.includes('Remove-Item Env:\\VIA_VRN2_NO_PUSH'));
  ok('指令用啟動器實際路徑(VRN2_UIAction_Config.json)', /\$A = '.*ActivateVRN-2\.py'/.test(c0), (c0.match(/\$A = '[^']*'/) || [''])[0]);
  dialogMode = 'dismiss';
  await page.click('#vcopy');
  await page.waitForTimeout(300);
  let clip = '';
  try { clip = await page.evaluate(() => navigator.clipboard.readText()); } catch (e) { clip = ''; }
  const btn = await page.textContent('#vcopy');
  const viaPrompt = dialogs.some(d => d.type === 'prompt');
  ok('⧉ 複製執行指令:剪貼簿拿到一般版指令(或剪貼簿不可用時跳對話框)', (clip === c0 && btn.includes('已複製')) || viaPrompt, clip ? 'clipboard' : (viaPrompt ? 'prompt' : 'none'));
  await page.check('#vnopush');
  await page.click('#vcopy');
  await page.waitForTimeout(300);
  try { clip = await page.evaluate(() => navigator.clipboard.readText()); } catch (e) { clip = ''; }
  ok('勾不上船後複製 → 拿到不上船版指令', clip === c1 || dialogs.filter(d => d.type === 'prompt').length >= 2);

  // 7) 錯誤 / 截圖
  ok('沒有頁面腳本錯誤', errors.length === 0, errors.join(' | '));
  await page.uncheck('#vnopush');
  await page.click('#vrn2tabs button >> nth=0');
  await page.screenshot({ path: path.join(shots, 'ui_overview.png'), fullPage: false });
  const outTab = tabs.findIndex(t => t.includes('剔除冊'));
  if (outTab >= 0) { await page.click(`#vrn2tabs button >> nth=${outTab}`); await page.screenshot({ path: path.join(shots, 'ui_rejected.png'), fullPage: false }); }
  ok('剔除冊有自己的分頁', outTab >= 0, outTab);
  const subTab = tabs.findIndex(t => t.includes('子欄拆分'));
  let subRows = 0;
  if (subTab >= 0) {
    await page.click(`#vrn2tabs button >> nth=${subTab}`);
    subRows = await page.$$eval('h2', hs => { const h = hs.find(x => x.textContent.includes('子欄拆分')); const t = h && h.nextElementSibling; return t && t.offsetParent !== null ? t.querySelectorAll('tr').length - 1 : -1; });
    await page.screenshot({ path: path.join(shots, 'ui_subcol.png'), fullPage: false });
  }
  ok('v0124 子欄拆分總表(自己的分頁 · 可見 · 每張表一列)', subTab >= 0 && subRows >= 1, 'tab ' + subTab + ' · 列 ' + subRows);
  await browser.close();
  const pass = res.filter(r => r.ok).length;
  for (const r of res) console.log(`  [${r.ok ? 'OK' : 'FAIL'}] ${r.name}${r.extra ? ' · ' + r.extra : ''}`);
  console.log(`[計] U/I 真瀏覽器實測 ${pass}/${res.length} · ${pass === res.length ? 'PASS' : 'FAIL'}`);
  process.exit(pass === res.length ? 0 : 1);
})().catch(e => { console.error('[RED] ' + e.stack); process.exit(2); });
