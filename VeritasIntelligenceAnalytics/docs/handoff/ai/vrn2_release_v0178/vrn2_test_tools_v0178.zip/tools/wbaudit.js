// VRN-2 Workbench responsive / accessibility audit — adapted from the operator's visual-responsive.spec (4 viewports · same checks · no density control:
// the Workbench has no density setting and its look is locked). Read-only: loads the page, measures, screenshots. No network (file://).
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const [, , file, outdir] = process.argv;
  const viewports = [
    { name: 'desktop', width: 1920, height: 1080 }, { name: 'laptop', width: 1440, height: 900 },
    { name: 'tablet', width: 768, height: 1024 }, { name: 'mobile', width: 390, height: 844 },
  ];
  const b = await chromium.launch();
  const out = { file: path.basename(file), results: [] };
  for (const vp of viewports) {
    const ctx = await b.newContext({ viewport: { width: vp.width, height: vp.height } });
    const p = await ctx.newPage();
    const consoleErrors = [], pageErrors = [], external = [];
    p.on('console', m => { if (m.type() === 'error') consoleErrors.push(m.text().slice(0, 160)); });
    p.on('pageerror', e => pageErrors.push(String(e).slice(0, 160)));
    p.on('request', r => { const u = r.url(); if (!u.startsWith('file:') && !u.startsWith('data:') && !u.startsWith('blob:') && !u.startsWith('about:')) external.push(u.slice(0, 120)); });
    await p.goto('file://' + file);
    await p.waitForTimeout(700);
    const tabs = await p.evaluate(() => document.querySelectorAll('.tabs button').length);
    const perTab = [];
    for (let i = 0; i < Math.max(1, tabs); i++) {
      if (tabs) { await p.evaluate(i => document.querySelectorAll('.tabs button')[i].click(), i); await p.waitForTimeout(250); }
      const m = await p.evaluate(() => {
        const vis = el => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el); return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
        const buttons = [...document.querySelectorAll('button, a.action, [role="button"]')].filter(vis);
        const unnamedButtons = buttons.filter(el => !(el.getAttribute('aria-label') || el.getAttribute('title') || (el.textContent || '').trim())).map(el => el.outerHTML.slice(0, 80));
        const controls = [...document.querySelectorAll('input,select,textarea')].filter(vis);
        const unnamedControls = controls.filter(el => {
          if (el.getAttribute('aria-label') || el.getAttribute('aria-labelledby') || el.getAttribute('title')) return false;
          if (el.labels && el.labels.length) return false;
          if (el.type === 'hidden') return false;
          return true;
        }).map(el => el.outerHTML.slice(0, 90));
        const tables = [...document.querySelectorAll('table')].filter(vis).map((t, i) => {
          let anc = t.parentElement, scroller = null;
          while (anc && anc !== document.body) { const ox = getComputedStyle(anc).overflowX; if (['auto', 'scroll', 'overlay', 'hidden'].includes(ox)) { scroller = ox; break; } anc = anc.parentElement; }
          return { id: t.id || t.className || 'table-' + i, sw: t.scrollWidth, cw: (t.parentElement || t).clientWidth, scroller };
        });
        const badTables = tables.filter(t => t.sw > t.cw + 2 && !t.scroller);
        return { lang: document.documentElement.lang, title: document.title.length, h1: document.querySelectorAll('h1').length, main: document.querySelectorAll('main').length,
          innerWidth, docW: document.documentElement.scrollWidth, bodyW: document.body.scrollWidth,
          unnamedButtons, unnamedControls, badTables: badTables.map(t => t.id + ' ' + t.sw + '>' + t.cw), tableCount: tables.length };
      });
      perTab.push(m);
    }
    if (outdir) await p.screenshot({ path: path.join(outdir, 'audit_' + vp.name + '.png') });
    const agg = {
      viewport: vp.name, width: vp.width, lang: perTab[0].lang, h1: perTab[0].h1, main: perTab[0].main, title: perTab[0].title,
      pageOverflowPx: Math.max(...perTab.map(m => Math.max(m.docW, m.bodyW) - m.innerWidth)),
      unnamedButtons: [...new Set(perTab.flatMap(m => m.unnamedButtons))], unnamedControls: [...new Set(perTab.flatMap(m => m.unnamedControls))],
      tablesWithoutScroller: [...new Set(perTab.flatMap(m => m.badTables))], consoleErrors, pageErrors, external,
    };
    out.results.push(agg);
    await ctx.close();
  }
  await b.close();
  out.pass = out.results.every(r => r.lang && r.title > 0 && r.h1 === 1 && r.main >= 1 && r.unnamedButtons.length === 0 && r.unnamedControls.length === 0
    && r.tablesWithoutScroller.length === 0 && r.consoleErrors.length === 0 && r.pageErrors.length === 0 && r.external.length === 0
    && (r.width < 1000 || r.pageOverflowPx <= 1));
  console.log(JSON.stringify(out, null, 1));
})();
