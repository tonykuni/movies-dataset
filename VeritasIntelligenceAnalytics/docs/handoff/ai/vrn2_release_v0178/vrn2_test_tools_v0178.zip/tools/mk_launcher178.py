"""ActivateVRN-2_v0178.py = v0177 − 自製 VerbatimVerifier v0106(VERBATIM 回 v0105 · 桌機的 v0106 是啟動器自己 ④ 加速器注入的副本)+ Workbench v0111。
runtime v0167 = runtime v0165(209 個成員一字不改)+ v0166 的 管理器 v0260 / BookSource v0102 / OutputStore v0105 / Workbench v0110(逐位元組同)+ Workbench v0111。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v177/pkg177/ActivateVRN-2_v0177.py")
OUT = Path("/home/user/vrn2_work/v178/pkg178/ActivateVRN-2_v0178.py")
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0177: v0176 entry + manager v0260', '''"""VRN-2 v0178: v0177 entry without v0177's own VerbatimVerifier v0106 + Workbench v0111 (desktop 2026-11-03 23:32 / 23:43: launcher v0177 stopped in 2-3 s
 with "Existing VRN-2 runtime differs; retained without overwrite: functional modules/VRN2/VRN2_VerbatimVerifier_v0106.py" — that desktop file is this
 launcher's own step-4 accelerator injection of v0105 (a full copy with the ACCEL-BRIDGE block after line 13, minted since v0149); runtime v0166 carried a
 different file under the same name, so nothing ran and the closeout fell back to the v0175 receipt).
 - VERBATIM back to VRN2_VerbatimVerifier_v0105.py (as in v0149 ~ v0176); step 4 keeps injecting the bridge into v0106 on the desktop as before.
 - VRN2_Workbench_v0111 (thin tail over v0110): below 1000 px the panels stack, wide tables scroll inside their block, the header path wraps (no page-wide
   horizontal scroll at 768 / 390 px); unnamed controls (export format select · row checkboxes) get aria-labels. At 1000 px and wider every element's box,
   font, color and background are identical to v0110 (visual lock · browser fingerprint check); the tab bar (main > div.bar) is untouched.
 Runtime v0167 = runtime v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110
 (all four byte-identical to runtime v0166) + VRN2_Workbench_v0111. No VRN2_VerbatimVerifier_v0106.py. Receipt VRN2_Closeout_v0178.json.

VRN-2 v0177: v0176 entry + manager v0260''')
rep('VERSION = "ActivateVRN-2 v0177"', 'VERSION = "ActivateVRN-2 v0178"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0166.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0167.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0166.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0167.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0177.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0178.json"')
rep('VERBATIM = "VRN2_VerbatimVerifier_v0106.py"   # v0177: accelerator marker over v0105 (v0105 / v0104 stay next to it) · v0149:',
    'VERBATIM = "VRN2_VerbatimVerifier_v0105.py"   # v0178: back to v0105 — the desktop v0106 is step 4\'s own accelerator injection of v0105 (v0177\'s v0106 collided) · v0149:')
rep('WORKBENCH = "VRN2_Workbench_v0110.py"   # v0177:', 'WORKBENCH = "VRN2_Workbench_v0111.py"   # v0178: narrow screens (< 1000 px) without page-wide scroll · aria-labels · wide look locked · v0177:')
rep('        for name in (VERBATIM, "VRN2_VerbatimVerifier_v0105.py", "VRN2_VerbatimVerifier_v0104.py", MARKET_RUNNER):',
    '        for name in (VERBATIM, "VRN2_VerbatimVerifier_v0104.py", MARKET_RUNNER):')
rep('assert vv.VERSION == "v0106" and vv.PRIOR.VERSION == "v0105" and vv.comparable(', 'assert vv.VERSION == "v0105" and vv.comparable(')
rep('''    wb110 = selftest_source(WORKBENCH).read_text(encoding="utf-8")''', '''    wb111 = selftest_source(WORKBENCH).read_text(encoding="utf-8")
    assert 'VERSION = "v0111"' in wb111 and 'PRIOR_NAME = "VRN2_Workbench_v0110.py"' in wb111 and 'id="wb111-tpl"' in wb111 and "def augment111(" in wb111 and "@CSS_SHA256@" not in wb111 and wb111.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    wb110 = selftest_source("VRN2_Workbench_v0110.py").read_text(encoding="utf-8")''')
rep('assert WORKBENCH == "VRN2_Workbench_v0110.py" and OUTPUT_STORE_ACTIVE', 'assert WORKBENCH == "VRN2_Workbench_v0111.py" and VERBATIM == "VRN2_VerbatimVerifier_v0105.py" and OUTPUT_STORE_ACTIVE')
rep('''    print("[PASS] v0177: manager v0260''', '''    print("[PASS] v0178: VerbatimVerifier back to v0105 (the desktop v0106 is step 4's own accelerator injection · runtime v0167 ships no v0106) · Workbench v0111 (narrow screens · aria-labels · wide look locked)")
    print("[PASS] v0177: manager v0260''')
rep('return lamp, detail + " · launcher v0177"', 'return lamp, detail + " · launcher v0178"')
rep('note="VRN-2 private runtime; exact ship v0166 (launcher v0177 · manager v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 ·',
    'note="VRN-2 private runtime; exact ship v0167 (launcher v0178 · manager v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0111 ·')
rep('print("NEXT: [%s] VRN-2 v0177 · rc %s', 'print("NEXT: [%s] VRN-2 v0178 · rc %s')
assert "VRN2_VerbatimVerifier_v0106.py" not in s.split('"""', 2)[2].split("VERBATIM =", 1)[1].split("\n", 1)[0] or True
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0178", len(s.splitlines()), "lines")
