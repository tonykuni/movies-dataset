"""v0178(冪等):套件 VRN2_Closeout_v0178.zip(啟動器 v0178 · runtime v0167 = v0165 + v0166 的 管理器 v0260 / BookSource v0102 / OutputStore v0105 / Workbench v0110(逐位元組同)+ Workbench v0111 · 不帶 VerbatimVerifier v0106)
→ RoundAll v0134(填套件雜湊)→ Handle-All v0126(指到 v0134)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0178)。vrn2_release_v0177 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v178"); pkg, rel = W / "pkg178", W / "release178"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v177/release177")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0177/VRN2_Release_v0177.json").read_text(encoding="utf-8"))
r171 = json.loads((REPO / "vrn2_release_v0177/VRN2_Release_v0177.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0167.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0167.zip").read_bytes()).hexdigest() and rt["based_on"] == r170["runtime"]["based_on"]
assert rt["retained_members"] == 209 and rt["new_members"] == ["VRN_SystemManager_v0260.py", "VRN2_BookSource_v0102.py", "VRN2_OutputStore_v0105.py", "VRN2_Workbench_v0110.py", "VRN2_Workbench_v0111.py"]
assert not any(f["path"] == "VRN2_VerbatimVerifier_v0106.py" for f in rt["files"])
old = {c["path"]: c["sha256"] for c in r170["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0178.py", "VRN2_Runtime_v0167.zip", "VRN2_Runtime_v0167.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0178.py", "VRN2_Runtime_v0167.zip", "VRN2_Runtime_v0167.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0177 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0178 — VRN-2 closeout package (2026-11-04 · no own VerbatimVerifier v0106 · pre-flight name check · Workbench v0111)\n\n"
  "Entry: python ActivateVRN-2_v0178.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0134.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0126.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0167.zip = v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110\n"
  "(those four byte-identical to runtime v0166) + VRN2_Workbench_v0111. No VRN2_VerbatimVerifier_v0106.py.\n\n"
  "v0178 (desktop 2026-11-03 23:32 / 23:43: launcher v0177 stopped in 2-3 s — the desktop VRN2_VerbatimVerifier_v0106.py is the launcher's own step-4\n"
  "accelerator injection of v0105; runtime v0166 carried a different v0106, so the add-only install refused and nothing ran):\n"
  " - launcher v0178: VerbatimVerifier back to v0105 (step 4 keeps injecting v0106 as before) · runtime v0167 ships no v0106.\n"
  " - RoundAll v0134: before step 4 compares every runtime member with functional modules/VRN2 — same name, different bytes -> RED row with the names, launcher not started.\n"
  " - Workbench v0111: below 1000 px the panels stack, wide tables scroll inside their block, the header path wraps; unnamed controls get aria-labels;\n"
  "   at 1000 px and wider every element is identical to v0110 (visual lock).\n"
  "v0177: manager v0260 (page_NNNN[_hash].pdf out of the stock scope) · BookSource v0102 (1,234.50 / 23.45%) · OutputStore v0105 · Workbench v0110.\n"
  "Verification: see VRN2_Verification_v0178.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0178.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0178", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0178.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0178/" + n, date_time=(2026, 11, 4, 8, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0134.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0178"' in ra and 'VERSION = "v0134"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0178"' in ra
(rel / "VRN2_RoundAll_v0134.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0178'")
rep("$F = 'VRN2_RoundAll_v0133.py'", "$F = 'VRN2_RoundAll_v0134.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0125", "Handle-All v0126", ha.count("Handle-All v0125"))
rep("套件 v0177 裝在新夾 VRN2_Closeout_v0177", "套件 v0178 裝在新夾 VRN2_Closeout_v0178")
rep("改跑整輪(套件 v0177 起頁面分割檔不進個股範圍)", "改跑整輪(套件 v0178 · 管理器 v0260 起頁面分割檔不進個股範圍)")
rep("取套件 v0177 → 診斷 → 全部自測 → 跑啟動器 v0177(", "取套件 v0178 → 診斷 → 全部自測 → 先比套件與現役夾同名檔 → 跑啟動器 v0178(")
rep("Workbench v0110(左右同字級", "Workbench v0111(窄螢幕不溢出 · 可讀名稱 · 寬螢幕外觀不變 · 含 v0110 左右同字級")
rep("取套件 v0177 → ⑤ 自動修", "取套件 v0178 → ⑤ 自動修")
rep("· Workbench v0110 · 輸出冊 SOURCE", "· Workbench v0111 · 輸出冊 SOURCE")
rep("只重跑 ⑪ 獨立驗證(套件 v0177 的", "只重跑 ⑪ 獨立驗證(套件 v0178 的")
left = [l for l in ha.split("\n") if re.search(r"Handle-All v0125|v0133[.]py|release_v0177|套件 v0177|Closeout_v0177", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha and "$wasAuto -and $Mode -eq 'repair'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0177", "vrn2_release_v0178"), ("VRN2_HandleAll_v0125.md", "VRN2_HandleAll_v0126.md"), ("Handle-All v0125 SHA-256 OK", "Handle-All v0126 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0126_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0178/VRN2_HandleAll_v0126_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

gates = "$env:VIA_NET_CONSENT='YES';$env:VIA_SCRAPE_CONSENT='YES';" + tiny
assert all(ord(c) < 128 for c in gates) and len(gates) < 560
(rel / "tiny_gates_line.txt").write_text(gates + "\n", encoding="ascii", newline="\n")
md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0126(2026-11-04 · 撤回自製 VerbatimVerifier v0106 · ④ 前同名檢查 · Workbench v0111 · 套件 v0178 · RoundAll v0134)

桌機 2026-11-03 23:32 / 23:43 回報 → 做法:

| 回報 | v0178 |
|---|---|
| 啟動器 v0177 跑 2-3 秒就 rc 1 · 收尾「VRN-2 3 項」· 錯誤比上一輪多 | 根因:桌機 `functional modules\\\\VRN2\\\\VRN2_VerbatimVerifier_v0106.py` 是**啟動器自己 ④ 加速器注入**的 v0105 副本(v0149 起每輪都在)· v0177 的 runtime 又帶了另一支同名的 v0106 → 啟動器只增不覆寫 → 拒裝 → **主跑沒跑**(收尾沿用 v0175 收據 · 多出「④ 跑啟動器 紅」與「頁面分割檔 黃」)。v0177 的改善沒有遺失:⑬a BookSource v0102(千分位)· Workbench v0110 · 四點 / 主題與摘要 綠都已經在桌機上 |
| 修法 | 套件 v0178:啟動器 VERBATIM 回 v0105(④ 照舊注入 v0106)· runtime v0167 不帶 v0106 · 其他新模組跟 v0166 逐位元組相同(桌機已放的不衝突)|
| 不再發生 | RoundAll v0134:④ 前先比「套件 runtime 每個檔 vs 現役夾同名檔」· 同名不同內容 → 紅一列列出檔名 · 不跑啟動器(不用等它 2 秒失敗)· ④ 沒有 NEXT 行時帶出啟動器最後一行 [RED] |
| HTML U/I 視覺鎖定 · 其他優化可加 | Workbench v0111:**1000px 以上每個元件位置 / 大小 / 字級 / 顏色跟 v0110 完全相同**(瀏覽器逐元件比對 3,678 個)· 999px 以下:左右上下排 · 寬表格在區塊內捲動 · 頁首路徑斷行(平板 / 手機 0 橫向溢出)· 匯出格式選單 / 勾選框補可讀名稱 |
| 該閘一切你所須不須再問 | 下面「開閘一行」= 同一行前面加兩個同意閘(你貼 = 你開)· 閘開著 Handle-All 就不會停下來問 · ⑥f 共識改經 VIA 網路工具重抓 |

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0178/VRN2_Closeout_v0178.zip`(SHA-256 `%s` · 啟動器 v0178 · runtime v0167)|
| 一支 Python | `VRN2_RoundAll_v0134.py`(SHA-256 `%s` · 自測 107 項)|
| 自動選模式 | 上一輪收據還是 v0175(⑦ 沒跑完)→ **這次整輪**(Handle-All v0126 自動判斷)|

## PowerShell 7 視窗 · 開閘一行(%d 字元 · 建議)

```powershell
%s
```

## PowerShell 7 視窗 · 閘不動(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0126 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0134 `%s`)。

## cmd 視窗(%d 字元 · 閘不動)

```bat
%s
```

## 人工核對(看過原文之後 · 只有你打才算 · `--note` 後面寫你核對的結論)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0134.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0134.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(gates), gates, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0126.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0134.py(套件 v0178)

`VRN2_RoundAll_v0134.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0133 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0178/VRN2_Closeout_v0178.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0178 · runtime v0167(不帶 VerbatimVerifier v0106)|
| ④ 前同名檢查 | 套件 runtime 清單每個檔 vs `functional modules\\\\VRN2` 同名檔 · 同名不同內容 → 紅「④ 套件與現役夾同名不同內容」(列檔名 · 不跑啟動器 · 負責方 VRN-2)|
| ④ 沒有 NEXT 行 | 帶出啟動器最後一行 `[RED]`(v0177 的原因就在那行) |
| ③ 自測清單 | Workbench v0111(先跑 v0110 自測)· VerbatimVerifier 回 v0105 |
| 補放鏈 | Workbench v0111 → v0107 · 頁面沒有 wb111 標記 → 重渲染 |
| 自測 | 107 項(v0133 的 105 項 + 104 · 104b)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0134.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0178 (launcher v0178 · runtime v0167) + VRN2_RoundAll_v0134 + VRN2_HandleAll_v0126", "date": "2026-11-04",
        "trigger": "桌機 2026-11-03 23:32 / 23:43:啟動器 v0177 2-3 秒 rc 1(Existing VRN-2 runtime differs: VRN2_VerbatimVerifier_v0106.py)· 操作員:為何錯誤增加 · 是否改善又遺失 · HTML U/I 視覺鎖定但其他優化可加 · 整合 VIA Agent OS · 自動完成",
        "root_cause": "desktop functional modules/VRN2/VRN2_VerbatimVerifier_v0106.py = the launcher's own step-4 accelerator injection of v0105 (since v0149); runtime v0166 shipped a different v0106 → add-only install refused → launcher rc 1 in 2 s → closeout reused the v0175 receipt",
        "fixes": {"launcher_v0178": "VERBATIM back to v0105 · WORKBENCH v0111 · selftest 26",
                  "runtime_v0167": "v0165 (209) + v0260 / BookSource v0102 / OutputStore v0105 / Workbench v0110 byte-identical to v0166 + Workbench v0111 · no VerbatimVerifier v0106",
                  "Workbench_v0111": "thin tail over v0110 · CSS only inside @media (max-width:999px) · aria-labels · wide look locked (browser element fingerprint ≥ 1000 px identical) · 4-viewport audit pass · selftest 5",
                  "RoundAll_v0134": "pre-flight runtime-vs-folder name check before step 4 · last [RED] line when no NEXT line · selftest 107",
                  "HandleAll_v0126": "points to RoundAll v0134 · same mode rules · gate-open line variant in the md (operator pastes = operator opens)"},
        "package": {"name": "VRN2_Closeout_v0178.zip", "sha256": want, "release_folder": "vrn2_release_v0178", "changed": True, "launcher": "ActivateVRN-2_v0178.py"},
        "runtime": {"name": "VRN2_Runtime_v0167.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 209, "new_members": rt["new_members"], "same_bytes_as_v0166": rt["same_bytes_as_v0166"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0133.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-04; file kept in vrn2_release_v0177"}],
        "roundall": {"name": "VRN2_RoundAll_v0134.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0134.md"},
        "handleall": {"name": "VRN2_HandleAll_v0126.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0126_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "gates_line_chars": len(gates), "cmd_line_chars": len(cmd_line)},
        "version_check": "Workbench v0111 · runtime v0167 · launcher / package / receipt v0178 · RoundAll v0134 · HandleAll v0126 checked free on this branch and origin/main; VerbatimVerifier v0106 is the desktop's injected copy and is not shipped",
        "results": {"status": "see VRN2_Verification_v0178.md"}}
(rel / "VRN2_Release_v0178.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")

print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
