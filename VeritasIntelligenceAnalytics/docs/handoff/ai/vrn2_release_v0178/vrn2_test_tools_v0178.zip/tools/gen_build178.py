"""從 build177.py 生 build178.py(套件 v0178 · RoundAll v0134 · Handle-All v0126)。"""
import re
from pathlib import Path

s = Path("/home/user/vrn2_work/v177/build177.py").read_text(encoding="utf-8")
s = s[:s.index('md = """')]


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep(s.split('"""', 2)[1], "v0178(冪等):套件 VRN2_Closeout_v0178.zip(啟動器 v0178 · runtime v0167 = v0165 + v0166 的 管理器 v0260 / BookSource v0102 / OutputStore v0105 / Workbench v0110(逐位元組同)"
    "+ Workbench v0111 · 不帶 VerbatimVerifier v0106)\n→ RoundAll v0134(填套件雜湊)→ Handle-All v0126(指到 v0134)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0178)。vrn2_release_v0177 及更早不動。")
rep('W = Path("/home/user/vrn2_work/v177"); pkg, rel = W / "pkg177", W / "release177"', 'W = Path("/home/user/vrn2_work/v178"); pkg, rel = W / "pkg178", W / "release178"')
rep('PREV = Path("/home/user/vrn2_work/v176/release176")', 'PREV = Path("/home/user/vrn2_work/v177/release177")')
rep('(REPO / "vrn2_release_v0176/VRN2_Release_v0176.json")', '(REPO / "vrn2_release_v0177/VRN2_Release_v0177.json")', 2)
rep('(pkg / "VRN2_Runtime_v0166.json")', '(pkg / "VRN2_Runtime_v0167.json")')
rep('(pkg / "VRN2_Runtime_v0166.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0165.zip " + r170["runtime"]["zip_sha256"]',
    '(pkg / "VRN2_Runtime_v0167.zip").read_bytes()).hexdigest() and rt["based_on"] == r170["runtime"]["based_on"]')
rep('rt["retained_members"] == 209 and rt["new_members"] == ["VRN_SystemManager_v0260.py", "VRN2_BookSource_v0102.py", "VRN2_OutputStore_v0105.py", "VRN2_Workbench_v0110.py", "VRN2_VerbatimVerifier_v0106.py"]',
    'rt["retained_members"] == 209 and rt["new_members"] == ["VRN_SystemManager_v0260.py", "VRN2_BookSource_v0102.py", "VRN2_OutputStore_v0105.py", "VRN2_Workbench_v0110.py", "VRN2_Workbench_v0111.py"]\n'
    'assert not any(f["path"] == "VRN2_VerbatimVerifier_v0106.py" for f in rt["files"])')
rep('pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0177.py", "VRN2_Runtime_v0166.zip", "VRN2_Runtime_v0166.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",\n'
    '          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_VerbatimVerifier_v0106.py", "VRN2_OCRBridge_v0101.py"]',
    'pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0178.py", "VRN2_Runtime_v0167.zip", "VRN2_Runtime_v0167.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",\n'
    '          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]')
rep('    if n not in ("ActivateVRN-2_v0177.py", "VRN2_Runtime_v0166.zip", "VRN2_Runtime_v0166.json", "VRN2_VerbatimVerifier_v0106.py"):', '    if n not in ("ActivateVRN-2_v0178.py", "VRN2_Runtime_v0167.zip", "VRN2_Runtime_v0167.json"):')
rep("# 其他成員跟 v0176 逐位元組相同", "# 其他成員跟 v0177 逐位元組相同")
i0 = s.index('files["README.txt"] = ('); i1 = s.index('files["VALIDATION_RESULT.json"]')
s = s[:i0] + '''files["README.txt"] = ("VRN2_Closeout_v0178 — VRN-2 closeout package (2026-11-04 · no own VerbatimVerifier v0106 · pre-flight name check · Workbench v0111)\\n\\n"
  "Entry: python ActivateVRN-2_v0178.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0134.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0126.md (same release folder).\\n"
  "Runtime: VRN2_Runtime_v0167.zip = v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110\\n"
  "(those four byte-identical to runtime v0166) + VRN2_Workbench_v0111. No VRN2_VerbatimVerifier_v0106.py.\\n\\n"
  "v0178 (desktop 2026-11-03 23:32 / 23:43: launcher v0177 stopped in 2-3 s — the desktop VRN2_VerbatimVerifier_v0106.py is the launcher's own step-4\\n"
  "accelerator injection of v0105; runtime v0166 carried a different v0106, so the add-only install refused and nothing ran):\\n"
  " - launcher v0178: VerbatimVerifier back to v0105 (step 4 keeps injecting v0106 as before) · runtime v0167 ships no v0106.\\n"
  " - RoundAll v0134: before step 4 compares every runtime member with functional modules/VRN2 — same name, different bytes -> RED row with the names, launcher not started.\\n"
  " - Workbench v0111: below 1000 px the panels stack, wide tables scroll inside their block, the header path wraps; unnamed controls get aria-labels;\\n"
  "   at 1000 px and wider every element is identical to v0110 (visual lock).\\n"
  "v0177: manager v0260 (page_NNNN[_hash].pdf out of the stock scope) · BookSource v0102 (1,234.50 / 23.45%) · OutputStore v0105 · Workbench v0110.\\n"
  "Verification: see VRN2_Verification_v0178.md. Hashes: PACKAGE_SHA256.json.\\n").encode("utf-8")
''' + s[i1:]
s = s.replace("VRN2_Verification_v0177.md", "VRN2_Verification_v0178.md")
rep('manifest = {"system": "VRN-2", "version": "v0177",', 'manifest = {"system": "VRN-2", "version": "v0178",')
rep('zpr = rel / "VRN2_Closeout_v0177.zip"', 'zpr = rel / "VRN2_Closeout_v0178.zip"')
rep('zipfile.ZipInfo("VRN2_Closeout_v0177/" + n, date_time=(2026, 11, 4, 2, 0, 0))', 'zipfile.ZipInfo("VRN2_Closeout_v0178/" + n, date_time=(2026, 11, 4, 8, 0, 0))')
rep('(W / "new/VRN2_RoundAll_v0133.py")', '(W / "new/VRN2_RoundAll_v0134.py")')
rep("'PACKAGE = \"VRN2_Closeout_v0177\"' in ra and 'VERSION = \"v0133\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177\"' in ra",
    "'PACKAGE = \"VRN2_Closeout_v0178\"' in ra and 'VERSION = \"v0134\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0178\"' in ra")
rep('(rel / "VRN2_RoundAll_v0133.py").write_text(ra', '(rel / "VRN2_RoundAll_v0134.py").write_text(ra')
m0 = re.search(r'^rep\("\$P = ', s, re.M).start()
m1 = s.index("ha_line = join(ha)")
s = s[:m0] + '''rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0178'")
rep("$F = 'VRN2_RoundAll_v0133.py'", "$F = 'VRN2_RoundAll_v0134.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0125", "Handle-All v0126", ha.count("Handle-All v0125"))
rep("套件 v0177 裝在新夾 VRN2_Closeout_v0177", "套件 v0178 裝在新夾 VRN2_Closeout_v0178")
rep("改跑整輪(套件 v0177 起頁面分割檔不進個股範圍)", "改跑整輪(套件 v0178 · 管理器 v0260 起頁面分割檔不進個股範圍)")
rep("取套件 v0177 → 診斷 → 全部自測 → 跑啟動器 v0177(", "取套件 v0178 → 診斷 → 全部自測 → 先比套件與現役夾同名檔 → 跑啟動器 v0178(")
rep("Workbench v0110(左右同字級", "Workbench v0111(窄螢幕不溢出 · 可讀名稱 · 寬螢幕外觀不變 · 含 v0110 左右同字級")
rep("取套件 v0177 → ⑤ 自動修", "取套件 v0178 → ⑤ 自動修")
rep("· Workbench v0110 · 輸出冊 SOURCE", "· Workbench v0111 · 輸出冊 SOURCE")
rep("只重跑 ⑪ 獨立驗證(套件 v0177 的", "只重跑 ⑪ 獨立驗證(套件 v0178 的")
left = [l for l in ha.split("\\n") if re.search(r"Handle-All v0125|v0133[.]py|release_v0177|套件 v0177|Closeout_v0177", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha and "$wasAuto -and $Mode -eq 'repair'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
''' + s[m1:]
rep('("vrn2_release_v0176", "vrn2_release_v0177"), ("VRN2_HandleAll_v0124.md", "VRN2_HandleAll_v0125.md"), ("Handle-All v0124 SHA-256 OK", "Handle-All v0125 SHA-256 OK")',
    '("vrn2_release_v0177", "vrn2_release_v0178"), ("VRN2_HandleAll_v0125.md", "VRN2_HandleAll_v0126.md"), ("Handle-All v0125 SHA-256 OK", "Handle-All v0126 SHA-256 OK")')
rep('(rel / "VRN2_HandleAll_v0125_boot.txt")', '(rel / "VRN2_HandleAll_v0126_boot.txt")')
rep("vrn2_release_v0177/VRN2_HandleAll_v0125_boot.txt", "vrn2_release_v0178/VRN2_HandleAll_v0126_boot.txt")
s = s + Path("/home/user/vrn2_work/v178/build178_tail.py").read_text(encoding="utf-8") + '\nprint("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))\n'
Path("/home/user/vrn2_work/v178/build178.py").write_text(s, encoding="utf-8")
print("ok")
