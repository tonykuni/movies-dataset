const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const out = {};
  for (const w of [1440, 390]) {
    const ctx = await b.newContext({ viewport: { width: w, height: 900 } }); const p = await ctx.newPage();
    const ext = [], errs = [];
    p.on('request', r => { if (!/^(file|data|blob|about):/.test(r.url())) ext.push(r.url()); });
    p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
    await p.goto('file://' + process.argv[2]); await p.waitForTimeout(800);
    out[w] = await p.evaluate(() => ({ title: document.title, h1: document.querySelectorAll('h1').length, overflow: document.documentElement.scrollWidth - innerWidth, text: document.body.innerText.slice(0, 200) }));
    out[w].external = ext; out[w].errors = errs;
    if (process.argv[3]) await p.screenshot({ path: process.argv[3] + '/agentos_' + w + '.png', fullPage: false });
    await ctx.close();
  }
  await b.close(); console.log(JSON.stringify(out, null, 1));
})();
