"""runtime v0167 = runtime v0165(209 個成員逐位元組不動)+ runtime v0166 的 管理器 v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110(逐位元組 = v0166 · 桌機已放過的照原樣)
+ Workbench v0111(新)· 不含 VRN2_VerbatimVerifier_v0106.py(桌機那個名字是啟動器 ④ 加速器注入的 v0105 副本 · v0177 自製的同名檔撞上 → 啟動器 2 秒 rc 1)。
套件夾 pkg178 = pkg176 的輔助檔(啟動器 v0136 · ExecutionBridge / RunWithTools v0103 · VerbatimVerifier v0104 / v0105 · OCRBridge v0101)· 沒有 v0106。"""
import hashlib, json, shutil, zipfile
from pathlib import Path
P176, P177 = Path("/home/user/vrn2_work/v176/pkg176"), Path("/home/user/vrn2_work/v177/pkg177")
new, out = Path("/home/user/vrn2_work/v178/new"), Path("/home/user/vrn2_work/v178/pkg178")
om = json.loads((P176 / "VRN2_Runtime_v0165.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
assert hashlib.sha256((P176 / "VRN2_Runtime_v0165.zip").read_bytes()).hexdigest() == om["zip_sha256"] and len(old_names) == 209
with zipfile.ZipFile(P176 / "VRN2_Runtime_v0165.zip") as z:
    members = {n: z.read(n) for n in old_names}
m166 = json.loads((P177 / "VRN2_Runtime_v0166.json").read_text(encoding="utf-8"))
assert hashlib.sha256((P177 / "VRN2_Runtime_v0166.zip").read_bytes()).hexdigest() == m166["zip_sha256"]
keep166 = ["VRN_SystemManager_v0260.py", "VRN2_BookSource_v0102.py", "VRN2_OutputStore_v0105.py", "VRN2_Workbench_v0110.py"]
with zipfile.ZipFile(P177 / "VRN2_Runtime_v0166.zip") as z:
    for n in keep166:
        b = z.read(n)
        assert hashlib.sha256(b).hexdigest() == next(e["sha256"] for e in m166["files"] if e["path"] == n), n
        members[n] = b
assert "VRN2_VerbatimVerifier_v0106.py" not in members
members["VRN2_Workbench_v0111.py"] = (new / "VRN2_Workbench_v0111.py").read_bytes()
new_names = keep166 + ["VRN2_Workbench_v0111.py"]
names = sorted(members); zp = out / "VRN2_Runtime_v0167.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 4, 8, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0167", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0165.zip " + om["zip_sha256"], "retained_members": len(old_names),
       "new_members": new_names, "same_bytes_as_v0166": keep166, "not_shipped": {"VRN2_VerbatimVerifier_v0106.py": "the desktop's copy is the launcher's own accelerator injection of v0105 (step 4, since v0149); v0177 shipped a different file under the same name"},
       "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0167.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(str(P176 / n), str(out / n))
print("runtime v0167", len(names), man["zip_sha256"][:12], "· pkg178", sorted(p.name for p in out.iterdir()))
