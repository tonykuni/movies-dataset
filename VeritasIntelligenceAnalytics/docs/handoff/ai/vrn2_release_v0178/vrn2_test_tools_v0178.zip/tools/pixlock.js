// Visual lock proof: v0110 page vs v0111 page, every tab, at wide widths. Screenshots of this page are not byte-stable run to run (v0110 vs itself
// differs), so the proof is a layout fingerprint: every visible element's box (rounded px) + font-size + color + background + display.
// a vs a must match (control) and a vs b must match at widths >= 1000 px.
const { chromium } = require('playwright');
async function fingerprints(br, f, w) {
  const ctx = await br.newContext({ viewport: { width: w, height: 900 } });
  const p = await ctx.newPage();
  await p.goto('file://' + f); await p.waitForTimeout(900); await p.evaluate(() => document.fonts.ready);
  const n = await p.evaluate(() => document.querySelectorAll('.tabs button').length);
  const out = [];
  for (let i = 0; i < n; i++) {
    await p.evaluate(i => document.querySelectorAll('.tabs button')[i].click(), i); await p.waitForTimeout(450);
    out.push(await p.evaluate(() => {
      const rows = [];
      for (const el of document.querySelectorAll('body *')) {
        if (el.tagName === 'SCRIPT' || el.tagName === 'STYLE') continue;
        const r = el.getBoundingClientRect(); if (!(r.width > 0 && r.height > 0)) continue;
        const s = getComputedStyle(el); if (s.visibility === 'hidden') continue;
        rows.push([el.tagName, Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height), s.fontSize, s.color, s.backgroundColor, s.display].join('|'));
      }
      return rows;
    }));
  }
  await ctx.close();
  return out;
}
(async () => {
  const [, , a, b] = process.argv;
  const br = await chromium.launch();
  const res = [];
  for (const w of [1920, 1440, 1366, 1100, 1000, 999, 768]) {
    const fa = await fingerprints(br, a, w), fa2 = await fingerprints(br, a, w), fb = await fingerprints(br, b, w);
    const eq = (x, y) => x.length === y.length && x.every((t, i) => y[i] && t.length === y[i].length && t.every((v, j) => v === y[i][j]));
    const diffTabs = fa.map((t, i) => (fb[i] ? t.filter((v, j) => v !== fb[i][j]).length : -1));
    res.push({ width: w, tabs: fa.length, control_same: eq(fa, fa2), v0110_vs_v0111_same: eq(fa, fb), elements: fa.map(t => t.length), differing_rows_per_tab: diffTabs });
  }
  await br.close();
  const wide = res.filter(r => r.width >= 1000);
  console.log(JSON.stringify({ results: res, locked_at_1000_and_up: wide.every(r => r.control_same && r.v0110_vs_v0111_same), narrow_changes: res.filter(r => r.width < 1000).every(r => !r.v0110_vs_v0111_same) }, null, 1));
})();
