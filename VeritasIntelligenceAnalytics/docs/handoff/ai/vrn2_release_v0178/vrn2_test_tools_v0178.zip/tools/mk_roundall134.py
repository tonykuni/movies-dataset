"""VRN2_RoundAll_v0134.py = 本線 v0133(倉裡 vrn2_release_v0177)+ 套件 v0178(啟動器 v0178 · runtime v0167)+ ④ 前檢查「套件與現役夾同名不同內容」+ ④ 沒有 NEXT 行時帶出啟動器最後一行 [RED]。"""
import re
from pathlib import Path

REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0177/VRN2_RoundAll_v0133.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0133')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0133 — ', '"""VRN2_RoundAll v0134 — ', 1)
at = doc.index("v0133(")
doc = doc[:at] + '''v0134(桌機 2026-11-03 23:32 / 23:43:啟動器 v0177 跑 2-3 秒就 rc 1 ——「Existing VRN-2 runtime differs; retained without overwrite:
  functional modules\\\\VRN2\\\\VRN2_VerbatimVerifier_v0106.py」:桌機那支 v0106 是啟動器自己 ④ 加速器注入的 v0105 副本(v0149 起每輪都在),
  runtime v0166 卻帶了另一支同名的 v0106 → 啟動器只增不覆寫 → 拒裝 → 主跑沒跑 · 收尾沿用 v0175 收據):
  · 套件 v0178(啟動器 v0178 · runtime v0167 = v0165 的 209 個成員一字不改 + 管理器 v0260 / BookSource v0102 / OutputStore v0105 / Workbench v0110
    (跟 runtime v0166 逐位元組相同 · 桌機已放過的照原樣)+ Workbench v0111;不帶 VerbatimVerifier v0106 · 啟動器 VERBATIM 回 v0105)。
  · ④ 跑啟動器之前先比:套件 runtime 清單裡每個檔 vs VIA 的 functional modules\\\\VRN2 同名檔 —— 同名不同內容 → 紅「④ 套件與現役夾同名不同內容」
    (列檔名 · 這輪不跑啟動器 · 現役那支不動 · 負責方 VRN-2 換新版號);④ 沒有 NEXT 行 → 帶出啟動器最後一行 [RED](這次的原因就在那行)。
  · ③ 自測清單:Workbench v0111(先跑 v0110 自測)· VerbatimVerifier 回 v0105;補放鏈 Workbench v0111 → v0107;Workbench 頁沒有 wb111 標記 → 重渲染。
  · 自測 107 項(v0133 的 105 項 + 104 · 104b)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0133.py", "用法:python VRN2_RoundAll_v0134.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


b0 = s.index('VERSION = "v0133"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0177", "v0178").replace("VRN2_Runtime_v0166", "VRN2_Runtime_v0167")
s = pre + post
rep('VERSION = "v0133"', 'VERSION = "v0134"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0133.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0133.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0134.py"', n_dl)
rep('"VRN2_RoundAll_v0133.py" in html_', '"VRN2_RoundAll_v0134.py" in html_')
rep("· v0132 起 103 項 · v0133 起 105 項。", "· v0132 起 103 项 · v0133 起 105 項 · v0134 起 107 項。".replace("项", "項"))
rep('("VRN2_Workbench_v0110.py", 600)', '("VRN2_Workbench_v0111.py", 600)', s.count('("VRN2_Workbench_v0110.py", 600)'))
rep('("VRN2_VerbatimVerifier_v0106.py", 300)', '("VRN2_VerbatimVerifier_v0105.py", 300)', s.count('("VRN2_VerbatimVerifier_v0106.py", 300)'))
rep('WORKBENCH_CHAIN = ("VRN2_Workbench_v0110.py", "VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")   # v0133 v0110 · v0131',
    'WORKBENCH_CHAIN = ("VRN2_Workbench_v0111.py", "VRN2_Workbench_v0110.py", "VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")   # v0134 v0111 · v0133 v0110 · v0131')
rep("WB_MARK = 'id=\"wb110-tpl\"'", "WB_MARK = 'id=\"wb111-tpl\"'")
rep("WB_MARK == 'id=\"wb110-tpl\"'", "WB_MARK == 'id=\"wb111-tpl\"'", s.count("WB_MARK == 'id=\"wb110-tpl\"'"))
rep('WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0110.py"', 'WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0111.py"', s.count('WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0110.py"'))
rep('WORKBENCH_CHAIN[1:] == ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")', 'WORKBENCH_CHAIN[2:] == ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")')
rep('<style id="wb110-tpl"></style>', '<style id="wb110-tpl"></style><style id="wb111-tpl"></style>', s.count('<style id="wb110-tpl"></style>'))
# ── ④ 前:套件 runtime 與現役夾同名不同內容 ──────────────────────────────
rep('''def step_run(pkg: Path, root: Path, vpy: str, state: dict, args) -> int:
    if state.get("lock_alive"):''', '''def runtime_collisions(pkg, root) -> list:
    """v0134 ④ 前:套件 runtime 清單裡的檔 · VIA 的 functional modules\\\\VRN2 已有同名但內容不同 → 啟動器只增不覆寫會拒裝(桌機 v0177 就是 VerbatimVerifier v0106)。"""
    man = jread(Path(pkg) / RUNTIME_MANIFEST, {}) if pkg else {}
    folder = Path(root) / "functional modules" / "VRN2" if root else None
    out = []
    for e in (man or {}).get("files") or []:
        name = str(e.get("path") or "")
        p = folder / name if folder and name else None
        if p is None or not p.is_file():
            continue
        try:
            if sha256_file(p) != e.get("sha256"):
                out.append(name)
        except OSError:
            continue
    return out


def step_run(pkg: Path, root: Path, vpy: str, state: dict, args) -> int:
    hit = runtime_collisions(pkg, root)                                   # v0134 先比 · 不讓啟動器 2 秒就拒裝
    if hit:
        say("RED", "④ 套件與現役夾同名不同內容", "套件 runtime 有 %d 個檔跟 functional modules\\\\VRN2 同名但內容不同(%s)· 啟動器只增不覆寫 → 會拒裝 · 這輪不跑啟動器"
            % (len(hit), "、".join(hit[:4]) + (" …" if len(hit) > 4 else "")),
            "現役夾那支不動(常見:啟動器 ④ 加速器注入的副本)· 把貼回包給 AI → 出新版號的套件(不覆寫)")
        return 1
    if state.get("lock_alive"):''')
rep('''    nxt = next((l for l in reversed(lines) if l.startswith("NEXT:")), "")
    say({0: "GREEN", 2: "YELLOW"}.get(rc, "RED"), "④ 跑啟動器 " + LAUNCHER, "rc %s · %.0f 秒 · %s" % (rc, time.time() - t0, nxt[:200] or "(沒有 NEXT 行)"))''',
    '''    nxt = next((l for l in reversed(lines) if l.startswith("NEXT:")), "")
    red = next((l.strip() for l in reversed(lines) if "[RED]" in l), "") if not nxt else ""   # v0134 沒有 NEXT 行 → 原因多半在最後一行 [RED]
    say({0: "GREEN", 2: "YELLOW"}.get(rc, "RED"), "④ 跑啟動器 " + LAUNCHER, "rc %s · %.0f 秒 · %s" % (rc, time.time() - t0, nxt[:200] or ("(沒有 NEXT 行)" + (" · 最後一行 " + red[:220] if red else ""))))''')
# ── 自測 104 / 104b ─────────────────────────────────────────────────
rep('''        with tempfile.TemporaryDirectory() as td101c:''', '''        with tempfile.TemporaryDirectory() as td104:
            p104, r104 = Path(td104) / "pkg", Path(td104) / "VIA"
            (r104 / "functional modules" / "VRN2").mkdir(parents=True)
            p104.mkdir()
            files104 = {"VRN2_VerbatimVerifier_v0106.py": b"ours", "VRN2_Workbench_v0111.py": b"wb", "VRN2_New_v0100.py": b"new"}
            (p104 / RUNTIME_MANIFEST).write_text(json.dumps({"files": [{"path": k, "sha256": hashlib.sha256(v).hexdigest()} for k, v in files104.items()]}), encoding="utf-8")
            (r104 / "functional modules" / "VRN2" / "VRN2_VerbatimVerifier_v0106.py").write_bytes(b"desktop accelerator injection")
            (r104 / "functional modules" / "VRN2" / "VRN2_Workbench_v0111.py").write_bytes(b"wb")
            hit104 = runtime_collisions(p104, r104)
            mark104 = len(RESULTS)
            st104 = {"lock_alive": False}
            a104 = parse_args([])
            rc104 = step_run(p104, r104, sys.executable, st104, a104)
            rows104 = RESULTS[mark104:]
            del RESULTS[mark104:]
            own104 = owner_of(rows104[0], {"receipt": {"x": 1}}) if rows104 else None
        chk("104 v0134:④ 前比套件 runtime 與現役夾 —— 同名不同內容(桌機注入的 v0106)→ 列出 · 同內容 / 現役夾沒有 → 不算 · 紅一列 · 不跑啟動器 · 負責方 VRN-2",
            hit104 == ["VRN2_VerbatimVerifier_v0106.py"] and rc104 == 1 and len(rows104) == 1 and rows104[0]["lamp"] == "RED"
            and rows104[0]["step"] == "④ 套件與現役夾同名不同內容" and "VRN2_VerbatimVerifier_v0106.py" in rows104[0]["detail"] and own104 and own104[0] == "VRN-2")
        body104 = Path(__file__).read_text(encoding="utf-8")
        chk("104b v0134:套件 v0178(runtime v0167 不帶 VerbatimVerifier v0106)· 自測清單 Workbench v0111 / VerbatimVerifier v0105 · 補放鏈 Workbench v0111 → v0107 · ④ 沒有 NEXT 行帶出最後一行 [RED]",
            PACKAGE == "VRN2_Closeout_v0178" and RUNTIME_ZIP == "VRN2_Runtime_v0167.zip" and ("VRN2_Workbench_v0111.py", 600) in SELFTESTS
            and ("VRN2_VerbatimVerifier_v0105.py", 300) in SELFTESTS and not any("VerbatimVerifier_v0106" in n for n, _ in SELFTESTS)
            and WORKBENCH_CHAIN[:2] == ("VRN2_Workbench_v0111.py", "VRN2_Workbench_v0110.py") and WB_MARK == 'id="wb111-tpl"'
            and '"(沒有 NEXT 行)" + (" · 最後一行 " + red[:220] if red else "")' in body104)
        with tempfile.TemporaryDirectory() as td101c:''')
rep('''("VRN2_OutputStore_v0105.py", 300), ("VRN2_Workbench_v0111.py", 600), ("VRN2_VerbatimVerifier_v0105.py", 300))) and "font-size:12.5px" in CLOSEOUT_CSS_133''',
    '''("VRN2_OutputStore_v0105.py", 300), ("VRN2_Workbench_v0111.py", 600), ("VRN2_VerbatimVerifier_v0105.py", 300))) and "font-size:12.5px" in CLOSEOUT_CSS_133''')
Path("/home/user/vrn2_work/v178/new").mkdir(exist_ok=True)
Path("/home/user/vrn2_work/v178/new/VRN2_RoundAll_v0134.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0134", len(s.splitlines()), "lines")
