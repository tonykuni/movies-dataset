"""v0178 收尾:驗證紀錄 · 交接 v0179(從 v0178 抄 · 只增)· 收尾規格 §15(只增)· 詳細交接報告補 §8(同日 · 更正 v0106 一條)· 放進倉 vrn2_release_v0178 · logs / 工具 zip。
桌機 / 上傳資料不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v178"); rel = W / "release178"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"
TAG = "Transform investment reports into structured database intelligence."


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def last(p):
    return [l for l in lines(p) if l.strip()][-1]


R = json.loads((rel / "VRN2_Release_v0178.json").read_text(encoding="utf-8"))
H = R["handleall"]
ra = [l for l in lines(W / "rall134_selftest.log") if re.search(r"^\[FAIL\]|--selftest · ", l)]
assert ra and "· 不過 0" in ra[-1] and "107 項" in ra[-1], ra[-1:]
L = lines(W / "launcher178_selftest.log")
lsum = [l for l in L if l.startswith("[PASS] v0178")]
assert lsum and not [l for l in L if l.startswith("[FAIL]")] and sum(1 for l in L if l.startswith("[PASS]")) == 26
wb = last(W / "wb111_selftest.log")
assert "全過(5 項)" in wb, wb
ps = json.loads((W / "pscheck178.log").read_text())
by = {x["f"]: x for x in ps}
assert all(x["e"] == 0 for x in ps) and by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"] and by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"] and "tiny_gates_line.txt.ps1" in by
pparse = "pwsh 剖析錯 %s(含開閘一行)· Handle-All 一行 = 可讀版 · 開機行 = 可讀版" % sorted(x["e"] for x in ps)
mode = (W / "modetest_result.txt").read_text(encoding="utf-8").strip()
assert "bad=full" in mode and "good=repair" in mode and "datared=repair" in mode
rc = [l for l in lines(W / "tiny178.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
assert "[RED] boot SHA-256 mismatch - not run" in (W / "tiny_tamper.log").read_text(encoding="utf-8")
states = {n: json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
base = {n: json.loads(Path("/home/user/vrn2_work/v176/closeout_%s.json" % n).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
assert states["auto1"].get("VRN-2") == base["auto1"].get("VRN-2") and states["auto2"].get("VRN-2") == base["auto2"].get("VRN-2"), (states, base)
E = json.loads((W / "e2e178_check.json").read_text(encoding="utf-8"))
assert (E["scope_in_page_fragments"] == 0 and E["topic_rows_with_basis"] == E["topic_rows_new_number_format"] > 0 and E["store_no_double"] and E["workbench_v0111"]
        and E["header_line3"] == TAG and E["injected_v0106_kept"] and E["workbench_v0111_installed"] and E["collision_rows"] == 0 and int(E["launcher_ran_seconds"][0]) > 60), E
B = json.loads((W / "browser178.json").read_text(encoding="utf-8"))
bsum = {w: {"buttons_px": sorted({h for k in ("summary", "export", "handover", "data") for h in r[k]["hs"]}), "overflow": sum(len(r[k]["over"]) for k in ("summary", "export", "handover", "data")),
            "view_copy_rows": (r.get("viewCopy") or {}).get("rows"), "thousands": r["data"]["n2"][:2], "header_line3": r["summary"]["head"][2:], "tab_bar_px": sorted(set(r["summary"]["barH"])), "errors": r["errs"]} for w, r in B.items()}
assert all(v["overflow"] == 0 and v["buttons_px"] == [28] and not v["errors"] and v["view_copy_rows"] and v["header_line3"] == [TAG] and v["tab_bar_px"] == [27, 29] for v in bsum.values()), bsum
AU = json.loads((W / "audit_e2e.json").read_text(encoding="utf-8"))
assert AU["pass"]
audit = {r["viewport"]: {"overflow_px": r["pageOverflowPx"], "unnamed_controls": len(r["unnamedControls"]) + len(r["unnamedButtons"]), "tables_without_scroller": len(r["tablesWithoutScroller"]),
                         "console_errors": len(r["consoleErrors"]), "external_requests": len(r["external"])} for r in AU["results"]}
AB = json.loads((W / "audit_wb110.json").read_text(encoding="utf-8"))
before = {r["viewport"]: {"overflow_px": r["pageOverflowPx"], "unnamed_controls": len(r["unnamedControls"]), "tables_without_scroller": len(r["tablesWithoutScroller"])} for r in AB["results"]}
PL = json.loads((W / "pixlock_e2e.json").read_text(encoding="utf-8"))
assert PL["locked_at_1000_and_up"] and PL["narrow_changes"]
lock = {r["width"]: {"elements": sum(r["elements"]), "identical": r["v0110_vs_v0111_same"], "control_stable": r["control_same"]} for r in PL["results"]}
AOS = json.loads((W / "agentos_evidence.json").read_text(encoding="utf-8"))
LAMPS = json.loads((W / "lamps.json").read_text(encoding="utf-8"))
R["results"] = {"roundall_v0134_selftest": ra[-1:], "launcher_v0178_selftest": lsum + ["26 sections PASS"], "workbench_v0111_selftest": wb, "pwsh_parse": pparse, "handleall_mode_test": mode,
                "e2e_rc": rc, "closeout_per_owner": states, "closeout_vrn2_items_same_as_v0176_baseline": True, "e2e": E, "browser": bsum, "workbench_audit_4_viewports": {"v0110": before, "v0111": audit},
                "visual_lock_fingerprint": lock, "via_agent_os": AOS, "peer_lamps_read_only": LAMPS,
                "not_run": "the desktop itself · the operator's own --confirm (H-fd2ea35f) · VIA Agent OS bootstrap --apply on the desktop VIA root"}
(rel / "VRN2_Release_v0178.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0178 驗證紀錄(2026-11-04 · 撤回自製 VerbatimVerifier v0106 · ④ 前同名檢查 · Workbench v0111 · 套件 v0178 · RoundAll v0134 · Handle-All v0126)

## 1. 桌機回報 → 根因 → 做法

| 回報 | 根因 / 做法 |
|---|---|
| 桌機 11/03 23:32 / 23:43 兩次:啟動器 v0177 2-3 秒 rc 1 · 收尾「VRN-2 3 項」· 錯誤比上一輪多 | 啟動器印 `Existing VRN-2 runtime differs; retained without overwrite: functional modules\\\\VRN2\\\\VRN2_VerbatimVerifier_v0106.py`。桌機那支是**啟動器自己 ④ 加速器注入**的 v0105 副本(v0149 起每輪都在 · 檔頭照 v0105 · 第 13 行後多一段 ACCEL-BRIDGE)· v0177 的 runtime 卻帶了另一支同名 v0106 → 只增不覆寫 → 拒裝 → 主跑沒跑 · 收尾沿用 v0175 收據(⑦ 逾時那一輪)· 多出「④ 跑啟動器 紅」與「頁面分割檔 黃(算 VRN-2)」|
| 改善有沒有遺失 | 沒有:同一輪 ⑤ 自動修已在桌機套上 BookSource v0102(主題與摘要 42 列千分位)· Workbench v0110 · 四點 / 主題與摘要 綠 · 增量庫 Combined 521 列就地整理(0 列追加)|
| 為什麼 v0177 沒在容器抓到 | 第一次 e2e 其實抓到了(同一句錯誤)· 我誤判成「沙盒底版的草稿」而把沙盒那支刪掉 —— 錯在這裡。v0178 的 e2e **保留**注入版 v0106(= 桌機現況)|
| 修法 | 套件 v0178:啟動器 VERBATIM 回 v0105(④ 照舊注入 v0106)· runtime v0167 不帶 v0106 · 管理器 v0260 / BookSource v0102 / OutputStore v0105 / Workbench v0110 跟 v0166 逐位元組相同 · RoundAll v0134 ④ 前同名檢查 |

## 2. 測試

| 項目 | 結果 |
|---|---|
| Workbench v0111 自測 | %s |
| 啟動器 v0178 自測 | 26 段全過 · %s |
| RoundAll v0134 自測 | %s(新增 104 同名不同內容 → 紅 · 不跑啟動器 · 負責方 VRN-2;104b 套件 / 清單)|
| PowerShell | %s · 模式規則實跑:%s |
| e2e(最短一行 · 沙盒**保留注入版 v0106** + 先放桌機已補放的 v0166 成員)| %s · 啟動器 v0178 實跑 %s 秒(v0177 在同樣狀態 2 秒拒裝)· 注入版 v0106 原封不動:%s · 同名衝突列 %d |
| e2e 資料面 | 範圍夾分割頁 %d 份 · 主題與摘要新寫法 %d / %d 列 · %s · 頁首第三行:%s |
| 收尾負責方 | auto1 %s · auto2 %s(VRN-2 項 = v0176 基準 · 沙盒限定)|
| Workbench 4 視窗稽核(操作員給的跨裝置規格 · 頁寬 / 可讀名稱 / 表格捲動 / 主控台 / 外連)| v0110:%s → **v0111:%s** |
| 視覺鎖定(同一頁 v0110 vs v0111 · 每個元件 位置 · 大小 · 字級 · 顏色 · 背景)| %s |
| 前輪瀏覽器項目(1,366 / 1,100)| %s |

## 3. 他系統驗收燈(只讀 · 四系統對等 · 不代修)

%s

## 4. 桌機下一步

1. 貼 `vrn2_release_v0178/VRN2_HandleAll_v0126.md` 的**開閘一行**(前面兩個同意閘是你貼 = 你開 · Handle-All 就不會停下來問)—— 上一輪收據仍是 v0175(⑦ 沒跑完)→ 自動整輪。
2. 收尾頁看:「④ 跑啟動器」不再 2 秒 rc 1 · 「頁面分割檔」綠 · ⑦ 遠低於 7,200 秒 · ⑧ 有本輪完成判定。
3. MQ-1560:`python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0134.py" --confirm H-fd2ea35f --note "你核對的結論"`(只有你打才算)。
""" % (wb[:90], lsum[0][:120], ra[-1][:90], pparse, mode, " · ".join(rc), E["launcher_ran_seconds"][0], E["injected_v0106_kept"], E["collision_rows"],
       E["scope_in_page_fragments"], E["topic_rows_new_number_format"], E["topic_rows_with_basis"], E["store"][:150], E["header_line3"],
       json.dumps(states["auto1"], ensure_ascii=False), json.dumps(states["auto2"], ensure_ascii=False),
       json.dumps(before, ensure_ascii=False), json.dumps(audit, ensure_ascii=False), json.dumps(lock, ensure_ascii=False), json.dumps(bsum, ensure_ascii=False)[:400], LAMPS["summary_md"])
(rel / "VRN2_Verification_v0178.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0178.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


Ls = src.split("\n")
assert Ls[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0177 + VRN2_RoundAll_v0133 + VRN2_HandleAll_v0125 · 2026-11-04(")
Ls[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0178 + VRN2_RoundAll_v0134 + VRN2_HandleAll_v0126 · 2026-11-04(撤回自製 VerbatimVerifier v0106 · ④ 前同名檢查 · Workbench v0111 · VIA Agent OS)"
src = "\n".join(Ls)
once("> **本輪(v0177)**",
     "> **本輪(v0178)**:桌機跑 v0177 兩次都 2-3 秒 rc 1 —— runtime v0166 帶的 VerbatimVerifier v0106 跟桌機那支(**啟動器 ④ 加速器自己注入的 v0105 副本** · v0149 起)同名不同內容 → 只增不覆寫拒裝。"
     "**套件 v0178**:VERBATIM 回 v0105 · runtime v0167 不帶 v0106(其他新模組跟 v0166 逐位元組相同)· **RoundAll v0134** ④ 前比「套件 runtime vs 現役夾同名檔」· **Workbench v0111**(寬螢幕外觀鎖定 · 窄螢幕不溢出 · 可讀名稱)· "
     "**Handle-All v0126**(md 多一條開閘一行)。另:**VIA Agent OS v0100** 整合進 `supportive modules\\\\agent_os`(八個 Skill · 唯讀 AST · 自測 15 / 驗收 23 全過 · 見 via_agent_os_v0100)。\n"
     "> **本輪(v0177)**")
rows = ("| **VRN2_HandleAll_v0126.md**(發行夾 · 開閘一行 + 最短一行 + cmd 一行 + 開機行 · 不是 .ps1)| **v0126** | `vrn2_release_v0178` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0134)|\n"
        "| **VRN2_RoundAll_v0134.py**(發行夾 · 一支入口)| **v0134** | `vrn2_release_v0178` | `%s` | **新**(套件 v0178 · ④ 前同名檢查 · 自測 107)|\n"
        "| ActivateVRN-2_v0178.py(套件 · runtime v0167)| **v0178** | 見發行清單 | `%s` | **新**(VERBATIM 回 v0105 · WORKBENCH v0111)|\n"
        "| VRN2_Runtime_v0167.zip | **v0167** | 套件內 | `%s` | **新**(v0165 的 209 個 + v0166 的 4 個逐位元組同 + Workbench v0111 · **不帶 VerbatimVerifier v0106**)|\n"
        "| VRN2_Workbench_v0111.py(runtime · v0110 薄尾)| **v0111** | runtime v0167 | 見 runtime 清單 | **新**(CSS 全在 @media (max-width:999px) · aria-label)|\n") % (
    H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12],
    next(c["sha256"] for c in R["components"] if c["path"] == "ActivateVRN-2_v0178.py")[:12], R["runtime"]["zip_sha256"][:12])
once("| **VRN2_HandleAll_v0125.md**(發行夾", rows + "| **VRN2_HandleAll_v0125.md**(發行夾")
once("| 0 | **(v0177)**", "| 0 | **(v0178)** 貼 `vrn2_release_v0178/VRN2_HandleAll_v0126.md` 的開閘一行(這次自動整輪)→ 收尾頁「④ 跑啟動器」不再 2 秒 rc 1 · MQ-1560 `--confirm H-fd2ea35f`(操作員)| 貼回 / 人工 |\n| 0 | **(v0177)**")
once("**v0177(2026-11-04)**:", "**v0178(2026-11-04)**:撤回自製 VerbatimVerifier v0106(撞桌機 ④ 注入版)· runtime v0167 · RoundAll v0134(④ 前同名檢查)· Workbench v0111 · Handle-All v0126 · VIA Agent OS v0100 · VCGC registry-sync。\n\n**v0177(2026-11-04)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0178)** **啟動器 ④ 會自己出新版號**:現役夾裡沒有加速器標記的尾版 → ④ 注入 ACCEL-BRIDGE 寫成「下一號」(v0149 起 VerbatimVerifier v0105 → v0106;更早還有 Workbench v0106「accelfix copy」)。"
     "**出新模組前先查:前版有沒有標記?沒有 → 下一號已被桌機佔了**(跳過那個號)。這輪 v0177 就是撞在這裡。\n"
     "- **(v0178)** **沙盒底版就是桌機的鏡子**:e2e 第一次失敗時先問「桌機會不會也這樣」,不要為了讓測試過而改沙盒(v0177 把注入版 v0106 從沙盒刪掉 → 測試綠 · 桌機紅)。\n"
     "- **(v0178)** **已經發出去的 runtime 成員不要改位元組**:桌機可能已經放了(RoundAll ⑤ 補放 · 啟動器裝到一半)· 下一版要沿用就一字不改,要改就換新號。\n"
     "- **(v0178)** **版號**:本線下一版 Workbench v0112+ · RoundAll v0135+ · Handle-All v0127+ · runtime v0168+ · 啟動器 / 套件 / 收據 v0179+ · VerbatimVerifier **v0107+**(v0106 是桌機注入版)。\n\n")
(REPO / "VRN2_Handover_v0179.md").write_text(src, encoding="utf-8", newline="\n")

spec = (REPO / "VIA_Closeout_Spec_20261103.md").read_text(encoding="utf-8")
if "## 15. v0178 輪更新" not in spec:
    spec = spec.rstrip("\n") + "\n\n" + (W / "spec15.md").read_text(encoding="utf-8")
    (REPO / "VIA_Closeout_Spec_20261103.md").write_text(spec, encoding="utf-8", newline="\n")
dh = (REPO / "VRN2_DetailedHandover_20261104.md").read_text(encoding="utf-8")
wrong = "- 沙盒測試底版若有未發佈的同名檔(這輪碰到一份 v0106 草稿),先確認任何發行套件 / runtime 都沒有它,再在沙盒拿掉 —— 不改號、不覆蓋。"
if wrong in dh:
    dh = dh.replace(wrong, "- ~~沙盒測試底版若有未發佈的同名檔(這輪碰到一份 v0106 草稿)…在沙盒拿掉~~ **更正(v0178)**:那支 v0106 是啟動器 ④ 加速器注入的 v0105 副本,桌機也有 —— 沙盒要保留;撞號就換新號(見 §8)。")
if "## 8. v0178 補充" not in dh:
    dh = dh.rstrip("\n") + "\n\n" + (W / "detailed8.md").read_text(encoding="utf-8")
(REPO / "VRN2_DetailedHandover_20261104.md").write_text(dh, encoding="utf-8", newline="\n")

D = REPO / "vrn2_release_v0178"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0178.zip", "VRN2_RoundAll_v0134.py", "VRN2_RoundAll_v0134.md", "VRN2_HandleAll_v0126.md", "VRN2_HandleAll_v0126_boot.txt", "VRN2_Release_v0178.json", "VRN2_Verification_v0178.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 4, 8, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t178a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")) + (((str(W.parent), "<work>"),) if not name.startswith("tools/") else ()):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    if not name.startswith("tools/"):
        data = re.sub(rb"/home/user/[^\s'\"]*", b"<work>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0178.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall134_selftest.log", "launcher178_selftest.log", "wb111_selftest.log", "pscheck178.log", "modetest_result.txt", "tiny178.rc", "seed178.log", "sim178.log",
                              "confirm_list.log", "e2e178_check.json", "browser178.json", "audit_wb110.json", "audit_wb111.json", "audit_e2e.json", "pixlock.json", "pixlock_e2e.json",
                              "agentos_evidence.json", "lamps.json")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0178.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("runtime167.py", "mk_launcher178.py", "mk_roundall134.py", "gen_build178.py", "build178_tail.py", "build178.py", "finalize178.py", "e2e178.sh", "e2e178_check.py",
                              "wbaudit.js", "pixlock.js", "aoscheck.js", "new/VRN2_Workbench_v0111.py")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1"), Path("/home/user/vrn2_work/v177/browser177.js")] + \
             [rel / n for n in ("tiny_line.txt", "tiny_gates_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0179", src.count("\n"))
