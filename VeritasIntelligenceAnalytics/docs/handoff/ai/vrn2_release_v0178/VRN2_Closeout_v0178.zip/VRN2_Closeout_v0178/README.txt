VRN2_Closeout_v0178 — VRN-2 closeout package (2026-11-04 · no own VerbatimVerifier v0106 · pre-flight name check · Workbench v0111)

Entry: python ActivateVRN-2_v0178.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0134.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0126.md (same release folder).
Runtime: VRN2_Runtime_v0167.zip = v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110
(those four byte-identical to runtime v0166) + VRN2_Workbench_v0111. No VRN2_VerbatimVerifier_v0106.py.

v0178 (desktop 2026-11-03 23:32 / 23:43: launcher v0177 stopped in 2-3 s — the desktop VRN2_VerbatimVerifier_v0106.py is the launcher's own step-4
accelerator injection of v0105; runtime v0166 carried a different v0106, so the add-only install refused and nothing ran):
 - launcher v0178: VerbatimVerifier back to v0105 (step 4 keeps injecting v0106 as before) · runtime v0167 ships no v0106.
 - RoundAll v0134: before step 4 compares every runtime member with functional modules/VRN2 — same name, different bytes -> RED row with the names, launcher not started.
 - Workbench v0111: below 1000 px the panels stack, wide tables scroll inside their block, the header path wraps; unnamed controls get aria-labels;
   at 1000 px and wider every element is identical to v0110 (visual lock).
v0177: manager v0260 (page_NNNN[_hash].pdf out of the stock scope) · BookSource v0102 (1,234.50 / 23.45%) · OutputStore v0105 · Workbench v0110.
Verification: see VRN2_Verification_v0178.md. Hashes: PACKAGE_SHA256.json.
