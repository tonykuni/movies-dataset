#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VRN-2 v0178: v0177 entry without v0177's own VerbatimVerifier v0106 + Workbench v0111 (desktop 2026-11-03 23:32 / 23:43: launcher v0177 stopped in 2-3 s
 with "Existing VRN-2 runtime differs; retained without overwrite: functional modules/VRN2/VRN2_VerbatimVerifier_v0106.py" — that desktop file is this
 launcher's own step-4 accelerator injection of v0105 (a full copy with the ACCEL-BRIDGE block after line 13, minted since v0149); runtime v0166 carried a
 different file under the same name, so nothing ran and the closeout fell back to the v0175 receipt).
 - VERBATIM back to VRN2_VerbatimVerifier_v0105.py (as in v0149 ~ v0176); step 4 keeps injecting the bridge into v0106 on the desktop as before.
 - VRN2_Workbench_v0111 (thin tail over v0110): below 1000 px the panels stack, wide tables scroll inside their block, the header path wraps (no page-wide
   horizontal scroll at 768 / 390 px); unnamed controls (export format select · row checkboxes) get aria-labels. At 1000 px and wider every element's box,
   font, color and background are identical to v0110 (visual lock · browser fingerprint check); the tab bar (main > div.bar) is untouched.
 Runtime v0167 = runtime v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110
 (all four byte-identical to runtime v0166) + VRN2_Workbench_v0111. No VRN2_VerbatimVerifier_v0106.py. Receipt VRN2_Closeout_v0178.json.

VRN-2 v0177: v0176 entry + manager v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110 + VerbatimVerifier v0106 (desktop 2026-11-03 22:28:
 the full run stopped at ⑦'s 7200-second cap — the picked source folder held 60 reports and 200 page_NNNN[_hash].pdf single pages split out of other files;
 operator: 「數字小數點兩位要有千分位號 · 左右面板字體大小一致 · 按鍵高度要一致 · 矩陣化 · 第二圖超出格子 · 擷取特定資料 · 特定日期 → 檢視副本 ·
 ps py 都要加加速器 · 覆蓋率 100%」).
 - manager VRN_SystemManager_v0260 (thin tail over v0259): page_NNNN[_hash].pdf (a page split out of another file, not a whole report) joins the
   non-stock filename rule vrn2scope reads → it stays in the source folder, is not copied to scope_in (earlier copies leave it), one line counts it.
 - ⑬a VRN2_BookSource_v0102 (thin tail over v0101): TOPIC & SUMMARY numbers as 1,234.50 (thousands separators · two decimals) and the upside as 23.45%;
   numeric book columns stay as they are.
 - ⑬ VRN2_OutputStore_v0105 (thin tail over v0104 · same behaviour): its self-test runs v0104's scenarios with the BookSource they were written for and
   adds the v0101 → v0102 switch (0 rows appended · stored rows tidied to the new number format).
 - VRN2_Workbench_v0110 (thin tail over v0109): header line 3 = "Transform investment reports into structured database intelligence." · left and right panels on the same 10.45 px · every button 28 px high · card values wrap and shrink to fit
   (03 page receipt name) · left-panel counts and output folder as matrices · 04 handover snapshot as a matrix · two-decimal numbers shown with
   thousands separators · 「檢視副本」 opens a read-only copy of the extract filter (book · dates · keyword) · the tab bar (main > div.bar) untouched.
 - VRN2_VerbatimVerifier_v0106 (thin tail over v0105): accelerator marker (the one active VRN-2 module without it) · comparison unchanged.
 Runtime v0166 = runtime v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110 + VRN2_VerbatimVerifier_v0106.
 Receipt VRN2_Closeout_v0177.json.

VRN-2 v0176: v0175 entry + ⑬a BookSource v0101 + OutputStore v0104 (operator 2026-11-03: "四點摘要前面出現任何標點符號如 ➢ 則刪除 · 第一點通常為評價,
 採取每日更新後的 ADJ 目標價 · ADJ CLOSE 來計算上漲空間 · 標題格式 Name(YFinance Ticker, 評等) - 原文標題").
 - ⑬a VRN2_BookSource_v0101 (thin tail over v0100 · v0100 unchanged): Summary TITLE / POINT_1 ~ POINT_4 lose their leading bullets / punctuation / numbering
   (➢ • ⚫ ● ■ ▶ → - * · (1) ① 1、 …) and nothing else (the verbatim check still finds every point); Combined "TOPIC & SUMMARY" becomes
   "Name(YFinance Ticker, 評等) - 原文標題 · 評價 · 點 · 點 · 點": the valuation point (目標價 / 上漲空間 / 評等 / target / upside / rating …) goes first and its upside is
   recomputed from the daily TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1 with the basis appended (調整後目標價 X ÷ 調整後收盤 Y = 上漲空間 Z%); no valuation point → one is
   added as point 1 (still four points); a missing adjusted price → numbers untouched (order only). JSON / CSV / Parquet alike, idempotent, receipt summary_cleanup.
 - ⑬ VRN2_OutputStore_v0104 (thin tail over v0103): the row hash strips the same leading symbols from Summary rows and ignores Combined TOPIC & SUMMARY (derived from
   hashed columns), so the cleaned books are not appended again; old store rows are tidied in place (DuckDB file copied first · rowid update · affected run partitions
   moved to _summary_tidy_<time>/ and rewritten · restore-fill --folder). A changed ADJ_CLOSE still appends a new Combined row (the daily upside is history).
 Runtime v0165 = runtime v0164 (207 members byte-identical) + VRN2_BookSource_v0101 + VRN2_OutputStore_v0104. Receipt VRN2_Closeout_v0176.json.

VRN-2 v0175: v0174 entry + ⑬a book Source / Broker columns + OutputStore v0103 + Workbench v0109 (operator 2026-11-03: "BROKER 一律用英文縮寫 · 輸出冊和增量庫也實體加
 Source 欄 · 字型字級以細節 / Detail 為準 · 資料驗證狀況放入系統摘要 · 所有資訊矩陣化燈號化 · 表頭統一 · 左面板步驟編號 · 說明放底下 · 全形標點").
 - ⑬a VRN2_BookSource_v0100 (new · runs after ⑬b, which rewrites FinancialAligned / Deleted, and before ⑬): BROKER_EN (English broker abbreviation, candidate table
   pending VCGC; unmapped → blank + listed in the receipt) and SOURCE (歷史 TWSE/TPEX · 報告預估 · 報告實際 · 報告 …, same rule as Workbench v0108) are written as the
   last two columns of BasicInfo · FinancialData · Summary · Combined · Rejected · FinancialAligned · Deleted (JSON keeps its indent · CSV keeps BOM / CRLF · Parquet keeps
   column types; every other value byte-identical; unchanged → not rewritten). MarketConsensus keeps its own SOURCE column. Never RED; VIA_VRN2_NO_BOOKSOURCE=1 opts out.
 - ⑬ VRN2_OutputStore_v0103 (thin tail over v0102): the row hash ignores SOURCE / BROKER_EN, so books that gained the two columns are not appended again; rows already in
   the store get the two columns filled in place from their own fields (DuckDB file copied first · affected run partitions moved to the backup and rewritten · restore-fill).
 - VRN2_Workbench_v0109 (thin tail over v0108): text font = the Detail column's Consolas + Microsoft JhengHei 10.45 px; 00 tab renamed 系統摘要 with the verification
   lamps as a matrix (status · item · detail) and a consensus matrix (FactSet 目標價中位數 · FactSet 分析師人數 …); 04 acceptance list → matrix; headers English line +
   Chinese line everywhere; parenthetical notes moved under the card; full-width punctuation beside Chinese; left panel as numbered steps; input classification matrix
   (stock report · non-stock report · news · page image · unclassified × PDF / Word / TXT / image); physical SOURCE / BROKER_EN used when present (no duplicate column).
 Runtime v0164 = runtime v0163 (204 members byte-identical) + VRN2_BookSource_v0100 + VRN2_OutputStore_v0103 + VRN2_Workbench_v0109. Receipt VRN2_Closeout_v0175.json.

VRN-2 v0174: v0172 entry + Workbench v0108 (operator 2026-11-03: "Ticker / YFinance 同步顯示 · 代號下一欄接 Name · Broker 英文縮寫 · 報告日左邊加時效欄
 (法定財報日之前或超過 30 個交易日 → 過期)· ENG049 對帳頁當靜態視覺模板 · 字體大小與顏色一致且鎖定 · 期間 YYYY / YYYY-MM / YYYY-MM-DD · 所有資料最後加 Source").
 - VRN2_Workbench_v0108 (thin tail over v0107 · v0107 and its dynamic prior unchanged): one locked CSS block taken from the VRN_ENG049_ContentReconcile v0102
   reconcile page (15 colours · font sizes 19 / 11 / 9.5 / 9 / 8 px · Microsoft JhengHei / Cormorant Garamond / Consolas · SHA-256 pinned in the module) laid over
   the whole Workbench (left panel · header · tabs · cards · matrices · 00 summary · the v0107 blocks); a display layer injected into the page script for the
   data tab: Freshness / 時效 column left of Report Date (before the latest statutory filing deadline 3/31 · 5/15 · 8/14 · 11/14, or more than 30 trading days old
   → 過期; trading days = Mon–Fri minus VDF's TW holiday list, read with ast · VDF untouched), TICKER shown as "Ticker / YFinance" with Name right after it,
   broker English abbreviations (candidate table pending VCGC), periods and dates as YYYY / YYYY-MM / YYYY-MM-DD, and a final Source column (歷史 TWSE/TPEX ·
   報告預估 · 報告實際 · 報告 …). window.VRN2_DATA stays byte-identical to the output books; every export keeps the book values and appends SOURCE as the last column.
 Runtime v0163 = runtime v0162 (203 members byte-identical) + VRN2_Workbench_v0108.
 Receipt VRN2_Closeout_v0174.json. Launcher number v0173 is skipped (release folder v0173 only replaced RoundAll; there is no launcher v0173).

VRN-2 v0172: v0170 entry + HistoryAlign v0103 + ConsensusJoin v0107 + Workbench v0107 (operator 2026-11-03: "新增小數欄,舊欄保留並標註,三項一起修 · 授權依建議最佳化完成";
 the three VRN P0 findings F1 / F2 / F3 were confirmed on the desktop 15:18 receipts).
 - F1 VRN2_HistoryAlign_v0103 (thin tail over v0102 · v0102 ~ v0100 unchanged): v0100's _write_books turns None into "" so a numeric column also holds strings
   and pyarrow refuses the whole FinancialAligned Parquet (ArrowInvalid · JSON / CSV were fine, 11,905 rows). v0103 lets the prior write first and only when the
   Parquet is "(沒寫…" rewrites it typed: all-number columns → float64 with null for empty (never 0 / ""), all-string → string, truly mixed → whole column as string;
   it reads the file back (row count · column names) before replacing, otherwise it reports not-written honestly. The receipt gains written[...].parquet_typed.
 - F2 VRN2_ConsensusJoin_v0107 (thin tail over v0106): Combined gains UPSIDE_ADJ (pure ratio · TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1 · 9 decimals) right after the
   old UPSIDE_PCT(ADJ) (percent · kept, meaning unchanged, annotated as the old column); output/VRN2_Combined_columns_latest.json documents unit / definition /
   old-or-new for both. Values come from the market book's upside_adj; a filled cell is never overwritten. The store adds the column via ALTER TABLE (old rows NULL).
 - F3 VRN2_Workbench_v0107 (self-contained post-processing tail · skips v0105 and the desktop accelfix copy v0106 so nothing is applied twice · carries the
   accelerator marker on line 3): "Basic Info · 合併檢視" puts the verbatim Basic Info book (NAME 23/52 · ADJ_CLOSE 0/52 on the desktop, by design) next to the
   merged Combined book (51/52) per report — verbatim values tagged 原, Combined fills tagged 合 with the source on hover; neither book is modified. Upside is
   shown from UPSIDE_ADJ × 100; three more verification lamps (Basic merge · new-vs-old upside cross-check · history-align Parquet); column notes on hover.
 Runtime v0162 = runtime v0160 (200 members byte-identical) + VRN2_HistoryAlign_v0103 + VRN2_ConsensusJoin_v0107 + VRN2_Workbench_v0107.
 Receipt VRN2_Closeout_v0172.json. Launcher number v0171 is skipped (release folder v0171 only replaced RoundAll; there is no launcher v0171).

VRN-2 v0170: v0168 entry + Workbench v0105 + ConsensusJoin v0106 (operator 2026-11-02: "開閘共識欄 · 要有共識資料 · Workbench 面板緊湊 / 字體比頁首略小 / 有底色的字白色 / 矩陣欄寬自動 / 紅黃綠資料驗證燈").
 - VRN2_Workbench_v0105 (dynamic-prior thin tail: on the desktop it chains the locally newer v0104, in this repo's runtime it chains v0102; the prior
   renders first and v0105 only post-processes the written page): a CSS override block (compact panels · largest panel font 17px < header h1 20px ·
   solid-background badges in white text · auto table column widths with sticky headers) plus two self-contained panels injected at the top of <main> —
   "資料驗證狀況" (one red / yellow / green / gray lamp per receipt: verbatim verify · independent verify · idempotence · completion · market 6e ·
   consensus 6f · history align 13b · incremental store 13 · Combined consensus columns) and "共識資料" (FactSet × Yahoo target-median matrix;
   snapshot rounds show a red ASOF badge so reused data is never presented as fresh).
 - VRN2_ConsensusJoin_v0106 (thin tail over v0105 · v0105 ~ v0100 unchanged): when the consent gate is CLOSED (net_deny.gate_closed) and the engine
   pass produced nothing (per_code empty), reuse the newest on-disk consensus snapshot consensus/factset_yfinance_consensus_matrix.csv (the engine's
   last successful matrix) to fill per_code, so the Combined consensus columns are populated offline; the receipt records snapshot_reused{asof ·
   source · codes} and the why starts with 快照補位(ASOF …). A compliance DENY (VCGC's call) is never backfilled; VIA_VRN2_NO_SNAPSHOT=1 turns it off.
   The gate itself stays operator-only: nothing here sets VIA_NET_CONSENT / VIA_SCRAPE_CONSENT, and an open-gate round still fetches fresh data.
 Runtime v0160 = runtime v0159 (198 members byte-identical) + VRN2_Workbench_v0105 + VRN2_ConsensusJoin_v0106.
 Receipt VRN2_Closeout_v0170.json. Launcher number v0169 is skipped (release folder v0169 only replaced RoundAll; there is no launcher v0169).

VRN-2 v0168: v0166 entry + manager VRN_SystemManager_v0259 (transposed tables asked again with the third reader's touching number fragments joined).
Operator 2026-11-02 uploaded 華南投顧-6143-振曜-1141128.pdf (the last "output books missing annual data"): page 1 prints the annual table (years as rows
2022 – 2026(F) · 8 items) = 40 values; v0236's third-reader gate (pdfplumber) rejected the whole table because a stray space glyph from another font lies
across 「3.0」 in the 2026(F) row and pdfplumber splits it into 「3」+「.0」 (the glyphs touch). v0259 asks the same gate again for such rows with
touching number fragments joined (gap ≤ 0.5 pt · decimal / thousands separator · result is a number); a passing table returns to the annual book.
 Real original: 40 / 40 values back · independent verifier TRANSALIGNED 40. Runtime v0159 = runtime v0158 (197 members byte-identical) + v0259.
 Receipt VRN2_Closeout_v0168.json. Launcher number v0167 is skipped (release folder v0167 only replaced RoundAll; there is no launcher v0167).

VRN-2 v0166: v0164 entry + manager VRN_SystemManager_v0258 (table repair before the books). Operator 2026-11-01 uploaded the originals of the
reports the closeout listed as "output books missing annual data" (human item H-275f449a): both print annual tables, the books dropped them.
 - 欣銓(3264) CTBC page 5: each item name is printed ~3 pt below its numbers → the engine stores a value-only row and a label-only row; the books
   skipped both (not even in the Rejected book). v0258 merges them only when the second reader prints that label and that annual number sequence on
   one line (unique) · label pieces split over cells are joined.
 - Daiwa-6278 page 2: a year banner above the real period header → cells with 3-5 numbers ("一格多值"). v0258 re-grids on the real header row:
   the second reader must find that header line once and each data row once (item + same numbers); each number goes to the nearest header label
   (one-to-one · in order · within 0.4 column gap); a row it cannot place goes to the Rejected book with the reason.
 Every repaired value still passes the second-reader column check, the third-reader gate, one-row-one-item and the independent verifier (step 11).
 Real originals: 3264 → 225 annual values · 6278 → 30 · independent verifier 685 / 685 ALIGNED; v0257 output kept (nothing removed).
 Runtime v0158 = runtime v0157 (196 members byte-identical) + VRN_SystemManager_v0258. Receipt VRN2_Closeout_v0166.json.
 Launcher number v0165 is skipped (release folder v0165 only replaced RoundAll; there is no launcher v0165).

VRN-2 v0164: v0163 entry + the operator decisions of 2026-11-01 ("Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原
才有可比較性 · 兩個單位所算的目標價中位數並存方便比較 · 最後把他跟 TWSE / TPEX 輸出格式一樣再合併").

 - step 6f VRN2_ConsensusJoin_v0105 (thin tail over v0104 · v0104 ~ v0100 unchanged):
   * TARGET_PRICE(ADJ) synchronous adjustment: when MarketFetch left it MISSING, the VDF daily partitions in VRN-2's own output folder are read (read-only):
     VDF-adjusted day before the report → adj_close / close; CLOSE_MISMATCH with a Yahoo/TWSE close ratio that is constant before the report and back to
     MATCH later (Yahoo's retroactive split / stock-dividend adjustment) → Yahoo adj close / TWSE close; anything else stays MISSING with the real reason.
     TARGET_PRICE(ADJ) · ADJ_CLOSE_BEFORE_REPORT · UPSIDE_PCT(ADJ) use one factor; evidence market/VRN2_TPAdjSync_latest.json (+ VDF status.json and
     per-ticker MISMATCH counts = the anchor of "6e fetch YELLOW · 0 failures", i.e. VDF rc 2 PARTIAL). MarketFetch's market JSON is not modified.
   * FACTSET_TARGET_PRICE_MEDIAN and YFINANCE_TARGET_PRICE_MEDIAN stay side by side (Combined column order unchanged).
   * consensus written in the TWSE / TPEX (VDF) output format under consensus/dataset (identity prefix date · ticker · yfinance_ticker · bloomberg_ticker · name ·
     key [date, ticker] · parquet/<ds>/ticker=/year=/data.parquet + <ds>.parquet + upper-case CSV): tw_consensus · tw_consensus_estimate, then merged with
     the TWSE / TPEX daily rows (as-of the consensus day) = tw_market_consensus + output/VRN2_MarketConsensus_latest.
 - step 13 VRN2_OutputStore_v0102 (thin tail over v0101): before every sync the long-term store drops rows computed from MOPS history
   (Deleted: all · FinancialAligned: every (run_id, file_sha) group carrying a history marker) after copying the DuckDB file (or the touched run files)
   into <out>/VRN2/_mops_purge_<stamp> (restore-purge puts it back); such rows are never appended again (mops_skipped); new book MarketConsensus.
 - SSOT proposals v0101 (VRN2_SSOT_Proposals_v0101.json = v0100's 9 entries + this round's 8 rules · ssot_id blank): step 5b (SSOTSync v0101, unchanged) sends them
   in the number request; VCGC conflict-tests and grants the numbers; apply fills them in. VRN2_SSOTSync_v0102 only isolates v0101's selftest.
 Runtime v0157 = runtime v0156 (192 members byte-identical) + VRN2_ConsensusJoin_v0105 + VRN2_OutputStore_v0102 + VRN2_SSOTSync_v0102 + VRN2_SSOT_Proposals_v0101.json.
 Receipt VRN2_Closeout_v0164.json.

VRN-2 v0163: v0158 entry + step 6e never touches MOPS (operator 2026-10-31 "不可用 MOPS · 全部國內使用 TWSE TPEX").

 - step 6e: the shared VRN2_MarketFetch --fetch always gets --no-financial, so the borrowed VDF engine is never asked for MOPS financial
   statements (its financial dataset reads mopsov.twse.com.tw); prices / indices / universe stay on the official TWSE / TPEX lanes.
 - financial statements already written by earlier runs (market/vdf/parquet/tw_financial, market/vdf/tw_financial.parquet) came from MOPS:
   they are moved (not deleted) to market/vdf/_mops_quarantine_<stamp> before the fetch, so --fill and step 13b no longer read them.
 - the shared MarketFetch and the VDF engine are read-only for VRN-2 (only the arguments VRN-2 passes and VRN-2's own output folder change).
 Runtime v0156 is used unchanged. Receipt VRN2_Closeout_v0163.json.

VRN-2 v0158: v0157 entry + step 3b (OCR isolated environment) follows the same rule (operator 2026-10-31 "依照你的建議進行").

 - step 3b: an OCR environment that is already set (VIA_VRN2_OCR_PY + VIA_VRN2_OCR_BRIDGE) or ready (envs/vrn2_ocr imports
   rapidocr_onnxruntime / rapidocr and wordninja) is used as before. Not ready -> this entry no longer creates the venv or pip-installs
   into it (the base did, with numpy>=1.24,<2.0); the step is YELLOW with the exact commands for VCGC to build it, and OCR stays queued.
   VCGC's install gate installs into the calling Python only (pip --user), so it cannot fill another venv; the isolated environment is
   handed to VCGC the same way as via_tw_fetch. --pip-install / VIA_VRN2_PIP_INSTALL=1 keeps the old behaviour (operator's choice only).

v0157: v0156 entry + the operator decision of 2026-10-31 ("預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝").

 - step 3 (environment check): the manager's envcheck runs check-only (the base still asks for --install; this entry drops it, so the
   manager no longer pip-installs into this Python with its numpy>=1.24,<2.0 constraint). Each missing package goes through VCGC's
   install gate supportive modules/registry/CGC_MDL056_InstallGate (highest version, the one VCGC EnvGovernance picks): pip check before /
   after, VIA_Lib_Registry entry, import smoke, SuperAccel install lane behind VIA_NET_CONSENT. One package per call; a package the gate
   could not install is not retried for 24 h (VIA_Reports/vrn2/VRN2_VCGCInstall_latest.json · VIA_VRN2_INSTALL_RETRY=1 retries); then
   envcheck runs again (check-only) and its result decides the lamp as before. --no-install / --plan: check only, no gate call.
   --pip-install or VIA_VRN2_PIP_INSTALL=1 restores the old in-place pip (operator's explicit choice).
 Runtime v0156 is used unchanged (manager / engines / ConsensusJoin not touched).

v0156: v0154 entry + the operator request of 2026-10-31 ("新版有版本號 · 加速器跟網路工具最新版都有版本號 · 直接透過 VCGC 的環境工具管理引擎
 下載所有不足工具及環境並確認無衝突 · 改成經網路工具和加速器出網再抓"). v0155 was the RoundAll-only round (no launcher v0155).

 - step 6f VRN2_ConsensusJoin_v0104 (thin tail over v0103): the bundled consensus engine is now
   VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122 (v0121 + every outbound request through the VIA network tool
   SUP_MDL740_NetUnified, highest version, core = locked AegisNexus v1652; accelerator bridge = highest VeritasCeleritas):
   cnyes -> http_bytes lane, YFinance -> yahoo_quote_summary_raw lane (no yfinance package). The network tool's double consent gate
   (VIA_NET_CONSENT / VIA_SCRAPE_CONSENT) is the operator's; closed -> the engine stops before fetching, ⑥f YELLOW with net_deny
   (never retried through another transport, never set by VRN-2). Today's checkpoint fetched by the direct engine v0120 + gate open ->
   archived with the engine's own function and fetched again through the network tool; the fetch-Python probe checks requests.
 Runtime v0156 = runtime v0154 (190 members byte-identical) + VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122 + VRN2_ConsensusJoin_v0104.

v0154: v0153 entry + the desktop run of 2026-10-30 20:09 (Handle-All v0101 → RoundAll v0109 full run · 2225 s · DUPKEY 0 ·
 close-out OPEN "VRN-2 2" = step 6f consensus).

 - step 6f: the first engine pass fetched 43 codes; 6933 / 7728 / 4171 answered "statusCode=404 頁面或商品不存在". ConsensusJoin v0102
   dropped them and ran the engine again, but the engine's checkpoint hash includes the code list, so the second pass did not resume:
   all 40 codes were fetched again and cnyes answered 8358 / 2891 with pages without __NEXT_DATA__ (ASSIGNED_JSON_NOT_FOUND) -> gate
   FAIL_CLOSED. ConsensusJoin v0103 (thin tail over v0102): before every engine pass it moves today's fetched payloads into the
   checkpoint of the code list being run (the engine's own hash / payload / archive functions) so the engine resumes them without
   going online; 404 / transient fetch failures are retried after a wait (only the failed codes are fetched); still failing -> 404 in
   no_coverage, transient in source_gap (YELLOW · data source) and left out of the gate; the Combined rows carry their own reason.
 Runtime v0154 = runtime v0153 (189 members byte-identical) + VRN2_ConsensusJoin_v0103.

v0153: v0152 entry + the desktop run of 2026-10-30 18:34 (Handle-All v0100 → RoundAll v0108 verify: close-out BLOCKED · VRN-2 0).

 - the independent verifier v0114 still counted DUPKEY 45 in the annual book: 6933_AMAX-KY page 8 holds two tables side by side
   (balance sheet ∥ income statement) and the right table's values were written under the left table's item (流動資產 2020 =
   1,331,956 and 3,411,492); 凱基 2891 page 5 had 8 row-less duplicates. Manager v0257 (thin tail over v0255): the same file · page ·
   table · row · item · period with different values → the leftmost cell keeps the item, a later value takes the label written in
   its own row (renamed · noted) or moves to the Rejected book; row-less duplicates move to the Rejected book. The same item on
   different rows (Percent of Revenues · Other adjustments) is not touched. The 14 container PDFs: 0 rows change.
 Runtime v0153 = runtime v0152 (188 members byte-identical) + VRN_SystemManager_v0257.

v0152: v0151 entry + the desktop runs of 2026-10-30 (RoundAll v0105 / v0107 · operator: "GENERATE A PS CODE TO HANDLE ALL").

 - step 11 VRN2_IndependentVerifier_v0114 (latest in the runtime): the only annual FAIL left on the desktop (260914_daiwa_aspeed.pdf PBR (x)
   26E 'n.a.') was the character-box reader again — the page reads header "Year to 31 Dec 26E 27E 28E" and row "PBR (x) n.a. 29.2 16.8", so
   the book value is right. A FAIL is now aligned by column in the second reading (one reader at a time, equal counts only): source value at
   the period = book value → NILVAL (empty marker) / PRESENT (number); a different value or no alignment keeps FAIL.
 - nothing else changes how steps run; VRN2_RoundAll_v0108 and the PowerShell 7 "handle all" code drive this package.
 Runtime v0152 = runtime v0151 (187 members byte-identical) + VRN2_IndependentVerifier_v0114.

v0151: v0150 entry + the close-out round (operator 2026-10-29: "solve the remaining system issues · HTML U/I · CLOSE OUT").

 - step 11 VRN2_IndependentVerifier_v0113 (latest in the runtime): the desktop's annual-data BADITEM 19 (MS-3665 / MS-8358 / MS-8210 /
   Daiwa aspeed · "ModelWare net inc (NT $ mn)" · "Prior EPS (NT$)**" · "DPS", every value on the page) came from the character-box reader
   only; an item is now read a second way (PDFium whole-page text + pdfplumber lines) before it is called "not on this page". Fabricated /
   renamed items stay BADITEM with the closest source line in the note; a value not on the page stays FAIL with the item's source line.
 - VRN2_RoundAll_v0104 writes the close-out page VIA_Reports/vrn2/VRN2_CloseoutUI_latest.html (every open item with its owner:
   VRN-2 / VCGC / human check / data source / reminder) — this launcher's receipt is one of its inputs; nothing here changes how steps run.
 Runtime v0151 = runtime v0150 (186 members byte-identical) + VRN2_IndependentVerifier_v0113.

v0150: v0149 entry + fixes from the desktop run of VRN2_RoundAll_v0102 (2026-10-29 19:00 · red 0 · yellow 20 · 5957 s).

 - step 11 VRN2_IndependentVerifier_v0112 (latest in the runtime): MS-6669 3510.00 / MS-3661 3190.00 CURRENT_PRICE FAILs were the character-box
   reader missing / mispairing the key-data sidebar on the desktop (the book values equal the source lines "Shr price, close (...) NT$3,510.00"
   / "... NT$3,190.00"); when it says no, the page is read a second way and only the same-line label counts (swaps stay FAIL).
 - step 6f VRN2_ConsensusJoin_v0102: the engine gate FAIL_CLOSED came only from 6933 / 4171 "statusCode=404 頁面或商品不存在" (cnyes has no
   FactSet page for them); those codes are left out and the same engine runs again (resume) so the gate judges the covered codes.
 - step 6e detail names the fetch Python and whether it met the VDF bounds ("Python 本行程" made RoundAll v0102 fetch everything a second
   time, ~35 min).
 Runtime v0150 = runtime v0149 (184 members byte-identical) + VRN2_IndependentVerifier_v0112 + VRN2_ConsensusJoin_v0102.

v0149: v0148 entry + fixes from the desktop run of VRN2_RoundAll_v0101 (2026-10-29 17:01 · red 4 · yellow 11).

 - closeout gate VRN2_VerbatimVerifier_v0105 (thin tail over v0104, which stays next to it): 3014TT-20231005.pdf point 3 was the only FAIL and the reason for
   rc 1. The stored excerpt (pdfplumber) ends a line with "Type-" and goes on with "C PD"; PDFium writes that line-end hyphen as U+FFFE and drops the line break.
   v0104 only joined "-" + newline before a lowercase letter and did not know U+FFFE. v0105 compares U+FFFE as "-" + newline and drops "-" + newline before any
   character on both sides (comparison form only; stored excerpts unchanged). Reproduced in the container with a generated PDF: v0104 FAIL, v0105 PASS.
 - step 11 VRN2_IndependentVerifier_v0111 (latest in the runtime, picked by the base as before): v0110 with its excerpt reader on VerbatimVerifier v0105.
 - step 6e VRN2_MarketFetchRun_v0100: the desktop gave MarketFetch v0112 envs/via_core_312 (all packages present), but MarketFetch's own fetch_python()
   returns envs/via_tw_fetch whenever that folder exists; it has no packages, so the fetch said "擷取環境缺套件" (and the VDF engine's bootstrap pip had failed
   there before). The runner loads the shared MarketFetch from its own file (read-only, unchanged), replaces only its fetch_python() with the first Python
   that passes the VDF engine's own dependency check (same modules, same >= / < bounds read from the engine file, Python 3.11+), and runs MarketFetch.main;
   when none passes, --fetch stays YELLOW with what each candidate misses and the engine is not started (no pip), --fill runs with a Python that has
   pandas + pyarrow. Without the runner in the runtime, 6e runs MarketFetch directly as v0148 did.
 Runtime v0149 = runtime v0148 (181 members byte-identical) + VRN2_VerbatimVerifier_v0105 + VRN2_IndependentVerifier_v0111 + VRN2_MarketFetchRun_v0100.

v0148: v0147 entry + fixes from the first desktop run of VRN2_RoundAll_v0100 (2026-10-29 14:40 · red 4 · yellow 10).

 - ⑥c / ⑫b handler VRN2_UIAction_v0110: its --selftest clears VIA_ROOT / VRN2_* for the run (v0109's ④ failed on the desktop because the shell has VIA_ROOT,
   so the selftest re-rendered the real Workbench); every action still goes to v0109.
 - ⑥f VRN2_ConsensusJoin_v0101: TPEx stocks use .TWO on Yahoo. cnyes answers "TWS:####:STOCK" for TPEx stocks too, so the fusion engine (bundled unchanged)
   asked Yahoo for 5274.TW / 5904.TW / 8358.TW / … → 404. The code → yfinance ticker map now comes from ⑥e's market book (VDF identity: TWSE .TW · TPEX .TWO) and the
   engine runs through a shim that swaps its ticker function (same Python, same engine file, same arguments); same-day checkpoint payloads fetched with the wrong
   suffix are re-fetched.
 - ⑬b VRN2_HistoryAlign_v0102: item mapping ignores component / other-basis rows (Other Revenue · Taxes payable · Total liabs & equity · minorities · adjusted /
   core · segment / business growth) and the add / multiply checks take |COGS|, accept ROE on average equity, take the value that recurs across a report's tables
   (estimate-revision tables carry old / new / % change for the same year) and mark basis mismatches UNCLEAR instead of FAIL
   (container data: 74 / 218 → 5 / 192 failing checks, the 5 being the deliberately contradicted synthetic history).
 Runtime v0148 = runtime v0147 (178 members byte-identical) + VRN2_UIAction_v0110 + VRN2_ConsensusJoin_v0101 + VRN2_HistoryAlign_v0102.

v0147: v0146 entry + fixes found while building the one-file runner VRN2_RoundAll_v0100.py (operator 2026-10-29: "generate a py code to handle all above and fix all test all debug all").

 - ⑬ long-term Parquet store: VRN2_OutputStore_v0101 keeps Combined · FinancialAligned · Deleted too, and appends per (book × source-file SHA) so books that appear later are
   back-filled for files the store already knows (v0100 only appended files it had never seen → on the desktop, with 52 known files, the new books stayed empty).
 - ⑬b history alignment now runs BEFORE ⑬, so FinancialAligned / Deleted of this run are in the store.
 - ⑬c legacy-database scan: VRN2_DataIntegrate_v0101 walks with a depth limit (output folder 2 · its parent 1 · legacy_in 3 · max 20,000 entries per folder) instead of rglob over the whole
   tree (the parent of a OneDrive output folder is the OneDrive root), and only asks about files that look like a VRN-2 book (≥ 3 mapped columns · an identity column · ITEM + VALUE for FinancialData).
 - ⑥e runs the borrowed MarketFetch with the fetch Python (VIA_FETCH_PY → %USERPROFILE%\\envs\\via_tw_fetch → this Python) because --fill imports pandas; --fill still runs after a --fetch
   timeout / error (VDF writes Parquet incrementally) and is skipped only when --fetch is GRAY.
 - --selftest no longer needs the runtime modules next to the launcher: it takes them out of VRN2_Runtime_v0147.zip in the package (v0144–v0146 selftests failed in a real package folder).
 - ⑬b history alignment: VRN2_HistoryAlign_v0101 sends a row to the Deleted zone only when it is the same order of magnitude as history (ratio 0.5–2) and > 3% off;
   a row that matches at another unit scale is overridden without deletion, an unclear-basis row (ratio far off) is left untouched, growth / % sections are ratios
   (RoundAll end-to-end: 100 → 39 deleted rows on the same data, the 61 were other units / growth tables).
 Runtime v0147 = runtime v0146 (175 members byte-identical) + VRN2_OutputStore_v0101 + VRN2_DataIntegrate_v0101 + VRN2_HistoryAlign_v0101.

v0146: v0145 entry + market data (⑥e) · FactSet / YFinance consensus Combined book (⑥f) · history alignment (⑬b) · legacy-database integration scan (⑬c) · Workbench v0102 · handler v0109 · SSOT proposals.

Operator 2026-10-29 (10:25 paste-back of v0145 · 2546 s · CPU 87.5% busy by another process so the launcher ran 1 lane; ⑬ duckdb incremental GREEN) asked:
 - U/I: headers with spaces (now bilingual per the operator list), everything top-aligned, amounts shown in NT$ millions with thousands separators (per-share / multiples / % keep their value),
   tiles auto-fit instead of overflowing, an output-folder slot (long-term Parquet store) above the other-system Gates, the first right-panel block = input dedup matrix + engine status, logo 180% with 1.5% margin.
 - "Why can't it fetch TWSE / TPEX / YFinance any more?": the desktop line's own manager (v0249+) carries a ⑥e MarketFetch step; this package line (manager v0243 → v0255) never had one.
   v0146 adds ⑥e here: after the run it borrows the shared folder's latest VRN2_MarketFetch_v*.py (desktop-line tool · read-only · wraps VDF_TW_AllInOne) with --fetch then --fill → VIA_Reports/vrn2/market/VRN2_Market_latest.json.
 - ⑥f: the uploaded VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120 (bundled unchanged in runtime v0146) fetches FactSet (cnyes) + YFinance consensus; VRN2_ConsensusJoin builds output/VRN2_Combined_latest
   (per report: … TARGET_PRICE · TARGET_PRICE(ADJ) · FACTSET / YFINANCE target medians · <year>_DILUTED_EPS_FACTSET ×3 · <year>_PER_FACTSET ×3 with real years n..n+2 · CURRENT_PRICE_REPORT · UPSIDE_PCT(ADJ) · ADJ_CLOSE · … · TOPIC & SUMMARY · STATUS).
 - ⑬b VRN2_HistoryAlign: at least one period of each report must reconcile with MOPS / TWSE history (0.97–1.03 · unit scale auto) before history overrides estimates; add/sub and mul/div checks; contradicted report values go to the Deleted zone.
 - ⑬c VRN2_DataIntegrate scan: legacy CSV / XLSX / Google-Sheet exports near the output folder are detected and the Workbench asks the user; apply (vrn2://integrate · handler v0109) never deletes originals (copies to TEMP after a verified new Parquet).
 Non-critical steps: ⑥e / ⑥f / ⑬b / ⑬c never turn the closeout RED (GRAY when opted out or a tool is absent · YELLOW on env / partial). Opt-outs: VIA_VRN2_NO_MARKET=1 · VIA_VRN2_NO_CONSENSUS=1 · VIA_VRN2_NO_HISTORY=1 · VIA_VRN2_NO_INTEGRATE=1.
 Runtime v0146 = runtime v0145 (167 members byte-identical) + Workbench v0102 · UIAction v0109 · SSOTSync v0101 · HistoryAlign v0100 · DataIntegrate v0100 · ConsensusJoin v0100 · SSOT proposals v0100 · the consensus engine v0120.

v0145: v0144 entry + manager v0255 (parallel idempotence gate · heartbeat · phase timing).

Desktop run 2026-10-29 08:14 (v0144 · 52 reports · 2422 s): everything registered and the U/I was bound (⑥c · ⑤b · ⑫b · ⑬ GREEN),
but step ⑦ took 1201 s with ~1050 s of silence although extraction served 52/52 from cache: the v0243 idempotence gate
re-extracts 3 reports twice in one single-lane subprocess per wave. v0145 only points the private runtime at manager v0255
(same gate contract; each wave runs one subprocess per file in parallel, prints a heartbeat every 30 s, records per-wave timing,
and times the native phases into VRN2_Phase_Timing_latest.json + one [計] 階段耗時 line). Runtime v0145 = runtime v0144 + v0255.

v0144: v0143 entry + output location / DuckDB incremental Parquet store + SSOT-ID coordination (VRN-2 side) + Workbench v0101 + handler v0108.

Operator 2026-10-29: the three systems (VRN-2 / VDF / VCGC) stay independent; SSOT / Regex / synonym / policy entries are proposed
bottom-up with a blank SSOT ID, VCGC detects cross-system conflicts, the user and AI fix them, VCGC assigns the number and the
subsystem fills it in automatically. VRN-2 is to close out quickly through the HTML U/I: output location chosen with Windows I/O
(dialog / drag) or a cloud-synced folder, Parquet output with incremental extraction managed by DuckDB.
v0144 lands runtime v0144 = runtime v0142 + VRN2_UIAction_v0108 (vrn2://pick?kind=outdir · outdir?reset=1 · --set-outdir) +
VRN2_OutputStore_v0100 (mirror + DuckDB incremental store, pyarrow fallback) + VRN2_SSOTSync_v0100 (request / apply / sync)
+ VRN2_Workbench_v0101 (output-location and store panel · SSOT-ID status). New steps: ⑤b SSOT-ID sync after the register;
⑬ output store after the closeout receipt (GRAY until an output folder is chosen; VRN2_OUTPUT_DIR seeds the config).

v0143: v0142 entry + single-instance guard + wider child limits + in-process ⑫b fallback. Runtime v0142 untouched.

Operator desktop run 2026-10-29 01:33 (paste-back): two launcher instances overlapped (01:35 and 01:58) on the same VIA root,
free RAM fell to 0.16 GB, and every child subprocess then hit its ceiling: ⑦ killed after 1500 s without output, ⑪ verifier
stopped at 1800 s, ⑫b --refresh-ui killed at 120 s, so the U/I had no input block and the one-click ⑤b went RED although
⑧ completed. v0143 adds: (1) VIA_Reports/vrn2/VRN2_Launcher.lock — a second launcher on the same root refuses to start while
the first PID is alive (VRN2_FORCE_PARALLEL=1 overrides); (2) child limits from the environment with safer defaults
(VRN2_UI_REFRESH_WAIT 600 s · VRN2_SILENT_MAX 3600 s for the ⑦ run · VRN2_MANIFEST_WAIT 900 s · VIA_VRN2_VERIFY_WAIT 3600 s);
(3) when the ⑫b handler subprocess fails or times out, this entry writes the input block itself (same patch_ui code, in
process) so the front end stays linked. Everything else is v0142.

v0142: v0141 entry + Workbench U/I (template-locked front end bound to the run's receipts) + summarizer v0117.

Operator 2026-10-28: the pasted run (v0136 line · summarizer v0114) showed truncated / header-polluted four points, and
the operator uploaded the "VIA VRN-2 Workbench" template to lock as the front end, integrated with the backend as one
system, with a transparent seal logo replacing the template logo. v0142 lands runtime v0142 = runtime v0141 +
VRN_ENG062_SummarizerV1_v0117 (leading banner / title / section-heading lines trimmed from an excerpt; spans stay
exact) + VRN2_Workbench_v0100 (renders VIA_Reports/vrn2/VRN2_Workbench_latest.html from the receipts and output books;
vrn2:// actions wired; VRN2_Logo.png auto-transparent) + its font assets. After the closeout receipt is written this
entry renders the Workbench, links it from the legacy U/I page and opens it. Everything else is v0141.
"""
from __future__ import annotations

# ===== 1. Parameters =====
VERSION = "ActivateVRN-2 v0178"
BASE_NAME = "ActivateVRN-2_v0136.py"
RUNTIME_ZIP = "VRN2_Runtime_v0167.zip"
RUNTIME_MANIFEST = "VRN2_Runtime_v0167.json"
PRIVATE_FOLDER = "VRN2"
OCR_BRIDGE = "VRN2_OCRBridge_v0101.py"
CONTEXT_NAME = "VRN2_Runtime_Context.json"
STATE_PATTERNS = (("SSOT", "VRN2_SSOT_v*.json"), ("SSOT", "VRN_Config_v1*.json"), ("registry", "VRN2_*.json"), ("registry", "VRN2_*.jsonl"))
MANAGER = "VRN_SystemManager_v0260.py"   # v0177: page_NNNN[_hash].pdf out of the stock scope over v0259 · v0168: transposed tables re-asked with joined number fragments over v0258 · v0166 v0258: table repair before the books (half-line labels · two-level period header) over v0257 · v0153 v0257: one row, one item (PRIOR v0255 · v0256 is the desktop line's in functional modules/VRN); v0255 kept (PRIOR pinned v0243)
VERBATIM = "VRN2_VerbatimVerifier_v0105.py"   # v0178: back to v0105 — the desktop v0106 is step 4's own accelerator injection of v0105 (v0177's v0106 collided) · v0149: thin tail over v0104 (line-end hyphen · U+FFFE) · v0104 stays next to it
MAX_PASSES = 2
WORKBENCH = "VRN2_Workbench_v0111.py"   # v0178: narrow screens (< 1000 px) without page-wide scroll · aria-labels · wide look locked · v0177: same font both panels · 28 px buttons · cards fit · matrices · 檢視副本 · thousands separators · v0175: Detail-column font · 系統摘要 matrices · two-line headers · step-numbered left panel · v0174: ENG049 template lock · data-tab display rules · Source column · v0172: self-contained tail (skips v0105 / accelfix v0106) · Basic Info merged view · UPSIDE_ADJ shown as % · v0170: dynamic-prior tail (desktop chains v0104 · repo runtime chains v0102) · compact CSS · verification lamps · consensus panel
UI_HANDLER = "VRN2_UIAction_v0110.py"   # v0105 / v0107 are the desktop line's publish handlers in functional modules/VRN; this line went v0108 → v0109 (vrn2://integrate) → v0110 (hermetic selftest)
OUTPUT_STORE = "VRN2_OutputStore_v0101.py"   # v0147: thin tail over v0100 (7 books · per-book back-fill)
OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0105.py"   # v0177: v0104 behaviour · self-test pins its BookSource · v0176: hash ignores leading bullets (Summary) / TOPIC & SUMMARY (Combined) · old rows tidied in place (backup · restore-fill) · v0175: row hash ignores SOURCE / BROKER_EN · old rows filled in place (backup · restore-fill) · v0164: thin tail over v0101 (MOPS rows purged with a backup · never appended again · MarketConsensus book)
SSOT_SYNC = "VRN2_SSOTSync_v0101.py"
BOOK_SOURCE = "VRN2_BookSource_v0102.py"   # v0177 ⑬a: 1,234.50 / 23.45% in TOPIC & SUMMARY · v0176 ⑬a: + four points without leading bullets · TOPIC & SUMMARY = Name(YF, 評等) - 標題 · valuation first · upside from TP(ADJ) ÷ ADJ_CLOSE · v0175 ⑬a: BROKER_EN + SOURCE written as the last two columns of the output books
HISTORY_ALIGN = "VRN2_HistoryAlign_v0103.py"   # v0172: typed Parquet rewrite when the prior could not write it (ArrowInvalid) · v0148: thin tail over v0101 (strict item mapping · checks UNCLEAR vs FAIL)
DATA_INTEGRATE = "VRN2_DataIntegrate_v0101.py"   # v0147: thin tail over v0100 (depth-limited walk · VRN-2-like filter)
CONSENSUS_JOIN_ACTIVE = "VRN2_ConsensusJoin_v0107.py"   # v0172: UPSIDE_ADJ ratio column after the kept percent column UPSIDE_PCT(ADJ) · column notes · v0170: snapshot backfill when the consent gate is closed (ASOF-labelled · operator opens the gate for fresh data) · v0164: thin tail over v0104 (TARGET_PRICE(ADJ) synchronous adjustment · consensus in the TWSE / TPEX format · merged)
CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0104.py"   # v0156: thin tail over v0103 (engine v0122 through the VIA network tool + accelerator · net_deny · provenance refresh) · v0154: thin tail over v0102 (resume today's payloads on a new code list · retry transient · source_gap) · v0150: 404 out of the gate · v0101: TPEx → .TWO
MARKET_FETCH_GLOB = "VRN2_MarketFetch_v[0-9][0-9][0-9][0-9].py"   # borrowed from the shared desktop-line folder functional modules/VRN (read-only · latest number)
MARKET_RUNNER = "VRN2_MarketFetchRun_v0100.py"   # v0149: runs the borrowed MarketFetch with a Python that passes the VDF engine's own dependency check
LOCK_NAME = "VRN2_Launcher.lock"
INSTALL_GATE_GLOB = "CGC_MDL056_InstallGate_v[0-9][0-9][0-9][0-9].py"   # v0157: VCGC 的安裝閘(supportive modules/registry · 最高版號 · 只呼叫 · 不改)
INSTALL_LEDGER = "VRN2_VCGCInstall_latest.json"   # v0157: VCGC 安裝閘裝不起來的套件(24 小時內不重試)
RECEIPT_NAME = "VRN2_Closeout_v0178.json"
MOPS_DATASETS = ("parquet/tw_financial", "tw_financial.parquet")   # v0163: the VDF engine's financial dataset = MOPS statements
LIMIT_DEFAULTS = {"VRN2_UI_REFRESH_WAIT": 600, "VRN2_SILENT_MAX": 3600, "VRN2_MANIFEST_WAIT": 900, "VIA_VRN2_VERIFY_WAIT": 3600, "VRN2_MARKET_WAIT": 1800, "VRN2_CONSENSUS_WAIT": 900}
CRITICAL_STEPS = ("② 定位 VRN-2 · VRN-2 SystemManager", "② 擷取引擎", "② 摘要器", "②b", "⑤", "⑥ 啟動前", "⑦", "⑧", "⑪")

import hashlib
import html
import importlib.util
import json
import os
import queue
import re
import subprocess
import threading
from pathlib import Path
import shutil
import sys
import tempfile
import time
import zipfile
import datetime

# [VIA:ACCEL-BRIDGE:v0111] The unchanged released launcher loads the existing accelerator bridge.


# ===== 2. Versioned runtime restoration =====
def load_base():
    path = Path(__file__).resolve().with_name(BASE_NAME)
    specification = importlib.util.spec_from_file_location("vrn2_release_v0136", path)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def restore_private_runtime(root: Path, package_dir: Path | None = None) -> Path:
    package_dir = package_dir or Path(__file__).resolve().parent
    manifest = json.loads((package_dir / RUNTIME_MANIFEST).read_text(encoding="utf-8"))
    archive_path = package_dir / RUNTIME_ZIP
    if hashlib.sha256(archive_path.read_bytes()).hexdigest() != manifest["zip_sha256"]:
        raise ValueError("VRN-2 runtime archive checksum mismatch")
    runtime = root / "functional modules" / PRIVATE_FOLDER
    staged = []
    with zipfile.ZipFile(archive_path) as archive:
        for entry in manifest["files"]:
            relative = Path(entry["path"])
            if relative.is_absolute() or ".." in relative.parts or len(relative.parts) != 1:
                raise ValueError("Invalid runtime member")
            data = archive.read(entry["path"])
            if hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise ValueError("Runtime member checksum mismatch: " + entry["path"])
            target = runtime / relative
            if target.exists() and target.read_bytes() != data:
                raise ValueError("Existing VRN-2 runtime differs; retained without overwrite: " + str(target))
            staged.append((target, data))
    for target, data in staged:
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    shared = root / "functional modules" / "VRN"
    for folder, pattern in STATE_PATTERNS:
        for source in (shared / folder).glob(pattern):
            target = runtime / folder / source.name
            if source.is_file() and not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
    return runtime


# ===== 2b. v0143: single-instance guard · child limits · ⑫b fallback =====
def pid_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
            if not handle:
                return False
            code = ctypes.c_ulong()
            still = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
            ctypes.windll.kernel32.CloseHandle(handle)
            return bool(still) and code.value == 259  # STILL_ACTIVE
        except Exception:  # noqa: BLE001
            return False
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def acquire_lock(output: Path) -> tuple:
    """One launcher per VIA root. Returns (ok, info). A live PID in the lock refuses this start unless VRN2_FORCE_PARALLEL=1; a stale lock is taken over."""
    output.mkdir(parents=True, exist_ok=True)
    path = output / LOCK_NAME
    old = {}
    if path.is_file():
        try:
            old = json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            old = {"pid": 0, "raw": "unreadable"}
        alive = pid_alive(int(old.get("pid") or 0))
        if alive and os.environ.get("VRN2_FORCE_PARALLEL") != "1":
            return False, {"lock": str(path), "holder": old, "alive": True, "why": "另一個 VRN-2 啟動器還在跑(PID %s · %s · 自 %s)· 本次不跑;等它結束再貼,或 VRN2_FORCE_PARALLEL=1 強制(會搶 RAM · 2026-10-29 實跑就是這樣全逾時)" % (old.get("pid"), old.get("version"), old.get("started"))}
        if alive:
            note = "VRN2_FORCE_PARALLEL=1 · 與 PID %s 並行" % old.get("pid")
        else:
            note = "接手過期鎖(PID %s 已不在)" % old.get("pid")
    else:
        note = "新鎖"
    mine = {"pid": os.getpid(), "version": VERSION, "started": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "root": str(output.parent.parent), "python": sys.executable}
    path.write_text(json.dumps(mine, ensure_ascii=False, indent=1), encoding="utf-8")
    return True, {"lock": str(path), "holder": mine, "alive": False, "why": note}


def release_lock(output: Path) -> None:
    path = output / LOCK_NAME
    try:
        if path.is_file() and int(json.loads(path.read_text(encoding="utf-8")).get("pid") or 0) == os.getpid():
            path.unlink()
    except Exception:  # noqa: BLE001
        pass


def limits() -> dict:
    out = {}
    for key, default in LIMIT_DEFAULTS.items():
        try:
            out[key] = max(int(os.environ.get(key) or default), 60)
        except ValueError:
            out[key] = default
    return out


def run_limits(arguments: list, timeout, kwargs: dict, lim: dict) -> tuple:
    """Map a child command to its (timeout, kwargs): --refresh-ui → VRN2_UI_REFRESH_WAIT; vrn2 --run → silent_max VRN2_SILENT_MAX; manifest → VRN2_MANIFEST_WAIT."""
    tokens = [str(a) for a in arguments]
    kwargs = dict(kwargs)
    if "--refresh-ui" in tokens:
        timeout = max(int(timeout or 0), lim["VRN2_UI_REFRESH_WAIT"])
        kwargs["silent_max"] = max(int(kwargs.get("silent_max") or 0), lim["VRN2_UI_REFRESH_WAIT"])
    elif "vrn2" in tokens and "--run" in tokens:
        kwargs["silent_max"] = max(int(kwargs.get("silent_max") or 0), lim["VRN2_SILENT_MAX"])
    elif tokens and tokens[-2:-1] == ["manifest"] or "manifest" in tokens[2:4]:
        timeout = max(int(timeout or 0), lim["VRN2_MANIFEST_WAIT"])
    return timeout, kwargs


def ensure_input_block(runtime: Path, output: Path, steps: list) -> dict:
    """⑫b fallback: if the handler subprocess did not leave the input block in the legacy U/I, write it here (same patch_ui, in process)."""
    ui = Path(output) / "VRN2_UI_latest.html"
    entries = [entry for entry in steps if str(entry.get("step", "")).startswith("⑫b")]
    present = ui.is_file() and "<!--vrn2-input-->" in ui.read_text(encoding="utf-8", errors="replace")
    if present and entries and entries[-1].get("lamp") == "GREEN":
        return {"lamp": "GREEN", "how": "子行程", "detail": entries[-1].get("detail", "")}
    if not ui.is_file():
        return {"lamp": "GRAY", "how": "none", "detail": "沒有 U/I 頁(⑦ 沒寫出)· 不補放"}
    handler = Path(runtime) / UI_HANDLER
    try:
        specification = importlib.util.spec_from_file_location("vrn2_ui_handler_fallback", handler)
        module = importlib.util.module_from_spec(specification)
        sys.modules[specification.name] = module
        specification.loader.exec_module(module)
        ok, message = module.patch_ui(output)
    except Exception as error:  # noqa: BLE001
        ok, message = False, "%s: %s" % (type(error).__name__, str(error)[:120])
    lamp = "GREEN" if ok else "YELLOW"
    detail = "v0143 本支補放(處理器子行程 %s)· %s" % ((entries[-1].get("detail", "")[:80] if entries else "沒跑"), message)
    if entries:
        entries[-1].update(lamp=lamp, detail=detail)
    else:
        steps.append({"step": "⑫b U/I 輸入區塊(window I/O)", "lamp": lamp, "detail": detail})
    return {"lamp": lamp, "how": "in-process", "detail": detail}


# ===== 2c. v0144: SSOT-ID sync · output store =====
def _load_runtime_module(runtime: Path, name: str, alias: str):
    specification = importlib.util.spec_from_file_location(alias, Path(runtime) / name)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def ssot_sync(runtime: Path, steps: list) -> dict:
    """⑤b: VRN-2 side of the three-system SSOT-ID protocol — apply VCGC grants / conflicts to the component register, rewrite the request."""
    try:
        module = _load_runtime_module(runtime, SSOT_SYNC, "vrn2_ssot_sync_entry")
        result = module.sync(Path(runtime))
    except Exception as error:  # noqa: BLE001
        result = {"lamp": "YELLOW", "apply": {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}, "request": {}}
    a, q = result.get("apply") or {}, result.get("request") or {}
    if a.get("lamp") == "GRAY":
        detail = a.get("why", "沒有登記冊")
    else:
        counts = q.get("counts") or {}
        detail = "核發 %s · 衝突 %s · 待核號 %s(SSOT 類 %s · 程式類 %s)· 自撞 %s · 登記冊 %s · 核發冊 %s" % (
            a.get("granted", 0), a.get("conflicts", 0), a.get("pending", 0), counts.get("ssot_like", "—"), counts.get("program", "—"), counts.get("self_conflicts", 0),
            a.get("register", "—"), " · ".join(a.get("grant_sources") or []) or "尚無(VCGC 還沒核發)")
    lamp = {"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(result.get("lamp"), "YELLOW")
    steps.append({"step": "⑤b SSOT-ID 核號同步(VRN-2 側)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑤b SSOT-ID 核號同步 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "apply": {k: a.get(k) for k in ("granted", "conflicts", "pending", "register", "grant_sources") if k in a}, "request": q}


def output_store(runtime: Path, output: Path, run_id: str, steps: list) -> dict:
    """⑬: mirror this run's books + incremental Parquet store (DuckDB) into the chosen output folder; GRAY when none is chosen."""
    try:
        module = _load_runtime_module(runtime, OUTPUT_STORE_ACTIVE, "vrn2_output_store_entry")   # v0164 v0102(先清 MOPS 列 · 備份)
        if os.environ.get("VRN2_OUTPUT_DIR") and not module.read_config(output).get("output_dir"):
            module.write_config(output, os.environ["VRN2_OUTPUT_DIR"], "環境變數 VRN2_OUTPUT_DIR")
        result = module.sync(Path(output), None, run_id)
    except Exception as error:  # noqa: BLE001
        result = {"lamp": "RED", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "RED")
    if lamp == "GRAY":
        detail = result.get("why", "未設定輸出位置")
    elif "store_engine" in result:
        appended = result.get("appended") or {}
        detail = "%s(%s)· 鏡像 %d · 引擎 %s · 新檔 %d / 已知 %d · 追加 %s · parquet %d%s" % (
            result.get("output_dir"), result.get("cloud_hint", ""), len(result.get("mirrored") or []), result.get("store_engine"), len(result.get("new_files") or []), len(result.get("known_files") or []),
            " / ".join("%s %s" % (k, v) for k, v in appended.items()), len(result.get("parquet_files") or []), (" · " + result["why"]) if result.get("why") else "")
        purge = result.get("mops_purge") or {}
        if purge.get("removed_total") or purge.get("lamp") == "RED":                                      # v0164 清 MOPS 列寫在前面(不被 300 字截掉)
            detail = "清 MOPS 列 %s(%s)· %s" % (json.dumps(purge.get("removed") or {}, ensure_ascii=False), Path(str(purge.get("folder") or "")).name or purge.get("lamp"), detail)
        if result.get("mops_skipped"):
            detail = "擋 MOPS 列 %s · %s" % (json.dumps(result["mops_skipped"], ensure_ascii=False), detail)
    else:
        detail = result.get("why", "")
    steps.append({"step": "⑬ 輸出位置 · 增量庫(DuckDB)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬ 輸出位置 · 增量庫 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {k: result.get(k) for k in ("lamp", "why", "output_dir", "cloud_hint", "store_engine", "store", "run_id", "new_files", "known_files", "appended", "totals", "catalog_files", "parquet_files", "mirrored", "mops_purge", "mops_skipped", "derived_fill", "summary_tidy") if k in result}


# ===== 3. Completion gate =====
# ===== v0146: ⑥e market data · ⑥f consensus Combined · ⑬b history alignment · ⑬c legacy-database integration scan =====
def shared_market_tool(root: Path) -> Path | None:
    """⑥e borrows the shared folder's VRN2_MarketFetch (desktop line · read-only · latest number); None when absent."""
    folder = Path(root) / "functional modules" / "VRN"
    hits = sorted(folder.glob(MARKET_FETCH_GLOB), key=lambda p: int(re.search(r"_v(\d{4})", p.name).group(1))) if folder.is_dir() else []
    return hits[-1] if hits else None


def stream_child(command: list, cwd: Path, wait: int, prefix: str) -> tuple:
    """Run a child, echo its lines live with a prefix, kill it after `wait` seconds of total time; returns (rc, lines)."""
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    proc = subprocess.Popen([str(c) for c in command], cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", env=env)
    bucket: queue.Queue = queue.Queue()

    def pump():
        for line in proc.stdout:
            bucket.put(line)
        bucket.put(None)
    threading.Thread(target=pump, daemon=True).start()
    lines, started = [], time.time()
    while True:
        try:
            line = bucket.get(timeout=5)
        except queue.Empty:
            if time.time() - started > wait:
                proc.kill()
                lines.append("[RED] 逾時 %d 秒 · 已停止" % wait)
                print(prefix + lines[-1], flush=True)
                break
            continue
        if line is None:
            break
        lines.append(line.rstrip("\n"))
        print(prefix + lines[-1][:300], flush=True)
    try:
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill()
    return (proc.returncode if proc.returncode is not None else -9), lines


def market_python() -> str:
    """v0147: the Python that runs MarketFetch (its --fill imports pandas): VIA_FETCH_PY → %USERPROFILE%\\envs\\via_tw_fetch → this Python."""
    explicit = os.environ.get("VIA_FETCH_PY") or ""
    if explicit and Path(explicit).is_file():
        return explicit
    home = os.environ.get("USERPROFILE") or os.environ.get("HOME") or ""
    for candidate in (Path(home) / "envs" / "via_tw_fetch" / "Scripts" / "python.exe", Path(home) / "envs" / "via_tw_fetch" / "bin" / "python"):
        if home and candidate.is_file():
            return str(candidate)
    return sys.executable


def pick_market_python(runner: Path, tool: Path, preferred: str) -> dict:
    """v0149: ask VRN2_MarketFetchRun which Python passes the VDF engine's own dependency check (same modules · same bounds · Python 3.11+) · nothing installed."""
    try:
        done = subprocess.run([sys.executable, "-X", "utf8", str(runner), "--tool", str(tool), "--python", preferred, "--pick-python"], capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=900, cwd=str(runner.parent))
        got = json.loads((done.stdout.strip().splitlines() or ["{}"])[-1])
    except Exception as error:  # noqa: BLE001
        got = {"python": None, "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    rows = [{k: row.get(k) for k in ("python", "how", "ok", "py_version", "missing", "import_failed")} for row in got.get("candidates") or []]
    got = {"python": got.get("python"), "fill_python": got.get("fill_python"), "requirements_from": got.get("requirements_from", ""), "why": got.get("why", ""),
           "candidates": rows, "skipped": got.get("skipped") or []}
    if got["python"]:
        print("[計] ⑥e 擷取 Python · %s · 合 VDF 引擎版本界線(%s)" % (got["python"], got["requirements_from"]), flush=True)
    else:
        print("[計] ⑥e 擷取 Python · 沒有合 VDF 引擎版本界線的 · 不啟動引擎 · %s" % got["why"][:500], flush=True)
    return got


def quarantine_mops_financial(output: Path) -> str:
    """v0163: move MOPS-sourced financial data out of the way (market/vdf/_mops_quarantine_<stamp> · nothing deleted) · returns the folder name or ''."""
    vdf = Path(output) / "market" / "vdf"
    found = [vdf / rel for rel in MOPS_DATASETS if (vdf / rel).exists()]
    if not found:
        return ""
    base_name = "_mops_quarantine_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    target, n = vdf / base_name, 1
    while target.exists():                                                      # 同一秒第二次 → 加序號
        n += 1
        target = vdf / ("%s_%d" % (base_name, n))
    for item in found:
        dest = target / item.relative_to(vdf)
        dest.parent.mkdir(parents=True, exist_ok=True)
        item.replace(dest)
    return target.name


def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:
    """⑥e: TWSE / TPEX / Yahoo market data through the shared folder's VRN2_MarketFetch (borrowed · read-only): --fetch then --fill; never RED (GRAY opted out / absent · YELLOW env or partial)."""
    basic = Path(output) / "output" / "VRN2_BasicInfo_latest.json"
    market = Path(output) / "market"
    tool = shared_market_tool(root)
    extra = {}
    if os.environ.get("VIA_VRN2_NO_MARKET") == "1":
        lamp, detail = "GRAY", "VIA_VRN2_NO_MARKET=1 · 本輪不抓市場資料"
    elif not tool:
        lamp, detail = "GRAY", "共用夾 functional modules\\VRN 沒有 VRN2_MarketFetch_v*.py(桌機線工具)· 不抓 · ⑬b 歷史對齊與 Combined 的還原價會缺"
    elif not basic.is_file():
        lamp, detail = "GRAY", "沒有基本資料冊(⑦ 沒出冊)· 不抓"
    else:
        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        moved = quarantine_mops_financial(output)                              # v0163 不用 MOPS:舊的 MOPS 財報移開(不刪)
        if moved:
            print("[計] ⑥e 不用 MOPS · 已落盤的 MOPS 財報移到 market\\vdf\\%s(不刪)" % moved, flush=True)
        fetch_py = fill_py = market_python()
        runner = Path(root) / "functional modules" / PRIVATE_FOLDER / MARKET_RUNNER
        picked = pick_market_python(runner, tool, fetch_py) if runner.is_file() else {}
        if picked.get("python"):
            fetch_py = fill_py = picked["python"]
        elif picked.get("fill_python"):
            fill_py = picked["fill_python"]                                     # --fill needs only pandas + pyarrow
        results = {}
        for verb in ("--fetch", "--fill"):
            py = fetch_py if verb == "--fetch" else fill_py
            head = [py, "-X", "utf8", str(runner), "--tool", str(tool), "--python", py] if runner.is_file() else [py, "-X", "utf8", str(tool)]
            command = head + [verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)] + (["--no-financial"] if verb == "--fetch" else [])   # v0163 不抓 MOPS 財報
            rc, lines = stream_child(command, tool.parent, wait + 120, "    [⑥e] ")
            last = next((line for line in reversed(lines) if line.startswith("[計] 市場")), "")
            match = re.search(r"\[計\] 市場(擷取|填值) · (GREEN|YELLOW|RED|GRAY) · (.*)", last)
            results[verb] = {"rc": rc, "lamp": match.group(2) if match else ("RED" if rc else "YELLOW"), "msg": (match.group(3) if match else (lines[-1] if lines else "沒有輸出"))[:240], "lines": len(lines)}
            if verb == "--fetch" and results[verb]["lamp"] == "GRAY":   # v0147: a RED / timed-out fetch still leaves Parquet behind → --fill anyway
                break
        fetched, filled = results.get("--fetch", {}), results.get("--fill", {})
        if fetched.get("lamp") == "GRAY":
            lamp = "GRAY"
        elif fetched.get("lamp") == "RED" or filled.get("lamp") == "RED":
            lamp = "YELLOW"
        elif filled.get("lamp") == "GREEN" and fetched.get("lamp") == "GREEN":
            lamp = "GREEN"
        else:
            lamp = "YELLOW"
        py_label = Path(fetch_py).parent.parent.name if fetch_py != sys.executable else "本行程"
        if picked.get("python"):
            py_label = "%s(合 VDF 界線 · %s)" % (picked["python"], picked.get("requirements_from") or "VDF 引擎")
        elif runner.is_file():
            py_label = "沒有合 VDF 界線的(填值用 %s)" % (Path(fill_py).parent.parent.name if fill_py != sys.executable else "本行程")
        detail = "%s · Python %s · 不用 MOPS(--no-financial)%s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, py_label, (" · MOPS 財報移到 " + moved) if moved else "", fetched.get("lamp", "—"), fetched.get("msg", ""), filled.get("lamp", "—"), filled.get("msg", "沒跑"))
        extra = {"tool": str(tool), "results": results, "market_json": str(market / "VRN2_Market_latest.json") if (market / "VRN2_Market_latest.json").is_file() else "",
                 "runner": runner.name if runner.is_file() else "", "fetch_python": picked, "no_mops": True, "mops_quarantine": moved}
    steps.append({"step": "⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 MarketFetch · 不用 MOPS)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑥e 市場擷取 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **extra}


def consensus_join(runtime: Path, root: Path, output: Path, steps: list, lim: dict) -> dict:
    """⑥f: FactSet / YFinance consensus through the bundled fusion engine, then the Combined book (target price → adjusted · medians · real-year EPS / PER); never RED."""
    try:
        module = _load_runtime_module(runtime, CONSENSUS_JOIN_ACTIVE, "vrn2_consensus_join_entry")   # v0164 v0105(同步還原 · TWSE / TPEX 格式合併)
        fixtures = [f for f in (os.environ.get("VRN2_CONSENSUS_FIXTURES") or "").split(";") if f.strip()]
        ran = module.run(Path(output), Path(root), fixtures or None, int(lim.get("VRN2_CONSENSUS_WAIT", 900)))
        joined = module.join(Path(output))
    except Exception as error:  # noqa: BLE001
        ran, joined = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}, {"lamp": "GRAY", "why": "沒組 Combined"}
    pair = (ran.get("lamp", "YELLOW"), joined.get("lamp", "YELLOW"))
    if "YELLOW" in pair or "RED" in pair:
        lamp = "YELLOW"                      # env missing / partial / engine trouble → YELLOW, never RED (non-critical step)
    elif pair == ("GREEN", "GREEN"):
        lamp = "GREEN"
    else:
        lamp = "GRAY"                        # opted out / no tool / no book
    detail = "共識 %s:%s · Combined %s:%s" % (ran.get("lamp", "—"), ran.get("why", ""), joined.get("lamp", "—"), joined.get("why", ""))
    steps.append({"step": "⑥f 共識合併(FactSet / YFinance → Combined 冊)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑥f 共識合併 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "run": {k: ran.get(k) for k in ("lamp", "why", "engine", "python", "codes", "codes_got", "codes_missing", "gate", "rc", "receipt", "yf_ticker_map", "yf_404",
                                                                        "no_coverage", "source_gap", "first_gate", "retries", "seed", "net_tool", "net_deny", "net_engine", "refresh", "engine_no_output", "snapshot_reused", "snapshot_note") if k in ran}, "join": {k: joined.get(k) for k in ("lamp", "why", "rows", "target_adj", "factset_median", "yf_median", "eps_cells", "year_n", "files", "tp_adj_sync", "tp_adj_status_rows", "consensus_dataset") if k in joined}}


def history_align(runtime: Path, root: Path, output: Path, steps: list) -> dict:
    """⑬b: history (MOPS / TWSE via ⑥e) reconciles ≥ 1 period per report → history overrides estimates · checks · Deleted zone; never RED."""
    if os.environ.get("VIA_VRN2_NO_HISTORY") == "1":
        result = {"lamp": "GRAY", "why": "VIA_VRN2_NO_HISTORY=1 · 本輪不做歷史對齊"}
    else:
        try:
            module = _load_runtime_module(runtime, HISTORY_ALIGN, "vrn2_history_align_entry")
            result = module.align(Path(root))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = str(result.get("why", ""))
    steps.append({"step": "⑬b 歷史對齊(歷史覆蓋預估 · 加減乘除檢驗 · 刪除區)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬b 歷史對齊 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **{k: result.get(k) for k in ("totals", "written", "receipt") if k in result}}


def book_source(runtime: Path, output: Path, steps: list) -> dict:
    """⑬a(v0175): BROKER_EN + SOURCE as the last two columns of the output books (JSON / CSV / Parquet · values otherwise untouched); never RED."""
    if os.environ.get("VIA_VRN2_NO_BOOKSOURCE") == "1":
        result = {"lamp": "GRAY", "why": "VIA_VRN2_NO_BOOKSOURCE=1 · 本輪不寫 SOURCE / BROKER_EN 欄"}
    else:
        try:
            module = _load_runtime_module(runtime, BOOK_SOURCE, "vrn2_book_source_entry")
            result = module.apply(Path(output))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = str(result.get("why", ""))
    steps.append({"step": "⑬a 輸出冊 Source / Broker 欄(實體)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬a 輸出冊 Source / Broker 欄 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **{k: result.get(k) for k in ("columns", "unmapped", "summary_cleanup", "module") if k in result}}


def integrate_scan(runtime: Path, output: Path, steps: list) -> dict:
    """⑬c: detect legacy CSV / XLSX / Google-Sheet exports and leave the question to the user in the Workbench (apply only via vrn2://integrate); never RED."""
    if os.environ.get("VIA_VRN2_NO_INTEGRATE") == "1":
        result = {"lamp": "GRAY", "state": "NONE", "why": "VIA_VRN2_NO_INTEGRATE=1 · 本輪不掃舊資料庫"}
    else:
        try:
            module = _load_runtime_module(runtime, DATA_INTEGRATE, "vrn2_data_integrate_entry")
            result = module.scan(Path(output))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "state": "NONE", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = "%s · %s" % (result.get("state", "NONE"), result.get("why", ""))
    steps.append({"step": "⑬c 舊資料庫整合掃描(CSV / XLSX / Google Sheet · 問使用者)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬c 舊資料庫整合掃描 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "state": result.get("state"), "candidates": len(result.get("candidates") or []), "receipt": result.get("receipt")}


def strict_exit_code(steps: list, original_rc: int) -> int:
    if original_rc != 0:
        return original_rc if original_rc in (1, 2, 130) else 1
    if any(entry.get("lamp") == "RED" for entry in steps):
        return 1
    for prefix in CRITICAL_STEPS:
        found = [entry for entry in steps if str(entry.get("step", "")).startswith(prefix)]
        if not found:
            return 1
        if any(entry.get("lamp") != "GREEN" for entry in found):
            return 2
    if any(entry.get("lamp") in ("YELLOW", "GRAY") and str(entry.get("step", "")).startswith("⑥c") for entry in steps):
        return 2
    return 0


def output_gaps(directory: Path) -> list:
    """Required report headings and four summary points must actually be populated."""
    gaps = []
    for stem, required in (("VRN2_BasicInfo_latest", ("FILENAME", "REPORT_DATE", "TICKER", "TITLE")), ("VRN2_Summary_latest", ("TITLE", "POINT_1", "POINT_2", "POINT_3", "POINT_4"))):
        path = directory / (stem + ".json")
        if not path.is_file():
            gaps.append({"book": stem, "reason": "missing output"})
            continue
        rows = json.loads(path.read_text(encoding="utf-8"))
        if not rows:
            gaps.append({"book": stem, "reason": "empty output"})
        for row in rows:
            missing = [key for key in required if not str(row.get(key) or "").strip()]
            if missing:
                gaps.append({"book": stem, "file": row.get("FILENAME"), "missing": missing})
    return gaps


def current_completion(base, comp, steps, comp_mtime, started):
    if comp_mtime < started - 1:
        # The native caller also prints comp.items after checking freshness.
        # Do not attribute an older run's failed items to this run.
        comp.clear()
        comp.update(verdict="本輪未寫出完成判定", red=1, yellow=0, items=[], exceptions=[])
    return base(comp, steps, comp_mtime, started)


def fresh_output_books(directory, started):
    names = ("VRN2_BasicInfo_latest.json", "VRN2_FinancialData_latest.json", "VRN2_Summary_latest.json", "VRN2_SummarySource_latest.json")
    return all((directory / name).is_file() and (directory / name).stat().st_mtime >= started - 1 for name in names)


def update_closeout_ui(path: Path, code: int, gaps: list) -> bool:
    if not path.is_file():
        return False
    label = {0: "GREEN", 1: "RED", 2: "YELLOW"}.get(code, "RED")
    message = "正式收尾通過" if code == 0 else "正式收尾尚未完成，保留待核對項目"
    reasons = "；".join(str(row.get("file", row.get("book", ""))) + ": " + ", ".join(row.get("missing", [row.get("reason", "")])) for row in gaps)
    notice = '<!--VRN2-CLOSEOUT-137-START--><div role="status" id="vrn2-closeout-137" style="padding:10px;margin-bottom:8px;border:2px solid #a66c11;background:#fff6d8;color:#523900"><strong>' + html.escape(label + " · " + message) + '</strong><div>' + html.escape(reasons) + '</div></div><!--VRN2-CLOSEOUT-137-END-->'
    page = path.read_text(encoding="utf-8")
    page = re.sub(r"<!--VRN2-CLOSEOUT-137-START-->.*?<!--VRN2-CLOSEOUT-137-END-->", "", page, flags=re.S)
    page, count = re.subn(r"(<body\b[^>]*>)", lambda match: match.group(1) + notice, page, count=1, flags=re.I)
    if count == 0:
        charset = re.match(r"\s*<meta\b[^>]*charset[^>]*>", page, flags=re.I)
        if charset:
            page = page[:charset.end()] + notice + page[charset.end():]
        else:
            page = '<meta charset="utf-8">\n' + notice + page
    temporary = path.with_suffix(".closeout.tmp")
    temporary.write_text(page, encoding="utf-8")
    temporary.replace(path)
    return True


def repass_wanted(output: Path, attempt: int) -> tuple:
    """A second pass is taken only when the idempotence gate found a stale main record (cache cleared) on the first pass."""
    if attempt >= MAX_PASSES or os.environ.get("VRN2_NO_REPASS") == "1":
        return False, "no re-pass (limit or VRN2_NO_REPASS)"
    path = output / "IDEMPOTENCE_latest.json"
    if not path.is_file():
        return False, "no idempotence receipt"
    try:
        receipt = json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return False, "unreadable idempotence receipt: " + type(error).__name__
    if receipt.get("classification") == "STALE_RECORD":
        return True, "STALE_RECORD · %s · cache cleared %d" % ("、".join(receipt.get("stale_files") or []), len(receipt.get("cache_cleared") or []))
    return False, "idempotence " + str(receipt.get("classification"))


def configure_ui_launcher(runtime, root, launcher=None):
    launcher = Path(launcher or __file__).resolve()
    path = Path(runtime) / "VRN2_UIAction_Config.json"
    config = json.loads(path.read_text(encoding="utf-8"))
    config.update(launcher=str(launcher), root=str(root), version=VERSION)
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    (launcher.parent / CONTEXT_NAME).write_text(json.dumps({"root": str(root)}, ensure_ascii=False, indent=2), encoding="utf-8")


def link_workbench(legacy: Path, workbench: Path) -> bool:
    """Legacy U/I page (written by the manager · reopened by the vrn2:// handler) gets one link bar to the Workbench; rerun replaces the same bar."""
    if not legacy.is_file():
        return False
    try:
        rel = os.path.relpath(workbench, legacy.parent).replace(os.sep, "/")
    except ValueError:
        rel = workbench.as_uri()
    bar = ('<!--VRN2-WORKBENCH-START--><div id="vrn2-workbench-link" style="padding:8px 12px;margin-bottom:8px;border:1px solid #dbd9d3;border-left:4px solid #b5291a;background:#fff;font:600 13px system-ui,sans-serif">'
           '<a href="%s" target="_blank" style="color:#b5291a;text-decoration:none">→ 開啟 VRN-2 Workbench(新 U/I · 範本視覺 · 本輪收據與輸出冊)</a>'
           '<span style="color:#6b6a66;font-weight:400"> · 這一頁是舊版 U/I(每檔細節 · 驗證過的輸出)</span></div><!--VRN2-WORKBENCH-END-->') % html.escape(rel)
    page = legacy.read_text(encoding="utf-8")
    page = re.sub(r"<!--VRN2-WORKBENCH-START-->.*?<!--VRN2-WORKBENCH-END-->", "", page, flags=re.S)
    page, count = re.subn(r"(<body\b[^>]*>)", lambda match: match.group(1) + bar, page, count=1, flags=re.I)
    if count == 0:
        page = bar + page
    temporary = legacy.with_suffix(".workbench.tmp")
    temporary.write_text(page, encoding="utf-8")
    temporary.replace(legacy)
    return True


def render_workbench(runtime: Path, root: Path, output: Path) -> dict:
    """Render the Workbench from the receipts just written; never fails the run (YELLOW on error)."""
    module_path = Path(runtime) / WORKBENCH
    try:
        specification = importlib.util.spec_from_file_location("vrn2_workbench_entry", module_path)
        module = importlib.util.module_from_spec(specification)
        sys.modules[specification.name] = module
        specification.loader.exec_module(module)
        path = module.render(root)
        linked = link_workbench(output / "VRN2_UI_latest.html", path)
        return {"lamp": "GREEN", "path": str(path), "version": getattr(module, "VERSION", "?"), "legacy_linked": linked, "detail": "%s · %s · 舊版 U/I 連結 %s" % (getattr(module, "VERSION", "?"), path, "已加" if linked else "沒有舊版頁")}
    except Exception as error:  # noqa: BLE001
        return {"lamp": "YELLOW", "path": "", "detail": "Workbench 沒渲染:%s: %s" % (type(error).__name__, str(error)[:160])}


def open_page(workbench: Path | None, base, output: Path) -> str:
    """Open the Workbench (Windows default browser); without it fall back to the legacy U/I; non-Windows prints the path."""
    if workbench and workbench.is_file():
        if hasattr(os, "startfile"):
            try:
                os.startfile(str(workbench))  # type: ignore[attr-defined]
                return "已送出瀏覽器開啟要求:%s" % workbench
            except OSError as error:
                return "開不了 %s(%s)· 請手動開" % (workbench, error.__class__.__name__)
        return "非 Windows · Workbench 在 %s" % workbench
    return base._ui_open(output, False)


_SELFTEST_CACHE = {}


def selftest_source(name: str) -> Path:
    """v0147: a runtime module for --selftest — next to the launcher → ../new (build tree) → taken out of the package's runtime zip (verified against its manifest)."""
    for candidate in (Path(__file__).with_name(name), Path(__file__).resolve().parent.parent / "new" / name):
        if candidate.is_file():
            return candidate
    if name in _SELFTEST_CACHE:
        return _SELFTEST_CACHE[name]
    archive, manifest = Path(__file__).with_name(RUNTIME_ZIP), Path(__file__).with_name(RUNTIME_MANIFEST)
    if not archive.is_file():
        raise FileNotFoundError("selftest needs %s (not next to the launcher, no %s)" % (name, RUNTIME_ZIP))
    expected = {}
    if manifest.is_file():
        expected = {entry["path"]: entry["sha256"] for entry in json.loads(manifest.read_text(encoding="utf-8")).get("files", [])}
    with zipfile.ZipFile(archive) as bundle:
        data = bundle.read(name)
    if expected and hashlib.sha256(data).hexdigest() != expected.get(name):
        raise ValueError("%s in %s does not match %s" % (name, RUNTIME_ZIP, RUNTIME_MANIFEST))
    folder = Path(tempfile.mkdtemp(prefix="vrn2-selftest-src-"))
    target = folder / name
    target.write_bytes(data)
    _SELFTEST_CACHE[name] = target
    return target


SELFTEST_ENV_CLEAR = ("VRN2_OUTPUT_DIR", "VIA_VRN2_NO_BOOKSOURCE", "VIA_VRN2_NO_MARKET", "VIA_VRN2_NO_CONSENSUS", "VIA_VRN2_NO_HISTORY", "VIA_VRN2_NO_INTEGRATE", "VRN2_CONSENSUS_FIXTURES", "VRN2_INTEGRATE_DIRS",
                      "VRN2_NO_REPASS", "VRN2_FORCE_PARALLEL", "VIA_FETCH_PY", "VRN2_UI_REFRESH_WAIT", "VRN2_SILENT_MAX", "VRN2_MANIFEST_WAIT", "VIA_VRN2_VERIFY_WAIT", "VRN2_MARKET_WAIT", "VRN2_CONSENSUS_WAIT")


def selftest() -> int:
    """v0147: hermetic — run-time switches the operator may have set (VRN2_OUTPUT_DIR seeds ⑬ · the wait limits · the step opt-outs) are cleared for the
    selftest and restored afterwards; v0144–v0146 failed their own ⑬ / limits checks whenever VRN2_OUTPUT_DIR or a limit was set in the shell."""
    saved = {key: os.environ.pop(key) for key in SELFTEST_ENV_CLEAR if key in os.environ}
    try:
        return _selftest_body()
    finally:
        for key in SELFTEST_ENV_CLEAR:
            os.environ.pop(key, None)
        os.environ.update(saved)


def _selftest_body() -> int:
    complete = [{"step": prefix, "lamp": "GREEN"} for prefix in CRITICAL_STEPS]
    assert strict_exit_code(complete, 0) == 0
    assert strict_exit_code(complete + [{"step": "⑧", "lamp": "RED"}], 0) == 1
    assert strict_exit_code(complete[:-1], 0) == 1
    assert strict_exit_code(complete[:-1] + [{"step": "⑪", "lamp": "YELLOW"}], 0) == 2
    assert strict_exit_code([], 1) == 1
    with tempfile.TemporaryDirectory(prefix="vrn2-private-check-") as temporary:
        root = Path(temporary)
        shared = root / "functional modules" / "VRN"
        shared.mkdir(parents=True)
        protected = shared / "VRN_SystemManager_v0153.py"
        protected.write_text("protected original", encoding="utf-8")
        runtime = restore_private_runtime(root)
        assert protected.read_text(encoding="utf-8") == "protected original"
        assert "def _vdf_home" in (runtime / "VRN_SystemManager_v0153.py").read_text(encoding="utf-8")
        assert (runtime / "rule_catalog_runtime.json").is_file()
        hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in runtime.iterdir()}
        restore_private_runtime(root)
        assert hashes == {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in runtime.iterdir()}
        (runtime / "VRN_SystemManager_v0153.py").write_text("different local content", encoding="utf-8")
        try:
            restore_private_runtime(root)
        except ValueError:
            pass
        else:
            raise AssertionError("Different local runtime must not be overwritten")
        cfg = runtime / "VRN2_UIAction_Config.json"
        cfg.write_text(json.dumps({"launcher": "old.py", "python": "python", "v2": "output"}), encoding="utf-8")
        launcher = root / "package" / "ActivateVRN-2_v0158.py"
        launcher.parent.mkdir()
        configure_ui_launcher(runtime, root, launcher)
        assert json.loads(cfg.read_text())["launcher"] == str(launcher)
        assert json.loads((launcher.parent / CONTEXT_NAME).read_text())["root"] == str(root)
        reports = root / "VIA_Reports" / "vrn2"
        reports.mkdir(parents=True)
        assert repass_wanted(reports, 1) == (False, "no idempotence receipt")
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "STALE_RECORD", "stale_files": ["a.pdf"], "cache_cleared": ["k.json"]}), encoding="utf-8")
        assert repass_wanted(reports, 1)[0] and not repass_wanted(reports, 2)[0]
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "NONDETERMINISTIC"}), encoding="utf-8")
        assert not repass_wanted(reports, 1)[0]
        os.environ["VRN2_NO_REPASS"] = "1"
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "STALE_RECORD"}), encoding="utf-8")
        assert not repass_wanted(reports, 1)[0]
        os.environ.pop("VRN2_NO_REPASS", None)
    with tempfile.TemporaryDirectory(prefix="vrn2-workbench-check-") as temporary:
        folder = Path(temporary)
        legacy = folder / "VRN2_UI_latest.html"
        legacy.write_text("<html><body><p>ui</p></body></html>", encoding="utf-8")
        wb = folder / "VRN2_Workbench_latest.html"
        wb.write_text("<html></html>", encoding="utf-8")
        assert link_workbench(legacy, wb) and link_workbench(legacy, wb)
        page = legacy.read_text(encoding="utf-8")
        assert page.count('id="vrn2-workbench-link"') == 1 and 'href="VRN2_Workbench_latest.html"' in page and page.index("vrn2-workbench-link") < page.index("<p>ui")
        assert not link_workbench(folder / "missing.html", wb)
        broken = render_workbench(folder, folder, folder)
        assert broken["lamp"] == "YELLOW" and not broken["path"]
        assert open_page(None, type("B", (), {"_ui_open": staticmethod(lambda o, n: "legacy")})(), folder) == "legacy"
    with tempfile.TemporaryDirectory(prefix="vrn2-guard-check-") as temporary:
        folder = Path(temporary)
        out = folder / "VIA_Reports" / "vrn2"
        assert pid_alive(os.getpid()) and not pid_alive(0) and not pid_alive(2 ** 22 + 12345)
        ok1, g1 = acquire_lock(out)
        assert ok1 and g1["why"] == "新鎖" and (out / LOCK_NAME).is_file()
        ok2, g2 = acquire_lock(out)
        assert not ok2 and g2["alive"] and "另一個 VRN-2 啟動器還在跑" in g2["why"] and json.loads((out / LOCK_NAME).read_text(encoding="utf-8"))["pid"] == os.getpid()
        os.environ["VRN2_FORCE_PARALLEL"] = "1"
        ok3, g3 = acquire_lock(out)
        os.environ.pop("VRN2_FORCE_PARALLEL", None)
        assert ok3 and "並行" in g3["why"]
        (out / LOCK_NAME).write_text(json.dumps({"pid": 2 ** 22 + 12345, "version": "old"}), encoding="utf-8")
        ok4, g4 = acquire_lock(out)
        assert ok4 and "過期鎖" in g4["why"]
        release_lock(out)
        assert not (out / LOCK_NAME).is_file()
        (out / LOCK_NAME).write_text(json.dumps({"pid": 1}), encoding="utf-8")
        release_lock(out)
        assert (out / LOCK_NAME).is_file()  # someone else's lock is never removed
        os.environ["VRN2_UI_REFRESH_WAIT"] = "700"
        os.environ["VRN2_SILENT_MAX"] = "10"  # below floor → 60
        lim = limits()
        os.environ.pop("VRN2_UI_REFRESH_WAIT", None)
        os.environ.pop("VRN2_SILENT_MAX", None)
        assert lim["VRN2_UI_REFRESH_WAIT"] == 700 and lim["VRN2_SILENT_MAX"] == 60 and lim["VIA_VRN2_VERIFY_WAIT"] == 3600
        lim = limits()
        assert run_limits(["python", "h.py", "--refresh-ui", "--v2", "x"], 120, {}, lim) == (600, {"silent_max": 600})
        assert run_limits(["python", "m.py", "vrn2", "--run", "--no-open"], 7200, {}, lim) == (7200, {"silent_max": 3600})
        assert run_limits(["python", "b.py", "manifest", "root"], 300, {}, lim)[0] == 900
        assert run_limits(["git", "status"], 120, {}, lim) == (120, {})
        runtime = folder / "rt"
        runtime.mkdir()
        (runtime / UI_HANDLER).write_text("from pathlib import Path\ndef patch_ui(v2):\n    p = Path(v2) / 'VRN2_UI_latest.html'\n    p.write_text(p.read_text(encoding='utf-8').replace('</body>', '<!--vrn2-input-->blk<!--/vrn2-input--></body>'), encoding='utf-8')\n    return True, 'fixture block'\n", encoding="utf-8")
        steps = [{"step": "⑫b U/I 輸入區塊(window I/O)", "lamp": "YELLOW", "detail": "[RED] 逾時 120 秒"}]
        assert ensure_input_block(runtime, out, steps)["how"] == "none"
        (out / "VRN2_UI_latest.html").write_text("<html><body>ui</body></html>", encoding="utf-8")
        got = ensure_input_block(runtime, out, steps)
        assert got["how"] == "in-process" and got["lamp"] == "GREEN" and steps[-1]["lamp"] == "GREEN" and "<!--vrn2-input-->" in (out / "VRN2_UI_latest.html").read_text(encoding="utf-8")
        assert ensure_input_block(runtime, out, steps)["how"] == "子行程"
        (runtime / UI_HANDLER).write_text("def patch_ui(v2):\n    raise RuntimeError('boom')\n", encoding="utf-8")
        (out / "VRN2_UI_latest.html").write_text("<html><body>ui</body></html>", encoding="utf-8")
        steps2 = []
        got2 = ensure_input_block(runtime, out, steps2)
        assert got2["lamp"] == "YELLOW" and steps2 and "RuntimeError" in steps2[-1]["detail"]
    with tempfile.TemporaryDirectory(prefix="vrn2-v0145-check-") as temporary:   # v0145 checks kept verbatim
        folder = Path(temporary)
        runtime = folder / "rt"
        runtime.mkdir()
        for name in (SSOT_SYNC, "VRN2_SSOTSync_v0100.py", OUTPUT_STORE_ACTIVE, "VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py", BOOK_SOURCE, "VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py"):   # thin tails need their prior next to them (v0164: v0102 active)
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        output = folder / "VIA_Reports" / "vrn2"
        (output / "output").mkdir(parents=True)
        (output / "scope_in").mkdir()
        steps = []
        got = ssot_sync(runtime, steps)
        assert got["lamp"] == "GRAY" and steps[-1]["step"].startswith("⑤b") and "登記冊" in steps[-1]["detail"]
        (runtime / "registry").mkdir()
        (runtime / "registry" / "VRN2_Component_Register_v0100.json").write_text(json.dumps({"entries": {"SSOT|A": {"no": "VRN2-SSOT-0001", "kind": "SSOT", "key": "A", "status": "暫編 · 待 VCGC 核號", "fp": "x"}}}), encoding="utf-8")
        got = ssot_sync(runtime, steps)
        assert got["lamp"] == "GREEN" and got["apply"]["pending"] == 1 and (runtime / "contract" / "VRN2_NUMBER_REQUEST_latest.json").is_file()
        got = output_store(runtime, output, "t1", steps)
        assert got["lamp"] == "GRAY" and steps[-1]["step"].startswith("⑬") and "未設定" in steps[-1]["detail"]
        (output / "scope_in" / "a.pdf").write_bytes(b"A")
        (output / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TICKER": "2330"}]), encoding="utf-8")
        for book in ("FinancialData", "Summary", "Rejected"):
            (output / "output" / ("VRN2_%s_latest.json" % book)).write_text("[]", encoding="utf-8")
        os.environ["VRN2_OUTPUT_DIR"] = str(folder / "OneDrive" / "out")
        got = output_store(runtime, output, "t2", steps)
        os.environ.pop("VRN2_OUTPUT_DIR", None)
        assert got["lamp"] in ("GREEN", "YELLOW") and (folder / "OneDrive" / "out" / "VRN2" / "latest" / "VRN2_BasicInfo_latest.json").is_file()
        if got.get("store_engine") != "none":
            assert got["new_files"] == ["a.pdf"] and got["appended"]["BasicInfo"] == 1
        assert json.loads((output / "VRN2_Output_Config.json").read_text(encoding="utf-8"))["how"].startswith("環境變數")
        got2 = output_store(runtime, output, "t3", steps)
        assert got2["new_files"] == [] and sum(got2["appended"].values()) == 0  # engine none → both empty as well
    with tempfile.TemporaryDirectory(prefix="vrn2-v0146-check-") as temporary:
        folder = Path(temporary)
        root = folder / "VIA"
        runtime = root / "functional modules" / "VRN2"
        runtime.mkdir(parents=True)
        for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0102.py", "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN_ACTIVE, "VRN2_ConsensusJoin_v0106.py", "VRN2_ConsensusJoin_v0105.py", CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        output = root / "VIA_Reports" / "vrn2"
        (output / "output").mkdir(parents=True)
        lim = limits()
        steps = []
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "GRAY" and "沒有 VRN2_MarketFetch" in steps[-1]["detail"] and steps[-1]["step"].startswith("⑥e")
        shared = root / "functional modules" / "VRN"
        shared.mkdir(parents=True)
        (shared / "VRN2_MarketFetch_v0112.py").write_text("import sys\nv = sys.argv[1]\nprint('[計] 心跳')\nprint('[計] 市場擷取 · GREEN · 擷取 2 代號' if v == '--fetch' else '[計] 市場填值 · YELLOW · 完整 1 · 部分 1')\n", encoding="utf-8")
        (shared / "VRN2_MarketFetch_v0101.py").write_text("print('old')\n", encoding="utf-8")
        assert shared_market_tool(root).name == "VRN2_MarketFetch_v0112.py"
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "GRAY" and "沒有基本資料冊" in got["detail"]
        (output / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TICKER": "2330", "REPORT_DATE": "2026-01-01", "TARGET_PRICE": "100", "BROKER": "A"}]), encoding="utf-8")
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "YELLOW" and got["results"]["--fetch"]["lamp"] == "GREEN" and got["results"]["--fill"]["lamp"] == "YELLOW" and "擷取 GREEN:擷取 2 代號" in got["detail"]
        os.environ["VIA_VRN2_NO_MARKET"] = "1"
        assert market_fetch(root, output, steps, lim)["lamp"] == "GRAY"
        os.environ.pop("VIA_VRN2_NO_MARKET", None)
        os.environ["VIA_VRN2_NO_CONSENSUS"] = "1"
        got = consensus_join(runtime, root, output, steps, lim)
        os.environ.pop("VIA_VRN2_NO_CONSENSUS", None)
        assert got["lamp"] in ("GRAY", "YELLOW") and got["run"]["lamp"] == "GRAY" and got["join"]["rows"] == 1 and steps[-1]["step"].startswith("⑥f") and (output / "output" / "VRN2_Combined_latest.json").is_file()
        combined = json.loads((output / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
        assert list(combined[0].keys())[9:13] == ["TARGET_PRICE", "TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN"] and combined[0]["TARGET_PRICE"] == "100"
        got = history_align(runtime, root, output, steps)
        assert got["lamp"] == "GRAY" and "沒有年度數據冊" in got["detail"] and steps[-1]["step"].startswith("⑬b")
        (output / "output" / "VRN2_FinancialData_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "ITEM": "Revenue", "PERIOD": "2025A", "VALUE": "1,000"}]), encoding="utf-8")
        got = history_align(runtime, root, output, steps)
        assert got["lamp"] == "GRAY" and "沒有市場資料" in got["detail"] and (output / "VRN2_HistoryAlign_latest.json").is_file()
        os.environ["VIA_VRN2_NO_HISTORY"] = "1"
        assert history_align(runtime, root, output, steps)["lamp"] == "GRAY"
        os.environ.pop("VIA_VRN2_NO_HISTORY", None)
        os.environ["VRN2_INTEGRATE_TEMP"] = str(folder / "temp")
        got = integrate_scan(runtime, output, steps)
        assert got["lamp"] == "GRAY" and got["state"] == "NONE" and steps[-1]["step"].startswith("⑬c")
        (output / "legacy_in").mkdir()
        (output / "legacy_in" / "old - Sheet1.csv").write_text("Ticker,Date,Broker,Target Price\n2330,2025-10-01,CLSA,1200\n", encoding="utf-8-sig")
        got = integrate_scan(runtime, output, steps)
        assert got["lamp"] == "YELLOW" and got["state"] == "PENDING_USER" and got["candidates"] == 1 and (output / "VRN2_Integrate_latest.json").is_file()
        os.environ.pop("VRN2_INTEGRATE_TEMP", None)
        complete = [{"step": prefix, "lamp": "GREEN"} for prefix in CRITICAL_STEPS]
        assert strict_exit_code(complete + [{"step": "⑥e 市場擷取", "lamp": "YELLOW"}, {"step": "⑬b 歷史對齊", "lamp": "GRAY"}], 0) == 0   # non-critical steps never change the code
    saved = {k: os.environ.get(k) for k in ("VIA_FETCH_PY", "USERPROFILE", "HOME")}
    with tempfile.TemporaryDirectory(prefix="vrn2-v0147-check-") as temporary:
        home = Path(temporary)
        os.environ.pop("VIA_FETCH_PY", None)
        os.environ["USERPROFILE"] = str(home)
        os.environ["HOME"] = str(home)
        assert market_python() == sys.executable
        env_py = home / "envs" / "via_tw_fetch" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        env_py.parent.mkdir(parents=True)
        env_py.write_text("", encoding="utf-8")
        assert market_python() == str(env_py)
        os.environ["VIA_FETCH_PY"] = sys.executable
        assert market_python() == sys.executable
    for key, value in saved.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value
    body = Path(__file__).read_text(encoding="utf-8")
    assert body.index('receipt["history_align"] = history_align(') < body.index("    store = output_store(runtime, output,")
    with tempfile.TemporaryDirectory(prefix="vrn2-v0148-check-") as temporary:
        folder = Path(temporary)
        root = folder / "VIA"
        runtime = root / "functional modules" / "VRN2"
        runtime.mkdir(parents=True)
        for name in (CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py", HISTORY_ALIGN, "VRN2_HistoryAlign_v0102.py", "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", UI_HANDLER, "VRN2_UIAction_v0109.py", "VRN2_UIAction_v0108.py"):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        output = root / "VIA_Reports" / "vrn2"
        (output / "market").mkdir(parents=True)
        (output / "market" / "VRN2_Market_latest.json").write_text(json.dumps({"per_ticker": {"5274": {"yfinance_ticker": "5274.TWO"}}, "per_file": {"a.pdf": {"yfinance_ticker": "2330.TW"}}}), encoding="utf-8")
        cj = _load_runtime_module(runtime, CONSENSUS_JOIN, "vrn2_consensus_join_v0148_check")
        assert cj.VERSION == "v0104" and cj.PRIOR.VERSION == "v0103" and cj.PRIOR.PRIOR.VERSION == "v0102" and cj.PRIOR.PRIOR.PRIOR.VERSION == "v0101" and cj.ticker_map(output) == {"5274": "5274.TWO", "2330": "2330.TW"}
        ha = _load_runtime_module(runtime, HISTORY_ALIGN, "vrn2_history_align_v0148_check")
        assert ha.VERSION == "v0103" and ha.PRIOR.VERSION == "v0102" and ha.BASE._write_books is ha._write_books and ha.std_of("Other Revenue") == "" and ha.std_of("Total Revenue") == "revenue" and ha.std_of("Taxes payable") == ""
        ui = _load_runtime_module(runtime, UI_HANDLER, "vrn2_uiaction_v0148_check")
        assert ui.VERSION == "v0110" and "VIA_ROOT" in ui.SELFTEST_ENV_CLEAR and hasattr(ui, "patch_ui")
    saved_fetch = os.environ.get("VIA_FETCH_PY")
    with tempfile.TemporaryDirectory(prefix="vrn2-v0149-check-") as temporary:
        folder = Path(temporary)
        root = folder / "VIA"
        runtime = root / "functional modules" / PRIVATE_FOLDER
        runtime.mkdir(parents=True)
        for name in (VERBATIM, "VRN2_VerbatimVerifier_v0104.py", MARKET_RUNNER):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        vv = _load_runtime_module(runtime, VERBATIM, "vrn2_verbatim_v0149_check")
        assert vv.VERSION == "v0105" and vv.comparable("Type-\nC PD") == vv.comparable("Type\ufffeC PD") == vv.comparable("Type\x02C PD") and vv.comparable("Type-C") != vv.comparable("TypeC")
        mr = _load_runtime_module(runtime, MARKET_RUNNER, "vrn2_marketrun_v0149_check")
        assert mr.VERSION == "v0100" and mr.requirements(None)[0] == mr.FALLBACK_REQUIREMENTS and len(mr.FALLBACK_REQUIREMENTS) == 6
        shared = root / "functional modules" / "VRN"
        (shared / "_vdf_fetch").mkdir(parents=True)
        (shared / "_vdf_fetch" / "VDF_TW_AllInOne_v099.py").write_text("DEPENDENCY_REQUIREMENTS = ()\n", encoding="utf-8")
        (shared / "VRN2_MarketFetch_v0199.py").write_text(
            "import sys\nfrom pathlib import Path\nHERE = Path(__file__).resolve().parent\nPROBE = \"import json; print('ok')\"\n"
            "def engine_path():\n    return HERE / '_vdf_fetch' / 'VDF_TW_AllInOne_v099.py'\n"
            "def fetch_python():\n    return 'WRONG-via_tw_fetch'\n"
            "def main(argv):\n    print('[計] 市場%s · GREEN · py=%s' % ('擷取' if '--fetch' in argv else '填值', fetch_python()))\n    return 0\n", encoding="utf-8")
        output = root / "VIA_Reports" / "vrn2"
        (output / "output").mkdir(parents=True)
        (output / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TICKER": "2330"}]), encoding="utf-8")
        os.environ["VIA_FETCH_PY"] = sys.executable
        steps = []
        got = market_fetch(root, output, steps, limits())
        if sys.version_info >= (3, 11):
            assert got["lamp"] == "GREEN" and got["runner"] == MARKET_RUNNER and got["fetch_python"]["python"] == sys.executable, got
            assert got["results"]["--fetch"]["msg"] == "py=" + sys.executable, got["results"]
    if saved_fetch is None:
        os.environ.pop("VIA_FETCH_PY", None)
    else:
        os.environ["VIA_FETCH_PY"] = saved_fetch
    with tempfile.TemporaryDirectory(prefix="vrn2-v0150-check-") as temporary:
        runtime = Path(temporary) / "VIA" / "functional modules" / PRIVATE_FOLDER
        runtime.mkdir(parents=True)
        for name in (CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        cj = _load_runtime_module(runtime, CONSENSUS_JOIN, "vrn2_consensus_join_v0150_check")
        rows = [{"code": c, "check_id": "FETCH_PIPELINE", "actual": "TARGET_PRICE_STATUS_NOT_200: statusCode=404 message=頁面或商品不存在", "status": "FAIL"} for c in ("6933", "4171")]
        assert cj.VERSION == "v0104" and sorted(cj.no_coverage(rows, ["2330", "6933", "4171"])) == ["4171", "6933"]
        assert cj.no_coverage(rows + [{"code": "2330", "check_id": "HTTP_PAGE_200", "actual": "500", "status": "FAIL"}], ["2330", "6933", "4171"]) == {}
        assert cj.PRIOR.run is cj.run and cj.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.PRIOR.run is cj.run
        assert cj.PRIOR.PRIOR.PRIOR.PRIOR.join is cj.join and cj.join is cj.PRIOR.join                                          # v0156: v0104 run · v0103 join
        assert cj.provenance_refresh(Path(temporary) / "none", "/no/engine.py", gate_open=True).get("archived") is None          # no engine → nothing archived
        transient = [{"code": "8358", "check_id": "FETCH_PIPELINE", "actual": "ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__", "status": "FAIL"}]
        nopage, blip, other = cj.classify(rows + transient + [{"code": "2330", "check_id": "HTTP_PAGE_200", "actual": "500", "status": "FAIL"}], ["2330", "6933", "4171", "8358"])
        assert sorted(nopage) == ["4171", "6933"] and list(blip) == ["8358"] and [r["code"] for r in other] == ["2330"]          # v0154: 404 · transient · other
        assert cj.seed_checkpoint(Path(temporary) / "none", "/no/engine.py", ["2330"]).get("seeded") == 0                       # nothing to move → the engine fetches as before
    body = Path(__file__).read_text(encoding="utf-8")
    assert '"%s(合 VDF 界線 · %s)" % (picked["python"]' in body
    m257 = selftest_source("VRN_SystemManager_v0257.py").read_text(encoding="utf-8")
    assert 'TAG = "v0257"' in m257 and 'PRIOR_NAME = "VRN_SystemManager_v0255.py"' in m257 and "def _rowfix(" in m257 and '_out_books = _timed("輸出冊", _out_books_v0257)' in m257
    m258 = selftest_source("VRN_SystemManager_v0258.py").read_text(encoding="utf-8")
    assert 'TAG = "v0258"' in m258 and 'PRIOR_NAME = "VRN_SystemManager_v0257.py"' in m258 and "def _zone_repair(" in m258 and '_out_books = _timed("輸出冊", _out_books_v0258)' in m258
    assert "def _zr_same_line(" in m258 and "def _zr_regrid(" in m258 and "_ZR_REASON" in m258
    wb105 = selftest_source("VRN2_Workbench_v0105.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0105"' in wb105 and "def _prior_path(" in wb105 and "def augment(" in wb105 and "資料驗證狀況" in wb105 and "wb105-css" in wb105
    wb107 = selftest_source("VRN2_Workbench_v0107.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0107"' in wb107 and wb107.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]" and '_SKIP_MARK = "wb105-css"' in wb107
    assert "def basic_merged(" in wb107 and "def upside_check(" in wb107 and "def parquet_check(" in wb107 and 'id="wb107b"' in wb107 and "Basic Info · 合併檢視" in wb107
    wb108 = selftest_source("VRN2_Workbench_v0108.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0108"' in wb108 and 'PRIOR_NAME = "VRN2_Workbench_v0107.py"' in wb108 and wb108.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    assert 'id="wb108-tpl"' in wb108 and "def freshness(" in wb108 and "def norm_period(" in wb108 and "def source_of(" in wb108 and "BROKER_ABBR = {" in wb108 and "@CSS_SHA256@" not in wb108
    wb109 = selftest_source("VRN2_Workbench_v0109.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0109"' in wb109 and 'PRIOR_NAME = "VRN2_Workbench_v0108.py"' in wb109 and wb109.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    assert 'id="wb109-tpl"' in wb109 and "def acceptance_rows(" in wb109 and "def input_classes(" in wb109 and "def summary_section(" in wb109 and "@CSS_SHA256@" not in wb109
    bs100 = selftest_source("VRN2_BookSource_v0100.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0100"' in bs100 and 'COLS = ("BROKER_EN", "SOURCE")' in bs100 and "def apply(" in bs100 and bs100.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    st103 = selftest_source("VRN2_OutputStore_v0103.py").read_text(encoding="utf-8")
    assert 'TAG = "v0103"' in st103 and 'PRIOR_NAME = "VRN2_OutputStore_v0102.py"' in st103 and 'DERIVED = ("BROKER_EN", "SOURCE")' in st103 and "def fill_source(" in st103
    bs101 = selftest_source("VRN2_BookSource_v0101.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0101"' in bs101 and 'PRIOR_NAME = "VRN2_BookSource_v0100.py"' in bs101 and "def strip_lead(" in bs101 and "def compose(" in bs101 and bs101.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    st104 = selftest_source("VRN2_OutputStore_v0104.py").read_text(encoding="utf-8")
    assert 'TAG = "v0104"' in st104 and 'PRIOR_NAME = "VRN2_OutputStore_v0103.py"' in st104 and "def tidy_summary(" in st104 and "def row_hash104(" in st104 and st104.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    bs102 = selftest_source(BOOK_SOURCE).read_text(encoding="utf-8")
    assert 'VERSION = "v0102"' in bs102 and 'PRIOR_NAME = "VRN2_BookSource_v0101.py"' in bs102 and "def money(" in bs102 and "V0101.compose = compose" in bs102 and bs102.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    st105 = selftest_source(OUTPUT_STORE_ACTIVE).read_text(encoding="utf-8")
    assert 'TAG = "v0105"' in st105 and 'PRIOR_NAME = "VRN2_OutputStore_v0104.py"' in st105 and st105.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    wb111 = selftest_source(WORKBENCH).read_text(encoding="utf-8")
    assert 'VERSION = "v0111"' in wb111 and 'PRIOR_NAME = "VRN2_Workbench_v0110.py"' in wb111 and 'id="wb111-tpl"' in wb111 and "def augment111(" in wb111 and "@CSS_SHA256@" not in wb111 and wb111.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    wb110 = selftest_source("VRN2_Workbench_v0110.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0110"' in wb110 and 'PRIOR_NAME = "VRN2_Workbench_v0109.py"' in wb110 and 'id="wb110-tpl"' in wb110 and "def augment110(" in wb110 and "@CSS_SHA256@" not in wb110
    m260 = selftest_source(MANAGER).read_text(encoding="utf-8")
    assert 'TAG = "v0260"' in m260 and 'PRIOR_NAME = "VRN_SystemManager_v0259.py"' in m260 and 'PAGE_FRAGMENT = r"^page_\\d{3,5}(?:_[0-9a-f]{6,})?\\.pdf$"' in m260 and "def vrn2scope(" in m260
    assert WORKBENCH == "VRN2_Workbench_v0111.py" and VERBATIM == "VRN2_VerbatimVerifier_v0105.py" and OUTPUT_STORE_ACTIVE == "VRN2_OutputStore_v0105.py" and BOOK_SOURCE == "VRN2_BookSource_v0102.py" and MANAGER == "VRN_SystemManager_v0260.py"
    body175 = Path(__file__).read_text(encoding="utf-8")
    assert body175.rindex('receipt["history_align"] = history_align(') < body175.rindex('receipt["book_source"] = book_source(') < body175.rindex("    store = output_store(runtime, output,")
    with tempfile.TemporaryDirectory(prefix="vrn2-v0175-check-") as temporary175:
        runtime175, output175 = Path(temporary175) / "rt", Path(temporary175) / "VIA_Reports" / "vrn2"
        runtime175.mkdir()
        for name175 in (BOOK_SOURCE, "VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py"):
            shutil.copy2(str(selftest_source(name175)), str(runtime175 / name175))
        steps175 = []
        assert book_source(runtime175, output175, steps175)["lamp"] == "GRAY" and steps175[-1]["step"].startswith("⑬a")
        (output175 / "output").mkdir(parents=True)
        (output175 / "output" / "VRN2_FinancialData_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "BROKER": "凱基", "PERIOD": "2026E", "VALUE": "1"}], ensure_ascii=False), encoding="utf-8")
        got175 = book_source(runtime175, output175, steps175)
        row175 = json.loads((output175 / "output" / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))[0]
        assert got175["lamp"] == "GREEN" and list(row175)[-2:] == ["BROKER_EN", "SOURCE"] and row175["BROKER_EN"] == "KGI" and row175["SOURCE"] == "報告預估" and row175["BROKER"] == "凱基"
        os.environ["VIA_VRN2_NO_BOOKSOURCE"] = "1"
        try:
            assert book_source(runtime175, output175, steps175)["lamp"] == "GRAY"
        finally:
            os.environ.pop("VIA_VRN2_NO_BOOKSOURCE", None)
        summ176 = {"REPORT_DATE": "2026-05-20", "FILENAME": "b.pdf", "TICKER": "9999", "BROKER": "凱基", "TITLE": "- 標題甲",
                   "POINT_1": "\u27a2 營收成長", "POINT_2": "\u2022 目標價 120 元,上漲空間 20%", "POINT_3": "\u26ab 毛利率回升", "POINT_4": "下半年出貨"}
        comb176 = {"REPORT_DATE": "2026-05-20", "FILENAME": "b.pdf", "TICKER": "9999", "YFINANCE_TICKER": "9999.TW", "NAME": "示例公司", "BROKER": "凱基", "RATING": "買進",
                   "TARGET_PRICE": "120", "TARGET_PRICE(ADJ)": "118.00", "ADJ_CLOSE": "100.00", "TOPIC & SUMMARY": "舊", "STATUS": "x"}
        (output175 / "output" / "VRN2_Summary_latest.json").write_text(json.dumps([summ176], ensure_ascii=False), encoding="utf-8")
        (output175 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps([comb176], ensure_ascii=False), encoding="utf-8")
        got176 = book_source(runtime175, output175, steps175)
        s176 = json.loads((output175 / "output" / "VRN2_Summary_latest.json").read_text(encoding="utf-8"))[0]
        c176 = json.loads((output175 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))[0]
        assert got176["lamp"] == "GREEN" and s176["POINT_1"] == "營收成長" and s176["POINT_2"].startswith("目標價 120") and s176["TITLE"] == "標題甲" and s176["POINT_4"] == "下半年出貨"
        assert c176["TOPIC & SUMMARY"].startswith("示例公司(9999.TW, 買進) - 標題甲 · 目標價 120 元,上漲空間 18.00%") and "調整後目標價 118.00 ÷ 調整後收盤 100.00 = 上漲空間 18.00%" in c176["TOPIC & SUMMARY"]
        assert (got176.get("summary_cleanup") or {}).get("upside_rows") == 1 and list(c176)[-2:] == ["BROKER_EN", "SOURCE"] and steps175[-1]["step"].startswith("⑬a")
        again176 = book_source(runtime175, output175, steps175)
        assert (again176.get("summary_cleanup") or {}).get("topic_rows") == 0 and json.loads((output175 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))[0] == c176
    cj106 = selftest_source("VRN2_ConsensusJoin_v0106.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0106"' in cj106 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0105.py"' in cj106 and "def snapshot_fill(" in cj106 and "VIA_VRN2_NO_SNAPSHOT" in cj106
    cj107 = selftest_source("VRN2_ConsensusJoin_v0107.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0107"' in cj107 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0106.py"' in cj107 and 'NEW_COL = "UPSIDE_ADJ"' in cj107 and 'OLD_COL = "UPSIDE_PCT(ADJ)"' in cj107
    assert CONSENSUS_JOIN_ACTIVE == "VRN2_ConsensusJoin_v0107.py"
    ha103 = selftest_source("VRN2_HistoryAlign_v0103.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0103"' in ha103 and 'PRIOR_NAME = "VRN2_HistoryAlign_v0102.py"' in ha103 and "def write_typed_parquet(" in ha103 and "BASE._write_books = _write_books" in ha103
    assert HISTORY_ALIGN == "VRN2_HistoryAlign_v0103.py"
    m259 = selftest_source("VRN_SystemManager_v0259.py").read_text(encoding="utf-8")
    assert 'TAG = "v0259"' in m259 and 'PRIOR_NAME = "VRN_SystemManager_v0258.py"' in m259 and "def _tj_recheck(" in m259 and '_out_books = _timed("輸出冊", _out_books_v0259)' in m259
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            mgr = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN_SystemManager_v\d{4}\.py", n))
        assert mgr[-1] == "VRN_SystemManager_v0260.py" and "VRN_SystemManager_v0259.py" in mgr and "VRN_SystemManager_v0258.py" in mgr and "VRN_SystemManager_v0257.py" in mgr and "VRN_SystemManager_v0255.py" in mgr and "VRN_SystemManager_v0243.py" in mgr, mgr[-3:]
    cj104 = selftest_source(CONSENSUS_JOIN).read_text(encoding="utf-8")
    assert CONSENSUS_JOIN == "VRN2_ConsensusJoin_v0104.py" and 'VERSION = "v0104"' in cj104 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0103.py"' in cj104
    assert "def provenance_refresh(" in cj104 and "def mark_provenance(" in cj104 and "VIA_VRN2_CONSENSUS_REFRESH" in cj104 and 'NET_MARK = "[VIA:NET-TOOL:"' in cj104
    eng122 = selftest_source("VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py").read_text(encoding="utf-8")
    assert "[VIA:NET-TOOL:v0122]" in eng122 and "SUP_MDL740_NetUnified_v" in eng122 and "def def_via_net(" in eng122 and "VIA_NET_DENY" in eng122 and "[VIA:ACCEL-BRIDGE:" in eng122
    assert "import yfinance" not in eng122.split("[VIA:NET-TOOL:v0122]", 1)[1].split("def def_fetch_yfinance_info", 1)[1].split("\ndef ", 1)[0]   # YFinance → network tool lane
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            names156 = bundle.namelist()
        cjs = sorted(n for n in names156 if re.fullmatch(r"VRN2_ConsensusJoin_v\d{4}\.py", n))
        engs = sorted(n for n in names156 if re.fullmatch(r"VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v\d{4}\.py", n))
        assert cjs[-1] == CONSENSUS_JOIN_ACTIVE and CONSENSUS_JOIN in cjs and "VRN2_ConsensusJoin_v0103.py" in cjs, cjs[-3:]     # v0164: v0105 newest · v0104 its PRIOR
        sts = sorted(n for n in names156 if re.fullmatch(r"VRN2_OutputStore_v\d{4}\.py", n))
        assert sts[-1] == OUTPUT_STORE_ACTIVE and OUTPUT_STORE in sts and "VRN2_OutputStore_v0100.py" in sts, sts
        assert engs[-1] == "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py" and "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py" in engs, engs
    base_src = selftest_source(BASE_NAME).read_text(encoding="utf-8")
    assert 'run(M + ["envcheck"] + ([] if "--no-install" in argv or "--plan" in argv else ["--install"]), 3600, envx, cwd=str(vrn))' in base_src    # the call v0157 intercepts
    mgr_cmd = ["/py/python", "-W", "ignore", "/x/VRN_SystemManager_v0257.py", "envcheck", "--install"]
    assert is_envcheck(mgr_cmd) and not is_envcheck(["/py/python", "x.py", "envcheck"]) and not is_envcheck(["/py/python", "-W", "ignore", "/x/VRN_SystemManager_v0257.py", "vrn2", "--run"])
    with tempfile.TemporaryDirectory(prefix="vrn2-v0157-check-") as temporary:
        root157 = Path(temporary) / "VIA"
        reg = root157 / "supportive modules" / "registry"
        reg.mkdir(parents=True)
        for v in ("v0103", "v0104", "v0099"):
            (reg / ("CGC_MDL056_InstallGate_%s.py" % v)).write_text("# stub\n", encoding="utf-8")
        calls, state = [], {"checks": 0, "fixed": set()}
        def fake_run(cmd, *a, **k):
            cmd = [str(c) for c in cmd]
            calls.append(cmd)
            if "envcheck" in cmd:
                state["checks"] += 1
                out = ["[計] 環境檢查(envcheck · /py/python)· 掃 加速器 / 網路工具 2 檔 + VRN-2 尾版 1 檔 · 第三方套件 3"]
                if "duckdb" not in state["fixed"]:
                    out.append("[計] 缺 必裝 duckdb(pip duckdb · 用於 X.py)")
                out.append("[計] 缺 選裝 lz4(pip lz4 · 用於 Y.py)")
                return (1 if "duckdb" not in state["fixed"] else 0), out
            if cmd[-1] == "duckdb":
                state["fixed"].add("duckdb")
                return 0, ["  [裝後] 衝突 0 條 · 新增 0 · 解除 0"]
            return 1, ["  [安裝] SuperAccel 委派 · exit 1 · 同意閘未開——安裝需 $env:VIA_NET_CONSENT='YES'(紅線:不代設)", "  [FAIL] pip 安裝失敗 — 誠實停止(不註冊)"]
        rc1, lines1 = env_step(fake_run, mgr_cmd, (3600, {"VIA_NO_OPEN": "1"}), {"cwd": "x"}, root157)
        gate_calls = [c for c in calls if "envcheck" not in c]
        assert all("--install" not in c for c in calls if "envcheck" in c) and state["checks"] == 2                                 # check-only · re-check after an install
        assert [Path(c[3]).name for c in gate_calls] == ["CGC_MDL056_InstallGate_v0104.py"] * 2 and [c[-1] for c in gate_calls] == ["duckdb", "lz4"]
        assert rc1 == 0 and "裝好 1 duckdb" in lines1[0] and "沒裝 1 lz4" in lines1[0] and any("補裝失敗 選裝 lz4" in l and "via-install lz4" in l for l in lines1)
        assert not any("缺 必裝" in l for l in lines1)                                                                                # base: GREEN / YELLOW from these lines as before
        ledger157 = json.loads((root157 / "VIA_Reports" / "vrn2" / INSTALL_LEDGER).read_text(encoding="utf-8"))
        assert list(ledger157) == ["lz4"] and ledger157["lz4"]["gate"] == "CGC_MDL056_InstallGate_v0104.py" and ledger157["lz4"]["kind"] == "選裝"
        calls.clear()
        rc2, lines2 = env_step(fake_run, mgr_cmd, (3600,), {}, root157)
        assert not [c for c in calls if "envcheck" not in c] and any(l.startswith("[計] 略過 lz4") for l in lines2)                  # 24 h: not retried
        calls.clear()
        env_step(fake_run, mgr_cmd[:-1], (3600,), {}, root157)                                                                        # --no-install / --plan (base drops --install)
        assert not [c for c in calls if "envcheck" not in c] and len(calls) == 1
        calls.clear()
        rc3, lines3 = env_step(fake_run, mgr_cmd, (3600,), {}, root157, legacy=True)
        assert calls == [mgr_cmd] and "舊行為" in lines3[0]                                                                           # explicit operator choice only
        state["fixed"].clear()
        calls.clear()
        rc4, lines4 = env_step(fake_run, mgr_cmd, (3600,), {}, Path(temporary) / "no_vcgc")
        assert not [c for c in calls if "envcheck" not in c] and rc4 == 1 and any("找不到 VCGC 安裝閘" in l and "必裝 duckdb" in l for l in lines4)
    with tempfile.TemporaryDirectory(prefix="vrn2-v0163-check-") as temporary:
        out163 = Path(temporary) / "VIA" / "VIA_Reports" / "vrn2"
        vdf163 = out163 / "market" / "vdf"
        fin163 = vdf163 / "parquet" / "tw_financial" / "ticker=2330" / "year=2025"
        fin163.mkdir(parents=True)
        (fin163 / "data.parquet").write_bytes(b"mops")
        (vdf163 / "tw_financial.parquet").write_bytes(b"mops")
        (vdf163 / "parquet" / "tw_equity_daily").mkdir(parents=True)
        moved163 = quarantine_mops_financial(out163)
        q163 = vdf163 / moved163
        assert moved163.startswith("_mops_quarantine_") and (q163 / "parquet" / "tw_financial" / "ticker=2330" / "year=2025" / "data.parquet").read_bytes() == b"mops"
        assert (q163 / "tw_financial.parquet").is_file() and not (vdf163 / "parquet" / "tw_financial").exists() and not (vdf163 / "tw_financial.parquet").exists()
        assert (vdf163 / "parquet" / "tw_equity_daily").is_dir() and quarantine_mops_financial(out163) == ""                            # prices stay · nothing left to move
        root163 = Path(temporary) / "VIA"
        shared163 = root163 / "functional modules" / "VRN"
        shared163.mkdir(parents=True)
        (shared163 / "VRN2_MarketFetch_v0112.py").write_text("import sys\nprint('[計] 市場%s · GREEN · nofin=%s' % ('擷取' if '--fetch' in sys.argv else '填值', '--no-financial' in sys.argv))\n", encoding="utf-8")
        (out163 / "output").mkdir(parents=True)
        (out163 / "output" / "VRN2_BasicInfo_latest.json").write_text("[]", encoding="utf-8")
        fin163.mkdir(parents=True)
        (fin163 / "data.parquet").write_bytes(b"mops2")
        saved163 = os.environ.pop("VIA_VRN2_NO_MARKET", None)
        try:
            steps163 = []
            got163 = market_fetch(root163, out163, steps163, {"VRN2_MARKET_WAIT": 120})
        finally:
            if saved163 is not None:
                os.environ["VIA_VRN2_NO_MARKET"] = saved163
        assert got163["results"]["--fetch"]["msg"].endswith("nofin=True") and got163["results"]["--fill"]["msg"].endswith("nofin=False")
        assert got163["no_mops"] and got163["mops_quarantine"].startswith("_mops_quarantine_") and not (vdf163 / "parquet" / "tw_financial").exists()
        assert steps163[-1]["step"].startswith("⑥e 市場擷取") and "不用 MOPS" in steps163[-1]["step"] and "不用 MOPS(--no-financial)" in steps163[-1]["detail"]
    with tempfile.TemporaryDirectory(prefix="vrn2-v0164-check-") as temporary:
        root164 = Path(temporary) / "VIA"
        runtime164 = root164 / "functional modules" / "VRN2"
        runtime164.mkdir(parents=True)
        for name in (CONSENSUS_JOIN_ACTIVE, "VRN2_ConsensusJoin_v0106.py", "VRN2_ConsensusJoin_v0105.py", CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py",
                     OUTPUT_STORE_ACTIVE, "VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py", BOOK_SOURCE, "VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py"):
            shutil.copy2(str(selftest_source(name)), str(runtime164 / name))
        cj = _load_runtime_module(runtime164, CONSENSUS_JOIN_ACTIVE, "vrn2_consensus_join_v0164_check")
        assert cj.VERSION == "v0107" and cj.PRIOR.VERSION == "v0106" and cj.PRIOR.PRIOR.VERSION == "v0105" and cj.PRIOR.PRIOR.PRIOR.VERSION == "v0104"
        assert cj.V0100.join is cj.join and cj.PRIOR.join is cj.join and cj.V0100.run is cj.run and cj.PRIOR.run is cj.run   # v0170: v0106 rewires run (snapshot backfill) and join (ASOF note)
        assert cj.V0100._write is cj._write and cj.V0100.columns is cj.columns                                                # v0172: v0107 rewires the Combined writer / column list
        cols172 = cj.columns(2026)
        assert cols172[cols172.index("UPSIDE_PCT(ADJ)") + 1] == "UPSIDE_ADJ" and cols172.count("UPSIDE_ADJ") == 1 and cj.ratio_text(0.4) == "0.400000000" and cj.ratio_text(None) == ""
        snap170 = cj.snapshot_fill({"net_deny": {"gate_closed": True}, "per_code": {}, "codes": ["9999"]}, root164 / "nowhere")
        assert snap170.get("snapshot_reused") is None and not snap170.get("per_code")                                        # no snapshot on disk → honest no-op
        assert cj.IDENTITY == ["date", "ticker", "yfinance_ticker", "bloomberg_ticker", "name"] and cj.KEYS["tw_market_consensus"] == ["date", "ticker"]
        assert "factset_target_price_median" in cj.MERGED_COLS and "yfinance_target_price_median" in cj.MERGED_COLS and "median_gap_pct" in cj.MERGED_COLS
        day164 = datetime.date
        rows164 = [{"date": day164(2025, 11, 26), "close": 400.0, "yf_close": 100.0, "yf_adj_close": 96.0, "close_check": "MISMATCH", "adjustment_status": "CLOSE_MISMATCH", "adj_close": None},
                   {"date": day164(2026, 10, 30), "close": 76.8, "yf_close": 76.8, "yf_adj_close": 76.8, "close_check": "MATCH", "adjustment_status": "ADJUSTED", "adj_close": 76.8}]
        sync164 = cj.sync_factor(rows164, day164(2025, 11, 28))
        assert sync164["mode"] == "SYNC_YAHOO_RATIO" and abs(sync164["factor"] - 0.24) < 1e-9                                       # split 1:4 · dividends 0.96
        assert cj.sync_factor(rows164[1:], day164(2025, 11, 28))["reason"].startswith("MISSING(")                                    # no day before the report → MISSING
        st = _load_runtime_module(runtime164, OUTPUT_STORE_ACTIVE, "vrn2_output_store_v0164_check")
        assert st.TAG == "v0105" and st.PRIOR.PRIOR.TAG.startswith("v0105") and st.PRIOR.TAG.startswith("v0105") and st.BOOKS[-1] == "MarketConsensus" and st.V0100.sync is st.sync and st.V0100._append_duckdb is st._append_duckdb
        assert st.mops_marked("FinancialAligned", {"VALUE_SOURCE": "HISTORY(MOPS / TWSE)"}) and not st.mops_marked("FinancialAligned", {"VALUE_SOURCE": "REPORT(估)"})
        assert st.mops_index("FinancialAligned", [{"run_id": "r", "file_sha": "a", "VALUE_SOURCE": "REPORT(估)"}, {"run_id": "r", "file_sha": "a", "VALUE_SOURCE": "REPORT(未對齊)"},
                                                  {"run_id": "r", "file_sha": "b", "VALUE_SOURCE": "REPORT"}]) == [0, 1]
        output164 = root164 / "VIA_Reports" / "vrn2"
        (output164 / "output").mkdir(parents=True)
        steps164 = []
        got164 = output_store(runtime164, output164, "t164", steps164)
        assert got164["lamp"] == "GRAY" and steps164[-1]["step"].startswith("⑬") and json.loads((output164 / "VRN2_StorePurge_latest.json").read_text(encoding="utf-8"))["lamp"] == "GRAY"
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():                     # v0164 SSOT 提案冊 v0101(這輪新規則 8 條 · ssot_id 空白 · 等 VCGC 核發)
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            names164 = bundle.namelist()
            book164 = json.loads(bundle.read("VRN2_SSOT_Proposals_v0101.json").decode("utf-8")) if "VRN2_SSOT_Proposals_v0101.json" in names164 else {}
        entries164 = book164.get("entries") or []
        assert "VRN2_SSOTSync_v0102.py" in names164 and len(entries164) == 17 and all(e.get("ssot_id") == "" for e in entries164) and entries164[-1]["proposed_no"] == "VRN2-PROP-0017"
    print("[PASS] v0164: step 6f loads ConsensusJoin v0105 (TARGET_PRICE(ADJ) synchronous adjustment · consensus in the TWSE / TPEX format · merged) · "
          "step 13 loads OutputStore v0102 (MOPS rows purged with a backup · never appended again · MarketConsensus book) · v0104 / v0101 kept as PRIOR · "
          "SSOT proposals v0101 (8 new rules · ssot_id blank · step 5b requests numbers from VCGC)")
    print("[PASS] v0163: step 6e never asks for MOPS · MarketFetch --fetch gets --no-financial (--fill unchanged) · MOPS financial data already on disk "
          "moved to market/vdf/_mops_quarantine_<stamp> (nothing deleted · prices stay)")
    ocr_src = selftest_source(BASE_NAME).read_text(encoding="utf-8")
    assert 'rc, _ = run(pipx + ["rapidocr_onnxruntime", "wordninja"], 2400)' in ocr_src and 'vdir = _cb_Path(os.environ.get("VIA_ENVS_HOME") or (_cb_Path.home() / "envs")) / "vrn2_ocr"' in ocr_src
    with tempfile.TemporaryDirectory(prefix="vrn2-v0158-check-") as temporary:
        envs = {"VIA_ENVS_HOME": temporary}
        vdir158, py158 = ocr_venv(envs)
        assert vdir158 == Path(temporary) / "vrn2_ocr" and not ocr_ready(envs, runner=lambda cmd: 0)                                     # no venv → not ready
        py158.parent.mkdir(parents=True)
        py158.write_text("", encoding="utf-8")
        seen = []
        assert ocr_ready(envs, runner=lambda cmd: seen.append(cmd) or 0) and seen[0][:2] == [str(py158), "-c"] and "wordninja" in seen[0][2]
        assert not ocr_ready(envs, runner=lambda cmd: 1)                                                                                   # venv without the packages
        assert ocr_ready({"VIA_VRN2_OCR_PY": "/x/python", "VIA_VRN2_OCR_BRIDGE": "/x/bridge.py"}, runner=lambda cmd: 1)                     # an assigned OCR env is used as is
        hand = ocr_handoff(envs)
        assert "VRN-2 不建、不 pip" in hand and "交 VCGC 建" in hand and str(vdir158) in hand and "rapidocr_onnxruntime wordninja" in hand and "OCR 照舊排佇列" in hand
    print("[PASS] v0158: step 3b uses a ready / assigned OCR environment as before · not ready → no venv, no pip from VRN-2 · YELLOW with the build commands for VCGC · "
          "OCR stays queued · old behaviour only with --pip-install / VIA_VRN2_PIP_INSTALL=1")
    print("[PASS] v0157: step 3 runs envcheck check-only (no pip in this Python) · missing packages go one by one through VCGC's newest "
          "CGC_MDL056_InstallGate · re-checked after an install · gate failures not retried for 24 h · --no-install / --plan: no gate call · "
          "no VCGC gate → hand to VCGC · old in-place pip only with --pip-install / VIA_VRN2_PIP_INSTALL=1")
    print("[PASS] v0156: ConsensusJoin v0104 is the active consensus join · engine v0122 (highest in the runtime) goes out through the VIA network tool "
          "SUP_MDL740_NetUnified + accelerator bridge · gate closed → net_deny, never another transport · direct engine v0120 kept as PRIOR")
    cj103 = selftest_source("VRN2_ConsensusJoin_v0103.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0103"' in cj103 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0102.py"' in cj103
    assert "def seed_checkpoint(" in cj103 and "def classify(" in cj103 and "VIA_VRN2_CONSENSUS_RETRIES" in cj103 and "source_gap" in cj103
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            cjs = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN2_ConsensusJoin_v\d{4}\.py", n))
        assert "VRN2_ConsensusJoin_v0103.py" in cjs and "VRN2_ConsensusJoin_v0102.py" in cjs, cjs[-3:]                 # v0156: v0104 is the newest
    print("[PASS] v0154: ConsensusJoin v0103 kept as PRIOR of v0104 (today's payloads resumed on a new code list · 404 / transient retried · still failing → no_coverage / source_gap, out of the gate) · v0102 kept as PRIOR")
    print("[PASS] v0178: VerbatimVerifier back to v0105 (the desktop v0106 is step 4's own accelerator injection · runtime v0167 ships no v0106) · Workbench v0111 (narrow screens · aria-labels · wide look locked)")
    print("[PASS] v0177: manager v0260 (page_NNNN[_hash].pdf out of the stock scope) · BookSource v0102 (1,234.50 / 23.45%) · OutputStore v0105 · Workbench v0110 (same font · 28 px buttons · matrices · 檢視副本) · VerbatimVerifier v0106 (accelerator marker) are active")
    print("[PASS] v0176: ⑬a BookSource v0101 (Summary 四點 / 標題去開頭符號 · Combined 主題與摘要 = 示例公司(9999.TW, 買進) - 標題甲 · 評價點第一 · 上漲空間 118 ÷ 100 − 1 = 18.0% · 再跑不變) · OutputStore v0104 active (chain v0103 → v0100)")
    print("[PASS] v0175: ⑬a BookSource v0100 (no books → GRAY · BROKER_EN KGI + SOURCE 報告預估 as the last two columns · BROKER kept · opt-out → GRAY · after ⑬b, before ⑬) · OutputStore v0103 active · Workbench v0109 active")
    print("[PASS] v0174: Workbench v0108 (ENG049 template lock · Freshness · Ticker / YFinance + Name · broker abbreviations · YYYY / YYYY-MM / YYYY-MM-DD · Source last · exports append SOURCE) is the active Workbench")
    print("[PASS] v0172: HistoryAlign v0103 (typed Parquet rewrite · JSON / CSV unchanged) · ConsensusJoin v0107 (UPSIDE_ADJ ratio column after the kept percent column · column notes) · Workbench v0107 (Basic Info merged view · self-contained · accelerator marker) are active")
    print("[PASS] v0170: Workbench v0105 (dynamic-prior tail · compact CSS · verification lamps · consensus panel) is the active Workbench; ConsensusJoin v0106 (gate-closed snapshot backfill · ASOF-labelled · never sets the consent gate) is the active join")
    print("[PASS] v0168: manager v0259 (now PRIOR of v0260) (transposed tables re-asked with the third reader's touching number fragments joined · still failing stays in Rejected) · v0258 kept as PRIOR")
    print("[PASS] v0166: manager v0258 (PRIOR of v0259) (table repair before the books: half-line label pairing · two-level period header re-grid · both confirmed by the second reader · unplaced rows to Rejected) · v0257 kept as PRIOR")
    print("[PASS] v0153: manager v0257 (PRIOR of v0258) (one row, one item: side-by-side right-table values renamed to their own row label or moved to Rejected · row-less duplicates rejected) · v0255 kept as PRIOR")
    v114 = selftest_source("VRN2_IndependentVerifier_v0114.py").read_text(encoding="utf-8")
    assert 'VERSION = "VRN2_IndependentVerifier_v0114"' in v114 and "def column_value(" in v114 and "def reader_lines(" in v114 and "PRIOR.verify_fin = verify_fin" in v114
    assert 'PRIOR = load("independent_v0114_financial_core", "VRN2_IndependentVerifier_v0105.py")' in v114 and 'if sys.argv[1:2] == ["--shard"]:' in v114
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            ivs2 = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN2_IndependentVerifier_v\d{4}\.py", n))
        assert ivs2[-1] == "VRN2_IndependentVerifier_v0114.py" and "VRN2_IndependentVerifier_v0113.py" in ivs2, ivs2[-3:]           # v0153: v0114 still the newest verifier
    print("[PASS] v0152: runtime's newest IndependentVerifier = v0114 (annual FAIL aligned by column in the second reading · structural copy, its own --shard) · v0113 kept")
    verifier = selftest_source("VRN2_IndependentVerifier_v0113.py").read_text(encoding="utf-8")
    assert 'VERSION = "VRN2_IndependentVerifier_v0113"' in verifier and "def item_on_page(" in verifier and "PRIOR.verify_fin = verify_fin" in verifier
    assert 'PRIOR = load("independent_v0113_financial_core", "VRN2_IndependentVerifier_v0105.py")' in verifier and 'if sys.argv[1:2] == ["--shard"]:' in verifier
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            ivs = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN2_IndependentVerifier_v\d{4}\.py", n))
        assert "VRN2_IndependentVerifier_v0113.py" in ivs and "VRN2_IndependentVerifier_v0112.py" in ivs, ivs[-3:]
    print("[PASS] v0151: runtime's newest IndependentVerifier = v0113 (BADITEM read a second way before 'item not on this page' · structural copy, its own --shard) · v0112 kept")
    print("[PASS] v0150: ConsensusJoin v0102 (no-FactSet-page 404 codes left out of the gate · other FAILs keep FAIL_CLOSED) · ⑥e detail names the fetch Python + VDF bounds")
    print("[PASS] v0149: VerbatimVerifier v0105 (line-end hyphen · U+FFFE) · ⑥e MarketFetchRun v0100 (MarketFetch's fetch_python → a Python that passes the VDF engine's bounds)")
    print("[PASS] v0148: UIAction v0110 (hermetic selftest · patch_ui kept) · ConsensusJoin v0101 (TPEx .TWO from the market book) · HistoryAlign v0102 (strict item mapping)")
    print("[PASS] v0147: OutputStore v0101 / DataIntegrate v0101 / HistoryAlign v0101 · ⑥e fetch Python (VIA_FETCH_PY → via_tw_fetch → this) · --fill after a failed --fetch · ⑬b before ⑬ · selftest modules from the runtime zip · hermetic selftest env")
    print("[PASS] v0146: ⑥e market fetch (absent → GRAY · no book → GRAY · fetch GREEN + fill YELLOW → YELLOW · opt-out) · ⑥f consensus Combined (opt-out run → Combined still built · column order) · ⑬b history align (no book / no market → GRAY · opt-out) · ⑬c integrate scan (none → GRAY · legacy csv → PENDING_USER) · non-critical lamps never change rc")
    print("[PASS] v0145: manager v0255 is the active manager (parallel idempotence gate · phase timing) · receipt v0145")
    print("[PASS] v0144: ⑤b SSOT-ID sync (no register → GRAY · pending → GREEN + request) · ⑬ output store (unset → GRAY · VRN2_OUTPUT_DIR seeds config · incremental append · idempotent re-run)")
    print("[PASS] v0143: v0142 checks + single-instance lock (live / stale / forced / foreign), child limits (env · floor · mapping), ⑫b in-process fallback (missing page · patched · already present · handler error)")
    return 0


# ===== 4. Delegate to the existing VRN-2 entry =====
# ===== v0157 ③ 環境:只檢查 · 缺的經 VCGC 安裝閘(不再用本環境 pip 補裝)=====
_MISS = re.compile(r"\[計\] 缺 (必裝|選裝) (\S+?)\(pip (\S+?) · 用於")


def vcgc_install_gate(root) -> Path | None:
    """VCGC 的安裝閘 CGC_MDL056_InstallGate 最高版號(同 VCGC EnvGovernance 的取法 · 只找檔 · 不改 VCGC 的檔)。"""
    folder = Path(root) / "supportive modules" / "registry"
    hits = list(folder.glob(INSTALL_GATE_GLOB)) if folder.is_dir() else []
    return max(hits, key=lambda p: int(p.stem.rsplit("_v", 1)[1])) if hits else None


def is_envcheck(arguments) -> bool:
    tokens = [str(a) for a in arguments or []]
    return "envcheck" in tokens and any(Path(t).name.startswith("VRN_SystemManager_v") for t in tokens)


def missing_packages(lines) -> list:
    out = []
    for line in lines or []:
        m = _MISS.search(str(line))
        if m and m.group(3) not in [x["pip"] for x in out]:
            out.append({"kind": m.group(1), "module": m.group(2), "pip": m.group(3)})
    return out


def env_step(run, arguments, args, kwargs, root, legacy=False) -> tuple:
    """③:envcheck 只檢查 → 缺的一個一個交 VCGC 安裝閘(24 小時內裝不起來的不重試)→ 再只檢查一次。回 (rc, lines),底座照舊判燈。"""
    tokens = [str(a) for a in arguments]
    allowed = "--install" in tokens                                         # 底座在 --no-install / --plan 時不帶 --install
    if legacy and allowed:
        rc, lines = run(tokens, *args, **kwargs)
        return rc, ["[計] ③ 環境檢查 · 操作員指定舊行為(--pip-install / VIA_VRN2_PIP_INSTALL=1):本環境 pip 補裝 · 不經 VCGC"] + list(lines)
    check = [t for t in tokens if t != "--install"]
    rc, lines = run(check, *args, **kwargs)
    miss = missing_packages(lines)
    if not miss or not allowed:
        why = "沒有缺的" if not miss else "--no-install / --plan:不裝"
        head = "[計] 環境檢查(只檢查 · 不 pip · 缺的經 VCGC 安裝閘)· %s · 缺:必裝 %d · 選裝 %d" % (why, sum(1 for x in miss if x["kind"] == "必裝"), sum(1 for x in miss if x["kind"] == "選裝"))
        print(head, flush=True)
        return rc, [head] + list(lines)
    gate = vcgc_install_gate(root)
    ledger_path = Path(root) / "VIA_Reports" / "vrn2" / INSTALL_LEDGER
    try:
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        ledger = {}
    retry = os.environ.get("VIA_VRN2_INSTALL_RETRY") == "1"
    notes, done, failed, skipped = [], [], [], []
    for x in miss:
        old = ledger.get(x["pip"]) or {}
        if not retry and old and time.time() - float(old.get("ts", 0)) < 86400:
            skipped.append(x["pip"])
            notes.append("[計] 略過 %s(%s)· 24 小時內 VCGC 安裝閘裝不起來(%s)· 交 VCGC:via-install %s" % (x["pip"], x["kind"], str(old.get("why", ""))[:80], x["pip"]))
            continue
        if gate is None:
            failed.append(x["pip"])
            notes.append("[計] 補裝失敗 %s %s · 找不到 VCGC 安裝閘(supportive modules\\registry\\CGC_MDL056_InstallGate_v####.py)→ 交 VCGC · VRN-2 不 pip" % (x["kind"], x["pip"]))
            continue
        grc, glines = run([tokens[0], "-X", "utf8", str(gate), x["pip"]], 1800, {"VIA_NO_OPEN": "1"}, cwd=str(gate.parent))
        tail = next((l.strip() for l in reversed(glines) if re.search(r"\[FAIL\]|\[裝後\]|exit \d|同意閘", str(l))), (glines or [""])[-1:][0] if glines else "")
        if grc == 0:
            done.append(x["pip"])
            ledger.pop(x["pip"], None)
            notes.append("[計] VCGC 安裝閘 %s · 裝好 %s(%s)· %s" % (gate.stem, x["pip"], x["kind"], str(tail)[:100]))
        else:
            failed.append(x["pip"])
            ledger[x["pip"]] = {"ts": time.time(), "day": time.strftime("%Y-%m-%d"), "rc": grc, "gate": gate.name, "kind": x["kind"], "module": x["module"], "why": str(tail)[:160]}
            notes.append("[計] 補裝失敗 %s %s · VCGC 安裝閘 %s rc %s · %s → 交 VCGC:via-install %s" % (x["kind"], x["pip"], gate.stem, grc, str(tail)[:100], x["pip"]))
    try:
        ledger_path.parent.mkdir(parents=True, exist_ok=True)
        ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass
    rc2, lines2 = run(check, *args, **kwargs) if done else (rc, lines)
    head = "[計] 環境檢查(只檢查 · 不 pip)· VCGC 安裝閘 %s · 裝好 %d%s · 沒裝 %d%s · 略過 %d" % (
        gate.stem if gate else "(找不到)", len(done), (" " + ",".join(done)) if done else "", len(failed), (" " + ",".join(failed)) if failed else "", len(skipped))
    for line in [head] + notes:
        print(line, flush=True)
    return rc2, [head] + notes + list(lines2)


# ===== v0158 ③b OCR 隔離環境:就緒照用 · 沒就緒不建不裝 · 交 VCGC =====
OCR_CHECK = ("import importlib\nok=0\nfor n in ('rapidocr_onnxruntime','rapidocr'):\n    try:\n        importlib.import_module(n); ok=1; break\n"
             "    except Exception: pass\nimportlib.import_module('wordninja')\nraise SystemExit(0 if ok else 1)\n")


def ocr_venv(env=None) -> tuple:
    """底座 ocr_env 用的同一個位置:VIA_ENVS_HOME(或 ~/envs)/vrn2_ocr · 回 (夾, python)。"""
    env = os.environ if env is None else env
    vdir = Path(env.get("VIA_ENVS_HOME") or (Path.home() / "envs")) / "vrn2_ocr"
    return vdir, vdir / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def ocr_ready(env=None, runner=None) -> bool:
    env = os.environ if env is None else env
    if env.get("VIA_VRN2_OCR_PY") and env.get("VIA_VRN2_OCR_BRIDGE"):
        return True
    _vdir, py = ocr_venv(env)
    if not py.exists():
        return False
    runner = runner or (lambda cmd: subprocess.run(cmd, capture_output=True, text=True, timeout=180).returncode)
    try:
        return runner([str(py), "-c", OCR_CHECK]) == 0
    except Exception:  # noqa: BLE001
        return False


def ocr_handoff(env=None) -> str:
    """沒就緒時給 VCGC 的建法(VRN-2 不建、不 pip)。"""
    vdir, py = ocr_venv(env)
    if os.name == "nt":
        build = 'py -3.11 -m venv "%s"' % vdir
    else:
        build = 'python3 -m venv "%s"' % vdir
    return ("OCR 隔離環境沒就緒(%s)· VRN-2 不建、不 pip(VCGC 安裝閘只裝進呼叫它的 Python · 裝不進別的 venv)→ 交 VCGC 建:%s ; "
            '"%s" -m pip install "numpy>=1.24,<2.0" rapidocr_onnxruntime wordninja · OCR 照舊排佇列' % (vdir, build, py))


def main(argv: list | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments == ["--selftest"]:
        return selftest()
    legacy_pip = "--pip-install" in arguments or os.environ.get("VIA_VRN2_PIP_INSTALL") == "1"     # v0157: 舊行為只在操作員明說時
    arguments = [a for a in arguments if a != "--pip-install"]
    base = load_base()
    if os.environ.get("VRN2_ROOT"):
        root = Path(os.environ["VRN2_ROOT"]).resolve()
    elif Path(__file__).with_name(CONTEXT_NAME).is_file():
        root = Path(json.loads(Path(__file__).with_name(CONTEXT_NAME).read_text(encoding="utf-8"))["root"]).resolve()
    else:
        root, _ = base.locate()
    for key in ("VIA_VRN2_NO_PUSH", "VIA_VRN2_NO_BORROW", "VIA_VRN2_NO_VRN1_SYNC"):
        os.environ[key] = "1"
    bridge_path = Path(__file__).with_name("VIA_ExecutionBridge_v0103.py")
    spec = importlib.util.spec_from_file_location("vrn2_execution_bridge", bridge_path)
    execution_bridge = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = execution_bridge
    spec.loader.exec_module(execution_bridge)
    tool_state = execution_bridge.activate(root)
    print("[加速] VRN-2 active lock:", tool_state["accelerator"])
    runtime = restore_private_runtime(root)
    lim = limits()
    os.environ["VIA_VRN2_VERIFY_WAIT"] = str(lim["VIA_VRN2_VERIFY_WAIT"])
    original_run = base.run
    def plain_run(arguments, *args, **kwargs):
        if args:
            timeout, kwargs = run_limits(arguments, args[0], kwargs, lim)
            args = (timeout,) + tuple(args[1:])
        if arguments and Path(str(arguments[0])).name.lower().startswith("python"):
            arguments = execution_bridge.command(arguments, root, Path(__file__).parent)
        return original_run(arguments, *args, **kwargs)
    def accelerated_run(arguments, *args, **kwargs):
        if is_envcheck(arguments):                                             # v0157 ③ 只檢查 · 缺的經 VCGC 安裝閘
            return env_step(plain_run, arguments, args, kwargs, root, legacy_pip)
        return plain_run(arguments, *args, **kwargs)
    base.run = accelerated_run
    original_manager_setup = base.land_manager
    def manager_setup(*args, **kwargs):
        _prior_manager, lamp, detail = original_manager_setup(*args, **kwargs)
        return runtime / MANAGER, lamp, detail + " · active manager v0260"
    base.land_manager = manager_setup
    original_register = base.register_ui_protocol
    def register_current_launcher(vrn, v2):
        lamp, detail = original_register(vrn, v2)
        configure_ui_launcher(vrn, root)
        return lamp, detail + " · launcher v0178"
    base.register_ui_protocol = register_current_launcher
    base.UI_HANDLER_NAME = UI_HANDLER                                      # v0144: ⑥c registers / ⑫b refreshes with handler v0108 (outdir)
    base._ui_wait = lambda: None

    def locate_private():
        base.LOCATE.update(note="VRN-2 private runtime; exact ship v0167 (launcher v0178 · manager v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0111 · HistoryAlign v0103 · ConsensusJoin v0107 UPSIDE_ADJ · no MOPS); manager v0259 transposed re-check (over v0258 table repair · v0257 · v0255); consensus join v0105 (TP(ADJ) sync · TWSE/TPEX format) over v0104 + engine v0122 via VIA network tool; step 3 installs via VCGC; step 3b no pip; shared VRN retained", fix=False)
        return root, runtime

    def own_runtime_ready(_runtime, _root):
        return "GREEN", "Exact VRN-2 runtime verified in functional modules/VRN2; shared VRN untouched"

    def skip_ship(*_arguments):
        return "GRAY", "Closeout validation only; no Git commit or push"

    def skip_archive(*_arguments):
        return "GRAY", "Versioned runtime retained; no files moved or deleted"

    original_ocr_environment = base.ocr_env

    def ocr_environment(environment=None):
        if not legacy_pip and not ocr_ready(os.environ if environment is None else {**os.environ, **environment}):
            return "YELLOW", ocr_handoff(os.environ if environment is None else {**os.environ, **environment})    # v0158 不建不裝 · 交 VCGC
        lamp, detail = original_ocr_environment(environment)
        target = os.environ if environment is None else environment
        if lamp == "GREEN":
            target["VIA_VRN2_OCR_BRIDGE"] = str(Path(__file__).resolve().with_name(OCR_BRIDGE))
        return lamp, detail + " · official ONNX telemetry opt-out bridge v0101"

    base.VERSION = VERSION
    base.locate = locate_private
    base.restore_bundle = own_runtime_ready
    base.git_ship = skip_ship
    base.consolidate = skip_archive
    base.ocr_env = ocr_environment
    base.PACK.clear()
    base.STEPS.clear()
    base.LOG.clear()
    original_done = base._done_ok
    base._done_ok = lambda comp, steps, stamp, start: current_completion(original_done, comp, steps, stamp, start)
    started = time.time()
    output = root / "VIA_Reports" / "vrn2"
    output.mkdir(parents=True, exist_ok=True)
    locked, guard = acquire_lock(output)
    if not locked:
        print("[RED] 單機閘 · " + guard["why"], flush=True)
        print("NEXT: [RED] VRN-2 v0143 · rc 1 · 另一個啟動器還在跑 · 鎖 %s" % guard["lock"], flush=True)
        return 1
    print("[計] 單機閘 · %s · 鎖 %s · 子行程上限 ⑫b %d 秒 · ⑦ 無輸出 %d 秒 · 工具冊 %d 秒 · ⑪ 等驗證 %d 秒" % (guard["why"], guard["lock"], lim["VRN2_UI_REFRESH_WAIT"], lim["VRN2_SILENT_MAX"], lim["VRN2_MANIFEST_WAIT"], lim["VIA_VRN2_VERIFY_WAIT"]), flush=True)
    try:
        return _main_locked(arguments, base, root, runtime, tool_state, output, started, lim, guard)
    finally:
        release_lock(output)


def _main_locked(arguments, base, root, runtime, tool_state, output, started, lim, guard) -> int:
    passes = []
    ui_block = {}
    ssot = {}
    for attempt in range(1, MAX_PASSES + 1):
        if attempt > 1:
            base.PACK.clear()
            base.STEPS.clear()
            base.LOG.clear()
        # The outer entry opens pages only after all gates are written.
        original_rc = base.main(arguments + (["--no-open"] if "--no-open" not in arguments else []))
        ui_block = ensure_input_block(runtime, output, base.STEPS)
        ssot = ssot_sync(runtime, base.STEPS)
        if ui_block.get("how") == "in-process":
            print("[計] ⑫b %s · %s" % (ui_block["lamp"], ui_block["detail"]), flush=True)
        again, why = repass_wanted(output, attempt)
        passes.append({"attempt": attempt, "rc": original_rc, "lamps": {entry.get("step"): entry.get("lamp") for entry in base.STEPS}, "idempotence": why, "repass": again})
        if not again:
            break
        print("[計] ⑧ 冪等閘 · " + why + " → 自動再跑一輪(第 %d 輪 · 該檔重新擷取 · 其餘沿用快取)" % (attempt + 1), flush=True)
    market = market_fetch(root, output, base.STEPS, lim)
    consensus = consensus_join(runtime, root, output, base.STEPS, lim)
    code = strict_exit_code(base.STEPS, original_rc)
    gaps = output_gaps(output / "output")
    if gaps and code == 0:
        code = 2
    fresh_outputs = fresh_output_books(output / "output", started)
    proof_report = {"verdict": "NOT_RUN", "rc": 1, "reason": "本輪輸出未齊，不驗舊冊"}
    try:
        if not fresh_outputs:
            raise RuntimeError(proof_report["reason"])
        proof_path = Path(__file__).with_name(VERBATIM)
        proof_spec = importlib.util.spec_from_file_location("vrn2_original_quote_gate", proof_path)
        proof_module = importlib.util.module_from_spec(proof_spec)
        sys.modules[proof_spec.name] = proof_module
        proof_spec.loader.exec_module(proof_module)
        source = output / "scope_in"
        proof_report = proof_module.verify(output / "output", source)
    except Exception as error:
        proof_report.update(verdict="FAIL" if fresh_outputs else "NOT_RUN", error=f"{type(error).__name__}: {error}")
    (output / "VRN2_VerbatimVerify_latest.json").write_text(json.dumps(proof_report, ensure_ascii=False, indent=2), encoding="utf-8")
    if proof_report["rc"] == 1:
        code = 1
    elif proof_report["rc"] == 2 and code == 0:
        code = 2
    if proof_report["rc"]:
        gaps.append({"book": "四點原文核對", "reason": proof_report["verdict"] + " · " + str(proof_report.get("counts", proof_report.get("error", "")))})
    update_closeout_ui(output / "VRN2_UI_latest.html", code, gaps)
    receipt = {"system": "VRN-2", "version": VERSION, "rc": code, "elapsed_s": round(time.time() - started, 2), "runtime": str(runtime), "passes": passes, "steps": base.STEPS, "fresh_outputs": fresh_outputs, "output_gaps": gaps, "source_quotes": proof_report, "tools": tool_state, "shared_runtime_modified": False,
               "guard": guard, "limits": lim, "ui_block": ui_block, "ssot_sync": ssot, "market": market, "consensus": consensus}
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    receipt["history_align"] = history_align(runtime, root, output, base.STEPS)   # v0147: before ⑬ so FinancialAligned / Deleted reach the store
    receipt["book_source"] = book_source(runtime, output, base.STEPS)   # v0175 ⑬a: after ⑬b (it rewrites FinancialAligned / Deleted) · before ⑬ (the store keeps the columns)
    store = output_store(runtime, output, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), base.STEPS)
    receipt["output_store"] = store
    receipt["steps"] = base.STEPS
    if store.get("lamp") == "RED" and code == 0:
        code = 2
        receipt["rc"] = code
    receipt["integrate"] = integrate_scan(runtime, output, base.STEPS)
    receipt["steps"] = base.STEPS
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    workbench = render_workbench(runtime, root, output)
    receipt["workbench"] = workbench
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[%s] Workbench U/I · %s" % (workbench["lamp"], workbench["detail"]))
    print("NEXT: [%s] VRN-2 v0178 · rc %s · 跑了 %d 輪 · %s" % ({0: "GREEN", 1: "RED", 2: "YELLOW"}.get(code, "RED"), code, len(passes), output / RECEIPT_NAME))
    if "--no-open" not in arguments and os.environ.get("VRN2_NO_UI") != "1":
        print("[U/I]", open_page(Path(workbench["path"]) if workbench.get("path") else None, base, output))
    return code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print("[RED] VRN-2 v0142:", type(error).__name__, str(error), file=sys.stderr)
        raise SystemExit(1)
