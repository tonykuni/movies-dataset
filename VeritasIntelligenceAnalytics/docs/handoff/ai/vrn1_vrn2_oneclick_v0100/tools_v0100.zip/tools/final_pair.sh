#!/bin/bash
P=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/pair
$P/tools/scen_pair.sh final
$P/tools/scen_pair_again.sh again
echo alldone >> $P/scen_again.rc
