"""v0155(小輪 · 冪等):RoundAll v0111(填套件 v0154 的雜湊 · 套件不動)→ Handle-All v0103(一行 + 可讀版)→ 開機行(ASCII)+ 開機檔 + 最短一行 + cmd 一行 → md · 發行清單。
vrn2_release_v0154 及更早的發行夾不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v155"; rel = W / "release155"; rel.mkdir(exist_ok=True)
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402

REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
r154 = json.loads((REPO / "vrn2_release_v0154/VRN2_Release_v0154.json").read_text(encoding="utf-8"))
want = r154["package"]["sha256"]
assert hashlib.sha256((REPO / "vrn2_release_v0154/VRN2_Closeout_v0154.zip").read_bytes()).hexdigest() == want
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0111.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0154"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0154"' in ra
(rel / "VRN2_RoundAll_v0111.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ps7 = (S / "v151/ps7/line_ps7_tpl.txt").read_text(encoding="utf-8").strip("\n").replace("vrn2_release_v0151", "vrn2_release_v0155").replace("@F@", "VRN2_RoundAll_v0111.py").replace("@H@", ra_sha)
assert ("$H = '%s'" % ra_sha) in ps7
(rel / "oneline_roundall_ps7.txt").write_text(ps7 + "\n", encoding="utf-8")
ha_src = (W / "ps7/handleall_src.ps1").read_text(encoding="utf-8").replace("@H@", ra_sha)
assert ha_src.count(ra_sha) == 1 and "vrn2_release_v0155" in ha_src and "VRN2_RoundAll_v0111.py" in ha_src
ha_line = join(ha_src); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha_src, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt_src = (W / "ps7/boot_src.ps1").read_text(encoding="utf-8").replace("@HA@", ha_sha)
bt_line = join(bt_src); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800 and ha_sha in bt_line
(rel / "boot_src.ps1").write_text(bt_src, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0103_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(bt_line.encode("utf-16-le")).decode("ascii"); assert len(cmd_line) < 8191
(rel / "boot_cmd.txt").write_text(cmd_line + "\n", encoding="utf-8")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0155/VRN2_HandleAll_v0103_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
md = r"""# VRN-2 · PowerShell 7 一行處理全部 · VRN2_HandleAll_v0103(2026-10-31 · 套件 v0154 · RoundAll v0111)

v0103 = v0102 + RoundAll v0111:桌機 2026-10-31 02:06 的 repair 把 ⑥f 修好了(GREEN · 8358 / 2891 抓到 · 4171 / 6933 / 7728 仍 404 不納入閘),
收尾卻 OPEN「VRN-2 1」—— Combined 冊裡 GFHK Apple(TICKER `AAPL`,不是台股 4 碼)那列的共識欄空,v0110 把它算成 VRN-2;v0111 算資料源(同調整後目標價的規則)。
套件仍是 `vrn2_release_v0154/VRN2_Closeout_v0154.zip`(不動)。

## PowerShell 7 貼這一行(@TLEN@ 字元 · 4 行內 · 不會讓輸入列當掉)

```powershell
@TINY@
```

`git fetch` 分支(只更新遠端記錄 · 不動工作目錄)→ `git show` 取 `VRN2_HandleAll_v0103_boot.txt`(開機行 · ASCII)→ 核對 SHA-256 `@BT12@` 才執行 →
開機行取本檔、核對 Handle-All 那一行的 SHA-256 `@HA12@` 才執行 → auto(上一輪收據 v0153 以後 + 輸出冊在 → repair)。
**不要直接貼下面「Handle-All 那一行」**(約 9,000 字元 · PowerShell 7 的輸入列在 133 × 33 的視窗貼超過約 4,300 字元會當掉)。

- 倉不在 `%USERPROFILE%\OneDrive\Documents\movies-dataset`:把開頭的 `$r="…"` 改成你的倉,並先貼 `$env:VRN2_ROOT = '<倉>\VeritasIntelligenceAnalytics'`。
- 畫面停在 `>>`:先按 `Ctrl+C`(或另開視窗)。
- 第一行應是 `[GREEN] boot: Handle-All v0103 SHA-256 OK`。
- 模式:`$env:VRN2_MODE = 'full' / 'repair' / 'verify' / 'report'`(預設 auto)。

## 這次桌機(2026-10-31 02:06 之後)貼下去會怎樣

auto → repair → ⑤ 沒有要修的(⑥f 已綠)→ 除錯報告 → 收尾頁用 v0111 重算 → 預期 **BLOCKED · VRN-2 0 · VCGC 1(MOPS DENY)· 人工 2(MQ-1560 OCR 4 點 · 缺項 3 份)· 資料源 2(市場資料 MISSING 1 · Combined 空格)** → 貼回包。約 1 ~ 2 分鐘。

## 開機行(同一段 · 已經在 PowerShell 7 也可直接貼 · @BTLEN@ 字元)

```powershell
@BOOT@
```

## cmd 視窗(內容 = 開機行 · 不經 PowerShell 輸入列)

```bat
@CMD@
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
@LINE@
```

## 可讀版 · Handle-All

```powershell
@SRC@
```

## 可讀版 · 開機行

```powershell
@BTSRC@
```
"""
for k, v in (("@TINY@", tiny), ("@TLEN@", str(len(tiny))), ("@BT12@", bt_sha[:12]), ("@HA12@", ha_sha[:12]), ("@BOOT@", bt_line), ("@BTLEN@", "{:,}".format(len(bt_line))), ("@CMD@", cmd_line),
             ("@LINE@", ha_line), ("@SRC@", ha_src.rstrip("\n")), ("@BTSRC@", bt_src.rstrip("\n"))):
    md = md.replace(k, v)
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == bt_line
(rel / "VRN2_HandleAll_v0103.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = r"""# VRN-2 一支 Python · VRN2_RoundAll_v0111.py(套件 v0154 不動 · 只改收尾頁負責方)

`VRN2_RoundAll_v0111.py`(只用 Python 標準庫 · SHA-256 `@RA12@`)= v0110 + 收尾頁 Combined:共識欄空、代號不是台股 4 碼(GFHK Apple · AAPL)→ 資料源
(TICKER 空白 → 人工 · 台股代號的「共識缺」照舊 VRN-2)。自測 51 項(v0110 的 50 項 + 51)。套件 `vrn2_release_v0154/VRN2_Closeout_v0154.zip`(SHA-256 `@WANT12@`)。
**最省事:`VRN2_HandleAll_v0103.md` 最上面那一行**。前版 v0110 的說明見 `vrn2_release_v0154/VRN2_RoundAll_v0110.md`。

## 在 PowerShell 7 視窗直接貼(約 2,300 字元)

```powershell
@PS7@
```

## 已經有這個檔時

```bat
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0111.py" --only report,closeout,pasteback
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0111.py" --only package,fix,report,closeout,pasteback
```
"""
ra_md = ra_md.replace("@RA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PS7@", ps7)
(rel / "VRN2_RoundAll_v0111.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0111 + VRN2_HandleAll_v0103 (package v0154 unchanged)", "date": "2026-10-31",
        "trigger": "桌機 2026-10-31 02:06 Handle-All v0102 repair:⑥f GREEN(ConsensusJoin v0103 · 搬 38 / 43 · 8358 / 2891 抓到 · 404 × 3 不納入閘)· 收尾 OPEN「VRN-2 1」= Combined 冊 GFHK Apple(AAPL)共識欄空被 v0110 算 VRN-2",
        "package": {"name": "VRN2_Closeout_v0154.zip", "folder": "vrn2_release_v0154", "sha256": want, "changed": False},
        "fixes": {"RoundAll_v0111_non_tw_consensus": "Combined gaps: consensus columns empty and TICKER not a TW 4-digit code → 'code is not a TW 4-digit code · consensus covers TW only' → data source (blank TICKER → human), same rule as TARGET_PRICE(ADJ); v0109 got data source by accident (batch summary text), v0110 → VRN-2; selftest 51",
                  "HandleAll_v0103": "v0102 pointed at RoundAll v0111 (vrn2_release_v0155); short line / boot line / cmd line as v0102"},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0110.py", "sha256": r154["roundall"]["sha256"], "status": "superseded 2026-10-31 (AAPL consensus gap counted as VRN-2); file kept in vrn2_release_v0154"}],
        "roundall": {"name": "VRN2_RoundAll_v0111.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0111.md"},
        "handleall": {"name": "VRN2_HandleAll_v0103.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0103_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "not_fixed_here": r154["not_fixed_here"], "results": {"status": "see VRN2_Verification_v0155.md"}}
(rel / "VRN2_Release_v0155.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("built", sorted(p.name for p in rel.iterdir()))
