"""VRN2_RoundAll_v0111.py = v0110 + 收尾頁 Combined:代號不是台股 4 碼的列(GFHK Apple · AAPL)共識欄空 → 資料源(v0110 算成 VRN-2 · 桌機 2026-10-31 02:06 repair)。
套件仍是 v0154(不動);只改負責方判斷。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v154/new/VRN2_RoundAll_v0110.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0110'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0110 — ', '"""VRN2_RoundAll v0111 — ', 1)
at = doc.index("v0110(桌機 2026-10-30 20:09")
doc = doc[:at] + r'''v0111(桌機 2026-10-31 02:06 · Handle-All v0102 repair · 608 秒:⑥f 用 ConsensusJoin v0103 重跑 → 搬 38 / 43 份 · 8358 / 2891 抓到 · 4171 / 6933 / 7728 重試仍 404 →
  不納入閘 → GREEN;收尾卻 OPEN「VRN-2 1」= ⑥ Combined 冊):GFHK Apple(TICKER AAPL,不是台股 4 碼)那一列共識欄空。v0109 以前碰巧被整批摘要裡的
  「鉅亨沒有 FactSet 頁」字樣算成資料源;v0110 拿掉整批摘要的代號清單後掉進「共識缺 → VRN-2」。v0111:共識欄空、代號不是台股 4 碼 →
  「代號不是台股 4 碼 · 共識只查台股」(TICKER 有值 = 資料源 · 空白 = 人工 · 同調整後目標價的規則)。套件仍是 v0154。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0110.py", "用法:python VRN2_RoundAll_v0111.py")
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0110"', 'VERSION = "v0111"')
rep('''                elif "共識引擎這次沒有產出" in st_row:
                    add(col, "共識引擎這次沒有產出(整批沒抓到)", "資料源", fname)
                elif m:''', '''                elif "共識引擎這次沒有產出" in st_row:
                    add(col, "共識引擎這次沒有產出(整批沒抓到)", "資料源", fname)
                elif not code:                                                 # v0111 代號不是台股 4 碼 → 共識不查(同調整後目標價的規則)
                    tk = str(r.get("TICKER") or "").strip()
                    add(col, "代號不是台股 4 碼(TICKER %s)· 共識只查台股" % (repr(tk) if tk else "空白"), "資料源" if tk else "人工", fname)
                elif m:''')
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()''', r'''        # 51 v0111 桌機 02:06:Combined 的 AAPL 列
        why40 = "共識 40 / 40 代號 · FactSet 中位數 40 · YFinance 中位數 39 · 上櫃 .TWO 7 · gate PASS_WITH_WARNINGS · rc 0 · 鉅亨沒有 FactSet 頁(404)不納入閘:4171,6933,7728"
        rows51 = [{"TICKER": "AAPL", "FILENAME": "GFHK - Apple update 20260915.pdf", "TARGET_PRICE": "", "FACTSET_TARGET_PRICE_MEDIAN": "", "YFINANCE_TARGET_PRICE_MEDIAN": "", "2026_DILUTED_EPS_FACTSET": "",
                   "STATUS": "CONSENSUS: 缺:" + why40 + " | BASIC: B"},
                  {"TICKER": "6933", "FILENAME": "6933_AMAX-KY_個股介紹報告.pdf", "TARGET_PRICE": "", "FACTSET_TARGET_PRICE_MEDIAN": "", "STATUS": "CONSENSUS: 缺:鉅亨沒有 FactSet 頁(404) | BASIC: B"},
                  {"TICKER": "2330", "FILENAME": "a.pdf", "TARGET_PRICE": "", "FACTSET_TARGET_PRICE_MEDIAN": "1450.00", "STATUS": "CONSENSUS: FactSet(鉅亨)20 位"}]
        g51, o51 = combined_gaps(rows51, {"4171", "6933", "7728"}, True)
        g51b, o51b = combined_gaps([dict(rows51[0], TICKER="")], set(), True)
        g51c, o51c = combined_gaps([dict(rows51[0], TICKER="1590")], set(), True)
        chk("51 Combined:代號不是台股 4 碼(GFHK Apple · AAPL)那列共識欄空 → 資料源(桌機 02:06 被 v0110 算成 VRN-2)· TICKER 空白 → 人工 · 台股代號的「共識缺」照舊 VRN-2",
            o51 == "資料源" and g51["FACTSET_TARGET_PRICE_MEDIAN"] == {"代號不是台股 4 碼(TICKER 'AAPL')· 共識只查台股": 1, "鉅亨沒有這檔的 FactSet 頁(404)": 1}
            and o51b == "人工" and o51c == "VRN-2" and not combined_consensus_only(g51))
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0110.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0111.py"').replace('"VRN2_RoundAll_v0110.py" in html_', '"VRN2_RoundAll_v0111.py" in html_')
assert "VRN2_RoundAll_v0110.py" not in s, [m.start() for m in re.finditer("VRN2_RoundAll_v0110.py", s)]
(S / "v155/new").mkdir(parents=True, exist_ok=True)
(S / "v155/new/VRN2_RoundAll_v0111.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0111 lines", s.count("\n"))
