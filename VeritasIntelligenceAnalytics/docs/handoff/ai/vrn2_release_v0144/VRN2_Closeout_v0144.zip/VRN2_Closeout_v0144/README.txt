VRN2_Closeout_v0144 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0144.py [--source <folder>] [--no-install] [--no-open]
Runtime: VRN2_Runtime_v0144.zip = runtime v0142 (162 members byte-identical) + VRN2_UIAction_v0108 + VRN2_OutputStore_v0100 + VRN2_SSOTSync_v0100 + VRN2_Workbench_v0101
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched; handler number v0108 because v0105 / v0107 belong to the desktop line's publish handlers).

New in v0144 (operator policy 2026-10-29):
 - output location: Workbench / legacy U/I 'select output folder' (vrn2://pick?kind=outdir · Windows dialog; drag zone opens the dialog; a OneDrive / Google Drive / Dropbox synced folder = cloud); VRN2_OUTPUT_DIR seeds it
 - ⑬ output store: mirror of the four books + Workbench + receipts to <out>/VRN2/latest; incremental Parquet store managed by DuckDB (<out>/VRN2/vrn2_store.duckdb · parquet/<book>/run=<id>.parquet · catalog.parquet); only files new by SHA-256 are appended; pyarrow fallback when duckdb is missing
 - ⑤b SSOT-ID sync: VRN-2 side of the three-system numbering protocol (request with blank ssot_id → VCGC grant / conflict → auto-fill into a new register version); see docs/handoff/ai/VIA_SSOT_ID_Protocol_v0100.md
 - Workbench v0101: output-location / store panel (export tab) and SSOT-ID status (handover tab)
Also v0143: single-instance lock, wider child limits, ⑫b in-process fallback.
Exit codes: 0 GREEN · 2 YELLOW · 1 RED.
