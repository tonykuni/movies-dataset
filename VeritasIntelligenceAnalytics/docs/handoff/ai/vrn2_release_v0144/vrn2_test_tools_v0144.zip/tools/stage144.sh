#!/bin/bash
# v0144 放進倉:docs/handoff/ai/vrn2_release_v0144/ + vrn1_vrn2_oneclick_v0105/ + functional modules/VRN/ 新工具(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v144
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0144; OP=$REPO/vrn1_vrn2_oneclick_v0105; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v144")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0144"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0105")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("full144.log", "full144.rc", "t144_setup.log", "pscheck144.log", "duck144.log", "duck144_sql.log", "scen144.rc", "scen144_first.log", "scen144_again.log", "scen144_tamper.log", "scen144_setup.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0144_selftest.log", "VRN2_SSOTSync_v0100_selftest.log", "VRN2_OutputStore_v0100_selftest.log", "VRN2_UIAction_v0108_selftest.log", "VRN2_Workbench_v0101_selftest.log")]
v2 = W / "t144/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0144.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_Activate_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Output_Config.json"):
    logs.append(("t144/" + n, v2 / n))
for n in ("VRN2_NUMBER_REQUEST_latest.json", "VRN2_NUMBER_STATE_latest.json"):
    logs.append(("t144/contract/" + n, W / "t144/VIA/functional modules/VRN2/contract" / n))
z(D / "logs_v0144.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py"))]
z(D / "vrn2_test_tools_v0144.zip", tools)
z(OP / "tools_v0105.zip", [("tools/" + q.name, q) for q in (W / "operator105" / "boot_pair105.ps1", W / "operator105" / "oneline_pair105.txt", W / "operator105" / "Run-VRN1-VRN2-v0105.ps1")])
for n in ("VRN1_VRN2_OneClick_v0105.md", "VRN1_VRN2_Verification_v0105.md"): shutil.copy(W / "operator105" / n, OP / n)
for n in ("VRN2_Closeout_v0144.zip", "VRN2_Release_v0144.json", "VRN2_OneClick_v0144.md", "VRN2_Verification_v0144.md"): shutil.copy(W / "release144" / n, D / n)
# 新成員只在私有 runtime zip(functional modules/VRN2)與 vrn2_test_tools_v0144.zip/new;不放共用 VRN 夾(桌機線 v0105 / v0107 在那裡,免得版本鏈混線)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
