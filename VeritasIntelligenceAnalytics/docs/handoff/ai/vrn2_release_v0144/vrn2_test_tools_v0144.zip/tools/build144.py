"""v0144 整包重建(冪等):runtime zip → pkg144 → release zip/json → 一鍵 v0144 md → 操作員 v0105 md → LocalRound 指回。"""
import base64, hashlib, json, re, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); old, new, out, rel = S / "v143/pkg143", S / "v144/new", S / "v144/pkg144", S / "v144/release144"
HANDLER = "VRN2_UIAction_v0108.py"
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_OCRBridge_v0101.py", "VRN2_VerbatimVerifier_v0104.py"): shutil.copy2(old / n, out / n)
for n in ("ActivateVRN-2_v0144.py", "VRN2_SSOTSync_v0100.py", "VRN2_OutputStore_v0100.py"): shutil.copy2(new / n, out / n)
for stale in out.glob("VRN2_UIAction_v*.py"): stale.unlink()
om = json.loads((old / "VRN2_Runtime_v0142.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
with zipfile.ZipFile(old / "VRN2_Runtime_v0142.zip") as z: members = {n: z.read(n) for n in old_names}
for e in om["files"]: assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"]
new_names = [HANDLER, "VRN2_OutputStore_v0100.py", "VRN2_SSOTSync_v0100.py", "VRN2_Workbench_v0101.py"]
for n in new_names: assert n not in members; members[n] = (new / n).read_bytes()
names = sorted(members); zp = out / "VRN2_Runtime_v0144.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0144", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0142.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names, "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0144.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
print("runtime v0144", len(names), man["zip_sha256"][:12])
# release
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0144.py", "VRN2_Runtime_v0144.zip", "VRN2_Runtime_v0144.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0144 — VRN-2 closeout package (2026-10-29)\n\nEntry: python ActivateVRN-2_v0144.py [--source <folder>] [--no-install] [--no-open]\n"
  "Runtime: VRN2_Runtime_v0144.zip = runtime v0142 (162 members byte-identical) + VRN2_UIAction_v0108 + VRN2_OutputStore_v0100 + VRN2_SSOTSync_v0100 + VRN2_Workbench_v0101\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched; handler number v0108 because v0105 / v0107 belong to the desktop line's publish handlers).\n\n"
  "New in v0144 (operator policy 2026-10-29):\n"
  " - output location: Workbench / legacy U/I 'select output folder' (vrn2://pick?kind=outdir · Windows dialog; drag zone opens the dialog; a OneDrive / Google Drive / Dropbox synced folder = cloud); VRN2_OUTPUT_DIR seeds it\n"
  " - ⑬ output store: mirror of the four books + Workbench + receipts to <out>/VRN2/latest; incremental Parquet store managed by DuckDB (<out>/VRN2/vrn2_store.duckdb · parquet/<book>/run=<id>.parquet · catalog.parquet); only files new by SHA-256 are appended; pyarrow fallback when duckdb is missing\n"
  " - ⑤b SSOT-ID sync: VRN-2 side of the three-system numbering protocol (request with blank ssot_id → VCGC grant / conflict → auto-fill into a new register version); see docs/handoff/ai/VIA_SSOT_ID_Protocol_v0100.md\n"
  " - Workbench v0101: output-location / store panel (export tab) and SSOT-ID status (handover tab)\n"
  "Also v0143: single-instance lock, wider child limits, ⑫b in-process fallback.\nExit codes: 0 GREEN · 2 YELLOW · 1 RED.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0144.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0144", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0144.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0144/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
rt = json.loads(files["VRN2_Runtime_v0144.json"].decode("utf-8"))
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0144", "date": "2026-10-29",
       "operator_policy_2026_10_29": "三系統獨立 · SSOT / Regex / 同義字 / 政策由基層提出(ID 空白)→ VCGC 核號 → 子系統自動補填;VRN-2 快速收尾用 HTML U/I:輸出位置 Windows I/O(拖曳 / 對話框)或連接雲端 · 輸出 Parquet 增量擷取 · 增量擷取用 DuckDB 管理",
       "base_package": {"name": "VRN2_Closeout_v0143 (launcher v0143 · runtime v0142)", "retained": "runtime v0142 members byte-identical inside runtime v0144; ActivateVRN-2_v0136.py base unchanged"},
       "supersedes": "v0143 for the closeout entry; VRN-2 one-click v0143; operator one-click v0104 → v0105",
       "design": {"ActivateVRN-2_v0144": "⑤b SSOT-ID sync after ⑤ · ⑬ output store after the closeout receipt (GRAY until an output folder is chosen · VRN2_OUTPUT_DIR seeds) · handler v0108 registered · Workbench v0101 · receipt v0144 gains ssot_sync / output_store",
                  "VRN2_OutputStore_v0100": "mirror + DuckDB incremental store (catalog by SHA-256 · per-book tables with run_id/file_sha · Parquet partitions per run · catalog.parquet) · pyarrow fallback · receipt VRN2_OutputStore_latest.json",
                  "VRN2_SSOTSync_v0100": "request (enriched · ssot_id blank · self-conflicts) · apply (grants → ssot_id · conflicts → 待人判 · new register version) · sync",
                  "VRN2_UIAction_v0108": "vrn2://pick?kind=outdir (FolderBrowserDialog · ShowNewFolderButton) · vrn2://outdir?reset=1 · --set-outdir · 輸出位置 block in the legacy U/I (number skips the desktop line's v0105 / v0107)",
                  "VRN2_Workbench_v0101": "export tab: 輸出位置 panel (buttons · drop zone → dialog · store receipt table); handover tab: SSOT-ID status table"},
       "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
       "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0144.json inside the package"},
       "tested_in": "Linux container · python 3.13 venv_vrn2 (pyarrow · no duckdb) + venv_duck (duckdb 1.5.6) · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0144.md"},
       "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0144/<files> (no .ps1 · the one-click md is the entry)"},
       "launcher": {"name": "ActivateVRN-2_v0144.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0144.py"]).hexdigest()}, "oneclick": "VRN2_OneClick_v0144.md", "test_tools_zip": "vrn2_test_tools_v0144.zip", "logs_zip": "logs_v0144.zip"}
(rel / "VRN2_Release_v0144.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8"); print("package", want[:12])
# one-click v0144 from v0143
md = (S / "v143/release143/VRN2_OneClick_v0143.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1)
def rep(a, b):
    global ps
    assert ps.count(a) == 1, (ps.count(a), a[:80]); ps = ps.replace(a, b)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1)
rep("  $Want   = '%s'   # VRN2_Closeout_v0143.zip SHA-256(套件 · 內含啟動器 v0143 + runtime v0142 清單 · runtime 不動)" % old_want, "  $Want   = '%s'   # VRN2_Closeout_v0144.zip SHA-256(套件 · 內含啟動器 v0144 + runtime v0144 清單 = v0142 + 處理器 v0108 / OutputStore / SSOTSync / Workbench v0101)" % want)
rep("[計] VRN-2 一鍵 v0143 · ActivateVRN-2 v0143(套件 · 私有 runtime v0142 不動:管理器 v0243 · 摘要器 v0117 · 驗證器 v0110 · 原文核對 v0104 · Workbench U/I v0100;v0143 = 單機閘 · 子行程上限加寬 · ⑫b 本支補放)",
    "[計] VRN-2 一鍵 v0144 · ActivateVRN-2 v0144(套件 · 私有 runtime v0144 = v0142 + 處理器 v0108 · OutputStore v0100 · SSOTSync v0100 · Workbench v0101;管理器 v0243 · 摘要器 v0117 · 驗證器 v0110 · 原文核對 v0104;v0144 = 輸出位置 window I/O · DuckDB 增量 Parquet 庫 · SSOT-ID 協作;v0143 = 單機閘 · 上限 · ⑫b 補放)")
rep("  # ===== VRN-2 一鍵 v0143(套件 v0143 = 啟動器 v0143 + runtime v0142 不動;", "  # ===== VRN-2 一鍵 v0144(套件 v0144 = 啟動器 v0144 + runtime v0144;v0144 = 操作員 2026-10-29 政策:⑬ 輸出位置(U/I 選輸出夾 · Windows 對話框 / 拖曳 → 對話框 / OneDrive 等同步夾 = 雲端)+ 增量 Parquet 庫(DuckDB · 只追加 SHA-256 新檔的列 · pyarrow 備援)· ⑤b SSOT-ID 核號同步(VRN-2 側:請求冊 ssot_id 空白 → 讀 VCGC 核發 / 衝突 → 自動補填出新版登記冊)· 處理器 v0108(v0105 / v0107 是桌機線的號)· Workbench v0101;v0143 = 啟動器 v0143 + runtime v0142 不動;")
rep('cl = j(v2 / "VRN2_Closeout_v0143.json") or {}', 'cl = j(v2 / "VRN2_Closeout_v0144.json") or {}')
rep('"%s|⑧b 收尾收據 v0143 · rc %s', '"%s|⑧b 收尾收據 v0144 · rc %s')
rep('"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0143.json(啟動器 v0143 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"', '"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0144.json(啟動器 v0144 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"')
rep('''wb = cl.get("workbench") or {}
if wb:
    print("%s|Workbench U/I v0100 · %s" % ("GREEN" if wb.get("lamp") == "GREEN" else "YELLOW", (wb.get("path") or wb.get("detail") or "")[:150]))
else:
    print("YELLOW|Workbench U/I 沒渲染(收據沒有 workbench 欄)")''', '''wb = cl.get("workbench") or {}
if wb:
    print("%s|Workbench U/I v0101 · %s" % ("GREEN" if wb.get("lamp") == "GREEN" else "YELLOW", (wb.get("path") or wb.get("detail") or "")[:150]))
else:
    print("YELLOW|Workbench U/I 沒渲染(收據沒有 workbench 欄)")
st_ = cl.get("output_store") or {}
if st_.get("lamp") == "GRAY":
    print("GRAY|⑬ 輸出位置未設定 · 輸出留在 VIA_Reports\\\\vrn2\\\\output(Workbench「選擇輸出夾…」或 $env:VRN2_OUTPUT_DIR)")
elif st_:
    print("%s|⑬ 輸出位置 %s · 增量庫 %s · 新檔 %d / 已知 %d · 追加 %s · parquet %d%s" % ({"GREEN": "GREEN", "YELLOW": "YELLOW"}.get(st_.get("lamp"), "RED"), st_.get("output_dir", ""), st_.get("store_engine", ""), len(st_.get("new_files") or []), len(st_.get("known_files") or []), " / ".join("%s %s" % (k, v) for k, v in (st_.get("appended") or {}).items()), len(st_.get("parquet_files") or []), (" · " + st_["why"]) if st_.get("why") else ""))
ss_ = cl.get("ssot_sync") or {}
if ss_:
    print("%s|⑤b SSOT-ID 核號同步 · %s" % ({"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(ss_.get("lamp"), "YELLOW"), (ss_.get("detail") or "")[:200]))''')
rep("'VRN2', 'VRN2_UIAction_v0104.py')   # v0142:處理器在私有 runtime", "'VRN2', 'VRN2_UIAction_v0108.py')   # v0144:處理器 v0108 在私有 runtime(v0105 / v0107 是桌機線的 publish 處理器)")
rep("($regH -match '[\\\\/]VRN2_UIAction_v0104\\.py$')", "($regH -match '[\\\\/]VRN2_UIAction_v0108\\.py$')")
rep("($cf.handler -eq 'VRN2_UIAction_v0104.py')", "($cf.handler -eq 'VRN2_UIAction_v0108.py')")
rep('"③ 本機套件不是 v0143,且讀不到', '"③ 本機套件不是 v0144,且讀不到'); rep('"③ 本機已是 v0143 套件(', '"③ 本機已是 v0144 套件(')
for a, b in (("VRN2_Closeout_v0143", "VRN2_Closeout_v0144"), ("vrn2_release_v0143", "vrn2_release_v0144"), ("ActivateVRN-2_v0143", "ActivateVRN-2_v0144"), ("VRN-2 一鍵 v0143", "VRN-2 一鍵 v0144"), ("vrn2_v0143_", "vrn2_v0144_"), ("套件 v0143 就位", "套件 v0144 就位"), ("啟動器 v0143", "啟動器 v0144"), ("VRN2_UIAction_Config.json v0143", "VRN2_UIAction_Config.json v0144"), ("'ActivateVRN-2 v0143'", "'ActivateVRN-2 v0144'"), ("# v0143 發行所在", "# v0144 發行所在"), ("VRN2_Handover_v0143", "VRN2_Handover_v0144"), ("VRN2_Release_v0143", "VRN2_Release_v0144"), ("VRN2_UIAction_v0104.py", "VRN2_UIAction_v0108.py")):
    ps = ps.replace(a, b)
assert ps.count("v0143 = 啟動器 v0144 + runtime v0142 不動") == 1; ps = ps.replace("v0143 = 啟動器 v0144 + runtime v0142 不動", "v0143 = 啟動器 v0143 + runtime v0142 不動")
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0143" in code and "v0143 =" not in code), line[:160]; assert "VRN2_UIAction_v0104" not in code and "VRN2_UIAction_v0105" not in code, line[:160]
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1), cs).replace("vrn2_release_v0143", "vrn2_release_v0144").replace("VRN2_OneClick_v0143.md", "VRN2_OneClick_v0144.md").replace("v0143", "v0144") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = (S / "v144/oneclick144_head.md").read_text(encoding="utf-8")
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps
(rel / "VRN2_OneClick_v0144.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot144.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline144.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0144.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0144", cs[:12])
# operator v0105 from v0104
out5 = S / "v144/operator105"; md4 = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0104/VRN1_VRN2_OneClick_v0104.md").read_text(encoding="utf-8")
ps4 = re.search(r"(?s)```powershell\n(.*?)\n```", md4).group(1); boot4 = re.search(r"(?s)```text\n(.*?)\n```", md4).group(1); one4 = re.search(r"(?s)```bat\n(.*?)\n```", md4).group(1)
p5 = ps4
def rep5(a, b):
    global p5
    assert p5.count(a) == 1, (p5.count(a), a[:80]); p5 = p5.replace(a, b)
rep5("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0143'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0144'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0143 程式碼 SHA-256", p5).group(1)
rep5("  $H2 = '%s'   # VRN-2 一鍵 v0143 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0144 程式碼 SHA-256" % cs)
rep5("  # ===== VRN-1 / VRN-2 操作員一鍵 v0104(2026-10-29 · ② 改指 VRN-2 一鍵 v0143:", "  # ===== VRN-1 / VRN-2 操作員一鍵 v0105(2026-10-29 · ② 改指 VRN-2 一鍵 v0144:輸出位置 window I/O · DuckDB 增量 Parquet 庫 · SSOT-ID 協作;v0104 · ② 改指 VRN-2 一鍵 v0143:")
rep5("操作員一鍵 v0104 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0105 · {0} · VRN-1 {1} · VIA {2}")
p5 = p5.replace("VRN2_OneClick_v0143.md", "VRN2_OneClick_v0144.md").replace("VRN-2 一鍵 v0143", "VRN-2 一鍵 v0144").replace("套件 v0143 = 啟動器 v0143 + runtime v0142", "套件 v0144 = 啟動器 v0144 + runtime v0144").replace("ActivateVRN-2_v0143 單機閘", "ActivateVRN-2_v0144 單機閘")
for line in p5.splitlines():
    code = line.split("#", 1)[0]; assert "v0143" not in code or "v0143:" in code, line[:160]
cs5 = hashlib.sha256(p5.encode("utf-8")).hexdigest()
boot5 = boot4.replace(re.search(r"\$H  = '([0-9a-f]{64})'", boot4).group(1), cs5).replace("vrn1_vrn2_oneclick_v0104", "vrn1_vrn2_oneclick_v0105").replace("VRN1_VRN2_OneClick_v0104.md", "VRN1_VRN2_OneClick_v0105.md").replace("操作員一鍵 v0104", "操作員一鍵 v0105") + "\n"
one5 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot5.encode("utf-16-le")).decode("ascii")
text = md4.replace("```powershell\n" + ps4 + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + boot4 + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + one4 + "\n```", "```bat\n@ONE@\n```")
old_cs4 = hashlib.sha256(ps4.encode("utf-8")).hexdigest()
text = text.replace(old_cs4, cs5).replace(old_cs4[:12], cs5[:12]).replace(old_h2, cs).replace(old_h2[:12], cs[:12]).replace("v0104", "v0105").replace("VRN-2 一鍵 v0143", "VRN-2 一鍵 v0144").replace("vrn2_release_v0143", "vrn2_release_v0144").replace("VRN2_OneClick_v0143", "VRN2_OneClick_v0144")
head_old = text.split("\n", 1)[0]; text = text.replace(head_old, "# VRN-1 / VRN-2 操作員一鍵 v0105(cmd / PowerShell 都能貼 · v0104 + ② 改指 VRN-2 一鍵 v0144:輸出位置 window I/O · DuckDB 增量 Parquet 庫 · SSOT-ID 協作)", 1)
intro_old = text.split("\n\n", 2)[1]; text = text.replace(intro_old, "操作員 2026-10-29 政策(三系統獨立 · SSOT-ID 由 VCGC 核號子系統補填 · VRN-2 快速收尾:輸出位置 Windows I/O / 雲端 · Parquet 增量擷取 · DuckDB 管理)。v0105 = v0104 + ② 改指 **VRN-2 一鍵 v0144**(套件 v0144 = 啟動器 v0144 + runtime v0144:處理器 v0108 · OutputStore · SSOTSync · Workbench v0101);其餘一字不改。\n\n" + intro_old, 1)
text = text.replace("@PS@", p5).replace("@BOOT@", boot5.rstrip("\n")).replace("@ONE@", one5)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p5 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot5
(out5 / "VRN1_VRN2_OneClick_v0105.md").write_text(text, encoding="utf-8", newline="\n"); (out5 / "boot_pair105.ps1").write_text(boot5, encoding="utf-8", newline="\n"); (out5 / "oneline_pair105.txt").write_text(one5 + "\n", encoding="utf-8"); (out5 / "Run-VRN1-VRN2-v0105.ps1").write_text(p5 + "\n", encoding="utf-8", newline="\n"); (out5 / "code_sha.txt").write_text(cs5)
print("operator v0105", cs5[:12])
lr = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/VRN2_LocalRound_v0100.md"); s = lr.read_text(encoding="utf-8")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0105 程式碼 SHA-256", "$H_OP = '%s'   # 操作員一鍵 v0105 程式碼 SHA-256" % cs5, s, count=1); assert cs5 in s
lr.write_text(s, encoding="utf-8"); print("localround H_OP", cs5[:12])
