"""收尾 v0144:results → VRN2_Release_v0144.json.results · VRN2_Verification_v0144.md(套件 zip 已定,不重算)。"""
import json, re
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v144")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def grep(path, pat, last=True):
    try: hits = [l for l in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if re.search(pat, l) and "<Objs" not in l and "</S>" not in l and "<S N=" not in l and "</U32>" not in l]
    except OSError: return ""
    return (hits[-1] if last else hits[0]) if hits else ""
def esc(x): return str(x).replace("|", "\\|")
o = W / "t144/VIA/VIA_Reports/vrn2"
cl = j(o / "VRN2_Closeout_v0144.json", {}); idem = j(o / "IDEMPOTENCE_latest.json", {}); comp = j(o / "VRN2_Completion_latest.json", {})
line7 = grep(W / "full144.log", r"⑦ 啟動 VRN-2 · \[計\] VRN-2 個股四項"); m7 = re.search(r"個股四項 · (\d+) 份\(全綠 (\d+)\)", line7)
line11 = grep(W / "full144.log", r"⑪ 獨立驗證\(背景 · 只讀\) ·"); m11 = re.search(r"基本資料 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 一標題四重點 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 年度數據 (\d+) 筆 · (\{[^}]*\})", line11)
st = cl.get("output_store") or {}; ss = cl.get("ssot_sync") or {}; wb = cl.get("workbench") or {}
req = j(W / "t144/VIA/functional modules/VRN2/contract/VRN2_NUMBER_REQUEST_latest.json", {}); state = j(W / "t144/VIA/functional modules/VRN2/contract/VRN2_NUMBER_STATE_latest.json", {})
non_green = [(s.get("step"), s.get("lamp")) for s in cl.get("steps", []) if s.get("lamp") != "GREEN"]
selft = {}
for n, pat in (("ActivateVRN-2_v0144", r"\[PASS\] v0144"), ("VRN2_SSOTSync_v0100", r"--selftest · OK"), ("VRN2_OutputStore_v0100", r"--selftest · OK"), ("VRN2_UIAction_v0108", r"自測 \d+/\d+"), ("VRN2_Workbench_v0101", r"--selftest · OK")):
    selft[n] = grep(W / (n + "_selftest.log"), pat).strip()[:220]
duck = (W / "duck144_sql.log").read_text(encoding="utf-8").splitlines() if (W / "duck144_sql.log").exists() else []
scen_rc = (W / "scen144.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen144.rc").exists() else "not run"
scen_first = grep(W / "scen144_first.log", r"③ 套件 v0144 就位|③ 本機已是 v0144"); scen_again = grep(W / "scen144_again.log", r"③ 本機已是 v0144|③ 套件 v0144 就位"); scen_tamper = (grep(W / "scen144_tamper.log", r"③ 本機套件夾有 \d+ 個檔與已驗證的 zip 不同").strip()[:160] + " → " + grep(W / "scen144_tamper.log", r"③ 舊套件夾已改名備份").strip()[:120])
scen_wb = grep(W / "scen144_first.log", r"Workbench U/I v0101"); scen_8b = grep(W / "scen144_first.log", r"⑧b 收尾收據 v0144"); scen_13 = grep(W / "scen144_first.log", r"⑬ 輸出位置"); scen_5b = grep(W / "scen144_first.log", r"⑤b SSOT-ID"); scen_h = grep(W / "scen144_first.log", r"⑤b .*處理器|vrn2:// 註冊")
R = {"selftests": selft, "pwsh_hash_chain": [l for l in (W / "pscheck144.log").read_text(encoding="utf-8").splitlines() if l.strip()],
     "full_run_v0144_19_real": {"closeout_rc": cl.get("rc"), "rc_reason": "③ 環境檢查 RED in the Linux sandbox only (accelerator deps not in venv; --no-install); same as v0142 / v0143", "non_green_steps": non_green,
        "lock_removed_after_run": not (o / "VRN2_Launcher.lock").exists(), "limits": cl.get("limits"), "ui_block": cl.get("ui_block"),
        "passes": [(p.get("attempt"), p.get("rc"), p.get("idempotence")) for p in cl.get("passes", [])], "completion": {"verdict": comp.get("verdict"), "red": comp.get("red"), "yellow": comp.get("yellow"), "manager": comp.get("manager")},
        "stock_reports": {"n": int(m7.group(1)) if m7 else None, "all_green": int(m7.group(2)) if m7 else None}, "idempotence": idem.get("classification"),
        "source_quotes": (cl.get("source_quotes") or {}).get("counts"), "output_gaps": cl.get("output_gaps"),
        "independent_verifier": {"basic": m11.group(2) if m11 else "", "summary": m11.group(4) if m11 else "", "financial_rows": int(m11.group(5)) if m11 else None, "financial_verdicts": m11.group(6) if m11 else ""},
        "registration_line": grep(W / "full144.log", r"註冊核對 ·").strip()[:200],
        "ssot_sync": {"lamp": ss.get("lamp"), "detail": ss.get("detail"), "apply": ss.get("apply"), "request_counts": (req.get("counts") or (ss.get("request") or {}).get("counts")), "request_file": "functional modules/VRN2/contract/VRN2_NUMBER_REQUEST_latest.json", "state_file_written": bool(state)},
        "output_store": {"lamp": st.get("lamp"), "why": st.get("why"), "store_engine": st.get("store_engine"), "cloud_hint": st.get("cloud_hint"), "mirrored": len(st.get("mirrored") or []) if isinstance(st.get("mirrored"), list) else st.get("mirrored"), "new_files": len(st.get("new_files") or []), "known_files": len(st.get("known_files") or []), "appended": st.get("appended"), "totals": st.get("totals"), "parquet_files": len(st.get("parquet_files") or [])},
        "workbench": {"lamp": wb.get("lamp"), "legacy_linked": wb.get("legacy_linked")}},
     "duckdb_real_path": {"env": "venv_duck · python 3.13 · duckdb 1.5.6 (no pyarrow)", "first_sync": grep(W / "duck144.log", r"本輪新檔 14").strip()[:400],
        "second_sync": grep(W / "duck144.log", r"本輪新檔 0 ").strip()[:400], "first_new": 14, "second_new": 0, "catalog_files": 14, "sql": duck, "selftest": selft["VRN2_OutputStore_v0100"]},
     "oneclick_scenario_pwsh": {"rc": scen_rc, "first": scen_first.strip()[:200], "again": scen_again.strip()[:200], "tamper": scen_tamper.strip()[:200], "workbench_line": scen_wb.strip()[:160], "closeout_line": scen_8b.strip()[:200], "step13_line": scen_13.strip()[:260], "step5b_ssot_line": scen_5b.strip()[:200], "handler_line": scen_h.strip()[:200]},
     "not_claimed": ["Windows desktop run of v0144: not yet (next paste-back); the desktop has not run v0143 either",
                     "VCGC side of the SSOT-ID protocol (reading VRN2_NUMBER_REQUEST_latest.json, writing VCGC_NUMBER_GRANT_latest.json): contract only (VIA_SSOT_ID_Protocol_v0100.md); not implemented by this line (VCGC is another system)",
                     "A real Windows FolderBrowserDialog for vrn2://pick?kind=outdir: not exercised in the container (handler selftest uses the VRN2_PICK_OUTDIR hook); the dialog code path is the same as vrn2://pick for input (v0133 · desktop-proven)",
                     "Browser drag-and-drop cannot read the dropped folder's real path (browser sandbox); the drop zone opens the dialog instead",
                     "DuckDB path inside the launcher: the launcher sandbox venv has no duckdb (pyarrow fallback · YELLOW); the DuckDB engine was proven with the OutputStore CLI in venv_duck on the same output books",
                     "Items carried from v0143: PasteBack zip 013350 transcript, v0248 / v0253 location on the desktop, verifier wall time on 52 files, 四點 FAIL 1 / 缺項 3 份年度數據"]}
rel_p = W / "release144/VRN2_Release_v0144.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
rr = R["full_run_v0144_19_real"]; sc = R["oneclick_scenario_pwsh"]; dk = R["duckdb_real_path"]; so = rr["output_store"]; sy = rr["ssot_sync"]
md = ["# VRN-2 v0144 容器實測紀錄(2026-10-29)", "",
      "起因:操作員 2026-10-29 政策 —— 三系統獨立、SSOT / Regex / 同義字 / 政策由基層提出(ID 空白)→ VCGC 核號 → 子系統自動補填;VRN-2 快速收尾用 HTML U/I:輸出位置 Windows I/O(拖曳 / 對話框)或連接雲端 · 輸出 Parquet 增量擷取 · 增量擷取用 DuckDB 管理 · 全景式檢視。", "",
      "## 1. 本輪改了什麼", "", "| 元件 | 版本 | 內容 |", "|---|---|---|",
      "| 啟動器 | ActivateVRN-2 v0144(v0136 底座 · v0143 的閘 / 上限 / ⑫b 補放照舊)| ⑤b SSOT-ID 核號同步(⑤ 之後)· ⑬ 輸出位置 / 增量庫(收尾收據之後 · 沒選輸出夾 = 灰 · `VRN2_OUTPUT_DIR` 預設)· 註冊處理器 v0108 · Workbench v0101 · 收據 v0144 多 `ssot_sync` / `output_store` |",
      "| VRN2_SSOTSync | v0100(runtime v0144 新成員)| `request`(登記冊尾版 → 請求冊 `contract/VRN2_NUMBER_REQUEST_latest.json`:ssot_id 空白 · proposed_no · vcgc_kind · 同義字 / 正則 / 來源 sha · 自撞)· `apply`(讀 `VCGC_NUMBER_GRANT_latest.json` 四處只讀合併 → 核發補填出新版登記冊 · 衝突待人判 · `contract/VRN2_NUMBER_STATE_latest.json`)· `sync` |",
      "| VRN2_OutputStore | v0100(runtime v0144 新成員)| 鏡像四本冊 + Workbench + 收據到 `<輸出夾>/VRN2/latest`;DuckDB 增量庫 `vrn2_store.duckdb`(catalog 以 SHA-256 為鍵 · book_* 帶 run_id / file_sha · 只追加新檔)· Parquet 分區 `parquet/<冊>/run=<id>.parquet` + `catalog.parquet`(DuckDB COPY)· 沒 duckdb → pyarrow 備援(黃)· 設定冊 `VRN2_Output_Config.json` · 收據 `VRN2_OutputStore_latest.json` |",
      "| VRN2_UIAction | v0108(v0104 留著;v0105 / v0107 是桌機線 publish 處理器的號)| `vrn2://pick?kind=outdir`(FolderBrowserDialog · 可新建)· `vrn2://outdir?reset=1` · `--set-outdir` · 舊版 U/I「輸出位置(window I/O)」區塊 · OneDrive / Google Drive / Dropbox 同步夾 = 雲端提示 |",
      "| VRN2_Workbench | v0101(v0100 留著 · 字型資產包 v0100 不動)| 匯出分頁:輸出位置面板(選擇 / 取消 · 拖曳區 → 開對話框 · 庫收據表:引擎 / 新檔 / 已知 / 追加 / 累計 / parquet)· 交接分頁:SSOT-ID 協作表(核發 / 衝突 / 待核號)|",
      "| 協定 | `docs/handoff/ai/VIA_SSOT_ID_Protocol_v0100.md` | 三系統共讀的契約:角色 · 請求冊 / 核發冊 JSON 格式 · 衝突規則 · VRN-2 落地位置;VCGC / VDF 側只寫契約,不代寫實作 |",
      "| 一鍵 | VRN-2 一鍵 v0144 · 操作員一鍵 v0105 · 本地實測一輪 v0100 改指 | ⑤b 核對處理器 v0108 · ⑧b 收據 v0144 · 摘要多 ⑬ / ⑤b 兩行 |", "",
      "## 2. 自測與雜湊鏈", "", "| 項 | 結果 |", "|---|---|"] + ["| `%s --selftest` | %s |" % (k, esc(v)) for k, v in R["selftests"].items()] + ["| pwsh 雜湊鏈 | %s |" % esc(l) for l in R["pwsh_hash_chain"]] + ["",
      "## 3. 沙盒全流程(套件 v0144 · 19 份真檔 · `VRN2_OUTPUT_DIR` 指向 OneDrive 式夾 · 容器 venv 沒 duckdb)", "", "| 項 | 結果 |", "|---|---|",
      "| 收尾 rc | %s(%s)|" % (rr["closeout_rc"], rr["rc_reason"]), "| 非綠步驟 | %s |" % esc(rr["non_green_steps"]),
      "| 單機閘 / 上限 / ⑫b | 結束後鎖檔已移除 %s · %s · ui_block %s |" % (rr["lock_removed_after_run"], esc(rr["limits"]), esc(rr["ui_block"])),
      "| 輪數 / 冪等 | %s · %s |" % (rr["passes"], rr["idempotence"]),
      "| ⑧ 完成判定 | %s · 紅 %s 黃 %s · %s |" % (rr["completion"]["verdict"], rr["completion"]["red"], rr["completion"]["yellow"], rr["completion"]["manager"]),
      "| ⑦ 個股四項 | %s 份 · 全綠 %s |" % (rr["stock_reports"]["n"], rr["stock_reports"]["all_green"]),
      "| 四點原文核對 | %s · 缺項 %s |" % (rr["source_quotes"], rr["output_gaps"]),
      "| ⑪ 獨立驗證 | 基本資料 %s · 四點 %s · 年度 %s 筆 %s |" % (rr["independent_verifier"]["basic"], rr["independent_verifier"]["summary"], rr["independent_verifier"]["financial_rows"], rr["independent_verifier"]["financial_verdicts"]),
      "| 註冊核對 | %s |" % esc(rr["registration_line"]),
      "| **⑤b SSOT-ID** | %s · %s · 請求冊 %s · counts %s · STATE 已寫 %s |" % (sy["lamp"], esc(sy["detail"]), sy["request_file"], esc(sy["request_counts"]), sy["state_file_written"]),
      "| **⑬ 輸出位置 · 增量庫** | %s · %s · 引擎 %s · 鏡像 %s · 新檔 %s / 已知 %s · 追加 %s · 累計 %s · parquet %s · %s |" % (so["lamp"], esc(so["cloud_hint"]), so["store_engine"], so["mirrored"], so["new_files"], so["known_files"], esc(so["appended"]), esc(so["totals"]), so["parquet_files"], esc(so["why"])),
      "| Workbench v0101 | %s · 舊版 U/I 連結 %s |" % (rr["workbench"]["lamp"], rr["workbench"]["legacy_linked"]), "",
      "擷取 / 驗收 / 驗證的數字與 v0142 / v0143 同一組(無退步)。", "",
      "## 4. DuckDB 正式路徑(venv_duck · 同一批輸出冊 · OutputStore CLI)", "", "| 項 | 結果 |", "|---|---|",
      "| 環境 | %s |" % dk["env"], "| 第一次 sync | %s |" % esc(dk["first_sync"]), "| 第二次 sync(同檔再跑)| %s |" % esc(dk["second_sync"])] + ["| SQL | `%s` |" % esc(l) for l in dk["sql"]] + ["| OutputStore 自測(venv_duck)| %s |" % esc(dk["selftest"]), "",
      "## 5. 一鍵 v0144 情境(pwsh · 假 GitHub 分支)", "", "| 項 | 結果 |", "|---|---|",
      "| rc | %s(rc 1 = 沙盒 ③ 環境檢查 RED,與 §3 同)|" % sc["rc"], "| 第一次(Downloads 沒套件 → 從分支取)| %s |" % esc(sc["first"]),
      "| 再貼一次 | %s |" % esc(sc["again"]), "| 竄改啟動器後再貼 | %s |" % esc(sc["tamper"]),
      "| ⑧b / Workbench | %s · %s |" % (esc(sc["closeout_line"]), esc(sc["workbench_line"])),
      "| ⑬ / ⑤b 摘要行 | %s · %s |" % (esc(sc["step13_line"]), esc(sc["step5b_ssot_line"])), "",
      "## 6. 沒有宣稱的", ""] + ["- " + x for x in R["not_claimed"]]
(W / "release144/VRN2_Verification_v0144.md").write_text("\n".join(md) + "\n", encoding="utf-8"); print("verification md + release results ok")
