"""VRN2_Handover_v0144.md:從 v0143 只增不減(標題 · 操作員令 · 本輪 → 前一輪 · 3.1 新列 · §7 新表 · §8 / §10 / §11 新項)。"""
import re, json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v144")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0143.md").read_text(encoding="utf-8")
R = json.loads((S / "release144/VRN2_Release_v0144.json").read_text(encoding="utf-8"))
rr = R["results"]["full_run_v0144_19_real"]; st = rr["output_store"]; ss = rr["ssot_sync"]; dk = R["results"]["duckdb_real_path"]
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)
lines = src.split("\n")
assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0143 · 2026-10-29(")
lines[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0144 · 2026-10-29(v0143 + 本輪:操作員 2026-10-29 政策 → 三系統 SSOT-ID 協作(VRN-2 側 SSOTSync v0100 · 協定 `VIA_SSOT_ID_Protocol_v0100.md`)· 輸出位置 Windows I/O / 雲端同步夾(處理器 v0108 `vrn2://pick?kind=outdir` · Workbench v0101 拖曳區)· 輸出 Parquet 增量擷取 · DuckDB 管理(OutputStore v0100)· 操作員一鍵 v0105 · 本地實測一輪改指;runtime v0142 的 162 個成員一個位元組都不動)"
src = "\n".join(lines)
# 操作員令 + 本輪 → 前一輪
old_round = "> **本輪(v0143 · 套件 = 啟動器 v0143 + runtime v0142 不動"
assert src.count(old_round) == 1
policy = ("> **操作員令(2026-10-29 · 政策)**:「獨立系統 VRN-2 / VDF / VCGC 3 個都是獨立系統 3 個彼此是有依賴性的但不會直接影響他們 … VRN-2 / VDF 此系統端會產生很多的 SSOT REGEX 同義字 政策上有很多規範都是由基層提出來 如 VDF / VRN-2 但有時 VCGC 也有他們的需求可提出 子系統提出後沒有 SSOT ID 空白 另一個子系統也有提 SSOT ID 空白 VCGC 會提示有衝突 等使用者與 AI 修改無誤後自動生成 SSOT 號碼 子系統看到了也會自動填上補全資料 三者靠使用者及 AI 協調 … 三個系統的這類手冊是一致的 三個系統都有自己的 SYSTEM MANAGER SSOT REGEX 同義字 政策庫及 MAIN() 自測至完成 TEST DEBUG OPTIMIZE TEST DEBUG CONSOLIDATE TEST DEBUG USER-TEST DEBUG ACTIVATE TEST DEBUG TILL THEY WORKS PERFECTLY. VRN-2 幾乎完成 快速收尾 用 HTML U/I 去做 輸出位置可用 WINDOWS I/O 拖曳式 或是連接雲端 … 輸出 PARQUET 增量擷取 增量擷取用 DUCKDB 管理 全景式檢視」(原文口述,錯字依語意校正)。\n"
            "> **本輪(v0144 · 套件 = 啟動器 v0144 + runtime v0144 = v0142 的 162 個成員不動 + 4 個新成員:處理器 v0108 · OutputStore v0100 · SSOTSync v0100 · Workbench v0101 · 操作員一鍵 v0105 · 本地實測一輪 v0100 改指 · 協定 `VIA_SSOT_ID_Protocol_v0100.md`)**:"
            "① **SSOT-ID 三系統協作(VRN-2 側)**:⑤b 讀本輪 `VRN2_Component_Register_v*.json` 尾版 → 寫核號請求冊 `functional modules\\VRN2\\contract\\VRN2_NUMBER_REQUEST_latest.json`(每條目 `ssot_id` 空白 · `proposed_no` = VRN-2 自己的號 · `vcgc_kind` SSOT / RGX / SYN / PLCY / PRMT … · 同義字 · 正則 · 來源檔與 sha · 自撞檢查)→ 讀 VCGC 核發冊 `VCGC_NUMBER_GRANT_latest.json`(依序 `<VRN-2 程式夾>\\contract\\` · `<VIA>\\VCGC\\contract\\` · `<VIA>\\supportive modules\\registry\\` · `<VIA>\\VIA_Reports\\vcgc\\` · 全部只讀合併)→ 核發 → 自動補填出**新版**登記冊(`v0101` …)· 衝突 → 「衝突 · 待人判」列在收據與 Workbench 交接分頁 · VCGC 還沒核發 → 待核號(綠 · 不擋);VRN-2 不寫 VCGC 的冊、不自己編 SSOT 號。"
            "② **輸出位置 window I/O / 雲端**:處理器 v0108 `vrn2://pick?kind=outdir`(Windows 資料夾對話框 · 可新建)· `vrn2://outdir?reset=1` · `--set-outdir`;Workbench v0101 匯出分頁「輸出位置」面板 + 拖曳區(瀏覽器拿不到拖進來的真路徑,拖曳 → 自動開對話框)· 舊版 U/I 左側「輸出位置(window I/O)」區塊;選 OneDrive / Google Drive / Dropbox 的同步夾 = 連接雲端(本機寫入 · 同步軟體上雲 · 收據印 cloud_hint);`$env:VRN2_OUTPUT_DIR` 可預設。"
            "③ **⑬ 輸出 Parquet 增量擷取 · DuckDB 管理**:OutputStore v0100 在收尾收據之後跑 → 鏡像四本冊 + Workbench + 收據到 `<輸出夾>\\VRN2\\latest\\`;增量庫 `<輸出夾>\\VRN2\\vrn2_store.duckdb`(`catalog` 以原檔 SHA-256 為鍵 · `book_<冊>` 每列帶 run_id / file_sha)· 只追加 SHA-256 新檔的列(同檔再跑 = 0 追加)· Parquet 分區 `parquet\\<冊>\\run=<id>.parquet` + `catalog.parquet`(DuckDB COPY)· 沒裝 duckdb → pyarrow 備援(黃 · 功能同 · 無 SQL)· 沒選輸出夾 → 灰(輸出留 `VIA_Reports\\vrn2\\output`)。"
            "④ 啟動器 v0144 = v0143 + ⑤b + ⑬ + 處理器 v0108 註冊 + Workbench v0101;收據 `VRN2_Closeout_v0144.json` 多 `ssot_sync` / `output_store`。容器實測:五支自測全過(啟動器 · SSOTSync 9/9 · OutputStore 9/9 · 處理器 14/14 · Workbench 18/18)· 沙盒 19 份真檔整輪(⑤b %s · ⑬ %s · 引擎 %s · 新檔 %s / 已知 %s · parquet %s)· venv_duck(duckdb 1.5.6)正式路徑:第一次 sync 新檔 %s · 第二次 0 · catalog %s 檔 · SQL 可查 · pwsh 雜湊鏈全 True。桌機還沒跑 v0144(下一次貼回)。\n"
            % (ss.get("lamp"), st.get("lamp"), st.get("store_engine"), st.get("new_files"), st.get("known_files"), st.get("parquet_files"), dk.get("first_new"), dk.get("catalog_files")))
src = src.replace(old_round, policy + "> **前一輪(v0143 · 套件 = 啟動器 v0143 + runtime v0142 不動", 1)
# 3.1 新列(放在 v0143 啟動器列之前)
anchor = "| ActivateVRN-2_v0143.py(套件 · 底座 v0136)| **v0143** |"
assert src.count(anchor) == 1
rows = ("| ActivateVRN-2_v0144.py(套件 · 底座 v0136)| **v0144** | 見發行清單 | `%s` | **新**(⑤b SSOT-ID 同步 · ⑬ 輸出位置 / 增量庫 · 處理器 v0108 · Workbench v0101;v0143 的閘 / 上限 / 補放照舊)|\n"
        "| **VRN2_SSOTSync** | **v0100**(runtime v0144 新成員)| 見 runtime 清單 | `%s` | **新**(request / apply / sync · 自測 9)|\n"
        "| **VRN2_OutputStore** | **v0100**(runtime v0144 新成員)| 見 runtime 清單 | `%s` | **新**(鏡像 + DuckDB 增量 Parquet 庫 · pyarrow 備援 · 自測 9)|\n"
        "| **VRN2_UIAction** | **v0108**(v0104 留著;v0105 / v0107 是桌機線 publish 處理器的號,本線跳過)| 見 runtime 清單 | `%s` | **新**(`vrn2://pick?kind=outdir` · `outdir?reset=1` · `--set-outdir` · 自測 14)|\n"
        "| **VRN2_Workbench** | **v0101**(v0100 留著)| 見 runtime 清單 | `%s` | **新**(匯出分頁 輸出位置面板 + 拖曳區 + 庫收據表 · 交接分頁 SSOT-ID 表 · 自測 18)|\n")
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg144/VRN2_Runtime_v0144.json").read_text(encoding="utf-8"))["files"]}
rows = rows % (R["launcher"]["sha256"][:12], rt["VRN2_SSOTSync_v0100.py"], rt["VRN2_OutputStore_v0100.py"], rt["VRN2_UIAction_v0108.py"], rt["VRN2_Workbench_v0101.py"])
src = src.replace(anchor, rows + anchor, 1)
# §7 新表
once("## 7. 本輪修正(v0136 / 另一團隊 v0140 → v0141 · 收尾套件)",
     "## 7. 本輪(v0143 → v0144 · 操作員 2026-10-29 政策)\n\n| # | 政策 | VRN-2 側做法(v0144)| 實測 |\n|---|---|---|---|\n"
     "| 1 | SSOT / Regex / 同義字 / 政策由基層提出 · ID 空白 → VCGC 提示衝突 → 使用者 + AI 修 → VCGC 核號 → 子系統自動補填 | SSOTSync v0100:請求冊(ssot_id 空白 · proposed_no · vcgc_kind · 自撞)→ 讀核發冊 → 核發補填出新版登記冊 · 衝突列待人判;契約寫在 `VIA_SSOT_ID_Protocol_v0100.md`(VCGC 核發冊的格式是**契約**,VCGC 那邊還沒實作,VRN-2 不代寫)| 自測 9 / 9 · 沙盒 ⑤b %s |\n"
     "| 2 | 輸出位置可用 Windows I/O 拖曳式或連接雲端 | 處理器 v0108 `vrn2://pick?kind=outdir` + Workbench v0101 面板 / 拖曳區(拖曳 → 對話框)+ 舊版 U/I 區塊;OneDrive 等同步夾 = 雲端(cloud_hint)| 處理器自測 14 / 14 · Workbench 18 / 18 · 沙盒 `VRN2_OUTPUT_DIR` 指 OneDrive 式夾 → %s |\n"
     "| 3 | 輸出 Parquet 增量擷取 · 用 DuckDB 管理 · 全景式檢視 | OutputStore v0100:catalog(SHA-256)+ book_* + Parquet 分區 + catalog.parquet;Workbench 匯出分頁列庫收據(引擎 · 新檔 / 已知 · 追加 · 累計)| venv_duck:新檔 %s → 第二次 0 · SQL join 可查;沙盒(無 duckdb)pyarrow 備援 %s |\n"
     "| 4 | 三系統獨立 · 各自 MAIN · 手冊一致 | VRN-2 只改自己的 runtime 與冊;VCGC / VDF 檔不碰;協定 md 放 `docs/handoff/ai/`(三系統共讀)| `git status` 只有 VRN-2 的檔 |\n\n---\n\n## 7.0g 前一輪 v0141(v0136 / 另一團隊 v0140 → v0141 · 收尾套件)"
     % (ss.get("lamp"), st.get("lamp"), dk.get("first_new"), st.get("lamp")))
# §8 新待辦
once("| 0 | **(v0143)** 桌機 2026-10-29 第一次實跑:",
     "| 0 | **(v0144)** 桌機還沒跑 v0144:貼本地實測一輪 v0100 的一行(已改指操作員一鍵 v0105 → VRN-2 一鍵 v0144)→ 看 ⑤b SSOT-ID(待核號 N · 衝突 0)· ⑬(灰 = 沒選輸出夾 → Workbench 匯出分頁「選擇輸出夾…」或 `$env:VRN2_OUTPUT_DIR`;黃 = 沒裝 duckdb → `pip install duckdb`)· 處理器 v0108 註冊 | 貼回 |\n"
     "| 0a | **(v0144)** VCGC 側核發冊還沒實作(契約在 `VIA_SSOT_ID_Protocol_v0100.md` §3):VCGC 那一線要讀 `functional modules\\VRN2\\contract\\VRN2_NUMBER_REQUEST_latest.json`、寫 `VCGC_NUMBER_GRANT_latest.json`(放 `<VIA>\\VCGC\\contract\\` 或 `<VIA>\\VIA_Reports\\vcgc\\`);VRN-2 不代寫 | VCGC 線 |\n"
     "| 0b | **(v0144)** 瀏覽器拿不到拖進來的資料夾真路徑(安全限制):拖曳區只當「開對話框」的入口;要真拖曳落地要 vrn2:// 處理器收 File System Access,下一輪 | 不改 |\n"
     "| 0 | **(v0143)** 桌機 2026-10-29 第一次實跑:")
# §10
once("## 10. 執行方式(v0143:貼 `docs/handoff/ai/VRN2_LocalRound_v0100.md` 頂端的一行(logo → ChainShip v0101 補船 → 操作員一鍵 v0104 → VRN-2 一鍵 v0143 → 貼回包);",
     "## 10. 執行方式(v0144:貼 `docs/handoff/ai/VRN2_LocalRound_v0100.md` 頂端的一行(logo → ChainShip v0101 補船 → 操作員一鍵 v0105 → VRN-2 一鍵 v0144 → 貼回包);或單跑 `vrn2_release_v0144/VRN2_OneClick_v0144.md` 的一行;輸出夾:跑完在 Workbench 匯出分頁按「選擇輸出夾…」(或 `$env:VRN2_OUTPUT_DIR = 'C:\\Users\\<你>\\OneDrive\\VRN2_out'` 再貼一次)· 增量庫要 `pip install duckdb`;前一版 v0143:貼同一行(當時指 操作員一鍵 v0104 → VRN-2 一鍵 v0143);")
# §11 規則
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0144)** **SSOT-ID 不自己編**:VRN-2 的登記冊 `ssot_id` 只能從 VCGC 的核發冊補填;VRN-2 自己的號是 `proposed_no`(VRN2-xxx)。請求冊 `contract\\VRN2_NUMBER_REQUEST_latest.json` 每輪重寫、核發冊只讀、補填一定出新版登記冊(舊版留著)· 狀態在 `contract\\VRN2_NUMBER_STATE_latest.json`。衝突不自己挑,列給人判。\n"
     "- **(v0144)** **輸出位置只從對話框 / 設定冊 / 環境變數來**:處理器不從網址讀路徑(同 v0133 輸入的規則);拖曳區不是真路徑來源。輸出夾在同步夾裡就是「雲端」,VRN-2 不接雲端 API。\n"
     "- **(v0144)** **增量以原檔 SHA-256 為準,不以檔名**:同名不同內容 = 新檔;同內容再跑 = 0 追加。庫的真相在 `vrn2_store.duckdb`,Parquet 是分區輸出;沒 duckdb 用 pyarrow 備援(黃),不要在沒庫時假裝綠。\n"
     "- **(v0144)** **處理器版號跳過桌機線用掉的號**(v0105 / v0107 是 publish 處理器):出新版前先 `chain VRN2_UIAction` 看兩條線的號。\n"
     "- **(v0144)** 三系統的協作手冊(`VIA_SSOT_ID_Protocol_v0100.md`)是契約:改契約出新版號、三邊同時改;VRN-2 線不替 VCGC / VDF 寫實作。\n\n")
(REPO / "VRN2_Handover_v0144.md").write_text(src, encoding="utf-8", newline="\n")
print("handover v0144 lines", src.count("\n"))
