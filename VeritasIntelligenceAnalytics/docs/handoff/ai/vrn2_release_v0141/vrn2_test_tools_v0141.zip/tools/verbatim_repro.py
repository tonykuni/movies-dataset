# 四點原文核對重現:ENG062 v0115 summarize_pdf → 每點用 pypdfium2 比對(照 VerbatimVerifier v0103 的 comparable)
import sys, json, re, unicodedata, importlib.util, hashlib
from pathlib import Path
RT = Path(sys.argv[1].split("@")[0]); PDFS = [Path(x) for x in sys.argv[2:]]
def load(name, p):
    spec = importlib.util.spec_from_file_location(name, p); m = importlib.util.module_from_spec(spec); sys.modules[name] = m; spec.loader.exec_module(m); return m
ENG = load("eng062_repro", RT / (sys.argv[1].split("@")[1] if "@" in sys.argv[1] else "VRN_ENG062_SummarizerV1_v0116.py"))
RT = Path(sys.argv[1].split("@")[0])
def comparable(text):
    text = unicodedata.normalize("NFKC", str(text)).replace("­", "").replace("\x02", "")
    text = re.sub(r"-\s*\n\s*(?=[a-z])", "", text)
    return re.sub(r"\s+", "", text).translate(str.maketrans({"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-"})).casefold()
import pypdfium2 as pdfium
tot = {"PASS": 0, "FAIL": 0, "OCR_PENDING": 0, "MISSING": 0}
for p in PDFS:
    try:
        s = ENG.summarize_pdf(str(p))
    except Exception as e:
        print(f"## {p.name}: summarize error {type(e).__name__}: {e}"); continue
    pdf = pdfium.PdfDocument(str(p))
    out = []
    for pt in s["points"]:
        if not pt.get("text"):
            tot["MISSING"] += 1; out.append(f"  P{pt['index']} MISSING"); continue
        ev = pt["evidence"][0]; q = pt["text"]; pg = int(ev.get("page") or 0)
        if not 1 <= pg <= len(pdf):
            tot["FAIL"] += 1; out.append(f"  P{pt['index']} FAIL invalid page {pg}"); continue
        page = pdf[pg - 1]; tp = page.get_textpage(); whole = tp.get_text_range()
        if not whole.strip():
            tot["OCR_PENDING"] += 1; out.append(f"  P{pt['index']} OCR_PENDING p{pg}"); continue
        box = ev.get("bbox"); bounded = ""
        if box and len(box) == 4:
            h = page.get_height(); bounded = tp.get_text_bounded(left=max(0, box[0]-2), bottom=max(0, h-box[3]-2), right=box[2]+2, top=h-box[1]+2)
        n = comparable(q)
        if n and n in comparable(bounded): tot["PASS"] += 1; out.append(f"  P{pt['index']} PASS bbox p{pg} reader={ev.get('reader')} src={ev.get('source')}")
        elif n and n in comparable(whole): tot["PASS"] += 1; out.append(f"  P{pt['index']} PASS page p{pg} reader={ev.get('reader')} src={ev.get('source')}")
        elif ev.get("reader") == "OCR": tot["OCR_PENDING"] += 1; out.append(f"  P{pt['index']} OCR_PENDING(reader OCR) p{pg}")
        else:
            tot["FAIL"] += 1
            # 找最長的共同前綴以定位差異
            cw = comparable(whole); i = 0
            while i < len(n) and n[:i+1] in cw: i += 1
            out.append(f"  P{pt['index']} FAIL p{pg} reader={ev.get('reader')} src={ev.get('source')} blk={ev.get('block_id')} len={len(n)} prefix_ok={i}")
            out.append(f"     quote: {q[:200]!r}")
            out.append(f"     cmp  : {n[max(0,i-30):i+40]!r}")
            j = cw.find(n[max(0,i-30):i]) if i >= 30 else -1
            out.append(f"     pdfium: {cw[j:j+90]!r}" if j >= 0 else "     pdfium: (prefix not found)")
    print(f"## {p.name} · title={str(s.get('title_original'))[:60]!r} · status={s.get('status')} missing={s.get('missing')}")
    print("\n".join(out))
print("TOTAL", tot)
