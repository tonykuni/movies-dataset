# 合成「短訊 / 英文 update」PDF(模擬 欣銓 Note · GFHK Apple update · 數字頁):用 fitz 寫文字層 → 給摘要器 v0116 + 第二讀取器核對
import sys, fitz
from pathlib import Path
out = Path(sys.argv[1]); out.mkdir(parents=True, exist_ok=True)
font_zh = "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc"
def pdf(name, pages):
    doc = fitz.open()
    for lines in pages:
        page = doc.new_page(width=595, height=842)
        y = 60
        for size, text, zh in lines:
            if zh:
                page.insert_text((50, y), text, fontsize=size, fontname="zh", fontfile=font_zh)
            else:
                page.insert_text((50, y), text, fontsize=size, fontname="helv")
            y += size * 1.6
    doc.save(out / name); doc.close()
pdf("欣銓(3264,B_買進)-SYN.pdf", [[
    (16, "欣銓 (3264 TT) 買進 目標價 NT$108", True),
    (12, "投資評等:買進 目標價:NT$108.0 收盤價:NT$92.3", True),
    (11, "測試需求回溫,第三季營收季增雙位數。", True),
    (11, "• 先進封裝測試產能利用率回升至八成", True),
    (11, "• 車用與工控客戶庫存調整接近尾聲", True),
    (11, "• 2026 年資本支出維持 30 億元,聚焦 CoWoS 相關測試", True),
    (9, "資料來源:公司、中信投顧整理", True),
    (9, "本報告純屬研究性質,僅供參考", True),
]])
pdf("GFHK - Apple update SYN.pdf", [[
    (16, "Apple Inc. (AAPL US) - Apple update", False),
    (11, "Rating: Buy  Target price: US$280  Current price: US$236", False),
    (11, "iPhone 17 demand: channel checks point to a stronger launch cycle than last year.", False),
    (11, "Services revenue keeps compounding at a double digit pace in all regions.", False),
    (11, "Gross margin guidance of 46%-47% for the December quarter.", False),
    (11, "Key risk: tariff exposure on China assembled units and FX headwinds.", False),
    (10, "Analyst: Test Analyst, analyst@example.com", False),
    (9, "Source: Company data, GF Securities (Hong Kong)", False),
], [
    (11, "Revenue (US$bn)   FY24A  FY25E  FY26E", False),
    (11, "iPhone            201.2  210.5  225.0", False),
    (11, "Services           96.2  107.4  118.9", False),
    (11, "Net income        93.7  101.2  110.8", False),
]])
pdf("Numbers only SYN.pdf", [[
    (12, "2024A 2025E 2026E", False),
    (12, "1,234 1,456 1,678", False),
    (12, "12.5 13.1 14.0", False),
]])
print("synthetic PDFs:", sorted(p.name for p in out.iterdir()))
