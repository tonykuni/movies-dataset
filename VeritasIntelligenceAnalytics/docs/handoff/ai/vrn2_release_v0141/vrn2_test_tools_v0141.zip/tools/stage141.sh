#!/bin/bash
# v0141 放進 movies-dataset 倉:docs/handoff/ai/vrn2_release_v0141/(套件 zip · 發行 json · 一鍵 md · 實測 md · logs zip · 工具 zip)+ 交接 v0141 / latest + 衝突交接冊加列(不放 .ps1 · 固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v141
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0141; mkdir -p $D
python3 - <<'PY'
import zipfile, pathlib, re
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v141")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0141")
def z(name, files):
    with zipfile.ZipFile(D / name, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 22, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("full140r.log", "full141.log", "full141f.log", "full141g.log", "stale141.log", "stale141g.log", "stale_driver.log", "stale_driver_g.log", "verbatim4.log", "verbatim_real13.log", "verbatim_synth116.log", "ui_test_g.log", "ui_input_g.log", "scen_first.log", "scen_again.log", "scen.rc", "full141g.rc")]
logs += [("idem/lanes.log", W / "idem/lanes.log"), ("idem/repro_ocr.log", W / "idem/repro_ocr.log")]
for t in ("t141g", "t141"):
    v2 = W / t / "VIA/VIA_Reports/vrn2"
    for n in ("VRN2_Closeout_v0141.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json"):
        logs.append((t + "/" + n, v2 / n))
    for q in sorted((v2 / "verify_independent").glob("*.digest.txt")):
        logs.append((t + "/" + q.name, q))
z("logs_v0141.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted((W / "tools").glob("*.py")) + sorted((W / "tools").glob("*.sh")) + sorted((W / "tools").glob("*.js"))]
tools += [("tools/idem/" + q.name, q) for q in sorted((W / "idem").glob("*.py"))]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py"))]
z("vrn2_test_tools_v0141.zip", tools)
print("zips ok")
PY
cp $W/release141/VRN2_Closeout_v0141.zip $W/release141/VRN2_Release_v0141.json $W/release141/VRN2_OneClick_v0141.md $W/release141/VRN2_Verification_v0141.md $D/
cp $W/release141/VRN2_Handover_v0141.md $REPO/VRN2_Handover_v0141.md; cp $W/release141/VRN2_Handover_v0141.md $REPO/VRN2_Handover_latest.md
ls -la --time-style=+%H:%M $D | awk '{print $5, $7}'
