"""vrn2_release_v0141:VRN2_Closeout_v0141.zip(套件夾:啟動器 v0136 底座 + v0141 + runtime v0141 zip/清單 + 橋 + 原文核對器 + OCR 橋 + PACKAGE_SHA256.json + README + VALIDATION_RESULT.json · 固定時間戳 · 冪等)
+ VRN2_Release_v0141.json。用法:python make_release141.py <pkg141 夾> <results.json> <輸出夾>"""
import hashlib, json, sys, zipfile
from pathlib import Path
pkg, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)
R = json.loads(res_p.read_text(encoding="utf-8"))
names = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0141.py", "VRN2_Runtime_v0141.zip", "VRN2_Runtime_v0141.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in names}
readme = R["readme"].encode("utf-8")
validation = json.dumps(R["validation"], ensure_ascii=False, indent=1).encode("utf-8")
files["README.txt"] = readme
files["VALIDATION_RESULT.json"] = validation
manifest = {"system": "VRN-2", "version": "v0141", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zp = out / "VRN2_Closeout_v0141.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0141/" + n, date_time=(2026, 10, 22, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
        z.writestr(zi, files[n])
zsha = hashlib.sha256(zp.read_bytes()).hexdigest()
rel = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0141", "date": "2026-10-22",
       "operator_order_2026_10_22": R["order"], "base_package": R["base_package"], "supersedes": R["supersedes"], "design": R["design"],
       "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
       "runtime": json.loads(files["VRN2_Runtime_v0141.json"].decode("utf-8")) | {"files": "see VRN2_Runtime_v0141.json inside the package"},
       "tested_in": R["tested_in"], "results": R["results"],
       "package": {"name": zp.name, "sha256": zsha, "bytes": zp.stat().st_size, "layout": "VRN2_Closeout_v0141/<files> (no .ps1 · the one-click md is the entry)"},
       "launcher": {"name": "ActivateVRN-2_v0141.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0141.py"]).hexdigest()},
       "oneclick": "VRN2_OneClick_v0141.md", "test_tools_zip": "vrn2_test_tools_v0141.zip", "logs_zip": "logs_v0141.zip"}
(out / "VRN2_Release_v0141.json").write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
print("package %s · %d bytes · sha %s" % (zp.name, zp.stat().st_size, zsha))
