#!/bin/bash
# v0141 沙盒樹:mktree.sh 的樹 + 工具鎖冊 / SuperAccel 橋 + 套件夾(v0104 內容)+ 52 份個股 + 非個股樣本
set -e
S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
U=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/uploads1022/closeout104/VRN2_Closeout_v0104
R="/home/user/movies-dataset/VeritasIntelligenceAnalytics"
T="$1"; PKGSRC="${2:-$U}"
cd /tmp && $S2/tools/mktree.sh "$T" "$U/ActivateVRN-2_v0136.py" > "$T.setup.log" 2>&1 || { cat "$T.setup.log"; exit 1; }
mkdir -p "$T/VIA/supportive modules/registry" "$T/VIA/supportive modules/ps7" "$T/pkg" "$T/src"
cp "$R/supportive modules/registry/VIA_ToolVersion_Lock_v0100.json" "$T/VIA/supportive modules/registry/"
cp "$R/supportive modules/VIA_SuperAccel_Module.py" "$R/supportive modules/"SUP_MDL737_SuperAccelModule_v*.py "$T/VIA/supportive modules/"
cp "$R/supportive modules/ps7/"*.ps1 "$T/VIA/supportive modules/ps7/"
cp -r "$PKGSRC/." "$T/pkg/"
rm -rf "$T/samples"; mkdir -p "$T/samples"
SAMPLES="${3:-$S2/vrn1/out_r9_syn/autotest/samples}"; cp "$SAMPLES"/* "$T/samples/"
cd "$T/VIA" && git add -A >/dev/null 2>&1 && git commit -qm "lock+accel" >/dev/null 2>&1 && git push -q origin main >/dev/null 2>&1 || true
echo "tree141 ok: $(ls "$T/samples" | wc -l) files · pkg $(ls "$T/pkg" | wc -l)"
