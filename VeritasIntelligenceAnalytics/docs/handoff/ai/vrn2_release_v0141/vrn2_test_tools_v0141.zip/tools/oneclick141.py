"""一鍵 v0141:從 MAIN 的 VRN2_OneClick_v0136.md 取 v0136 一鍵程式碼 → 錨點替換成「套件 v0141」版(③ 取 VRN2_Closeout_v0141.zip · 套件內逐檔雜湊 · ④ 跑 ActivateVRN-2_v0141.py · ⑤ 收尾收據 / 冪等閘 · ⑤b 處理器在 functional modules\\VRN2)
→ Run-VRN2-v0141.ps1 + VRN2_OneClick_v0141.md + boot141.ps1 + oneline141.txt。
用法:python oneclick141.py <MAIN 的 VRN2_OneClick_v0136.md> <VRN2_Closeout_v0141.zip SHA-256> <輸出夾>"""
import base64, hashlib, re, sys
from pathlib import Path
src, want, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]); assert re.fullmatch(r"[0-9a-f]{64}", want); out.mkdir(parents=True, exist_ok=True)
md = src.read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
assert base64.b64decode(one.split()[-1]).decode("utf-16-le") == boot + "\n"
L = ps.split("\n")
def find(prefix, start=0):
    hits = [i for i in range(start, len(L)) if L[i].lstrip().startswith(prefix)]
    assert len(hits) == 1, (prefix[:60], len(hits)); return hits[0]
def rep(a, b, n=1):
    global ps
    assert ps.count(a) == n, (ps.count(a), a[:80]); ps = ps.replace(a, b)
# ---- ③ 取得套件(整段換掉:從「# ③ 取得啟動器 v0136」到「} else { Say GREEN "③ 本機已是 v0136」那行) ----
i0 = find("# ③ 取得啟動器 v0136"); i1 = find('} else { Say GREEN "③ 本機已是 v0136')
new3 = '''    # ③ 取得套件 v0141:本機套件夾的 VRN2_Closeout_v0141.zip 雜湊對(且啟動器在)→ 直接用;不是 → 從 GitHub 分支(讀不到 → main)讀發行夾(git fetch + git archive · 不切換分支)· 套件雜湊 + 套件內逐檔雜湊都對才解壓 · 舊套件夾改名備份
    $zk = Join-Path $Pk 'VRN2_Closeout_v0141.zip'
    $have = if ((Test-Path -LiteralPath $zk) -and (Test-Path -LiteralPath $A)) { (Get-FileHash -LiteralPath $zk -Algorithm SHA256).Hash.ToLower() } else { '' }
    $rel = $null
    $top = $null; if (Get-Command git -ErrorAction SilentlyContinue) { $top = (git -C $R rev-parse --show-toplevel 2>$null) }; if ($top) { $top = "$top".Trim() }
    if ($top -and $have -ne $Want) {
      foreach ($b in $Br, 'main') {
        $ok = $false
        foreach ($w in 0, 2, 4, 8, 16) { if ($w) { Start-Sleep -Seconds $w }; git -C $top fetch -q origin $b 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { $ok = $true; break } }
        if (-not $ok) { continue }
        $z = Join-Path $tmp 'vrn2_release_v0141.zip'
        git -C $top archive --format=zip -o $z "origin/${b}:$RelP" 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $z)) { $rel = Join-Path $tmp 'rel'; Expand-Archive -LiteralPath $z -DestinationPath $rel -Force; break }
      }
    }
    if ($have -ne $Want) {
      if (-not $rel) { Say RED "③ 本機套件不是 v0141,且讀不到 GitHub 分支 $Br 或 main(網路 / git)· 請手動下載 VRN2_Closeout_v0141.zip 解壓到 $Pk"; $global:LASTEXITCODE = 1; return }
      $zl = Join-Path $rel 'VRN2_Closeout_v0141.zip'; $mj = Join-Path $rel 'VRN2_Release_v0141.json'
      if (-not ((Test-Path -LiteralPath $zl) -and (Test-Path -LiteralPath $mj))) { Say RED "③ GitHub 分支的發行夾 $RelP 缺 VRN2_Closeout_v0141.zip / VRN2_Release_v0141.json · 不使用"; $global:LASTEXITCODE = 1; return }
      $man = Get-Content -Raw -Encoding UTF8 -LiteralPath $mj | ConvertFrom-Json
      $got = (Get-FileHash -LiteralPath $zl -Algorithm SHA256).Hash.ToLower()
      if ($got -ne $Want -or $man.package.sha256 -ne $Want) { Say RED "③ 下載的套件雜湊不對($got)· 不使用"; $global:LASTEXITCODE = 1; return }
      Expand-Archive -LiteralPath $zl -DestinationPath (Join-Path $tmp 'l') -Force
      $new = [IO.Path]::Combine($tmp, 'l', 'VRN2_Closeout_v0141')
      $pm = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $new 'PACKAGE_SHA256.json') | ConvertFrom-Json
      foreach ($f in $pm.files) { $fp = Join-Path $new $f.path; if (-not (Test-Path -LiteralPath $fp) -or ((Get-FileHash -LiteralPath $fp -Algorithm SHA256).Hash.ToLower() -ne $f.sha256)) { Say RED "③ 套件內 $($f.path) 雜湊不對 · 不使用"; $global:LASTEXITCODE = 1; return } }
      if (-not (Test-Path -LiteralPath $new -PathType Container) -or -not (Test-Path -LiteralPath (Join-Path $new 'ActivateVRN-2_v0141.py'))) { Say RED "③ 套件解壓後找不到 ActivateVRN-2_v0141.py · 不使用"; $global:LASTEXITCODE = 1; return }
      New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Pk) | Out-Null
      if (Test-Path -LiteralPath $Pk) { $bak = $Pk + '_' + $t0.ToString('yyyyMMdd_HHmmss') + '.bak'; Move-Item -LiteralPath $Pk -Destination $bak; Say GREEN "③ 舊套件夾已改名備份 → $bak" }
      Copy-Item -LiteralPath $new -Destination $Pk -Recurse -Force
      Copy-Item -LiteralPath $zl -Destination $zk -Force
      Say GREEN "③ 套件 v0141 就位(SHA-256 $($Want.Substring(0,12)) · 套件內 $(@($pm.files).Count) 檔逐檔核對相符 · 來源 GitHub $b)→ $Pk"
    } else { Say GREEN "③ 本機已是 v0141 套件(SHA-256 $($Want.Substring(0,12)))· $Pk" }'''
L[i0:i1 + 1] = new3.split("\n"); ps = "\n".join(L)
# ---- 檔頭 / 變數 ----
rep("""  $A      = if ($env:VRN2_LAUNCHER) { $env:VRN2_LAUNCHER } else { Join-Path $env:USERPROFILE 'Downloads\\ActivateVRN-2.py' }                   # 啟動器位置""",
    """  $Pk     = if ($env:VRN2_PACKAGE) { $env:VRN2_PACKAGE } else { Join-Path $env:USERPROFILE 'Downloads\\VRN2_Closeout_v0141' }             # 套件夾(啟動器 v0141 + 私有 runtime v0141 + 橋 · 不是單一檔)
  $A      = Join-Path $Pk 'ActivateVRN-2_v0141.py'                                                                                        # 啟動器位置(套件內)""")
rep("""  $Want   = 'cb6bf142a0e33824e3ef97ec134f37fd970b6225cd1384cecdee409c77d68354'   # ActivateVRN-2 v0136 SHA-256""",
    """  $Want   = '%s'   # VRN2_Closeout_v0141.zip SHA-256(套件 · 內含啟動器 v0141 + runtime v0141 清單)""" % want)
rep("""  $me = Get-Process -Id $PID; $prio0 = $me.PriorityClass; $via0 = $env:VIA_ROOT""",
    """  $me = Get-Process -Id $PID; $prio0 = $me.PriorityClass; $via0 = $env:VIA_ROOT; $vrn0 = $env:VRN2_ROOT""")
rep("""    $env:VIA_ROOT = $root
    Say GREEN ("③b VRN-2 程式夾 {0}(來源 {1})" -f [IO.Path]::Combine($root, 'functional modules', 'VRN'), $how)""",
    """    $env:VIA_ROOT = $root; $env:VRN2_ROOT = $root                                                 # v0141:啟動器先看 VRN2_ROOT(私有 runtime 落在 functional modules\\VRN2)
    Say GREEN ("③b VRN-2 程式夾 {0}(來源 {1})· 私有 runtime → {2}" -f [IO.Path]::Combine($root, 'functional modules', 'VRN'), $how, [IO.Path]::Combine($root, 'functional modules', 'VRN2'))""")
rep("""    if ($null -ne $via0) { $env:VIA_ROOT = $via0 } else { Remove-Item Env:\\VIA_ROOT -ErrorAction SilentlyContinue }""",
    """    if ($null -ne $via0) { $env:VIA_ROOT = $via0 } else { Remove-Item Env:\\VIA_ROOT -ErrorAction SilentlyContinue }
    if ($null -ne $vrn0) { $env:VRN2_ROOT = $vrn0 } else { Remove-Item Env:\\VRN2_ROOT -ErrorAction SilentlyContinue }""")
# ---- ④ 說明 ----
rep("""    Write-Host ("[計] VRN-2 一鍵 v0136 · ActivateVRN-2 v0136 · {0}" -f $(if ($NoPush) { '只實測不上船' } else { '完成後自動上船(VRN-2 船包)' })) -ForegroundColor Yellow""",
    """    Write-Host ("[計] VRN-2 一鍵 v0141 · ActivateVRN-2 v0141(套件 · 私有 runtime v0141:管理器 v0243 · 摘要器 v0116 · 驗證器 v0110 · 原文核對 v0104)· {0}" -f $(if ($NoPush) { '只實測不上船' } else { '收尾驗證(套件啟動器不上船 · ⑨ 灰)' })) -ForegroundColor Yellow""")
# ---- ⑤ 驗證器搜尋:先私有 runtime ----
rep("""      $ver = Get-ChildItem -LiteralPath ([IO.Path]::Combine($R, 'functional modules', 'VRN')) -Filter 'VRN2_IndependentVerifier_v*.py' -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1""",
    """      $vdir = @([IO.Path]::Combine($R, 'functional modules', 'VRN2'), [IO.Path]::Combine($R, 'functional modules', 'VRN')) | Where-Object { Test-Path -LiteralPath $_ -PathType Container } | Select-Object -First 1
      $ver = if ($vdir) { Get-ChildItem -LiteralPath $vdir -Filter 'VRN2_IndependentVerifier_v*.py' -ErrorAction SilentlyContinue | Sort-Object Name | Select-Object -Last 1 } else { $null }""")
# ---- 摘要 python:加 收尾收據 + 冪等閘 ----
rep("""tm = j(v2 / "tools" / "VRN2_ToolManifest_v0100.json") or {}""",
    """cl = j(v2 / "VRN2_Closeout_v0141.json") or {}
if cl:
    ps_ = cl.get("passes") or []
    q = cl.get("source_quotes") or {}
    print("%s|⑧b 收尾收據 v0141 · rc %s · 跑了 %d 輪(%s)· 四點原文核對 %s %s · 輸出缺項 %d" % ({0: "GREEN", 2: "YELLOW"}.get(cl.get("rc"), "RED"), cl.get("rc"), len(ps_), " / ".join(str(p.get("idempotence", "")) for p in ps_), q.get("verdict"), q.get("counts"), len(cl.get("output_gaps") or [])))
    for g in (cl.get("output_gaps") or [])[:6]:
        print("YELLOW|   缺項 · %s" % json.dumps(g, ensure_ascii=False)[:150])
    for st_ in cl.get("steps") or []:
        if st_.get("lamp") == "RED":
            print("RED|   紅燈步驟 · %s · %s" % (str(st_.get("step"))[:30], str(st_.get("detail"))[:140]))
else:
    print("YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0141.json(啟動器 v0141 沒跑完)")
idm = j(v2 / "IDEMPOTENCE_latest.json") or {}
if idm:
    print("%s|冪等閘 · %s · %s · %s" % ("GREEN" if idm.get("lamp") == "GREEN" else "RED", idm.get("classification"), " · ".join(str(f.get("file", ""))[:24] for f in idm.get("files") or []), (idm.get("method") or "")[:70]))
tm = j(v2 / "tools" / "VRN2_ToolManifest_v0100.json") or {}""")
# ---- ⑤b:處理器在私有 runtime(functional modules\\VRN2)· 設定檔版本 v0141 ----
rep("""      $hExp = [IO.Path]::Combine($R, 'functional modules', 'VRN', 'VRN2_UIAction_v0104.py')""",
    """      $hExp = [IO.Path]::Combine($R, 'functional modules', 'VRN2', 'VRN2_UIAction_v0104.py')   # v0141:處理器在私有 runtime""")
rep("""$hCfg = ($cf.version -eq 'ActivateVRN-2 v0136') -and ($cf.handler -eq 'VRN2_UIAction_v0104.py')""",
    """$hCfg = ($cf.version -eq 'ActivateVRN-2 v0141') -and ($cf.handler -eq 'VRN2_UIAction_v0104.py')""")
# ---- 最終燈:啟動器 rc 0 / 2 / 1 ----
rep("""    $lamp = if ($rcL -ne 0 -or -not $ok8 -or $c5.lamp -eq 'RED') { 'RED' } elseif ($vok -eq $true -and $c5.lamp -eq 'GREEN' -and $c5.inpOk -and -not $c5cBad) { 'GREEN' } else { 'YELLOW' }""",
    """    $lamp = if ($rcL -eq 1 -or -not $ok8 -or $c5.lamp -eq 'RED') { 'RED' } elseif ($rcL -eq 0 -and $vok -eq $true -and $c5.lamp -eq 'GREEN' -and $c5.inpOk -and -not $c5cBad) { 'GREEN' } else { 'YELLOW' }   # v0141:啟動器 rc 2 = 有待核對(OCR 原文 / 缺項)→ 最多黃""")
rep("""    $msg = @{ RED = $(if ($rcL -ne 0 -or -not $ok8) { 'VRN-2 有紅燈(⑧ 完成判定不是本輪的綠 或 啟動器 rc 不是 0)· 把貼包(≤300 行 · 結尾 NEXT)貼回' }""",
    """    $msg = @{ RED = $(if ($rcL -eq 1 -or -not $ok8) { 'VRN-2 有紅燈(⑧ 完成判定不是本輪的綠 或 啟動器 rc 1:紅燈步驟 / 四點原文核對 FAIL / 冪等非冪等)· 看 ⑧b 收尾收據與冪等閘那兩行 · 把貼包(≤300 行 · 結尾 NEXT)貼回' }""")
rep("""elseif ($vok -eq $false) { 'VRN-2 ⑧ 本輪完成 · 獨立驗證有待核對 → U/I「驗證過的輸出」看 ✗ 格 · 把驗證摘要貼回' } else {""",
    """elseif ($vok -eq $false) { 'VRN-2 ⑧ 本輪完成 · 獨立驗證有待核對 → U/I「驗證過的輸出」看 ✗ 格 · 把驗證摘要貼回' } elseif ($rcL -eq 2) { 'VRN-2 ⑧ 本輪完成 · 啟動器 rc 2:有待核對(OCR 原文待核對原圖 / 輸出缺項 / 非 Windows 的 ③)→ 看 ⑧b 收尾收據那行 · 把它貼回' } else {""")
# ---- 版號 / 文字 ----
rep("""  # ===== VRN-2 一鍵 v0136(啟動器 v0136 整合一支 第二回:""", """  # ===== VRN-2 一鍵 v0141(套件 v0141 = 另一團隊收尾套件 v0104 的 v0140 入口 + 本輪修正:摘要器 ENG062 v0116 四點補齊階梯(短訊 / bullet / 整頁文字 · 每點仍是原文精確字串)· 管理器 v0243 冪等閘走主跑同一條子行程路徑重跑兩次並分類(GREEN / 主跑紀錄過期 → 清該檔快取自動再跑一輪 / 引擎非冪等)· 原文核對 v0104 缺句 = 待核對不是 FAIL · 獨立驗證器 v0110;v0136 整合一支 第二回:""")
n = ps.count("v0136"); ps = ps.replace("v0136", "v0141")
n3 = ps.count("驗證器 v0105"); assert n3 == 1, n3; ps = ps.replace("驗證器 v0105", "驗證器 v0110")
assert "Downloads\\ActivateVRN-2.py" not in ps and "$RelP   = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0141'" in ps
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1); boot = boot.replace(h_old, cs).replace("v0136", "v0141") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = """# VRN-2 一鍵 v0141(cmd / PowerShell 都能貼 · 套件 v0141 = 另一團隊收尾套件 v0104(啟動器 v0140 入口 · 私有 runtime)+ 本輪修正:摘要器 v0116 四點補齊 · 管理器 v0243 冪等閘像對像 + 自動再跑一輪 · 原文核對 v0104 缺句 ≠ FAIL · 驗證器 v0110 · U/I 自己跳出)

操作員令(2026-10-22):「自動完成 VRN-2 所有問題 自己測試自完成」。上傳的 `VRN2_Closeout_v0104.zip`(啟動器 v0140 · 管理器 v0242 · 驗證器 v0109)在 `C:\\測試樣本報告` 實跑:
RED 冪等(神達 3706 主跑紀錄 ≠ 同行程重跑)· 四點原文核對 FAIL 8(GFHK Apple update POINT_1~4 · 欣銓 POINT_3~4 · 3014TT · 華南 2606 —— 缺句被算成 FAIL)· OCR_PENDING 4(MQ-1560 影像頁)· 輸出冊缺項 6 · 獨立驗證 ✗ 45(6933 AMAX 37 · 凱基 2891 8)。

v0141 = v0140 入口不動(私有 runtime 落在 `functional modules\\VRN2` · 共用 VRN 不碰 · 不上船 · 不封存)+ runtime v0141(= v0140 的 155 個成員逐位元保留 + 4 個新版檔):

| 元件 | 版本 | 改了什麼 |
|---|---|---|
| 摘要器 ENG062 | v0116(v0115 留著)| 先跑 v0115 嚴格挑句;還缺的點用階梯補齊:放寬句(≥12 中文字 / ≥5 英文字 · 前 6 頁)→ 單行(bullet · 去掉開頭的 • / 控制字元)→ 整頁文字行;每點仍是來源區塊的精確字串(頁碼 · 字元區間 · bbox · 雜湊)· 影像頁仍 MISSING(OCR 待核對)|
| 管理器 | v0243(v0239 底座 · v0242 的功能全留)| 冪等閘:挑 3 份用**主跑同一條子行程路徑**(`python -W ignore ENG397 --shard`)重跑 **兩次** · 分類:全同 GREEN / 重跑兩次一致但主跑紀錄不同 = STALE_RECORD(清該檔擷取快取 · 啟動器自動再跑一輪)/ 重跑兩次就不同 = NONDETERMINISTIC(RED · 列出第一個差異路徑)· 收據記錄執行環境(python · -I · fitz · PYTHONHASHSEED · 快取夾 · OCR 階梯)|
| 原文核對 | v0104 | 沒有可引用句子的點 = MISSING(rc 2 待核對),不再當 FAIL;讀不到的 PDF 一列 FAIL 不中斷;第二讀取器比對時忽略 bullet / 控制字元(PDFium 與 PyMuPDF 對缺字形的對應不同)|
| 獨立驗證器 | v0110(財務核心 v0105 不變)| 四點判決多 MISSING(原文不足 · 待核對)|
| 啟動器 | v0141(v0136 底座 · v0140 入口)| 冪等閘回 STALE_RECORD → 自動再跑一輪(最多 2 輪 · `$env:VRN2_NO_REPASS=1` 關掉)· 收據 `VRN2_Closeout_v0141.json` 記每輪 · 結束碼 GREEN 0 / YELLOW 2(OCR 待核對 / 缺項)/ RED 1 |

**獨立驗證 ✗ 45(6933 AMAX 37 · 凱基 2891 8)**:這兩份 PDF 不在本輪手上的樣本裡(本機 13 份真實個股報告 ⑪ 錯值 0),財務核心 v0105 不動;請把這兩份 PDF 或 `verify_independent\\VRN2_IndependentVerify_*.json.digest.txt` 貼回,下一輪才能對症。

套件 `VRN2_Closeout_v0141.zip`(SHA-256 `%s` · 從 `vrn2_release_v0141` 取 · 解壓到 `%%USERPROFILE%%\\Downloads\\VRN2_Closeout_v0141`)。
沒有 .ps1:下面那一行(cmd 也能貼)從 GitHub 讀本檔的一鍵程式碼、核對 SHA-256 才執行;一鍵再核對套件雜湊與套件內逐檔雜湊才解壓。

| 步驟 | v0141 做什麼 |
|---|---|
| ① ② | CPU / DRAM · PS 加速器(同 v0136)|
| ③ | 本機套件夾的 zip 雜湊對 → 直接用;不是 → GitHub 分支(讀不到 → main)`vrn2_release_v0141` → 套件雜湊 + `PACKAGE_SHA256.json` 逐檔核對 → 解壓(舊套件夾改名備份)|
| ③b | 定位 VRN-2 程式夾(VIA 根 · MAIN 成功紀錄 · VIA_ROOT · 倉裡找)→ `VRN2_ROOT` / `VIA_ROOT` 都指過去 |
| ④ | `python ActivateVRN-2_v0141.py [--source …]`:①~⑫(⑨ ⑩ ⑫ 灰 · 不上船 · 不借 VRN-1)· ⑧ 冪等閘 STALE_RECORD → 自動第 2 輪 · 四點原文核對 → 收據 |
| ⑤ | 摘要:⑧ 完成判定 · **⑧b 收尾收據**(rc · 跑了幾輪 · 四點原文核對 · 缺項)· **冪等閘分類** · 輸出冊 · U/I 寫回 · 獨立驗證摘要 |
| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\VRN2\\VRN2_UIAction_v0104.py`(或設定檔 v0141)· U/I 沒開就代開 |

開關:`$env:VRN2_SOURCE = 'C:\\測試樣本報告'` 指定來源夾 · `$env:VRN2_PACKAGE` 換套件夾 · `$env:VRN2_LAUNCHER_ARGS = '--no-install'` · `$env:VRN2_NO_REPASS = 1` 不自動再跑 · `$env:VRN2_NO_UI = 1` 不開 U/I。
VRN-2 主體(管理器鏈 v0231 → v0239 · ENG397 v0127 · 摘要器 v0114 / v0115 · 驗證器 v0105 ~ v0109 · 工具橋 · OCR 橋)與 v0140 套件的 155 個 runtime 成員**一個位元組都不動**;VRN-1 / VDF / VCGC 不碰。

## 在「命令提示字元(cmd)」或 PowerShell 都能貼的一行(建議用這個)

這一行在 cmd 或 PowerShell 貼上都可以:它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)讀本檔的一鍵程式碼 → **核對 SHA-256** → 才執行(不存檔 · 不改執行原則 · 結束碼 GREEN 0 / YELLOW 2 / RED 1)。

```bat
@ONE@
```

或:在 cmd 先輸入 `powershell` 按 Enter,再貼下面整段程式碼(或存成 `ActivateVRN-2.ps1` 後 `powershell -ExecutionPolicy Bypass -File ActivateVRN-2.ps1`)。

程式碼 SHA-256(本文 · 一行核對的就是這個):`%s`

```powershell
@PS@
```

## 一行實際做的事(boot · 給看的 · 上面那行就是它的 base64)

```text
@BOOT@
```
""" % (want, cs[:12])
newmd = head.replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", newmd).group(1).split()[-1]).decode("utf-16-le") == boot
assert "vrn2_release_v0141" in boot and "VRN2_OneClick_v0141.md" in boot and "v0136" not in boot
(out / "VRN2_OneClick_v0141.md").write_text(newmd, encoding="utf-8", newline="\n"); (out / "boot141.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline141.txt").write_text(one + "\n", encoding="utf-8"); (out / "Run-VRN2-v0141.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("package %s · code %s · one-liner %d 字 · md %d · 換版號 %d 處" % (want[:12], cs[:12], len(one), len(newmd), n))
