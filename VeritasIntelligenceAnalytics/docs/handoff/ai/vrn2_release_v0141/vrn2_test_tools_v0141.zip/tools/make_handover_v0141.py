"""VRN2_Handover_v0141.md = v0136 交接報告(MAIN)+ v0141(收尾套件:摘要器 v0116 · 管理器 v0243 · 原文核對 v0104 · 驗證器 v0110 · 啟動器 v0141)· 逐行錨點 · 冪等。
用法:python make_handover_v0141.py <v0136.md> <results141.json> <release json> <輸出 md>"""
import json, re, sys
from pathlib import Path
src, res_p, rel_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
R = json.loads(res_p.read_text(encoding="utf-8")); REL = json.loads(rel_p.read_text(encoding="utf-8"))
rr = R["results"]["full_run_v0141_19_real"]; heal = R["results"]["stale_cache_autoheal"]
lines = src.read_text(encoding="utf-8").split("\n")
def one(prefix):
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    assert len(hits) == 1, (prefix[:50], len(hits)); return hits[0]
def sub(prefix, new):
    i = one(prefix); lines[i] = new(lines[i]) if callable(new) else new
def before(prefix, extra):
    i = one(prefix); lines[i:i] = extra
def after(prefix, extra):
    i = one(prefix); lines[i + 1:i + 1] = extra
sub("# VRN-2 交接報告 · ActivateVRN-2 v0136 · 2026-10-21(",
    "# VRN-2 交接報告 · ActivateVRN-2 v0141 · 2026-10-22(收尾套件:另一團隊 v0104 套件的 v0140 入口 + 本輪修正 —— 摘要器 ENG062 v0116 四點補齊階梯 · 管理器 v0243 冪等閘像對像重跑兩次並分類 + 啟動器自動再跑一輪 · 原文核對 v0104 缺句 = 待核對 · 獨立驗證器 v0110 · 備援指令回 v0136 契約)")
before("> **本輪(v0136 · 啟動器 + 獨立驗證器 VRN2_IndependentVerifier_v0105",
       ["> **操作員令(2026-10-22)**:「自動完成VRN-2所有問題 自己測試自完成」+ 上傳 `VRN2_Closeout_v0104.zip`(另一團隊:啟動器 v0140 · 管理器 v0242 · 驗證器 v0109 · 私有 runtime v0140 落 `functional modules\\VRN2`)與 `VRN2_VDF_Closeout_v0103.zip`(v0139 前版 + VDF v0115/v0116 · VDF 本輪不碰)+ v0140 在 `C:\\測試樣本報告` 的 U/I 貼回(RED 冪等 神達 3706 · 四點原文核對 FAIL 8 / OCR_PENDING 4 · 輸出冊缺項 6 · 獨立驗證 ✗ 45:6933 AMAX 37 · 凱基 2891 8)。",
        "> **本輪(v0141 · 套件 = v0140 入口 + runtime v0141 · 新增 ENG062 v0116 · 管理器 v0243 · 原文核對 v0104 · 驗證器 v0110 · 交接報告 v0141 · v0140 的 155 個 runtime 成員與啟動器底座 v0136 一個位元組都不動)**:① **冪等 RED**:v0242 的閘拿「主跑紀錄(可能來自擷取快取或子行程)」和「同行程重跑一次」比,不是像對像、也分不出紀錄過期與引擎非冪等;v0243 走主跑同一條子行程路徑(`python -W ignore ENG397 --shard`)重跑**兩次**:全同 GREEN;重跑一致、主跑不同 = STALE_RECORD → 清該檔擷取快取 → 啟動器 v0141 **自動再跑一輪**(`VRN2_NO_REPASS=1` 關);重跑就不同 = NONDETERMINISTIC(RED · 印第一個差異路徑);收據記錄執行環境(python · -I · fitz · PYTHONHASHSEED · 快取夾 · OCR 階梯)。容器 13 份真實多頁檔三條路徑 ×4 次語意差異 %d;神達原檔不在容器。② **四點原文核對 FAIL 8 / 缺項 6**:摘要器 v0115 只挑嚴格句,短訊 / bullet / 英文 update 湊不滿 4 點,空點被 v0103 算 FAIL → ENG062 v0116 先跑 v0115,缺的點用階梯補齊(放寬句 → 單行 bullet → 整頁文字行 · 去掉開頭 bullet / 控制字元),每點仍是來源區塊精確字串(頁碼 · 字元區間 · bbox · 雜湊 · evidence.selection 記層級);原文核對 v0104:缺句 = MISSING(rc 2 待核對)、讀不到的 PDF 一列 FAIL、比對忽略 bullet / 控制字元;驗證器 v0110 四點判決多 MISSING。合成 GFHK / 欣銓式 PDF:v0115 0/4 · 1/4 → v0116 4/4 · 4/4(純數字頁仍 MISSING)。③ **備援「複製執行指令」**:v0242 換成只有 PS7 模板(真瀏覽器 3 條不過)→ v0243 回到 v0136 契約(升優先權 → PS 加速器 → PS7 模板 → 實際啟動器 · 不上船版)。④ **✗ 45**:兩份 PDF 不在容器,財務核心 v0105 不動,要原檔或 digest。⑤ 沙盒 19 份:⑦ %s/%s · ⑧ %s 紅 %s 黃 %s · 冪等 %s · 四點 %s · ⑪ 錯值 %s · 自癒情境 第 1 輪 STALE_RECORD → 第 2 輪 %s · U/I %s。" % (
            R["results"]["engine_determinism_13_real"]["semantic_differences"], rr["stock_reports"]["all_green"], rr["stock_reports"]["n"], rr["completion"]["verdict"], rr["completion"]["red"], rr["completion"]["yellow"], rr["idempotence"]["classification"], rr["source_quotes"], rr["independent_verifier"]["fin_bad"], heal["final_classification"], R["results"]["ui_real_browser"]["ui_test"])])
sub("> **本輪(v0136 · 啟動器 + 獨立驗證器 VRN2_IndependentVerifier_v0105", lambda l: l.replace("> **本輪(v0136", "> **前一輪(v0136", 1))
sub("> **前一輪(v0135 · 啟動器 + 獨立驗證器 VRN2_IndependentVerifier_v0104", lambda l: l.replace("> **前一輪(v0135", "> **v0135(", 1))
sub("| **啟動器(MAIN)** |", "| **收尾套件(MAIN)** | `C:\\Users\\tonyk\\Downloads\\VRN2_Closeout_v0141\\`(一鍵 ③ 解壓;`ActivateVRN-2_v0141.py` + 底座 `ActivateVRN-2_v0136.py` + `VRN2_Runtime_v0141.zip/.json` + 橋 + 原文核對 v0104 + OCR 橋 v0101)| **v0141** · 套件雜湊見 `docs/handoff/ai/vrn2_release_v0141/VRN2_Release_v0141.json` · 另一團隊的 v0104 套件夾(v0140)留著 |")
after("| **收尾套件(MAIN)** |", ["| **私有 runtime** | `<ROOT>\\functional modules\\VRN2\\` | v0140 起:runtime 清單逐檔雜湊還原(已在且同 = 沿用 · 不同 = 停不覆寫)· v0141 多 4 檔:ENG062 v0116 · 管理器 v0243 · 原文核對 v0104 · 驗證器 v0110 · 共用 `functional modules\\VRN` 不碰 |",
                               "| **收尾收據** | `<ROOT>\\VIA_Reports\\vrn2\\VRN2_Closeout_v0141.json` · `IDEMPOTENCE_latest.json` · `VRN2_VerbatimVerify_latest.json` | rc 0 / 2 / 1 · 每輪(passes)· 冪等分類 + 執行環境 + 差異路徑 · 四點原文核對(PASS / MISSING / OCR_PENDING / FAIL)|"])
sub("| **獨立驗證器** |", "| **獨立驗證器** | `<ROOT>\\functional modules\\VRN2\\VRN2_IndependentVerifier_v0110.py` | v0141 落地(v0102 ~ v0109 留著)· 財務核心 v0105 · 四點判決 PASS / OCR / MISSING / FAIL |")
sub("| **交接報告** |", lambda l: l.replace("VRN2_Handover_v0136.md", "VRN2_Handover_v0141.md"))
sub("| 本輪證據 |", lambda l: l.replace("`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0136\\`(", "`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0141\\`(v0136:`vrn2_release_v0136\\` · "))
sub("### 3.1 現役版本(v0136 內嵌", "### 3.1 現役版本(v0141 套件 · 私有 runtime v0141 逐檔雜湊還原)")
sub("| ActivateVRN-2.py | **v0136** |", "| ActivateVRN-2_v0141.py(套件 · 底座 v0136)| **v0141** | 見發行清單 | 見發行清單 | **新**(= v0140 入口 + 管理器 v0243 + 原文核對 v0104 + runtime v0141 + STALE_RECORD 自動再跑一輪)|")
before("| **VRN2_ToolBridge** | **v0101** |", ["| **VRN_SystemManager** | **v0243**(v0239 底座 · v0240 ~ v0242 留著)| 見 runtime 清單 | 見 runtime 清單 | **新**(冪等閘像對像 ×2 + 分類 + 清過期快取 · 備援指令回 v0136 契約)|",
                                             "| **VRN_ENG062_SummarizerV1** | **v0116**(v0114 / v0115 留著)| 見 runtime 清單 | 見 runtime 清單 | **新**(四點補齊階梯 · 每點精確字串)|",
                                             "| **VRN2_VerbatimVerifier** | **v0104**(v0100 ~ v0103 留著)| 見 runtime 清單 | 見 runtime 清單 | **新**(缺句 MISSING · 讀不到 PDF 一列 FAIL · 忽略 bullet / 控制字元)|",
                                             "| **VRN2_IndependentVerifier** | **v0110**(v0105 核心 · v0106 ~ v0109 留著)| 見 runtime 清單 | 見 runtime 清單 | **新**(四點 MISSING 判決)|"])
after("| **v0134** | 同 v0239 | v0127 | v0114 | 整合一支", ["| v0135 / v0136 | 同 v0239 | v0127 | v0114 | Codex #561 / #562 · 整合一支第二回(驗證器 v0104 / v0105 · ⑫a)|",
                                                        "| (另一團隊 v0137 ~ v0140 · 套件 v0102 ~ v0104)| v0240 ~ v0242 | v0127 | v0115 | 私有 runtime · 原文四點(SOURCE_VERBATIM)· 冪等語意比較 · 緊湊 U/I · 完成驗收容許缺值 |",
                                                        "| **v0141** | → **v0243** | v0127 | **v0116** | 收尾套件:四點補齊階梯 · 冪等閘像對像 ×2 + 分類 + 自動再跑一輪 · 原文核對 v0104 · 驗證器 v0110 · 備援指令回 v0136 契約 |"])
before("## 7. 本輪修正(v0135 → v0136 · 整合一支 第二回)", [
    "## 7. 本輪修正(v0136 / 另一團隊 v0140 → v0141 · 收尾套件)",
    "",
    "| # | 貼回(v0140 · C:\\測試樣本報告)| 追到的根因 | v0141 做法 | 實測 |",
    "|---|---|---|---|---|",
    "| 1 | 冪等 RED:神達 3706 主跑紀錄 ≠ 重跑 | v0242 閘:主跑紀錄(快取 / 子行程)vs 同行程重跑一次;分不出紀錄過期與引擎非冪等;神達原檔不在容器 | 管理器 v0243:主跑同一條子行程路徑重跑 ×2 → GREEN / STALE_RECORD(清該檔擷取快取 → 啟動器自動第 2 輪)/ NONDETERMINISTIC(RED · 第一個差異路徑)· 收據記錄執行環境 | 13 份真實檔三路徑 ×4 差異 %d · 沙盒冪等 %s · 自癒情境 STALE_RECORD → 第 2 輪 %s |" % (R["results"]["engine_determinism_13_real"]["semantic_differences"], rr["idempotence"]["classification"], heal["final_classification"]),
    "| 2 | 四點原文核對 FAIL 8(GFHK P1~4 · 欣銓 P3~4 · 3014TT · 華南 2606)| v0115 只挑嚴格句;空點被原文核對 v0103 算 FAIL | ENG062 v0116 階梯補齊(每點精確字串 · 去 bullet / 控制字元)· 原文核對 v0104 缺句 = MISSING rc 2 · 驗證器 v0110 | 合成 GFHK / 欣銓式 PDF 0/4 · 1/4 → 4/4 · 4/4;真實 13 份 %s;沙盒 %s |" % (R["results"]["four_points_real13_v0115"], rr["source_quotes"]),
    "| 3 | 輸出冊缺項 6 | 同 2 | 同 2 | 沙盒一標題四重點 %d 份全 4/4 |" % rr["summary_rows"],
    "| 4 | U/I 備援「複製執行指令」| v0242 換成只有 PS7 模板 | 管理器 v0243 回 v0136 契約 + PS7 模板 + VRN2_ROOT + finally Restore | Chromium %s |" % R["results"]["ui_real_browser"]["ui_test"],
    "| 5 | 獨立驗證 ✗ 45(6933 AMAX 37 · 凱基 2891 8)| 兩份 PDF 不在容器 | 財務核心 v0105 不動;要原檔或 digest | — |",
    "| 6 | 入口 | 另一團隊的 Invoke-VRN2-Closeout_v0104.ps1 寫死 v0140 | 不出 .ps1:一鍵 `VRN2_OneClick_v0141.md`(③ 套件雜湊 + 套件內逐檔雜湊 · ⑤ 收尾收據 / 冪等閘 · ⑤b 處理器在 functional modules\\VRN2)| pwsh 情境見 VRN2_Verification_v0141.md |",
    "",
    "---",
    ""])
sub("## 7. 本輪修正(v0135 → v0136 · 整合一支 第二回)", "## 7.0f v0135 → v0136(整合一支 第二回)")
before("## 8. 已知問題與待辦(依優先序)", [])
after("## 8. 已知問題與待辦(依優先序)", ["", "| 0 | **(v0141)** 獨立驗證 ✗ 45(6933 AMAX 37 · 凱基 2891 8)與 神達 / GFHK / 欣銓 原檔不在容器:要操作員用 v0141 跑一次 `C:\\測試樣本報告`,把 `VRN2_Closeout_v0141.json` + `IDEMPOTENCE_latest.json` + `verify_independent\\*.digest.txt` 貼回 | 下一輪 |",
                                   "| 0b | **(v0141)** 冪等閘若回 NONDETERMINISTIC:收據 `differences_rerun_vs_rerun` 第一個路徑就是擷取端非冪等的位置(ENG397 v0127 要出 v0128)| 看收據 |",
                                   "| 0c | **(v0141)** MQ-1560 影像頁四點 OCR_PENDING 是設計(rc 2 黃);要綠需人工核對原圖 | 不改 |"])
sub("## 10. 執行方式", "## 10. 執行方式(v0141:貼 `vrn2_release_v0141/VRN2_OneClick_v0141.md` 的一行;或 `python <套件夾>\\ActivateVRN-2_v0141.py --source C:\\測試樣本報告`;`$env:VRN2_NO_REPASS=1` 不自動再跑)")
after("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)", ["",
    "- **(v0141)** 另一團隊的收尾套件(v0137 ~ v0140 · 私有 runtime `functional modules\\VRN2`)是現役入口:改 VRN-2 = 出新 runtime 成員 + 新入口版號,runtime 清單逐檔雜湊、舊成員一個都不少;不要再把元件 base64 內嵌回單檔啟動器。",
    "- **(v0141)** 冪等閘三分類:GREEN / STALE_RECORD(清快取 · 啟動器自動再跑一輪)/ NONDETERMINISTIC(RED);RED 時先看收據 `context`(-I · fitz · PYTHONHASHSEED · 快取夾)與第一個差異路徑,再動擷取端。",
    "- **(v0141)** 四點:缺句是 MISSING(待核對 · 黃),不是 FAIL;FAIL 只留給「有文字但第二讀取器讀不到 / PDF 換過 / 雜湊不對」。階梯補的點 evidence.selection = relaxed / line / page,仍是精確字串。",
    "- **(v0141)** U/I 備援指令契約:升優先權 → PS 加速器 → PS7 模板 → `& $py $A`;不上船版帶 `VIA_VRN2_NO_PUSH='1'`。真瀏覽器測試(`ui_test141.js`)會查。",
    "- **(v0141)** 不出 .ps1;一鍵 md 的 ③ 要核對套件雜湊 + `PACKAGE_SHA256.json` 逐檔。"])
out.write_text("\n".join(lines), encoding="utf-8"); print("handover v0141 written", len(lines), "lines")
