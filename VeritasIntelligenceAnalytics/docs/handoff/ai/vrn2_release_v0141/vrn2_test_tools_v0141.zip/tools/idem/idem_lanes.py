# 主跑路徑(平行分路 · 子行程)vs 冪等重跑路徑(同行程 · LANES=1)· 同一批真檔各跑一次 + 再跑一次 LANES=1 → 三方比對
import sys, json, os, shutil, tempfile, importlib.util, contextlib
from pathlib import Path
RT = Path(sys.argv[1]); SRC = Path(sys.argv[2]); OUT = Path(sys.argv[3]); OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(Path(__file__).parent)); from idemlib import semantic_record, record_differences  # noqa
spec = importlib.util.spec_from_file_location("eng397_lanes", RT / "VRN_ENG397_P1Segment_v0127.py"); eng = importlib.util.module_from_spec(spec); sys.modules[spec.name] = eng; spec.loader.exec_module(eng)
def one(tag, lanes, cache=None):
    d = OUT / tag; shutil.rmtree(d, ignore_errors=True); (d / "in").mkdir(parents=True)
    for p in SRC.glob("*.pdf"): shutil.copy2(p, d / "in" / p.name)
    os.environ["VIA_VRN2_LANES"] = str(lanes)
    if cache: os.environ["VIA_VRN2_P1_CACHE"] = str(cache)
    else: os.environ.pop("VIA_VRN2_P1_CACHE", None)
    with (d / "run.log").open("w", encoding="utf-8") as log, contextlib.redirect_stdout(log):
        eng.run(d / "in", d / "rep")
    rows = {r["file"]: r for r in json.loads((d / "rep/p1view/P1VIEW_latest.json").read_text(encoding="utf-8"))}
    print(f"{tag}: lanes {lanes} files {len(rows)} lamps {dict((f, r.get('lamp')) for f, r in rows.items())}")
    return rows
A = one("A_lanes3_cache", 3, OUT / "p1cache")   # 主跑:平行 + 寫快取
B = one("B_inproc1", 1)                            # 冪等重跑:同行程 · 無快取
C = one("C_inproc1_again", 1)
D = one("D_lanes3_cachehit", 3, OUT / "p1cache")  # 主跑第二輪:快取命中
for name in sorted(A):
    for tag, other in (("A~B", B), ("B~C", C), ("A~D", D)):
        diff = record_differences(semantic_record(A[name] if tag != "B~C" else B[name]), semantic_record(other.get(name, {})))
        if diff:
            print(f"DIFF {tag} {name}: {len(diff)}")
            for row in diff[:6]: print("   ", json.dumps(row, ensure_ascii=False)[:260])
print("done")
