# 冪等重現:ENG397 v0127 對同一份 PDF 連跑 N 次(VIA_VRN2_LANES=1 · 無 P1 快取)· 以 v0242 的 semantic_record / record_differences 比較
import sys, json, os, shutil, tempfile, importlib.util, contextlib, hashlib
from pathlib import Path
RT = Path(sys.argv[1]); PDF = Path(sys.argv[2]); N = int(sys.argv[3]); OUT = Path(sys.argv[4]); OUT.mkdir(parents=True, exist_ok=True)
RUNTIME_METADATA = frozenset(("n", "img", "cache", "cache_hit", "cache_path", "elapsed", "elapsed_s", "secs", "duration_s", "pid", "worker_id", "generated_at"))
def semantic_record(value, key="", path=()):
    if isinstance(value, dict):
        ignored = RUNTIME_METADATA - {"img"} if not path else ({"img"} if len(path) == 2 and path[0] == "pages" else set())
        return {name: semantic_record(item, name, path + (name,)) for name, item in value.items() if name not in ignored}
    if isinstance(value, list):
        result = [semantic_record(item, key, path + (index,)) for index, item in enumerate(value)]
        return sorted(result) if key in ("reasons", "na") and all(isinstance(item, str) for item in result) else result
    return value
def record_differences(before, after, path="", limit=80):
    if type(before) is not type(after): return [{"path": path, "before": before, "after": after}]
    if isinstance(before, dict):
        out = []
        for name in sorted(set(before) | set(after)):
            if name not in before or name not in after: out.append({"path": path + "/" + name, "before": before.get(name), "after": after.get(name)})
            else: out.extend(record_differences(before[name], after[name], path + "/" + name, limit - len(out)))
            if len(out) >= limit: break
        return out[:limit]
    if isinstance(before, list):
        out = []
        if len(before) != len(after): out.append({"path": path + "/length", "before": len(before), "after": len(after)})
        for index, (l, r) in enumerate(zip(before, after)):
            out.extend(record_differences(l, r, path + f"/{index}", limit - len(out)))
            if len(out) >= limit: break
        return out[:limit]
    return [] if before == after else [{"path": path, "before": before, "after": after}]
spec = importlib.util.spec_from_file_location("eng397_idem", RT / "VRN_ENG397_P1Segment_v0127.py"); eng = importlib.util.module_from_spec(spec); sys.modules[spec.name] = eng; spec.loader.exec_module(eng)
os.environ["VIA_VRN2_LANES"] = "1"; os.environ.pop("VIA_VRN2_P1_CACHE", None)
recs = []
for i in range(N):
    d = Path(tempfile.mkdtemp(prefix="idem_", dir=str(OUT))); (d / "in").mkdir(); shutil.copy2(PDF, d / "in" / PDF.name)
    with (d / "run.log").open("w", encoding="utf-8") as log, contextlib.redirect_stdout(log):
        eng.run(d / "in", d / "rep")
    rows = json.loads((d / "rep/p1view/P1VIEW_latest.json").read_text(encoding="utf-8"))
    rec = rows[0]; recs.append(rec)
    (OUT / f"rec_{i}.json").write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"run {i}: lamp {rec.get('lamp')} pages {len(rec.get('pages') or [])} engines {[ (z.get('engine') or '')[:30] for pg in rec.get('pages') or [] for z in pg.get('zones') or []][:6]}")
for i in range(1, N):
    diff = record_differences(semantic_record(recs[0]), semantic_record(recs[i]))
    print(f"run0 vs run{i}: {len(diff)} differences")
    for row in diff[:12]: print("  ", json.dumps(row, ensure_ascii=False)[:300])
