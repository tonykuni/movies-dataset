from pathlib import Path
RUNTIME_METADATA = frozenset(("n", "img", "cache", "cache_hit", "cache_path", "elapsed", "elapsed_s", "secs", "duration_s", "pid", "worker_id", "generated_at"))
def semantic_record(value, key="", path=()):
    if isinstance(value, dict):
        ignored = RUNTIME_METADATA - {"img"} if not path else ({"img"} if len(path) == 2 and path[0] == "pages" else set())
        return {name: semantic_record(item, name, path + (name,)) for name, item in value.items() if name not in ignored}
    if isinstance(value, list):
        result = [semantic_record(item, key, path + (index,)) for index, item in enumerate(value)]
        return sorted(result) if key in ("reasons", "na") and all(isinstance(item, str) for item in result) else result
    return value
def record_differences(before, after, path="", limit=80):
    if type(before) is not type(after): return [{"path": path, "before": before, "after": after}]
    if isinstance(before, dict):
        out = []
        for name in sorted(set(before) | set(after)):
            if name not in before or name not in after: out.append({"path": path + "/" + name, "before": before.get(name), "after": after.get(name)})
            else: out.extend(record_differences(before[name], after[name], path + "/" + name, limit - len(out)))
            if len(out) >= limit: break
        return out[:limit]
    if isinstance(before, list):
        out = []
        if len(before) != len(after): out.append({"path": path + "/length", "before": len(before), "after": len(after)})
        for index, (l, r) in enumerate(zip(before, after)):
            out.extend(record_differences(l, r, path + f"/{index}", limit - len(out)))
            if len(out) >= limit: break
        return out[:limit]
    return [] if before == after else [{"path": path, "before": before, "after": after}]
