#!/bin/bash
# 冪等自癒情境:在已跑過的樹上,竄改 p1_cache 裡第 1 份(依檔名排序 · 綠燈 · ≥2 頁)的擷取紀錄一個數值 → 再跑一次啟動器 v0141
#   期待:第 1 輪 ⑧ 冪等 RED(STALE_RECORD · 清快取)→ 啟動器自動第 2 輪 → 冪等 GREEN · 跑了 2 輪
S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v141
T="$1"; N="${2:-stale141}"
V2="$T/VIA/VIA_Reports/vrn2"
$S2/venv_vrn2/bin/python - "$V2" <<'PY'
import json, sys, re
from pathlib import Path
v2 = Path(sys.argv[1]); cache = v2 / "p1_cache"
idem = json.loads((v2 / "IDEMPOTENCE_latest.json").read_text(encoding="utf-8"))
target = sorted(e["file"] for e in idem["files"])[0]
print("tamper target:", target, "· classification before:", idem.get("classification"), idem.get("lamp"))
hit = None
for cf in cache.glob("*.json"):
    rec = json.loads(cf.read_text(encoding="utf-8"))
    if rec.get("file") == target:
        hit = cf; break
assert hit, "cache record not found"
rec = json.loads(hit.read_text(encoding="utf-8"))
done = False
for pg in rec.get("pages") or []:
    for z in pg.get("zones") or []:
        for row in z.get("rows") or []:
            for i, c in enumerate(row):
                if re.fullmatch(r"\d[\d,]*\.\d+", c or ""):
                    row[i] = c[:-1] + ("7" if c[-1] != "7" else "8"); done = True; break
                if done: break
            if done: break
        if done: break
    if done: break
assert done, "no numeric cell to tamper"
hit.write_text(json.dumps(rec, ensure_ascii=False, default=str), encoding="utf-8")
print("tampered", hit.name)
PY
bash $W/tools/run_full.sh "$T" ActivateVRN-2_v0141.py "$N"
cat $W/$N.rc; grep -E "冪等閘|自動再跑|NEXT:|→ (RED|GREEN|YELLOW) ⑧" $W/$N.log | cut -c1-260
$S2/venv_vrn2/bin/python - "$V2" <<'PY'
import json, sys
from pathlib import Path
v2 = Path(sys.argv[1])
idem = json.loads((v2 / "IDEMPOTENCE_latest.json").read_text(encoding="utf-8"))
rc = json.loads((v2 / "VRN2_Closeout_v0141.json").read_text(encoding="utf-8"))
print("final idempotence:", idem.get("classification"), idem.get("lamp"), "· passes:", [(p["attempt"], p["rc"], p["idempotence"][:60], p["repass"]) for p in rc["passes"]], "· closeout rc", rc["rc"])
PY
