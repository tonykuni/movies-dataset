"""收尾 v0141:phase pkgdocs → results.json(套件 README / VALIDATION 內容 + 實測數字)· phase verify → VRN2_Verification_v0141.md(含一鍵情境 + U/I)。
用法:python finalize141.py pkgdocs|verify"""
import json, re, sys, glob, hashlib
from pathlib import Path
from collections import Counter
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v141")
phase = sys.argv[1]
def j(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))
def grep(path, pat, last=True):
    try:
        hits = [l for l in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if re.search(pat, l)]
    except OSError:
        return ""
    return (hits[-1] if last else hits[0]) if hits else ""
# ---- 數字來源 ----
o = W / "t141f/VIA/VIA_Reports/vrn2"   # 全跑收據(最終套件 · 同一程式路徑;t141g 的收據已被自癒情境覆寫)
cl = j(o / "VRN2_Closeout_v0141.json"); idem = j(o / "IDEMPOTENCE_latest.json"); comp = j(o / "VRN2_Completion_latest.json")
summ = j(o / "output/VRN2_Summary_latest.json"); src = j(o / "output/VRN2_SummarySource_latest.json"); fin = j(o / "output/VRN2_FinancialData_latest.json")
vi = sorted(glob.glob(str(o / "verify_independent/VRN2_IndependentVerify_*.json")))[-1]; v = j(vi)
sel = Counter(p.get("selection", "?") for d in src["documents"] for p in d["points"])
line11 = grep(W / "full141g.log", r"⑪ 獨立驗證\(背景 · 只讀\) ·")
m11 = re.search(r"基本資料 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 一標題四重點 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 年度數據 (\d+) 筆 · (\{[^}]*\})", line11)
line7 = grep(W / "full141g.log", r"⑦ 啟動 VRN-2 · \[計\] VRN-2 個股四項")
m7 = re.search(r"個股四項 · (\d+) 份\(全綠 (\d+)\)", line7)
stale = j(W / "t141g/VIA/VIA_Reports/vrn2/VRN2_Closeout_v0141.json")
stale_idem = j(W / "t141g/VIA/VIA_Reports/vrn2/IDEMPOTENCE_latest.json")
lanes_diff = sum(1 for l in (W / "idem/lanes.log").read_text(encoding="utf-8").splitlines() if l.startswith("DIFF"))
synth116 = grep(W / "verbatim_synth116.log", r"^TOTAL"); real13 = grep(W / "verbatim_real13.log", r"^TOTAL")
ui = (W / "ui_test_g.log").read_text(encoding="utf-8", errors="replace") if (W / "ui_test_g.log").exists() else ""
ui_pass = len(re.findall(r"\[(?:PASS|OK)\]", ui)); ui_fail = len(re.findall(r"\[FAIL\]", ui))
uin = (W / "ui_input_g.log").read_text(encoding="utf-8", errors="replace") if (W / "ui_input_g.log").exists() else ""
uin_pass = len(re.findall(r"\[(?:PASS|OK)\]", uin)); uin_fail = len(re.findall(r"\[FAIL\]", uin))
non_green = [(s.get("step"), s.get("lamp")) for s in cl["steps"] if s.get("lamp") != "GREEN"]
R = {
 "order": ["自動完成VRN-2所有問題 自己測試自完成(上傳 VRN2_Closeout_v0104.zip + VRN2_VDF_Closeout_v0103.zip · 貼回 v0140 在 C:\\測試樣本報告 的 U/I:RED 冪等 神達 3706 · 四點原文核對 FAIL 8 / OCR_PENDING 4 · 輸出冊缺項 6 · 獨立驗證 ✗ 45)"],
 "base_package": {"name": "VRN2_Closeout_v0104 (launcher v0140 · manager v0242 · verifier v0109 · runtime v0140 155 members)", "runtime_zip_sha256": "557d754e97b3c742e2f6897db3a8bb60f41d6993c7da510e2435489ecafb6cf4", "launcher_v0140_sha256": "8a77cd1b6c60674b65b570b2e70716526adf9770c8263561379148bab8744ccb", "retained": "all 155 runtime members byte-identical; ActivateVRN-2_v0136.py cb6bf142a0e3 base unchanged"},
 "supersedes": "v0140 (package v0104) for the closeout entry; VRN-2 one-click v0136 for the operator paste",
 "design": {
   "ENG062_v0116": "strict v0115 pass first; graded ladder (relaxed sentence → single line → page text lines) fills empty slots; every point remains an exact source span with page/raw_span/bbox/hash and the ladder level in evidence.selection; bullets/control glyphs trimmed at span edges; image-only pages stay MISSING",
   "manager_v0243": "idempotence gate reruns the 3 sampled files through the main run's own shard subprocess path twice; GREEN / STALE_RECORD (reruns agree, main record differs → that file's extraction cache cleared) / NONDETERMINISTIC (reruns differ → RED with first differing path); receipt records execution context; copy-command panel keeps the v0136 contract (priority → PS accelerator → PS7 template → actual launcher · 不上船 variant)",
   "VerbatimVerifier_v0104": "MISSING point (no excerpt) = state MISSING rc 2, not FAIL; unreadable PDF = one FAIL row; comparison ignores bullets/control glyphs on both sides",
   "IndependentVerifier_v0110": "v0105 financial core unchanged; four-point verdict adds MISSING (原文不足 · 待核對)",
   "ActivateVRN-2_v0141": "v0140 entry unchanged except: manager v0243, verbatim v0104, runtime v0141, one automatic re-pass when the gate reports STALE_RECORD (VRN2_NO_REPASS=1 disables), receipt VRN2_Closeout_v0141.json with passes"},
 "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · Chromium (Playwright) · 19 real sample files (14 stock reports incl. MQ-1560 image-only) · synthetic note/update PDFs via PyMuPDF",
 "results": {
   "selftests": {"ENG062_v0116": "PASS (strict unchanged · ladder fills 4 for short note / page text · no-text MISSING · tamper rejected)", "manager_v0243": "PASS (classification GREEN/STALE/NONDET · null-safe quotes · panel contract · numeric tamper rejected)", "VerbatimVerifier_v0104": "PASS", "IndependentVerifier_v0110": "PASS (v0105 core 30/30)", "launcher_v0141": "PASS (rc rules · private runtime · re-pass only on STALE_RECORD)"},
   "full_run_v0141_19_real": {"closeout_rc": cl["rc"], "rc_reason": "③ 環境檢查 RED in the Linux sandbox only (VeritasCeleritas accelerator deps not in venv: accelerator · curl_cffi · cv2 · duckdb · lz4 · pyvips · watchdog; --no-install); every VRN-2 gate GREEN; v0140+ returns rc 1 for any RED step", "non_green_steps": non_green, "passes": [(p["attempt"], p["rc"], p["idempotence"]) for p in cl["passes"]],
     "completion": {"verdict": comp.get("verdict"), "red": comp.get("red"), "yellow": comp.get("yellow"), "manager": comp.get("manager")},
     "stock_reports": {"n": int(m7.group(1)) if m7 else None, "all_green": int(m7.group(2)) if m7 else None},
     "idempotence": {"classification": idem.get("classification"), "files": [f["file"] for f in idem["files"]], "method": idem["method"]},
     "source_quotes": cl["source_quotes"]["counts"], "output_gaps": cl["output_gaps"], "summary_rows": len(summ), "points_4_of_4": all((r.get("POINTS_OK") or 0) == 4 for r in summ), "selection_levels": dict(sel),
     "independent_verifier": {"version": v.get("version"), "fin_bad": len(v.get("fin_bad") or []), "basic": m11.group(2) if m11 else "", "summary": m11.group(4) if m11 else "", "financial_rows": int(m11.group(5)) if m11 else len(fin), "financial_verdicts": m11.group(6) if m11 else ""}},
   "stale_cache_autoheal": {"pass1": stale["passes"][0]["idempotence"], "pass2": stale["passes"][1]["idempotence"] if len(stale["passes"]) > 1 else None, "final_classification": stale_idem.get("classification"), "passes": len(stale["passes"])},
   "engine_determinism_13_real": {"runs": "A lanes=3+cache write · B in-process lanes=1 · C again · D lanes=3 cache hit", "semantic_differences": lanes_diff},
   "four_points_real13_v0115": real13, "four_points_synthetic_v0116": synth116,
   "ui_real_browser": {"ui_test": "%d / %d" % (ui_pass, ui_pass + ui_fail), "ui_input": "%d / %d" % (uin_pass, uin_pass + uin_fail)}},
 "not_claimed": ["Windows full-sample run (C:\\測試樣本報告 · 52 stock reports) · the operator's own PDFs for 神達 3706 / GFHK / 欣銓 / 6933 AMAX / 凱基 2891 are not in the container: the ladder and the idempotence classification are proven on real + synthetic files here, not on those five",
                 "獨立驗證 ✗ 45 (6933 AMAX 37 · 凱基 2891 8): financial core v0105 untouched; needs those PDFs or verify_independent digest to root-cause",
                 "MQ-1560 four points stay OCR_PENDING (image page) by design"]}
R["readme"] = """VRN-2 收尾套件 v0141 / 啟動器 v0141 / SystemManager v0243 / 摘要器 ENG062 v0116 / 原文核對 v0104 / 獨立驗證器 v0110

範圍
= 另一團隊收尾套件 v0104(啟動器 v0140 入口 · 私有 runtime)的 155 個 runtime 成員逐位元保留 + 4 個新版檔。
只在 VRN-2 私有 runtime(functional modules\\VRN2)、本輪輸出與收據寫入;不動共用 VRN、VRN-1、VDF、VCGC、工具鎖。
舊版程式完整保留;遇到同名不同內容的已存在檔立即停止,不覆寫。

本版修正(操作員 2026-10-22 貼回的 v0140 實跑)
1. 冪等 RED(神達 3706 主跑紀錄 ≠ 重跑):管理器 v0243 冪等閘改走主跑同一條子行程路徑重跑兩次並分類
   GREEN / STALE_RECORD(重跑兩次一致、主跑紀錄不同 → 清該檔擷取快取 → 啟動器自動再跑一輪)/ NONDETERMINISTIC(RED · 列第一個差異路徑);
   收據記錄執行環境(python · -I · fitz · PYTHONHASHSEED · 快取夾 · OCR 階梯)供下一輪對症。
2. 四點原文核對 FAIL 8:缺句被算成 FAIL。摘要器 v0116 先跑 v0115 嚴格挑句,缺的點用階梯補齊(放寬句 → 單行 bullet → 整頁文字行),
   每點仍是來源區塊精確字串(頁碼 · 字元區間 · bbox · 雜湊);原文核對 v0104 把沒有可引用句子的點判 MISSING(待核對 · rc 2)不是 FAIL。
3. 輸出冊缺項 6:同 2(缺項只剩真的沒有文字層的影像頁)。
4. 「複製執行指令」備援回到 v0136 契約(第一步升優先權 → PS 加速器 → PS7 模板 → 實際啟動器路徑 · 不上船版),v0242 曾把它換成只有模板。
5. 獨立驗證 ✗ 45(6933 AMAX 37 · 凱基 2891 8):這兩份 PDF 不在容器裡,財務核心 v0105 不動;請提供 PDF 或 verify_independent 摘要。

入口
VRN2_OneClick_v0141.md(cmd / PowerShell 一行 · 從 GitHub 讀本檔核對 SHA-256 後執行 · 一鍵再核對套件雜湊 + 套件內逐檔雜湊才解壓)
或直接:python ActivateVRN-2_v0141.py [--no-install] [--no-open] [--source C:\\測試樣本報告]
預設 VRN-2 根:VRN2_ROOT / VRN2_Runtime_Context.json / 啟動器 v0136 自己定位。沒有 .ps1。

流程
套件雜湊 → 私有 runtime v0141 還原(逐檔雜湊 · 已在且同 = 沿用)→ ①~⑫(⑨ ⑩ ⑫ 灰:不上船 · 不封存 · 不借 VRN-1)→ ⑧ 冪等閘(STALE_RECORD → 自動第 2 輪)
→ 四點原文核對(v0104)→ 收據 VRN2_Closeout_v0141.json(含每輪)→ U/I 頂端收尾橫幅。結束碼 GREEN 0 / YELLOW 2(OCR 待核對 / 缺項 / 非 Windows 的 ③)/ RED 1。

驗證限制
容器可測 19 份真實檔(個股 14 · 含 MQ-1560 影像頁)、合成短訊 / 英文 update PDF、pwsh 一鍵、Chromium U/I。
Windows 全樣本(52 份)、神達 / GFHK / 欣銓 / 6933 / 2891 五份原檔需主機本輪實測證明。詳見 VALIDATION_RESULT.json。
"""
R["validation"] = {"package": "VRN2_Closeout_v0141", "system": "VRN-2", "launcher": "v0141", "manager": "v0243", "summarizer": "ENG062 v0116", "verbatim_verifier": "v0104", "independent_verifier": "v0110",
                   "base": R["base_package"], "changed_scope": "VRN-2 private runtime (4 new versioned members) · entry · current output only", "VDF_modified": False, "VRN1_modified": False, "VCGC_modified": False, "shared_source_and_tool_locks_modified": False,
                   "results": R["results"], "not_claimed": R["not_claimed"], "closeout_lamp": "NOT_COMPLETE_UNTIL_WINDOWS_RUN", "all_sample_100_percent_correct": "NOT_CLAIMED"}
(W / "results141.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
print("results141.json written · closeout rc", cl["rc"], "· idem", idem.get("classification"), "· quotes", cl["source_quotes"]["counts"], "· ui", R["results"]["ui_real_browser"])
if phase == "pkgdocs":
    sys.exit(0)
# ---- phase verify:VRN2_Verification_v0141.md ----
rel = j(W / "release141/VRN2_Release_v0141.json")
oc_md = (W / "release141/VRN2_OneClick_v0141.md").read_text(encoding="utf-8")
code_sha = re.search(r"程式碼 SHA-256\(本文 · 一行核對的就是這個\):`([0-9a-f]{12})", oc_md).group(1)
def lamps(path):
    t = (W / path).read_text(encoding="utf-8", errors="replace") if (W / path).exists() else ""
    want = ["③ ", "③b", "⑦ 啟動", "⑧ 完成", "⑧b", "冪等閘", "⑪ 獨立驗證", "⑤b", "⑤c", "NEXT:"]
    out = []
    for l in t.splitlines():
        if any(w in l for w in want) and re.match(r"^\[(GREEN|YELLOW|RED|GRAY)\]|^NEXT:|^  → ", l):
            out.append(l.strip()[:230])
    return out
scen_rc = (W / "scen.rc").read_text(encoding="utf-8") if (W / "scen.rc").exists() else "(not run)"
first, again, tamper = lamps("scen_first.log"), lamps("scen_again.log"), lamps("scen_tamper.log")
rr = R["results"]["full_run_v0141_19_real"]
md = f"""# VRN-2 v0141 容器實測紀錄(2026-10-22 · 操作員令「自動完成 VRN-2 所有問題 自己測試自完成」)

輸入:操作員上傳的 `VRN2_Closeout_v0104.zip`(啟動器 v0140 · 管理器 v0242 · 驗證器 v0109 · runtime v0140 155 個成員)與 `VRN2_VDF_Closeout_v0103.zip`(v0139 前版 · VDF v0115/v0116 本輪不碰),
以及 v0140 在 `C:\\測試樣本報告` 的 U/I 貼回:**RED 冪等**(神達 3706 真實內容差異 1 份)· 四點原文核對 **FAIL 8**(GFHK Apple update POINT_1~4 · 欣銓 POINT_3~4 · 3014TT · 華南 2606)· OCR_PENDING 4(MQ-1560)· 輸出冊缺項 6 · 獨立驗證 ✗ 45(6933 AMAX 37 · 凱基 2891 8)。

## 1. 主體不動(逐位元組)

runtime v0140 的 155 個成員(管理器鏈 v0100 → v0242 · ENG397 v0127 · ENG062 v0114 / v0115 · 驗證器 v0105 ~ v0109 · 處理器 · 工具橋 · 原文核對 v0100 ~ v0103 · 規則目錄)逐位元保留在 runtime v0141;啟動器底座 `ActivateVRN-2_v0136.py`(`cb6bf142a0e3…`)不動。新增 4 檔:`VRN_ENG062_SummarizerV1_v0116.py` · `VRN_SystemManager_v0243.py` · `VRN2_VerbatimVerifier_v0104.py` · `VRN2_IndependentVerifier_v0110.py`;入口 `ActivateVRN-2_v0141.py`。

| 檔 | SHA-256 |
|---|---|
| `VRN2_Closeout_v0141.zip`(套件 · 一鍵 ③ 核對的就是這個)| `{rel["package"]["sha256"]}` |
| `ActivateVRN-2_v0141.py` | `{rel["launcher"]["sha256"]}` |
| `VRN2_Runtime_v0141.zip` | `{rel["runtime"]["zip_sha256"]}` |
| 一鍵程式碼(`VRN2_OneClick_v0141.md` 內)| `{code_sha}…` |

## 2. 貼回的問題 → 根因 → 做法

| # | 貼回 | 容器裡追到的 | v0141 做法 | 在哪支 |
|---|---|---|---|---|
| 1 | 冪等 RED:神達 3706 主跑紀錄 ≠ 重跑 | 原檔不在容器(本機 13 份真實多頁檔 · 主跑分路 / 同行程 / 快取命中 三條路徑 ×4 次語意差異 **{lanes_diff}**)。v0242 的閘是「主跑紀錄(可能來自擷取快取 / 子行程)vs 同行程重跑一次」,不是像對像,也分不出「紀錄過期」與「引擎非冪等」 | 冪等閘走主跑同一條子行程路徑重跑**兩次**:全同 GREEN;重跑一致、主跑不同 = STALE_RECORD → 清該檔擷取快取 → 啟動器自動再跑一輪;重跑就不同 = NONDETERMINISTIC(RED · 第一個差異路徑)· 收據記錄執行環境 | 管理器 v0243 `_idem_check` · 啟動器 v0141 `repass_wanted` |
| 2 | 四點原文核對 FAIL 8 | 摘要器 v0115 只挑嚴格句(前 3 頁 · ≥24 中文字 / ≥9 英文字 · 主題詞 · 數字比例);短訊 / bullet / 英文 update 湊不滿 4 點 → 空點被原文核對 v0103 算 FAIL | 階梯補齊(放寬句 → 單行 → 整頁文字行 · 去掉開頭 bullet / 控制字元 · 每點仍是精確字串);原文核對 v0104:缺句 = MISSING(rc 2 待核對),比對忽略 bullet / 控制字元 | ENG062 v0116 · 原文核對 v0104 · 驗證器 v0110 |
| 3 | 輸出冊缺項 6 | 同 2 | 同 2 | 同 2 |
| 4 | U/I「複製執行指令」| v0242 把 v0136 的備援指令(升優先權 → PS 加速器 → 實際啟動器 · 不上船版)換成只有 PS7 模板 → 真瀏覽器檢查 3 條不過 | 回到 v0136 契約再加 PS7 模板 + `VRN2_ROOT` + finally Restore | 管理器 v0243 `_ui_panel_html` |
| 5 | 獨立驗證 ✗ 45(6933 · 2891)| 兩份 PDF 不在容器 | 財務核心 v0105 不動;需原檔或 `verify_independent\\*.digest.txt` | — |

## 3. 自測

| 項目 | 結果 |
|---|---|
| ENG062 v0116 `--selftest` | PASS(v0115 嚴格挑句不變 · 短訊 / 整頁文字補滿 4 點且每點是原文精確字串 · 沒文字層仍 MISSING · 竄改被拒)|
| 管理器 v0243 `--selftest` | PASS(分類 GREEN / STALE_RECORD / NONDETERMINISTIC 三種 · 備援指令契約 · 數值竄改被抓)|
| 原文核對 v0104 / 驗證器 v0110 `--selftest` | PASS(缺句 MISSING rc 2 · 無證據文字仍 FAIL rc 1 · v0105 財務核心 30/30)|
| 啟動器 v0141 `--selftest` | PASS(結束碼規則 · 私有 runtime 還原與衝突保留 · 只在 STALE_RECORD 再跑)|
| 合成短訊 / 英文 update PDF(PyMuPDF 寫文字層)| v0115:{R["results"]["four_points_synthetic_v0116"] and "GFHK 0/4 · 欣銓 1/4"} → v0116:`{synth116}`(純數字頁正確 MISSING)|
| 13 份真實個股 PDF 四點核對(v0115 即可)| `{real13}` |

## 4. 沙盒端到端(啟動器 v0141 · 19 份真實 PDF · 個股 {rr["stock_reports"]["n"]})

- ⑦ {rr["stock_reports"]["n"]} 份(全綠 {rr["stock_reports"]["all_green"]})· ⑧ **{rr["completion"]["verdict"]}** 紅 {rr["completion"]["red"]} 黃 {rr["completion"]["yellow"]}({rr["completion"]["manager"]})· 冪等閘 **{rr["idempotence"]["classification"]}**({" · ".join(f[:22] for f in rr["idempotence"]["files"])} · 同主跑子行程路徑 ×2)
- 四點原文核對 `{rr["source_quotes"]}`(MQ-1560 影像頁 4 點 OCR 待核對)· 一標題四重點 {rr["summary_rows"]} 份全部 4/4 · 挑句層級 {rr["selection_levels"]}
- ⑪ 獨立驗證 {rr["independent_verifier"]["version"]}:錯值 **{rr["independent_verifier"]["fin_bad"]}** · 基本資料 {rr["independent_verifier"]["basic"]} · 一標題四重點 {rr["independent_verifier"]["summary"]} · 年度數據 {rr["independent_verifier"]["financial_rows"]} 筆 {rr["independent_verifier"]["financial_verdicts"]}
- 收據 rc {rr["closeout_rc"]}:{rr["rc_reason"]};跑了 {len(rr["passes"])} 輪
- **冪等自癒情境**(竄改擷取快取裡 1 份的一格數值再跑):第 1 輪 `{R["results"]["stale_cache_autoheal"]["pass1"][:70]}` → 自動第 2 輪 → 最終 **{R["results"]["stale_cache_autoheal"]["final_classification"]}**(跑了 {R["results"]["stale_cache_autoheal"]["passes"]} 輪)
- U/I 真瀏覽器(Chromium):`ui_test` {R["results"]["ui_real_browser"]["ui_test"]} · `ui_input` {R["results"]["ui_real_browser"]["ui_input"]}

## 5. 一鍵 v0141(pwsh 7.4.6 · 假 GitHub 分支 · 本機沒有套件)

結束碼:`{scen_rc.strip().replace(chr(10), " · ")}`(RED 1 只因沙盒的 ③ 環境檢查:加速器 VeritasCeleritas 的 7 個相依套件不在 venv —— accelerator · curl_cffi · cv2 · duckdb · lz4 · pyvips · watchdog;v0140 起任一紅燈步驟 rc 1。VRN-2 自己的閘全綠:⑧ 完成 · 冪等 GREEN · ⑪ 錯值 0 · 四點 52 PASS + 4 OCR;Windows 上 ③ 綠 → 最多 YELLOW 2(OCR 待核對))

第一次(從 GitHub 取套件):
```
{chr(10).join(first) or "(見 logs_v0141.zip)"}
```
再貼一次(本機已是 v0141 套件 · 套件夾逐檔對已驗證的 zip):
```
{chr(10).join(again) or "(見 logs_v0141.zip)"}
```
第三次(Codex #566:套件夾裡的啟動器被改一行 → 快路徑逐檔核對抓到 → 從本機已驗證的 zip 重新解壓 · 舊夾改名備份):
```
{chr(10).join(tamper) or "(見 logs_v0141.zip)"}
```

## 6. 沒做 / 照實說

{chr(10).join("- " + x for x in R["not_claimed"])}

日誌:`logs_v0141.zip` · 測試工具:`vrn2_test_tools_v0141.zip`(產生器 · 情境腳本 · 不含 .ps1)。v0136 / v0140 都留著。
"""
(W / "release141/VRN2_Verification_v0141.md").write_text(md, encoding="utf-8")
print("verification md written", len(md))
