#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VRN-2 v0141: v0140 entry + four-point completion + like-for-like idempotence with one automatic re-pass.

Operator 2026-10-22 (v0140 run on C:\\測試樣本報告): RED 冪等 (神達 3706 main record ≠ in-process rerun) ·
四點原文核對 FAIL 8 (missing points counted as FAIL) · 輸出冊 缺項 6. v0141 lands runtime v0141 (summarizer
ENG062 v0116 ladder · manager v0243 shard-path idempotence ×2 with STALE_RECORD / NONDETERMINISTIC classification ·
verbatim verifier v0104 MISSING ≠ FAIL · independent verifier v0110). When the gate reports STALE_RECORD the
manager clears that file's extraction cache and this entry runs the whole flow once more (VRN2_NO_REPASS=1 disables).
Financial extraction remains the released version; four points are exact source excerpts.
"""
from __future__ import annotations

# ===== 1. Parameters =====
VERSION = "ActivateVRN-2 v0141"
BASE_NAME = "ActivateVRN-2_v0136.py"
RUNTIME_ZIP = "VRN2_Runtime_v0141.zip"
RUNTIME_MANIFEST = "VRN2_Runtime_v0141.json"
PRIVATE_FOLDER = "VRN2"
OCR_BRIDGE = "VRN2_OCRBridge_v0101.py"
CONTEXT_NAME = "VRN2_Runtime_Context.json"
STATE_PATTERNS = (("SSOT", "VRN2_SSOT_v*.json"), ("SSOT", "VRN_Config_v1*.json"), ("registry", "VRN2_*.json"), ("registry", "VRN2_*.jsonl"))
MANAGER = "VRN_SystemManager_v0243.py"
VERBATIM = "VRN2_VerbatimVerifier_v0104.py"
MAX_PASSES = 2
CRITICAL_STEPS = ("② 定位 VRN-2 · VRN-2 SystemManager", "② 擷取引擎", "② 摘要器", "②b", "⑤", "⑥ 啟動前", "⑦", "⑧", "⑪")

import hashlib
import html
import importlib.util
import json
import os
import re
from pathlib import Path
import shutil
import sys
import tempfile
import time
import zipfile

# [VIA:ACCEL-BRIDGE:v0111] The unchanged released launcher loads the existing accelerator bridge.


# ===== 2. Versioned runtime restoration =====
def load_base():
    path = Path(__file__).resolve().with_name(BASE_NAME)
    specification = importlib.util.spec_from_file_location("vrn2_release_v0136", path)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def restore_private_runtime(root: Path, package_dir: Path | None = None) -> Path:
    package_dir = package_dir or Path(__file__).resolve().parent
    manifest = json.loads((package_dir / RUNTIME_MANIFEST).read_text(encoding="utf-8"))
    archive_path = package_dir / RUNTIME_ZIP
    if hashlib.sha256(archive_path.read_bytes()).hexdigest() != manifest["zip_sha256"]:
        raise ValueError("VRN-2 runtime archive checksum mismatch")
    runtime = root / "functional modules" / PRIVATE_FOLDER
    staged = []
    with zipfile.ZipFile(archive_path) as archive:
        for entry in manifest["files"]:
            relative = Path(entry["path"])
            if relative.is_absolute() or ".." in relative.parts or len(relative.parts) != 1:
                raise ValueError("Invalid runtime member")
            data = archive.read(entry["path"])
            if hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise ValueError("Runtime member checksum mismatch: " + entry["path"])
            target = runtime / relative
            if target.exists() and target.read_bytes() != data:
                raise ValueError("Existing VRN-2 runtime differs; retained without overwrite: " + str(target))
            staged.append((target, data))
    for target, data in staged:
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    shared = root / "functional modules" / "VRN"
    for folder, pattern in STATE_PATTERNS:
        for source in (shared / folder).glob(pattern):
            target = runtime / folder / source.name
            if source.is_file() and not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
    return runtime


# ===== 3. Completion gate =====
def strict_exit_code(steps: list, original_rc: int) -> int:
    if original_rc != 0:
        return original_rc if original_rc in (1, 2, 130) else 1
    if any(entry.get("lamp") == "RED" for entry in steps):
        return 1
    for prefix in CRITICAL_STEPS:
        found = [entry for entry in steps if str(entry.get("step", "")).startswith(prefix)]
        if not found:
            return 1
        if any(entry.get("lamp") != "GREEN" for entry in found):
            return 2
    if any(entry.get("lamp") in ("YELLOW", "GRAY") and str(entry.get("step", "")).startswith("⑥c") for entry in steps):
        return 2
    return 0


def output_gaps(directory: Path) -> list:
    """Required report headings and four summary points must actually be populated."""
    gaps = []
    for stem, required in (("VRN2_BasicInfo_latest", ("FILENAME", "REPORT_DATE", "TICKER", "TITLE")), ("VRN2_Summary_latest", ("TITLE", "POINT_1", "POINT_2", "POINT_3", "POINT_4"))):
        path = directory / (stem + ".json")
        if not path.is_file():
            gaps.append({"book": stem, "reason": "missing output"})
            continue
        rows = json.loads(path.read_text(encoding="utf-8"))
        if not rows:
            gaps.append({"book": stem, "reason": "empty output"})
        for row in rows:
            missing = [key for key in required if not str(row.get(key) or "").strip()]
            if missing:
                gaps.append({"book": stem, "file": row.get("FILENAME"), "missing": missing})
    return gaps


def current_completion(base, comp, steps, comp_mtime, started):
    if comp_mtime < started - 1:
        # The native caller also prints comp.items after checking freshness.
        # Do not attribute an older run's failed items to this run.
        comp.clear()
        comp.update(verdict="本輪未寫出完成判定", red=1, yellow=0, items=[], exceptions=[])
    return base(comp, steps, comp_mtime, started)


def fresh_output_books(directory, started):
    names = ("VRN2_BasicInfo_latest.json", "VRN2_FinancialData_latest.json", "VRN2_Summary_latest.json", "VRN2_SummarySource_latest.json")
    return all((directory / name).is_file() and (directory / name).stat().st_mtime >= started - 1 for name in names)


def update_closeout_ui(path: Path, code: int, gaps: list) -> bool:
    if not path.is_file():
        return False
    label = {0: "GREEN", 1: "RED", 2: "YELLOW"}.get(code, "RED")
    message = "正式收尾通過" if code == 0 else "正式收尾尚未完成，保留待核對項目"
    reasons = "；".join(str(row.get("file", row.get("book", ""))) + ": " + ", ".join(row.get("missing", [row.get("reason", "")])) for row in gaps)
    notice = '<!--VRN2-CLOSEOUT-137-START--><div role="status" id="vrn2-closeout-137" style="padding:10px;margin-bottom:8px;border:2px solid #a66c11;background:#fff6d8;color:#523900"><strong>' + html.escape(label + " · " + message) + '</strong><div>' + html.escape(reasons) + '</div></div><!--VRN2-CLOSEOUT-137-END-->'
    page = path.read_text(encoding="utf-8")
    page = re.sub(r"<!--VRN2-CLOSEOUT-137-START-->.*?<!--VRN2-CLOSEOUT-137-END-->", "", page, flags=re.S)
    page, count = re.subn(r"(<body\b[^>]*>)", lambda match: match.group(1) + notice, page, count=1, flags=re.I)
    if count == 0:
        charset = re.match(r"\s*<meta\b[^>]*charset[^>]*>", page, flags=re.I)
        if charset:
            page = page[:charset.end()] + notice + page[charset.end():]
        else:
            page = '<meta charset="utf-8">\n' + notice + page
    temporary = path.with_suffix(".closeout.tmp")
    temporary.write_text(page, encoding="utf-8")
    temporary.replace(path)
    return True


def repass_wanted(output: Path, attempt: int) -> tuple:
    """A second pass is taken only when the idempotence gate found a stale main record (cache cleared) on the first pass."""
    if attempt >= MAX_PASSES or os.environ.get("VRN2_NO_REPASS") == "1":
        return False, "no re-pass (limit or VRN2_NO_REPASS)"
    path = output / "IDEMPOTENCE_latest.json"
    if not path.is_file():
        return False, "no idempotence receipt"
    try:
        receipt = json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return False, "unreadable idempotence receipt: " + type(error).__name__
    if receipt.get("classification") == "STALE_RECORD":
        return True, "STALE_RECORD · %s · cache cleared %d" % ("、".join(receipt.get("stale_files") or []), len(receipt.get("cache_cleared") or []))
    return False, "idempotence " + str(receipt.get("classification"))


def configure_ui_launcher(runtime, root, launcher=None):
    launcher = Path(launcher or __file__).resolve()
    path = Path(runtime) / "VRN2_UIAction_Config.json"
    config = json.loads(path.read_text(encoding="utf-8"))
    config.update(launcher=str(launcher), root=str(root), version=VERSION)
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    (launcher.parent / CONTEXT_NAME).write_text(json.dumps({"root": str(root)}, ensure_ascii=False, indent=2), encoding="utf-8")


def selftest() -> int:
    complete = [{"step": prefix, "lamp": "GREEN"} for prefix in CRITICAL_STEPS]
    assert strict_exit_code(complete, 0) == 0
    assert strict_exit_code(complete + [{"step": "⑧", "lamp": "RED"}], 0) == 1
    assert strict_exit_code(complete[:-1], 0) == 1
    assert strict_exit_code(complete[:-1] + [{"step": "⑪", "lamp": "YELLOW"}], 0) == 2
    assert strict_exit_code([], 1) == 1
    with tempfile.TemporaryDirectory(prefix="vrn2-private-check-") as temporary:
        root = Path(temporary)
        shared = root / "functional modules" / "VRN"
        shared.mkdir(parents=True)
        protected = shared / "VRN_SystemManager_v0153.py"
        protected.write_text("protected original", encoding="utf-8")
        runtime = restore_private_runtime(root)
        assert protected.read_text(encoding="utf-8") == "protected original"
        assert "def _vdf_home" in (runtime / "VRN_SystemManager_v0153.py").read_text(encoding="utf-8")
        assert (runtime / "rule_catalog_runtime.json").is_file()
        hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in runtime.iterdir()}
        restore_private_runtime(root)
        assert hashes == {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in runtime.iterdir()}
        (runtime / "VRN_SystemManager_v0153.py").write_text("different local content", encoding="utf-8")
        try:
            restore_private_runtime(root)
        except ValueError:
            pass
        else:
            raise AssertionError("Different local runtime must not be overwritten")
        cfg = runtime / "VRN2_UIAction_Config.json"
        cfg.write_text(json.dumps({"launcher": "old.py", "python": "python", "v2": "output"}), encoding="utf-8")
        launcher = root / "package" / "ActivateVRN-2_v0141.py"
        launcher.parent.mkdir()
        configure_ui_launcher(runtime, root, launcher)
        assert json.loads(cfg.read_text())["launcher"] == str(launcher)
        assert json.loads((launcher.parent / CONTEXT_NAME).read_text())["root"] == str(root)
        reports = root / "VIA_Reports" / "vrn2"
        reports.mkdir(parents=True)
        assert repass_wanted(reports, 1) == (False, "no idempotence receipt")
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "STALE_RECORD", "stale_files": ["a.pdf"], "cache_cleared": ["k.json"]}), encoding="utf-8")
        assert repass_wanted(reports, 1)[0] and not repass_wanted(reports, 2)[0]
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "NONDETERMINISTIC"}), encoding="utf-8")
        assert not repass_wanted(reports, 1)[0]
        os.environ["VRN2_NO_REPASS"] = "1"
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "STALE_RECORD"}), encoding="utf-8")
        assert not repass_wanted(reports, 1)[0]
        os.environ.pop("VRN2_NO_REPASS", None)
    print("[PASS] v0141: failure rc, missing verification, yellow verification, private runtime, catalog, re-pass only on STALE_RECORD, conflict preservation")
    return 0


# ===== 4. Delegate to the existing VRN-2 entry =====
def main(argv: list | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments == ["--selftest"]:
        return selftest()
    base = load_base()
    if os.environ.get("VRN2_ROOT"):
        root = Path(os.environ["VRN2_ROOT"]).resolve()
    elif Path(__file__).with_name(CONTEXT_NAME).is_file():
        root = Path(json.loads(Path(__file__).with_name(CONTEXT_NAME).read_text(encoding="utf-8"))["root"]).resolve()
    else:
        root, _ = base.locate()
    for key in ("VIA_VRN2_NO_PUSH", "VIA_VRN2_NO_BORROW", "VIA_VRN2_NO_VRN1_SYNC"):
        os.environ[key] = "1"
    bridge_path = Path(__file__).with_name("VIA_ExecutionBridge_v0103.py")
    spec = importlib.util.spec_from_file_location("vrn2_execution_bridge", bridge_path)
    execution_bridge = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = execution_bridge
    spec.loader.exec_module(execution_bridge)
    tool_state = execution_bridge.activate(root)
    print("[加速] VRN-2 active lock:", tool_state["accelerator"])
    runtime = restore_private_runtime(root)
    original_run = base.run
    def accelerated_run(arguments, *args, **kwargs):
        if arguments and Path(str(arguments[0])).name.lower().startswith("python"):
            arguments = execution_bridge.command(arguments, root, Path(__file__).parent)
        return original_run(arguments, *args, **kwargs)
    base.run = accelerated_run
    original_manager_setup = base.land_manager
    def manager_setup(*args, **kwargs):
        _prior_manager, lamp, detail = original_manager_setup(*args, **kwargs)
        return runtime / MANAGER, lamp, detail + " · active manager v0243"
    base.land_manager = manager_setup
    original_register = base.register_ui_protocol
    def register_current_launcher(vrn, v2):
        lamp, detail = original_register(vrn, v2)
        configure_ui_launcher(vrn, root)
        return lamp, detail + " · launcher v0141"
    base.register_ui_protocol = register_current_launcher
    base._ui_wait = lambda: None

    def locate_private():
        base.LOCATE.update(note="VRN-2 private runtime; exact ship v0153; manager v0243; shared VRN retained", fix=False)
        return root, runtime

    def own_runtime_ready(_runtime, _root):
        return "GREEN", "Exact VRN-2 runtime verified in functional modules/VRN2; shared VRN untouched"

    def skip_ship(*_arguments):
        return "GRAY", "Closeout validation only; no Git commit or push"

    def skip_archive(*_arguments):
        return "GRAY", "Versioned runtime retained; no files moved or deleted"

    original_ocr_environment = base.ocr_env

    def ocr_environment(environment=None):
        lamp, detail = original_ocr_environment(environment)
        target = os.environ if environment is None else environment
        if lamp == "GREEN":
            target["VIA_VRN2_OCR_BRIDGE"] = str(Path(__file__).resolve().with_name(OCR_BRIDGE))
        return lamp, detail + " · official ONNX telemetry opt-out bridge v0101"

    base.VERSION = VERSION
    base.locate = locate_private
    base.restore_bundle = own_runtime_ready
    base.git_ship = skip_ship
    base.consolidate = skip_archive
    base.ocr_env = ocr_environment
    base.PACK.clear()
    base.STEPS.clear()
    base.LOG.clear()
    original_done = base._done_ok
    base._done_ok = lambda comp, steps, stamp, start: current_completion(original_done, comp, steps, stamp, start)
    started = time.time()
    output = root / "VIA_Reports" / "vrn2"
    output.mkdir(parents=True, exist_ok=True)
    passes = []
    for attempt in range(1, MAX_PASSES + 1):
        if attempt > 1:
            base.PACK.clear()
            base.STEPS.clear()
            base.LOG.clear()
        # The outer entry opens pages only after all gates are written.
        original_rc = base.main(arguments + (["--no-open"] if "--no-open" not in arguments else []))
        again, why = repass_wanted(output, attempt)
        passes.append({"attempt": attempt, "rc": original_rc, "lamps": {entry.get("step"): entry.get("lamp") for entry in base.STEPS}, "idempotence": why, "repass": again})
        if not again:
            break
        print("[計] ⑧ 冪等閘 · " + why + " → 自動再跑一輪(第 %d 輪 · 該檔重新擷取 · 其餘沿用快取)" % (attempt + 1), flush=True)
    code = strict_exit_code(base.STEPS, original_rc)
    gaps = output_gaps(output / "output")
    if gaps and code == 0:
        code = 2
    fresh_outputs = fresh_output_books(output / "output", started)
    proof_report = {"verdict": "NOT_RUN", "rc": 1, "reason": "本輪輸出未齊，不驗舊冊"}
    try:
        if not fresh_outputs:
            raise RuntimeError(proof_report["reason"])
        proof_path = Path(__file__).with_name(VERBATIM)
        proof_spec = importlib.util.spec_from_file_location("vrn2_original_quote_gate", proof_path)
        proof_module = importlib.util.module_from_spec(proof_spec)
        sys.modules[proof_spec.name] = proof_module
        proof_spec.loader.exec_module(proof_module)
        source = output / "scope_in"
        proof_report = proof_module.verify(output / "output", source)
    except Exception as error:
        proof_report.update(verdict="FAIL" if fresh_outputs else "NOT_RUN", error=f"{type(error).__name__}: {error}")
    (output / "VRN2_VerbatimVerify_latest.json").write_text(json.dumps(proof_report, ensure_ascii=False, indent=2), encoding="utf-8")
    if proof_report["rc"] == 1:
        code = 1
    elif proof_report["rc"] == 2 and code == 0:
        code = 2
    if proof_report["rc"]:
        gaps.append({"book": "四點原文核對", "reason": proof_report["verdict"] + " · " + str(proof_report.get("counts", proof_report.get("error", "")))})
    update_closeout_ui(output / "VRN2_UI_latest.html", code, gaps)
    receipt = {"system": "VRN-2", "version": VERSION, "rc": code, "elapsed_s": round(time.time() - started, 2), "runtime": str(runtime), "passes": passes, "steps": base.STEPS, "fresh_outputs": fresh_outputs, "output_gaps": gaps, "source_quotes": proof_report, "tools": tool_state, "shared_runtime_modified": False}
    (output / "VRN2_Closeout_v0141.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print("NEXT: [%s] VRN-2 v0141 · rc %s · 跑了 %d 輪 · %s" % ({0: "GREEN", 1: "RED", 2: "YELLOW"}.get(code, "RED"), code, len(passes), output / "VRN2_Closeout_v0141.json"))
    if "--no-open" not in arguments and os.environ.get("VRN2_NO_UI") != "1":
        print("[U/I]", base._ui_open(output, False))
    return code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print("[RED] VRN-2 v0141:", type(error).__name__, str(error), file=sys.stderr)
        raise SystemExit(1)
