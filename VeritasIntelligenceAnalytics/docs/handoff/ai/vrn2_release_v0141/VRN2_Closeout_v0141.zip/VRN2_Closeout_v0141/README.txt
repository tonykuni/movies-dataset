VRN-2 收尾套件 v0141 / 啟動器 v0141 / SystemManager v0243 / 摘要器 ENG062 v0116 / 原文核對 v0104 / 獨立驗證器 v0110

範圍
= 另一團隊收尾套件 v0104(啟動器 v0140 入口 · 私有 runtime)的 155 個 runtime 成員逐位元保留 + 4 個新版檔。
只在 VRN-2 私有 runtime(functional modules\VRN2)、本輪輸出與收據寫入;不動共用 VRN、VRN-1、VDF、VCGC、工具鎖。
舊版程式完整保留;遇到同名不同內容的已存在檔立即停止,不覆寫。

本版修正(操作員 2026-10-22 貼回的 v0140 實跑)
1. 冪等 RED(神達 3706 主跑紀錄 ≠ 重跑):管理器 v0243 冪等閘改走主跑同一條子行程路徑重跑兩次並分類
   GREEN / STALE_RECORD(重跑兩次一致、主跑紀錄不同 → 清該檔擷取快取 → 啟動器自動再跑一輪)/ NONDETERMINISTIC(RED · 列第一個差異路徑);
   收據記錄執行環境(python · -I · fitz · PYTHONHASHSEED · 快取夾 · OCR 階梯)供下一輪對症。
2. 四點原文核對 FAIL 8:缺句被算成 FAIL。摘要器 v0116 先跑 v0115 嚴格挑句,缺的點用階梯補齊(放寬句 → 單行 bullet → 整頁文字行),
   每點仍是來源區塊精確字串(頁碼 · 字元區間 · bbox · 雜湊);原文核對 v0104 把沒有可引用句子的點判 MISSING(待核對 · rc 2)不是 FAIL。
3. 輸出冊缺項 6:同 2(缺項只剩真的沒有文字層的影像頁)。
4. 「複製執行指令」備援回到 v0136 契約(第一步升優先權 → PS 加速器 → PS7 模板 → 實際啟動器路徑 · 不上船版),v0242 曾把它換成只有模板。
5. 獨立驗證 ✗ 45(6933 AMAX 37 · 凱基 2891 8):這兩份 PDF 不在容器裡,財務核心 v0105 不動;請提供 PDF 或 verify_independent 摘要。

入口
VRN2_OneClick_v0141.md(cmd / PowerShell 一行 · 從 GitHub 讀本檔核對 SHA-256 後執行 · 一鍵再核對套件雜湊 + 套件內逐檔雜湊才解壓)
或直接:python ActivateVRN-2_v0141.py [--no-install] [--no-open] [--source C:\測試樣本報告]
預設 VRN-2 根:VRN2_ROOT / VRN2_Runtime_Context.json / 啟動器 v0136 自己定位。沒有 .ps1。

流程
套件雜湊 → 私有 runtime v0141 還原(逐檔雜湊 · 已在且同 = 沿用)→ ①~⑫(⑨ ⑩ ⑫ 灰:不上船 · 不封存 · 不借 VRN-1)→ ⑧ 冪等閘(STALE_RECORD → 自動第 2 輪)
→ 四點原文核對(v0104)→ 收據 VRN2_Closeout_v0141.json(含每輪)→ U/I 頂端收尾橫幅。結束碼 GREEN 0 / YELLOW 2(OCR 待核對 / 缺項 / 非 Windows 的 ③)/ RED 1。

驗證限制
容器可測 19 份真實檔(個股 14 · 含 MQ-1560 影像頁)、合成短訊 / 英文 update PDF、pwsh 一鍵、Chromium U/I。
Windows 全樣本(52 份)、神達 / GFHK / 欣銓 / 6933 / 2891 五份原檔需主機本輪實測證明。詳見 VALIDATION_RESULT.json。
