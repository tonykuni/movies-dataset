#!/bin/bash
# v0160 最短一行 e2e:沙盒 VIA(桌機 v0153 狀態 · t153d)+ 倉的 VIA 網路工具 + 倉的 VIA PS 加速器進度模組 + 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設(AI 不代設)
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v160; T=$W/t160a; P=$S2/venv_vrn2/bin/python; REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
$P -m pip freeze > $W/freeze_before.txt 2>/dev/null
B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai; mkdir -p $D/vrn2_release_v0158 $D/vrn2_release_v0160
cp $REPO/vrn2_release_v0158/VRN2_Closeout_v0158.zip $REPO/vrn2_release_v0158/VRN2_Release_v0158.json $D/vrn2_release_v0158/
cp $W/release160/VRN2_Release_v0160.json $W/release160/VRN2_RoundAll_v0116.py $W/release160/VRN2_RoundAll_v0116.md $W/release160/VRN2_HandleAll_v0108.md $W/release160/VRN2_HandleAll_v0108_boot.txt $D/vrn2_release_v0160/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release160/tiny_line.txt)
LINE="$LINE; 'PYPROG=' + (\$global:VIA_PYPROG_LAST | ConvertTo-Json -Compress); 'START_PROCESS=' + (Get-Command Start-Process).CommandType; 'ACCEL_LIT=' + \$env:VIA_ACCEL_LIT"
run() { N=$1; shift; cd "$T/home" && env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 \
  VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2 "$@" timeout 3000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny160.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; }
rm -f $W/tiny160.rc; run report VRN2_MODE=report; run auto
mv "$T/VIA/supportive modules/VIA_PS_PyProgress_Module.ps1" "$T/VIA/supportive modules/VIA_PS_PyProgress_Module.ps1.off"; run nomod VRN2_MODE=report
mv "$T/VIA/supportive modules/VIA_PS_PyProgress_Module.ps1.off" "$T/VIA/supportive modules/VIA_PS_PyProgress_Module.ps1"
run full VRN2_MODE=full
run tmo VRN2_MODE=full VRN2_TIMEOUT_SEC=5
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0160/VRN2_HandleAll_v0108_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny160.rc
$P -m pip freeze > $W/freeze_after.txt 2>/dev/null; cmp -s $W/freeze_before.txt $W/freeze_after.txt && echo "venv unchanged" >> $W/tiny160.rc || echo "venv CHANGED" >> $W/tiny160.rc
git -C /home/user/movies-dataset status --short >> $W/tiny160.rc
