r'''v0116 收尾頁新版面(放進 RoundAll v0116:取代 CLOSEOUT_CSS / CLOSEOUT_JS / render_closeout)。單檔 · 不連外 · 一個 <script>。'''

CLOSEOUT_CSS = r'''
:root{--bg:#f3f5f9;--surface:#ffffff;--surface-2:#f8fafc;--ink:#0f172a;--ink-2:#334155;--mute:#64748b;--line:#e2e8f0;--line-2:#cbd5e1;
--accent:#2563eb;--accent-ink:#ffffff;--accent-soft:#e7eefe;--green:#15803d;--yellow:#b45309;--red:#b91c1c;--gray:#64748b;--violet:#6d28d9;--cyan:#0e7490;
--chip-vrn2:var(--red);--chip-vcgc:var(--violet);--chip-human:var(--yellow);--chip-src:var(--cyan);--chip-note:var(--gray);--chip-sum:var(--gray);
--code:#f1f5f9;--shadow:0 1px 2px rgba(15,23,42,.05),0 6px 20px rgba(15,23,42,.06);--radius:14px;color-scheme:light}
@media (prefers-color-scheme:dark){:root:not([data-theme=light]){--bg:#0a0f1c;--surface:#111a2c;--surface-2:#0d1526;--ink:#e2e8f0;--ink-2:#cbd5e1;--mute:#94a3b8;--line:#1f2b44;--line-2:#2c3b5a;
--accent:#7ba3ff;--accent-ink:#0a0f1c;--accent-soft:#16233f;--green:#4ade80;--yellow:#fbbf24;--red:#f87171;--gray:#94a3b8;--violet:#a78bfa;--cyan:#22d3ee;
--code:#0b1222;--shadow:0 1px 2px rgba(0,0,0,.45),0 10px 28px rgba(0,0,0,.35);color-scheme:dark}}
:root[data-theme=dark]{--bg:#0a0f1c;--surface:#111a2c;--surface-2:#0d1526;--ink:#e2e8f0;--ink-2:#cbd5e1;--mute:#94a3b8;--line:#1f2b44;--line-2:#2c3b5a;
--accent:#7ba3ff;--accent-ink:#0a0f1c;--accent-soft:#16233f;--green:#4ade80;--yellow:#fbbf24;--red:#f87171;--gray:#94a3b8;--violet:#a78bfa;--cyan:#22d3ee;
--code:#0b1222;--shadow:0 1px 2px rgba(0,0,0,.45),0 10px 28px rgba(0,0,0,.35);color-scheme:dark}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.6 "Segoe UI Variable","Segoe UI","Microsoft JhengHei UI","Microsoft JhengHei","PingFang TC","Noto Sans TC",system-ui,-apple-system,sans-serif;-webkit-font-smoothing:antialiased}
a{color:var(--accent)}h1{font-size:18px;margin:0;letter-spacing:.2px}h2{font-size:15px;margin:0;letter-spacing:.2px}
.sticky{position:sticky;top:0;z-index:20}
.topbar{display:flex;flex-wrap:wrap;gap:12px 20px;align-items:center;justify-content:space-between;padding:12px 24px;background:var(--surface);background:color-mix(in srgb,var(--surface) 90%,transparent);backdrop-filter:saturate(1.4) blur(10px);border-bottom:1px solid var(--line)}
.brand{display:flex;gap:12px;align-items:center;min-width:0}.mark{flex:none;display:grid;place-items:center;width:38px;height:38px;border-radius:11px;color:#fff;font-weight:800;font-size:13px;letter-spacing:.3px;background:linear-gradient(135deg,#2563eb,#7c3aed)}
.sub{color:var(--mute);font-size:12px;overflow-wrap:anywhere}.tools{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.pill{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:5px 12px;font-weight:700;font-size:13px;border:1px solid currentColor;background:color-mix(in srgb,currentColor 9%,transparent)}
.pill::before{content:"";width:8px;height:8px;border-radius:50%;background:currentColor}
.iconbtn{border:1px solid var(--line-2);background:var(--surface);color:var(--ink);border-radius:10px;padding:6px 12px;cursor:pointer;font:inherit;font-size:13px}
.iconbtn:hover{border-color:var(--accent);color:var(--accent)}
.tabs{display:flex;gap:4px;overflow-x:auto;padding:6px 24px;background:var(--surface);background:color-mix(in srgb,var(--bg) 92%,transparent);backdrop-filter:blur(10px);border-bottom:1px solid var(--line)}
section[id]{scroll-margin-top:118px}
.tabs a{flex:none;text-decoration:none;color:var(--ink-2);padding:5px 12px;border-radius:8px;font-size:13px}.tabs a:hover{background:var(--surface);color:var(--accent)}
.s-OPEN{color:var(--red)}.s-BLOCKED{color:var(--violet)}.s-REVIEW{color:var(--yellow)}.s-DATA_GAP{color:var(--cyan)}.s-PASS{color:var(--green)}
main{max-width:1320px;margin:0 auto;padding:20px 24px 48px;display:grid;grid-template-columns:minmax(0,1fr);gap:18px}
.card,.panel,.kpi{background:var(--surface);border:1px solid var(--line);border-radius:var(--radius);box-shadow:var(--shadow);min-width:0}
.panel{padding:18px 20px}.panel>header{display:flex;flex-wrap:wrap;gap:8px 16px;align-items:baseline;justify-content:space-between;margin-bottom:12px}
.count{color:var(--mute);font-size:12px}
.hero{display:grid;grid-template-columns:minmax(0,1.35fr) minmax(0,1fr) minmax(0,1.15fr);gap:18px}
.card{padding:18px 20px}.eyebrow{text-transform:uppercase;letter-spacing:1.2px;font-size:11px;color:var(--mute);font-weight:700;margin-bottom:8px}
.state{border-radius:12px;padding:12px 16px;border:1.5px solid currentColor;background:color-mix(in srgb,currentColor 8%,transparent)}
.state b{font-size:22px;display:block;letter-spacing:.3px}.state span{font-size:13px;color:var(--ink-2)}
.big{font-size:15px;margin:14px 0 0;color:var(--ink)}.note{color:var(--mute);font-size:12px;margin:12px 0 0}
.actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}
.primary{display:inline-flex;align-items:center;gap:6px;background:var(--accent);color:var(--accent-ink);border-radius:10px;padding:8px 14px;text-decoration:none;font-weight:600}
.ghost{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line-2);color:var(--ink);border-radius:10px;padding:7px 13px;text-decoration:none}
.primary:hover{filter:brightness(1.08)}.ghost:hover{border-color:var(--accent);color:var(--accent)}
.ringwrap{display:flex;gap:18px;align-items:center;flex-wrap:wrap}
.donut{flex:none;width:136px;height:136px;border-radius:50%;display:grid;place-items:center}
.donut>div{width:96px;height:96px;border-radius:50%;background:var(--surface);display:grid;place-items:center;text-align:center;line-height:1.15}
.donut b{font-size:26px;font-variant-numeric:tabular-nums}.donut small{display:block;color:var(--mute);font-size:11px}
.legend{list-style:none;margin:0;padding:0;display:grid;gap:6px;font-size:13px}.legend li{display:flex;align-items:center;gap:8px}.legend b{margin-left:auto;font-variant-numeric:tabular-nums;padding-left:16px}
.stack{display:flex;height:10px;border-radius:999px;overflow:hidden;background:var(--line);margin:4px 0 14px}.stack span{display:block;height:100%;background:var(--c)}
.owners{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px}
.owner{border:1px solid var(--line);border-left:4px solid var(--c);border-radius:10px;padding:8px 10px;background:var(--surface-2)}
.owner b{font-size:13px}.owner .n{float:right;font-weight:800;font-size:18px;color:var(--c);font-variant-numeric:tabular-nums}.owner p{margin:4px 0 0;color:var(--mute);font-size:11.5px;line-height:1.45}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px}.kpi{padding:12px 16px}
.kpi .k{color:var(--mute);font-size:12px}.kpi .v{font-size:26px;font-weight:750;font-variant-numeric:tabular-nums;line-height:1.25}
.v.green{color:var(--green)}.v.yellow{color:var(--yellow)}.v.red{color:var(--red)}.v.gray{color:var(--gray)}
.chip{display:inline-block;border-radius:999px;padding:1px 9px;font-size:12px;font-weight:650;color:#fff;background:var(--c);white-space:nowrap}
.c-VRN-2{--c:var(--chip-vrn2)}.c-VCGC{--c:var(--chip-vcgc)}.c-人工{--c:var(--chip-human)}.c-資料源{--c:var(--chip-src)}.c-提醒{--c:var(--chip-note)}.c-彙總{--c:var(--chip-sum)}
.lamp{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px;vertical-align:middle;flex:none}.l-GREEN{background:var(--green)}.l-YELLOW{background:var(--yellow)}.l-RED{background:var(--red)}.l-GRAY{background:var(--gray)}
.flow{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:6px}
.flow li{display:inline-flex;align-items:center;max-width:100%;border:1px solid var(--line);border-radius:999px;padding:3px 11px 3px 9px;font-size:12.5px;background:var(--surface-2);color:var(--ink-2)}
.flow li span.t{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.flow li.f-RED{border-color:var(--red)}.flow li.f-YELLOW{border-color:color-mix(in srgb,var(--yellow) 55%,var(--line))}
.filters{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;align-items:center}
.seg{display:inline-flex;flex-wrap:wrap;gap:4px;padding:3px;border:1px solid var(--line);border-radius:12px;background:var(--surface-2)}
.seg button{border:0;background:transparent;color:var(--ink-2);border-radius:9px;padding:5px 12px;cursor:pointer;font:inherit;font-size:13px}
.seg button.on{background:var(--surface);color:var(--accent);font-weight:650;box-shadow:var(--shadow)}
.filters input{flex:1;min-width:200px;border:1px solid var(--line-2);background:var(--surface);color:var(--ink);border-radius:10px;padding:7px 12px;font:inherit}
.filters input:focus,.iconbtn:focus-visible,.seg button:focus-visible{outline:2px solid var(--accent);outline-offset:1px}
.tablewrap{overflow:auto;max-height:70vh;border:1px solid var(--line);border-radius:12px}
table{border-collapse:separate;border-spacing:0;width:100%}th,td{text-align:left;vertical-align:top;padding:9px 12px;border-bottom:1px solid var(--line)}
th{position:sticky;top:0;z-index:1;background:var(--surface-2);font-size:12px;color:var(--mute);font-weight:650;white-space:nowrap}
tbody tr:hover td{background:color-mix(in srgb,var(--accent) 5%,transparent)}tbody tr:last-child td{border-bottom:0}
td.lampcell{white-space:nowrap}td.stepcell{min-width:160px;font-weight:600;color:var(--ink-2)}td.detail{max-width:560px;overflow-wrap:anywhere}td.next{max-width:380px;color:var(--mute);overflow-wrap:anywhere}
tr.empty td{color:var(--mute);text-align:center;padding:22px}
dl.facts{display:grid;grid-template-columns:minmax(140px,240px) 1fr;gap:0;margin:0;border:1px solid var(--line);border-radius:12px;overflow:hidden}
dl.facts dt,dl.facts dd{margin:0;padding:8px 12px;border-bottom:1px solid var(--line)}dl.facts dt{color:var(--mute);background:var(--surface-2);font-size:13px}dl.facts dd{overflow-wrap:anywhere}
.links{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:10px}
.links a,.links span{display:block;border:1px solid var(--line);border-radius:12px;padding:10px 12px;text-decoration:none;color:var(--ink);background:var(--surface-2)}
.links a{border-left:3px solid var(--accent)}.links a:hover{border-color:var(--accent);background:var(--accent-soft)}
.links .miss{color:var(--mute);border-style:dashed}.links small{display:block;color:var(--mute);font-size:11px;overflow-wrap:anywhere;margin-top:2px}
.cmd{display:flex;gap:8px;align-items:flex-start;margin:8px 0}.cmd code{flex:1;background:var(--code);border:1px solid var(--line);border-radius:10px;padding:9px 12px;font:12px/1.55 "Cascadia Mono",Consolas,ui-monospace,monospace;overflow-wrap:anywhere}
.cmd button{flex:none;border:1px solid var(--line-2);background:var(--surface);color:var(--ink);border-radius:10px;padding:7px 12px;cursor:pointer;font:inherit;font-size:13px}.cmd button:hover{border-color:var(--accent);color:var(--accent)}
footer{color:var(--mute);font-size:12px;text-align:center;padding:0 16px 28px}
.toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%) translateY(20px);opacity:0;pointer-events:none;background:var(--ink);color:var(--bg);border-radius:10px;padding:8px 16px;font-size:13px;transition:opacity .2s,transform .2s;z-index:30}
.toast.show{opacity:1;transform:translateX(-50%) translateY(0)}
@media (max-width:1080px){.hero{grid-template-columns:minmax(0,1fr) minmax(0,1fr)}.hero .statecard{grid-column:1/-1}}
@media (max-width:640px){.sticky{position:static}.topbar{padding:10px 16px}.tabs{padding:6px 16px}main{padding:14px 16px 32px}.hero{grid-template-columns:minmax(0,1fr)}
dl.facts{grid-template-columns:1fr}.kpis{grid-template-columns:repeat(3,minmax(0,1fr))}.kpi .v{font-size:20px}.tablewrap{max-height:none;border:0}
#items thead{display:none}#items,#items tbody,#items tr,#items td{display:block;width:100%}#items tr{border:1px solid var(--line);border-radius:12px;padding:8px 10px;margin-bottom:8px}
#items td{border:none;padding:2px 0;max-width:none}#items td.lampcell{display:inline-block;width:auto;margin-left:8px}#items td:first-child{display:inline-block;width:auto}}
@media print{.sticky{position:static}.tabs,.iconbtn,.filters,.cmd button,.toast{display:none}body{background:#fff}.card,.panel,.kpi{box-shadow:none}.tablewrap{max-height:none;overflow:visible}}
'''

CLOSEOUT_JS = r'''
(function(){var d=document,root=d.documentElement,KEY='vrn2-closeout-theme';
function store(v){try{if(v){localStorage.setItem(KEY,v);}else{localStorage.removeItem(KEY);}}catch(e){}}
function saved(){try{return localStorage.getItem(KEY)||'';}catch(e){return '';}}
var tb=d.getElementById('theme'),names={'':'主題:跟系統','light':'主題:淺色','dark':'主題:深色'},order=['','light','dark'];
function setTheme(v){if(v){root.setAttribute('data-theme',v);}else{root.removeAttribute('data-theme');}if(tb){tb.textContent=names[v]||names[''];}}
setTheme(saved());if(tb){tb.addEventListener('click',function(){var cur=root.getAttribute('data-theme')||'',nx=order[(order.indexOf(cur)+1)%order.length];setTheme(nx);store(nx);});}
var toast=d.getElementById('toast'),tt=null;function say(t){if(!toast){return;}toast.textContent=t;toast.classList.add('show');clearTimeout(tt);tt=setTimeout(function(){toast.classList.remove('show');},1600);}
var own='全部',q='',rows=[].slice.call(d.querySelectorAll('#items tbody tr[data-owner]')),empty=d.getElementById('empty'),cnt=d.getElementById('shown');
function apply(){var n=0;rows.forEach(function(tr){var ok=(own==='全部'||tr.dataset.owner===own)&&(!q||tr.textContent.toLowerCase().indexOf(q)>=0);tr.style.display=ok?'':'none';if(ok){n++;}});
if(empty){empty.hidden=!(rows.length&&n===0);}if(cnt){cnt.textContent='顯示 '+n+' / '+rows.length+' 項';}}
d.querySelectorAll('.seg button').forEach(function(b){b.addEventListener('click',function(){own=b.dataset.owner;d.querySelectorAll('.seg button').forEach(function(x){x.classList.toggle('on',x===b);x.setAttribute('aria-pressed',x===b?'true':'false');});apply();});});
var s=d.getElementById('q');if(s){s.addEventListener('input',function(){q=s.value.toLowerCase();apply();});}
d.addEventListener('keydown',function(e){if(e.key==='/'&&s&&d.activeElement!==s&&!/input|textarea/i.test((d.activeElement||{}).tagName||'')){e.preventDefault();s.focus();}});
function copied(b){b.textContent='已複製';say('已複製到剪貼簿');setTimeout(function(){b.textContent='複製';},1500);}
d.querySelectorAll('.cmd button').forEach(function(b){b.addEventListener('click',function(){var t=b.parentNode.querySelector('code').textContent;
if(navigator.clipboard&&window.isSecureContext!==false){navigator.clipboard.writeText(t).then(function(){copied(b);},function(){fallback(t,b);});}else{fallback(t,b);}});});
function fallback(t,b){var a=d.createElement('textarea');a.value=t;a.setAttribute('readonly','');a.style.position='fixed';a.style.opacity='0';d.body.appendChild(a);a.select();try{d.execCommand('copy');copied(b);}catch(e){say('複製失敗:請手動選取');}d.body.removeChild(a);}
apply();})();
'''


def render_closeout(doc: dict) -> str:
    """收尾頁 HTML(v0116 新版面 · 單檔 · 不連外 · 一個 script · 淺 / 深 / 跟系統主題 · 手機寬度可讀 · 可列印)。"""
    c = doc["counts"]
    order = [o for o, _, _ in OWNERS]
    items = sorted(doc["items"], key=lambda i: (order.index(i["owner"]) if i["owner"] in order else 9, {"RED": 0, "YELLOW": 1}.get(i["lamp"], 2)))
    open_n = sum(1 for i in items if i["owner"] not in ("提醒", "彙總"))
    lamp_zh = {"RED": "紅", "YELLOW": "黃", "GREEN": "綠", "GRAY": "灰"}
    label_of = {o: label for o, label, _ in OWNERS}
    kpi = "".join('<div class="kpi"><div class="k">%s</div><div class="v %s">%s</div></div>' % (_h(k), cls, _h(v)) for k, v, cls in (
        ("綠燈", c.get("GREEN", 0), "green"), ("黃燈", c.get("YELLOW", 0), "yellow"), ("紅燈", c.get("RED", 0), "red"), ("灰燈", c.get("GRAY", 0), "gray"),
        ("待辦(不含提醒)", open_n, "red" if doc["state"] == "OPEN" else ("yellow" if open_n else "green")), ("耗時(秒)", "%.0f" % float(doc.get("elapsed_s") or 0), "")))
    total = sum(int(c.get(k, 0) or 0) for k in ("GREEN", "YELLOW", "RED", "GRAY"))
    stops, at = [], 0.0
    for k, var in (("GREEN", "--green"), ("YELLOW", "--yellow"), ("RED", "--red"), ("GRAY", "--gray")):
        share = 100.0 * int(c.get(k, 0) or 0) / total if total else 0.0
        if share:
            stops.append("var(%s) %.2f%% %.2f%%" % (var, at, at + share))
        at += share
    ring = ("conic-gradient(%s)" % ",".join(stops)) if stops else "conic-gradient(var(--line) 0 100%)"
    legend = "".join('<li><span class="lamp l-%s"></span>%s<b>%d</b></li>' % (k, z, int(c.get(k, 0) or 0)) for k, z in (("GREEN", "綠 · 過"), ("YELLOW", "黃 · 要看"), ("RED", "紅 · 要修"), ("GRAY", "灰 · 略過 / 資訊")))
    per = {o: (doc["per_owner"].get(o, 0) if o not in ("提醒", "彙總") else sum(1 for i in items if i["owner"] == o)) for o, _, _ in OWNERS}
    real_n = sum(per[o] for o in ("VRN-2", "VCGC", "人工", "資料源"))
    stack = "".join('<span class="c-%s" style="width:%.2f%%" title="%s %d"></span>' % (_h(o), 100.0 * per[o] / real_n, _h(label_of[o]), per[o]) for o in ("VRN-2", "VCGC", "人工", "資料源") if per[o]) if real_n else ""
    owner_cards = "".join('<div class="owner c-%s"><span class="n">%d</span><b>%s</b><p>%s</p></div>' % (_h(o), per[o], _h(label), _h(what)) for o, label, what in OWNERS if o != "彙總")
    buttons = '<button type="button" class="on" aria-pressed="true" data-owner="全部">全部 %d</button>' % len(items) + "".join(
        '<button type="button" aria-pressed="false" data-owner="%s">%s %d</button>' % (_h(o), _h(label), sum(1 for i in items if i["owner"] == o)) for o, label, _ in OWNERS if any(i["owner"] == o for i in items))
    rows = "".join('<tr data-owner="%s"><td><span class="chip c-%s">%s</span></td><td class="lampcell"><span class="lamp l-%s"></span>%s</td><td class="stepcell">%s</td><td class="detail">%s</td><td class="next">%s</td></tr>' % (
        _h(i["owner"]), _h(i["owner"]), _h(label_of.get(i["owner"], i["owner"])), _h(i["lamp"]), _h(lamp_zh.get(i["lamp"], i["lamp"])), _h(i["step"]), _h(i["detail"][:700]), _h(" · ".join(x for x in (i.get("why"), i.get("hint")) if x)[:500]))
        for i in items)
    rows += '<tr class="empty" id="empty" hidden><td colspan="5">沒有符合篩選 / 搜尋的項目</td></tr>' if items else '<tr class="empty"><td colspan="5">沒有待辦 · VRN-2 側這輪沒有要做的事</td></tr>'
    steps = doc.get("steps") or []
    flow = "".join('<li class="f-%s" title="%s"><span class="lamp l-%s"></span><span class="t">%s</span></li>' % (_h(s.get("lamp")), _h(str(s.get("detail") or "")[:240]), _h(s.get("lamp")), _h(s.get("step"))) for s in steps)
    facts = "".join("<dt>%s</dt><dd>%s</dd>" % (_h(k), _h(str(v)[:600])) for k, v in doc["facts"])
    links = "".join(('<a href="%s"><b>%s</b><small>%s</small></a>' % (_h(_uri(l["path"])), _h(l["label"]), _h(l["path"]))) if l["exists"] else
                    '<span class="miss"><b>%s</b><small>%s</small></span>' % (_h(l["label"]), _h(l["path"] or "(這輪沒有)")) for l in doc["links"])
    wb = next((l for l in doc["links"] if l["label"].startswith("Workbench") and l["exists"]), None)
    pb = next((l for l in doc["links"] if l["label"].startswith("貼回包") and l["exists"]), None)
    actions = (('<a class="primary" href="%s">開 Workbench</a>' % _h(_uri(wb["path"]))) if wb else "") + (('<a class="ghost" href="%s">貼回包(上傳給 AI)</a>' % _h(_uri(pb["path"]))) if pb else "")
    cmds = "".join('<div class="cmd"><code>%s</code><button type="button">複製</button></div>' % _h(x) for x in doc["next"])
    head = ("<!doctype html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<meta name=\"color-scheme\" content=\"light dark\"><title>VRN-2 收尾</title><style>%s</style></head><body>" % CLOSEOUT_CSS)
    top = ('<div class="sticky"><header class="topbar"><div class="brand"><span class="mark">V2</span><div><h1>VRN-2 收尾 · Close-out</h1><div class="sub">%s · %s · 套件 %s · 啟動器 %s</div></div></div>'
           '<div class="tools"><span class="pill s-%s">%s · %s</span><button type="button" class="iconbtn" id="theme">主題:跟系統</button></div></header>' % (
               _h(doc["at"]), _h(doc["tool"]), _h(Path(str(doc.get("package") or "")).name or "—"), _h(doc["launcher"]), _h(doc["state"]), _h(doc["state"]), _h(doc["state_label"])))
    nav = ('<nav class="tabs" aria-label="段落"><a href="#overview">總覽</a><a href="#flow">流程</a><a href="#todo">待辦</a><a href="#data">數據</a><a href="#files">檔案</a><a href="#next">下次怎麼跑</a></nav></div>')
    hero = ('<section class="hero" id="overview"><div class="card statecard"><div class="eyebrow">結案判定</div><div class="state s-%s"><b>%s · %s</b><span>%s</span></div>'
            '<p class="big">%s</p><div class="actions">%s</div><p class="note">%s</p></div>' % (
                _h(doc["state"]), _h(doc["state"]), _h(doc["state_label"]), _h(doc["state_text"]),
                _h(("VRN-2 側可結案(不是 OPEN)· " if doc["vrn2_closed"] else "VRN-2 側未結案 · ") + doc["state_text"]), actions, _h(doc["rule"]))
            + '<div class="card"><div class="eyebrow">這輪的燈號</div><div class="ringwrap"><div class="donut" style="background:%s"><div><span><b>%d</b><small>列結果</small></span></div></div><ul class="legend">%s</ul></div></div>' % (ring, total, legend)
            + '<div class="card"><div class="eyebrow">待辦依負責方 · %d 項</div><div class="stack" role="img" aria-label="負責方分布">%s</div><div class="owners">%s</div></div></section>' % (real_n, stack, owner_cards))
    body = ('<section class="kpis" aria-label="摘要">%s</section>' % kpi
            + '<section class="panel" id="flow"><header><h2>流程 · 每一步的燈</h2><span class="count">%d 列 · 游標移上去看內容</span></header><ol class="flow">%s</ol></section>' % (len(steps), flow or "<li>沒有步驟紀錄</li>")
            + '<section class="panel" id="todo"><header><h2>待辦(依負責方)</h2><span class="count" id="shown">%d 項</span></header><div class="filters"><div class="seg" role="group" aria-label="負責方">%s</div>'
              '<input id="q" type="search" placeholder="搜尋步驟 / 檔名 / 代號(按 / 直接搜尋)" aria-label="搜尋"></div>' % (len(items), buttons)
            + '<div class="tablewrap"><table id="items"><thead><tr><th>負責</th><th>燈</th><th>步驟</th><th>內容</th><th>為什麼是它 · 下一步</th></tr></thead><tbody>%s</tbody></table></div></section>' % rows
            + '<section class="panel" id="data"><header><h2>這輪的數據</h2></header><dl class="facts">%s</dl></section>' % (facts or "<dt>—</dt><dd>沒有(只跑了部分步驟)</dd>")
            + '<section class="panel" id="files"><header><h2>檔案</h2><span class="count">點了在本機開 · 虛線 = 這輪沒有</span></header><div class="links">%s</div></section>' % links
            + '<section class="panel" id="next"><header><h2>下次怎麼跑</h2></header>%s<p class="note">第 1 行整輪 · 第 2 行不重跑只修 + 除錯 + 打包 · 第 3 行只診斷 + 自測 · 跑完把貼回包 zip 上傳給 AI</p></section>' % cmds)
    return (head + top + nav + "<main>" + hero + body + "</main><footer>VRN-2 自己的收尾頁 · 只讀其他系統的檔 · 不連外 · %s</footer>" % _h(doc["tool"])
            + '<div class="toast" id="toast" role="status" aria-live="polite"></div><script>%s</script></body></html>' % CLOSEOUT_JS)
