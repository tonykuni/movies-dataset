"""VRN2_RoundAll_v0116.py = v0115(倉裡 vrn2_release_v0159)+ [進度] n/N · ①b 本行程點 VIA 加速器 · 收尾頁新版面 · 問句整行先印 · --launcher-args 去外圍引號。套件 v0158 不動。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v160")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0159/VRN2_RoundAll_v0115.py").read_text(encoding="utf-8")
ui = (W / "closeout_ui.py").read_text(encoding="utf-8")
s = src


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


# ---- 說明 ----
rep('"""VRN2_RoundAll v0115 — ', '"""VRN2_RoundAll v0116 — ')
rep("v0115(操作員 2026-10-31:「繼續下一步,依照你的建議進行」", '''v0116(操作員 2026-10-31:「所有 PS / PY 檔案都要導入加速器 · 貼到 PowerShell 上的指令也要加裝相同加速模組及自動更新進度條及百分比 ·
  模板應該在加速器裡面 · 不卡斷 · 加速完成指令自動跳出 HTML U/I · 人機互動介面現代化專業感要足夠」):
  · ①b 本行程點 VIA 加速器:套件裡的 VIA_ExecutionBridge_v0103(核對 VIA 工具鎖冊 · 跟啟動器同一支)→ 鎖版 VeritasCeleritas 把執行緒預算寫進環境 ·
    之後的子行程照繼承。沒有套件 / 鎖冊 / 這支 Python 缺套件 → 灰(照跑 · 啟動器自己會點);鎖冊對不上 → 黃(收尾頁 VCGC)· VRN2_NO_ACCEL=1 不點。
  · [進度] n/N:每一步依權重印一行;④ 跑啟動器把它的進度條(█░ 百分比)換算進來;⑤ 自動修逐項。PowerShell 的 VIA 加速器進度模板
    (supportive modules 的 VIA_PS_PyProgress_Module.ps1 · Invoke-VIAPython)照這一行畫真百分比、經過 / 剩約;子行程自己的 [進度] 行改標 [子步驟]
    才轉播(不搶總進度)。
  · 收尾頁新版面:頂列狀態 + 段落導覽 · 結案卡 · 燈號環圈 · 負責方堆疊條 · 流程(每一步的燈)· 待辦篩選 / 搜尋 / 空結果提示 · 檔案卡 ·
    一鍵複製提示框 · 淺 / 深 / 跟系統主題(記在這台瀏覽器)· 可列印。仍是單檔 · 不連外 · 一個 script。
  · ⑤ 舊資料庫要問整不整合時:問句先整行印出再等輸入(經 PowerShell 進度模板轉播也看得到)。
  · --launcher-args 每段去掉外圍引號(PowerShell 傳進來的 "--no-install" 以前會原樣交給啟動器 · 認不得)。
  · 套件仍是 vrn2_release_v0158/VRN2_Closeout_v0158.zip(不動 · 雜湊照釘)。自測 64 項(v0115 的 59 項 + 60 ~ 64)。

v0115(操作員 2026-10-31:「繼續下一步,依照你的建議進行」''')
rep("用法:python VRN2_RoundAll_v0115.py", "用法:python VRN2_RoundAll_v0116.py")
rep('VERSION = "v0115"', 'VERSION = "v0116"')
rep("import hashlib\nimport json\n", "import hashlib\nimport importlib.util\nimport json\n")
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0115.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0116.py"', 2)
rep('"VRN2_RoundAll_v0115.py" in html_', '"VRN2_RoundAll_v0116.py" in html_')

# ---- [進度] n/N ----
rep('''def jread(path: Path, default=None):''', '''# ===== v0116 [進度] n/N(PowerShell 的 VIA 加速器進度模板 Invoke-VIAPython 認這一行 · 畫真百分比)=====
PROGRESS_WEIGHT = {"package": 3, "preflight": 5, "selftest": 10, "run": 60, "fix": 10, "verify": 8, "report": 3, "closeout": 2, "pasteback": 1}
_BAR_LINE = re.compile(r"\\[[█░]{20}\\]\\s*(\\d{1,3})%\\s*·\\s*(.*)")              # 啟動器(base v0136)的進度條
_PROG_LINE = re.compile(r"^(\\s*)\\[進度\\]")                                   # 子行程自己的 [進度] 行 → 改標 [子步驟](不搶總進度)
_ANSI = re.compile(r"\\x1b\\[[0-9;]*m")


class Progress:
    """依權重算總進度:begin(步驟) 先把上一步算完 · part(比例) = 目前這一步做到哪 · end() = N/N · 同一行不重印。"""

    def __init__(self, keys):
        self.keys = [k for k in keys if k in PROGRESS_WEIGHT]
        self.total = sum(PROGRESS_WEIGHT[k] for k in self.keys) or 1
        self.done, self.cur, self.last = 0, None, None

    def emit(self, n, label):
        n = max(0, min(int(n), self.total))
        if (n, label) != self.last:
            self.last = (n, label)
            print("[進度] %d/%d %s" % (n, self.total, label), flush=True)

    def begin(self, key, label):
        if key not in self.keys:
            return
        if self.cur:
            self.done += PROGRESS_WEIGHT[self.cur]
        self.cur = key
        self.emit(self.done, label)

    def part(self, frac, label):
        if self.cur:
            self.emit(self.done + PROGRESS_WEIGHT[self.cur] * max(0.0, min(1.0, float(frac))), label)

    def end(self, label):
        if self.cur:
            self.done += PROGRESS_WEIGHT[self.cur]
            self.cur = None
        self.emit(self.total, label)


PROG = Progress(())


def prog_begin(key, label):
    PROG.begin(key, label)


def prog_part(frac, label):
    PROG.part(frac, label)


def launcher_progress(text: str) -> None:
    """v0116 ④ 啟動器的進度條(█░ 百分比 · 可能帶色碼)換算進總進度。"""
    m = _BAR_LINE.search(_ANSI.sub("", str(text)))
    if m:
        prog_part(int(m.group(1)) / 100.0, "④ 啟動器 %s%% · %s" % (m.group(1), m.group(2).strip()[:60]))


def launcher_args(text) -> list:
    """v0116 --launcher-args 每段去掉外圍引號(PowerShell 傳進來的 "--no-install")。"""
    return [a.strip("\\"'") for a in str(text or "").split() if a.strip("\\"'")]


def jread(path: Path, default=None):''')
rep('''def run_stream(cmd: list, cwd=None, env=None, timeout: int = 3600, prefix: str = "    ", quiet: bool = False, heartbeat: int = 60) -> tuple:''',
    '''def run_stream(cmd: list, cwd=None, env=None, timeout: int = 3600, prefix: str = "    ", quiet: bool = False, heartbeat: int = 60, on_line=None) -> tuple:''')
rep('''        text = line.rstrip("\\n")
        lines.append(text)
        if not quiet:
            print(prefix + text[:400], flush=True)''', '''        text = line.rstrip("\\n")
        lines.append(text)
        if on_line is not None:                                              # v0116 ④ 啟動器進度條 → 總進度
            try:
                on_line(text)
            except Exception:  # noqa: BLE001
                on_line = None                                               # 進度換算出錯 → 這次不再換算(子行程照跑 · 輸出照轉播)
        if not quiet:
            print(prefix + _PROG_LINE.sub(r"\\1[子步驟]", text, count=1)[:400], flush=True)''')
rep('''    cmd += [a for a in (args.launcher_args or "").split() if a]''', '''    cmd += launcher_args(args.launcher_args)                                # v0116 去外圍引號''')
rep('''    rc, lines = run_stream(cmd, cwd=pkg, env=env, timeout=int(args.run_timeout), prefix="  ")''',
    '''    rc, lines = run_stream(cmd, cwd=pkg, env=env, timeout=int(args.run_timeout), prefix="  ", on_line=launcher_progress)''')
rep('''    for key, desc in plan:
        lamp, detail = "GRAY", ""''', '''    for n_, (key, desc) in enumerate(plan):
        prog_part(n_ / len(plan), "⑤ 自動修 %d/%d · %s" % (n_ + 1, len(plan), desc[:50]))   # v0116
        lamp, detail = "GRAY", ""''')
rep('''                        answer = input("要整合嗎?[y = 整合 / n = 不要 / 其他 = 先不決定]:").strip().lower()''',
    '''                        print("要整合嗎?[y = 整合 / n = 不要 / 其他 = 先不決定](打字後按 Enter)", flush=True)   # v0116 問句整行先印(經 PowerShell 進度模板轉播看得到)
                        answer = input().strip().lower()''')

# ---- ①b 本行程點 VIA 加速器 ----
rep('''def step_run(pkg: Path, root: Path, vpy: str, state: dict, args) -> int:''', '''# ===== v0116 ①b 本行程點 VIA 加速器 =====
ACCEL_BRIDGE = "VIA_ExecutionBridge_v0103.py"
TOOL_LOCK_REL = Path("supportive modules") / "registry" / "VIA_ToolVersion_Lock_v0100.json"


def step_accel(root, pkg) -> dict:
    """v0116 RoundAll 本行程也點 VIA 加速器:套件裡的 VIA_ExecutionBridge_v0103(核對 VIA 工具鎖冊 · 跟啟動器同一支)→ 鎖版加速器把執行緒預算寫進環境 ·
    之後的子行程照繼承。只讀鎖冊、不改。沒有套件 / 鎖冊 / 這支 Python 缺套件 → 灰(照跑 · 啟動器自己會點);鎖冊對不上 → 黃(收尾頁 VCGC)。"""
    step = "①b VIA 加速器"
    if os.environ.get("VRN2_NO_ACCEL") == "1":
        return say("GRAY", step, "VRN2_NO_ACCEL=1 · 這輪 RoundAll 本行程不點(啟動器自己照點)")
    bridge = Path(pkg) / ACCEL_BRIDGE if pkg else None
    if not root or bridge is None or not bridge.is_file():
        return say("GRAY", step, "沒有套件裡的 %s(這輪沒取套件)· 不點 · 照跑(啟動器自己會點)" % ACCEL_BRIDGE)
    if not (Path(root) / TOOL_LOCK_REL).is_file():
        return say("GRAY", step, "VIA 工具鎖冊不在(%s)· 不點 · 照跑" % TOOL_LOCK_REL.as_posix())
    try:
        spec = importlib.util.spec_from_file_location("vrn2_roundall_execution_bridge", bridge)
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        state = module.activate(Path(root))
    except (ValueError, RuntimeError, KeyError) as error:                   # 鎖冊內容 / 加速器跟鎖冊對不上
        return say("YELLOW", step, "沒點亮 · 鎖冊對不上(%s: %s)· 照跑" % (type(error).__name__, str(error)[:300]),
                   "VIA 工具鎖冊與加速器是 VCGC 管的 → 交 VCGC 對鎖冊(VRN-2 不改鎖冊 · 不換工具)")
    except Exception as error:  # noqa: BLE001
        return say("GRAY", step, "沒點亮(%s: %s)· 照跑(啟動器用 VRN-2 Python 自己會點)" % (type(error).__name__, str(error)[:300]))
    modes = " · ".join("%s=%s" % (k, (v or {}).get("mode")) for k, v in sorted((state.get("verification") or {}).items()))
    applied = state.get("applied") or {}
    return say("GREEN", step, "%s · 鎖冊 %s · 執行緒 %s · 子行程照繼承" % (Path(str(state.get("accelerator") or "?")).name, modes or "—",
                                                               applied.get("VIA_ACCEL_ACTIVE_THREADS") or applied.get("OMP_NUM_THREADS") or "?"))


def step_run(pkg: Path, root: Path, vpy: str, state: dict, args) -> int:''')
rep('''    if "③b OCR" in step:                                                      # v0114 啟動器 v0158 不建 OCR venv · 不 pip''',
    '''    if step.startswith("①b VIA 加速器"):                                     # v0116 鎖冊 / 加速器是 VCGC 管的
        return "VCGC", "VIA 工具鎖冊與加速器對不上 → VCGC 對鎖冊(VRN-2 不改鎖冊 · 照跑)"
    if "③b OCR" in step:                                                      # v0114 啟動器 v0158 不建 OCR venv · 不 pip''')

# ---- main:總進度 + ①b ----
rep('''    print("══════ %s %s · %s · Python %s · %s ══════" % (NAME, VERSION, _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), sys.version.split()[0], " → ".join(s for s in STEPS if want[s])), flush=True)
    root, tried = find_root(args.root)''', '''    print("══════ %s %s · %s · Python %s · %s ══════" % (NAME, VERSION, _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), sys.version.split()[0], " → ".join(s for s in STEPS if want[s])), flush=True)
    global PROG
    PROG = Progress([s for s in STEPS if want[s]])                          # v0116 [進度] n/N(PowerShell 的 VIA 加速器進度模板照它畫真百分比)
    root, tried = find_root(args.root)''')
rep('''    pkg = None
    if want["package"]:
        pkg = guarded("① 套件", step_package, root, args)''', '''    pkg = None
    prog_begin("package", "① 取套件")
    if want["package"]:
        pkg = guarded("① 套件", step_package, root, args)''')
rep('''    vpy, vpy_how = guarded("② VRN-2 Python", vrn2_python, root, args.python, default=(sys.executable, "本行程(找 Python 時出例外)"))''',
    '''    guarded("①b VIA 加速器", step_accel, root, pkg)                          # v0116 本行程點 VIA 加速器(子行程照繼承)
    prog_begin("preflight", "② 診斷")
    vpy, vpy_how = guarded("② VRN-2 Python", vrn2_python, root, args.python, default=(sys.executable, "本行程(找 Python 時出例外)"))''')
rep('''    if want["selftest"] and pkg:
        guarded("③ 自測", step_selftest, pkg, vpy)
    if want["run"] and pkg and root:''', '''    prog_begin("selftest", "③ 全部自測")
    if want["selftest"] and pkg:
        guarded("③ 自測", step_selftest, pkg, vpy)
    prog_begin("run", "④ 跑啟動器")
    if want["run"] and pkg and root:''')
rep('''    if want["fix"] and root:
        guarded("⑤ 自動修", step_fix''', '''    prog_begin("fix", "⑤ 自動修")
    if want["fix"] and root:
        guarded("⑤ 自動修", step_fix''')
rep('''    if want["verify"] and root:
        guarded("⑪b 重跑獨立驗證", step_verify, root, pkg, vpy)
    report = {}''', '''    prog_begin("verify", "⑪b 重跑獨立驗證")
    if want["verify"] and root:
        guarded("⑪b 重跑獨立驗證", step_verify, root, pkg, vpy)
    prog_begin("report", "⑥ 除錯報告")
    report = {}''')
rep('''    zplan = pasteback_path() if want["pasteback"] else None
    page = step_closeout(root, summary, zplan) if (want["closeout"] and root) else None     # v0104 ⑧ 收尾頁(貼回包也帶它)
    zpath = guarded("⑦ 貼回包", step_pasteback, root, transcript, zplan) if want["pasteback"] else None''', '''    zplan = pasteback_path() if want["pasteback"] else None
    prog_begin("closeout", "⑧ 收尾頁")
    page = step_closeout(root, summary, zplan) if (want["closeout"] and root) else None     # v0104 ⑧ 收尾頁(貼回包也帶它)
    prog_begin("pasteback", "⑦ 貼回包")
    zpath = guarded("⑦ 貼回包", step_pasteback, root, transcript, zplan) if want["pasteback"] else None
    PROG.end("完成" + ((" · 收尾 %s" % page["state"]) if page else ""))''')

# ---- 收尾頁:流程資料 + 新版面 ----
rep('''"links": link_rows, "facts": facts,''', '''"links": link_rows,
           "steps": [{"step": r.get("step"), "lamp": r.get("lamp"), "detail": str(r.get("detail") or "")[:240]} for r in results], "facts": facts,''')
a = s.index('CLOSEOUT_CSS = """')
b = s.index("def build_closeout(")
u_css = ui[ui.index("CLOSEOUT_CSS = r'''"):ui.index("def render_closeout(")]
s = s[:a] + u_css.rstrip("\n") + "\n\n\n" + s[b:]
a = s.index("def render_closeout(doc: dict) -> str:")
b = s.index("def step_closeout(")
u_render = ui[ui.index("def render_closeout(doc: dict) -> str:"):]
s = s[:a] + u_render.rstrip("\n") + "\n\n\n" + s[b:]

# ---- 自測 60 ~ 64 ----
rep('''            and p59d == ("/import/only/python", "只看匯入(②)"))
''', '''            and p59d == ("/import/only/python", "只看匯入(②)"))
        buf60, keep60, saved_prog = io.StringIO(), sys.stdout, globals()["PROG"]
        sys.stdout = buf60
        try:
            globals()["PROG"] = Progress(["package", "fix", "report", "closeout", "pasteback"])
            prog_begin("package", "① 取套件")
            prog_begin("run", "④ 不在這輪計畫")
            prog_begin("fix", "⑤ 自動修")
            prog_part(0.5, "⑤ 一半")
            prog_part(0.5, "⑤ 一半")
            prog_begin("report", "⑥")
            prog_begin("closeout", "⑧")
            prog_begin("pasteback", "⑦")
            PROG.end("完成")
            globals()["PROG"] = Progress(["package", "run", "report"])
            prog_begin("package", "①")
            prog_begin("run", "④")
            launcher_progress("  [█████░░░░░░░░░░░░░░░]  25% · ③ 環境檢查")
            launcher_progress("\\x1b[33m[██████████░░░░░░░░░░]  50% · ⑤ 元件登記\\x1b[0m")
            launcher_progress("[計] 這不是進度條 12/40 30%")
        finally:
            sys.stdout = keep60
            globals()["PROG"] = saved_prog
        p60 = [l for l in buf60.getvalue().splitlines() if l.startswith("[進度]")]
        n60 = [tuple(int(x) for x in re.match(r"\\[進度\\] (\\d+)/(\\d+)", l).groups()) for l in p60]
        chk("60 [進度] n/N:依權重 · 這輪計畫外的步驟不算 · 同一行不重印 · 結束 = N/N · ④ 啟動器進度條(含色碼)換算進總進度 · 別的 n/N 不當進度",
            n60 == [(0, 19), (3, 19), (8, 19), (13, 19), (16, 19), (18, 19), (19, 19), (0, 66), (3, 66), (18, 66), (33, 66)] and p60[9].endswith("④ 啟動器 25% · ③ 環境檢查"))
        seen61, buf61, keep61 = [], io.StringIO(), sys.stdout
        sys.stdout = buf61
        try:
            rc61, lines61 = run_stream([sys.executable, "-c", "print('[進度] 3/11 ③ 環境檢查'); print('  [進度] 4/11 x'); print('ok')"], timeout=120, prefix="  ", on_line=seen61.append)
        finally:
            sys.stdout = keep61
        out61 = buf61.getvalue().splitlines()
        chk("61 子行程的 [進度] 行改標 [子步驟] 才轉播(PowerShell 進度模板只認 RoundAll 的總進度)· 原行照收(NEXT / 燈號照判)· on_line 每行都收到",
            rc61 == 0 and lines61 == ["[進度] 3/11 ③ 環境檢查", "  [進度] 4/11 x", "ok"] and seen61 == lines61 and "  [子步驟] 3/11 ③ 環境檢查" in out61
            and "    [子步驟] 4/11 x" in out61 and not any(re.match(r"^\\s*\\[進度\\]", l) for l in out61))
        acc = td / "acc62"
        (acc / "pkg").mkdir(parents=True)
        (acc / "root" / TOOL_LOCK_REL).parent.mkdir(parents=True)
        (acc / "root" / TOOL_LOCK_REL).write_text("{}", encoding="utf-8")
        buf62, keep62 = io.StringIO(), sys.stdout
        sys.stdout = buf62
        try:
            r62a = step_accel(acc / "root", acc / "pkg")
            (acc / "pkg" / ACCEL_BRIDGE).write_text("def activate(root):\\n    return {'accelerator': '/x/VeritasCeleritas_v1141.py', 'verification': {'accelerator': {'mode': 'EXACT'}, "
                                                     "'network': {'mode': 'EXACT'}}, 'applied': {'VIA_ACCEL_ACTIVE_THREADS': '6'}}\\n", encoding="utf-8")
            r62b = step_accel(acc / "root", acc / "pkg")
            (acc / "pkg" / ACCEL_BRIDGE).write_text("def activate(root):\\n    raise ValueError('accelerator tool content mismatch; not only CRLF/BOM')\\n", encoding="utf-8")
            r62c = step_accel(acc / "root", acc / "pkg")
            (acc / "pkg" / ACCEL_BRIDGE).write_text("import no_such_module_t62\\n", encoding="utf-8")
            r62d = step_accel(acc / "root", acc / "pkg")
            os.environ["VRN2_NO_ACCEL"] = "1"
            r62e = step_accel(acc / "root", acc / "pkg")
            os.environ.pop("VRN2_NO_ACCEL", None)
            r62f = step_accel(acc / "nolock", acc / "pkg")
        finally:
            sys.stdout = keep62
            os.environ.pop("VRN2_NO_ACCEL", None)
        o62 = owner_of(r62c, {})
        chk("62 ①b 本行程點 VIA 加速器:套件的 ExecutionBridge 點亮 → 綠(加速器 · 鎖冊 · 執行緒)· 沒有橋 / 鎖冊 / 缺套件 / VRN2_NO_ACCEL=1 → 灰照跑 · 鎖冊對不上 → 黃 · 收尾頁 VCGC",
            r62a["lamp"] == "GRAY" and r62b["lamp"] == "GREEN" and "VeritasCeleritas_v1141.py" in r62b["detail"] and "accelerator=EXACT" in r62b["detail"] and "執行緒 6" in r62b["detail"]
            and r62c["lamp"] == "YELLOW" and o62 is not None and o62[0] == "VCGC" and r62d["lamp"] == "GRAY" and r62e["lamp"] == "GRAY" and r62f["lamp"] == "GRAY")
        doc63 = {"tool": "VRN2_RoundAll v0116", "at": "2026-10-31T09:00:00", "state": "BLOCKED", "state_label": "等 VCGC", "state_text": "VRN-2 側沒有待修 · 1 項等 VCGC 決定 / 安裝", "vrn2_closed": True,
                 "per_owner": {"VCGC": 1, "人工": 2}, "counts": {"GREEN": 20, "YELLOW": 8, "RED": 0, "GRAY": 12}, "elapsed_s": 321.4, "package": "C:/x/VRN2_Closeout_v0158", "launcher": LAUNCHER,
                 "items": [{"owner": "VCGC", "lamp": "YELLOW", "step": "⑥ ⑥e MOPS", "detail": "DENY", "hint": "", "why": "VCGC 決定"},
                           {"owner": "人工", "lamp": "YELLOW", "step": "⑥ 四點原文核對", "detail": "OCR_PENDING 4", "hint": "", "why": ""},
                           {"owner": "人工", "lamp": "YELLOW", "step": "⑥ 輸出缺項", "detail": "<b>x</b>", "hint": "", "why": ""}],
                 "links": [{"label": "Workbench(四本冊)", "path": str(td / "wb.html"), "exists": True}, {"label": "貼回包(上傳給 AI)", "path": str(td / "pb.zip"), "exists": True},
                           {"label": "⑥e 擷取錯誤", "path": "", "exists": False}],
                 "steps": [{"step": "⓪ VIA 根", "lamp": "GREEN", "detail": "C:/x"}, {"step": "①b VIA 加速器", "lamp": "GREEN", "detail": "VeritasCeleritas_v1141.py"},
                           {"step": "⑥ ⑥e MOPS", "lamp": "YELLOW", "detail": "<i>DENY</i>"}],
                 "facts": [("① 套件", "ok")], "next": ["python a.py"], "rule": "BLOCKED 不是成功"}
        h63 = render_closeout(doc63)
        ring63 = re.search(r'class="donut" style="background:conic-gradient\\(([^"]+)\\)"', h63)
        chk("63 收尾頁新版面:頂列狀態 + 主題切換(淺 / 深 / 跟系統)· 結案卡 · 燈號環圈(依綠黃紅灰比例)· 負責方堆疊條 · 流程每一步的燈 · 待辦空結果提示 · 檔案卡 · 複製提示框 · 可列印 · 單檔不連外 · 一個 script · 內容跳脫",
            h63.count("<script>") == 1 and "http://" not in h63 and "https://" not in h63 and 'id="theme"' in h63 and "prefers-color-scheme:dark" in h63 and ":root[data-theme=dark]" in h63
            and 'class="pill s-BLOCKED"' in h63 and 'class="state s-BLOCKED"' in h63 and ring63 is not None and "var(--green) 0.00% 50.00%" in ring63.group(1)
            and "var(--yellow) 50.00% 70.00%" in ring63.group(1) and "var(--gray) 70.00% 100.00%" in ring63.group(1) and "var(--red)" not in ring63.group(1)
            and "<b>40</b><small>列結果</small>" in h63 and 'class="c-VCGC" style="width:33.33%"' in h63 and 'class="c-人工" style="width:66.67%"' in h63 and h63.count('<li class="f-') == 3
            and "&lt;i&gt;DENY&lt;/i&gt;" in h63 and "<i>DENY</i>" not in h63 and "&lt;b&gt;x&lt;/b&gt;" in h63 and 'id="empty" hidden' in h63 and 'id="toast"' in h63 and "@media print" in h63
            and '<a class="primary" href="' in h63 and ">貼回包(上傳給 AI)</a>" in h63 and '<span class="miss"><b>⑥e 擷取錯誤' in h63 and "localStorage" in h63 and "aria-pressed" in h63)
        src64 = Path(__file__).read_text(encoding="utf-8")
        chk("64 --launcher-args 去外圍引號(PowerShell 傳進來的 \\"--no-install\\")· 舊資料庫問句整行先印再等輸入 · 收尾頁 json 帶每一步的燈(流程)",
            launcher_args('"--no-install"') == ["--no-install"] and launcher_args("--no-install --x") == ["--no-install", "--x"] and launcher_args("'--plan' ''") == ["--plan"] and launcher_args(None) == []
            and ("input(" + '"要整合嗎') not in src64 and "answer = input().strip().lower()" in src64 and any(x.get("step") == "⑥ 輸出缺項" for x in cj.get("steps") or []) and 'id="flow"' in html_)
''')
assert "def render_closeout(doc: dict) -> str:" in s and s.count('CLOSEOUT_CSS = r\'\'\'') == 1 and s.count("CLOSEOUT_JS = r'''") == 1 and 'CLOSEOUT_CSS = """' not in s
assert "RoundAll_v0115" not in s[s.index("用法:"):].replace("vrn2_release_v0159/VRN2_RoundAll_v0115", "")
out = W / "new" / "VRN2_RoundAll_v0116.py"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0116 lines", s.count("\n"))
