"""v0160(冪等):RoundAll v0116(套件 v0158 不動)→ Handle-All v0108(VIA 加速器進度模板 · 跑完開收尾頁)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單。
vrn2_release_v0159 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v160"); rel = W / "release160"; rel.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r159 = json.loads((REPO / "vrn2_release_v0159/VRN2_Release_v0159.json").read_text(encoding="utf-8"))
want = r159["package"]["sha256"]
assert hashlib.sha256((REPO / "vrn2_release_v0158/VRN2_Closeout_v0158.zip").read_bytes()).hexdigest() == want
ra = (W / "new/VRN2_RoundAll_v0116.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'VERSION = "v0116"' in ra
(rel / "VRN2_RoundAll_v0116.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (Path("/home/user/vrn2_work/v159/release159/handleall_src.ps1")).read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b):
    global ha
    assert ha.count(a) == 1, a[:90]
    ha = ha.replace(a, b)


rep("$ProgressPreference = 'SilentlyContinue'", "$ProgressPreference = 'Continue'")
rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0159'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0160'")
rep("$F = 'VRN2_RoundAll_v0115.py'", "$F = 'VRN2_RoundAll_v0116.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep('''Write-Host "[VRN-2] Handle-All v0107 · PowerShell $($PSVersionTable.PSVersion) · 模式 $($Mode) · VIA $($R)" -ForegroundColor Yellow
''', '''Write-Host "[VRN-2] Handle-All v0108 · PowerShell $($PSVersionTable.PSVersion) · 模式 $($Mode) · VIA $($R)" -ForegroundColor Yellow
# v0108 VIA 加速器進度模板(VIA 自己的 supportive modules · 只載入不改):25 加速器點亮 · Invoke-VIAPython 真百分比 · 心跳 · 逾時不卡
$am = Join-Path $R 'supportive modules' 'VIA_PS_PyProgress_Module.ps1'
if (-not (Get-Command Invoke-VIAPython -ErrorAction SilentlyContinue) -and (Test-Path -LiteralPath $am)) { try { . $am } catch { Write-Host "[YELLOW] ⓪ VIA 加速器進度模組載入失敗($($_.Exception.Message))· 改用內建進度條" -ForegroundColor Yellow } }
$viaProg = [bool](Get-Command Invoke-VIAPython -ErrorAction SilentlyContinue)
$Stage = { param($p, $s) if (Get-Command Write-VIAProgress -ErrorAction SilentlyContinue) { Write-VIAProgress -Activity 'VRN-2 Handle-All v0108 · VIA 加速器' -Status $s -Percent $p -Id 10 } else { Write-Progress -Id 10 -Activity 'VRN-2 Handle-All v0108' -Status $s -PercentComplete $p } }
if ($viaProg) { Write-Host "[GREEN] ⓪ VIA 加速器進度模板 $($am)(Invoke-VIAPython · 25 加速器 · 真百分比 · 經過 / 剩約 · 心跳 · 逾時不卡)" -ForegroundColor Green } else { Write-Host "[YELLOW] ⓪ 找不到 VIA 加速器進度模板($($am))· 改用內建進度條(一樣照 RoundAll 的 [進度] n/N 畫真百分比)" -ForegroundColor Yellow }
& $Stage 5 '① 工具(git / python)'
''')
rep('''if ($IsWindows) {
$busy =''', '''& $Stage 10 '② 有沒有別的 VRN-2 在跑'
if ($IsWindows) {
$busy =''')
rep('''$bad = @(Get-ChildItem''', '''& $Stage 15 '③ Downloads 套件夾讀得到嗎'
$bad = @(Get-ChildItem''')
rep('''$g1 = "$env:VIA_NET_CONSENT"''', '''& $Stage 20 '③b VIA 網路工具同意閘(只讀)'
$g1 = "$env:VIA_NET_CONSENT"''')
rep("再貼那一行(操作員決定 · VRN-2 只讀 · 不代設)", "再貼那一行 · cmd 視窗是 set VIA_NET_CONSENT=YES 跟 set VIA_SCRAPE_CONSENT=YES(操作員決定 · VRN-2 只讀 · 不代設)")
rep('''$rcp = Get-ChildItem''', '''& $Stage 25 '④ 選模式'
$rcp = Get-ChildItem''')
rep('''$t = Join-Path ([IO.Path]::GetTempPath()) "vrn2_handleall_''', '''& $Stage 30 "⑤ 從 GitHub 取 $($F) · 核對 SHA-256"
$t = Join-Path ([IO.Path]::GetTempPath()) "vrn2_handleall_''')
rep('''Expand-Archive -LiteralPath $z -DestinationPath $t -Force''', '''$ProgressPreference = 'SilentlyContinue'; Expand-Archive -LiteralPath $z -DestinationPath $t -Force; $ProgressPreference = 'Continue\'''')
rep('''Write-Host "[計] ⑥ 執行 $($py) $($F) --root $($R) $($ra -join ' ')" -ForegroundColor DarkGray
& $py $dst --root $R @ra
$rc = $LASTEXITCODE
''', '''# v0108 RoundAll 不自己開頁(--no-open)· 跑完由這裡開收尾頁 · 逾時保底:整輪 5 小時 · 其他 2 小時($env:VRN2_TIMEOUT_SEC 可調 · VIA_PY_TIMEOUT_SEC=0 = 不設限)
$ra += '--no-open'
$to = ($Mode -eq 'full') ? 18000 : 7200
if ("$env:VRN2_TIMEOUT_SEC" -match '^[1-9]\\d*$') { $to = [int]$env:VRN2_TIMEOUT_SEC } elseif ("$env:VIA_PY_TIMEOUT_SEC" -eq '0') { $to = 0 }
Write-Host "[計] ⑥ 執行 $($py) $($F) --root $($R) $($ra -join ' ') · $($viaProg ? '經 VIA 加速器進度模板 Invoke-VIAPython' : '內建進度條') · 逾時保底 $(($to -gt 0) ? "$($to) 秒" : '不設限')(不卡斷)" -ForegroundColor DarkGray
& $Stage 35 "⑥ RoundAll · 模式 $($Mode) · 真百分比看下一條進度列"
$ub = $env:PYTHONUNBUFFERED
$env:PYTHONUNBUFFERED = '1'
if ($viaProg) { Invoke-VIAPython -Python $py -TimeoutSec $to -Rest (@($dst, '--root', $R) + $ra) } else { & $py $dst --root $R @ra 2>&1 | ForEach-Object { $l = "$_"; if ($l -match '^\\[進度\\]\\s*(\\d+)\\s*/\\s*(\\d+)\\s*(.*)$' -and [int]$Matches[2] -gt 0) { Write-Progress -Id 13 -Activity "VRN-2 · $($F)" -Status "$($Matches[1])/$($Matches[2]) · $($Matches[3])" -PercentComplete ([Math]::Min(100, [int](100 * [int]$Matches[1] / [int]$Matches[2]))) }; $l }; Write-Progress -Id 13 -Activity "VRN-2 · $($F)" -Completed }
$rc = $LASTEXITCODE
$env:PYTHONUNBUFFERED = $ub
if ($rc -eq 124 -and $viaProg) { Write-Host "[YELLOW] ⑥ RoundAll 逾 $($to) 秒被停(不卡斷保底 · 只停它自己那棵行程樹)· 真的要更久:先貼 `$env:VRN2_TIMEOUT_SEC = '28800' 再貼那一行" -ForegroundColor Yellow }
& $Stage 97 '⑦ 收尾 · 開收尾頁'
''')
rep('''if ($pb -and (Test-Path -LiteralPath $pb)) { Write-Host "  貼回包 $($pb)(上傳給 AI)" -ForegroundColor Green }
}''', '''if ($pb -and (Test-Path -LiteralPath $pb)) { Write-Host "  貼回包 $($pb)(上傳給 AI)" -ForegroundColor Green }
# v0108 跑完自動開收尾頁(預設瀏覽器 · 不擋這個視窗)· 這頁是 VRN-2 自己的 · 操作員 2026-10-31 指定要跳出 · 不要跳:$env:VRN2_NO_UI = '1'
$html = Join-Path $V2 'VRN2_CloseoutUI_latest.html'
$nopen = " · VIA_NO_OPEN=1 是 VIA 批次工具的零跳出;這頁是操作員 2026-10-31 指定跑完要跳出的 VRN-2 收尾頁 · 不要跳:先貼 `$env:VRN2_NO_UI = '1'"
if (Test-Path -LiteralPath $html) { if ("$env:VRN2_NO_UI" -eq '1') { Write-Host '  [計] ⑧ VRN2_NO_UI=1 · 不開收尾頁(上面那個檔自己開)' -ForegroundColor DarkGray } elseif (-not $IsWindows) { Write-Host '  [計] ⑧ 不是 Windows · 收尾頁自己開(上面那個檔)' -ForegroundColor DarkGray } else { try { Microsoft.PowerShell.Management\\Start-Process -FilePath $html -ErrorAction Stop; Write-Host "  [GREEN] ⑧ 已開收尾頁(預設瀏覽器 · 不擋這個視窗)$((\"$env:VIA_NO_OPEN\" -eq '1') ? $nopen : '')" -ForegroundColor Green } catch { Write-Host "  [YELLOW] ⑧ 收尾頁沒開成($($_.Exception.Message))· 自己開上面那個檔" -ForegroundColor Yellow } } }
}''')
rep('''Write-Host "[計] Handle-All 結束''', '''Write-Progress -Id 10 -Activity 'VRN-2 Handle-All v0108' -Completed
Write-Host "[計] Handle-All 結束''')
assert "exit" not in ha.replace("Exception", "")
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")

bt = Path("/home/user/vrn2_work/v159/release159/boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0159", "vrn2_release_v0160"), ("VRN2_HandleAll_v0107.md", "VRN2_HandleAll_v0108.md"), ("Handle-All v0107 SHA-256 OK", "Handle-All v0108 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0108_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0160/VRN2_HandleAll_v0108_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and "%" not in cmd_line
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0108(2026-10-31 · RoundAll v0116 · 套件 v0158 不動)

v0108 = v0107 + 操作員 2026-10-31「所有 PS / PY 檔案都要導入加速器 · 貼到 PowerShell 上的指令也要加裝相同加速模組及自動更新進度條及百分比 ·
模板應該在加速器裡面 · 不卡斷 · 加速完成指令自動跳出 HTML U/I · 人機互動介面現代化專業感要足夠」。

| 項目 | 現在 |
|---|---|
| 加速器(PowerShell) | 先載入 VIA 自己的 `supportive modules\\VIA_PS_PyProgress_Module.ps1`(它帶 `VIA_PS_Accel_Module.ps1` · 25 加速器點亮)· RoundAll 經 VIA 的 `Invoke-VIAPython` 跑 · 模組不在 → 內建進度條(黃燈說明) |
| 加速器(Python) | RoundAll v0116 ①b 本行程點 VIA 加速器(套件裡的 `VIA_ExecutionBridge_v0103` 核對 VIA 工具鎖冊 · 跟啟動器同一支)· 子行程照繼承 |
| 進度條 + 百分比 | 上面一條 = Handle-All 步驟(① ~ ⑦ 百分比)· 下面一條 = RoundAll 真百分比(`[進度] n/N` · 經過 · 剩約 · 30 秒沒輸出顯示心跳)· ④ 跑啟動器時把啟動器自己的進度條換算進來 |
| 不卡斷 | 逾時保底:整輪 5 小時 · 其他 2 小時(`$env:VRN2_TIMEOUT_SEC` 可調)· 逾時只停 RoundAll 自己那棵行程樹 · 結束碼 124 · 視窗不關 |
| 自動跳出 HTML U/I | 跑完自動開收尾頁(預設瀏覽器 · 不擋這個視窗)· 不要跳:`$env:VRN2_NO_UI = '1'` |
| 收尾頁 | 新版面:頂列狀態 · 結案卡 · 燈號環圈 · 負責方堆疊條 · 流程(每一步的燈)· 待辦篩選 / 搜尋 · 檔案卡 · 一鍵複製 · 淺 / 深 / 跟系統主題 · 可列印 · 單檔不連外 |
| 一支 Python | `VRN2_RoundAll_v0116.py`(SHA-256 `%s`)· 套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s` · 不動) |

## 先看:你開的是哪一種視窗?

- 提示字元是 `PS C:\\Users\\tonyk>`(前面有 **PS**)→ **PowerShell** → 用下面「PowerShell 7 視窗」那段。
- 提示字元是 `C:\\Users\\tonyk>`(前面沒有 PS)→ **cmd(命令提示字元)** → 用下面「cmd 視窗」那段。
  cmd 不認 `$env:…`、`$r=…` 這種 PowerShell 寫法:2026-10-31 桌機就是在 cmd 貼了 PowerShell 的行 →
  `The filename, directory name, or volume label syntax is incorrect.` / `'$r' is not recognized as an internal or external command`。

## PowerShell 7 視窗(%d 字元)

同意閘是操作員的決定(VRN-2 只讀、不代設):要經 VIA 網路工具抓共識,新開的視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`
(`VIA_NET_CONSENT` 桌機已是 YES)· 要整輪再加貼 `$env:VRN2_MODE = 'full'`(不貼 = auto)。然後貼:

```powershell
%s
```

## cmd 視窗(命令提示字元 · %d 字元)

```bat
set VIA_SCRAPE_CONSENT=YES
%s
```

第 1 行 = 同意閘(操作員決定 · 不想經網路工具抓就不貼)· 第 2 行 = 上面 PowerShell 那一行的編碼版(PowerShell 7 解碼後一字不差 · 一樣核對 SHA-256 才執行)。
要整輪(約 40 分鐘)才在第 2 行之前多貼一行 `set VRN2_MODE=full`(同一個 cmd 視窗會一直記著 · 改回 auto:`set VRN2_MODE=`)。
`'pwsh' is not recognized` → 開始功能表開「PowerShell 7」改用上面那段。

第一行應是 `[GREEN] boot: Handle-All v0108 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0116 `%s`)。

## 這次桌機貼下去會怎樣

- auto = repair(上一輪收據 `VRN2_Closeout_v0153.json`、輸出冊都在):⓪ 綠「VIA 加速器進度模板」→ 兩條進度列 → ①b 綠「VIA 加速器 VeritasCeleritas_v1141 · 鎖冊 accelerator=EXACT · network=EXACT」
  → ⑥f 已經是今天經網路工具抓的 → 不重抓 → 收尾 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2**(跟 05:30 一樣)→ **收尾頁自動跳出**。
- 整輪(`VRN2_MODE=full` · 約 40 分鐘):下面那條進度列跟著啟動器 ① ~ ⑫ 走 · 收據換成啟動器 v0158 · ③ 只檢查 · ③b 照用 OCR 隔離環境。
- BLOCKED / REVIEW / DATA_GAP 都不是成功;VCGC 的 closeout_lamp 才是 VCGC 驗收。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (ra_sha[:12], want[:12], len(tiny), tiny, len(cmd_line), cmd_line, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0108.md").write_text(md, encoding="utf-8", newline="\n")

ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0116.py(套件 v0158 不動 · 加速器 · 真百分比 · 收尾頁新版面)

`VRN2_RoundAll_v0116.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0115 +

| 改了什麼 | 說明 |
|---|---|
| ①b 本行程點 VIA 加速器 | 套件裡的 `VIA_ExecutionBridge_v0103`(核對 VIA 工具鎖冊 · 跟啟動器同一支)→ 鎖版 VeritasCeleritas 把執行緒預算寫進環境 · 子行程照繼承;沒有套件 / 鎖冊 / 缺套件 → 灰照跑;鎖冊對不上 → 黃(收尾頁 VCGC)· `VRN2_NO_ACCEL=1` 不點 |
| `[進度] n/N` | 每一步依權重印一行 · ④ 啟動器的進度條換算進來 · ⑤ 自動修逐項;PowerShell 的 VIA 加速器進度模板(`Invoke-VIAPython`)照它畫真百分比;子行程自己的 `[進度]` 改標 `[子步驟]` 才轉播 |
| 收尾頁新版面 | 頂列狀態 + 段落導覽 · 結案卡 · 燈號環圈 · 負責方堆疊條 · 流程 · 待辦篩選 / 搜尋 / 空結果提示 · 檔案卡 · 複製提示框 · 淺 / 深 / 跟系統主題 · 可列印 |
| 小修 | 舊資料庫問句整行先印再等輸入 · `--launcher-args` 每段去掉外圍引號(PowerShell 傳進來的 `"--no-install"`) |

自測 64 項(v0115 的 59 項 + 60 ~ 64)。套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s` · 本檔內已釘死)。**最省事:`VRN2_HandleAll_v0108.md` 的那一行(PowerShell / cmd 各一段)**。

```bat
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0116.py" --only package,fix,report,closeout,pasteback
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0116.py"
```

PowerShell 把 `%%USERPROFILE%%` 換成 `$env:USERPROFILE`。直接跑 python 時收尾頁照舊由 RoundAll 自己開(Windows · `--no-open` / `VRN2_NO_UI=1` 不開)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0116.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0116 + VRN2_HandleAll_v0108 (package v0158 unchanged)", "date": "2026-10-31",
        "trigger": "操作員 2026-10-31:cmd 視窗貼了 PowerShell 的行(語法錯)+「所有 PS / PY 檔案都要導入加速器 · 貼到 PowerShell 上的指令也要加裝相同加速模組及自動更新進度條及百分比 · 模板應該在加速器裡面 · 不卡斷 · 加速完成指令自動跳出 HTML U/I · 現代化專業感」",
        "package": {"name": "VRN2_Closeout_v0158.zip", "folder": "vrn2_release_v0158", "sha256": want, "changed": False},
        "fixes": {"RoundAll_v0116": "step 1b: the RoundAll process applies the VIA accelerator through the package's VIA_ExecutionBridge_v0103 (tool lock verified, same as the launcher; children inherit) · GRAY when no package / lock / module · YELLOW → VCGC on a lock mismatch · '[進度] n/N' weighted progress lines (launcher bar folded into step 4; step 5 per fix; child '[進度]' relabelled '[子步驟]') · closeout page redesign (sticky status bar + section nav · state card · lamp ring · owner stack · per-step flow · filter / search / empty state · file cards · copy toast · light / dark / system theme · print) · integrate question printed on its own line before input() · --launcher-args tokens lose surrounding quotes · selftest 64",
                  "HandleAll_v0108": "dot-sources VIA's own supportive modules/VIA_PS_PyProgress_Module.ps1 (VIA_PS_Accel_Module · 25 accelerators) and runs RoundAll through Invoke-VIAPython (real percent from '[進度] n/N', elapsed / ETA, heartbeat, timeout ceiling 5 h full / 2 h other, VRN2_TIMEOUT_SEC) · built-in progress fallback without the module · stage progress bar (Write-VIAProgress) · RoundAll --no-open, then the closeout page opens at the end (Start-Process, non-blocking; VRN2_NO_UI=1 skips) · consent hint names the cmd form",
                  "cmd_line": "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand <UTF-16LE base64 of the tiny line> · md tells PowerShell (PS prompt) from cmd (no PS) · cmd consent form: set VIA_SCRAPE_CONSENT=YES"},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0115.py", "sha256": r159["roundall"]["sha256"], "status": "superseded 2026-10-31 (no in-process accelerator / no [進度] lines / previous closeout layout); file kept in vrn2_release_v0159"}],
        "roundall": {"name": "VRN2_RoundAll_v0116.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0116.md"},
        "handleall": {"name": "VRN2_HandleAll_v0108.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0108_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "not_fixed_here": r159["not_fixed_here"], "results": {"status": "see VRN2_Verification_v0160.md"}}
(rel / "VRN2_Release_v0160.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
for k, v in (("ra_sha.txt", ra_sha), ("ha_sha.txt", ha_sha), ("bt_sha.txt", bt_sha)):
    (rel / k).write_text(v)
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
