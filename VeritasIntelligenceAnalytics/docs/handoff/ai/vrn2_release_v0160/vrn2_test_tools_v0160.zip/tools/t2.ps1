& {
. '/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules/VIA_PS_PyProgress_Module.ps1'
$env:VIA_ACCEL_LIT = '1'
$t0 = Get-Date
Invoke-VIAPython -Python python3 -TimeoutSec 2 -Rest @('-c', 'import time; print("[進度] 1/4 a", flush=True); time.sleep(30)')
"timeout rc=$LASTEXITCODE secs=$([int]((Get-Date) - $t0).TotalSeconds)"
$env:VIA_NO_OPEN = '1'
"proxy:"; Start-Process -FilePath ./page.html
"qualified:"; try { Microsoft.PowerShell.Management\Start-Process -FilePath /bin/true -Wait -ErrorAction Stop; 'real cmdlet ran /bin/true' } catch { "err $($_.Exception.Message)" }
(Get-Command Microsoft.PowerShell.Management\Start-Process).CommandType
}
