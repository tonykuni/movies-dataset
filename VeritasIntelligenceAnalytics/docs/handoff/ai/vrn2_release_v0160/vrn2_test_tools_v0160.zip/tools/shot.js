const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  for (const [name, w, h, scheme] of [['light', 1440, 1000, 'light'], ['dark', 1440, 1000, 'dark'], ['mobile', 390, 900, 'light']]) {
    const p = await b.newPage({ viewport: { width: w, height: h }, colorScheme: scheme });
    const errs = [];
    p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
    await p.goto('file://' + __dirname + '/closeout_sample.html');
    await p.waitForTimeout(300);
    await p.screenshot({ path: `shot_${name}.png`, fullPage: name !== 'mobile' });
    const sw = await p.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
    if (name === 'light') {
      await p.click('.seg button[data-owner="人工"]'); const vis = await p.evaluate(() => [...document.querySelectorAll('#items tbody tr[data-owner]')].filter(r => r.style.display !== 'none').length);
      await p.fill('#q', 'zzzz-no-match'); const emp = await p.evaluate(() => !document.getElementById('empty').hidden);
      await p.fill('#q', ''); await p.click('.seg button[data-owner="全部"]');
      await p.click('#theme'); const th1 = await p.evaluate(() => document.documentElement.getAttribute('data-theme'));
      await p.click('#theme'); const th2 = await p.evaluate(() => document.documentElement.getAttribute('data-theme'));
      await p.screenshot({ path: 'shot_toggle_dark.png', fullPage: false });
      console.log(name, 'scroll', sw, 'human rows', vis, 'empty shown', emp, 'theme', th1, th2, 'errors', errs.length, errs.slice(0,3));
    } else console.log(name, 'scroll', sw, 'errors', errs.length, errs.slice(0,3));
    await p.close();
  }
  await b.close();
})();
