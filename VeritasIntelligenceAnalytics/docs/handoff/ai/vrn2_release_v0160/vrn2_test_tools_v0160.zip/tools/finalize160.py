"""v0160 收尾:驗證紀錄 · 交接 v0161(從 v0160 抄 · 只增)· 放進倉 vrn2_release_v0160 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v160"); rel = W / "release160"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    return x.replace(str(W / "t160a"), "<sbx>").replace(SCR, "<scratch>").replace(SCR0, "<scratch0>")


R = json.loads((rel / "VRN2_Release_v0160.json").read_text(encoding="utf-8"))
st = [l for l in lines(W / "rall116_selftest.log") if re.search(r"^\[PASS\] 6[0-4] |^\[FAIL\]|--selftest · ", l)]
stv = [l for l in lines(W / "rall116_selftest_venv.log") if "--selftest · " in l]
ps = json.loads((W / "pscheck160.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny160.rc") if l.strip() and not l.startswith((" M ", "?? "))] + ["倉:e2e 沒寫任何檔(VCGC 自己的全景監看行程會寫它的冊 · 不提交 · 已還原)"]
pat = r"boot:|boot SHA|⓪ VIA 加速器進度|找不到 VIA 加速器進度|\[GREEN\] ①b|\[GRAY\] ①b|\[進度\]|逾 \d+ 秒被停|⑦ 這輪沒有寫出|===== 收尾|⑧ 不是 Windows|Handle-All 結束|PYPROG="
e2e = {n: [short(l)[:190] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)] for n in ("report", "auto", "nomod", "full", "tmo", "tamper")}
proxy = [l for l in lines(W / "proxy_check.log") if l.strip()]
R["results"] = {"selftest": st, "selftest_venv": stv, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "proxy_and_timeout": proxy,
                "ui": "closeout page rendered from the desktop 05:41 paste-back data and from the sandbox full run · Chromium 1440 / 390 px · light / dark / theme toggle · owner filter · search empty state · no console errors · no horizontal scroll",
                "not_run": "Windows-only branch of the closeout open (Start-Process on .html with the default browser) — container is Linux; the module-qualified Start-Process call reaching the real cmdlet past VIA's VIA_NO_OPEN proxy is checked in pwsh (proxy_and_timeout)"}
(rel / "VRN2_Release_v0160.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0160 驗證紀錄(2026-10-31 · RoundAll v0116 · Handle-All v0108 · 套件 v0158 不動)

## 1. 起因

操作員在 **cmd 視窗**貼了 PowerShell 的行(`$env:VIA_SCRAPE_CONSENT = 'YES'` → `The filename, directory name, or volume label syntax is incorrect.` ·
最短一行 → `'$r' is not recognized`)· 並下令:「所有 PS / PY 檔案都要導入加速器 · VDF 及任何向外擷取資料的工具都要加入網路工具 · 貼到 PowerShell 上的指令也要加裝
相同加速模組及自動更新進度條及百分比 · 模板應該在加速器裡面 · 不卡斷 · 加速完成指令自動跳出 HTML U/I · 人機互動介面現代化專業感要足夠」。

## 2. 修法

| 檔 | 版 | 內容 |
|---|---|---|
| `VRN2_HandleAll_v0108.md` | v0108 | 載入 VIA 自己的 `supportive modules\\VIA_PS_PyProgress_Module.ps1`(帶 `VIA_PS_Accel_Module.ps1` · 25 加速器)· RoundAll 經 `Invoke-VIAPython`(真百分比 · 經過 / 剩約 · 心跳 · 逾時保底 整輪 5 h / 其他 2 h · `VRN2_TIMEOUT_SEC`)· 模組不在 → 內建進度條 · Handle-All 步驟進度列(`Write-VIAProgress`)· RoundAll `--no-open` → 跑完這裡開收尾頁(`Microsoft.PowerShell.Management\\Start-Process` · 不擋視窗 · `VRN2_NO_UI=1` 不開)· cmd 一行 |
| `VRN2_RoundAll_v0116.py` | v0116 | ①b 本行程點 VIA 加速器(套件的 `VIA_ExecutionBridge_v0103` · 核對工具鎖冊)· `[進度] n/N`(權重 · ④ 啟動器進度條換算 · ⑤ 逐項 · 子行程 `[進度]` 改標 `[子步驟]`)· 收尾頁新版面 · 問句整行先印 · `--launcher-args` 去外圍引號 · 自測 64 |

套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip` 不動(`%s`)。RoundAll v0116 `%s` · Handle-All 一行 `%s` · 開機檔 `%s` · 最短一行 %d 字元 · cmd 一行 %d 字元。

## 3. 測試

```text
%s
%s
%s
e2e 結束碼:%s
```

VCGC 全景骨架卡(`CGC_MDL158 … read`):RoundAll v0116 報 10 項 SWALLOW,跟 v0115 一樣多(進度掛勾出錯改成「不再換算」,不是吞掉)。

## 4. 最短一行 e2e(桌機 v0153 狀態沙盒 · 倉的 VIA 網路工具 + VIA PS 加速器進度模組 · 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設)

```text
%s
```

- auto(repair)/ full:⓪ 綠(VIA 加速器進度模板)· ①b 綠(`VeritasCeleritas_v1141 · accelerator=EXACT · network=EXACT`)· full 的 `[進度]` 跟著啟動器 0 → 100%% 走 · `VIA_PYPROG_LAST` = 100%%。
- nomod(模組拿掉):⓪ 黃 · 內建進度條照 `[進度]` 畫。 tmo(`VRN2_TIMEOUT_SEC=5`):5 秒停 · 結束碼 124 · 視窗不卡。 tamper:開機檔被改 → 不執行。
- 沙盒收尾是 BLOCKED(沙盒自己的 VCGC 項 · 跟桌機不同)· 收尾頁在 Linux 印「不是 Windows · 自己開」。

## 5. 開頁代理與逾時(pwsh)

```text
%s
```

VIA 的 `VIA_PS_Accel_Module.ps1` 在 `VIA_NO_OPEN=1` 時把 `Start-Process` / `Invoke-Item` 開 .html 的動作擋掉(桌機那行 `[VIA_NO_OPEN] 抑制跳出` 就是它)。
收尾頁是操作員指定要跳出的 VRN-2 自己的頁 → Handle-All 用模組全名呼叫真的 `Start-Process`,同時印出 VIA_NO_OPEN 的說明與 `VRN2_NO_UI=1` 關法(只開這一頁)。

## 6. 收尾頁 U/I

用桌機 05:41 貼回包的收尾資料、沙盒整輪的真收尾頁各渲染一次:Chromium 1440 / 390 寬 · 淺 / 深色 · 主題切換 · 負責方篩選 · 搜尋空結果 · 無主控台錯誤 · 無橫向捲動。

## 7. 桌機預期

PowerShell 7 視窗(`PS C:\\…>`):新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'` 再貼最短一行;cmd 視窗(`C:\\…>`):`set VIA_SCRAPE_CONSENT=YES` 再貼 cmd 一行。
auto = repair → ⓪ 綠 · ①b 綠 · 兩條進度列 → **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2**(⑥f 今天已經經網路工具抓過 · 不重抓)→ 收尾頁自動跳出(新版面)。
""" % (R["package"]["sha256"][:12], R["roundall"]["sha256"][:12], H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], H["cmd_line_chars"],
       "\n".join(st), "venv(有 PyMuPDF):" + " ".join(stv), pparse, " · ".join(rc), "\n".join("[%s] " % n + l for n in e2e for l in e2e[n]), "\n".join(proxy))
(rel / "VRN2_Verification_v0160.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0160.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0115 + VRN2_HandleAll_v0107 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0116 + VRN2_HandleAll_v0108 · 2026-10-31(PowerShell 指令導入 VIA 加速器進度模板 · 真百分比 · 不卡斷 · "
        "跑完自動跳出收尾頁 · 收尾頁新版面 · cmd 一行;套件 v0158 不動)")
src = "\n".join(L)
once("> **本輪(v0159 · 小輪)**",
     "> **本輪(v0160)**:操作員在 cmd 視窗貼了 PowerShell 的行(語法錯)+ 令「所有 PS / PY 都導入加速器 · 貼到 PowerShell 的指令也要相同加速模組 + 自動更新進度條 / 百分比(模板在加速器裡)· 不卡斷 · "
     "完成自動跳出 HTML U/I · 現代化專業感」。**Handle-All v0108**:載入 VIA 的 `VIA_PS_PyProgress_Module.ps1`(25 加速器)· RoundAll 經 `Invoke-VIAPython`(真百分比 · 心跳 · 逾時保底 5 h / 2 h)· "
     "步驟進度列 · 跑完自動開收尾頁(`VRN2_NO_UI=1` 不開)· cmd 一行(`pwsh -EncodedCommand` · %d 字元)。**RoundAll v0116**:①b 本行程點 VIA 加速器(工具鎖冊核對)· `[進度] n/N` · "
     "收尾頁新版面 · 自測 64。套件 v0158 不動(VerbatimVerifier v0105 經 v0104 的 main 已走加速器橋 · 不為加註記出新套件)。\n"
     "> **本輪(v0159 · 小輪)**" % H["cmd_line_chars"])
once("| **VRN2_HandleAll_v0107.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0107** | `vrn2_release_v0159` |",
     "| **VRN2_HandleAll_v0108.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0108** | `vrn2_release_v0160` | 一行版 `%s` · 開機檔 `%s` | **新**(VIA 加速器進度模板 · 跑完開收尾頁 · 最短一行 %d 字元 · cmd 一行 %d 字元)|\n"
     "| **VRN2_RoundAll_v0116.py**(發行夾 · 一支入口 · 不在套件內)| **v0116** | `vrn2_release_v0160` | `%s` | **新**(①b 加速器 · [進度] n/N · 收尾頁新版面 · 自測 64 項)|\n"
     "| **VRN2_HandleAll_v0107.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0107** | `vrn2_release_v0159` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], H["cmd_line_chars"], R["roundall"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0115.py**(發行夾 · 一支入口 · 不在套件內)| **v0115** | `vrn2_release_v0159` | `92ea3b3e4b1f` | **新**(",
     "| **VRN2_RoundAll_v0115.py**(發行夾 · 一支入口 · 不在套件內)| **v0115** | `vrn2_release_v0159` | `92ea3b3e4b1f` | 被 v0116 取代(沒有本行程加速器 / 進度行 · 舊收尾頁版面)· (")
once("| 0 | **(v0159)**",
     "| 0 | **(v0160)** 先看視窗:`PS C:\\\\…>` = PowerShell → `$env:VIA_SCRAPE_CONSENT='YES'` 再貼 `vrn2_release_v0160/VRN2_HandleAll_v0108.md` 的最短一行(%d 字元);`C:\\\\…>` = cmd → `set VIA_SCRAPE_CONSENT=YES` 再貼 cmd 一行 → "
     "repair 預期 BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2 · 兩條進度列 · 收尾頁自動跳出 | 貼回 |\n"
     "| 0 | **(v0159)**" % H["tiny_line_chars"])
once("**v0159(2026-10-31)**:", "**v0160(2026-10-31)**:PowerShell 指令導入 VIA 加速器進度模板(真百分比 · 不卡斷)· RoundAll 本行程點加速器 · 跑完自動跳出收尾頁 · 收尾頁新版面 · cmd 一行;套件 v0158 不動。\n\n**v0159(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0160)** **進度百分比用 VIA 加速器的模板**:PowerShell 端跑 python 一律經 VIA 的 `Invoke-VIAPython`(`supportive modules\\\\VIA_PS_PyProgress_Module.ps1` · 只載入不改);"
     "Python 端印 `[進度] n/N 說明`(它只認這種 n/N)· 子行程自己的 `[進度]` 要改標再轉播,不然會搶走總進度。長工一定給 `-TimeoutSec`(預設 1800 秒會把整輪砍掉)。\n"
     "- **(v0160)** **VIA_NO_OPEN 是 VIA 批次工具的零跳出**:VIA 的 PS 加速器模組會把 `Start-Process` / `Invoke-Item` 開 .html 擋掉;操作員指定要跳出的 VRN-2 收尾頁用模組全名呼叫,並印出說明與 `VRN2_NO_UI=1` 關法。\n"
     "- **(v0160)** **先分清視窗**:提示字元有 `PS` = PowerShell;沒有 = cmd。cmd 不認 `$env:` / `$r=`;給 cmd 的是 `set X=Y` + `pwsh -EncodedCommand`(md 兩段都要有)。\n\n")
(REPO / "VRN2_Handover_v0161.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0160"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0116.py", "VRN2_RoundAll_v0116.md", "VRN2_HandleAll_v0108.md", "VRN2_HandleAll_v0108_boot.txt", "VRN2_Release_v0160.json", "VRN2_Verification_v0160.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    z.writestr(zi, data.replace(str(W / "t160a").encode(), b"<sbx>").replace(SCR.encode(), b"<scratch>").replace(SCR0.encode(), b"<scratch0>"))


with zipfile.ZipFile(D / "logs_v0160.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "rall116_selftest.log", W / "rall116_selftest_venv.log", W / "pscheck160.log", W / "tiny160.rc", W / "proxy_check.log"] + sorted(W.glob("tiny_*.log")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0160.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("closeout_ui.py", "mk_roundall116.py", "build160.py", "finalize160.py", "e2e160.sh", "t/t2.ps1", "ui/shot.js")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0161", src.count("\n"))
