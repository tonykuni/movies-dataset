const { chromium } = require('playwright');
(async () => {
  const [, , file] = process.argv;
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1366, height: 900 } });
  await p.goto('file://' + file);
  await p.waitForTimeout(800);
  const info = await p.evaluate(() => {
    const path = el => { const a = []; while (el && el !== document.body) { a.unshift(el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (el.className && typeof el.className === 'string' ? '.' + el.className.split(' ').filter(Boolean).join('.') : '')); el = el.parentElement; } return a.join(' > '); };
    const q = s => Array.from(document.querySelectorAll(s));
    const tabs = document.querySelector('.tabs');
    const sel = q('select').map(s => path(s)).slice(0, 4);
    const outf = document.querySelector('aside .outfolder');
    const kv = document.querySelector('aside .w9-kv');
    const ho = q('.box').find(b => /交接快照/.test(b.textContent));
    const cards = q('.cards .box').map(c => { const v = c.querySelector('div'); return { w: c.clientWidth, sw: v ? v.scrollWidth : 0, cw: v ? v.clientWidth : 0, t: (v ? v.textContent : '').slice(0, 30) }; });
    const nums = q('#dsBody td').slice(0, 400).map(td => td.textContent.trim()).filter(t => /^-?\d+\.\d{2}$/.test(t)).slice(0, 8);
    return { tabsPath: tabs ? path(tabs) : null, tabParent: tabs ? path(tabs.parentElement) : null, sel, outfolder: outf ? outf.innerHTML.slice(0, 900) : null,
      kv: kv ? kv.outerHTML.slice(0, 500) : null, handover: ho ? ho.innerHTML.slice(0, 700) : null, cards, nums,
      asideBtns: q('aside a.action, aside button').map(x => x.textContent.trim()).slice(0, 30), mainSections: q('main > *').map(path).slice(0, 12) };
  });
  console.log(JSON.stringify(info, null, 1));
  await b.close();
})();
