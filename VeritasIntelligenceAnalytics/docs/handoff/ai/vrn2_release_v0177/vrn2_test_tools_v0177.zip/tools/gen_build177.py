"""從 build176.py 生 build177.py(套件 v0177 · RoundAll v0133 · Handle-All v0125)。"""
import re
from pathlib import Path

s = Path("/home/user/vrn2_work/v176/build176.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep(s.split('"""', 2)[1], "v0177(冪等):套件 VRN2_Closeout_v0177.zip(啟動器 v0177 · runtime v0166 = v0165 + 管理器 v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110 · VerbatimVerifier v0106)\n"
    "→ RoundAll v0133(填套件雜湊)→ Handle-All v0125(指到 v0133 · 上一輪 ⑦ 沒跑完 → 自動改整輪)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0177)。vrn2_release_v0176 及更早不動。")
rep('W = Path("/home/user/vrn2_work/v176"); pkg, rel = W / "pkg176", W / "release176"', 'W = Path("/home/user/vrn2_work/v177"); pkg, rel = W / "pkg177", W / "release177"')
rep('PREV = Path("/home/user/vrn2_work/v175/release175")', 'PREV = Path("/home/user/vrn2_work/v176/release176")')
rep('(REPO / "vrn2_release_v0175/VRN2_Release_v0175.json")', '(REPO / "vrn2_release_v0176/VRN2_Release_v0176.json")', 2)
rep('(pkg / "VRN2_Runtime_v0165.json")', '(pkg / "VRN2_Runtime_v0166.json")')
rep('(pkg / "VRN2_Runtime_v0165.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0164.zip "', '(pkg / "VRN2_Runtime_v0166.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0165.zip "')
rep('rt["retained_members"] == 207 and rt["new_members"] == ["VRN2_BookSource_v0101.py", "VRN2_OutputStore_v0104.py"]',
    'rt["retained_members"] == 209 and rt["new_members"] == ["VRN_SystemManager_v0260.py", "VRN2_BookSource_v0102.py", "VRN2_OutputStore_v0105.py", "VRN2_Workbench_v0110.py", "VRN2_VerbatimVerifier_v0106.py"]')
rep('pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0176.py", "VRN2_Runtime_v0165.zip", "VRN2_Runtime_v0165.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",\n          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]',
    'pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0177.py", "VRN2_Runtime_v0166.zip", "VRN2_Runtime_v0166.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",\n          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_VerbatimVerifier_v0106.py", "VRN2_OCRBridge_v0101.py"]')
rep('    if n not in ("ActivateVRN-2_v0176.py", "VRN2_Runtime_v0165.zip", "VRN2_Runtime_v0165.json"):', '    if n not in ("ActivateVRN-2_v0177.py", "VRN2_Runtime_v0166.zip", "VRN2_Runtime_v0166.json", "VRN2_VerbatimVerifier_v0106.py"):')
rep("# 其他成員跟 v0175 逐位元組相同", "# 其他成員跟 v0176 逐位元組相同")
i0 = s.index('files["README.txt"] = ('); i1 = s.index('files["VALIDATION_RESULT.json"]')
s = s[:i0] + '''files["README.txt"] = ("VRN2_Closeout_v0177 — VRN-2 closeout package (2026-11-04 · page fragments out of scope · thousands separators · Workbench v0110 · accelerator 100%)\\n\\n"
  "Entry: python ActivateVRN-2_v0177.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0133.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0125.md (same release folder).\\n"
  "Runtime: VRN2_Runtime_v0166.zip = v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110 + VRN2_VerbatimVerifier_v0106.\\n\\n"
  "v0177 (desktop 2026-11-03 22:28: step 7 stopped at its 7200-second cap — 200 page_NNNN[_hash].pdf single pages from the picked folder were in the stock scope):\\n"
  " - manager v0260: page_NNNN[_hash].pdf is a page split out of another file, not a report -> not copied to scope_in (source untouched, counted).\\n"
  " - BookSource v0102: TOPIC & SUMMARY numbers as 1,234.50 and the upside as 23.45% (numeric book columns unchanged). OutputStore v0105: same as v0104.\\n"
  " - Workbench v0110: same 10.45 px in both panels, every button 28 px, card values fit, matrices (left counts, output folder, handover), two-decimal\\n"
  "   numbers with thousands separators, a read-only view copy of the extract filter; the tab bar is untouched.\\n"
  " - VerbatimVerifier v0106: accelerator marker (the last active VRN-2 module without it).\\n"
  "v0176: BookSource v0101 (four points without leading bullets · title format · adjusted upside) · OutputStore v0104. v0163: no MOPS.\\n"
  "Verification: see VRN2_Verification_v0177.md. Hashes: PACKAGE_SHA256.json.\\n").encode("utf-8")
''' + s[i1:]
s = s.replace("VRN2_Verification_v0176.md", "VRN2_Verification_v0177.md")
rep('manifest = {"system": "VRN-2", "version": "v0176",', 'manifest = {"system": "VRN-2", "version": "v0177",')
rep('zpr = rel / "VRN2_Closeout_v0176.zip"', 'zpr = rel / "VRN2_Closeout_v0177.zip"')
rep('zipfile.ZipInfo("VRN2_Closeout_v0176/" + n, date_time=(2026, 11, 3, 14, 0, 0))', 'zipfile.ZipInfo("VRN2_Closeout_v0177/" + n, date_time=(2026, 11, 4, 2, 0, 0))')
rep('(W / "new/VRN2_RoundAll_v0132.py")', '(W / "new/VRN2_RoundAll_v0133.py")')
rep("'PACKAGE = \"VRN2_Closeout_v0176\"' in ra and 'VERSION = \"v0132\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176\"' in ra",
    "'PACKAGE = \"VRN2_Closeout_v0177\"' in ra and 'VERSION = \"v0133\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177\"' in ra")
rep('(rel / "VRN2_RoundAll_v0132.py").write_text(ra', '(rel / "VRN2_RoundAll_v0133.py").write_text(ra')
m0 = re.search(r'^rep\("\$P = ', s, re.M).start()
m1 = s.index("ha_line = join(ha)")
s = s[:m0] + '''rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177'")
rep("$F = 'VRN2_RoundAll_v0132.py'", "$F = 'VRN2_RoundAll_v0133.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0124", "Handle-All v0125", ha.count("Handle-All v0124"))
rep("套件 v0176 裝在新夾 VRN2_Closeout_v0176", "套件 v0177 裝在新夾 VRN2_Closeout_v0177")
rep("取套件 v0176 → 診斷 → 全部自測 → 跑啟動器 v0176(", "取套件 v0177 → 診斷 → 全部自測 → 跑啟動器 v0177(管理器 v0260 頁面分割檔不進個股範圍 · ")
rep("⑬a BookSource v0101(四點去開頭符號 · 主題與摘要 = Name(YFinance Ticker, 評等) - 原文標題 · 評價點用調整後目標價 ÷ 調整後收盤 · 含 v0100 SOURCE / BROKER_EN)· 增量庫 OutputStore v0104(不重複追加 · 舊列就地整理 · 含 v0103 補欄)· Workbench v0109(",
    "⑬a BookSource v0102(主題與摘要數字千分位兩位小數 · 含 v0101 四點去符號 / 標題格式 / 調整後上漲空間 · v0100 SOURCE / BROKER_EN)· 增量庫 OutputStore v0105(不重複追加 · 舊列就地整理)· Workbench v0110(左右同字級 · 按鍵同高 · 矩陣化 · 檢視副本 · 千分位 · 含 v0109 ")
rep("repair = '取套件 v0176 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 四點去開頭符號 · 主題與摘要新格式 · 評價點上漲空間 = 調整後目標價 ÷ 調整後收盤 − 1 ·",
    "repair = '取套件 v0177 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 主題與摘要數字千分位兩位小數 · 四點去開頭符號 · 評價點上漲空間 = 調整後目標價 ÷ 調整後收盤 − 1 · Workbench v0110 ·")
rep("只重跑 ⑪ 獨立驗證(套件 v0176 的", "只重跑 ⑪ 獨立驗證(套件 v0177 的")
rep("if ($Mode -eq 'auto') { $Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full';", "$wasAuto = ($Mode -eq 'auto'); if ($Mode -eq 'auto') { $Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full';")
i60 = ha.index("if ($Mode -ne 'full' -and -not $haveOut) {")
e60 = ha.index("\\n", i60) + 1
ha = ha[:e60] + ("if ($wasAuto -and $Mode -eq 'repair' -and $rcp) { try { $rj = Get-Content -LiteralPath $rcp.FullName -Raw -Encoding utf8 | ConvertFrom-Json; "
                 "$s7 = @($rj.steps | Where-Object { \\"$($_.step)\\" -like '⑦ 啟動*' })[0]; $s8 = @($rj.steps | Where-Object { \\"$($_.step)\\" -like '⑧ 完成判定*' })[0]; "
                 "if (($s7 -and \\"$($s7.detail)\\" -match '(^|[^a-z])rc [1-9]') -or ($s8 -and \\"$($s8.detail)\\" -match '本輪未寫出完成判定|⑦ 沒跑完')) { Write-Host \\"[YELLOW] ④ 上一輪 ⑦ 沒跑完($(\\"$($s7.detail)\\".Trim()))→ repair 補不了 · 改跑整輪(套件 v0177 起頁面分割檔不進個股範圍)\\" -ForegroundColor Yellow; $Mode = 'full' } } catch { Write-Host \\"[GRAY] ④ 讀上一輪收據沒成($($_.Exception.Message))· 照 $($Mode)\\" -ForegroundColor DarkGray } }\\n") + ha[e60:]
left = [l for l in ha.split("\\n") if re.search(r"Handle-All v0124|v0132[.]py|release_v0176|套件 v0176|Closeout_v0176", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha and "$wasAuto -and $Mode -eq 'repair'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
''' + s[m1:]
rep('("vrn2_release_v0175", "vrn2_release_v0176"), ("VRN2_HandleAll_v0123.md", "VRN2_HandleAll_v0124.md"), ("Handle-All v0123 SHA-256 OK", "Handle-All v0124 SHA-256 OK")',
    '("vrn2_release_v0176", "vrn2_release_v0177"), ("VRN2_HandleAll_v0124.md", "VRN2_HandleAll_v0125.md"), ("Handle-All v0124 SHA-256 OK", "Handle-All v0125 SHA-256 OK")')
rep('(rel / "VRN2_HandleAll_v0124_boot.txt")', '(rel / "VRN2_HandleAll_v0125_boot.txt")')
rep("vrn2_release_v0176/VRN2_HandleAll_v0124_boot.txt", "vrn2_release_v0177/VRN2_HandleAll_v0125_boot.txt")
i0 = s.index('md = """'); i1 = s.index('print("package"')
s = s[:i0] + Path("/home/user/vrn2_work/v177/build177_tail.py").read_text(encoding="utf-8") + s[i1:]
Path("/home/user/vrn2_work/v177/build177.py").write_text(s, encoding="utf-8")
print("ok")
