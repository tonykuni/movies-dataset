const { chromium } = require('playwright');
(async () => {
  const [, , file, outdir] = process.argv;
  const b = await chromium.launch();
  const res = {};
  for (const w of [1366, 1100]) {
    const ctx = await b.newContext({ viewport: { width: w, height: 900 } });
    const p = await ctx.newPage();
    const errs = [];
    p.on('pageerror', e => errs.push(String(e)));
    await p.goto('file://' + file);
    await p.waitForTimeout(900);
    const measure = async () => p.evaluate(() => {
      const q = s => Array.from(document.querySelectorAll(s));
      const vis = el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
      const btnSel = 'aside a.action, aside button, section.tabsec .box a.action, section.tabsec .box button, section.tabsec .toolbar button';
      const hs = [...new Set(q(btnSel).filter(vis).map(e => Math.round(e.getBoundingClientRect().height)))];
      const asideFs = [...new Set(q('aside a.action, aside button, aside td, aside .w9-t').filter(vis).map(e => getComputedStyle(e).fontSize))];
      const mainFs = [...new Set(q('section.tabsec.on td, #sysmatrix td').filter(vis).slice(0, 200).map(e => getComputedStyle(e).fontSize))];
      const barH = q('main > div.bar button, main > div.bar select').filter(vis).map(e => Math.round(e.getBoundingClientRect().height));
      const over = q('.cards>.box>div:nth-child(2), ' + btnSel).filter(vis).filter(e => e.scrollWidth > e.clientWidth + 1).map(e => e.textContent.trim().slice(0, 30));
      const cardFs = q('.cards>.box>div:nth-child(2)').filter(vis).map(e => e.textContent.trim().slice(0, 26) + '=' + getComputedStyle(e).fontSize);
      return { hs, asideFs, mainFs, barH, over, cardFs, kv: q('table.w10-kv').length, of: q('table.w10-of').length, ho: q('table[data-w10="ho"]').length,
        view: q('button[data-w10="xview"]').length, n2: q('td.w10-num').slice(0, 5).map(e => e.textContent),
        head: q('header.vh small, header.vh h1, header.vh .tag').map(e => e.textContent.trim()),
        tagOver: q('header.vh .tag').filter(e => e.scrollWidth > e.clientWidth + 1).length,
        tagFs: q('header.vh .tag').map(e => getComputedStyle(e).fontSize) };
    });
    const r = {};
    r.summary = await measure();
    for (const [i, name] of [[2, 'export'], [3, 'handover'], [1, 'data']]) {
      await p.evaluate(i => { const bs = document.querySelectorAll('.tabs button'); if (bs[i]) bs[i].click(); }, i);
      await p.waitForTimeout(400);
      if (name === 'data') {
        await p.evaluate(() => { const b = Array.from(document.querySelectorAll('button[data-act="ds"]')).find(x => /Combined/.test(x.textContent)); if (b) b.click(); });
        await p.waitForTimeout(400);
      }
      r[name] = await measure();
      if (outdir) await p.screenshot({ path: outdir + '/wb110_' + w + '_' + name + '.png' });
    }
    await p.evaluate(() => { const bs = document.querySelectorAll('.tabs button'); if (bs[2]) bs[2].click(); });
    await p.waitForTimeout(300);
    const [pop] = await Promise.all([ctx.waitForEvent('page', { timeout: 5000 }).catch(() => null), p.evaluate(() => { const v = document.querySelector('button[data-w10="xview"]'); if (v) v.click(); })]);
    if (pop) { await pop.waitForLoadState(); r.viewCopy = await pop.evaluate(() => ({ title: document.title, rows: document.querySelectorAll('tbody tr').length, head: document.querySelectorAll('thead th').length })); }
    r.errs = errs;
    res[w] = r;
    if (outdir) await p.screenshot({ path: outdir + '/wb110_' + w + '_aside.png', clip: { x: 0, y: 100, width: 290, height: 800 } });
    await ctx.close();
  }
  console.log(JSON.stringify(res, null, 1));
  await b.close();
})();
