"""ActivateVRN-2_v0177.py = v0176 + 管理器 v0260(頁面分割檔不進個股範圍)+ BookSource v0102(千分位兩位小數)+ OutputStore v0105 + Workbench v0110 + VerbatimVerifier v0106(加速器標記)。
runtime v0166 = runtime v0165(209 個成員一字不改)+ VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v176/pkg176/ActivateVRN-2_v0176.py")
OUT = Path("/home/user/vrn2_work/v177/pkg177/ActivateVRN-2_v0177.py")
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0176: v0175 entry + ⑬a BookSource v0101 + OutputStore v0104', '''"""VRN-2 v0177: v0176 entry + manager v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110 + VerbatimVerifier v0106 (desktop 2026-11-03 22:28:
 the full run stopped at ⑦'s 7200-second cap — the picked source folder held 60 reports and 200 page_NNNN[_hash].pdf single pages split out of other files;
 operator: 「數字小數點兩位要有千分位號 · 左右面板字體大小一致 · 按鍵高度要一致 · 矩陣化 · 第二圖超出格子 · 擷取特定資料 · 特定日期 → 檢視副本 ·
 ps py 都要加加速器 · 覆蓋率 100%」).
 - manager VRN_SystemManager_v0260 (thin tail over v0259): page_NNNN[_hash].pdf (a page split out of another file, not a whole report) joins the
   non-stock filename rule vrn2scope reads → it stays in the source folder, is not copied to scope_in (earlier copies leave it), one line counts it.
 - ⑬a VRN2_BookSource_v0102 (thin tail over v0101): TOPIC & SUMMARY numbers as 1,234.50 (thousands separators · two decimals) and the upside as 23.45%;
   numeric book columns stay as they are.
 - ⑬ VRN2_OutputStore_v0105 (thin tail over v0104 · same behaviour): its self-test runs v0104's scenarios with the BookSource they were written for and
   adds the v0101 → v0102 switch (0 rows appended · stored rows tidied to the new number format).
 - VRN2_Workbench_v0110 (thin tail over v0109): header line 3 = "Transform investment reports into structured database intelligence." · left and right panels on the same 10.45 px · every button 28 px high · card values wrap and shrink to fit
   (03 page receipt name) · left-panel counts and output folder as matrices · 04 handover snapshot as a matrix · two-decimal numbers shown with
   thousands separators · 「檢視副本」 opens a read-only copy of the extract filter (book · dates · keyword) · the tab bar (main > div.bar) untouched.
 - VRN2_VerbatimVerifier_v0106 (thin tail over v0105): accelerator marker (the one active VRN-2 module without it) · comparison unchanged.
 Runtime v0166 = runtime v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110 + VRN2_VerbatimVerifier_v0106.
 Receipt VRN2_Closeout_v0177.json.

VRN-2 v0176: v0175 entry + ⑬a BookSource v0101 + OutputStore v0104''')
rep('VERSION = "ActivateVRN-2 v0176"', 'VERSION = "ActivateVRN-2 v0177"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0165.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0166.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0165.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0166.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0176.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0177.json"')
rep('MANAGER = "VRN_SystemManager_v0259.py"   # v0168:', 'MANAGER = "VRN_SystemManager_v0260.py"   # v0177: page_NNNN[_hash].pdf out of the stock scope over v0259 · v0168:')
rep('VERBATIM = "VRN2_VerbatimVerifier_v0105.py"   # v0149:', 'VERBATIM = "VRN2_VerbatimVerifier_v0106.py"   # v0177: accelerator marker over v0105 (v0105 / v0104 stay next to it) · v0149:')
rep('WORKBENCH = "VRN2_Workbench_v0109.py"   # v0175:', 'WORKBENCH = "VRN2_Workbench_v0110.py"   # v0177: same font both panels · 28 px buttons · cards fit · matrices · 檢視副本 · thousands separators · v0175:')
rep('OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0104.py"   # v0176:', 'OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0105.py"   # v0177: v0104 behaviour · self-test pins its BookSource · v0176:')
rep('BOOK_SOURCE = "VRN2_BookSource_v0101.py"   # v0176 ⑬a:', 'BOOK_SOURCE = "VRN2_BookSource_v0102.py"   # v0177 ⑬a: 1,234.50 / 23.45% in TOPIC & SUMMARY · v0176 ⑬a:')
rep('OUTPUT_STORE_ACTIVE, "VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py", BOOK_SOURCE, "VRN2_BookSource_v0100.py")',
    'OUTPUT_STORE_ACTIVE, "VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py", BOOK_SOURCE, "VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py")', 2)
rep('        for name175 in (BOOK_SOURCE, "VRN2_BookSource_v0100.py"):', '        for name175 in (BOOK_SOURCE, "VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py"):')
rep('        for name in (VERBATIM, "VRN2_VerbatimVerifier_v0104.py", MARKET_RUNNER):', '        for name in (VERBATIM, "VRN2_VerbatimVerifier_v0105.py", "VRN2_VerbatimVerifier_v0104.py", MARKET_RUNNER):')
rep('assert vv.VERSION == "v0105" and vv.comparable(', 'assert vv.VERSION == "v0106" and vv.PRIOR.VERSION == "v0105" and vv.comparable(')
rep('    bs101 = selftest_source(BOOK_SOURCE).read_text(encoding="utf-8")', '    bs101 = selftest_source("VRN2_BookSource_v0101.py").read_text(encoding="utf-8")')
rep('    st104 = selftest_source(OUTPUT_STORE_ACTIVE).read_text(encoding="utf-8")', '    st104 = selftest_source("VRN2_OutputStore_v0104.py").read_text(encoding="utf-8")')
rep('''    assert WORKBENCH == "VRN2_Workbench_v0109.py" and OUTPUT_STORE_ACTIVE == "VRN2_OutputStore_v0104.py" and BOOK_SOURCE == "VRN2_BookSource_v0101.py"''',
    '''    bs102 = selftest_source(BOOK_SOURCE).read_text(encoding="utf-8")
    assert 'VERSION = "v0102"' in bs102 and 'PRIOR_NAME = "VRN2_BookSource_v0101.py"' in bs102 and "def money(" in bs102 and "V0101.compose = compose" in bs102 and bs102.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    st105 = selftest_source(OUTPUT_STORE_ACTIVE).read_text(encoding="utf-8")
    assert 'TAG = "v0105"' in st105 and 'PRIOR_NAME = "VRN2_OutputStore_v0104.py"' in st105 and st105.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    wb110 = selftest_source(WORKBENCH).read_text(encoding="utf-8")
    assert 'VERSION = "v0110"' in wb110 and 'PRIOR_NAME = "VRN2_Workbench_v0109.py"' in wb110 and 'id="wb110-tpl"' in wb110 and "def augment110(" in wb110 and "@CSS_SHA256@" not in wb110
    m260 = selftest_source(MANAGER).read_text(encoding="utf-8")
    assert 'TAG = "v0260"' in m260 and 'PRIOR_NAME = "VRN_SystemManager_v0259.py"' in m260 and 'PAGE_FRAGMENT = r"^page_\\\\d{3,5}(?:_[0-9a-f]{6,})?\\\\.pdf$"' in m260 and "def vrn2scope(" in m260
    assert WORKBENCH == "VRN2_Workbench_v0110.py" and OUTPUT_STORE_ACTIVE == "VRN2_OutputStore_v0105.py" and BOOK_SOURCE == "VRN2_BookSource_v0102.py" and MANAGER == "VRN_SystemManager_v0260.py"''')
rep('''        assert c176["TOPIC & SUMMARY"].startswith("示例公司(9999.TW, 買進) - 標題甲 · 目標價 120 元,上漲空間 18.0%") and "調整後目標價 118 ÷ 調整後收盤 100 = 上漲空間 18.0%" in c176["TOPIC & SUMMARY"]''',
    '''        assert c176["TOPIC & SUMMARY"].startswith("示例公司(9999.TW, 買進) - 標題甲 · 目標價 120 元,上漲空間 18.00%") and "調整後目標價 118.00 ÷ 調整後收盤 100.00 = 上漲空間 18.00%" in c176["TOPIC & SUMMARY"]''')
rep('    assert MANAGER == "VRN_SystemManager_v0259.py"\n', '')
rep('assert mgr[-1] == "VRN_SystemManager_v0259.py" and "VRN_SystemManager_v0258.py" in mgr', 'assert mgr[-1] == "VRN_SystemManager_v0260.py" and "VRN_SystemManager_v0259.py" in mgr and "VRN_SystemManager_v0258.py" in mgr')
rep('assert st.TAG == "v0104" and st.PRIOR.PRIOR.TAG.startswith("v0104") and st.PRIOR.TAG.startswith("v0104")', 'assert st.TAG == "v0105" and st.PRIOR.PRIOR.TAG.startswith("v0105") and st.PRIOR.TAG.startswith("v0105")')
rep('''    print("[PASS] v0176: ⑬a BookSource v0101''', '''    print("[PASS] v0177: manager v0260 (page_NNNN[_hash].pdf out of the stock scope) · BookSource v0102 (1,234.50 / 23.45%) · OutputStore v0105 · Workbench v0110 (same font · 28 px buttons · matrices · 檢視副本) · VerbatimVerifier v0106 (accelerator marker) are active")
    print("[PASS] v0176: ⑬a BookSource v0101''')
rep('print("[PASS] v0168: manager v0259 is the active manager', 'print("[PASS] v0168: manager v0259 (now PRIOR of v0260)')
rep('return runtime / MANAGER, lamp, detail + " · active manager v0259"', 'return runtime / MANAGER, lamp, detail + " · active manager v0260"')
rep('return lamp, detail + " · launcher v0176"', 'return lamp, detail + " · launcher v0177"')
rep('note="VRN-2 private runtime; exact ship v0165 (launcher v0176 · BookSource v0101 · OutputStore v0104 · Workbench v0109 ·',
    'note="VRN-2 private runtime; exact ship v0166 (launcher v0177 · manager v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 ·')
rep('print("NEXT: [%s] VRN-2 v0176 · rc %s', 'print("NEXT: [%s] VRN-2 v0177 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0177", len(s.splitlines()), "lines")
