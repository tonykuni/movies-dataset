"""v0177 收尾:驗證紀錄 · 交接 v0178(從 v0177 抄 · 只增)· 詳細交接報告(2026-11-04)· 收尾規格 §14(只增)· 放進倉 vrn2_release_v0177 · logs / 工具 zip。桌機 / 上傳資料不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v177"); rel = W / "release177"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def last(p):
    return [l for l in lines(p) if l.strip()][-1]


R = json.loads((rel / "VRN2_Release_v0177.json").read_text(encoding="utf-8"))
H = R["handleall"]
ra = [l for l in lines(W / "rall133_selftest.log") if re.search(r"^\[FAIL\]|--selftest · ", l)]
assert ra and "· 不過 0" in ra[-1], ra[-1:]
lsum = [l for l in lines(W / "launcher177_selftest.log") if l.startswith("[PASS] v0177")]
assert lsum and not [l for l in lines(W / "launcher177_selftest.log") if l.startswith("[FAIL]")]
mods = {"管理器 v0260(含 v0259 鏈)": last(W / "mgr260_selftest.log"), "BookSource v0102(含 v0101 / v0100)": last(W / "booksource102_selftest.log"),
        "OutputStore v0105(含 v0104 → v0100)": last(W / "store105_selftest.log"), "Workbench v0110(含 v0109 鏈)": last(W / "wb110_selftest.log"),
        "VerbatimVerifier v0106(含 v0105 / v0104)": last(W / "verbatim106_selftest.log")}
assert all(("不過 0" in v) or ("全過" in v) or ("failed 0" in v) for v in mods.values()), mods
ps = json.loads((W / "pscheck177.log").read_text())
by = {x["f"]: x for x in ps}
assert all(x["e"] == 0 for x in ps) and by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"] and by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"]
pparse = "pwsh 剖析錯 %s · Handle-All 一行 = 可讀版 True · 開機行 = 可讀版 True" % sorted(x["e"] for x in ps)
mode = (W / "modetest_result.txt").read_text(encoding="utf-8").strip()
assert "bad=full" in mode and "good=repair" in mode and "datared=repair" in mode
rc = [l for l in lines(W / "tiny177.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
assert "[RED] boot SHA-256 mismatch - not run" in (W / "tiny_tamper.log").read_text(encoding="utf-8")
states = {n: json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
base = {n: json.loads(Path("/home/user/vrn2_work/v176/closeout_%s.json" % n).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
assert states["auto1"].get("VRN-2") == base["auto1"].get("VRN-2") and states["auto2"].get("VRN-2") == base["auto2"].get("VRN-2"), (states, base)
E = json.loads((W / "e2e177_check.json").read_text(encoding="utf-8"))
assert E["scope_in_page_fragments"] == 0 and E["topic_rows_with_basis"] == E["topic_rows_new_number_format"] > 0 and E["store_no_double"] and E["workbench_v0110"] and E["header_line3"] == "Transform investment reports into structured database intelligence.", E
B = json.loads((W / "browser177.json").read_text(encoding="utf-8"))
bsum = {w: {"buttons_px": sorted({h for k in ("summary", "export", "handover", "data") for h in r[k]["hs"]}), "font_left_right": [r["export"]["asideFs"], r["export"]["mainFs"][:1]],
            "overflow": sum(len(r[k]["over"]) for k in ("summary", "export", "handover", "data")), "card_fit": r["export"]["cardFs"], "view_copy_rows": (r.get("viewCopy") or {}).get("rows"),
            "thousands": r["data"]["n2"][:3], "header": r["summary"]["head"], "header_line3_overflow": r["summary"]["tagOver"], "tab_bar_px": sorted(set(r["summary"]["barH"])),
            "errors": r["errs"]} for w, r in B.items()}
assert all(v["overflow"] == 0 and v["buttons_px"] == [28] and not v["errors"] and v["view_copy_rows"] and v["header"][2:] == ["Transform investment reports into structured database intelligence."] and v["header_line3_overflow"] == 0
           and v["tab_bar_px"] == [27, 29] for v in bsum.values()), bsum
A = json.loads((W / "audit177.json").read_text(encoding="utf-8"))
R["results"] = {"roundall_v0133_selftest": ra[-1:], "launcher_v0177_selftest": lsum, "module_selftests": mods, "pwsh_parse": pparse, "handleall_mode_test": mode, "e2e_rc": rc,
                "closeout_per_owner": states, "closeout_vrn2_items_same_as_v0176_baseline": True, "e2e": E, "browser": bsum, "accelerator_network_audit": A,
                "not_run": "the desktop itself (one line · auto = full this time because the last receipt's step 7 timed out) · the operator's own --confirm (H-fd2ea35f)"}
(rel / "VRN2_Release_v0177.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0177 驗證紀錄(2026-11-04 · 頁面分割檔不進範圍 · 千分位兩位小數 · Workbench v0110 · 加速器 100%% · 套件 v0177 · RoundAll v0133 · Handle-All v0125)

## 1. 桌機回報 → 根因 → 做法

| 回報 | 根因 / 做法 |
|---|---|
| 整輪 ⑦ 逾時 7200 秒 · ⑧ 沒寫完成判定 · 收尾 VRN-2 2 項 | 來源夾 305 份 = 60 份報告 + 200 份 `page_NNNN[_雜湊].pdf`(11/02 從別的檔切出來的單頁 · 掃描影像 · 頁號 1–63)· 舊範圍規則只排除明確非個股檔名 → 260 份當個股逐份 OCR(擷取 6,798 秒)· **管理器 v0260** 把分割頁加進非個股檔名規則(原檔不動)· **Handle-All v0125** 上一輪 ⑦ 沒跑完 → 自動整輪 · ⑧ 只因資料面紅照舊 repair |
| 數字小數點兩位要有千分位號 | BookSource v0102:主題與摘要 1,234.50 / 23.45%%(數值欄不動)· Workbench v0110 顯示兩位小數加千分位(資料不改)|
| 第二圖超出格子 · 左右面板字級 / 按鍵高度 · 矩陣化 · 檢視副本 · 字體偏小 | Workbench v0110(分頁列不動)· 收尾頁字級小一號 |
| ps / py 加速器 100%% · 向外擷取加最新網路工具 | 見 §3 |

## 2. 測試

| 項目 | 結果 |
|---|---|
| 模組自測 | %s |
| 啟動器 v0177 自測 | 全過 · %s |
| RoundAll v0133 自測 | %s |
| PowerShell | %s · 模式規則實跑:%s |
| 瀏覽器(Chromium · 1,366 / 1,100 寬)| %s |
| e2e(最短一行 · 沙盒 · 樣本夾多放 3 份 page_NNNN 分割頁)| %s · 範圍:%s · %s · 範圍夾分割頁 %d 份 |
| e2e repair(模擬桌機 v0176:BookSource 收據 v0101)| %s · 主題與摘要新寫法 %d / %d 列 · %s · 頁面分割檔列:%s |
| 收尾負責方 | VRN-2 項與 v0176 基準相同(沙盒限定 · 沒有真 OCR 環境)|

## 3. 加速器 / 網路工具稽核(VRN-2 現役模組鏈)

%s

## 4. 桌機下一步

1. 貼 `vrn2_release_v0177/VRN2_HandleAll_v0125.md` 的最短一行 —— 這次會**自動改整輪**(上一輪 ⑦ 逾時);同意閘照舊由你決定(要最新共識才開)。
2. 範圍應回到 60 份上下(52 份個股 + 少數非個股檔名不明的報告)· ⑦ 預期遠低於 7200 秒。
3. MQ-1560:`python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0133.py" --confirm H-fd2ea35f --note "你核對的結論"`(只有你打才算 · `--note` 後面不要留「…」)。
""" % (" · ".join("%s:%s" % (k, v[-32:]) for k, v in mods.items()), lsum[0][:110], ra[-1][:90], pparse, mode,
       json.dumps(bsum, ensure_ascii=False)[:420], " · ".join(rc), E["scope_line"][-120:], E["fragment_line"][-90:], E["scope_in_page_fragments"],
       E["plan"][:160], E["topic_rows_new_number_format"], E["topic_rows_with_basis"], E["store"][:160], E["page_fragment_row"][:120], A["summary_md"])
(rel / "VRN2_Verification_v0177.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0177.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0176 + VRN2_RoundAll_v0132 + VRN2_HandleAll_v0124 · 2026-11-03(")
L[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0177 + VRN2_RoundAll_v0133 + VRN2_HandleAll_v0125 · 2026-11-04(頁面分割檔不進範圍 · 千分位兩位小數 · Workbench v0110 · 加速器 100%)"
src = "\n".join(L)
once("> **本輪(v0176)**",
     "> **本輪(v0177)**:桌機 11/03 22:28 整輪 ⑦ 逾時(來源夾 200 份 page_NNNN 分割頁進了個股範圍)→ **管理器 v0260**(分割頁不進範圍)· **Handle-All v0125**(上一輪 ⑦ 沒跑完 → 自動整輪 · ⑧ 只因資料面紅照舊 repair)· "
     "**BookSource v0102**(主題與摘要 1,234.50 / 23.45%)· **OutputStore v0105** · **Workbench v0110**(頁首第三行換成操作員指定標語 · 左右同字級 · 按鍵同高 28px · 卡片自動縮字 · 左欄 / 交接矩陣 · 千分位 · 檢視副本 · 分頁列不動)· "
     "**VerbatimVerifier v0106**(加速器標記 · 沒有 pypdfium2 的 Python 自測照實略過 PDF 那段)· **RoundAll v0133**(頁面分割檔列 · 收尾頁字級)· 套件 v0177(啟動器 v0177 · runtime v0166)。VCGC(操作員授權剩餘黃燈):registry-sync 新 1 變更 128 · 編號 audit 0 / 0 / 0;"
     "X-LOCK 重驗被交接閘擋(見詳細交接報告)。詳細交接報告:`VRN2_DetailedHandover_20261104.md`。\n"
     "> **本輪(v0176)**")
rows = ("| **VRN2_HandleAll_v0125.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0125** | `vrn2_release_v0177` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0133 · ⑦ 沒跑完 → 整輪)|\n"
        "| **VRN2_RoundAll_v0133.py**(發行夾 · 一支入口 · 不在套件內)| **v0133** | `vrn2_release_v0177` | `%s` | **新**(套件 v0177 · 頁面分割檔列 · 收尾頁字級 · 自測 105)|\n"
        "| ActivateVRN-2_v0177.py(套件 · 底座 v0136 · runtime v0166)| **v0177** | 見發行清單 | `%s` | **新**(管理器 v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 · VerbatimVerifier v0106)|\n"
        "| VRN2_Runtime_v0166.zip(套件 · runtime)| **v0166** | 套件內 | `%s` | **新**(v0165 的 209 個成員不動 + 管理器 v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110)|\n"
        "| VRN_SystemManager_v0260.py(runtime · v0259 薄尾)| **v0260** | runtime v0166 | 見 runtime 清單 | **新**(page_NNNN[_雜湊].pdf 不進個股範圍)|\n"
        "| VRN2_BookSource_v0102.py / VRN2_OutputStore_v0105.py / VRN2_Workbench_v0110.py | v0102 / v0105 / v0110 | runtime v0166 | 見 runtime 清單 | **新** |\n"
        "| VRN2_VerbatimVerifier_v0106.py(套件夾 · v0105 薄尾)| **v0106** | 套件 | 見發行清單 | **新**(加速器標記 · 缺 pypdfium2 自測照實略過)|\n") % (
    H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12],
    next(c["sha256"] for c in R["components"] if c["path"] == "ActivateVRN-2_v0177.py")[:12], R["runtime"]["zip_sha256"][:12])
once("| **VRN2_HandleAll_v0124.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0124** | `vrn2_release_v0176` |",
     rows + "| **VRN2_HandleAll_v0124.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0124** | `vrn2_release_v0176` |")
once("| 0 | **(v0176)**",
     "| 0 | **(v0177)** 貼 `vrn2_release_v0177/VRN2_HandleAll_v0125.md` 的最短一行(這次自動整輪 · 分割頁不進範圍)→ 看收尾頁「頁面分割檔」綠 · ⑦ 遠低於 7200 秒 · MQ-1560 `--confirm H-fd2ea35f`(操作員)| 貼回 / 人工 |\n"
     "| 0 | **(v0176)**")
once("**v0176(2026-11-03)**:", "**v0177(2026-11-04)**:管理器 v0260(頁面分割檔不進範圍)· BookSource v0102(千分位兩位小數)· OutputStore v0105 · Workbench v0110(頁首第三行 · 同字級 · 同按鍵高 · 矩陣化 · 檢視副本)· VerbatimVerifier v0106 · RoundAll v0133 · Handle-All v0125(⑦ 沒跑完 → 整輪)· 套件 v0177 · VCGC registry-sync。\n\n**v0176(2026-11-03)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0177)** **範圍不是「沒被排除的 PDF 全收」**:page_NNNN[_雜湊].pdf 這種從別的檔切出來的單頁不是報告(管理器 v0260 · 非個股檔名規則);操作員選的來源夾可能混進其他工具的產物,"
     "範圍數字突然變大(52 → 260)要先看檔名再跑。⑦ 有 7200 秒上限,範圍爆量就會逾時。\n"
     "- **(v0177)** **repair 補不了 ⑦**:上一輪 ⑦ 沒跑完 → Handle-All v0125 自動改整輪;別讓收尾一直停在沿用前版收據。\n"
     "- **(v0177)** **U/I 鎖定區**:Workbench 分頁列(main > div.bar · 操作員截圖一)不動;改版只改左欄與各頁區塊(v0110 CSS 選擇器自測檢查不含 .bar)。數字顯示加千分位只改顯示,資料冊與匯出不改。頁首第三行 = 「Transform investment reports into structured database intelligence.」(v0110 只換字 · 樣式不動)。\n"
     "- **(v0177)** **版號**:本線下一版 管理器 v0261+ · BookSource v0103+ · OutputStore v0106+ · Workbench v0111+ · VerbatimVerifier v0107+ · RoundAll v0134+ · Handle-All v0126+ · runtime v0167+ · 啟動器 / 套件 / 收據 v0178+。\n\n")
(REPO / "VRN2_Handover_v0178.md").write_text(src, encoding="utf-8", newline="\n")
(REPO / "VRN2_DetailedHandover_20261104.md").write_text((W / "detailed_handover.md").read_text(encoding="utf-8"), encoding="utf-8", newline="\n")

spec = (REPO / "VIA_Closeout_Spec_20261103.md").read_text(encoding="utf-8")
if "## 14. v0177 輪更新" not in spec:
    spec = spec.rstrip("\n") + "\n\n" + (W / "spec14.md").read_text(encoding="utf-8")
    (REPO / "VIA_Closeout_Spec_20261103.md").write_text(spec, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0177"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0177.zip", "VRN2_RoundAll_v0133.py", "VRN2_RoundAll_v0133.md", "VRN2_HandleAll_v0125.md", "VRN2_HandleAll_v0125_boot.txt", "VRN2_Release_v0177.json", "VRN2_Verification_v0177.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 4, 2, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t177a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")) + (((str(W.parent), "<work>"),) if not name.startswith("tools/") else ()):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    if not name.startswith("tools/"):
        data = re.sub(rb"/home/user/[^\s'\"]*", b"<work>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0177.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall133_selftest.log", "launcher177_selftest.log", "mgr260_selftest.log", "booksource102_selftest.log", "store105_selftest.log", "wb110_selftest.log", "verbatim106_selftest.log",
                              "pscheck177.log", "modetest_result.txt", "tiny177.rc", "seed177.log", "sim177.log", "confirm_list.log", "e2e177_check.json", "browser177.json", "audit177.json")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0177.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall133.py", "mk_launcher177.py", "runtime166.py", "gen_build177.py", "build177.py", "build177_tail.py", "finalize177.py", "e2e177.sh", "e2e177_check.py", "browser177.js", "shot2.js", "dom.js")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0178", src.count("\n"))
