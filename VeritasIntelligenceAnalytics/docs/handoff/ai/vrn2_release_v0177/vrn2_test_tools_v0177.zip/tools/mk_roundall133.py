"""VRN2_RoundAll_v0133.py = 本線 v0132(倉裡 vrn2_release_v0176)+ 套件 v0177(啟動器 v0177 · runtime v0166)+ 頁面分割檔診斷 + BookSource v0102 觸發 + 收尾頁字級。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v177")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0176/VRN2_RoundAll_v0132.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0132')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0132 — ', '"""VRN2_RoundAll v0133 — ', 1)
at = doc.index("v0132(")
doc = doc[:at] + '''v0133(桌機 2026-11-03 22:28:整輪 ⑦ 跑滿 7200 秒被停 —— 選的來源夾有 200 份 page_NNNN[_雜湊].pdf 分割頁混進個股範圍;操作員:
  「數字小數點兩位要有千分位號 · 左右面板字體大小一致 · 按鍵高度要一致 · 矩陣化 · html u/i 自動最佳化 · 字體偏小較佳」):
  · 套件 v0177(啟動器 v0177 · runtime v0166 = v0165 的 209 個成員一字不改 + 管理器 v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110;
    VerbatimVerifier v0106 在套件夾)。
  · ⑥ 除錯:新增「頁面分割檔」一列:範圍夾 scope_in 裡還有 page_NNNN[_雜湊].pdf → 黃(上一輪 ⑦ 因此逾時 · 管理器 v0260 起移出範圍 · 跑整輪);沒有 → 綠。
  · ⑤ source:上次寫欄的 BookSource 早於 v0102(主題與摘要數字還不是千分位兩位小數)→ 也排 ⑬a;補放鏈 BookSource v0102 → v0100 · OutputStore v0105 → v0100 ·
    Workbench v0110 → v0107;Workbench 頁沒有 wb110 標記 → 重渲染。
  · ③ 自測清單:管理器 v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 · VerbatimVerifier v0106(各自先跑前版自測)。
  · 收尾頁:字級整體小一號(內文 12.5px · 表格 12px · 標籤 11px · 大數字依視窗寬度自動縮)· 按鍵同高 28px。
  · 自測 105 項(實跑計數:v0132 的 103 項 + 103 · 103b)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0132.py", "用法:python VRN2_RoundAll_v0133.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


b0 = s.index('VERSION = "v0132"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0176", "v0177").replace("VRN2_Runtime_v0165", "VRN2_Runtime_v0166")
s = pre + post
rep('VERSION = "v0132"', 'VERSION = "v0133"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0132.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0132.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0133.py"', n_dl)
rep('"VRN2_RoundAll_v0132.py" in html_', '"VRN2_RoundAll_v0133.py" in html_')
rep("· v0131 起 101 項(實跑計數 · 先前寫 103 是把子項算進去)· v0132 起 103 項。", "· v0131 起 101 項(實跑計數 · 先前寫 103 是把子項算進去)· v0132 起 103 項 · v0133 起 105 項。")
for a, b in (('("VRN2_Workbench_v0109.py", 600)', '("VRN2_Workbench_v0110.py", 600)'), ('("VRN2_BookSource_v0101.py", 300)', '("VRN2_BookSource_v0102.py", 300)'),
             ('("VRN2_OutputStore_v0104.py", 300)', '("VRN2_OutputStore_v0105.py", 300)'), ('("VRN_SystemManager_v0259.py", 1800)', '("VRN_SystemManager_v0260.py", 1800)'),
             ('("VRN2_VerbatimVerifier_v0105.py", 300)', '("VRN2_VerbatimVerifier_v0106.py", 300)')):
    rep(a, b, s.count(a))
rep('("VRN_SystemManager_v0258.py", 1800) not in SELFTESTS', '("VRN_SystemManager_v0259.py", 1800) not in SELFTESTS')
rep('STORE_CHAIN = ("VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py",', 'STORE_CHAIN = ("VRN2_OutputStore_v0105.py", "VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py",')
n = s.count('STORE_CHAIN[0] == "VRN2_OutputStore_v0104.py"')
rep('STORE_CHAIN[0] == "VRN2_OutputStore_v0104.py"', 'STORE_CHAIN[0] == "VRN2_OutputStore_v0105.py"', n)
rep('STORE_CHAIN[:2] == ("VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py")', 'STORE_CHAIN[:3] == ("VRN2_OutputStore_v0105.py", "VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py")')
rep('BOOKSOURCE_CHAIN = ("VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py")    # v0132',
    'BOOKSOURCE_CHAIN = ("VRN2_BookSource_v0102.py", "VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py")    # v0133 v0102 千分位兩位小數 · v0132')
rep('BOOKSOURCE_CHAIN[1:] == ("VRN2_BookSource_v0100.py",)', 'BOOKSOURCE_CHAIN[-1:] == ("VRN2_BookSource_v0100.py",)')
rep('BOOKSOURCE_CHAIN == ("VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py")', 'BOOKSOURCE_CHAIN[1:] == ("VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py")')
rep('WORKBENCH_CHAIN = ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")   # v0131',
    'WORKBENCH_CHAIN = ("VRN2_Workbench_v0110.py", "VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")   # v0133 v0110 · v0131')
n = s.count('WORKBENCH_CHAIN == ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")')
rep('WORKBENCH_CHAIN == ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")', 'WORKBENCH_CHAIN[1:] == ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")', n)
n = s.count('WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0109.py"')
rep('WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0109.py"', 'WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0110.py"', n)
rep("""WB_MARK = 'id="wb109-tpl"'""", """WB_MARK = 'id="wb110-tpl"'""")
n = s.count("""WB_MARK == 'id="wb109-tpl"'""")
rep("""WB_MARK == 'id="wb109-tpl"'""", """WB_MARK == 'id="wb110-tpl"'""", n)
rep('''('id="wb109-tpl"', "細節字型 · 系統摘要矩陣 · 表頭雙行 · 左欄步驟(Workbench v0109)"))''',
    '''('id="wb109-tpl"', "細節字型 · 系統摘要矩陣 · 表頭雙行 · 左欄步驟(Workbench v0109)"), ('id="wb110-tpl"', "左右同字級 · 按鍵同高 · 矩陣化 · 檢視副本 · 千分位(Workbench v0110)"))''')
# 舊項目的工作台頁(只有 wb109)在 v0133 會被判「要重渲染」→ 舊項目的固定頁補上 wb110 標記(行為不變)
rep('''(v101 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb109-tpl"></style></html>', encoding="utf-8")''',
    '''(v101 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb109-tpl"></style><style id="wb110-tpl"></style></html>', encoding="utf-8")''')
rep('''(v102 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb109-tpl"></style></html>', encoding="utf-8")''',
    '''(v102 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb109-tpl"></style><style id="wb110-tpl"></style></html>', encoding="utf-8")''')
rep('''            (v98 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb108-tpl"></style><style id="wb109-tpl"></style></html>', encoding="utf-8")''',
    '''            (v98 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb108-tpl"></style><style id="wb109-tpl"></style><style id="wb110-tpl"></style></html>', encoding="utf-8")''')
# ── source_due:BookSource 早於 v0102 ──
rep('''    if "summary_cleanup" not in (jread(rec, {}) or {}):                         # v0132 BookSource v0100 寫的 → 四點還帶符號 · 主題與摘要舊格式
        return "四點還帶開頭符號 · 主題與摘要還是舊格式(上次是 BookSource v0100 寫的)"
    return ""''', '''    rj = jread(rec, {}) or {}
    if "summary_cleanup" not in rj:                                            # v0132 BookSource v0100 寫的 → 四點還帶符號 · 主題與摘要舊格式
        return "四點還帶開頭符號 · 主題與摘要還是舊格式(上次是 BookSource v0100 寫的)"
    mv = re.search(r"v(\\d{4})", str(rj.get("module") or ""))
    if mv and int(mv.group(1)) < 102:                                          # v0133 數字還不是千分位兩位小數
        return "主題與摘要的數字還不是千分位兩位小數(上次是 BookSource v%s 寫的)" % mv.group(1)
    return ""''')
# ── ⑥ 頁面分割檔 ──
rep('''    pf = points_format(v2)                                                    # v0132''', '''    pg = page_fragments(v2)                                                   # v0133
    if pg:
        f(pg[0], "頁面分割檔", pg[1], pg[2])
    pf = points_format(v2)                                                    # v0132''')
rep('''def source_due(v2, planned) -> str:''', '''PAGE_FRAGMENT = re.compile(r"^page_\\d{3,5}(?:_[0-9a-f]{6,})?\\.pdf$", re.I)


def page_fragments(v2):
    """v0133 ⑥:範圍夾 scope_in 裡的 page_NNNN[_雜湊].pdf(從別的檔切出來的單頁 · 不是整份報告)→ (燈, 說明, 下一步);沒有範圍夾 → None。"""
    sc = Path(v2) / "scope_in"
    if not sc.is_dir():
        return None
    allp = [p.name for p in sc.glob("*.pdf")]
    pages = [n for n in allp if PAGE_FRAGMENT.match(n)]
    if not pages:
        return "GREEN", "範圍夾 %d 份 · 沒有頁面分割檔(page_NNNN)" % len(allp), ""
    return ("YELLOW", "範圍夾 %d 份裡有 %d 份頁面分割檔(%s …)· 上一輪 ⑦ 把它們當個股報告逐份 OCR → 跑滿時限被停" % (len(allp), len(pages), "、".join(sorted(pages)[:3])),
            "管理器 v0260(套件 v0177)起不進個股範圍(原檔不動)→ 跑整輪:先貼 $env:VRN2_MODE = 'full' 再貼那一行(Handle-All v0125 看到上一輪 ⑦ 沒跑完也會自動改整輪)")


def source_due(v2, planned) -> str:''')
# ── 收尾頁字級 ──
rep('''<title>VRN-2 收尾</title><style>%s</style></head><body>" % CLOSEOUT_CSS)''',
    '''<title>VRN-2 收尾</title><style>%s</style><style id=\\"ra133\\">%s</style></head><body>" % (CLOSEOUT_CSS, CLOSEOUT_CSS_133))''')
rep('''def page_fragments(v2):''', '''CLOSEOUT_CSS_133 = ("body{font-size:12.5px;line-height:1.55}h1{font-size:16px}h2{font-size:13.5px}.sub,.count,.note,.kpi .k,th,.chip,.flow li,.eyebrow{font-size:11px}"
                    ".pill,.iconbtn,.tabs a,.seg button,.legend,.owner b,td,.big,.state span{font-size:12px}.owner p{font-size:10.5px}"
                    ".state b{font-size:clamp(15px,1.6vw,19px)}.kpi .v,.donut b{font-size:clamp(16px,1.9vw,22px)}.owner .n{font-size:clamp(13px,1.4vw,16px)}"
                    ".iconbtn,.seg button,.tabs a,button{min-height:28px;height:28px;display:inline-flex;align-items:center;white-space:nowrap}"
                    ".kpi .v,.state b,.donut b{overflow-wrap:anywhere}td{overflow-wrap:anywhere}")   # v0133 字級小一號 · 大數字依寬度縮 · 按鍵同高


def page_fragments(v2):''')
rep('''json.dumps({"lamp": "GREEN", "module": "VRN2_BookSource v0101", "summary_cleanup": {"stripped_cells": 3}})''',
    '''json.dumps({"lamp": "GREEN", "module": "VRN2_BookSource v0102", "summary_cleanup": {"stripped_cells": 3}})''')   # 102 的「v0101 寫過」改成現行版(v0133 起 v0101 也會再排 ⑬a)
# ── 自測 103 / 103b ──
j = s.index('        with tempfile.TemporaryDirectory() as td101c:')
s = s[:j] + '''        with tempfile.TemporaryDirectory() as td103:
            v103 = Path(td103) / "vrn2"
            (v103 / "scope_in").mkdir(parents=True)
            pg0 = page_fragments(v103)
            for n103 in ("MQ-1560 20260520.pdf", "page_0001.pdf", "page_0001_03dd97f40f.pdf", "page_1.pdf"):
                (v103 / "scope_in" / n103).write_bytes(b"%PDF")
            pg1 = page_fragments(v103)
            (v103 / "output").mkdir()
            (v103 / "output" / "VRN2_Summary_latest.json").write_text("[]", encoding="utf-8")
            t103 = time.time()
            os.utime(v103 / "output" / "VRN2_Summary_latest.json", (t103 - 100, t103 - 100))
            (v103 / BOOKSOURCE_RECEIPT).write_text(json.dumps({"lamp": "GREEN", "module": "VRN2_BookSource v0101", "summary_cleanup": {}}), encoding="utf-8")
            os.environ.pop("VIA_VRN2_NO_BOOKSOURCE", None)
            try:
                sd101 = source_due(v103, set())
                (v103 / BOOKSOURCE_RECEIPT).write_text(json.dumps({"lamp": "GREEN", "module": "VRN2_BookSource v0102", "summary_cleanup": {}}), encoding="utf-8")
                sd102 = source_due(v103, set())
            finally:
                os.environ["VIA_VRN2_NO_BOOKSOURCE"] = "1"
        chk("103 v0133:範圍夾沒有分割頁 → 綠 · 有 page_0001 / page_0001_03dd97f40f → 黃(2 份 · page_1 不算)· 下一步寫整輪 · BookSource 收據 v0101 → 排 ⑬a(千分位兩位小數)· v0102 → 不排",
            pg0[0] == "GREEN" and pg1[0] == "YELLOW" and "有 2 份頁面分割檔" in pg1[1] and "VRN2_MODE" in pg1[2] and "千分位兩位小數" in sd101 and "v0101" in sd101 and sd102 == "")
        chk("103b v0133:套件 v0177 · 補放鏈 BookSource v0102 → v0100 · OutputStore v0105 → · Workbench v0110 → v0107 · 自測清單 管理器 v0260 / BookSource v0102 / OutputStore v0105 / Workbench v0110 / VerbatimVerifier v0106 · 收尾頁字級小一號",
            PACKAGE == "VRN2_Closeout_v0177" and RUNTIME_ZIP == "VRN2_Runtime_v0166.zip" and BOOKSOURCE_CHAIN[0] == "VRN2_BookSource_v0102.py" and STORE_CHAIN[0] == "VRN2_OutputStore_v0105.py"
            and WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0110.py" and WB_MARK == 'id="wb110-tpl"' and all(x in SELFTESTS for x in (("VRN_SystemManager_v0260.py", 1800), ("VRN2_BookSource_v0102.py", 300),
            ("VRN2_OutputStore_v0105.py", 300), ("VRN2_Workbench_v0110.py", 600), ("VRN2_VerbatimVerifier_v0106.py", 300))) and "font-size:12.5px" in CLOSEOUT_CSS_133 and "height:28px" in CLOSEOUT_CSS_133)
''' + s[j:]
(W / "new").mkdir(exist_ok=True)
(W / "new" / "VRN2_RoundAll_v0133.py").write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,30}VRN2_Runtime_v0165.{0,30}|.{0,30}Closeout_v0176.{0,30}", s[s.index('VERSION = "v0133"'):])]
print("RoundAll v0133 lines", s.count("\n"), "· stale refs:", len(left), left[:3])
