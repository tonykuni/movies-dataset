md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0125(2026-11-04 · 頁面分割檔不進範圍 · 千分位兩位小數 · Workbench v0110 · 加速器 100%% · 套件 v0177 · RoundAll v0133)

桌機 2026-11-03 22:28 回報 → 做法:

| 回報 / 要求 | v0177 |
|---|---|
| 整輪 ⑦ 跑滿 7200 秒被停(⑧ 沒寫完成判定 · 收尾 VRN-2 2 項)| 根因:選的來源夾 305 份 = 60 份報告 + **200 份 page_NNNN[_雜湊].pdf**(11/02 從別的檔切出來的單頁 · 掃描影像)· 舊規則把它們當個股報告 → 260 份逐份 OCR(擷取迴圈 6,798 秒)→ 驗收還沒跑完就到時限。**管理器 v0260**:page_NNNN[_雜湊].pdf 不進個股範圍(原檔不動 · 範圍夾裡上一輪複製進去的移走 · 多一行計數)|
| 下一輪怎麼跑 | **Handle-All v0125**:上一輪收據 ⑦ 沒跑完(rc 非 0 / 本輪沒寫出完成判定)→ 自動改**整輪**(repair 補不了 ⑦ · ⑧ 只因資料面紅照舊 repair)· RoundAll v0133 收尾頁多一列「頁面分割檔」(範圍夾還有 → 黃)|
| 數字小數點兩位要有千分位號 | 主題與摘要:調整後目標價 1,234.50 ÷ 調整後收盤 1,000.00 = 上漲空間 23.45%%(BookSource v0102)· Workbench 畫面上兩位小數的數字顯示成 1,234.50(資料冊 / 匯出不改)|
| 第二圖超出格子 | 03 頁卡片大字值:會斷行 · 依卡片寬度自動縮字(19px → 最小 11px)· 瀏覽器實測 1,366 / 1,100 寬都 0 個超框 |
| 左右面板字體大小一致 · 按鍵高度要一致 | 左欄按鍵 9px → 10.45px(= 右側內文)· 左欄與各頁區塊內所有按鍵 28px 同高(太長先縮字再省略)· 分頁列(第一張截圖)一個字都沒動 |
| 左右面板矩陣化不夠仍亂 | 左欄 ② 檔案數 → 4 欄矩陣 · ④ 輸出位置 → 路徑 / 同步 / 增量庫 / 累計 / 本輪 矩陣 · 04 頁交接快照 → 項目 / 內容矩陣 |
| 擷取特定資料 · 特定日期 → 檢視副本 | 03 頁那一格多「檢視副本」:同一套條件(資料冊 · 起訖日 · 標的 / 關鍵字)在新分頁開唯讀表格副本 |
| html u/i 自動最佳化 · 字體偏小較佳 | 自動縮字只往小 · 視窗改大小 / 換分頁時重算 · 收尾頁字級小一號(內文 12.5px)|
| ps py 都要加加速器 · 向外擷取引擎都要加最新網路工具 | VRN-2 現役模組加速器標記 100%%(唯一缺的 VerbatimVerifier → v0106 補上)· VRN-2 自己的向外擷取(共識引擎 v0122)經 VIA 網路工具;⑥e 價格經 VDF 的 AllInOne_v039(VDF 的檔 · 只記錄不改 · 見驗證紀錄)|

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0177/VRN2_Closeout_v0177.zip`(SHA-256 `%s` · 啟動器 v0177 · runtime v0166 = v0165 + 管理器 v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110 + VerbatimVerifier v0106)|
| 一支 Python | `VRN2_RoundAll_v0133.py`(SHA-256 `%s` · 自測 105 項)|
| 自動選模式 | 收據 ≥ v0170 而且上一輪 ⑦ 跑完 → repair;**上一輪 ⑦ 沒跑完 → 整輪**(這次就是整輪)|

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0125 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0133 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 只有你打才算 · `--note` 後面寫你核對的結論)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0133.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0133.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0125.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0133.py(套件 v0177)

`VRN2_RoundAll_v0133.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0132 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0177/VRN2_Closeout_v0177.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0177 · runtime v0166 |
| ⑥ 除錯 | 新一列「頁面分割檔」:範圍夾 scope_in 裡還有 page_NNNN[_雜湊].pdf → 黃 · 下一步跑整輪 |
| ⑤ source | 上次寫欄的 BookSource 早於 v0102 → 也排 ⑬a(主題與摘要數字千分位兩位小數)· 補放鏈 BookSource v0102 → v0100 · OutputStore v0105 → v0100 · Workbench v0110 → v0107 |
| ③ 自測清單 | 管理器 v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 · VerbatimVerifier v0106 |
| 收尾頁 | 字級小一號 · 大數字依寬度縮 · 按鍵同高 28px |
| 自測 | 105 項(實跑計數:v0132 的 103 項 + 103 · 103b)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0133.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0177 (launcher v0177 · runtime v0166) + VRN2_RoundAll_v0133 + VRN2_HandleAll_v0125", "date": "2026-11-04",
        "trigger": "桌機 2026-11-03 22:28:整輪 ⑦ 逾時 7200 秒(範圍 260 份含 200 份 page_NNNN 分割頁)· 操作員:數字小數點兩位要有千分位號 · 第二圖超出格子 · 左右面板字體大小一致 · 按鍵高度要一致 · "
                   "左右面板矩陣化 · 擷取特定資料 · 特定日期 → 檢視副本 · html u/i 自動最佳化 · 字體偏小較佳 · ps py 都要加加速器 · 覆蓋率 100% · 向外擷取引擎加最新網路工具",
        "root_cause": "source folder 305 files = 60 reports + 200 page_NNNN[_hash].pdf single pages (split 11-02, scanned) → vrn2scope kept them as stock reports (260) → OCR for each → p1loop 6798 s → step 7 cap 7200 s",
        "fixes": {"Manager_v0260": "thin tail over v0259 · page fragments join the non-stock filename rule · selftest 6 (+ v0259)",
                  "BookSource_v0102": "thin tail over v0101 · 1,234.50 / 23.45% in TOPIC & SUMMARY · selftest 7 (+ v0101)",
                  "OutputStore_v0105": "thin tail over v0104 · same behaviour · selftest pins v0104's BookSource + v0101→v0102 scenario × 2 engines",
                  "Workbench_v0110": "thin tail over v0109 · same font both panels · 28 px buttons · cards fit · matrices · view copy · thousands separators · header line 3 = operator tagline · tab bar untouched · selftest 7 + browser",
                  "VerbatimVerifier_v0106": "thin tail over v0105 · accelerator marker · selftest skips (not passes) the PDF step on a Python without pypdfium2", "launcher_v0177": "new actives · selftest", "RoundAll_v0133": "package v0177 · page-fragment row · BookSource < v0102 → ⑬a · closeout font · selftest 105",
                  "HandleAll_v0125": "auto mode: last receipt step 7 not finished (rc 1-9 / completion not written this round) → full; a data-only RED step 8 stays repair"},
        "package": {"name": "VRN2_Closeout_v0177.zip", "sha256": want, "release_folder": "vrn2_release_v0177", "changed": True, "launcher": "ActivateVRN-2_v0177.py"},
        "runtime": {"name": "VRN2_Runtime_v0166.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 209, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0132.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-04; file kept in vrn2_release_v0176"}],
        "roundall": {"name": "VRN2_RoundAll_v0133.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0133.md"},
        "handleall": {"name": "VRN2_HandleAll_v0125.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0125_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "Manager v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 · VerbatimVerifier v0106 · runtime v0166 · launcher / package / receipt v0177 · RoundAll v0133 · HandleAll v0125 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0177.md"}}
(rel / "VRN2_Release_v0177.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
