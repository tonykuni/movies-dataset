"""e2e v0177 結果檢查(只讀沙盒產物 · 寫 e2e177_check.json · 路徑遮掉 · 不印報告內容值)。"""
import json, re
from pathlib import Path
W = Path("/home/user/vrn2_work/v177"); V2 = W / "t177a" / "VIA" / "VIA_Reports" / "vrn2"


def txt(p):
    return Path(p).read_text(encoding="utf-8", errors="replace") if Path(p).is_file() else ""


strip = lambda t: re.sub(r"\x1b\[[0-9;]*m", "", t)
log1, log2 = strip(txt(W / "tiny_auto1.log")), strip(txt(W / "tiny_auto2.log"))
comb = json.loads(txt(W / "out_auto2" / "VRN2_Combined_latest.json") or "[]")
store = json.loads(txt(V2 / "VRN2_OutputStore_latest.json") or "{}")
bsr = json.loads(txt(V2 / "VRN2_BookSource_latest.json") or "{}")
clo = json.loads(txt(W / "closeout_auto2.json") or "{}")
wb2 = txt(W / "wb_auto2.html")
scope_line = next((l.strip() for l in log1.splitlines() if "VRN-2 範圍(只擷取個股報告)" in l), "")
frag_line = next((l.strip() for l in log1.splitlines() if "v0260 頁面分割檔" in l and "份不進個股範圍" in l), "(啟動器 ⑥b 只回範圍那一行 · 分割頁算在「檔名」排除裡)")
plan = next((l for l in log2.splitlines() if "⑤ 自動修計畫" in l), "")
src_fix = next((l.strip() for l in log2.splitlines() if "⑤ 修 · ⑬a" in l), "")
pf = next((l.strip() for l in log2.splitlines() if "⑥ 頁面分割檔" in l), "")
fmt_ok = [bool(re.search(r"調整後目標價 [\d,]+\.\d{2} ÷ 調整後收盤 [\d,]+\.\d{2} = 上漲空間 -?[\d,]+\.\d{2}%", str(c.get("TOPIC & SUMMARY") or ""))) for c in comb if "調整後目標價" in str(c.get("TOPIC & SUMMARY") or "")]
scope_in = sorted(p.name for p in (V2 / "scope_in").glob("*.pdf")) if (V2 / "scope_in").is_dir() else []
report_books = ("BasicInfo", "FinancialData", "Summary", "Combined", "Rejected", "FinancialAligned", "Deleted")
app = store.get("appended") or {}
out = {"scope_line": scope_line[:240], "fragment_line": frag_line[:200], "scope_in_page_fragments": sum(1 for n in scope_in if re.match(r"page_\d{3,5}", n)), "scope_in_files": len(scope_in),
       "plan": plan.split("⑤ 自動修計畫", 1)[-1].strip(":: ")[:300], "source_fix": src_fix[:240], "page_fragment_row": pf[:200],
       "topic_rows_with_basis": len(fmt_ok), "topic_rows_new_number_format": sum(fmt_ok), "booksource_module": bsr.get("module"),
       "store": "auto2 追加 %s · 整理 %s" % (json.dumps({b: app.get(b) for b in report_books if b in app}, ensure_ascii=False), json.dumps((store.get("summary_tidy") or {}).get("changed") or {}, ensure_ascii=False)),
       "store_no_double": bool(app) and all(not app.get(b) for b in report_books),
       "workbench_v0110": wb2.count('id="wb110-tpl"') == 1 and 'id="wb110-dom"' in wb2,
       "header_line3": (re.findall(r'<header class="vh">.*?<div class="tag">([^<]*)</div>', wb2, re.S) or [""])[0],
       "closeout_per_owner": clo.get("per_owner")}
s = json.dumps(out, ensure_ascii=False, indent=1).replace(str(W / "t177a"), "<sbx>")
(W / "e2e177_check.json").write_text(s, encoding="utf-8")
print(s)
