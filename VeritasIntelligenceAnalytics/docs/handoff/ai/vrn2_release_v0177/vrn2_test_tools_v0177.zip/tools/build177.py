"""v0177(冪等):套件 VRN2_Closeout_v0177.zip(啟動器 v0177 · runtime v0166 = v0165 + 管理器 v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110 · VerbatimVerifier v0106)
→ RoundAll v0133(填套件雜湊)→ Handle-All v0125(指到 v0133 · 上一輪 ⑦ 沒跑完 → 自動改整輪)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0177)。vrn2_release_v0176 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v177"); pkg, rel = W / "pkg177", W / "release177"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v176/release176")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0176/VRN2_Release_v0176.json").read_text(encoding="utf-8"))
r171 = json.loads((REPO / "vrn2_release_v0176/VRN2_Release_v0176.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0166.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0166.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0165.zip " + r170["runtime"]["zip_sha256"]
assert rt["retained_members"] == 209 and rt["new_members"] == ["VRN_SystemManager_v0260.py", "VRN2_BookSource_v0102.py", "VRN2_OutputStore_v0105.py", "VRN2_Workbench_v0110.py", "VRN2_VerbatimVerifier_v0106.py"]
old = {c["path"]: c["sha256"] for c in r170["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0177.py", "VRN2_Runtime_v0166.zip", "VRN2_Runtime_v0166.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_VerbatimVerifier_v0106.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0177.py", "VRN2_Runtime_v0166.zip", "VRN2_Runtime_v0166.json", "VRN2_VerbatimVerifier_v0106.py"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0176 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0177 — VRN-2 closeout package (2026-11-04 · page fragments out of scope · thousands separators · Workbench v0110 · accelerator 100%)\n\n"
  "Entry: python ActivateVRN-2_v0177.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0133.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0125.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0166.zip = v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110 + VRN2_VerbatimVerifier_v0106.\n\n"
  "v0177 (desktop 2026-11-03 22:28: step 7 stopped at its 7200-second cap — 200 page_NNNN[_hash].pdf single pages from the picked folder were in the stock scope):\n"
  " - manager v0260: page_NNNN[_hash].pdf is a page split out of another file, not a report -> not copied to scope_in (source untouched, counted).\n"
  " - BookSource v0102: TOPIC & SUMMARY numbers as 1,234.50 and the upside as 23.45% (numeric book columns unchanged). OutputStore v0105: same as v0104.\n"
  " - Workbench v0110: same 10.45 px in both panels, every button 28 px, card values fit, matrices (left counts, output folder, handover), two-decimal\n"
  "   numbers with thousands separators, a read-only view copy of the extract filter; the tab bar is untouched.\n"
  " - VerbatimVerifier v0106: accelerator marker (the last active VRN-2 module without it).\n"
  "v0176: BookSource v0101 (four points without leading bullets · title format · adjusted upside) · OutputStore v0104. v0163: no MOPS.\n"
  "Verification: see VRN2_Verification_v0177.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0177.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0177", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0177.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0177/" + n, date_time=(2026, 11, 4, 2, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0133.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0177"' in ra and 'VERSION = "v0133"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177"' in ra
(rel / "VRN2_RoundAll_v0133.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177'")
rep("$F = 'VRN2_RoundAll_v0132.py'", "$F = 'VRN2_RoundAll_v0133.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0124", "Handle-All v0125", ha.count("Handle-All v0124"))
rep("套件 v0176 裝在新夾 VRN2_Closeout_v0176", "套件 v0177 裝在新夾 VRN2_Closeout_v0177")
rep("取套件 v0176 → 診斷 → 全部自測 → 跑啟動器 v0176(", "取套件 v0177 → 診斷 → 全部自測 → 跑啟動器 v0177(管理器 v0260 頁面分割檔不進個股範圍 · ")
rep("⑬a BookSource v0101(四點去開頭符號 · 主題與摘要 = Name(YFinance Ticker, 評等) - 原文標題 · 評價點用調整後目標價 ÷ 調整後收盤 · 含 v0100 SOURCE / BROKER_EN)· 增量庫 OutputStore v0104(不重複追加 · 舊列就地整理 · 含 v0103 補欄)· Workbench v0109(",
    "⑬a BookSource v0102(主題與摘要數字千分位兩位小數 · 含 v0101 四點去符號 / 標題格式 / 調整後上漲空間 · v0100 SOURCE / BROKER_EN)· 增量庫 OutputStore v0105(不重複追加 · 舊列就地整理)· Workbench v0110(左右同字級 · 按鍵同高 · 矩陣化 · 檢視副本 · 千分位 · 含 v0109 ")
rep("repair = '取套件 v0176 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 四點去開頭符號 · 主題與摘要新格式 · 評價點上漲空間 = 調整後目標價 ÷ 調整後收盤 − 1 ·",
    "repair = '取套件 v0177 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 主題與摘要數字千分位兩位小數 · 四點去開頭符號 · 評價點上漲空間 = 調整後目標價 ÷ 調整後收盤 − 1 · Workbench v0110 ·")
rep("只重跑 ⑪ 獨立驗證(套件 v0176 的", "只重跑 ⑪ 獨立驗證(套件 v0177 的")
rep("if ($Mode -eq 'auto') { $Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full';", "$wasAuto = ($Mode -eq 'auto'); if ($Mode -eq 'auto') { $Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full';")
i60 = ha.index("if ($Mode -ne 'full' -and -not $haveOut) {")
e60 = ha.index("\n", i60) + 1
ha = ha[:e60] + ("if ($wasAuto -and $Mode -eq 'repair' -and $rcp) { try { $rj = Get-Content -LiteralPath $rcp.FullName -Raw -Encoding utf8 | ConvertFrom-Json; "
                 "$s7 = @($rj.steps | Where-Object { \"$($_.step)\" -like '⑦ 啟動*' })[0]; $s8 = @($rj.steps | Where-Object { \"$($_.step)\" -like '⑧ 完成判定*' })[0]; "
                 "if (($s7 -and \"$($s7.detail)\" -match '(^|[^a-z])rc [1-9]') -or ($s8 -and \"$($s8.detail)\" -match '本輪未寫出完成判定|⑦ 沒跑完')) { Write-Host \"[YELLOW] ④ 上一輪 ⑦ 沒跑完($(\"$($s7.detail)\".Trim()))→ repair 補不了 · 改跑整輪(套件 v0177 起頁面分割檔不進個股範圍)\" -ForegroundColor Yellow; $Mode = 'full' } } catch { Write-Host \"[GRAY] ④ 讀上一輪收據沒成($($_.Exception.Message))· 照 $($Mode)\" -ForegroundColor DarkGray } }\n") + ha[e60:]
left = [l for l in ha.split("\n") if re.search(r"Handle-All v0124|v0132[.]py|release_v0176|套件 v0176|Closeout_v0176", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha and "$wasAuto -and $Mode -eq 'repair'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0176", "vrn2_release_v0177"), ("VRN2_HandleAll_v0124.md", "VRN2_HandleAll_v0125.md"), ("Handle-All v0124 SHA-256 OK", "Handle-All v0125 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0125_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0177/VRN2_HandleAll_v0125_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0125(2026-11-04 · 頁面分割檔不進範圍 · 千分位兩位小數 · Workbench v0110 · 加速器 100%% · 套件 v0177 · RoundAll v0133)

桌機 2026-11-03 22:28 回報 → 做法:

| 回報 / 要求 | v0177 |
|---|---|
| 整輪 ⑦ 跑滿 7200 秒被停(⑧ 沒寫完成判定 · 收尾 VRN-2 2 項)| 根因:選的來源夾 305 份 = 60 份報告 + **200 份 page_NNNN[_雜湊].pdf**(11/02 從別的檔切出來的單頁 · 掃描影像)· 舊規則把它們當個股報告 → 260 份逐份 OCR(擷取迴圈 6,798 秒)→ 驗收還沒跑完就到時限。**管理器 v0260**:page_NNNN[_雜湊].pdf 不進個股範圍(原檔不動 · 範圍夾裡上一輪複製進去的移走 · 多一行計數)|
| 下一輪怎麼跑 | **Handle-All v0125**:上一輪收據 ⑦ 沒跑完(rc 非 0 / 本輪沒寫出完成判定)→ 自動改**整輪**(repair 補不了 ⑦ · ⑧ 只因資料面紅照舊 repair)· RoundAll v0133 收尾頁多一列「頁面分割檔」(範圍夾還有 → 黃)|
| 數字小數點兩位要有千分位號 | 主題與摘要:調整後目標價 1,234.50 ÷ 調整後收盤 1,000.00 = 上漲空間 23.45%%(BookSource v0102)· Workbench 畫面上兩位小數的數字顯示成 1,234.50(資料冊 / 匯出不改)|
| 第二圖超出格子 | 03 頁卡片大字值:會斷行 · 依卡片寬度自動縮字(19px → 最小 11px)· 瀏覽器實測 1,366 / 1,100 寬都 0 個超框 |
| 左右面板字體大小一致 · 按鍵高度要一致 | 左欄按鍵 9px → 10.45px(= 右側內文)· 左欄與各頁區塊內所有按鍵 28px 同高(太長先縮字再省略)· 分頁列(第一張截圖)一個字都沒動 |
| 左右面板矩陣化不夠仍亂 | 左欄 ② 檔案數 → 4 欄矩陣 · ④ 輸出位置 → 路徑 / 同步 / 增量庫 / 累計 / 本輪 矩陣 · 04 頁交接快照 → 項目 / 內容矩陣 |
| 擷取特定資料 · 特定日期 → 檢視副本 | 03 頁那一格多「檢視副本」:同一套條件(資料冊 · 起訖日 · 標的 / 關鍵字)在新分頁開唯讀表格副本 |
| html u/i 自動最佳化 · 字體偏小較佳 | 自動縮字只往小 · 視窗改大小 / 換分頁時重算 · 收尾頁字級小一號(內文 12.5px)|
| ps py 都要加加速器 · 向外擷取引擎都要加最新網路工具 | VRN-2 現役模組加速器標記 100%%(唯一缺的 VerbatimVerifier → v0106 補上)· VRN-2 自己的向外擷取(共識引擎 v0122)經 VIA 網路工具;⑥e 價格經 VDF 的 AllInOne_v039(VDF 的檔 · 只記錄不改 · 見驗證紀錄)|

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0177/VRN2_Closeout_v0177.zip`(SHA-256 `%s` · 啟動器 v0177 · runtime v0166 = v0165 + 管理器 v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110 + VerbatimVerifier v0106)|
| 一支 Python | `VRN2_RoundAll_v0133.py`(SHA-256 `%s` · 自測 105 項)|
| 自動選模式 | 收據 ≥ v0170 而且上一輪 ⑦ 跑完 → repair;**上一輪 ⑦ 沒跑完 → 整輪**(這次就是整輪)|

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0125 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0133 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 只有你打才算 · `--note` 後面寫你核對的結論)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0133.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0133.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0125.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0133.py(套件 v0177)

`VRN2_RoundAll_v0133.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0132 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0177/VRN2_Closeout_v0177.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0177 · runtime v0166 |
| ⑥ 除錯 | 新一列「頁面分割檔」:範圍夾 scope_in 裡還有 page_NNNN[_雜湊].pdf → 黃 · 下一步跑整輪 |
| ⑤ source | 上次寫欄的 BookSource 早於 v0102 → 也排 ⑬a(主題與摘要數字千分位兩位小數)· 補放鏈 BookSource v0102 → v0100 · OutputStore v0105 → v0100 · Workbench v0110 → v0107 |
| ③ 自測清單 | 管理器 v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 · VerbatimVerifier v0106 |
| 收尾頁 | 字級小一號 · 大數字依寬度縮 · 按鍵同高 28px |
| 自測 | 105 項(實跑計數:v0132 的 103 項 + 103 · 103b)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0133.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0177 (launcher v0177 · runtime v0166) + VRN2_RoundAll_v0133 + VRN2_HandleAll_v0125", "date": "2026-11-04",
        "trigger": "桌機 2026-11-03 22:28:整輪 ⑦ 逾時 7200 秒(範圍 260 份含 200 份 page_NNNN 分割頁)· 操作員:數字小數點兩位要有千分位號 · 第二圖超出格子 · 左右面板字體大小一致 · 按鍵高度要一致 · "
                   "左右面板矩陣化 · 擷取特定資料 · 特定日期 → 檢視副本 · html u/i 自動最佳化 · 字體偏小較佳 · ps py 都要加加速器 · 覆蓋率 100% · 向外擷取引擎加最新網路工具",
        "root_cause": "source folder 305 files = 60 reports + 200 page_NNNN[_hash].pdf single pages (split 11-02, scanned) → vrn2scope kept them as stock reports (260) → OCR for each → p1loop 6798 s → step 7 cap 7200 s",
        "fixes": {"Manager_v0260": "thin tail over v0259 · page fragments join the non-stock filename rule · selftest 6 (+ v0259)",
                  "BookSource_v0102": "thin tail over v0101 · 1,234.50 / 23.45% in TOPIC & SUMMARY · selftest 7 (+ v0101)",
                  "OutputStore_v0105": "thin tail over v0104 · same behaviour · selftest pins v0104's BookSource + v0101→v0102 scenario × 2 engines",
                  "Workbench_v0110": "thin tail over v0109 · same font both panels · 28 px buttons · cards fit · matrices · view copy · thousands separators · header line 3 = operator tagline · tab bar untouched · selftest 7 + browser",
                  "VerbatimVerifier_v0106": "thin tail over v0105 · accelerator marker · selftest skips (not passes) the PDF step on a Python without pypdfium2", "launcher_v0177": "new actives · selftest", "RoundAll_v0133": "package v0177 · page-fragment row · BookSource < v0102 → ⑬a · closeout font · selftest 105",
                  "HandleAll_v0125": "auto mode: last receipt step 7 not finished (rc 1-9 / completion not written this round) → full; a data-only RED step 8 stays repair"},
        "package": {"name": "VRN2_Closeout_v0177.zip", "sha256": want, "release_folder": "vrn2_release_v0177", "changed": True, "launcher": "ActivateVRN-2_v0177.py"},
        "runtime": {"name": "VRN2_Runtime_v0166.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 209, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0132.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-04; file kept in vrn2_release_v0176"}],
        "roundall": {"name": "VRN2_RoundAll_v0133.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0133.md"},
        "handleall": {"name": "VRN2_HandleAll_v0125.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0125_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "Manager v0260 · BookSource v0102 · OutputStore v0105 · Workbench v0110 · VerbatimVerifier v0106 · runtime v0166 · launcher / package / receipt v0177 · RoundAll v0133 · HandleAll v0125 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0177.md"}}
(rel / "VRN2_Release_v0177.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
