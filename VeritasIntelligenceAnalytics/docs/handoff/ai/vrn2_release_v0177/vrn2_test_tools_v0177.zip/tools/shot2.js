const { chromium } = require('playwright');
(async () => {
  const [, , file, out, tabIdx, w, y] = process.argv;
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: parseInt(w || '1480'), height: 900 }, deviceScaleFactor: 1 });
  await p.goto('file://' + file);
  await p.waitForTimeout(800);
  const tabs = await p.evaluate(() => Array.from(document.querySelectorAll('.tabs button')).map(b => b.textContent.trim()));
  if (tabIdx !== undefined && tabIdx !== '') {
    await p.evaluate(i => { const bs = document.querySelectorAll('.tabs button'); if (bs[i]) bs[i].click(); }, parseInt(tabIdx));
    await p.waitForTimeout(600);
  }
  const tabY = await p.evaluate(() => { const e = document.querySelector('.tabs'); return e ? e.getBoundingClientRect().top + window.scrollY : -1; });
  await p.evaluate(yy => { const t = document.querySelector(".tabs"); if (yy > 0 && t) t.scrollIntoView({block: "start"}); }, parseInt(y || "0"));
  await p.waitForTimeout(200);
  await p.screenshot({ path: out });
  console.log(JSON.stringify({ tabs, tabY }));
  await b.close();
})();
