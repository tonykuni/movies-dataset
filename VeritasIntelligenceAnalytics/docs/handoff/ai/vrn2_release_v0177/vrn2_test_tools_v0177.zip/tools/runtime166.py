"""runtime v0166 = runtime v0165(209 個成員逐位元組不動)+ 管理器 v0260 + BookSource v0102 + OutputStore v0105 + Workbench v0110 · 套件夾 pkg177(VerbatimVerifier v0106 放套件 · 其他照 pkg176)。"""
import hashlib, json, shutil, zipfile
from pathlib import Path
old, new, out = Path("/home/user/vrn2_work/v176/pkg176"), Path("/home/user/vrn2_work/v177/new"), Path("/home/user/vrn2_work/v177/pkg177")
out.mkdir(parents=True, exist_ok=True)
om = json.loads((old / "VRN2_Runtime_v0165.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
assert hashlib.sha256((old / "VRN2_Runtime_v0165.zip").read_bytes()).hexdigest() == om["zip_sha256"]
with zipfile.ZipFile(old / "VRN2_Runtime_v0165.zip") as z:
    members = {n: z.read(n) for n in old_names}
for e in om["files"]:
    assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"], e["path"]
assert len(old_names) == 209, len(old_names)
new_names = ["VRN_SystemManager_v0260.py", "VRN2_BookSource_v0102.py", "VRN2_OutputStore_v0105.py", "VRN2_Workbench_v0110.py", "VRN2_VerbatimVerifier_v0106.py"]
for n in new_names:
    assert n not in members, n
    members[n] = (new / n).read_bytes()
names = sorted(members); zp = out / "VRN2_Runtime_v0166.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 4, 2, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0166", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0165.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names,
       "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0166.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(str(old / n), str(out / n))
shutil.copy2(str(new / "VRN2_VerbatimVerifier_v0106.py"), str(out / "VRN2_VerbatimVerifier_v0106.py"))
print("runtime v0166", len(names), man["zip_sha256"][:12], "· pkg177", sorted(p.name for p in out.iterdir()))
