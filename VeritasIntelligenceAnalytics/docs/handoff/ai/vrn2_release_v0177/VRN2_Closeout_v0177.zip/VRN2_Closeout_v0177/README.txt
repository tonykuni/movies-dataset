VRN2_Closeout_v0177 — VRN-2 closeout package (2026-11-04 · page fragments out of scope · thousands separators · Workbench v0110 · accelerator 100%)

Entry: python ActivateVRN-2_v0177.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0133.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0125.md (same release folder).
Runtime: VRN2_Runtime_v0166.zip = v0165 (209 members byte-identical) + VRN_SystemManager_v0260 + VRN2_BookSource_v0102 + VRN2_OutputStore_v0105 + VRN2_Workbench_v0110 + VRN2_VerbatimVerifier_v0106.

v0177 (desktop 2026-11-03 22:28: step 7 stopped at its 7200-second cap — 200 page_NNNN[_hash].pdf single pages from the picked folder were in the stock scope):
 - manager v0260: page_NNNN[_hash].pdf is a page split out of another file, not a report -> not copied to scope_in (source untouched, counted).
 - BookSource v0102: TOPIC & SUMMARY numbers as 1,234.50 and the upside as 23.45% (numeric book columns unchanged). OutputStore v0105: same as v0104.
 - Workbench v0110: same 10.45 px in both panels, every button 28 px, card values fit, matrices (left counts, output folder, handover), two-decimal
   numbers with thousands separators, a read-only view copy of the extract filter; the tab bar is untouched.
 - VerbatimVerifier v0106: accelerator marker (the last active VRN-2 module without it).
v0176: BookSource v0101 (four points without leading bullets · title format · adjusted upside) · OutputStore v0104. v0163: no MOPS.
Verification: see VRN2_Verification_v0177.md. Hashes: PACKAGE_SHA256.json.
