#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# [VIA:ACCEL-BRIDGE:v0111]
"""Read-only second-reader check of the four source excerpts — v0106 = v0105 thin tail (v0105 / v0104 kept byte-identical).

Operator 2026-11-03: 「ps py 都要加加速器 · 覆蓋率 100%」. The VRN-2 accelerator audit of the active module chain found one active file without the
accelerator marker: VRN2_VerbatimVerifier_v0105.py (its prior v0104 has it). v0106 carries the marker on line 3, joins the VIA accelerator the same
way the other VRN-2 tails do (best effort · never required for the check) and changes nothing else: comparable() / verify() are v0105's.
No network, no writes besides the launcher's own VRN2_VerbatimVerify_latest.json.
Selftest: a Python without pypdfium2 cannot build v0104's test PDF → step ① prints [SKIP] (environment · install via VCGC), never a fake PASS.
"""
from __future__ import annotations

import contextlib
import importlib.util
import io
import os
import re
import sys
from pathlib import Path

VERSION = "v0106"
PRIOR_NAME = "VRN2_VerbatimVerifier_v0105.py"
HERE = Path(__file__).resolve().parent


def _prior():
    path = HERE / PRIOR_NAME
    if not path.is_file():
        raise FileNotFoundError("前版 %s 不在 %s" % (PRIOR_NAME, HERE))
    spec = importlib.util.spec_from_file_location("vrn2_verbatim_prior_v0105", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


PRIOR = _prior()
for _name in dir(PRIOR):
    if not _name.startswith("__") and _name not in globals():
        globals()[_name] = getattr(PRIOR, _name)
comparable = PRIOR.comparable
verify = PRIOR.verify


def accelerator() -> str:
    """VIA accelerator (VeritasCeleritas · newest version next to the VIA root) if importable; '' otherwise — the check never depends on it."""
    root = os.environ.get("VIA_ROOT")
    if not root:
        return ""
    sup = Path(root) / "supportive modules"
    cands = sorted(sup.rglob("VeritasCeleritas_v[0-9]*.py")) if sup.is_dir() else []
    if not cands:
        return ""
    try:
        spec = importlib.util.spec_from_file_location("via_celeritas_for_verbatim", cands[-1])
        module = importlib.util.module_from_spec(spec)
        with contextlib.redirect_stdout(io.StringIO()):
            spec.loader.exec_module(module)
        return cands[-1].name
    except Exception:  # noqa: BLE001
        return ""


def selftest():
    bad = []

    def chk(label, cond):
        print(("[PASS] " if cond else "[FAIL] ") + label, flush=True)
        if not cond:
            bad.append(label)
    buf = io.StringIO()
    skipped = ""
    try:
        with contextlib.redirect_stdout(buf):
            rc = PRIOR.selftest()
    except ModuleNotFoundError as error:                                   # v0104 的自測要 pypdfium2 造 PDF;這個 Python 沒有 = 環境(交 VCGC)· 不冒充 PASS
        if getattr(error, "name", "") not in ("pypdfium2", "pdfplumber", "PIL"):
            raise
        skipped = error.name
        rc = None
    if skipped:
        print("[SKIP] ① v0105 自測要 %s 造測試 PDF · 這個 Python(%s)沒有 → 不驗(環境 · 缺的經 VCGC 安裝)· 核對本身照樣要它" % (skipped, sys.executable), flush=True)
    else:
        chk("① v0105 自測(行尾連字號 · U+FFFE · v0104 的 MISSING / FAIL)照過 · %s" % (buf.getvalue().strip().splitlines() or ["—"])[-1][:60], rc == 0)
    src = Path(__file__).read_text(encoding="utf-8")
    chk("② 第 3 行加速器標記 · comparable / verify 就是 v0105 的 · 不連外",
        src.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]" and comparable is PRIOR.comparable and verify is PRIOR.verify
        and not re.search(r"^\s*(import|from)\s+(requests|urllib|http|socket)\b", src, re.M) and comparable("Type-\nC PD") == comparable("Type\ufffeC PD"))
    saved = os.environ.pop("VIA_ROOT", None)
    try:
        chk("③ 沒有 VIA 根 → 加速器略過(回空字串 · 核對照跑)", accelerator() == "")
    finally:
        if saved is not None:
            os.environ["VIA_ROOT"] = saved
    print("[%s] VRN2_VerbatimVerifier %s --selftest · %d 項 · 不過 %d%s" % ("PASS" if not bad else "FAIL", VERSION, 2 if skipped else 3, len(bad),
                                                                        (" · 略過 1(沒有 %s)" % skipped) if skipped else ""), flush=True)
    return 0 if not bad else 1


def main(argv=None):
    if (sys.argv[1:] if argv is None else argv) == ["--selftest"]:
        return selftest()
    return PRIOR.main(argv)


if __name__ == "__main__":
    raise SystemExit(main())
