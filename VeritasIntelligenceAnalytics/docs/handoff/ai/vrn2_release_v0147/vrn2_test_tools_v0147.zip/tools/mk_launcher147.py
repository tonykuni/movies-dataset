"""ActivateVRN-2_v0147.py = v0146 + OutputStore v0101 / DataIntegrate v0101 · ⑥e 用擷取 Python · fill 不因 fetch 逾時跳過 · ⑬b 在 ⑬ 前 · 自測從 runtime zip 取輔助模組。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v146/new/ActivateVRN-2_v0146.py").read_text(encoding="utf-8")
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90]); s = s.replace(a, b)
rep('"""VRN-2 v0146: v0145 entry + market data (⑥e)',
    '"""VRN-2 v0147: v0146 entry + fixes found while building the one-file runner VRN2_RoundAll_v0100.py (operator 2026-10-29: "generate a py code to handle all above and fix all test all debug all").\n\n'
    ' - ⑬ long-term Parquet store: VRN2_OutputStore_v0101 keeps Combined · FinancialAligned · Deleted too, and appends per (book × source-file SHA) so books that appear later are\n'
    '   back-filled for files the store already knows (v0100 only appended files it had never seen → on the desktop, with 52 known files, the new books stayed empty).\n'
    ' - ⑬b history alignment now runs BEFORE ⑬, so FinancialAligned / Deleted of this run are in the store.\n'
    ' - ⑬c legacy-database scan: VRN2_DataIntegrate_v0101 walks with a depth limit (output folder 2 · its parent 1 · legacy_in 3 · max 20,000 entries per folder) instead of rglob over the whole\n'
    '   tree (the parent of a OneDrive output folder is the OneDrive root), and only asks about files that look like a VRN-2 book (≥ 3 mapped columns · an identity column · ITEM + VALUE for FinancialData).\n'
    ' - ⑥e runs the borrowed MarketFetch with the fetch Python (VIA_FETCH_PY → %USERPROFILE%\\\\envs\\\\via_tw_fetch → this Python) because --fill imports pandas; --fill still runs after a --fetch\n'
    '   timeout / error (VDF writes Parquet incrementally) and is skipped only when --fetch is GRAY.\n'
    ' - --selftest no longer needs the runtime modules next to the launcher: it takes them out of VRN2_Runtime_v0147.zip in the package (v0144–v0146 selftests failed in a real package folder).\n'
    ' - ⑬b history alignment: VRN2_HistoryAlign_v0101 sends a row to the Deleted zone only when it is the same order of magnitude as history (ratio 0.5–2) and > 3% off;\n'
    '   a row that matches at another unit scale is overridden without deletion, an unclear-basis row (ratio far off) is left untouched, growth / % sections are ratios\n'
    '   (RoundAll end-to-end: 100 → 39 deleted rows on the same data, the 61 were other units / growth tables).\n'
    ' Runtime v0147 = runtime v0146 (175 members byte-identical) + VRN2_OutputStore_v0101 + VRN2_DataIntegrate_v0101 + VRN2_HistoryAlign_v0101.\n\n'
    'v0146: v0145 entry + market data (⑥e)')
rep('VERSION = "ActivateVRN-2 v0146"', 'VERSION = "ActivateVRN-2 v0147"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0146.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0147.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0146.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0147.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0146.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0147.json"')
rep('OUTPUT_STORE = "VRN2_OutputStore_v0100.py"', 'OUTPUT_STORE = "VRN2_OutputStore_v0101.py"   # v0147: thin tail over v0100 (7 books · per-book back-fill)')
rep('HISTORY_ALIGN = "VRN2_HistoryAlign_v0100.py"', 'HISTORY_ALIGN = "VRN2_HistoryAlign_v0101.py"   # v0147: thin tail over v0100 (Deleted only for same-magnitude contradictions)')
rep('DATA_INTEGRATE = "VRN2_DataIntegrate_v0100.py"', 'DATA_INTEGRATE = "VRN2_DataIntegrate_v0101.py"   # v0147: thin tail over v0100 (depth-limited walk · VRN-2-like filter)')
# ⑥e: fetch python + fill after fetch error
rep('''        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        results = {}''', '''        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        fetch_py = market_python()
        results = {}''')
rep('command = [sys.executable, "-X", "utf8", str(tool), verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)]',
    'command = [fetch_py, "-X", "utf8", str(tool), verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)]')
rep('if verb == "--fetch" and results[verb]["lamp"] in ("GRAY", "RED"):', 'if verb == "--fetch" and results[verb]["lamp"] == "GRAY":   # v0147: a RED / timed-out fetch still leaves Parquet behind → --fill anyway')
rep('''        detail = "%s · 擷取 %s:%s · 填值 %s:%s" % (tool.name,''', '''        detail = "%s · Python %s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, Path(fetch_py).parent.parent.name if fetch_py != sys.executable else "本行程",''')
rep('''def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:''', '''def market_python() -> str:
    """v0147: the Python that runs MarketFetch (its --fill imports pandas): VIA_FETCH_PY → %USERPROFILE%\\\\envs\\\\via_tw_fetch → this Python."""
    explicit = os.environ.get("VIA_FETCH_PY") or ""
    if explicit and Path(explicit).is_file():
        return explicit
    home = os.environ.get("USERPROFILE") or os.environ.get("HOME") or ""
    for candidate in (Path(home) / "envs" / "via_tw_fetch" / "Scripts" / "python.exe", Path(home) / "envs" / "via_tw_fetch" / "bin" / "python"):
        if home and candidate.is_file():
            return str(candidate)
    return sys.executable


def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:''')
# ⑬b before ⑬
rep('''    store = output_store(runtime, output, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), base.STEPS)
    receipt["output_store"] = store
    receipt["steps"] = base.STEPS
    if store.get("lamp") == "RED" and code == 0:
        code = 2
        receipt["rc"] = code
    receipt["history_align"] = history_align(runtime, root, output, base.STEPS)
    receipt["integrate"] = integrate_scan(runtime, output, base.STEPS)''', '''    receipt["history_align"] = history_align(runtime, root, output, base.STEPS)   # v0147: before ⑬ so FinancialAligned / Deleted reach the store
    store = output_store(runtime, output, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), base.STEPS)
    receipt["output_store"] = store
    receipt["steps"] = base.STEPS
    if store.get("lamp") == "RED" and code == 0:
        code = 2
        receipt["rc"] = code
    receipt["integrate"] = integrate_scan(runtime, output, base.STEPS)''')
rep('print("NEXT: [%s] VRN-2 v0146 · rc %s', 'print("NEXT: [%s] VRN-2 v0147 · rc %s')
rep('return lamp, detail + " · launcher v0146"', 'return lamp, detail + " · launcher v0147"')
rep('launcher = root / "package" / "ActivateVRN-2_v0146.py"', 'launcher = root / "package" / "ActivateVRN-2_v0147.py"')
# selftest helper source
rep('''def selftest() -> int:''', '''_SELFTEST_CACHE = {}


def selftest_source(name: str) -> Path:
    """v0147: a runtime module for --selftest — next to the launcher → ../new (build tree) → taken out of the package's runtime zip (verified against its manifest)."""
    for candidate in (Path(__file__).with_name(name), Path(__file__).resolve().parent.parent / "new" / name):
        if candidate.is_file():
            return candidate
    if name in _SELFTEST_CACHE:
        return _SELFTEST_CACHE[name]
    archive, manifest = Path(__file__).with_name(RUNTIME_ZIP), Path(__file__).with_name(RUNTIME_MANIFEST)
    if not archive.is_file():
        raise FileNotFoundError("selftest needs %s (not next to the launcher, no %s)" % (name, RUNTIME_ZIP))
    expected = {}
    if manifest.is_file():
        expected = {entry["path"]: entry["sha256"] for entry in json.loads(manifest.read_text(encoding="utf-8")).get("files", [])}
    with zipfile.ZipFile(archive) as bundle:
        data = bundle.read(name)
    if expected and hashlib.sha256(data).hexdigest() != expected.get(name):
        raise ValueError("%s in %s does not match %s" % (name, RUNTIME_ZIP, RUNTIME_MANIFEST))
    folder = Path(tempfile.mkdtemp(prefix="vrn2-selftest-src-"))
    target = folder / name
    target.write_bytes(data)
    _SELFTEST_CACHE[name] = target
    return target


SELFTEST_ENV_CLEAR = ("VRN2_OUTPUT_DIR", "VIA_VRN2_NO_MARKET", "VIA_VRN2_NO_CONSENSUS", "VIA_VRN2_NO_HISTORY", "VIA_VRN2_NO_INTEGRATE", "VRN2_CONSENSUS_FIXTURES", "VRN2_INTEGRATE_DIRS",
                      "VRN2_NO_REPASS", "VRN2_FORCE_PARALLEL", "VIA_FETCH_PY", "VRN2_UI_REFRESH_WAIT", "VRN2_SILENT_MAX", "VRN2_MANIFEST_WAIT", "VIA_VRN2_VERIFY_WAIT", "VRN2_MARKET_WAIT", "VRN2_CONSENSUS_WAIT")


def selftest() -> int:
    """v0147: hermetic — run-time switches the operator may have set (VRN2_OUTPUT_DIR seeds ⑬ · the wait limits · the step opt-outs) are cleared for the
    selftest and restored afterwards; v0144–v0146 failed their own ⑬ / limits checks whenever VRN2_OUTPUT_DIR or a limit was set in the shell."""
    saved = {key: os.environ.pop(key) for key in SELFTEST_ENV_CLEAR if key in os.environ}
    try:
        return _selftest_body()
    finally:
        for key in SELFTEST_ENV_CLEAR:
            os.environ.pop(key, None)
        os.environ.update(saved)


def _selftest_body() -> int:''')
rep('''        for name in (SSOT_SYNC, "VRN2_SSOTSync_v0100.py", OUTPUT_STORE):   # v0146: SSOTSync v0101 is a thin tail over v0100
            source = Path(__file__).with_name(name)
            if not source.is_file():
                source = Path(__file__).resolve().parent.parent / "new" / name
            shutil.copy2(str(source), str(runtime / name))''', '''        for name in (SSOT_SYNC, "VRN2_SSOTSync_v0100.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py"):   # thin tails need their prior next to them
            shutil.copy2(str(selftest_source(name)), str(runtime / name))''')
rep('''        for name in (HISTORY_ALIGN, DATA_INTEGRATE, CONSENSUS_JOIN):
            source = Path(__file__).with_name(name)
            if not source.is_file():
                source = Path(__file__).resolve().parent.parent / "new" / name
            shutil.copy2(str(source), str(runtime / name))''', '''        for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))''')
# selftest additions: market_python + order check
rep('''    print("[PASS] v0146: ⑥e market fetch''', '''    saved = {k: os.environ.get(k) for k in ("VIA_FETCH_PY", "USERPROFILE", "HOME")}
    with tempfile.TemporaryDirectory(prefix="vrn2-v0147-check-") as temporary:
        home = Path(temporary)
        os.environ.pop("VIA_FETCH_PY", None)
        os.environ["USERPROFILE"] = str(home)
        os.environ["HOME"] = str(home)
        assert market_python() == sys.executable
        env_py = home / "envs" / "via_tw_fetch" / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
        env_py.parent.mkdir(parents=True)
        env_py.write_text("", encoding="utf-8")
        assert market_python() == str(env_py)
        os.environ["VIA_FETCH_PY"] = sys.executable
        assert market_python() == sys.executable
    for key, value in saved.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value
    body = Path(__file__).read_text(encoding="utf-8")
    assert body.index('receipt["history_align"] = history_align(') < body.index("    store = output_store(runtime, output,")
    print("[PASS] v0147: OutputStore v0101 / DataIntegrate v0101 / HistoryAlign v0101 · ⑥e fetch Python (VIA_FETCH_PY → via_tw_fetch → this) · --fill after a failed --fetch · ⑬b before ⑬ · selftest modules from the runtime zip · hermetic selftest env")
    print("[PASS] v0146: ⑥e market fetch''')
for bad in ('ActivateVRN-2 v0146"', '"VRN2_Closeout_v0146.json"', '"VRN2_Runtime_v0146.zip"', '"VRN2_Runtime_v0146.json"', "VRN-2 v0146 · rc", 'launcher v0146"', '"VRN2_OutputStore_v0100.py"\n', 'DATA_INTEGRATE = "VRN2_DataIntegrate_v0100.py"'):
    assert bad not in s, bad
(S / "v147/new/ActivateVRN-2_v0147.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0147", len(s.splitlines()), "lines")
