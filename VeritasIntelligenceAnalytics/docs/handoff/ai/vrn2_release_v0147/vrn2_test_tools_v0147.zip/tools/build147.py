"""v0147 整包重建(冪等):pkg147 → release zip/json → VRN2_RoundAll_v0100.py(填套件雜湊)+ 一行啟動 md → 一鍵 v0147 md → 操作員 v0108 md → LocalRound 改指。"""
import base64, hashlib, json, re, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); out, rel, op8, new = S / "v147/pkg147", S / "v147/release147", S / "v147/operator108", S / "v147/new"
rel.mkdir(exist_ok=True); op8.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
rt = json.loads((out / "VRN2_Runtime_v0147.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN2_OutputStore_v0101.py", "VRN2_DataIntegrate_v0101.py", "VRN2_HistoryAlign_v0101.py"]
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0147.py", "VRN2_Runtime_v0147.zip", "VRN2_Runtime_v0147.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0147 — VRN-2 closeout package (2026-10-29)\n\nEntry: python ActivateVRN-2_v0147.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0100.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.\n"
  "Runtime: VRN2_Runtime_v0147.zip = runtime v0146 (175 members byte-identical) + VRN2_OutputStore_v0101 + VRN2_DataIntegrate_v0101 + VRN2_HistoryAlign_v0101,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0147 (fixes found while building and testing the runner):\n"
  " - ⑬ long-term Parquet store keeps Combined · FinancialAligned · Deleted and back-fills per (book × source SHA): with all 52 desktop files already\n"
  "   known, v0100 would have stored 0 rows of the new books forever.\n"
  " - ⑬b history alignment runs before ⑬ so this run's FinancialAligned / Deleted reach the store.\n"
  " - ⑬c legacy-database scan: depth-limited walk (output folder 2 · its parent 1 · legacy_in 3 · 20,000 entries max) instead of rglob over the whole\n"
  "   OneDrive, and only VRN-2-like files are offered (≥ 3 mapped columns · FILENAME / TICKER · ITEM + VALUE for FinancialData).\n"
  " - ⑥e runs MarketFetch with the fetch Python (VIA_FETCH_PY → %USERPROFILE%\\envs\\via_tw_fetch); --fill still runs after a failed --fetch.\n"
  " - launcher --selftest takes its helper modules out of VRN2_Runtime_v0147.zip (v0144–v0146 selftests failed inside a real package folder) and clears run-time\n"
  "   switches while testing (v0144–v0146 failed their own checks whenever VRN2_OUTPUT_DIR or a limit was set in the shell).\n"
  " - ⑬b Deleted zone only for same-magnitude contradictions (HistoryAlign v0101): other-unit rows are matched, unclear-basis rows untouched, growth / % sections are ratios.\n"
  " - ⑬ the store appends per (book × source SHA × row-content hash): new books back-fill known files, and rows whose content changed (Combined prices) are appended.\n"
  "Verification: see VRN2_Verification_v0147.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0147.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0147", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0147.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0147/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll py:填套件雜湊 =====
ra_src = (new / "VRN2_RoundAll_v0100.py").read_text(encoding="utf-8")
assert ra_src.count('PACKAGE_SHA256 = "@PACKAGE_SHA256@"') == 1 or re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', ra_src)
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0100.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
ra_boot = """$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$R  = if ($env:VRN2_ROOT) { $env:VRN2_ROOT } else { 'C:\\Users\\tonyk\\OneDrive\\Documents\\movies-dataset\\VeritasIntelligenceAnalytics' }
$Br = 'claude/optimistic-goodall-yhalc5'
$P  = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0147'
$F  = 'VRN2_RoundAll_v0100.py'
$H  = '@RASHA@'
Write-Host ('[VRN-2] PowerShell ' + $PSVersionTable.PSVersion + ' · 從 GitHub 讀 VRN2_RoundAll_v0100.py(核對 SHA-256 後執行)') -ForegroundColor Yellow
$top = git -C $R rev-parse --show-toplevel 2>$null
if (-not $top) { Write-Host "[RED] $R 不是 git 倉或找不到 git(先設 `$env:VRN2_ROOT)" -ForegroundColor Red; exit 1 }
$top = "$top".Trim()
$t = Join-Path ([IO.Path]::GetTempPath()) ('vrn2_roundall_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Force -Path $t | Out-Null
$z = Join-Path $t 'roundall.zip'; $okz = $false
foreach ($b in $Br, 'main') {
  foreach ($w in 0, 2, 4, 8, 16) { if ($w) { Start-Sleep -Seconds $w }; git -C $top fetch -q origin $b 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { break } }
  git -C $top archive --format=zip -o $z ('origin/' + $b + ':' + $P) $F 2>&1 | Out-Null
  if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $z)) { $okz = $true; Write-Host ('[計] 來源 GitHub ' + $b) -ForegroundColor DarkGray; break }
}
if (-not $okz) { Write-Host "[RED] 讀不到 GitHub 分支 $Br 或 main 的 $F(網路 / git)" -ForegroundColor Red; exit 1 }
Expand-Archive -LiteralPath $z -DestinationPath $t -Force
$code = [IO.File]::ReadAllText((Join-Path $t $F), [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$bytes = (New-Object Text.UTF8Encoding($false)).GetBytes($code)
$sha = -join ([Security.Cryptography.SHA256]::Create().ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') })
if ($sha -ne $H) { Write-Host "[RED] $F SHA-256 不對($sha)· 不執行" -ForegroundColor Red; exit 1 }
$dst = Join-Path $env:USERPROFILE ('Downloads\\' + $F)
[IO.File]::WriteAllBytes($dst, $bytes)
$exe = if ($env:VRN2_PY) { $env:VRN2_PY } else { (Get-Command python, py -ErrorAction SilentlyContinue | Where-Object { $_.Source -notmatch 'WindowsApps' } | Select-Object -First 1).Source }
if (-not $exe) { Write-Host '[RED] 找不到 python(不要用 WindowsApps 的假 python)' -ForegroundColor Red; exit 1 }
Write-Host ('[GREEN] ' + $F + ' SHA-256 ' + $H.Substring(0, 12) + ' 相符 → ' + $dst + ' · 用 ' + $exe + ' 執行') -ForegroundColor Green
$ra = @($dst, '--root', $R)
if ($env:VRN2_ROUNDALL_ARGS) { $ra += ($env:VRN2_ROUNDALL_ARGS -split '\\s+' | Where-Object { $_ }) }
& $exe @ra
exit $LASTEXITCODE
""".replace("@RASHA@", ra_sha)
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii"); assert len(ra_one) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0100.py(取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯報告 → 貼回包)

操作員令(2026-10-29):「generate a py code to handle all above and fix all test all debug all」。本檔的 `VRN2_RoundAll_v0100.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪,
把本輪所有需求(Workbench 雙語表頭 / 靠上 / 百萬台幣千分位 / 自動縮放 / 左欄輸出夾 / 右欄去重矩陣 + 引擎狀態 / logo · ⑥e TWSE / TPEX / Yahoo · ⑥f FactSet / YFinance → Combined ·
⑬b 歷史對齊 · ⑬c 舊資料庫整合 · ⑬ 長線 Parquet 庫)跑起來、測過、修能修的、把修不了的說清楚。套件 = `VRN2_Closeout_v0147.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。

| 步驟 | 做什麼 | 不做什麼 |
|---|---|---|
| ⓪ VIA 根 | `--root` → `VRN2_ROOT` / `VIA_ROOT` → 本檔所在的倉 → 啟動器記的 `Downloads\\VRN2_Closeout_v0*\\VRN2_Runtime_Context.json` → vrn2:// 註冊 → `%USERPROFILE%\\OneDrive\\Documents\\movies-dataset\\VeritasIntelligenceAnalytics` | 找不到不猜:印出查過的地方 |
| ① 套件 | 本機 `Downloads\\VRN2_Closeout_v0147` 的 zip 雜湊對 + 逐檔對 → 直接用;否則 git archive 發行夾(分支 → main)→ 核對 → 解壓;本機夾有檔不對 → 整夾改名備份再解壓 | 不刪舊套件夾 |
| ② 診斷 | VRN-2 Python 的必裝套件 · 擷取 Python(`VIA_FETCH_PY` / `%USERPROFILE%\\envs\\via_tw_fetch`)的 yfinance 等 · 共用 MarketFetch / VDF 引擎 · 啟動器鎖 · 輸出夾可寫 · 來源夾 · 磁碟 · CPU(有 psutil 才量)· git | 不裝套件(缺的交 VCGC,照印指令)|
| ③ 自測 | runtime zip 解到 TEMP(逐檔核對)→ Workbench v0102 · HistoryAlign · DataIntegrate v0100 / v0101 · UIAction v0109 · SSOTSync v0101 · OutputStore v0101 · ConsensusJoin · 管理器 v0255 各 `--selftest` + 啟動器 `--selftest` | 不碰真資料 |
| ④ 跑 | `ActivateVRN-2_v0147.py`(預設不上船 `VIA_VRN2_NO_PUSH=1`)· 逐行即時印 · 60 秒沒輸出印心跳 · 另一個啟動器在跑就不跑 | `--ship` 才推 |
| ⑤ 自動修 | ⑥e 用錯 Python 而擷取 Python 套件齊 → 重抓 · 找到有 yfinance 的 Python → 重跑 ⑥f · 市場資料比歷史對齊新 → 重跑 ⑬b · Combined 舊 → 重組 · 有修 → ⑬ 增量庫補寫 → Workbench 重渲染 · 舊資料庫待決定 → 問你(`--integrate`)· 過期鎖 → 清 | 收尾收據先備份成 `.before_roundall.json` 再標註;不刪任何資料 |
| ⑥ 除錯 | 每個非綠步驟 + 下一步 · 四點原文核對不過的檔 / 點 · 輸出缺項 · 完成判定 · 冪等閘 · 階段耗時前三 · Combined 欄序 / 空格 · Workbench 標記 · 市場 / 歷史對齊 / 增量庫 / 整合 / SSOT → `VIA_Reports\\vrn2\\VRN2_RoundAll_latest.json` | — |
| ⑦ 貼回包 | `Downloads\\VRN2_PasteBack_<時間>.zip`:逐字稿 · 最後 300 行 · 各收據 · Combined / 四本冊 csv · Workbench · 獨立驗證摘要 | — |

結束碼 0 綠 · 2 黃 · 1 紅;最後一行 `NEXT: [燈] …`。

## 在 cmd 或 PowerShell 貼這一行(建議)

它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)取 `VRN2_RoundAll_v0100.py` → **核對 SHA-256**(`@RASHA12@`)→ 存到 `Downloads` → 用你的 python 執行。
VIA 根不在預設位置就先設 `$env:VRN2_ROOT`(cmd:`set VRN2_ROOT=…`);要帶參數就設 `$env:VRN2_ROUNDALL_ARGS`(例:`--integrate yes --source C:\\測試樣本報告`)。

```bat
@ONE@
```

## 已經有這個檔時

```bat
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0100.py"
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0100.py" --skip-run --integrate yes        :: 不重跑,只修 + 除錯 + 打包(例:剛在別處裝好 yfinance)
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0100.py" --only preflight,selftest         :: 只診斷 + 自測
```

常用參數:`--source <報告夾>` · `--integrate ask|yes|no|skip`(舊資料庫)· `--no-open` · `--ship`(允許上船)· `--offline`(不連 GitHub)· `--python <VRN-2 的 python>` · `--skip-selftest` · `--selftest`(本檔自測)。

## 一行解開來的程式碼(核對用)

```text
@BOOT@
```
"""
ra_md = ra_md.replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
(rel / "VRN2_RoundAll_v0100.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0147 + VRN2_RoundAll_v0100", "date": "2026-10-29",
       "trigger": "操作員 2026-10-29:「generate a py code to handle all above and fix all test all debug all」→ 一支 Python VRN2_RoundAll_v0100.py(取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯 → 貼回包)+ 做它、測它時抓到的缺陷修成 v0147(見 fixes)",
       "base_package": {"name": "VRN2_Closeout_v0146 (launcher v0146 · runtime v0146)", "retained": "runtime v0146 members byte-identical inside runtime v0147; ActivateVRN-2_v0136.py base unchanged"},
       "supersedes": "v0146 for the closeout entry; VRN-2 one-click v0146; operator one-click v0107 → v0108",
       "fixes": {"OutputStore_v0101": "new books Combined / FinancialAligned / Deleted + per (book × source SHA) back-fill (v0100 stored 0 rows of new books once all files were known)",
                 "launcher_v0147_13b_before_13": "history alignment before the store so FinancialAligned / Deleted of this run are stored",
                 "DataIntegrate_v0101": "depth-limited scandir walk (no rglob over the OneDrive root) + only VRN-2-like files are offered",
                 "launcher_v0147_6e": "MarketFetch runs with the fetch Python (pandas for --fill) · --fill also after a failed --fetch",
                 "launcher_v0147_selftest": "helper modules from the runtime zip (v0144–v0146 selftest raised FileNotFoundError inside a real package folder) + hermetic env (VRN2_OUTPUT_DIR / limits / opt-outs cleared while testing)",
                 "HistoryAlign_v0101": "Deleted zone only for same-magnitude contradictions; other-unit rows matched; unclear-basis rows untouched; growth / % sections are ratios (100 → 39 deleted on the same data)",
                 "OutputStore_v0101_row_hash": "append per (book × source SHA × row-content hash) so later Combined price / consensus updates reach the long-term store; old rows kept",
                 "RoundAll_launcher_args": "--launcher-args with a value starting with - is accepted"},
       "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
       "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0147.json inside the package"},
       "roundall": {"name": "VRN2_RoundAll_v0100.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0100.md"},
       "tested_in": "Linux container · python 3.13 venv_vrn2 (pyarrow · no duckdb · no yfinance) + venv_duck (duckdb 1.5.6) · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0147.md"},
       "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0147/<files> (no .ps1 · the one-click md / RoundAll py are the entries)"},
       "launcher": {"name": "ActivateVRN-2_v0147.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0147.py"]).hexdigest()},
       "oneclick": "VRN2_OneClick_v0147.md", "test_tools_zip": "vrn2_test_tools_v0147.zip", "logs_zip": "logs_v0147.zip"}
(rel / "VRN2_Release_v0147.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
# ===== one-click v0147 from v0146 =====
md = (REPO / "vrn2_release_v0146/VRN2_OneClick_v0146.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); old_cs = hashlib.sha256(ps.encode("utf-8")).hexdigest(); assert old_cs in boot
def rep(a, b):
    global ps
    assert ps.count(a) == 1, (ps.count(a), a[:80]); ps = ps.replace(a, b)
def rrep(pat, b):
    global ps
    assert len(re.findall(pat, ps)) == 1, (len(re.findall(pat, ps)), pat[:80]); ps = re.sub(pat, lambda m: b, ps)
rrep(r"  \$Want   = '[0-9a-f]{64}'   # VRN2_Closeout_v0146\.zip SHA-256[^\n]*", "  $Want   = '%s'   # VRN2_Closeout_v0147.zip SHA-256(套件 · 內含啟動器 v0147 + runtime v0147 清單 = v0146 + OutputStore v0101 · DataIntegrate v0101)" % want)
rep("[計] VRN-2 一鍵 v0146 · ActivateVRN-2 v0146(套件 · 私有 runtime v0146 = v0145 + ",
    "[計] VRN-2 一鍵 v0147 · ActivateVRN-2 v0147(套件 · 私有 runtime v0147 = v0146 + OutputStore v0101(長線 Parquet 庫收 Combined / FinancialAligned / Deleted · 依冊補缺)· DataIntegrate v0101(限深掃描 · 只問像 VRN-2 的檔);⑬b 移到 ⑬ 前 · ⑥e 用擷取 Python;另有一支 Python VRN2_RoundAll_v0100.py 跑全流程;v0146 = v0145 + ")
rep("  # ===== VRN-2 一鍵 v0146(套件 v0146 = 啟動器 v0146 + runtime v0146 = v0145 + 8 個新成員;",
    "  # ===== VRN-2 一鍵 v0147(套件 v0147 = 啟動器 v0147 + runtime v0147 = v0146 + OutputStore v0101 + DataIntegrate v0101;v0147 = 做一支 Python 全流程 VRN2_RoundAll_v0100.py 時測出的修正:長線庫收新冊並補缺 · ⑬b 在 ⑬ 前 · 整合掃描限深 + 只問像 VRN-2 的檔 · ⑥e 用擷取 Python · 自測從 runtime zip 取模組;v0146 = 套件 v0146 = 啟動器 v0146 + runtime v0146 = v0145 + 8 個新成員;")
rep('cl = j(v2 / "VRN2_Closeout_v0146.json") or {}', 'cl = j(v2 / "VRN2_Closeout_v0147.json") or {}')
rep('"%s|⑧b 收尾收據 v0146 · rc %s', '"%s|⑧b 收尾收據 v0147 · rc %s')
rep('"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0146.json(啟動器 v0146 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"', '"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0147.json(啟動器 v0147 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"')
rep('print("GRAY|%s · 收據沒有這一欄(啟動器不是 v0146)" % lb_)', 'print("GRAY|%s · 收據沒有這一欄(啟動器不是 v0146 以後)" % lb_)\nprint("GRAY|更完整的除錯 / 自動修 / 貼回包:python VRN2_RoundAll_v0100.py --skip-run(見 vrn2_release_v0147/VRN2_RoundAll_v0100.md)")')
rep('"③ 本機套件不是 v0146,且讀不到', '"③ 本機套件不是 v0147,且讀不到'); rep('"③ 本機已是 v0146 套件(', '"③ 本機已是 v0147 套件(')
rep("($cf.version -eq 'ActivateVRN-2 v0146')", "($cf.version -eq 'ActivateVRN-2 v0147')")
for a, b in (("VRN2_Closeout_v0146", "VRN2_Closeout_v0147"), ("vrn2_release_v0146", "vrn2_release_v0147"), ("ActivateVRN-2_v0146", "ActivateVRN-2_v0147"), ("VRN-2 一鍵 v0146 跑完", "VRN-2 一鍵 v0147 跑完"), ("vrn2_v0146_", "vrn2_v0147_"), ("套件 v0146 就位", "套件 v0147 就位"), ("啟動器 v0146 依 MAIN", "啟動器 v0147 依 MAIN"), ("# v0146 發行所在", "# v0147 發行所在"), ("VRN2_Handover_v0147", "VRN2_Handover_v0148"), ("VRN2_Release_v0146", "VRN2_Release_v0147"), ("Downloads\\VRN2_Closeout_v0146'", "Downloads\\VRN2_Closeout_v0147'"), ("套件夾(啟動器 v0146 +", "套件夾(啟動器 v0147 +"), ("VRN2_UIAction_Config.json v0146", "VRN2_UIAction_Config.json v0147")):
    ps = ps.replace(a, b)
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0146" in code and "v0146 =" not in code and "v0146 以後" not in code), line[:200]
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(old_cs, cs).replace("vrn2_release_v0146", "vrn2_release_v0147").replace("VRN2_OneClick_v0146.md", "VRN2_OneClick_v0147.md").replace("v0146", "v0147") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = md.replace("```powershell\n" + re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + re.search(r"(?s)```text\n(.*?)\n```", md).group(1) + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + re.search(r"(?s)```bat\n(.*?)\n```", md).group(1) + "\n```", "```bat\n@ONE@\n```")
head = head.replace(old_want, "@WANT@").replace(old_cs, "@CS@").replace(old_cs[:12], "@CS@")
def hrep(a, b):
    global head
    assert head.count(a) == 1, (head.count(a), a[:80]); head = head.replace(a, b)
def hline(prefix, b):
    global head
    ls = head.split("\n"); idx = [i for i, l in enumerate(ls) if l.startswith(prefix)]; assert len(idx) == 1, (prefix, idx); ls[idx[0]] = b; head = "\n".join(ls)
hline("# VRN-2 一鍵 v0146(", "# VRN-2 一鍵 v0147(cmd / PowerShell 都能貼 · 套件 v0147 = 啟動器 v0147 + runtime v0147 = v0146 + OutputStore v0101 · DataIntegrate v0101)")
hrep("v0146 = v0145 入口 + runtime v0146(= runtime v0145 的 167 個成員逐位元保留 + 8 個新檔):",
     "操作員 2026-10-29:「generate a py code to handle all above and fix all test all debug all」→ 一支 Python **`VRN2_RoundAll_v0100.py`**(同發行夾 · 用法見 `VRN2_RoundAll_v0100.md`:取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯報告 → 貼回包)。做它、測它時抓到的缺陷,修成 v0147:\n\n"
     "v0147 = v0146 入口 + runtime v0147(= runtime v0146 的 175 個成員逐位元保留 + 3 個新檔):\n\n| 元件 | 版本 | 修了什麼 |\n|---|---|---|\n"
     "| 長線 Parquet 庫 ⑬ | VRN2_OutputStore v0101(v0100 留著)| 多收 Combined · FinancialAligned · Deleted;追加規則改成「這本冊裡還沒有 (原檔 SHA-256, 列內容雜湊) 這一列」—— v0100 只追加沒見過的原檔,桌機 52 份都已知 → 新冊永遠 0 列、Combined 隔天更新的還原價 / 共識也進不了庫;同內容再跑仍 0 列 · 舊列保留 · 舊庫(沒有 row_sha)照算 · 收據多 `backfilled` |\n"
     "| 歷史對齊 ⑬b | VRN2_HistoryAlign v0101(v0100 留著)| 刪除區只收「同數量級(比值 0.5 ~ 2)卻差 > 3%」的列;別的單位對得上 → 覆蓋不刪;比值差太遠 → 口徑不明,不覆蓋不刪;成長率 / 占比段落當比率列 —— 同一份資料刪除區 100 → 39 列(那 61 列是別的單位 / 成長率表)|\n"
     "| 舊資料庫整合 ⑬c | VRN2_DataIntegrate v0101(v0100 留著)| 走訪有深度上限(輸出夾 2 層 · 它的上一層 1 層 · legacy_in 3 層 · 每夾最多 20,000 項)—— v0100 用 rglob 走整棵樹,輸出夾在 OneDrive 時上一層就是整個 OneDrive;只問像 VRN-2 冊的檔(對到 ≥ 3 欄 · 有 FILENAME / TICKER · 年度數據要有 ITEM + VALUE),家用記帳之類略過 |\n"
     "| 啟動器 | ActivateVRN-2 v0147 | ⑬b 歷史對齊移到 ⑬ 之前(本輪的 FinancialAligned / Deleted 才進得了庫)· ⑥e 用擷取 Python 跑 MarketFetch(`--fill` 要 pandas)· `--fetch` 失敗 / 逾時仍跑 `--fill` · `--selftest` 從套件的 runtime zip 取模組(v0144 ~ v0146 的自測在真套件夾會 FileNotFoundError)、自測時清掉會改行為的環境變數(設了 `VRN2_OUTPUT_DIR` 的殼裡 v0144 ~ v0146 的自測會自己失敗)· 收據 `VRN2_Closeout_v0147.json` |\n\n"
     "前一版 v0146 = v0145 入口 + runtime v0146(= runtime v0145 的 167 個成員逐位元保留 + 8 個新檔):")
hrep("| 啟動器 | ActivateVRN-2 v0146 |", "| 啟動器(v0146)| ActivateVRN-2 v0146 |")
hrep("| 步驟 | v0146 做什麼 |", "| 步驟 | v0147 做什麼 |")
hrep("| ① ② ③ ③b | 同 v0145(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|", "| ① ② ③ ③b | 同 v0146(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|")
hline("| ④ | `python ActivateVRN-2_v0146.py", "| ④ | `python ActivateVRN-2_v0147.py [--source …]`:單機閘 → ①~⑤ → ⑤b SSOT-ID 核號同步(含提案冊)→ ⑥ → ⑦(管理器 v0255)→ ⑥e 市場擷取(擷取 Python)→ ⑥f 共識合併(Combined 冊)→ ⑧~⑫ → ⑫b 補放 → 四點原文核對 → 收據 → **⑬b 歷史對齊 → ⑬ 輸出位置 · 長線 Parquet 庫(七冊 · 補缺)** → ⑬c 舊資料庫整合掃描(限深)→ Workbench v0102 渲染 + 開啟 |")
hline("| ⑤ | 摘要多七行", "| ⑤ | 摘要多七行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID · 階段耗時 · ⑥e 市場擷取 · ⑥f 共識合併 · ⑬b 歷史對齊 · ⑬c 舊資料庫整合(都讀 `VRN2_Closeout_v0147.json`)+ 一行指向 `VRN2_RoundAll_v0100.py` |")
hline("| ⑤b ⑤c |", "| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\\\VRN2\\\\VRN2_UIAction_v0109.py`(設定檔 v0147 · `vrn2://integrate` 取最新的 DataIntegrate = v0101)· U/I 有輸入區塊 · 沒開就代開 |")
hrep("VRN-2 主體(ENG397 · 摘要器 · 驗證器 · 工具橋 · OCR 橋 · 管理器 v0255)與 runtime v0145 的 167 個成員一個位元組都不動", "VRN-2 主體(ENG397 · 摘要器 · 驗證器 · 工具橋 · OCR 橋 · 管理器 v0255)與 runtime v0146 的 175 個成員一個位元組都不動(OutputStore / DataIntegrate / HistoryAlign 的 v0100 留著,v0101 薄尾疊上)")
for a, b in (("VRN2_OneClick_v0146", "VRN2_OneClick_v0147"), ("vrn2_release_v0146", "vrn2_release_v0147"), ("VRN2_Closeout_v0146.zip", "VRN2_Closeout_v0147.zip"), ("Downloads\\VRN2_Closeout_v0146", "Downloads\\VRN2_Closeout_v0147")):
    head = head.replace(a, b)
(S / "v147/oneclick147_head.md").write_text(head, encoding="utf-8", newline="\n")
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and "@" + "WANT@" not in newmd
(rel / "VRN2_OneClick_v0147.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot147.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline147.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0147.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0147", cs[:12])
# ===== operator v0108 from v0107 =====
md7 = (REPO / "vrn1_vrn2_oneclick_v0107/VRN1_VRN2_OneClick_v0107.md").read_text(encoding="utf-8")
ps7 = re.search(r"(?s)```powershell\n(.*?)\n```", md7).group(1); boot7 = re.search(r"(?s)```text\n(.*?)\n```", md7).group(1); one7 = re.search(r"(?s)```bat\n(.*?)\n```", md7).group(1)
p8 = ps7
def rep8(a, b):
    global p8
    assert p8.count(a) == 1, (p8.count(a), a[:80]); p8 = p8.replace(a, b)
rep8("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0146'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0147'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0146 程式碼 SHA-256", p8).group(1); assert old_h2 == old_cs
rep8("  $H2 = '%s'   # VRN-2 一鍵 v0146 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0147 程式碼 SHA-256" % cs)
rep8("  # ===== VRN-1 / VRN-2 操作員一鍵 v0107(2026-10-29 · ② 改指 VRN-2 一鍵 v0146:",
     "  # ===== VRN-1 / VRN-2 操作員一鍵 v0108(2026-10-29 · ② 改指 VRN-2 一鍵 v0147:長線庫收新冊並補缺 · ⑬b 在 ⑬ 前 · 整合掃描限深 · ⑥e 用擷取 Python · 自測從 runtime zip 取模組;另有一支 Python VRN2_RoundAll_v0100.py;v0107 · ② 改指 VRN-2 一鍵 v0146:")
rep8("操作員一鍵 v0107 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0108 · {0} · VRN-1 {1} · VIA {2}")
p8 = p8.replace("VRN2_OneClick_v0146.md", "VRN2_OneClick_v0147.md").replace("VRN-2 一鍵 v0146", "VRN-2 一鍵 v0147").replace("套件 v0146 = 啟動器 v0146 + runtime v0146", "套件 v0147 = 啟動器 v0147 + runtime v0147").replace("ActivateVRN-2_v0146 單機閘", "ActivateVRN-2_v0147 單機閘")
assert p8.count("v0107 · ② 改指 VRN-2 一鍵 v0147:") == 1; p8 = p8.replace("v0107 · ② 改指 VRN-2 一鍵 v0147:", "v0107 · ② 改指 VRN-2 一鍵 v0146:")
for line in p8.splitlines():
    code = line.split("#", 1)[0]; assert "v0146" not in code or "v0146:" in code, line[:160]
cs8 = hashlib.sha256(p8.encode("utf-8")).hexdigest()
boot8 = boot7.replace(re.search(r"\$H  = '([0-9a-f]{64})'", boot7).group(1), cs8).replace("vrn1_vrn2_oneclick_v0107", "vrn1_vrn2_oneclick_v0108").replace("VRN1_VRN2_OneClick_v0107.md", "VRN1_VRN2_OneClick_v0108.md").replace("操作員一鍵 v0107", "操作員一鍵 v0108") + "\n"
one8 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot8.encode("utf-16-le")).decode("ascii")
text = md7.replace("```powershell\n" + ps7 + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + boot7 + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + one7 + "\n```", "```bat\n@ONE@\n```")
old_cs7 = hashlib.sha256(ps7.encode("utf-8")).hexdigest()
text = text.replace(old_cs7, cs8).replace(old_cs7[:12], cs8[:12]).replace(old_h2, cs).replace(old_h2[:12], cs[:12]).replace("v0107", "v0108").replace("VRN-2 一鍵 v0146", "VRN-2 一鍵 v0147").replace("vrn2_release_v0146", "vrn2_release_v0147").replace("VRN2_OneClick_v0146", "VRN2_OneClick_v0147")
head_old = text.split("\n", 1)[0]; text = text.replace(head_old, "# VRN-1 / VRN-2 操作員一鍵 v0108(cmd / PowerShell 都能貼 · v0107 + ② 改指 VRN-2 一鍵 v0147:長線庫收新冊並補缺 · ⑬b 在 ⑬ 前 · 整合掃描限深 · ⑥e 用擷取 Python)", 1)
intro_old = text.split("\n\n", 2)[1]; text = text.replace(intro_old, "操作員 2026-10-29「generate a py code to handle all above and fix all test all debug all」→ 一支 Python `VRN2_RoundAll_v0100.py`(`vrn2_release_v0147`)+ 修成 VRN-2 v0147。v0108 = v0107 + ② 改指 **VRN-2 一鍵 v0147**(套件 v0147 = 啟動器 v0147 + runtime v0147 = v0146 + OutputStore v0101 · DataIntegrate v0101);其餘一字不改。\n\n" + intro_old, 1)
text = text.replace("@PS@", p8).replace("@BOOT@", boot8.rstrip("\n")).replace("@ONE@", one8)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p8 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot8
(op8 / "VRN1_VRN2_OneClick_v0108.md").write_text(text, encoding="utf-8", newline="\n"); (op8 / "boot_pair108.ps1").write_text(boot8, encoding="utf-8", newline="\n"); (op8 / "oneline_pair108.txt").write_text(one8 + "\n", encoding="utf-8"); (op8 / "Run-VRN1-VRN2-v0108.ps1").write_text(p8 + "\n", encoding="utf-8", newline="\n"); (op8 / "code_sha.txt").write_text(cs8)
(op8 / "VRN1_VRN2_Verification_v0108.md").write_text(
    "# VRN-1 / VRN-2 操作員一鍵 v0108 · 容器驗證(2026-10-29)\n\nv0108 = v0107 的程式碼只改三處:② 發行夾 `vrn2_release_v0146` → `vrn2_release_v0147`、`$H2` → VRN-2 一鍵 v0147 程式碼 SHA-256(`%s`)、橫幅「操作員一鍵 v0107」→「v0108」;歷史子句(v0107 · ② 改指 VRN-2 一鍵 v0146 …)照舊。\n\n"
    "| 檢查 | 結果 |\n|---|---|\n| pwsh 7.4.6 語法剖析(Run-VRN1-VRN2-v0108.ps1 · boot_pair108.ps1)| 見 `vrn2_release_v0147/logs_v0147.zip` 的 `pscheck147.log` |\n| 本段程式碼 SHA-256 = boot 裡的 `$H` | 同上 |\n| 一行(-EncodedCommand)解碼 = boot | 同上 |\n"
    "| `$H2` = `VRN2_OneClick_v0147.md` 程式碼 SHA-256 | 同上 |\n| 橫幅版號 | `操作員一鍵 v0108` |\n| 本地實測一輪 v0100 的 `$H_OP` = 本段程式碼 SHA-256 | 同上 |\n\n沒有 .ps1 進倉:一鍵程式碼只在本夾的 md 裡,`tools_v0108.zip` 是容器測試用副本。\n" % cs[:12], encoding="utf-8", newline="\n")
print("operator v0108", cs8[:12])
# ===== LocalRound re-point =====
lr = REPO / "VRN2_LocalRound_v0100.md"; s = lr.read_text(encoding="utf-8")
if "VRN1_VRN2_OneClick_v0108.md" in s:
    s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0108 程式碼 SHA-256", "$H_OP = '%s'   # 操作員一鍵 v0108 程式碼 SHA-256" % cs8, s, count=1); assert cs8 in s
    lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP refreshed", cs8[:12]); raise SystemExit(0)
def lrep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
lrep("# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0146(開 Workbench)→ 打包貼回材料)", "# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0147(開 Workbench)→ 打包貼回材料)")
lrep("> **2026-10-29 v0146 改指(", "> **2026-10-29 v0147 改指(操作員「generate a py code to handle all above and fix all test all debug all」):** 本段現在指 操作員一鍵 **v0108** → VRN-2 一鍵 **v0147**(長線 Parquet 庫收 Combined / FinancialAligned / Deleted 並補缺 · ⑬b 在 ⑬ 前 · 舊資料庫掃描限深 + 只問像 VRN-2 的檔 · ⑥e 用擷取 Python · 自測從 runtime zip 取模組)。另有一支 Python **`vrn2_release_v0147/VRN2_RoundAll_v0100.py`** 跑全流程(取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯 → 貼回包 · 用法見同夾 `VRN2_RoundAll_v0100.md`);本段 ④ 貼回包多收 `VRN2_RoundAll_latest.json`。\n> **2026-10-29 v0146 改指(")
lrep("本段現在指 操作員一鍵 **v0107** → VRN-2 一鍵 **v0146**", "本段當時指 操作員一鍵 **v0107** → VRN-2 一鍵 **v0146**")
lrep("從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0107.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0146 套件**(啟動器 v0146 → ", "從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0108.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0147 套件**(啟動器 v0147 → 長線庫收新冊並補缺 · ⑬b 在 ⑬ 前 · 整合掃描限深;v0146 的 ")
lrep("最後 300 行貼包 · `VRN2_Closeout_v0146.json` ·", "最後 300 行貼包 · `VRN2_Closeout_v0147.json` · `VRN2_RoundAll_latest.json` ·")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0107 程式碼 SHA-256\(VRN1_VRN2_OneClick_v0107\.md powershell 區塊 · ② 指 VRN-2 一鍵 v0146\)", "$H_OP = '%s'   # 操作員一鍵 v0108 程式碼 SHA-256(VRN1_VRN2_OneClick_v0108.md powershell 區塊 · ② 指 VRN-2 一鍵 v0147)" % cs8, s, count=1); assert cs8 in s
lrep("  $k3 = '③ 跑 VRN-2 v0146'", "  $k3 = '③ 跑 VRN-2 v0147'")
lrep("  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0107' 'VRN1_VRN2_OneClick_v0107.md' $H_OP", "  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0108' 'VRN1_VRN2_OneClick_v0108.md' $H_OP")
lrep("  foreach ($rel in 'VRN2_Closeout_v0146.json',", "  foreach ($rel in 'VRN2_Closeout_v0147.json', 'VRN2_RoundAll_latest.json',")
lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP", cs8[:12])
