import hashlib, json, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); old, new, out = S / "v146/pkg146", S / "v147/new", S / "v147/pkg147"
om = json.loads((old / "VRN2_Runtime_v0146.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
with zipfile.ZipFile(old / "VRN2_Runtime_v0146.zip") as z: members = {n: z.read(n) for n in old_names}
for e in om["files"]: assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"]
new_names = ["VRN2_OutputStore_v0101.py", "VRN2_DataIntegrate_v0101.py", "VRN2_HistoryAlign_v0101.py"]
for n in new_names: assert n not in members, n; members[n] = (new / n).read_bytes()
for n in ("VRN2_OutputStore_v0100.py", "VRN2_DataIntegrate_v0100.py", "VRN2_HistoryAlign_v0100.py"): assert members[n] == (new / n).read_bytes(), n   # priors byte-identical
names = sorted(members); zp = out / "VRN2_Runtime_v0147.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0147", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0146.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names, "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0147.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
print("runtime v0147", len(names), man["zip_sha256"][:12])
