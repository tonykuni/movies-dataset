#!/bin/bash
# v0147 放進倉:docs/handoff/ai/vrn2_release_v0147/ + vrn1_vrn2_oneclick_v0108/ + functional modules/VRN/ 新工具(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v147
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0147; OP=$REPO/vrn1_vrn2_oneclick_v0108; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v147")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0147"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0108")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("ra147_first.log", "ra147_fix.log", "ra147.rc", "t147ra_setup.log", "pscheck147.log", "scen147.rc", "scen147_first.log", "scen147_again.log", "scen147_tamper.log", "scen147_setup.log", "roundall_selftest.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0147_selftest.log", "ActivateVRN-2_v0147_selftest_iso.log", "VRN2_OutputStore_v0101_selftest.log", "VRN2_OutputStore_v0101_selftest_duckdb.log", "VRN2_DataIntegrate_v0101_selftest.log", "VRN2_HistoryAlign_v0101_selftest.log", "run_roundall147.sh")]
v2 = W / "t147ra/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0147.json", "VRN2_Closeout_v0147.before_roundall.json", "VRN2_RoundAll_latest.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Output_Config.json", "VRN2_Phase_Timing_latest.json", "VRN2_HistoryAlign_latest.json", "VRN2_Integrate_latest.json", "consensus/VRN2_Consensus_latest.json", "market/VRN2_Market_latest.json", "output/VRN2_Combined_latest.csv", "output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "VRN2_Workbench_latest.html"):
    logs.append(("t147ra/" + n, v2 / n))
for n in ("VRN2_NUMBER_REQUEST_latest.json", "VRN2_NUMBER_STATE_latest.json"):
    logs.append(("t147ra/contract/" + n, W / "t147ra/VIA/functional modules/VRN2/contract" / n))
z(D / "logs_v0147.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))] + [("release/" + q.name, q) for q in (W / "release147" / "boot_roundall.ps1", W / "release147" / "oneline_roundall.txt", W / "release147" / "Run-VRN2-v0147.ps1", W / "release147" / "boot147.ps1")]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py")) if q.name in ("VRN2_OutputStore_v0101.py", "VRN2_DataIntegrate_v0101.py", "VRN2_HistoryAlign_v0101.py", "ActivateVRN-2_v0147.py", "VRN2_RoundAll_v0100.py")]
z(D / "vrn2_test_tools_v0147.zip", tools)
z(OP / "tools_v0108.zip", [("tools/" + q.name, q) for q in (W / "operator108" / "boot_pair108.ps1", W / "operator108" / "oneline_pair108.txt", W / "operator108" / "Run-VRN1-VRN2-v0108.ps1")])
for n in ("VRN1_VRN2_OneClick_v0108.md", "VRN1_VRN2_Verification_v0108.md"): shutil.copy(W / "operator108" / n, OP / n)
for n in ("VRN2_Closeout_v0147.zip", "VRN2_Release_v0147.json", "VRN2_OneClick_v0147.md", "VRN2_Verification_v0147.md", "VRN2_RoundAll_v0100.py", "VRN2_RoundAll_v0100.md"): shutil.copy(W / "release147" / n, D / n)
# 新成員只在私有 runtime zip(functional modules/VRN2)與 vrn2_test_tools_v0147.zip/new;不放共用 VRN 夾;VRN2_RoundAll_v0100.py 放發行夾(一支入口)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
