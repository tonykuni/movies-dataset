import importlib.util, json, sys, tempfile
from pathlib import Path
N = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v147/new")
def load(name, alias):
    sp = importlib.util.spec_from_file_location(alias, N / name); m = importlib.util.module_from_spec(sp); sys.modules[alias] = m; sp.loader.exec_module(m); return m
old = load("VRN2_OutputStore_v0100.py", "old_store")
with tempfile.TemporaryDirectory() as td:
    td = Path(td); v2 = td / "VIA_Reports" / "vrn2"; (v2 / "output").mkdir(parents=True); (v2 / "scope_in").mkdir()
    for n in ("a.pdf", "b.pdf"): (v2 / "scope_in" / n).write_bytes(n.encode())
    rows = {"BasicInfo": [{"FILENAME": "a.pdf", "TICKER": "2330", "_STATUS": {"X": "Y"}}, {"FILENAME": "b.pdf", "TICKER": "2454"}], "FinancialData": [{"FILENAME": "a.pdf", "ITEM": "Rev", "VALUE": "1,000", "PAGE": 3}], "Summary": [], "Rejected": []}
    for k, r in rows.items(): (v2 / "output" / ("VRN2_%s_latest.json" % k)).write_text(json.dumps(r), encoding="utf-8")
    out = td / "out"
    r0 = old.sync(v2, out, "v0100run")
    new = load("VRN2_OutputStore_v0101.py", "new_store")
    (v2 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TARGET_PRICE": "1"}]), encoding="utf-8")
    r1 = new.sync(v2, out, "v0101run")
    print(r0["store_engine"], "v0100 totals", r0["totals"], "→ v0101 appended", r1["appended"], "totals", r1["totals"])
    ok = r1["appended"]["BasicInfo"] == 0 and r1["appended"]["FinancialData"] == 0 and r1["appended"]["Combined"] == 1
    print("COMPAT", "PASS" if ok else "FAIL")
