"""收尾 v0147:results → VRN2_Release_v0147.json.results · VRN2_Verification_v0147.md(套件 zip 已定,不重算)。"""
import glob, json, re, zipfile
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v147")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def lines(p):
    try: return [l for l in Path(p).read_text(encoding="utf-8", errors="replace").splitlines() if "<Objs" not in l and "</S>" not in l and "<S N=" not in l]
    except OSError: return []
def grep(p, pat, all_=False):
    hits = [l for l in lines(p) if re.search(pat, l)]
    return hits if all_ else (hits[-1] if hits else "")
def esc(x): return str(x).replace("|", "\\|")
v2 = W / "t147ra/VIA/VIA_Reports/vrn2"
ra1 = W / "ra147_first.log"; ra2 = W / "ra147_fix.log"
top = lambda p: [l for l in lines(p) if re.match(r"^\[(GREEN|YELLOW|RED|GRAY)\] |^NEXT:|^總表", l)]
first_rows, fix_rows = top(ra1), top(ra2)
def count(rows):
    c = {k: sum(1 for l in rows if l.startswith("[%s]" % k)) for k in ("GREEN", "YELLOW", "RED", "GRAY")}
    return c
reds1 = [l[:200] for l in first_rows if l.startswith("[RED]")]
st = j(v2 / "VRN2_OutputStore_latest.json", {}) or {}; hist = j(v2 / "VRN2_HistoryAlign_latest.json", {}) or {}; integ = j(v2 / "VRN2_Integrate_latest.json", {}) or {}
comb = j(v2 / "output/VRN2_Combined_latest.json", []) or []; cl = j(v2 / "VRN2_Closeout_v0147.json", {}) or {}
zips = sorted(glob.glob(str(W / "t147ra/Downloads/VRN2_PasteBack_*.zip")))
pz = zipfile.ZipFile(zips[-1]).namelist() if zips else []
selft = {n: grep(W / f, r"--selftest · .*不過 0|\[PASS\] v0147") [:200] for n, f in (("VRN2_RoundAll_v0100", "roundall_selftest.log"), ("VRN2_OutputStore_v0101 · pyarrow", "VRN2_OutputStore_v0101_selftest.log"), ("VRN2_OutputStore_v0101 · duckdb", "VRN2_OutputStore_v0101_selftest_duckdb.log"), ("VRN2_DataIntegrate_v0101", "VRN2_DataIntegrate_v0101_selftest.log"), ("VRN2_HistoryAlign_v0101", "VRN2_HistoryAlign_v0101_selftest.log"), ("ActivateVRN-2_v0147(建置夾)", "ActivateVRN-2_v0147_selftest.log"), ("ActivateVRN-2_v0147(真套件 zip 解到隔離夾 · VRN2_OUTPUT_DIR 已設)", "ActivateVRN-2_v0147_selftest_iso.log"))}
c1, c2 = count(first_rows), count(fix_rows)
st_rows = [l for l in first_rows if "③ 自測 ·" in l]; st_green = sum(1 for l in st_rows if l.startswith("[GREEN]"))
red_names = sorted({re.sub(r"^\[RED\] ", "", l).split(" · ")[0] for l in reds1})
skipped = [Path(str(s_.get("path", ""))).name for s_ in (integ.get("skipped") or [])]
e2e = {"summary": "RoundAll 全流程 %s(綠 %d · 黃 %d · 紅 %d · 灰 %d)· ③ 自測 %d 支 · 綠 %d · 紅的步驟:%s · Combined %d 列 · 整合 %s(套用 %d · 略過 %s)"
              % (re.sub(r" · 貼回包 .*", "", grep(ra1, r"^NEXT:")), c1["GREEN"], c1["YELLOW"], c1["RED"], c1["GRAY"], len(st_rows), st_green, " / ".join(red_names) or "無", len(comb),
                 integ.get("state"), len(integ.get("applied") or []), "、".join(skipped) or "無"), "reds": reds1, "rows": first_rows}
fix = {"summary": "只修回合 %s(綠 %d · 黃 %d · 紅 %d):⑤ 計畫 %s · 歷史對齊 %s · 長線庫 %s(Combined 值變了的列另存一版,舊版留著)"
              % (re.sub(r" · 貼回包 .*", "", grep(ra2, r"^NEXT:")), c2["GREEN"], c2["YELLOW"], c2["RED"], grep(ra2, r"⑤ 自動修計畫")[len("[計] ⑤ 自動修計畫:"):][:200], str(hist.get("why", ""))[:160], json.dumps(st.get("totals") or {}, ensure_ascii=False)), "rows": fix_rows}
R = {"selftests": selft, "pwsh_hash_chain": [l for l in lines(W / "pscheck147.log") if l.strip()],
     "roundall_e2e": e2e, "roundall_fix_pass": fix,
     "store_after_fix": {k: st.get(k) for k in ("lamp", "store_engine", "appended", "backfilled", "totals")}, "history_after_fix": {k: hist.get(k) for k in ("lamp", "why", "totals")},
     "integrate": {"state": integ.get("state"), "applied": len(integ.get("applied") or []), "skipped": [(Path(str(s.get("path", ""))).name, s.get("why")) for s in integ.get("skipped") or []]},
     "combined_first_row": {k: (comb[0].get(k) if comb else None) for k in ("FILENAME", "TARGET_PRICE", "TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN", "2026_DILUTED_EPS_FACTSET", "2026_PER_FACTSET", "UPSIDE_PCT(ADJ)")},
     "receipt_roundall": cl.get("roundall"), "pasteback_zip": {"name": Path(zips[-1]).name if zips else None, "members": len(pz), "has": [m for m in pz if m.endswith(("transcript.txt", "VRN2_RoundAll_latest.json", "VRN2_Closeout_v0147.before_roundall.json", "VRN2_FinancialAligned_latest.csv", "VRN2_Deleted_latest.csv"))]},
     "oneclick_scenario_pwsh": {"rc": (W / "scen147.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen147.rc").exists() else "not run",
                                "first": grep(W / "scen147_first.log", r"③ 套件 v0147 就位|③ 本機已是 v0147")[:200], "again": grep(W / "scen147_again.log", r"③ 本機已是 v0147")[:200],
                                "tamper": grep(W / "scen147_tamper.log", r"③ 舊套件夾已改名備份")[:160], "closeout": grep(W / "scen147_first.log", r"⑧b 收尾收據 v0147")[:200], "roundall_hint": grep(W / "scen147_first.log", r"VRN2_RoundAll_v0100")[:160]},
     "not_claimed": ["Windows desktop run of v0147 / RoundAll: not yet (next paste-back)",
                     "⑥e real TWSE / TPEX / Yahoo fetch and ⑥f live cnyes / Yahoo consensus: the container has no network and no yfinance; ⑥f ran on offline engine fixtures, ⑬b on a synthetic market json shaped like MarketFetch --fill (values derived from the report's own figures, one contradicted on purpose)",
                     "RoundAll ⑤ market re-fetch path (wrong Python → re-fetch with via_tw_fetch) is covered by its plan selftest only; no via_tw_fetch env exists here",
                     "Windows-only paths (os.startfile, winreg vrn2:// lookup, ctypes PID check) are exercised by code review and the posix equivalents only",
                     "3014TT POINT_3 FAIL and the 3 missing annual-data books from the desktop runs: still need the paste-back zip; RoundAll only lists such items"]}
rel_p = W / "release147/VRN2_Release_v0147.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
md = ["# VRN-2 v0147 + VRN2_RoundAll_v0100 容器實測紀錄(2026-10-29)", "",
      "操作員令:「generate a py code to handle all above and fix all test all debug all」。一支 Python `VRN2_RoundAll_v0100.py` 跑全流程;做它、測它時抓到的缺陷修成 v0147(見發行清單 `fixes`)。", "",
      "## 1. 自測", "", "| 檔 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有 PASS 行)") for k, v in selft.items()] + ["",
      "## 2. PowerShell 雜湊鏈(pwsh 7.4.6)", "", "```", *R["pwsh_hash_chain"], "```", "",
      "## 3. 端到端:RoundAll 在仿桌機沙盒(套件從假 GitHub 分支取 · 共用 MarketFetch 在、沒 yfinance · 輸出夾在 OneDrive · 舊 Google Sheet CSV + 家用記帳 CSV · 19 份真實樣本)", "",
      e2e["summary"], "", "```", *[l[:260] for l in first_rows], "```", "",
      "## 4. 只修回合(`--skip-package --skip-selftest --skip-run`,先放一份合成的市場資料)", "", fix["summary"], "", "```", *[l[:260] for l in fix_rows], "```", "",
      "| 項目 | 值 |", "|---|---|", "| 長線庫(修後)| %s |" % esc(json.dumps(R["store_after_fix"], ensure_ascii=False)), "| 歷史對齊(修後)| %s |" % esc(json.dumps(R["history_after_fix"], ensure_ascii=False)[:600]),
      "| 舊資料庫整合 | %s |" % esc(json.dumps(R["integrate"], ensure_ascii=False)), "| Combined 第一列 | %s |" % esc(json.dumps(R["combined_first_row"], ensure_ascii=False)),
      "| 收尾收據的 roundall 欄 | %s |" % esc(json.dumps(R["receipt_roundall"], ensure_ascii=False)[:500]), "| 貼回包 | %s |" % esc(json.dumps(R["pasteback_zip"], ensure_ascii=False)), "",
      "## 5. 一鍵 v0147 使用者情境(pwsh · 假 GitHub 分支 → 跑 → 再貼 → 竄改)", "", "| 項目 | 值 |", "|---|---|"] + ["| %s | %s |" % (k, esc(v)) for k, v in R["oneclick_scenario_pwsh"].items()] + ["",
      "## 6. 沒做到 / 沒驗到(照實)", ""] + ["- %s" % x for x in R["not_claimed"]]
(W / "release147/VRN2_Verification_v0147.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
print("finalize147 ok ·", e2e["summary"][:120], "·", fix["summary"][:120])
