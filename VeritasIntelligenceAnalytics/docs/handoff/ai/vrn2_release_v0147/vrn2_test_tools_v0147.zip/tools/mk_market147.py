"""合成一份 ⑥e 市場資料(模擬 MarketFetch --fill 的輸出形狀)給「只修」回合:每份報告的年度實際期營收 → 歷史(千元)對得上;第一份的淨利故意差 20%(要進刪除區)。"""
import importlib.util, json, sys
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
v2 = S / "v147/t147ra/VIA/VIA_Reports/vrn2"
sp = importlib.util.spec_from_file_location("ha", S / "v146/new/VRN2_HistoryAlign_v0100.py"); ha = importlib.util.module_from_spec(sp); sys.modules["ha"] = ha; sp.loader.exec_module(ha)
basic = json.loads((v2 / "output/VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
fin = json.loads((v2 / "output/VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
per_file, made, contradicted = {}, 0, 0
for i, b in enumerate(basic):
    fn, code = b.get("FILENAME"), str(b.get("TICKER") or "")[:4]
    tp = ha.num(b.get("TARGET_PRICE"))
    rec = {"ticker": code, "name": "公司" + code, "yfinance_ticker": code + ".TW", "bloomberg_ticker": code + " TT", "adj_close": 100.0 + i, "adj_close_date": "2026-10-28",
           "adj_close_before_report": 95.0 + i, "adjustment_factor_report": 0.98, "status": "OK", "financial_annual": []}
    if tp:
        rec["target_price_adj"] = round(tp * 0.98, 2); rec["upside_adj"] = round(rec["target_price_adj"] / rec["adj_close"] - 1, 9); rec["upside_pct_adj"] = round(rec["upside_adj"] * 100, 1)
    seen = set()
    for r in fin:
        if r.get("FILENAME") != fn:
            continue
        std, (y, kind), v = ha.std_of(r.get("ITEM")), ha.period_of(r.get("PERIOD")), ha.num(r.get("VALUE"))
        if std not in ("revenue", "net_income") or not y or kind == "E" or v is None or (std, y) in seen:
            continue
        seen.add((std, y))
        factor = 1.2 if (std == "net_income" and i == 0) else 1.0
        contradicted += factor != 1.0
        rec["financial_annual"].append({"year": y, "std": std, "account": r.get("ITEM"), "value": v * 1000 * factor, "unit": "千元", "basis": "ANNUAL"})
        made += 1
    per_file[fn] = rec
(v2 / "market").mkdir(exist_ok=True)
(v2 / "market/VRN2_Market_latest.json").write_text(json.dumps({"version": "synthetic-for-test", "ts": "2026-10-29T12:00:00", "per_file": per_file, "per_ticker": {}}, ensure_ascii=False, indent=1), encoding="utf-8")
print("synthetic market json · files %d · history cells %d · contradicted %d" % (len(per_file), made, contradicted))
