"""VRN2_Handover_v0148.md:從 v0147 只增不減。"""
import json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v147")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0147.md").read_text(encoding="utf-8")
R = json.loads((S / "release147/VRN2_Release_v0147.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg147/VRN2_Runtime_v0147.json").read_text(encoding="utf-8"))["files"]}
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)
lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0146 · 2026-10-29(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0147 + VRN2_RoundAll_v0100 · 2026-10-29(v0146 + 本輪:操作員「generate a py code to handle all above and fix all test all debug all」→ 一支 Python 全流程 VRN2_RoundAll_v0100.py"
            "(取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯 → 貼回包)+ 做它時測出的八個缺陷修成 v0147(長線庫收新冊並依列雜湊補缺 · 歷史對齊不再把別的單位 / 成長率列誤刪 · ⑬b 在 ⑬ 前 · 整合掃描限深 + 只問像 VRN-2 的檔 · ⑥e 用擷取 Python · 啟動器自測從 runtime zip 取模組 + 不受環境變數影響)· "
            "一鍵 v0147 · 操作員一鍵 v0108 · 本地實測一輪改指;runtime v0146 的 175 個成員一個位元組都不動 · +3 個新檔)")
src = "\n".join(lines)
old_round = "> **操作員令(2026-10-29 · 10:25 貼回後)**"
assert src.count(old_round) == 1
e2e = res["roundall_e2e"]; fx = res.get("roundall_fix_pass") or {}
new_round = ("> **操作員令(2026-10-29 · v0146 推上之後)**:「generate a py code to handle all above and fix all test all debug all」。\n"
             "> **本輪(v0147 · 套件 = 啟動器 v0147 + runtime v0147 = v0146 的 175 個成員不動 + OutputStore v0101 + DataIntegrate v0101 + HistoryAlign v0101 · 一支 Python `vrn2_release_v0147/VRN2_RoundAll_v0100.py` · 一鍵 v0147 · 操作員一鍵 v0108)**:"
             "① **VRN2_RoundAll_v0100.py**(只用標準庫 · 釘死套件 SHA-256):⓪ 找 VIA 根(參數 → 環境變數 → 本檔所在的倉 → 啟動器記的 Runtime_Context → vrn2:// 註冊 → 預設位置)→ ① 套件(本機 zip 雜湊 + 逐檔 → 否則 git archive 分支 / main → 竄改整夾改名備份)→ "
             "② 診斷(VRN-2 Python 套件 · 擷取 Python yfinance 等 · 共用 MarketFetch / VDF 引擎 · 鎖 · 輸出夾可寫 · 來源夾 · 磁碟 · CPU · git;缺的只列、照印 VCGC 指令)→ ③ runtime zip 解到 TEMP 逐檔核對 · 十支 --selftest + 啟動器 --selftest → "
             "④ 跑啟動器(預設不上船 · 心跳)→ ⑤ 自動修(⑥e 用錯 Python 重抓 · 有 yfinance 的 Python 重跑 ⑥f · 市場比歷史新重跑 ⑬b · Combined 重組 · ⑬ 補寫 · Workbench 重渲染 · 舊資料庫問使用者 · 清過期鎖;收尾收據先備份 .before_roundall.json)→ "
             "⑥ 除錯報告(每個非綠步驟 + 下一步 · 四點核對不過的檔 / 點 · 缺項 · 完成判定 · 冪等閘 · 階段耗時前三 · Combined 欄序 / 空格 · Workbench 標記 · 市場 / 歷史 / 庫 / 整合 / SSOT → VRN2_RoundAll_latest.json)→ ⑦ 貼回包(Downloads)。"
             "一行啟動在 `VRN2_RoundAll_v0100.md`(cmd / PowerShell 都能貼 · 核對 py 的 SHA-256 · CRLF 也驗得過)。"
             "② **做它時測出並修掉的缺陷**:(a)⑬ 長線庫只追加「沒見過的原檔」→ 桌機 52 份已知時新冊永遠 0 列 → OutputStore v0101 以「冊 × 原檔 SHA × 列雜湊」判缺(已知原檔的新冊 / 改過的列也進庫,同列不重寫)+ 收 Combined / FinancialAligned / Deleted;(b)⑬b 在 ⑬ 之後 → 本輪對齊冊進不了庫 → 移到前面;"
             "(c)DataIntegrate v0100 用 rglob 走整棵樹(輸出夾在 OneDrive 時上一層 = 整個 OneDrive)且任何 CSV 都問 → v0101 限深 scandir + 只問像 VRN-2 的檔;(d)⑥e 用 VRN-2 的 Python 跑 MarketFetch(--fill 要 pandas)· fetch 失敗就不 fill → 用擷取 Python · 照樣 fill;"
             "(e)啟動器 --selftest 在真套件夾找不到 runtime 模組(v0144 ~ v0146)→ 從 runtime zip 取;(f)啟動器 --selftest 在設了 VRN2_OUTPUT_DIR / 上限變數的殼會自己失敗(v0144 起)→ 自測時清掉再還原(RoundAll 第一次端到端就抓到);"
             "(g)RoundAll 自己:`--launcher-args \"--no-install\"` 被 argparse 當選項 → 併成 `=` 形式;(h)⑬b HistoryAlign v0100 只要「同年同科目」就比,報告寫百萬元 / 億元或成長率列也拿千元歷史去比 → 沙盒 100 列誤進刪除區 → v0101:換算後對得上才覆蓋、別的單位對得上只覆蓋不刪、同量級(0.5 ~ 2 倍)且差 >3%% 才刪、其餘標「不明」不動、成長率 / %% 段落只做比率檢驗(沙盒 100 → 39 刪 · 44 不明)。"
             "③ **端到端(沙盒仿桌機:套件從假 GitHub 分支取 · 共用 MarketFetch 在但沒 yfinance · 輸出夾在 OneDrive · 有舊 Google Sheet CSV + 不相干的家用記帳 CSV)**:%s;第二次只修(`--skip-run`,先放一份合成的市場資料)%s。桌機還沒跑 v0147 / RoundAll。\n"
             % (e2e.get("summary", "見驗證紀錄"), fx.get("summary", "見驗證紀錄")))
src = src.replace(old_round, new_round + old_round, 1)
once("> **本輪(v0146 · 套件 = 啟動器 v0146 + runtime v0146", "> **前一輪(v0146 · 套件 = 啟動器 v0146 + runtime v0146")
anchor = "| ActivateVRN-2_v0146.py(套件 · 底座 v0136)| **v0146** |"
assert src.count(anchor) == 1
rows = ("| **VRN2_RoundAll_v0100.py**(發行夾 · 一支入口 · 不在套件內)| **v0100** | `vrn2_release_v0147` | `%s` | **新**(取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯 → 貼回包 · 自測 12 項)|\n"
        "| ActivateVRN-2_v0147.py(套件 · 底座 v0136)| **v0147** | 見發行清單 | `%s` | **新**(OutputStore v0101 / DataIntegrate v0101 · ⑬b 在 ⑬ 前 · ⑥e 擷取 Python · 自測從 runtime zip 取模組 + 不受環境影響)|\n"
        "| **VRN2_OutputStore** | **v0101**(薄尾 · v0100 留著)| runtime v0147 | `%s` | **新**(七冊 · 冊 × 原檔 × 列雜湊判缺 · pyarrow / duckdb 自測各 8 項)|\n"
        "| **VRN2_DataIntegrate** | **v0101**(薄尾 · v0100 留著)| runtime v0147 | `%s` | **新**(限深走訪 · 只問像 VRN-2 的檔 · 自測 7 項)|\n"
        "| **VRN2_HistoryAlign** | **v0101**(薄尾 · v0100 留著)| runtime v0147 | `%s` | **新**(單位換算後才比 · 別的單位只覆蓋不刪 · 同量級才刪 · 不明不動 · 成長率段只做比率 · 自測 6 項)|\n") % (
    R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], rt["VRN2_OutputStore_v0101.py"], rt["VRN2_DataIntegrate_v0101.py"], rt["VRN2_HistoryAlign_v0101.py"])
src = src.replace(anchor, rows + anchor, 1)
once("## 7. 本輪(v0145 → v0146 · 桌機 2026-10-29 10:25 貼回 + 操作員 U/I 與資料需求)",
     "## 7. 本輪(v0146 → v0147 + VRN2_RoundAll_v0100 · 操作員「generate a py code to handle all above and fix all test all debug all」)\n\n| # | 缺陷 | 怎麼抓到的 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | 長線 Parquet 庫的新冊永遠 0 列(已知原檔不再追加)| 寫 RoundAll ⑤「庫裡還沒有新冊」判斷時讀 OutputStore v0100 | OutputStore v0101:冊 × 原檔 SHA × 列雜湊判缺 · 七冊 · 舊庫列沒有列雜湊就現算 | 自測 8 項 × pyarrow / duckdb · 端到端 Combined / FinancialAligned 進庫 · 再跑不重寫 |\n"
     "| b | ⑬b 在 ⑬ 之後 → 本輪對齊冊進不了庫 | 同上 | 啟動器 v0147 對調 | 啟動器自測檢查順序 |\n"
     "| c | 舊資料庫掃描走整個 OneDrive · 任何 CSV 都問 | 讀 DataIntegrate v0100 的 rglob | DataIntegrate v0101 限深 + 像不像 VRN-2 | 自測 7 項 · 端到端家用記帳 CSV 略過 |\n"
     "| d | ⑥e 用 VRN-2 的 Python(--fill 要 pandas)· fetch 失敗不 fill | 讀 MarketFetch --fill | 擷取 Python · 照樣 fill | 啟動器自測 |\n"
     "| e | 啟動器 --selftest 在真套件夾 FileNotFoundError(v0144 ~ v0146)| 把 v0146 套件放在隔離夾跑自測 | 從 runtime zip 取模組 | 隔離夾自測 PASS;v0146 同條件重現失敗 |\n"
     "| f | 啟動器 --selftest 在設了 VRN2_OUTPUT_DIR 的殼自己失敗(v0144 起)| RoundAll 第一次端到端 ③ 紅 | 自測時清掉再還原 | 帶 VRN2_OUTPUT_DIR / 上限 / 開關變數跑自測 PASS |\n"
     "| g | RoundAll `--launcher-args \"--no-install\"` 被當選項 | 端到端第一次啟動 | 併成 `--launcher-args=…` | RoundAll 自測 ⑪ |\n"
     "| h | ⑬b 歷史對齊把別的單位 / 成長率列誤進刪除區(沙盒 100 列,其中 61 列是單位或成長率)| RoundAll 只修回合放合成市場資料後看刪除區 | HistoryAlign v0101:換算後才比 · 同量級才刪 · 不明不動 · 成長率段只做比率 | 自測 6 項 · 同一份沙盒資料刪除 100 → 39 · 不明 44 |\n\n---\n\n## 7.0j 前一輪(v0145 → v0146 · 桌機 2026-10-29 10:25 貼回 + 操作員 U/I 與資料需求)")
once("| 0 | **(v0146)** 桌機跑 v0146(", "| 0 | **(v0147)** 桌機跑一支 Python:貼 `vrn2_release_v0147/VRN2_RoundAll_v0100.md` 的一行(或 `python Downloads\\VRN2_RoundAll_v0100.py`)· 跑完上傳 `Downloads\\VRN2_PasteBack_<時間>.zip`;要只修不重跑 → `--skip-run`;建好 via_tw_fetch 環境後 `--skip-run` 會自動重抓市場 / 共識並補庫 | 貼回 zip |\n"
     "| 0a | **(v0147)** RoundAll ⑤ 的修正只做「重跑某一步」:四點原文核對 FAIL / 年度數據缺項 / 冪等 NONDETERMINISTIC 這類要看原 PDF 的,只列清單不自動改 | 貼回 zip |\n"
     "| 0 | **(v0146)** 桌機跑 v0146(")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0147)** **一支入口 = VRN2_RoundAll**:取套件 / 診斷 / 自測 / 跑 / 修 / 除錯 / 打包都在它;下一輪改套件版號時同步改它的常數(PACKAGE · RELEASE_REL · LAUNCHER · RECEIPT · SELFTESTS)並出 v0101,套件雜湊由建置填(build147 的 `PACKAGE_SHA256` 取代)。\n"
     "- **(v0147)** **自動修只做可重跑、不刪資料的**:重跑一步 · 重組冊 · 補庫 · 重渲染 · 清過期鎖;收尾收據先備份 `.before_roundall.json` 才標註。要看原 PDF 的(四點 FAIL · 缺項 · 非冪等)只列不改。\n"
     "- **(v0147)** **自測必須不受殼的環境變數影響**:會改行為的變數(輸出夾 · 上限 · 步驟開關 · fixture)在自測開頭清掉、結束還原;RoundAll 的 ③ 用使用者真實的殼跑自測,就是為了抓這種事。\n"
     "- **(v0147)** **自測要在真套件夾測**:不能只在建置夾(旁邊有 new/)測;把套件 zip 解到隔離夾再跑一次。\n"
     "- **(v0147)** **增量庫以「冊 × 原檔」判缺**,不是只看原檔新舊;新加的冊會自動把已知原檔補進來一次。\n"
     "- **(v0147)** 掃使用者的夾一律限深 + 項目上限,不用 rglob;只問像 VRN-2 冊的檔。\n"
     "- **(v0147)** **刪除區只收「確定是同一個數、量級相同卻對不上」的列**:單位不同 / 成長率 / 看不出來的一律不刪,只標「不明」留給人看;改這段規則先看刪除區列數有沒有暴增。\n\n")
(REPO / "VRN2_Handover_v0148.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0148 lines", src.count("\n"))
