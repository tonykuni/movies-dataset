#!/bin/bash
# 端到端:VRN2_RoundAll_v0100.py 在模擬桌機的沙盒跑全流程(套件從假 GitHub 分支取)· $1 = 回合名 · 其餘參數照傳給 RoundAll
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v147; T=$W/t147ra; N="$1"; shift
OCRPY=$S/v131/ocrenv/vrn2_ocr/bin/python; P=$S2/venv_vrn2/bin/python
if [ "$N" = "first" ]; then
  rm -rf $T $T.br $T.setup.log
  bash $S/v142/mktree142.sh $T $W/pkg147 "$S2/shipF/samples" > $W/t147ra_setup.log 2>&1 || { cat $W/t147ra_setup.log; exit 1; }
  rm -rf $T/pkg
  R="/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN"
  mkdir -p "$T/VIA/functional modules/VRN/_vdf_fetch"; cp "$R/VRN2_MarketFetch_v0112.py" "$T/VIA/functional modules/VRN/"; cp "$R/_vdf_fetch/VDF_TW_AllInOne_v039.py" "$T/VIA/functional modules/VRN/_vdf_fetch/"
  cp "/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules/"SUP_MDL737_SuperAccelModule_v*.py "$T/VIA/supportive modules/" 2>/dev/null
  (cd "$T/VIA" && git add -A >/dev/null 2>&1 && git -c user.email=t@t -c user.name=t commit -qm "shared tools" >/dev/null 2>&1; git push -q origin main >/dev/null 2>&1)
  B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0147; mkdir -p $D
  cp $W/release147/VRN2_Closeout_v0147.zip $W/release147/VRN2_Release_v0147.json $W/release147/VRN2_OneClick_v0147.md $W/release147/VRN2_RoundAll_v0100.py $W/release147/VRN2_RoundAll_v0100.md $D/
  (cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1)
  (cd "$T/VIA" && git fetch -q origin >/dev/null 2>&1)
  mkdir -p "$T/OneDrive/VRN2_out" "$T/home/OneDrive" "$T/Downloads"
  printf '\xef\xbb\xbfTicker,Date,Broker,Target Price,Rating\n2330,2025-10-01,CLSA,1200,BUY\n3008,2025-10-05,KGI,2500,HOLD\n' > "$T/OneDrive/VRN2_out/舊基本資料 - Sheet1.csv"
  printf '\xef\xbb\xbf日期,項目,金額\n2025-01-01,午餐,120\n' > "$T/OneDrive/家用記帳.csv"
  git -C $T.br show HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0147/VRN2_RoundAll_v0100.py > "$T/Downloads/VRN2_RoundAll_v0100.py"
  FX=$($P - <<'PY'
import json, importlib.util, sys, pathlib
S = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
sp = importlib.util.spec_from_file_location("cj", S / "v146/new/VRN2_ConsensusJoin_v0100.py"); m = importlib.util.module_from_spec(sp); sys.modules["cj"] = m; sp.loader.exec_module(m)
codes = m.codes_from_basic(S / "v145/t145/VIA/VIA_Reports/vrn2")
print(";".join(str(m._fixture(S / "v147/fx" / ("fx%s.json" % c), c, "公司" + c, 100.0 + i, 120.0 + i, 118.0 + i, {2026: 5.0 + i, 2027: 6.0 + i, 2028: 7.0 + i})) for i, c in enumerate(codes)))
PY
)
  echo "$FX" > $W/fx147.list
fi
FX=$(cat $W/fx147.list)
cd "$T/Downloads" && env HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/Downloads" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ENVS_HOME="$T/envs" VIA_TOOLS_ROOT="$T/VIA" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 \
  VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_OUTPUT_DIR="$T/OneDrive/VRN2_out" VRN2_CONSENSUS_FIXTURES="$FX" VRN2_CONSENSUS_YEAR=2026 VRN2_INTEGRATE_TEMP="$T/tmp" \
  timeout 7000 $P "$T/Downloads/VRN2_RoundAll_v0100.py" --root "$T/VIA" --python "$P" --no-open --launcher-args "--no-install" "$@" > $W/ra147_$N.log 2>&1
echo "$N rc $?" >> $W/ra147.rc
