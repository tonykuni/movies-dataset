VRN2_Closeout_v0147 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0147.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0100.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.
Runtime: VRN2_Runtime_v0147.zip = runtime v0146 (175 members byte-identical) + VRN2_OutputStore_v0101 + VRN2_DataIntegrate_v0101 + VRN2_HistoryAlign_v0101,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0147 (fixes found while building and testing the runner):
 - ⑬ long-term Parquet store keeps Combined · FinancialAligned · Deleted and back-fills per (book × source SHA): with all 52 desktop files already
   known, v0100 would have stored 0 rows of the new books forever.
 - ⑬b history alignment runs before ⑬ so this run's FinancialAligned / Deleted reach the store.
 - ⑬c legacy-database scan: depth-limited walk (output folder 2 · its parent 1 · legacy_in 3 · 20,000 entries max) instead of rglob over the whole
   OneDrive, and only VRN-2-like files are offered (≥ 3 mapped columns · FILENAME / TICKER · ITEM + VALUE for FinancialData).
 - ⑥e runs MarketFetch with the fetch Python (VIA_FETCH_PY → %USERPROFILE%\envs\via_tw_fetch); --fill still runs after a failed --fetch.
 - launcher --selftest takes its helper modules out of VRN2_Runtime_v0147.zip (v0144–v0146 selftests failed inside a real package folder) and clears run-time
   switches while testing (v0144–v0146 failed their own checks whenever VRN2_OUTPUT_DIR or a limit was set in the shell).
 - ⑬b Deleted zone only for same-magnitude contradictions (HistoryAlign v0101): other-unit rows are matched, unclear-basis rows untouched, growth / % sections are ratios.
 - ⑬ the store appends per (book × source SHA × row-content hash): new books back-fill known files, and rows whose content changed (Combined prices) are appended.
Verification: see VRN2_Verification_v0147.md. Hashes: PACKAGE_SHA256.json.
