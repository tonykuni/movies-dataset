import threading as _thr

_TL = _thr.local()                                                       # v0122 平行段:工作執行緒的子行程輸出先收在這(主執行緒依固定次序印出 / 收進貼包)


def run(args: list, timeout: int, env_extra: dict | None = None, cwd=None, silent_max: int = 1500) -> tuple:
    """v0108 不卡住:子行程輸出由背景執行緒讀進佇列 · 主迴圈每秒檢查 · 沉默 20 秒印心跳 · 總時限 / 長時間無輸出(silent_max)確實停止本子行程 · [計] / [RED] 行收進貼包。
    v0122 從平行段的工作執行緒呼叫時:不即時印(不交錯)· [計] / [RED] 行收進該工作自己的暫存(主執行緒依固定次序收進貼包 · 冪等)。"""
    import queue as _q
    worker = _thr.current_thread() is not _thr.main_thread()
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PYTHONWARNINGS="ignore", **(env_extra or {}))
    lines, t0 = [], time.time()
    try:
        p = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, cwd=cwd, text=True, encoding="utf-8", errors="replace", bufsize=1)
    except OSError as exc:
        return 127, ["[RED] 無法啟動 %s · %s" % (args[:2], exc)]
    q = _q.Queue()
    def rd():
        for ln in p.stdout:
            q.put(ln.rstrip("\n"))
        q.put(None)
    _thr.Thread(target=rd, daemon=True).start()
    last, beat, done = time.time(), time.time(), False
    while not done:
        try:
            ln = q.get(timeout=1.0)
        except _q.Empty:
            ln = ""
        now = time.time()
        if ln is None:
            done = True
            break
        if ln:
            last = beat = now
            lines.append(ln)
            if not worker:
                print(D + "    " + ln[:220] + Z, flush=True)
        elif now - beat >= 20:
            beat = now
            if not worker:
                print(D + "    [心跳] 仍在執行 · 已 %d 秒 · 距上次輸出 %d 秒" % (now - t0, now - last) + Z, flush=True)
        if now - t0 > timeout or now - last > silent_max:
            p.kill()
            lines.append("[RED] %s · 已停止(只停本子行程)" % (("逾時 %d 秒" % timeout) if now - t0 > timeout else ("%d 秒沒有任何輸出" % silent_max)))
            break
    try:
        rc = p.wait(timeout=30)
    except subprocess.TimeoutExpired:
        p.kill()
        rc = 124
    sink = getattr(_TL, "pack", None) if worker else None
    for ln in lines:
        s_ = ln.strip()
        if s_.startswith(("[計]", "[RED]")) or "[RED]" in s_[:12]:
            (sink if sink is not None else PACK).append(s_[:300])
    return rc, lines


def _sysinfo(sample: float = 0.5) -> dict:
    """v0122 不靠 psutil 也量得到:可用 RAM(GB)· CPU 使用率(%)· Windows = ctypes(GlobalMemoryStatusEx / GetSystemTimes)· Linux = /proc · 量不到 = None(照實說)。"""
    out = {"ram_gb": None, "cpu_pct": None}
    try:
        if os.name == "nt":
            import ctypes
            from ctypes import wintypes
            class _MS(ctypes.Structure):
                _fields_ = [("dwLength", wintypes.DWORD), ("dwMemoryLoad", wintypes.DWORD), ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong), ("ullTotalVirtual", ctypes.c_ulonglong),
                            ("ullAvailVirtual", ctypes.c_ulonglong), ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]
            ms = _MS()
            ms.dwLength = ctypes.sizeof(_MS)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(ms)):
                out["ram_gb"] = round(ms.ullAvailPhys / 1e9, 2)
            FT = wintypes.FILETIME
            def _t():
                i, k, u = FT(), FT(), FT()
                ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k), ctypes.byref(u))
                f = lambda x: (x.dwHighDateTime << 32) | x.dwLowDateTime  # noqa: E731
                return f(i), f(k) + f(u)
            i1, t1 = _t()
            time.sleep(sample)
            i2, t2 = _t()
            if t2 > t1:
                out["cpu_pct"] = round(100.0 * (1 - (i2 - i1) / float(t2 - t1)), 1)
        elif os.path.exists("/proc/meminfo"):
            mi = dict((l.split(":")[0], l.split(":")[1].strip()) for l in open("/proc/meminfo", encoding="ascii", errors="ignore") if ":" in l)
            if "MemAvailable" in mi:
                out["ram_gb"] = round(int(mi["MemAvailable"].split()[0]) * 1024 / 1e9, 2)
            def _s():
                v = [int(x) for x in open("/proc/stat", encoding="ascii").readline().split()[1:]]
                return v[3] + (v[4] if len(v) > 4 else 0), sum(v)
            i1, t1 = _s()
            time.sleep(sample)
            i2, t2 = _s()
            if t2 > t1:
                out["cpu_pct"] = round(100.0 * (1 - (i2 - i1) / float(t2 - t1)), 1)
    except Exception:  # noqa: BLE001
        pass
    return out


def optimize() -> dict:
    """第一步提高 CPU / DRAM 效能(只動本行程與子行程):GC · 執行緒上限 = CPU-1 · 溢寫夾 · CPU 閒(<60%)時本行程升「高於標準」(子行程繼承)· 不碰他人行程。
    v0122 沒有 psutil 也做得到:RAM / CPU 用 _sysinfo(ctypes / /proc)· Windows 升優先權改用 SetPriorityClass(結束還原)。"""
    gc.collect()
    n = os.cpu_count() or 2
    for k in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_MAX_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ.setdefault(k, str(max(1, n - 1)))
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    spill = _cb_Path(os.environ.get("TEMP") or os.environ.get("TMP") or "/tmp") / "VIA_progress" / ("activate_" + ts) / "spill"
    spill.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("VIA_SPILL_DIR", str(spill))
    info = {"cpu": n, "threads": max(1, n - 1), "spill": str(spill), "prio": "不變", "ram_gb": None, "cpu_pct": None, "_restore": None, "_restore_w": None, "meter": "—"}
    try:
        import psutil  # noqa: WPS433
        info["ram_gb"] = round(psutil.virtual_memory().available / 1e9, 2)
        info["cpu_pct"] = psutil.cpu_percent(interval=0.5)
        info["meter"] = "psutil"
        me = psutil.Process()
        if os.name == "nt" and info["cpu_pct"] < 60:
            old = me.nice()
            me.nice(psutil.ABOVE_NORMAL_PRIORITY_CLASS)
            info["prio"], info["_restore"] = "高於標準(本行程 · 結束還原)", old
    except Exception:  # noqa: BLE001
        si = _sysinfo()
        info["ram_gb"], info["cpu_pct"], info["meter"] = si["ram_gb"], si["cpu_pct"], "ctypes" if os.name == "nt" else "/proc"
        if os.name == "nt" and info["cpu_pct"] is not None and info["cpu_pct"] < 60:
            try:
                import ctypes
                k32 = ctypes.windll.kernel32
                h = k32.GetCurrentProcess()
                old = k32.GetPriorityClass(h)
                if old and k32.SetPriorityClass(h, 0x8000):                 # ABOVE_NORMAL_PRIORITY_CLASS
                    info["prio"], info["_restore_w"] = "高於標準(本行程 · 結束還原 · ctypes)", old
            except Exception:  # noqa: BLE001
                pass
    if info["ram_gb"] is not None and info["ram_gb"] < 2:
        os.environ["VIA_LOW_RAM"] = "1"
    ram, cpu = info.get("ram_gb") or 2.0, info.get("cpu_pct") or 0
    lanes = 3 if n >= 4 and ram >= 3 and cpu < 70 else (2 if n >= 2 and ram >= 1.5 and cpu < 85 else 1)   # v0108 安全前提下最多 3 路
    if (os.environ.get("VIA_VRN2_LANES") or "").isdigit():          # 手動指定優先(1~3)
        lanes = max(1, min(3, int(os.environ["VIA_VRN2_LANES"])))
    os.environ["VIA_VRN2_LANES"] = str(lanes)
    os.environ.setdefault("VIA_VRN2_FILE_TIMEOUT", "300")
    os.environ.setdefault("VIA_VRN2_ACC_TIMEOUT", "300")
    info["lanes"] = lanes
    return info


def restore(info: dict) -> None:
    try:
        if info.get("_restore") is not None:
            import psutil  # noqa: WPS433
            psutil.Process().nice(info["_restore"])
        if info.get("_restore_w"):
            import ctypes
            ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), info["_restore_w"])
    except Exception:  # noqa: BLE001
        pass


_PYC_HEAD = ("# [VIA:ACCEL-BRIDGE:v0111] 每個 python -c 指令先接正本加速器(L103 · 找不到 = 不改行為)\n"
             "import sys as _s, re as _r\nfrom pathlib import Path as _P\n_p = _P(%r).resolve()\n"
             "while _p.parent != _p and not (_p / 'supportive modules').is_dir():\n    _p = _p.parent\n"
             "_c = sorted(list((_p / 'supportive modules').glob('VeritasCeleritas_v[0-9][0-9][0-9][0-9].py')) + list((_p / 'supportive modules').glob('*/VeritasCeleritas_v[0-9][0-9][0-9][0-9].py')), key=lambda x: int(_r.search(r'_v(\\d{4})', x.name).group(1)))\n"
             "try:\n    _s.path.insert(0, str(_c[-1].parent)) if _c else None\n    __import__(_c[-1].stem) if _c else None\nexcept Exception:\n    pass\n")


def _pyc(code: str, anchor=None) -> str:
    """v0122 python -c 指令一律先接加速器橋(與檔案型 py 同一條政策 · 找不到正本不改行為)。"""
    return _PYC_HEAD % str(anchor or _cb_Path(__file__).resolve().parent) + code


def _heads(vrn) -> dict:
    """v0122 九頭龍守門:VRN 夾(不含子夾)+ SSOT 夾每個家族的版號集合 {家族: {版號}}。"""
    out = {}
    for d in (_cb_Path(vrn), _cb_Path(vrn) / "SSOT"):
        if not d.is_dir():
            continue
        for p in d.iterdir():
            m = re.match(r"^(.*)_v(\d{4})\.(py|json)$", p.name)
            if m and p.is_file():
                out.setdefault("%s/%s" % (d.name, m.group(1)), set()).add(int(m.group(2)))
    return out


def _heads_diff(h0: dict, h1: dict, allow=("SSOT/VRN2_SSOT", "SSOT/VRN_Config")) -> list:
    """平行段前後比對:新出現的家族 / 版號 → 只准設定冊各多 1 版(範圍聚焦本來就會出) · 其餘 = 九頭龍風險。"""
    bad = []
    for fam, vs in h1.items():
        new = sorted(vs - h0.get(fam, set()))
        if not new:
            continue
        key = fam.replace("VRN/", "")
        if not any(key.endswith(a) for a in allow) or len(new) > 1:
            bad.append("%s 新增 v%s" % (fam, "、".join("%04d" % v for v in new)))
    return bad


def _par_workers(info: dict, n: int) -> int:
    """v0122 平行段路數(動態):CPU-1 為上限 · 可用 RAM <2GB 或 CPU ≥85% → 最多 2 路 · VIA_VRN2_PAR=1 關閉平行 · 數字 = 手動指定。"""
    w = min(n, max(1, int(info.get("threads") or 1)))
    if info.get("ram_gb") is not None and info["ram_gb"] < 2:
        w = min(w, 2)
    if info.get("cpu_pct") is not None and info["cpu_pct"] >= 85:
        w = min(w, 2)
    pv = os.environ.get("VIA_VRN2_PAR") or ""
    if pv.isdigit():
        w = max(1, min(n, int(pv)))
    return w


def _par_plan(tasks: list, prev: dict) -> list:
    """v0122 動態排步驟:依上一輪實測耗時(沒有 → 預估)最長的先跑(LPT)· 同時跑時牆鐘最短。tasks = [(鍵, 名稱, 函式, 預估秒)]。"""
    return sorted(tasks, key=lambda t: -float(prev.get(t[0], t[3]) or t[3]))


def _par_run(tasks: list, workers: int) -> tuple:
    """v0122 平行段:互不相連的步驟同時跑(執行緒 · 每個步驟自己的子行程 / 時限)· 一步出錯不拖累其他步 · 回 ({鍵: (燈, 說明, 秒, 貼包行)}, 牆鐘秒)。"""
    import concurrent.futures as _cf
    res, t0 = {}, time.time()
    def one(t):
        _TL.pack = []
        s = time.time()
        try:
            lamp, det = t[2]()
        except Exception as exc:  # noqa: BLE001
            lamp, det = "RED", "例外 %s %s" % (type(exc).__name__, str(exc)[:120])
        return t[0], (lamp, det, round(time.time() - s, 1), list(_TL.pack))
    with _cf.ThreadPoolExecutor(max_workers=max(1, workers), thread_name_prefix="vrn2par") as ex:
        futs = [ex.submit(one, t) for t in tasks]
        pend, beat = set(futs), time.time()
        while pend:
            done_, pend = _cf.wait(pend, timeout=1.0)
            for f_ in done_:
                k_, v_ = f_.result()
                res[k_] = v_
            if pend and time.time() - beat >= 15:
                beat = time.time()
                say("    [心跳] 平行段 · 完成 %d/%d · 已 %d 秒 · 進行中:%s" % (len(res), len(tasks), time.time() - t0, "、".join(t[1] for t in tasks if t[0] not in res)[:120]), D)
    return res, round(time.time() - t0, 1)


def _done_ok(comp: dict, steps: list, comp_mtime: float, t0: float) -> tuple:
    """v0122 ⑧ 完成判定只認本輪:完成判定檔必須是本輪寫的(⑦ 中斷時沿用舊檔 = 假綠)· ⑦ 不能紅 · ② / ⑥ 自測不能紅。回 (是否完成, 原因)。"""
    why = []
    if comp.get("verdict") != "完成":
        why.append("完成判定 %s" % (comp.get("verdict") or "—"))
    if comp_mtime < t0 - 1:
        why.append("完成判定檔不是本輪寫的(⑦ 沒跑完 · 不採用舊結果)")
    if any(s_["lamp"] == "RED" for s_ in steps if s_["step"].startswith("⑦")):
        why.append("⑦ 紅")
    if any(s_["lamp"] == "RED" for s_ in steps if s_["step"].startswith(("②", "⑥"))):
        why.append("自測有紅")
    return (not why), " · ".join(why)


def _git(cwd, *a, t=120) -> tuple:
    import subprocess as _sp
    try:
        r_ = _sp.run(["git", "-c", "core.quotepath=false", *a], cwd=str(cwd), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=t)
        return r_.returncode, (r_.stdout + r_.stderr).strip()
    except Exception as exc:  # noqa: BLE001
        return 99, type(exc).__name__


def _git_tracked(d) -> tuple:
    """回 (狀態, {絕對路徑}):repo = 'repo' · 不在 repo = 'none' · 在 repo 但 git 用不了 = 'unknown'(保守:不封存)。"""
    d = _cb_Path(d)
    rc, top = _git(d, "rev-parse", "--show-toplevel")
    if rc == 0 and top:
        rc, ls = _git(d, "ls-files")
        if rc == 0:
            return "repo", {str((d / l).resolve()) for l in ls.splitlines() if l}
        return "unknown", set()
    if any((p_ / ".git").exists() for p_ in [d] + list(d.parents)):
        return "unknown", set()
    return "none", set()


SHIP_REL = ("docs", "handoff", "ai", "vrn2_ship")                         # v0123 VRN-2 自己的上船位置(獨立系統 · 不放進 functional modules\VRN 的共用家族)


def _bundle_members(vrn, root) -> tuple:
    """v0123 VRN-2 船包內容:VRN-2 自己的檔(git 沒追蹤 = 不是 GitHub 上別的系統的檔)· 管理器鏈(≤ 尾版)· 現役引擎 / 摘要器 / 處理器 / 規則目錄 /
    AssetIndex · VRN2_SSOT 全部 · VRN-2 寫的 VRN_Config(v1000 起)最新一版 · VRN-2 元件登記冊(鎖 / 成功登記帶時間 → 留本機 · 不進船包 · 內容沒變就不會每輪重送)。git 追蹤中的前版(VCGC 側 VRN 的 v0114–v0153 · ENG062 v0103)只記路徑 + blob 當相依。
    回 ([(絕對路徑, 船包內路徑)], [相依 {path, blob}])。"""
    vrn, root = _cb_Path(vrn), _cb_Path(root)
    gst, tracked = _git_tracked(vrn)
    def mine(p_):
        return p_.is_file() and str(p_.resolve()) not in tracked
    tail = _vnum(MGR_NAME)
    pick = [p_ for p_ in vrn.glob("VRN_SystemManager_v[0-9][0-9][0-9][0-9].py") if _vnum(p_) <= tail and mine(p_)]
    for n_ in [m_[0] for m_ in MGR_CHAIN] + [MGR_NAME] + [e[0] for e in ENGINES] + [e[0] for e in EXTRAS]:
        if mine(vrn / n_):
            pick.append(vrn / n_)
    for pat in ("VRN_ENG396_AssetIndex_v[0-9][0-9][0-9][0-9].py",):
        f_ = latest(vrn, pat)
        if f_ and mine(f_):
            pick.append(f_)
    ss = vrn / "SSOT"
    pick += [p_ for p_ in ss.glob("VRN2_SSOT_v[0-9][0-9][0-9][0-9].json") if mine(p_)]
    cfg = [p_ for p_ in ss.glob("VRN_Config_v[0-9][0-9][0-9][0-9].json") if _vnum(p_) >= 1000 and mine(p_)]
    pick += sorted(cfg, key=_vnum)[-1:]
    rg = vrn / "registry"
    for pat in ("VRN2_Component_Register_v[0-9][0-9][0-9][0-9].json",):
        f_ = latest(rg, pat) if rg.is_dir() else None
        if f_ and mine(f_):
            pick.append(f_)
    out = []
    for p_ in sorted(set(pick), key=lambda x: str(x)):
        try:
            out.append((p_, str(p_.resolve().relative_to(root.resolve())).replace("\\", "/")))
        except ValueError:
            continue
    deps = []
    if gst == "repo":
        rc_, top = _git(vrn, "rev-parse", "--show-toplevel")
        first = min([_vnum(p_) for p_ in pick if p_.name.startswith("VRN_SystemManager_v")] or [0])
        need = [p_ for p_ in vrn.glob("VRN_SystemManager_v[0-9][0-9][0-9][0-9].py") if _vnum(p_) < first and not mine(p_)]
        need += [p_ for p_ in vrn.glob("VRN_ENG062_SummarizerV1_v[0-9][0-9][0-9][0-9].py") if not mine(p_)]
        for p_ in sorted(need, key=lambda x: x.name):
            rc_, blob = _git(vrn, "hash-object", "--", p_.name)
            try:
                rp = str(p_.resolve().relative_to(root.resolve())).replace("\\", "/")
            except ValueError:
                continue
            deps.append({"path": rp, "blob": blob.strip() if rc_ == 0 else ""})
    return out, deps


def _write_bundle(zpath, members, deps) -> dict:
    """固定內容 → 固定位元組(檔名排序 · 時間固定 1980-01-01)· 內容沒變 git 就不會有變更。回清單 dict。"""
    import zipfile
    zpath = _cb_Path(zpath)
    files = []
    tmp = zpath.with_suffix(".tmp")
    with zipfile.ZipFile(str(tmp), "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for src, arc in sorted(members, key=lambda x: x[1]):
            data = _cb_Path(src).read_bytes()
            zi = zipfile.ZipInfo(arc, date_time=(1980, 1, 1, 0, 0, 0))
            zi.compress_type, zi.external_attr = zipfile.ZIP_DEFLATED, 0o644 << 16
            z.writestr(zi, data)
            files.append({"path": arc, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    if zpath.exists() and zpath.read_bytes() == tmp.read_bytes():
        tmp.unlink()
    else:
        tmp.replace(zpath)
    return {"system": "VRN-2", "independent": True, "launcher": VERSION, "manager_tail": MGR_NAME,
            "note": "VRN-2 獨立系統的船包:只含 VRN-2 自己的檔 · 新電腦由 ActivateVRN-2 ② 依本清單補回(只增不減)· 相依檔是 GitHub 上別的系統的檔(只記路徑與 blob · 不複製)",
            "files": files, "depends_on_tracked": deps}


def restore_bundle(vrn, root) -> tuple:
    """v0123 ② 新電腦 / 新 clone:依 repo 裡 VRN-2 船包把缺的 VRN-2 檔補回原位(只增不減 · 雜湊對才寫 · 本機已有且不同 → 保留本機)· 沒有船包 → 灰。"""
    import zipfile
    vrn, root = _cb_Path(vrn), _cb_Path(root)
    sd = root.joinpath(*SHIP_REL)
    zp, mp = sd / "VRN2_Bundle_latest.zip", sd / "VRN2_Bundle_latest.json"
    if not (zp.exists() and mp.exists()):
        return "GRAY", "repo 裡還沒有 VRN-2 船包(第一次完成上船後才有)"
    try:
        man = json.loads(mp.read_text(encoding="utf-8"))
        got, same, keep, bad = 0, 0, [], []
        with zipfile.ZipFile(str(zp)) as z:
            for f_ in man.get("files") or []:
                dst = root / f_["path"]
                data = z.read(f_["path"])
                if hashlib.sha256(data).hexdigest() != f_["sha256"]:
                    bad.append(f_["path"].rsplit("/", 1)[-1])
                    continue
                if dst.exists():
                    if hashlib.sha256(dst.read_bytes()).hexdigest() == f_["sha256"]:
                        same += 1
                    else:
                        keep.append(dst.name)
                    continue
                dst.parent.mkdir(parents=True, exist_ok=True)
                dst.write_bytes(data)
                got += 1
        miss = [d_["path"].rsplit("/", 1)[-1] for d_ in man.get("depends_on_tracked") or [] if not (root / d_["path"]).exists()]
    except Exception as exc:  # noqa: BLE001
        return "YELLOW", "船包讀取失敗 %s · 不補回" % type(exc).__name__
    lamp = "RED" if bad else ("YELLOW" if miss else "GREEN")
    return lamp, "VRN-2 船包 %d 檔 · 補回 %d · 已在 %d · 本機不同保留 %d%s%s%s" % (
        len(man.get("files") or []), got, same, len(keep), (":" + "、".join(keep[:3])) if keep else "",
        (" · 雜湊不符不寫 %d:%s" % (len(bad), "、".join(bad[:3]))) if bad else "", (" · 缺相依 %d(請先 git pull):%s" % (len(miss), "、".join(miss[:3]))) if miss else "")


def git_ship(vrn, root, comp: dict) -> tuple:
    """⑨ 上船 GitHub:只在完成時 · v0123 獨立系統:只提交 VRN-2 自己的位置(docs/handoff/ai/vrn2_ship 船包 + 清單 · 交接報告)·
    不把 .py 放進 functional modules\\VRN 的共用家族(VRN_SystemManager / ENG062 / VRN_Config 是 VCGC 側 VRN 也用的名字)·
    絕不提交 PDF / VIA_Reports / 範圍夾 · git commit -- <路徑> 只提交這些路徑(不動使用者其他暫存變更)· VIA_VRN2_NO_PUSH=1 不推送。"""
    vrn, root = _cb_Path(vrn), _cb_Path(root)
    hd = root / "docs" / "handoff" / "ai"
    hd.mkdir(parents=True, exist_ok=True)
    hb = base64.b64decode(HANDOVER_B64)
    for n_ in (HANDOVER_NAME, "VRN2_Handover_latest.md"):
        p_ = hd / n_
        if not p_.exists() or p_.read_bytes() != hb:
            p_.write_bytes(hb)
    rc, top = _git(vrn, "rev-parse", "--show-toplevel")
    if rc != 0 or not top:
        return "GRAY", "VRN 夾不在 git repo · 不上船(交接報告已落地 %s)" % hd
    top = _cb_Path(top.splitlines()[-1].strip())
    sd = root.joinpath(*SHIP_REL)
    sd.mkdir(parents=True, exist_ok=True)
    members, deps = _bundle_members(vrn, root)
    man = _write_bundle(sd / "VRN2_Bundle_latest.zip", members, deps)
    mtxt = json.dumps(man, ensure_ascii=False, indent=1)
    mp = sd / "VRN2_Bundle_latest.json"
    if not mp.exists() or mp.read_text(encoding="utf-8") != mtxt:
        mp.write_text(mtxt, encoding="utf-8")
    rel = []
    for p_ in (sd / "VRN2_Bundle_latest.zip", mp, hd / HANDOVER_NAME, hd / "VRN2_Handover_latest.md"):
        try:
            rel.append(str(p_.resolve().relative_to(top.resolve())).replace("\\", "/"))
        except ValueError:
            continue
    nmgr = len([f_ for f_ in man["files"] if "VRN_SystemManager_v" in f_["path"]])
    note = "船包 %d 檔(管理器鏈 %d 支)· 相依 GitHub 檔 %d" % (len(man["files"]), nmgr, len(deps))
    rc, st = _git(top, "status", "--porcelain", "--", *rel)
    if rc == 0 and not st.strip():
        return "GREEN", "GitHub 已是最新 · VRN-2 船包無變更 · %s" % note
    _git(top, "add", "--", *rel)
    msg = "VRN-2 %s 收尾 · 完成判定 %s · 紅 %d 黃 %d · 自動上船(VRN-2 獨立船包 docs/handoff/ai/vrn2_ship · %s · 交接報告)" % (VERSION.split()[-1], comp.get("verdict", ""), comp.get("red", 0), comp.get("yellow", 0), note)
    rc, out = _git(top, "commit", "-m", msg, "--", *rel)
    if rc != 0 and "nothing" not in out.lower():
        return "YELLOW", "提交失敗 · %s" % out[-160:]
    rc, h_ = _git(top, "rev-parse", "--short", "HEAD")
    if os.environ.get("VIA_VRN2_NO_PUSH") == "1":
        return "GREEN", "已提交本機 %s(%s)· VIA_VRN2_NO_PUSH=1 不推送" % (h_, note)
    rc, out = _git(top, "push", t=240)
    if rc != 0:
        return "YELLOW", "已提交本機 %s(%s)· 推送失敗(認證 / 網路 / 遠端較新 → 先 git pull 再重跑):%s" % (h_, note, out[-140:])
    return "GREEN", "已上船 GitHub · 提交 %s · %s · 位置 docs/handoff/ai/vrn2_ship · 交接報告 docs/handoff/ai/VRN2_Handover_latest.md" % (h_, note)


def consolidate(vrn) -> tuple:
    """v0120 ⑩ 整併封存:完成後把被取代的 ENG397 / ENG062 舊版移到 _archive_vrn2(不刪除 · 寫清單 · --restore-archive 可還原)· 管理器是薄尾鏈不封存。
    v0122 不搬 GitHub 上的檔(git 追蹤中 = 別的系統 / 前人的正本 · 例:ENG062 v0101~v0103)· 不搬現役版還在引用的檔(ENG062 v0112 載入 v0103 的舊 API)· git 狀態不明 → 不封存。"""
    import datetime
    vrn = _cb_Path(vrn)
    arc = vrn / "_archive_vrn2"
    cur = {"VRN_ENG397_P1Segment_v": _vnum(ENG_NAME), "VRN_ENG062_SummarizerV1_v": max([_vnum(e[0]) for e in EXTRAS if e[0].startswith("VRN_ENG062_SummarizerV1_v")] or [0])}
    gst, tracked = _git_tracked(vrn)
    if gst == "unknown":
        return "YELLOW", "VRN 夾在 git repo 但 git 用不了 · 分不出哪些是 GitHub 上的檔 · 這輪不封存(只增不減)"
    refs = ""
    for pre, cv in cur.items():
        p_cur = vrn / ("%s%04d.py" % (pre, cv))
        if p_cur.exists():
            refs += p_cur.read_text(encoding="utf-8", errors="replace")
    moved, kept = [], []
    for pre, cv in cur.items():
        if not cv:
            continue
        for p_ in sorted(vrn.glob(pre + "[0-9][0-9][0-9][0-9].py")):
            if _vnum(p_) >= cv:
                continue
            if str(p_.resolve()) in tracked:
                kept.append(p_.name + "(GitHub 上的檔)")
                continue
            if p_.name in refs:
                kept.append(p_.name + "(現役版仍引用)")
                continue
            arc.mkdir(parents=True, exist_ok=True)
            dst = arc / p_.name
            sha = hashlib.sha256(p_.read_bytes()).hexdigest()
            if dst.exists() and hashlib.sha256(dst.read_bytes()).hexdigest() == sha:
                p_.unlink()
            else:
                if dst.exists():
                    dst = arc / ("%s.%s%s" % (p_.stem, sha[:8], p_.suffix))
                shutil.move(str(p_), str(dst))
            moved.append({"file": p_.name, "sha256": sha, "from": str(p_), "to": str(dst), "ts": datetime.datetime.now().isoformat(timespec="seconds")})
    if moved:
        with (arc / "ARCHIVE_MANIFEST.jsonl").open("a", encoding="utf-8") as fh:
            for x in moved:
                fh.write(json.dumps(x, ensure_ascii=False) + "\n")
    return "GREEN", "封存被取代的舊版 %d 個 → %s(不刪除 · 清單 ARCHIVE_MANIFEST.jsonl · --restore-archive 可還原)· 保留 %d 個%s · 現役 ENG397 v%04d · ENG062 v%04d · 管理器薄尾鏈不封存" % (
        len(moved), arc, len(kept), (":" + "、".join(kept[:4])) if kept else "", cur["VRN_ENG397_P1Segment_v"], cur["VRN_ENG062_SummarizerV1_v"])


def register_ui_protocol(vrn, v2) -> tuple:
    """v0121 ⑥c U/I 操作協定:寫 VRN2_UIAction_Config.json(啟動器 / python / 輸出根)· Windows 註冊 vrn2:// 到 HKCU(只寫目前使用者 · 不需管理員 · 不碰 via://)。
    v0122 處理器 = 內嵌那一版(帶加速器橋的 v0102)· 沒有才用夾裡最新版。"""
    vrn, v2 = _cb_Path(vrn), _cb_Path(v2)
    handler = vrn / UI_HANDLER_NAME
    if not handler.exists():
        handler = latest(vrn, "VRN2_UIAction_v[0-9][0-9][0-9][0-9].py") or handler
    cfg = {"python": sys.executable, "launcher": str(_cb_Path(__file__).resolve()), "v2": str(v2), "version": VERSION, "handler": handler.name}
    (vrn / "VRN2_UIAction_Config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=1), encoding="utf-8")
    if os.name != "nt":
        return "GRAY", "非 Windows · 不註冊 vrn2://(設定檔已寫 · 處理器 %s)" % handler.name
    if not handler.exists():
        return "YELLOW", "找不到處理器 %s" % handler
    try:
        import winreg
        pyw = _cb_Path(sys.executable).with_name("pythonw.exe")
        exe = pyw if pyw.exists() else _cb_Path(sys.executable)
        cmd = '"%s" "%s" "%%1"' % (exe, handler)
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\vrn2") as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "URL:VRN-2 Protocol")
            winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Classes\vrn2\shell\open\command") as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, cmd)
        return "GREEN", "vrn2:// 已註冊到目前使用者(HKCU)· 處理器 %s · U/I 左側按鈕可直接操作(重跑 / 不上船 / 清快取 / 還原封存)" % handler.name
    except Exception as exc:  # noqa: BLE001
        return "YELLOW", "vrn2:// 註冊失敗 %s · U/I 請用「複製執行指令」" % type(exc).__name__


def _land_mgr_one(vrn, name, sha, b64, env_extra) -> tuple:
    dst = vrn / name
    raw = base64.b64decode("".join(b64.split()))
    if hashlib.sha256(raw).hexdigest() != sha:
        return "RED", "內嵌 %s hash 不符 · 不落地" % name
    if dst.exists():
        same = hashlib.sha256(dst.read_bytes()).hexdigest() == sha
        return ("GREEN", "%s 已在且 hash 同" % name) if same else ("YELLOW", "%s 已在但內容不同 · 不覆蓋(只增不減)" % name)
    dst.write_bytes(raw)
    rc, lines = run([sys.executable, "-W", "ignore", str(dst), "--selftest"], 900, env_extra, cwd=str(vrn))
    tail = next((l for l in reversed(lines) if "自測" in l), "")
    if rc != 0:
        q = vrn / "_quarantine"
        q.mkdir(exist_ok=True)
        shutil.move(str(dst), str(q / (name + ".selftest_fail")))
        return "RED", "%s 自測失敗 → 搬 _quarantine(不刪)· %s" % (name, tail.strip()[:80])
    return "GREEN", "%s 落地 · %s" % (name, tail.strip()[:80])


def land_manager(vrn) -> tuple:
    """內嵌管理器落地(只增不減):v0122 先依序落地前版鏈(MGR_CHAIN · 例 v0231)再落地尾版 · 已在且同 hash → 用;不在 → 寫入 → 自測;自測失敗 → 搬 _quarantine(不刪)→ 用前一版。"""
    env = {"VIA_SKIP_PRIOR_SELFTEST": "1", "VIA_NO_OPEN": "1"}
    det = []
    for name, sha, b64 in MGR_CHAIN:
        lamp, d_ = _land_mgr_one(vrn, name, sha, b64, env)
        det.append(d_)
        if lamp == "RED":
            return latest(vrn, "VRN_SystemManager_v[0-9][0-9][0-9][0-9].py"), "RED", " · ".join(det) + " · 改用現有尾版"
    lamp, d_ = _land_mgr_one(vrn, MGR_NAME, MGR_SHA, MGR_B64, env)
    det.append(d_)
    mgr = vrn / MGR_NAME if lamp != "RED" else latest(vrn, "VRN_SystemManager_v[0-9][0-9][0-9][0-9].py")
    return mgr, lamp if all("內容不同" not in x for x in det) or lamp == "RED" else "YELLOW", " · ".join(det)


def land_extras(vrn) -> tuple:
    """v0104:摘要器 ENG062 + 精簡規則目錄 + U/I 處理器落地(只增不減)· py 先編譯 + 載入確認 · json 先解析;失敗搬 _quarantine。v0122 檢查指令也接加速器(_pyc)。"""
    out, worst = [], "GREEN"
    for name, sha, b64 in EXTRAS:
        dst = vrn / name
        raw = base64.b64decode("".join(b64.split()))
        if hashlib.sha256(raw).hexdigest() != sha:
            out.append("%s hash 不符 · 不落地" % name)
            worst = "RED"
            continue
        if dst.exists():
            same = hashlib.sha256(dst.read_bytes()).hexdigest() == sha
            out.append("%s %s" % (name, "已在且 hash 同" if same else "已在但內容不同 · 不覆蓋(只增不減)"))
            worst = worst if same else ("YELLOW" if worst == "GREEN" else worst)
            continue
        dst.write_bytes(raw)
        if name.endswith(".py"):
            chk = "import importlib.util,sys;sp=importlib.util.spec_from_file_location('e',sys.argv[1]);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);assert m.VERSION in sys.argv[1] and callable(m.summarize_pdf) and m.load_catalog();print('[計] ENG062 載入 OK')"
            if not name.startswith("VRN_ENG062_"):                              # v0121 非摘要器(vrn2:// 處理器等)只需能編譯 + 有 main
                chk = "import py_compile,sys,ast;py_compile.compile(sys.argv[1],doraise=True);t=ast.parse(open(sys.argv[1],encoding='utf-8').read());assert any(getattr(n,'name','')=='main' for n in t.body);print('[計] 編譯 OK')"
            rc, lines = run([sys.executable, "-W", "ignore", "-c", _pyc(chk, vrn), str(dst)], 300, {"VIA_NO_OPEN": "1"}, cwd=str(vrn))
        else:
            try:
                json.loads(raw.decode("utf-8"))
                rc = 0
            except ValueError:
                rc = 1
        if rc != 0:
            q = vrn / "_quarantine"
            q.mkdir(exist_ok=True)
            shutil.move(str(dst), str(q / (name + ".check_fail")))
            out.append("%s 檢查失敗 → 搬 _quarantine" % name)
            worst = "RED"
        else:
            out.append("%s 落地" % name)
    return worst, " · ".join(out)


def _ui_wait() -> None:
    """v0122 從 U/I(vrn2://)開的視窗:結束時停住等 Enter(貼包不會一閃而過 · 也存在 VIA_Reports\\vrn2\\ActivateVRN-2_*.log)。"""
    if os.environ.get("VRN2_FROM_UI") != "1":
        return
    try:
        if sys.stdin and sys.stdin.isatty():
            input("[計] 按 Enter 關閉視窗(貼包也存在 VIA_Reports\\vrn2\\ActivateVRN-2_*.log)")
    except (EOFError, OSError, KeyboardInterrupt):
        pass


def selftest() -> int:
    import tempfile
    ok, tot = 0, 0
    def chk(name, cond):
        nonlocal ok, tot
        tot += 1
        ok += bool(cond)
        print("  [%s] %s" % ("OK" if cond else "FAIL", name))
    t = [("[計] 加速器注入(accelfix) 計畫 · 缺標記現役尾版 0 · 本批 0", r"缺標記現役尾版 (\d+)", 0), ("[計] PS 加速橋(accelfix --all · ps1) 計畫 · 缺橋現役尾版 3 · 本批 3", r"缺橋現役尾版 (\d+)", 3)]
    for line, rx, want in t:
        chk("數字擷取 %s" % rx, _num([line], rx) == want)
    blobs = [(MGR_NAME, MGR_SHA, MGR_B64)] + list(MGR_CHAIN) + list(ENGINES) + list(EXTRAS) + [(OCR_BRIDGE_NAME, OCR_BRIDGE_SHA, OCR_BRIDGE_B64), (HANDOVER_NAME, HANDOVER_SHA, HANDOVER_B64)]
    chk("內嵌 %d 個元件 hash 全對(管理器鏈 %s · 引擎 · 摘要器 · 處理器 · OCR 橋 · 交接報告)" % (len(blobs), " → ".join([m_[0][-9:-3] for m_ in MGR_CHAIN] + [MGR_NAME[-9:-3]])),
        all(hashlib.sha256(base64.b64decode("".join(b.split()))).hexdigest() == h for _, h, b in blobs))
    src = _cb_Path(__file__).read_text(encoding="utf-8")
    chk("本支帶加速器橋 [VIA:ACCEL-BRIDGE:v0111]", "[VIA:ACCEL-BRIDGE:v0111]" in src and "[VIA:ACCEL-BRIDGE:END]" in src)
    pc = _pyc("print('x')")
    try:
        compile(pc, "<pyc>", "exec")
        pc_ok = True
    except SyntaxError:
        pc_ok = False
    chk("python -c 指令先接加速器(_pyc)· 可編譯 · 帶橋標記", pc_ok and pc.startswith("# [VIA:ACCEL-BRIDGE:v0111]"))
    si = _sysinfo(0.1)
    chk("不靠 psutil 量 RAM / CPU(%s):RAM %s GB · CPU %s%%" % ("ctypes" if os.name == "nt" else "/proc", si["ram_gb"], si["cpu_pct"]), os.name not in ("nt", "posix") or si["ram_gb"] is not None)
    tk = [("a", "A", None, 5), ("b", "B", None, 60), ("c", "C", None, 1)]
    order = [x[0] for x in _par_plan(tk, {"a": 30})]
    w = [_par_workers({"threads": 7, "ram_gb": 8, "cpu_pct": 10}, 6), _par_workers({"threads": 7, "ram_gb": 1.5, "cpu_pct": 10}, 6), _par_workers({"threads": 1}, 6)]
    chk("動態排步驟:最長的先跑(上輪實測優先)%s · 路數 %s(RAM 低 / 單核自動降)" % (order, w), order == ["b", "a", "c"] and w == [6, 2, 1])
    calls = []
    res_, wall_ = _par_run([("x", "X", lambda: (time.sleep(0.3), calls.append("x"), ("GREEN", "x"))[2], 1), ("y", "Y", lambda: (_ for _ in ()).throw(ValueError("boom")), 1),
                            ("z", "Z", lambda: (time.sleep(0.3), ("GREEN", "z"))[1], 1)], 3)
    chk("平行段:同時跑(牆鐘 %.1f 秒 < 序跑 0.6)· 一步例外不拖累其他步 → %s" % (wall_, {k_: v_[0] for k_, v_ in sorted(res_.items())}),
        wall_ < 0.55 and res_["x"][0] == "GREEN" and res_["y"][0] == "RED" and res_["z"][0] == "GREEN")
    td = _cb_Path(tempfile.mkdtemp(prefix="act123-"))
    (td / "SSOT").mkdir()
    (td / "A_v0001.py").write_text("x=1\n", encoding="utf-8")
    h0 = _heads(td)
    (td / "SSOT" / "VRN2_SSOT_v0101.json").write_text("{}", encoding="utf-8")
    ok_a = _heads_diff(h0, _heads(td)) == []
    (td / "A_v0002.py").write_text("x=2\n", encoding="utf-8")
    bad_b = _heads_diff(h0, _heads(td))
    chk("九頭龍守門:設定冊多 1 版 = 正常 · 平行段多出 A_v0002.py = 擋下 → %s" % bad_b, ok_a and len(bad_b) == 1 and "A" in bad_b[0])
    now = time.time()
    d1 = _done_ok({"verdict": "完成"}, [{"step": "⑦ 啟動 VRN-2", "lamp": "GREEN"}], now, now - 5)
    d2 = _done_ok({"verdict": "完成"}, [{"step": "⑦ 啟動 VRN-2", "lamp": "RED"}], now - 3600, now - 5)
    chk("⑧ 只認本輪:本輪寫的完成檔 → %s · 舊檔 + ⑦ 紅 → %s(%s)" % (d1[0], d2[0], d2[1][:30]), d1[0] and not d2[0] and "不是本輪" in d2[1])
    rc_g, _ = _git(td, "--version")
    if rc_g == 0:
        import zipfile
        gr = td / "repo"
        vrn = gr / "functional modules" / "VRN"
        (vrn / "SSOT").mkdir(parents=True)
        (vrn / "registry").mkdir()
        for nm in ("VRN_SystemManager_v0153.py", "VRN_ENG062_SummarizerV1_v0103.py", "SSOT/VRN_Config_v0100.json"):
            (vrn / nm).write_text("# tracked · 別的系統的檔\n", encoding="utf-8")
        _git(gr, "init", "-q")
        _git(gr, "-c", "user.email=t@t", "-c", "user.name=t", "add", "-A")
        _git(gr, "-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "base")
        for nm in ("VRN_SystemManager_v0230.py", MGR_NAME, "VRN_ENG062_SummarizerV1_v0111.py", [e[0] for e in EXTRAS if e[0].startswith("VRN_ENG062_")][-1],
                   "SSOT/VRN2_SSOT_v0100.json", "SSOT/VRN_Config_v1001.json", "registry/VRN2_Lock_latest.json", "registry/VRN2_Component_Register_v0100.json"):
            (vrn / nm).write_text("# VRN-2 本機\n" + ("VRN_ENG062_SummarizerV1_v0103.py\n" if nm.startswith("VRN_ENG062_") and not nm.endswith("v0111.py") else ""), encoding="utf-8")
        mem, deps = _bundle_members(vrn, gr)
        arcs = [a_ for _, a_ in mem]
        dps = [d_["path"].rsplit("/", 1)[-1] for d_ in deps]
        chk("⑨ 船包只裝 VRN-2 自己的檔 %d 個(管理器鏈 v0230 + 尾版 · VRN2_SSOT · VRN_Config v1001 · 元件登記冊 · 帶時間的鎖不裝)· GitHub 上的 v0153 / ENG062 v0103 / VRN_Config v0100 只記相依 %s" % (len(arcs), dps),
            "functional modules/VRN/VRN_SystemManager_v0230.py" in arcs and "functional modules/VRN/" + MGR_NAME in arcs and "functional modules/VRN/SSOT/VRN_Config_v1001.json" in arcs
            and not any(x in " ".join(arcs) for x in ("v0153", "SummarizerV1_v0103", "VRN_Config_v0100", "VRN2_Lock_latest")) and "functional modules/VRN/registry/VRN2_Component_Register_v0100.json" in arcs and "VRN_SystemManager_v0153.py" in dps and "VRN_ENG062_SummarizerV1_v0103.py" in dps)
        sd = gr.joinpath(*SHIP_REL)
        sd.mkdir(parents=True)
        man = _write_bundle(sd / "VRN2_Bundle_latest.zip", mem, deps)
        b1 = (sd / "VRN2_Bundle_latest.zip").read_bytes()
        _write_bundle(sd / "VRN2_Bundle_latest.zip", mem, deps)
        (sd / "VRN2_Bundle_latest.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
        chk("⑨ 船包內容沒變 → 位元組相同(git 不會有假變更)", (sd / "VRN2_Bundle_latest.zip").read_bytes() == b1)
        g2 = td / "clone"
        for p_ in [x for x in gr.rglob("*") if x.is_file() and ".git" not in x.parts]:
            r_ = p_.relative_to(gr)
            if str(r_).startswith(("docs",)) or "VRN_SystemManager_v0153" in r_.name or "SummarizerV1_v0103" in r_.name or r_.name == "VRN_Config_v0100.json":
                (g2 / r_).parent.mkdir(parents=True, exist_ok=True)
                (g2 / r_).write_bytes(p_.read_bytes())
        v2r = g2 / "functional modules" / "VRN"
        r1 = restore_bundle(v2r, g2)
        r2 = restore_bundle(v2r, g2)
        chk("② 新 clone 依船包補回 VRN-2 檔 → %s · 再跑一次不重寫 → %s" % (r1[1][:40], r2[1][:40]),
            r1[0] == "GREEN" and (v2r / MGR_NAME).exists() and (v2r / "VRN_SystemManager_v0230.py").exists() and " 補回 0 " in r2[1] and r2[0] == "GREEN")
        hd = gr / "docs" / "handoff" / "ai"
        os.environ["VIA_VRN2_NO_PUSH"], _np = "1", os.environ.get("VIA_VRN2_NO_PUSH")
        _git(gr, "config", "user.email", "t@t")
        _git(gr, "config", "user.name", "t")
        gl_, gd_ = git_ship(vrn, gr, {"verdict": "完成", "red": 0, "yellow": 0})
        if _np is None:
            os.environ.pop("VIA_VRN2_NO_PUSH", None)
        else:
            os.environ["VIA_VRN2_NO_PUSH"] = _np
        rc_s, shown = _git(gr, "show", "--name-only", "--pretty=format:", "HEAD")
        chk("⑨ 上船只提交 VRN-2 自己的位置(船包 + 清單 + 交接報告)· functional modules 一個檔都不提交 → %s" % [x.rsplit("/", 1)[-1] for x in shown.split()],
            gl_ == "GREEN" and shown.strip() and not any(x.startswith("functional modules") for x in shown.split()) and any("vrn2_ship/VRN2_Bundle_latest.zip" in x for x in shown.split()))
        cl_, cd_ = consolidate(vrn)
        chk("⑩ 封存不搬 GitHub 上的檔(v0103 留)· 搬本機舊版 v0111 → %s" % cd_[:60], (vrn / "VRN_ENG062_SummarizerV1_v0103.py").exists() and not (vrn / "VRN_ENG062_SummarizerV1_v0111.py").exists()
            and (vrn / "_archive_vrn2" / "VRN_ENG062_SummarizerV1_v0111.py").exists())
    else:
        chk("⑨ / ⑩ git 守門(本機沒有 git · 只檢查函式存在)", callable(_bundle_members) and callable(consolidate))
    print("[計] %s 自測 %d/%d · %s" % (VERSION, ok, tot, "PASS" if ok == tot else "FAIL"))
    return 0 if ok == tot else 1


def main(argv: list) -> int:
    if "--restore-archive" in argv:                                        # v0120 還原 ⑩ 封存
        try:
            _r, _v = locate()[:2]
            rc_ = restore_archive(_v)
        except Exception as exc:  # noqa: BLE001
            say("[RED] 還原封存失敗 %s" % exc, R)
            rc_ = 2
        _ui_wait()
        return rc_
    if "--selftest" in argv:
        return selftest()
    os.system("")                                        # Windows 主控台開 ANSI 色
    t0 = time.time()
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    N = 9
    say("══════ %s · %s · %s ══════" % (VERSION, ts, sys.executable), Y)
    bar(0, N, "① CPU / DRAM 優化(第一步)")
    info = optimize()
    step("① CPU / DRAM 優化", "GREEN", "CPU %s 核 · 執行緒上限 %s · 可用 RAM %s GB · CPU 使用 %s%%(%s)· 優先權 %s · 平行 %s 路(擷取 / 驗收 · 每份逾時 300 秒)· 溢寫夾 %s" % (
        info["cpu"], info["threads"], info["ram_gb"], info["cpu_pct"], info.get("meter"), info["prio"], info.get("lanes"), info["spill"]))
    par = {}
    try:
        bar(1, N, "② 定位 VRN-2 · 落地 VRN-2 SystemManager")
        root, vrn = locate()
        if not vrn:
            step("② 定位 VRN-2", "RED", "找不到 VRN-2 程式夾 functional modules\\VRN(可設環境變數 VIA_ROOT)")
            return 2
        bl_, bd_ = restore_bundle(vrn, root)                                  # v0123 新電腦 / 新 clone:依 VRN-2 船包補回(只增不減)
        step("② VRN-2 船包(新電腦補回)", bl_, bd_)
        mgr, lamp, det = land_manager(vrn)
        step("② 定位 VRN-2 · VRN-2 SystemManager", lamp if mgr else "RED", "%s · 使用 %s" % (det, ("%s(%s)" % (MGR_DISPLAY, mgr.name)) if mgr else "—"))
        el, ed = land_engine(vrn)
        step("② 擷取引擎 ENG397", el, ed)
        xl, xd = land_extras(vrn)
        step("② 摘要器 ENG062 + 規則目錄 + U/I 處理器", xl, xd)
        if not mgr:
            return 2
        M = [sys.executable, "-W", "ignore", str(mgr)]
        envx = {"VIA_NO_OPEN": "1"}
        v2 = root / "VIA_Reports" / "vrn2"
        v2.mkdir(parents=True, exist_ok=True)
        try:
            prev = json.loads((v2 / "VRN2_Activate_latest.json").read_text(encoding="utf-8")).get("par") or {}
        except Exception:  # noqa: BLE001
            prev = {}
        bar(2, N, "③ 環境檢查與補裝(序跑:補裝會動到套件 · 先做完別的步驟才匯入)")
        rc, ln = run(M + ["envcheck"] + ([] if "--no-install" in argv or "--plan" in argv else ["--install"]), 3600, envx, cwd=str(vrn))
        head = next((l.strip() for l in ln if "環境檢查" in l), "")
        miss = [l.strip() for l in ln if "缺 必裝" in l or "補裝失敗" in l]
        step("③ 環境檢查與補裝", "GREEN" if rc == 0 and not miss else ("RED" if any("必裝" in m for m in miss) else "YELLOW"), (head[:160] or "rc %d" % rc) + (" · 仍缺 %d" % len(miss) if miss else ""))
        bar(3, N, "④ 加速器覆蓋 100%(序跑:會出 v+1 檔 · 做完才掃描 / 編譯)")
        if "--plan" not in argv:
            run(M + ["accelfix", "--all", "--apply", "--limit", "5000"], 3600, envx, cwd=str(vrn))
        rc, ln = run(M + ["accelfix", "--all", "--limit", "5000"], 1800, envx, cwd=str(vrn))
        py_left, ps_left = _num(ln, r"缺標記現役尾版 (\d+)"), _num(ln, r"缺橋現役尾版 (\d+)")
        skipped = [l for l in ln if "跳過" in l and "原檔" in l]
        lamp = "GREEN" if py_left == 0 and ps_left in (0, -1) else ("YELLOW" if skipped and py_left + max(ps_left, 0) <= len(skipped) else "RED")
        step("④ 加速器覆蓋", lamp, "py 現役尾版未覆蓋 %s · ps1 現役尾版未覆蓋 %s%s" % (py_left, ps_left if ps_left >= 0 else "(無 pwsh 未檢)", " · 原檔本身語法錯而略過 %d(不動原檔)" % len(skipped) if skipped else ""))
        # v0122 平行段:六個暫時獨立、不相連的步驟同時跑(各自的子行程 / 時限 · 不寫 .py · 只有範圍聚焦寫設定冊)· 前後比對檔頭防九頭龍
        bar(4, N, "④b 平行段(六個互不相連的步驟同時跑 · 動態排序)")
        ocr_envd = {}
        def t_ocr():
            return ocr_env(ocr_envd)
        def t_proto():
            return register_ui_protocol(vrn, v2)
        def t_scope():
            rcs, lns = run(M + ["vrn2scope"], 1800, {"VIA_VRN_HEALTH_OUT": str(v2)}, cwd=str(vrn))   # v0117 範圍聚焦:只擷取個股報告 + VRN-2 獨立設定冊
            return ("GREEN" if rcs == 0 else "RED"), next((x.strip()[:220] for x in lns if "範圍(只擷取個股報告)" in x), "rc %d" % rcs)
        def t_e397():
            e397 = latest(vrn, "VRN_ENG397_P1Segment_v[0-9][0-9][0-9][0-9].py")
            if not e397:
                return "RED", "找不到擷取引擎 ENG397(落地失敗又沒有前一版)"
            rc_, ln_ = run([sys.executable, "-W", "ignore", str(e397), "--selftest"], 900, envx, cwd=str(vrn))
            return ("GREEN" if rc_ == 0 else "RED"), next((l.strip() for l in reversed(ln_) if "自測" in l), "ENG397 自測 rc %d" % rc_)[:90]
        def t_probe():
            probe = ("import sys,re;from pathlib import Path;p=Path(r'%s').resolve()\n"
                     "while p.parent!=p and not (p/'supportive modules').is_dir(): p=p.parent\n"
                     "s=p/'supportive modules';c=sorted(list(s.glob('VeritasCeleritas_v[0-9][0-9][0-9][0-9].py'))+list(s.glob('*/VeritasCeleritas_v[0-9][0-9][0-9][0-9].py')),key=lambda x:int(re.search(r'_v(\\d{4})',x.name).group(1)))\n"
                     "n=list(s.glob('VeritasAegisNexus_v1652.py'))+list(s.glob('*/VeritasAegisNexus_v1652.py'))\n"
                     "[sys.path.insert(0,str(x.parent)) for x in c[-1:]+n[:1]]\n"
                     "import importlib;a=importlib.import_module(c[-1].stem);print('[計] 加速器可匯入',c[-1].stem)\n"
                     "importlib.import_module('VeritasAegisNexus_v1652') if n else None;print('[計] 網路工具',('可匯入' if n else '找不到'))") % str(vrn)
            rc_, ln_ = run([sys.executable, "-W", "ignore", "-c", probe], 300, envx)
            return ("GREEN" if rc_ == 0 else "RED"), " · ".join(l.split("]", 1)[-1].strip() for l in ln_ if l.startswith("[計]")) or "rc %d" % rc_
        def t_static():
            bad_, n_ = [], 0
            for pat in ("VRN_SystemManager_v[0-9][0-9][0-9][0-9].py", "VRN_ENG397_P1Segment_v[0-9][0-9][0-9][0-9].py", "VRN_ENG396_AssetIndex_v[0-9][0-9][0-9][0-9].py", "VRN2_UIAction_v[0-9][0-9][0-9][0-9].py"):
                f = latest(vrn, pat)
                if f:
                    n_ += 1
                    try:
                        compile(f.read_text(encoding="utf-8"), f.name, "exec")
                    except SyntaxError as exc:
                        bad_.append("%s 第 %s 行" % (f.name, exc.lineno))
            pdfs = list(INPUT_DIR.glob("*.pdf")) if INPUT_DIR.is_dir() else []
            if not pdfs:
                bad_.append("輸入夾 %s 沒有 PDF" % INPUT_DIR)
            if "[VIA:ACCEL-BRIDGE:v0111]" not in _cb_Path(__file__).read_text(encoding="utf-8"):
                bad_.append("本支沒有加速器橋")
            return ("GREEN" if not bad_ else "RED"), "編譯尾版 %d 支 · 輸入夾 PDF %d 份 · 本支帶加速器橋(本行程 %s)%s" % (n_, len(pdfs), _ACCEL_VER or "未載入", (" · 失敗:" + " / ".join(bad_)) if bad_ else "")
        tasks = [("ocr", "③b OCR 隔離環境", t_ocr, 60), ("proto", "⑥c U/I 操作協定", t_proto, 1), ("scope", "⑥b 範圍聚焦(個股報告)", t_scope, 10),
                 ("e397", "⑥ ENG397 自測", t_e397, 15), ("probe", "⑥ 加速器 / 網路工具匯入", t_probe, 3), ("static", "⑥ 編譯 / 輸入夾 / 本支加速器橋", t_static, 2)]
        if "--plan" in argv:
            tasks = [t for t in tasks if t[0] not in ("ocr", "proto", "scope")]
        plan = _par_plan(tasks, prev)
        wk = _par_workers(info, len(plan))
        h0 = _heads(vrn)
        say("    [計] 平行段 · %d 步 · 同時 %d 路(CPU %s 核 · RAM %s GB · CPU 使用 %s%%)· 排序(上輪實測最長先跑):%s" % (len(plan), wk, info["cpu"], info["ram_gb"], info["cpu_pct"], " → ".join(t[1] for t in plan)), Y)
        res, wall = _par_run(plan, wk)
        os.environ.update(ocr_envd)                                           # OCR 環境變數由主執行緒寫(平行中不改 os.environ)
        dragons = _heads_diff(h0, _heads(vrn))
        par = {k_: v_[2] for k_, v_ in res.items()}
        for k_, nm_, _, _ in tasks:                                           # 固定次序記錄(與跑完先後無關 · 貼包冪等)
            lamp_, det_, sec_, pk_ = res.get(k_, ("RED", "沒有結果", 0, []))
            PACK.extend(pk_)
            STEPS.append({"step": nm_, "lamp": lamp_, "detail": "%s · 耗時 %.0f 秒(平行)" % (det_, sec_)})
            say("  → %s %s · %s · 耗時 %.0f 秒(平行)" % (lamp_, nm_, det_, sec_), {"GREEN": G, "YELLOW": Y, "RED": R}.get(lamp_, D))
            PACK.append("[%s] %s · %s" % ("RED" if lamp_ == "RED" else "計", nm_, det_))
        step("④b 平行段", "RED" if dragons else "GREEN", "%d 步同時 %d 路 · 牆鐘 %.0f 秒(序跑合計 %.0f 秒)· 新增九頭龍頭 %d%s" % (
            len(plan), wk, wall, sum(par.values()), len(dragons), (":" + "、".join(dragons)) if dragons else ""))
        bar(5, N, "⑤ 元件登記(序跑:平行段寫完設定冊才掃)")
        rc, ln = run(M + ["register"], 1200, envx, cwd=str(vrn))
        rg = next((l.strip() for l in ln if "元件登記(VRN-2 register)" in l), "")
        step("⑤ 元件登記", "GREEN" if rc == 0 and rg else "RED", (rg.split("· ", 1)[-1][:200] if rg else "rc %d" % rc))
        bar(6, N, "⑥ 啟動前快速測試(彙整平行段)")
        gate = [(nm_, res.get(k_, ("RED",))[0] != "RED") for k_, nm_, _, _ in tasks if k_ in ("e397", "probe", "static")] + [("平行段無九頭龍", not dragons)]
        bad = [n for n, okk in gate if not okk]
        step("⑥ 啟動前快速測試", "GREEN" if not bad else "RED", "%d/%d 過%s" % (len(gate) - len(bad), len(gate), (" · 失敗:" + " / ".join(bad)) if bad else ""))
        overall = "RED" if any(s["lamp"] == "RED" for s in STEPS) else ("YELLOW" if any(s["lamp"] == "YELLOW" for s in STEPS) else "GREEN")
        (v2 / "VRN2_Activate_latest.json").write_text(json.dumps({"ts": ts, "lamp": overall, "version": VERSION, "python": sys.executable, "steps": STEPS, "par": par, "par_workers": wk, "par_wall": wall}, ensure_ascii=False, indent=1), encoding="utf-8")
        if bad and "--force" not in argv:
            say("[RED] 啟動前測試未過 → 不啟動 VRN-2(修好再跑 · 或加 --force 強制)", R)
            return 1
        bar(7, N, "⑦ 啟動 VRN-2 實測 → U/I")
        if "--plan" in argv:
            step("⑦ 啟動 VRN-2", "GRAY", "--plan 只檢查不啟動")
        else:
            os.environ.pop("VIA_NO_OPEN", None)
            try:                                                                  # v0118 調節輪參數(VRN2_SSOT · funnel)由 MAIN 帶入引擎
                _ssb = sorted((vrn / "SSOT").glob("VRN2_SSOT_v[0-9][0-9][0-9][0-9].json"), key=_vnum)
                _fp = (json.loads(_ssb[-1].read_text(encoding="utf-8")).get("funnel") or {}) if _ssb else {}
                os.environ["VIA_VRN2_OCR_LADDER"] = str(_fp.get("ocr_ladder") or "200,325p")
                os.environ["VIA_VRN2_OCR_MIN_CONF"] = str(_fp.get("ocr_min_conf") or 0.85)
                os.environ["VIA_VRN2_OCR_MIN_CHARS"] = str(_fp.get("ocr_min_chars") or 40)
                if str(_fp.get("max_tier") or "T3") in ("T0", "T1"):
                    os.environ.pop("VIA_VRN2_OCR_PY", None)
                    os.environ.pop("VIA_VRN2_OCR_BRIDGE", None)
                say("    [計] 調節輪參數 · 階梯 %s · 信心 %s · 字數 %s · 上限 %s(VRN2_SSOT)" % (os.environ["VIA_VRN2_OCR_LADDER"], os.environ["VIA_VRN2_OCR_MIN_CONF"], os.environ["VIA_VRN2_OCR_MIN_CHARS"], _fp.get("max_tier") or "T3"), Y)
            except Exception as exc:  # noqa: BLE001
                say("    [計] 調節輪參數讀不到(%s)· 用引擎預設" % type(exc).__name__, Y)
            old_pv, new_pv = root / "VIA_Reports" / "vrn" / "p1view", v2 / "p1view"
            if old_pv.is_dir() and not new_pv.exists():                      # v0107 第一次:舊紀錄複製到 VRN-2 專屬夾(舊位置不刪)· 退步比對接續
                new_pv.mkdir(parents=True, exist_ok=True)
                ncp = 0
                for f in old_pv.iterdir():
                    if f.is_file():
                        shutil.copy2(str(f), str(new_pv / f.name))
                        ncp += 1
                say("    [計] VRN-2 輸出改到專屬夾 %s · 第一次複製舊 p1view 紀錄 %d 檔(舊位置保留不刪 · 與 VRN-1 區隔)" % (new_pv, ncp), Y)
            (v2 / "ocr_cache").mkdir(parents=True, exist_ok=True)
            rc, ln = run(M + ["vrn2", "--run"], 7200, {"VIA_VRN_HEALTH_OUT": str(v2), "VIA_VRN2_OCR_CACHE": str(v2 / "ocr_cache"), "VIA_VRN2_P1_CACHE": str(v2 / "p1_cache")}, cwd=str(vrn))   # v0120 擷取快取 · v0113 OCR 快取
            ui = next((l.split("[U/I]", 1)[1].strip() for l in reversed(ln) if "[U/I]" in l and "VRN2_UI" in l), "")
            key = next((l.strip() for l in ln if "VRN-2 個股四項" in l), "")
            step("⑦ 啟動 VRN-2", "GREEN" if rc == 0 else ("YELLOW" if rc == 1 else "RED"), (key[:150] or "rc %d" % rc) + (" · U/I " + ui if ui else ""))
            (v2 / "VRN2_Activate_latest.json").write_text(json.dumps({"ts": ts, "lamp": "RED" if any(s["lamp"] == "RED" for s in STEPS) else ("YELLOW" if any(s["lamp"] == "YELLOW" for s in STEPS) else "GREEN"),
                                                                       "version": VERSION, "python": sys.executable, "steps": STEPS, "par": par, "par_workers": wk, "par_wall": wall}, ensure_ascii=False, indent=1), encoding="utf-8")
        if "--plan" not in argv:
            bar(8, N, "⑧ 完成判定")
            try:
                cp_ = v2 / "VRN2_Completion_latest.json"
                comp = json.loads(cp_.read_text(encoding="utf-8"))
                done, why = _done_ok(comp, STEPS, cp_.stat().st_mtime, t0)
                step("⑧ 完成判定", "GREEN" if done else "RED", "%s · 輸出驗證 紅 %d 黃 %d%s%s" % ("VRN-2 完成" if done else "未完成(%s)" % why,
                     comp.get("red", 0), comp.get("yellow", 0), (" · 已知例外:" + "、".join(comp.get("exceptions") or [])) if comp.get("exceptions") else "", ""))
                for it in comp.get("items", []):
                    if it.get("lamp") == "RED":
                        PACK.append("[RED] 完成判定未過 · %s · %s" % (it.get("name"), str(it.get("detail"))[:150]))
                if done:                                                          # v0118 ⑨ 上船 GitHub(只在完成時)
                    gl_, gd_ = git_ship(vrn, v2.parent.parent, comp)
                    step("⑨ 上船 GitHub", gl_, gd_)
                    try:                                                          # v0120 ⑩ 整併封存(上船之後 · 舊版不進下次掃描)
                        cl_, cd_ = consolidate(vrn)
                    except Exception as exc:  # noqa: BLE001
                        cl_, cd_ = "YELLOW", "整併封存未完成 %s" % type(exc).__name__
                    step("⑩ 整併封存", cl_, cd_)
                else:
                    step("⑨ 上船 GitHub", "GRAY", "完成判定未過 · 不上船")
                    step("⑩ 整併封存", "GRAY", "完成判定未過 · 不整併")
            except Exception as exc:  # noqa: BLE001
                step("⑧ 完成判定", "RED", "讀不到 VRN2_Completion_latest.json · %s" % type(exc).__name__)
        bar(N, N, "完成")
        return 0
    finally:
        restore(info)
        say("══════ 貼給 AI(%d 行 · %.0f 秒)══════" % (min(len(PACK), 290), time.time() - t0), Y)
        for l in PACK[:290]:
            say(l, R if l.startswith("[RED]") else Y)
        _fin = next((s_ for s_ in STEPS if s_["step"].startswith("⑧")), None)
        if _fin and _fin["lamp"] == "GREEN":
            exc_ = re.sub(r"\s*·\s*耗時 \d+ 秒$", "", _fin["detail"].split("已知例外:", 1)[1]) if "已知例外:" in _fin["detail"] else ""
            nxt = "VRN-2 完成 · 自測 / 實測全過 · 輸出驗證無誤(U/I 已開啟)" + ((" · " + exc_ + " 待 OCR") if exc_ else "")
        else:
            nxt = "全綠 → 鎖定 · 下一輪" if not any(s["lamp"] == "RED" for s in STEPS) else "有紅 → 貼回 AI"
        say("NEXT: " + nxt, Y)
        try:
            root, _ = locate()
            if root:
                lg = root / "VIA_Reports" / "vrn2" / ("ActivateVRN-2_%s.log" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
                lg.write_text("\n".join(LOG), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass
        _ui_wait()
