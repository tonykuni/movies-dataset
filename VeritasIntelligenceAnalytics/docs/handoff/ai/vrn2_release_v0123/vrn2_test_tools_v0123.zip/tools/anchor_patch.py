"""精準錨點改寫:每組 old 必須恰好出現一次 · 改後必須能編譯 · 輸出新檔(原檔不動)。用法:anchor_patch.py 原檔 新檔 規則.json"""
import json, sys, pathlib
src, dst, rules = sys.argv[1], sys.argv[2], json.loads(pathlib.Path(sys.argv[3]).read_text(encoding="utf-8"))
s = pathlib.Path(src).read_text(encoding="utf-8")
for i, (old, new) in enumerate(rules):
    n = s.count(old)
    if n != 1:
        sys.exit("規則 %d 錨點出現 %d 次:%r" % (i, n, old[:80]))
    s = s.replace(old, new)
if dst.endswith(".py"):
    compile(s, dst, "exec")
pathlib.Path(dst).write_text(s, encoding="utf-8", newline="")
print("OK %s · %d 處" % (pathlib.Path(dst).name, len(rules)))
