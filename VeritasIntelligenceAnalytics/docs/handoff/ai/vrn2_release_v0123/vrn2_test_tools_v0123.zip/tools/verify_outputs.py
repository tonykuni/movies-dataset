"""VRN-2 輸出值獨立驗證(不 import 任何 VRN-2 程式 · 讀法 = pypdfium2 字元框 · 與擷取用的 pdfplumber 不同讀取器)。

用法:python verify_outputs.py <output 夾> <PDF 夾> <報告 .json>
  基本資料:每欄值必須在 PDF 原文找得到(或可由原文重算)· 推算值要標推算
  年度數據:每筆 VALUE 必須在該頁 · 同列有 ITEM · 數值落在 PERIOD 表頭那一欄(x 對齊)
"""
import json
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import pypdfium2 as pdfium


def nfk(t):
    return unicodedata.normalize("NFKC", t or "")


def squash(t):
    return re.sub(r"\s+", "", nfk(t)).lower()


_PAGES = {}


def page_lines(pdf, pno):
    """回 [(y, [(x0, x1, token)])] · 依字元框分列分詞(列 = 字元垂直中心差 < 0.5 字高)。"""
    key = (str(pdf), pno)
    if key in _PAGES:
        return _PAGES[key]
    doc = pdfium.PdfDocument(str(pdf))
    out = []
    if 1 <= pno <= len(doc):
        tp = doc[pno - 1].get_textpage()
        chars = []
        for i in range(tp.count_chars()):
            ch = tp.get_text_range(i, 1)
            l, b, r, t = tp.get_charbox(i, loose=True)
            if ch in ("\r", "\n") or r <= l:
                chars.append(None)
                continue
            chars.append((ch, l, b, r, t))
        rows = []
        for c in chars:
            if c is None:
                continue
            ch, l, b, r, t = c
            yc, h = (b + t) / 2, max(t - b, 1.0)
            row = next((rw for rw in rows if abs(rw[0] - yc) < 0.5 * max(h, rw[1])), None)
            if row is None:
                row = [yc, h, []]
                rows.append(row)
            row[2].append((l, r, ch, h))
        for yc, h, cs in rows:
            cs.sort(key=lambda x: x[0])
            toks, cur = [], None
            for l, r, ch, hh in cs:
                if ch.isspace():
                    cur = None
                    continue
                if cur is not None and l - cur[1] <= 0.25 * hh:
                    cur[1], cur[2] = r, cur[2] + ch
                else:
                    cur = [l, r, ch]
                    toks.append(cur)
            out.append((yc, [(a, b_, nfk(s)) for a, b_, s in toks]))
        out.sort(key=lambda x: -x[0])
    doc.close()
    _PAGES[key] = out
    return out


def page_text(pdf, pno):
    return "\n".join(" ".join(t for _, _, t in toks) for _, toks in page_lines(pdf, pno))


def all_text(pdf, pages=(1, 2, 3, 4, 5, 6, 7, 8)):
    """兩個讀取器聯集(pypdfium2 字元框 + pdfplumber 文字層)· 去掉字母間的字型雜訊 %(To%mmy → Tommy)。"""
    import pdfplumber
    t = [page_text(pdf, p) for p in pages]
    try:
        with pdfplumber.open(str(pdf)) as d:
            t += [(d.pages[p - 1].extract_text() or "") for p in pages if p <= len(d.pages)]
    except Exception:  # noqa: BLE001
        pass
    return re.sub(r"(?<=[A-Za-z\u4e00-\u9fff])%(?=[A-Za-z\u4e00-\u9fff])", "", nfk("\n".join(t)))


def num_in(v, text):
    """數值回原文:字面 · 字距拆開 · 千分位 · 小數位不同(4200 = 4,200.00)都算同值。"""
    v = nfk(v).strip().lstrip("+")
    if not v:
        return True
    pat = r"(?<![\d,])(?<!\d\.)" + re.escape(v) + r"(?![\d])"
    if re.search(pat, text):
        return True
    t = re.sub(r"(?<=[\d.,])\s+(?=[\d.,])", "", nfk(text))
    if re.search(pat, t):
        return True
    vv = v.replace(",", "").rstrip("%")
    try:
        fv = float(vv)
    except ValueError:
        return False
    for tt in (nfk(text), t):                                            # 原樣 + 字距接回 兩種都比(接回會把換行兩邊的數字黏住)
        t2 = re.sub(r"(?<=\d),(?=\d{3}(?!\d))", "", tt)
        if any(abs(float(x) - fv) < 1e-9 for x in re.findall(r"(?<![\d.])\d+(?:\.\d+)?(?![\d.])", t2)):
            return True
    return False


RATING_ONLY = re.compile(r"(?i)^(?:中立|買進|買入|賣出|持有|增加持股|減碼|區間操作|未評等|neutral|buy|sell|hold|outperform|underperform|overweight|underweight|equal[- ]?weight|not rated|nr)(?:\s*[(（][^)）]{1,14}[)）])?$")


def src_score(v, raw_sq):
    """原文覆蓋率:值壓縮後每 6 字一窗(步距 3)有幾成在原文(兩讀取器聯集)· 跨欄交錯的標題也量得到。"""
    sv = squash(v)
    if len(sv) <= 6:
        return 1.0 if sv in raw_sq else 0.0
    wins = [sv[i:i + 6] for i in range(0, len(sv) - 5, 3)]
    return sum(1 for w in wins if w in raw_sq) / len(wins)


def verify_fin(rows, pdfdir):
    res = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        lines = page_lines(pdf, int(x["PAGE"]))
        item, per, val = nfk(x["ITEM"]).strip(), nfk(x["PERIOD"]).strip(), nfk(x["VALUE"]).strip()
        sv = squash(val)
        # 1) 值在該頁
        ptxt = "\n".join(" ".join(t for _, _, t in tk) for _, tk in lines)
        present = num_in(val, ptxt) or sv in squash(ptxt)
        # 2) 科目那一列(科目前 14 字壓縮比對 · 允許科目折行:取科目起點所在列與下一列)
        key = squash(item)[:14]
        cand = []
        for k, (y, tk) in enumerate(lines):
            lt = squash("".join(t for _, _, t in tk))
            if key and key in lt:
                cand.append(k)
        # 3) 表頭期間欄 x(取在科目列上方、最近的那一個表頭)
        verdict, note = ("PRESENT" if present else "FAIL"), ""
        kind = "NUM" if re.search(r"\d", val) else ("NIL" if re.fullmatch(r"(?i)[-–—]+|n\.?a\.?|nm|n/?m|n/?a|na|nil|neg\.?|ns|--", val) else "TEXT")
        best = None
        for k in cand:
            y = lines[k][0]
            row_toks = [tt for kk in (k, k + 1) if kk < len(lines) and abs(lines[kk][0] - y) < 14 for tt in lines[kk][1]]
            hits = [((a + b) / 2, a, b, t) for a, b, t in row_toks if squash(t) == sv or squash(t) == sv.replace(",", "")]
            if not hits:
                continue
            for yy, tk in lines:                                 # 每個在上方、同期間字樣的表頭都試 · 取 x 最近(並排表各自的表頭)
                if not (y - 1 < yy < y + 520):
                    continue
                for a, b, t in tk:
                    if t != per:
                        continue
                    hx = (a + b) / 2
                    colw = min([abs((aa + bb) / 2 - hx) for aa, bb, tt in tk if tt != per and re.match(r"^(?:FY)?\d{2,4}[AEFP]?$|^\d{1,2}/\d{2}[AEFe]?$|^[A-Z][a-z]{2}-\d{2}[AEF]$", tt)] + [60])
                    for vx, va, vb, vt in hits:
                        dx = abs(vx - hx)
                        if best is None or dx < best[0]:
                            best = (dx, colw, hx, vx, b - a, yy)
        if best:
            dx, colw, hx, vx, hw, hy = best
            if dx <= max(0.55 * colw, hw * 0.9, 12):
                verdict, note = "ALIGNED", "dx %.1f · 欄寬 %.0f" % (dx, colw)
            else:
                verdict, note = "MISALIGNED", "值 x %.0f · 表頭 %s x %.0f · dx %.1f · 欄寬 %.0f" % (vx, per, hx, dx, colw)
        if kind == "TEXT" and not re.fullmatch(r"(?i)net\s*cash|淨現金", val):
            verdict, note = "BADVALUE", "VALUE 不是數字 / 空值記號(科目或底線混進數值欄)· " + note
        elif len([t for t in val.split() if re.search(r"\d", t) or re.fullmatch(r"(?i)[-–—]+|n\.?a\.?|n/a|nm|n\.m\.|nil", t)]) >= 2:
            verdict, note = "BADVALUE", "一格多值 · %s" % note
        si = squash(item)
        rows_sq = [squash("".join(t for _, _, t in tk)) for _, tk in lines]
        wrapped = any(si[:k] in rows_sq[i] and si[k:] in "".join(rows_sq[i + 1:i + 3]) for i in range(len(rows_sq)) for k in range(6, len(si) - 2))   # 科目折行
        if verdict in ("ALIGNED", "PRESENT") and si not in squash(ptxt) and not wrapped:
            verdict, note = "BADITEM", "科目 %r 本頁原文沒有 · %s" % (item, note)
        res.append(dict(x, _V=verdict, _N=note))
    return res


_BROKER = [(r"(?i)^CLST|clsa|cl-sec", "CLSA"), (r"(?i)^Citi|citi\.com", "Citi"), (r"(?i)^Daiwa|daiwa", "Daiwa"), (r"(?i)^GS-|gs\.com", "Goldman Sachs"),
           (r"(?i)^JP-|jpmorgan", "J.P. Morgan"), (r"(?i)^MQ-|macquarie", "Macquarie"), (r"(?i)^MS-|morganstanley", "Morgan Stanley"),
           (r"凱基|KGI", "凱基"), (r"中信|CTBC", "中信"), (r"華南", "華南"), (r"兆豐", "兆豐"), (r"台新", "台新")]


def verify_basic(rows, pdfdir):
    out = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        t1 = all_text(pdf, (1,))
        ta = all_text(pdf)
        st = x.get("_STATUS") or {}
        chk = {}
        def put(k, ok, why=""):
            chk[k] = ("PASS" if ok else "FAIL") + ((" · " + why) if why else "")
        f = x["FILENAME"]
        tk = x.get("TICKER", "")
        put("TICKER", bool(tk) and (tk in f or tk in t1), "檔名或首頁")
        d = x.get("REPORT_DATE", "")
        if d:
            y, m, dd = d.split("-")
            roc = "%d%s%s" % (int(y) - 1911, m, dd)
            put("REPORT_DATE", (y + m + dd) in f or roc in f or (y[2:] + m + dd) in f or any(s in t1 for s in (d, "%s/%s/%s" % (y, m, dd), "%s年%d月%d日" % (y, int(m), int(dd)))), "檔名 / 首頁")
        tt = x.get("TITLE", "")
        if tt:
            sc = src_score(tt, squash(ta))
            put("TITLE", sc >= 0.8 and not RATING_ONLY.match(nfk(tt).strip()), "原文覆蓋 %.0f%% · 不是只有評等" % (100 * sc))
        for k in ("YFINANCE_TICKER", "ENGLISH_NAME", "RATING"):
            v = nfk(x.get(k, "")).strip()
            if v:
                put(k, squash(v) in squash(t1) or squash(v) in squash(ta), "原文")
        v = x.get("BLOOMBERG_TICKER", "")
        if v:
            put("BLOOMBERG_TICKER", squash(v) in squash(ta) or st.get("BLOOMBERG_TICKER", "").startswith("推算"), "原文或標推算")
        if x.get("NAME"):
            put("NAME", x["NAME"] in f or x["NAME"] in ta, "檔名 / 原文")
        for e in [e for e in (x.get("EMAIL") or "").split("、") if e]:
            put("EMAIL:" + e, e.lower() in re.sub(r"\s+", "", nfk(ta)).lower(), "原文")
        tel = x.get("TEL", "")
        if tel:
            digits = re.sub(r"\D", "", tel)
            put("TEL", len(digits) >= 8 and digits[-8:] in re.sub(r"\D", "", ta), "原文數字")
        for nm in [a for a in (x.get("ANALYST") or "").split("、") if a]:
            put("ANALYST:" + nm, squash(nm) in squash(ta) and not re.search(r"信箱|電話|郵件|傳真|地址|研究員|分析師|聯絡|日期", nm), "原文(姓名照原文印 · 不是欄位標籤)")
        b = x.get("BROKER", "")
        if b:
            exp = next((name for rx, name in _BROKER if re.search(rx, f) or re.search(rx, x.get("EMAIL", ""))), None)
            put("BROKER", exp is None or squash(exp)[:4] in squash(b) or squash(b)[:4] in squash(exp), "檔名 / 網域 → %s" % exp)
        for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
            v = x.get(k, "")
            if v:
                put(k, num_in(v, ta), "原文")
        up = x.get("UPSIDE_PCT", "")
        if up:
            if (st.get("UPSIDE_PCT") or "").startswith("計算"):
                try:
                    calc = (float(x["TARGET_PRICE"].replace(",", "")) / float(x["CURRENT_PRICE_REPORT"].replace(",", "")) - 1) * 100
                    put("UPSIDE_PCT", abs(calc - float(up)) < 0.06, "重算 %.2f" % calc)
                except (ValueError, ZeroDivisionError, KeyError):
                    put("UPSIDE_PCT", False, "無法重算")
            else:
                put("UPSIDE_PCT", num_in(up, ta) or num_in(up.lstrip("+"), ta), "原文")
        out.append({"FILENAME": f, "checks": chk})
    return out


def _nums_raw(text):
    """原文數字(兩種讀法聯集:原樣 · 字距拆開接回)· 千分位去掉。原樣那份不接空白(表格相鄰數字不會黏在一起)。"""
    out = []
    for t in (nfk(text), re.sub(r"(?<=[\d.,])\s+(?=[\d.,])", "", nfk(text))):
        t = re.sub(r"(?<=\d),(?=\d{3}(?!\d))", "", t)
        out += [float(x) for x in re.findall(r"(?<![\d.])\d+(?:\.\d+)?(?![\d.])", t)]
    return out


def verify_point(v, text, rsq):
    """一個重點 → 逐段檢查:原文句(覆蓋 ≥85% · 數字在原文)· 摘要器組句(評價句 / EPS 序列:輸入數字在原文 · 「計算」的值重算對得上)。回 (PASS/FAIL, 說明)。"""
    v = nfk(v)
    segs = [x.strip(" ,，。") for x in re.split(r"[；;⚫•]", v) if x.strip(" ,，。")]
    nums = None
    bad, notes, eps = [], [], []
    for sg in segs:
        m = re.match(r"^(\d{4}) 年 .*?EPS.*?\s([\-\d.,]+)(?: TWD)?(?:\s*[（(]計算 YoY ([\-\d.]+)%[）)])?$", sg)
        if m:
            eps.append((int(m.group(1)), float(m.group(2).replace(",", "")), float(m.group(3)) if m.group(3) else None))
            if not num_in(m.group(2), text):
                bad.append("EPS %s 不在原文" % m.group(2))
            continue
        if sg.startswith("目標價 ") or "上漲空間" in sg or sg.startswith(("原目標價", "目標價依據", "報告潛在")):
            for k_, val in re.findall(r"(目標價|原目標價|倍)\s*([\d.,]+)", sg) + [("倍", x) for x in re.findall(r"([\d.]+)\s*倍", sg)]:
                if not num_in(val, text):
                    bad.append("%s %s 不在原文" % (k_, val))
            mu = re.search(r"上漲空間\s*(-?[\d.]+)%", sg)
            if mu:
                if "計算" in sg:
                    tp = re.search(r"目標價\s*([\d.,]+)", v)
                    nums = nums if nums is not None else _nums_raw(text)
                    z = float(mu.group(1))
                    okz = tp is not None and any(n > 0 and abs((float(tp.group(1).replace(",", "")) / n - 1) * 100 - z) <= 0.06 for n in nums)
                    notes.append("上漲空間重算%s" % ("對" if okz else "對不上"))
                    if not okz:
                        bad.append("上漲空間 %s%% 重算對不上" % mu.group(1))
                elif not num_in(mu.group(1), text):
                    bad.append("上漲空間 %s%% 不在原文" % mu.group(1))
            continue
        sc = src_score(sg, rsq)
        if sc < 0.85:                                                    # 標題 + 句子黏在一起(原文中間隔著圖表字)→ 兩段各自在原文也算
            q = squash(sg)
            if any(q[:k] in rsq and src_score(q[k:], rsq) >= 0.9 for k in range(4, min(len(q) - 4, 24))):
                sc = 0.9
        nb = [n for n in re.findall(r"\d[\d,]*\.?\d*", sg) if len(n.strip(",.")) >= 2 and not num_in(n.strip(",."), text)]
        if sc < 0.85 or nb:
            bad.append("原文句覆蓋 %.0f%%%s「%s」" % (100 * sc, (" · 數字不在原文 " + "、".join(nb[:3])) if nb else "", sg[:30]))
    for i, (y, x, yoy) in enumerate(eps):
        if yoy is None:
            continue
        prev = eps[i - 1][1] if i and eps[i - 1][0] == y - 1 else None
        if prev is not None:
            ok_ = prev and abs((x / prev - 1) * 100 - yoy) <= 0.06
        else:
            nums = nums if nums is not None else _nums_raw(text)
            ok_ = any(n and abs((x / n - 1) * 100 - yoy) <= 0.06 for n in nums)
        notes.append("%d YoY 重算%s" % (y, "對" if ok_ else "對不上"))
        if not ok_:
            bad.append("%d YoY %.1f%% 重算對不上" % (y, yoy))
    return ("FAIL" if bad else "PASS"), " · ".join(bad or notes)[:200]


def verify_summary(rows, pdfdir):
    out = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        text = all_text(pdf)
        rsq = squash(text)
        chk = {}
        if x.get("TITLE"):
            sc = src_score(x["TITLE"], rsq)
            chk["TITLE"] = ("PASS" if sc >= 0.8 and not RATING_ONLY.match(nfk(x["TITLE"]).strip()) else "FAIL") + " · 原文覆蓋 %.0f%%" % (100 * sc)
        for i in range(1, 5):
            v = x.get("POINT_%d" % i) or ""
            if v:
                r_, n_ = verify_point(v, text, rsq)
                chk["POINT_%d" % i] = r_ + " · " + n_
        out.append({"FILENAME": x["FILENAME"], "checks": chk, "points_ok": x.get("POINTS_OK")})
    return out


def main(od, pdfdir, rep):
    od = Path(od)
    basic = json.loads((od / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
    fin = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
    vb = verify_basic(basic, pdfdir)
    vf = verify_fin(fin, pdfdir)
    sp = od / "VRN2_Summary_latest.json"
    vs = verify_summary(json.loads(sp.read_text(encoding="utf-8")), pdfdir) if sp.exists() else []
    sc_ = Counter(v.split(" ·")[0] for r in vs for v in r["checks"].values())
    bc = Counter(v.split(" ·")[0] for r in vb for v in r["checks"].values())
    fc = Counter(r["_V"] for r in vf)
    per_file = defaultdict(Counter)
    for r in vf:
        per_file[r["FILENAME"]][r["_V"]] += 1
    Path(rep).write_text(json.dumps({"basic": vb, "summary": vs, "summary_counts": dict(sc_), "fin_counts": dict(fc), "fin_per_file": {k: dict(v) for k, v in per_file.items()},
                                     "fin_bad": [r for r in vf if r["_V"] in ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM")]}, ensure_ascii=False, indent=1), encoding="utf-8")
    print("[驗證] 基本資料 %d 份 · 欄位檢查 %s" % (len(vb), dict(bc)))
    for r in vb:
        bad = {k: v for k, v in r["checks"].items() if v.startswith("FAIL")}
        if bad:
            print("  [FAIL] %s · %s" % (r["FILENAME"][:40], " | ".join("%s %s" % kv for kv in bad.items())[:300]))
    print("[驗證] 一標題四重點 %d 份 · 欄位檢查 %s" % (len(vs), dict(sc_)))
    for r in vs:
        bad = {k: v for k, v in r["checks"].items() if v.startswith("FAIL")}
        if bad:
            print("  [FAIL] %s · %s" % (r["FILENAME"][:40], " | ".join("%s %s" % kv for kv in bad.items())[:300]))
    print("[驗證] 年度數據 %d 筆 · %s" % (len(vf), dict(fc)))
    for f, c in sorted(per_file.items()):
        print("  %-46s %s" % (f[:46], dict(c)))
    return 0 if not any(v.startswith("FAIL") for r in vb + vs for v in r["checks"].values()) and not fc.get("FAIL") and not fc.get("MISALIGNED") and not fc.get("BADVALUE") and not fc.get("BADITEM") else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
