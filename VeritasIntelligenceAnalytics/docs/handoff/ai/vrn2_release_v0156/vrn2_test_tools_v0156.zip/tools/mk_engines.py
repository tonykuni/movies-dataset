"""共識引擎新版(只增 · 舊版一字不動):
  Fusion v0122 = v0121(桌機 · v0120 + 加速器橋 v0111)+ 出網一律經 VIA 統包網路工具(SUP_MDL740_NetUnified 最高版號)
  Matrix v0112 = v0111(操作員上傳)+ 加速器橋(同 Fusion v0121 那段)+ 同一套出網改法
兩支引擎原本只有兩個出網點:def_http_get(urllib 直連)· def_fetch_yfinance_info(yfinance 套件)—— 都改經網路工具;網路工具回 DENY = 停(不換道重試)。"""
import hashlib
import sys
from pathlib import Path

S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v156"
OUT = W / "new"
OUT.mkdir(parents=True, exist_ok=True)
FUSION_BASE = S / "v153/t153d/VIA/functional modules/VRN2/VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0121.py"
MATRIX_BASE = W / "up/VIA_FactSet_YFinance_Consensus_Matrix_Engine_v0111.py"
FUSION_V0120 = W / "up/VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py"

NET_BLOCK = r'''
# ===== [VIA:NET-TOOL:v0122] 出網一律經 VIA 統包網路工具(SUP_MDL740_NetUnified 最高版號 · 雙同意閘 · 核心 = 鎖冊 AegisNexus)=====
# 操作員 2026-10-31:「新版有版本號 · 加速器跟網路工具最新版都有版本號 · 改成經網路工具和加速器出網再抓」。
# 本引擎只有兩個出網點(def_http_get · def_fetch_yfinance_info)—— 都經網路工具的車道(http_bytes · yahoo_quote_summary_raw);
# 網路工具回 DENY(同意閘未開 / 合規)= 停,不換別的傳輸重試(VIA 規則:Explicit denials are never retried through another transport);
# 找不到網路工具 = 停(不退回直連)。同意閘(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT)是操作員的決定 · 本引擎永不代設。
_VIA_NET = {"mod": None, "path": None, "why": None}


def def_via_net():
    """VIA 統包網路工具(最高版號);找不到 / 載入失敗 → RuntimeError(不退回直連)。"""
    import importlib.util as _ilu
    import re as _re
    import sys as _sys
    from pathlib import Path as _P

    if _VIA_NET["mod"] is not None:
        return _VIA_NET["mod"]
    here = _P(__file__).resolve()
    hits = []
    for parent in [here.parent] + list(here.parents):
        folder = parent / "supportive modules" / "network"
        if folder.is_dir():
            hits = [p for p in folder.glob("SUP_MDL740_NetUnified_v*.py") if _re.fullmatch(r"SUP_MDL740_NetUnified_v\d{4}", p.stem)]
            if hits:
                break
    if not hits:
        _VIA_NET["why"] = "VIA_NET_TOOL_MISSING: supportive modules/network/SUP_MDL740_NetUnified_v####.py 不在(本引擎不退回直連)"
        raise RuntimeError(_VIA_NET["why"])
    path = max(hits, key=lambda p: int(p.stem.rsplit("_v", 1)[1]))
    spec = _ilu.spec_from_file_location("via_net_for_consensus_engine", path)
    mod = _ilu.module_from_spec(spec)
    _sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    _VIA_NET.update(mod=mod, path=str(path))
    return mod


def def_via_net_status():
    """網路工具 · 閘 · 加速器的狀態(不出網)。"""
    status = {"net_tool": None, "gate_open": False, "gate": None, "accelerator": None}
    try:
        net = def_via_net()
        status["net_tool"] = _P_name(_VIA_NET["path"])
        gate = net.gate_state() if callable(getattr(net, "gate_state", None)) else {}
        status["gate"] = {k: gate.get(k) for k in ("gate1_net_consent", "gate2_scrape_token_set", "gate1_raw", "scrape_value") if k in gate}
        status["gate_open"] = bool(gate.get("open"))
        status["accelerator"] = "VIA_SuperAccel_Module" if getattr(net, "VIA_ACCEL", None) is not None else None
    except Exception as exc:  # noqa: BLE001
        status["error"] = f"{type(exc).__name__}: {exc}"
    accel_ver = globals().get("_ACCEL_VER")
    if accel_ver:
        status["accelerator"] = (status["accelerator"] + " · " if status["accelerator"] else "") + accel_ver
    return status


def _P_name(path):
    from pathlib import Path as _P
    return _P(path).stem if path else None
# ===== [VIA:NET-TOOL:END] =====
'''

HTTP_GET_NEW = r'''def def_http_get(url, referer=None, timeout=None, retries=None):
    """v0122:經 VIA 統包網路工具 http_bytes 車道(雙同意閘先行 · 重試退避 · 404 不重試);DENY → PermissionError(不換道)。"""
    timeout_value = timeout or REQUEST_TIMEOUT_SECONDS
    retry_count = REQUEST_RETRIES if retries is None else retries
    net = def_via_net()
    result = net.http_bytes(
        url,
        timeout=timeout_value,
        retries=max(1, retry_count),
        backoff=REQUEST_BACKOFF_SECONDS,
        headers=def_build_headers(referer=referer),
    ) or {}
    state = result.get("state")
    if state == "DENY":
        raise PermissionError(f"VIA_NET_DENY: {result.get('note')} url={url}")
    if state != "OK":
        raise RuntimeError(f"HTTP_GET_FAILED: url={url} error={result.get('note')} via=VIA_NET")
    body = result.get("data") or b""
    status = int(result.get("status") or 200)
    if status != 200:
        raise RuntimeError(f"HTTP_GET_FAILED: url={url} error=HTTP_STATUS_{status} via=VIA_NET")
    return {
        "status": status,
        "url": url,
        "headers": {},
        "body": body,
        "sha256": def_sha256_bytes(body),
        "attempt": int(result.get("attempts") or 1),
        "via": "VIA_NET:%s/%s" % (_P_name(_VIA_NET["path"]), result.get("via")),
    }


'''

YF_NEW = r'''YF_QUOTE_SUMMARY_MODULES = "price,summaryDetail,financialData,defaultKeyStatistics,recommendationTrend,earningsTrend"


def def_yf_raw(value):
    """quoteSummary 的 {"raw": …, "fmt": …} → raw;其他原樣。"""
    if isinstance(value, dict) and "raw" in value:
        return value.get("raw")
    return value


def def_yf_flatten_quote_summary(result):
    """quoteSummary modules → yfinance Ticker.info 同名欄位(先到先得:price → summaryDetail → financialData → defaultKeyStatistics)。"""
    info = {}
    for module in ("price", "summaryDetail", "financialData", "defaultKeyStatistics"):
        block = (result or {}).get(module) or {}
        if not isinstance(block, dict):
            continue
        for key, value in block.items():
            if key not in info or info[key] in (None, ""):
                info[key] = def_yf_raw(value)
    price = (result or {}).get("price") or {}
    if isinstance(price, dict):
        info.setdefault("symbol", price.get("symbol"))
        info["shortName"] = info.get("shortName") or price.get("shortName")
        info["longName"] = info.get("longName") or price.get("longName")
        info["currency"] = info.get("currency") or price.get("currency")
    return info


def def_yf_analysis_from_quote_summary(result, info):
    """quoteSummary 的 recommendationTrend / earningsTrend → 與 yfinance 分析方法同名的表(列 = dict)。"""
    analysis = {}
    analysis["get_analyst_price_targets"] = {
        "current": info.get("currentPrice"),
        "low": info.get("targetLowPrice"),
        "mean": info.get("targetMeanPrice"),
        "median": info.get("targetMedianPrice"),
        "high": info.get("targetHighPrice"),
    } if any(info.get(k) is not None for k in ("targetLowPrice", "targetMeanPrice", "targetMedianPrice", "targetHighPrice")) else None
    trend = ((result or {}).get("earningsTrend") or {}).get("trend") or []
    def rows(key, fields):
        out = []
        for item in trend:
            if not isinstance(item, dict):
                continue
            block = item.get(key) or {}
            if not isinstance(block, dict) or not block:
                continue
            row = {"period": item.get("period"), "endDate": item.get("endDate")}
            for name in fields:
                if name in block:
                    row[name] = def_yf_raw(block.get(name))
            if len(row) > 2:
                out.append(row)
        return out or None
    analysis["get_earnings_estimate"] = rows("earningsEstimate", ["avg", "low", "high", "yearAgoEps", "numberOfAnalysts", "growth"])
    analysis["get_revenue_estimate"] = rows("revenueEstimate", ["avg", "low", "high", "numberOfAnalysts", "yearAgoRevenue", "growth"])
    analysis["get_eps_trend"] = rows("epsTrend", ["current", "7daysAgo", "30daysAgo", "60daysAgo", "90daysAgo"])
    analysis["get_eps_revisions"] = rows("epsRevisions", ["upLast7days", "upLast30days", "downLast30days", "downLast90days"])
    growth = [{"period": item.get("period"), "growth": def_yf_raw(item.get("growth"))} for item in trend if isinstance(item, dict) and item.get("growth") is not None]
    analysis["get_growth_estimates"] = growth or None
    rec = ((result or {}).get("recommendationTrend") or {}).get("trend") or []
    analysis["get_recommendations_summary"] = [
        {k: def_yf_raw(v) for k, v in item.items()} for item in rec if isinstance(item, dict)
    ] or None
    status = {
        name: {"status": "PASS" if analysis.get(name) not in (None, {}, []) else "NO_COVERAGE", "error": None, "via": "VIA_NET:yahoo_quote_summary_raw"}
        for name in YFINANCE_ANALYSIS_METHODS
    }
    for name in YFINANCE_ANALYSIS_METHODS:
        analysis.setdefault(name, None)
    return analysis, status


def def_fetch_yfinance_info(yfinance_ticker):
    """v0122:YFinance 共識經 VIA 統包網路工具 yahoo_quote_summary_raw 車道(不用 yfinance 套件直連);DENY → PermissionError(不換道)。"""
    import json as _json
    import time

    ticker = def_validate_yfinance_ticker(yfinance_ticker)
    net = def_via_net()
    last_error = None
    for attempt in range(YFINANCE_REQUEST_RETRIES):
        result = net.yahoo_quote_summary_raw([ticker], YF_QUOTE_SUMMARY_MODULES) or {}
        state = result.get("state")
        if state == "DENY":
            raise PermissionError(f"VIA_NET_DENY: {result.get('note')} ticker={ticker}")
        found = (result.get("results") or {}).get(ticker)
        if state == "OK" and isinstance(found, dict) and found:
            info = def_yf_flatten_quote_summary(found)
            selected = {field: info.get(field) for field in YFINANCE_INFO_FIELDS}
            analysis, method_status = def_yf_analysis_from_quote_summary(found, info)
            selected = def_merge_yfinance_price_targets(selected, analysis)
            adj_close = def_safe_float(info.get("currentPrice") if info.get("currentPrice") is not None else info.get("regularMarketPrice"))
            selected["adjClose"] = adj_close
            core_coverage = any(selected.get(field) is not None for field in ["targetLowPrice", "targetMeanPrice", "targetMedianPrice", "targetHighPrice", "recommendationKey"])
            analysis_coverage = any(value not in [None, {}, []] for value in analysis.values())
            return {
                "url": YFINANCE_SOURCE_URL_TEMPLATE.format(ticker=ticker),
                "http_status": 200,
                "sha256": def_sha256_bytes(_json.dumps(def_json_ready({"info": selected, "analysis": analysis, "method_status": method_status}), ensure_ascii=False, sort_keys=True).encode("utf-8")),
                "data": selected,
                "analysis": analysis,
                "method_status": method_status,
                "coverage_status": "COVERED" if core_coverage or analysis_coverage else "NO_COVERAGE",
                "source_mode": "YFINANCE_CONSENSUS_BUNDLE_LIVE",
                "captured_at_utc": def_now_utc_iso(),
                "yfinance_version": "quoteSummary via %s" % _P_name(_VIA_NET["path"]),
                "adj_close_source": "INFO_PRICE_FALLBACK",
                "attempt": attempt + 1,
            }
        failed = result.get("failed") or []
        last_error = (failed[0].get("err") if failed and isinstance(failed[0], dict) else None) or result.get("note") or state
        if attempt + 1 < YFINANCE_REQUEST_RETRIES:
            time.sleep(YFINANCE_RETRY_SLEEP_SECONDS * (attempt + 1))
    raise RuntimeError(f"YFINANCE_INFO_FETCH_FAILED: ticker={ticker} error={last_error} via=VIA_NET")


'''


YF_NEW_MATRIX = r"""def def_fetch_yfinance_info(yfinance_ticker):
    '''v0112:YFinance 經 VIA 統包網路工具 yahoo_quote_summary_raw 車道(不用 yfinance 套件直連);DENY → PermissionError(不換道)。'''
    import json as _json
    import time

    ticker = def_validate_yfinance_ticker(yfinance_ticker)
    net = def_via_net()
    last_error = None
    for attempt in range(YFINANCE_REQUEST_RETRIES):
        result = net.yahoo_quote_summary_raw([ticker], "price,summaryDetail,financialData,defaultKeyStatistics") or {}
        state = result.get("state")
        if state == "DENY":
            raise PermissionError(f"VIA_NET_DENY: {result.get('note')} ticker={ticker}")
        found = (result.get("results") or {}).get(ticker)
        if state == "OK" and isinstance(found, dict) and found:
            info = {}
            for module in ("price", "summaryDetail", "financialData", "defaultKeyStatistics"):
                block = found.get(module) or {}
                if isinstance(block, dict):
                    for key, value in block.items():
                        if key not in info or info[key] in (None, ""):
                            info[key] = value.get("raw") if isinstance(value, dict) and "raw" in value else value
            selected = {field: info.get(field) for field in YFINANCE_INFO_FIELDS}
            selected["adjClose"] = def_safe_float(info.get("currentPrice") if info.get("currentPrice") is not None else info.get("regularMarketPrice"))
            if any(selected.get(field) is not None for field in ["targetLowPrice", "targetMeanPrice", "targetMedianPrice", "targetHighPrice", "recommendationKey"]):
                return {
                    "url": YFINANCE_SOURCE_URL_TEMPLATE.format(ticker=ticker),
                    "http_status": 200,
                    "sha256": def_sha256_bytes(_json.dumps(def_json_ready(selected), ensure_ascii=False, sort_keys=True).encode("utf-8")),
                    "data": selected,
                    "source_mode": "YFINANCE_INFO_LIVE",
                    "captured_at_utc": def_now_utc_iso(),
                    "yfinance_version": "quoteSummary via %s" % _P_name(_VIA_NET["path"]),
                    "adj_close_source": "INFO_PRICE_FALLBACK",
                    "attempt": attempt + 1,
                }
            last_error = "YFINANCE_INFO_CONSENSUS_FIELDS_ALL_MISSING"
        else:
            failed = result.get("failed") or []
            last_error = (failed[0].get("err") if failed and isinstance(failed[0], dict) else None) or result.get("note") or state
        if attempt + 1 < YFINANCE_REQUEST_RETRIES:
            time.sleep(YFINANCE_RETRY_SLEEP_SECONDS * (attempt + 1))
    raise RuntimeError(f"YFINANCE_INFO_FETCH_FAILED: ticker={ticker} error={last_error} via=VIA_NET")


"""


def _cut_def(src: str, name: str) -> tuple:
    """回 (起, 迄):`def name(` 那一行 → 下一個頂層 def / 註解區塊之前。"""
    start = src.index("\ndef %s(" % name) + 1
    tail = src[start + 1:]
    import re
    m = re.search(r"\n(?=(def |class |# =====|[A-Z_][A-Z0-9_]* = ))", tail)
    end = start + 1 + (m.start() + 1 if m else len(tail))
    return start, end


def _replace_def(src: str, name: str, new: str) -> str:
    start, end = _cut_def(src, name)
    return src[:start] + new + src[end:].lstrip("\n")


def build(base_text: str, label: str, version: str, accel_from: str | None, yf_new: str = YF_NEW) -> str:
    s = base_text
    if accel_from is not None:                                                # Matrix:先接上同一段加速器橋(Fusion v0121 那段)
        a0 = accel_from.index("# ===== [VIA:ACCEL-BRIDGE:v0111]")
        a1 = accel_from.index("# ===== [VIA:ACCEL-BRIDGE:END] =====") + len("# ===== [VIA:ACCEL-BRIDGE:END] =====")
        doc_end = s.index('"""', s.index('"""') + 3) + 3
        s = s[:doc_end] + "\n" + accel_from[a0:a1] + "\n" + s[doc_end:]
    marker = "# ===== [VIA:ACCEL-BRIDGE:END] ====="
    assert s.count(marker) == 1, label
    s = s.replace(marker, marker + "\n" + NET_BLOCK, 1)
    s = _replace_def(s, "def_http_get", HTTP_GET_NEW)
    s = _replace_def(s, "def_fetch_yfinance_info", yf_new)
    old_dep = '''    if live_mode:
        required.append("yfinance")'''
    if s.count(old_dep) == 1:
        s = s.replace(old_dep, '''    if live_mode:
        required.append("requests")                                          # v0122:YFinance 經網路工具 quoteSummary 車道(要 requests · 不再要 yfinance)''', 1)
    import re
    s = re.sub(r"DEPENDENCY_INSTALL_COMMAND = \(\n(    '[^\n]*\n)+\)", "DEPENDENCY_INSTALL_COMMAND = (\n    '經 VCGC 環境工具管理引擎補:requests duckdb pyarrow pandas(不要自己 pip)'\n)", s, count=1)
    dep_line = '''    print(
        f"def Mode       : "
        f"{def_display_source_mode('OFFLINE_LIVE_FIXTURE') if offline_mode else '即時資料'}"
    )'''
    assert s.count(dep_line) == 1, label
    s = s.replace(dep_line, dep_line + '''
    net_status = def_via_net_status()
    print(f"def Net tool   : {net_status.get('net_tool') or net_status.get('error')} · 閘 {'開' if net_status.get('gate_open') else '關'} · 加速器 {net_status.get('accelerator') or '—'}")
    if not offline_mode and net_status.get("error"):
        raise RuntimeError(f"VIA_NET_TOOL_MISSING: {net_status.get('error')}(本引擎不退回直連)")
    if not offline_mode and not net_status.get("gate_open"):
        raise PermissionError("VIA_NET_DENY: VIA 網路工具同意閘未開(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT · 操作員決定 · 引擎不代設 · 不換道直連)")''', 1)
    # offline_mode 在 dep_line 之前定義(def_run_pipeline 開頭)—— 確認
    run0 = s.index("\ndef def_run_pipeline(")
    assert s.index("offline_mode = bool(fixtures)", run0) < s.index(dep_line, run0), label
    note = ("%s — %s(VRN-2 · 2026-10-31 · 操作員令「改成經網路工具和加速器出網再抓」):\n"
            "  出網一律經 VIA 統包網路工具 SUP_MDL740_NetUnified(最高版號 · 雙同意閘 · 核心 = 鎖冊 AegisNexus)+ 加速器(VeritasCeleritas 最高版號 · 退回鎖版 v1141):\n"
            "  鉅亨頁 / API → http_bytes 車道 · YFinance → yahoo_quote_summary_raw 車道(不再直接用 yfinance 套件);DENY = 停(不換道直連);\n"
            "  同意閘未開(即時模式)→ 開跑前就停(PermissionError VIA_NET_DENY);離線 fixture 照舊不出網。其餘邏輯一字不動。\n\n") % (label, version)
    first = s.index('"""') + 3
    s = s[:first] + "\n" + note + s[first:].lstrip("\n")
    compile(s, label, "exec")
    return s


fusion = build(FUSION_BASE.read_text(encoding="utf-8"), "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine", "v0122", None)
(OUT / "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py").write_text(fusion, encoding="utf-8", newline="\n")
matrix = build(MATRIX_BASE.read_text(encoding="utf-8"), "VIA_FactSet_YFinance_Consensus_Matrix_Engine", "v0112", FUSION_BASE.read_text(encoding="utf-8"), YF_NEW_MATRIX)
(OUT / "VIA_FactSet_YFinance_Consensus_Matrix_Engine_v0112.py").write_text(matrix, encoding="utf-8", newline="\n")
for p in sorted(OUT.glob("VIA_*.py")):
    t = p.read_text(encoding="utf-8")
    print(p.name, t.count("\n"), "行", hashlib.sha256(t.encode()).hexdigest()[:12], "· urlopen 呼叫", t.count("urlopen(request"), "· import yfinance", t.count("import yfinance"))
