"""VRN2_RoundAll_v0112.py = v0111 + 套件 v0156(共識引擎 v0122 經 VIA 網路工具 + 加速器 · ConsensusJoin v0104)+ 收尾頁 DENY 負責方 + ⑤ 經網路工具重抓 ⑥f。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v155/new/VRN2_RoundAll_v0111.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0111'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0111 — ', '"""VRN2_RoundAll v0112 — ', 1)
at = doc.index("v0111(桌機 2026-10-31 02:06")
doc = doc[:at] + r'''v0112(操作員 2026-10-31:「新版有版本號 · 加速器跟網路工具最新版都有版本號 · 直接透過 VCGC 的環境工具管理引擎下載所有不足工具及環境並確認無衝突 ·
  改成經網路工具和加速器出網再抓」):
  · 套件 v0156(啟動器 v0156 · runtime v0156 = v0154 的 190 個成員不動 + 共識引擎 v0122 + ConsensusJoin v0104)。引擎 v0122 = v0121 + 出網一律經
    VIA 統包網路工具 SUP_MDL740_NetUnified(最高版號 · 雙同意閘 · 核心 = 鎖冊 AegisNexus v1652)+ 加速器(VeritasCeleritas 最高版號):鉅亨 → http_bytes ·
    YFinance → yahoo_quote_summary_raw(不再直接用 yfinance 套件);DENY = 停、不換道直連。
  · 收尾頁:⑥f 共識收據有 net_deny → 同意閘未開 = 人工(操作員決定 · VRN-2 不代設)· 合規 DENY = VCGC;Combined 那幾格同樣分。
  · ⑤ 自動修(新):共識收據不是經網路工具的引擎抓的,而且同意閘是開的(VIA_NET_CONSENT=YES · VIA_SCRAPE_CONSENT=YES / I_ACCEPT_RESPONSIBLE_SCRAPING,
    操作員設的)→ 套件 runtime 的 ConsensusJoin 鏈 + 引擎只增不覆寫地補放 → VIA_VRN2_CONSENSUS_REFRESH=1 重跑 ⑥f(今天的 checkpoint 封存 · 全部經網路工具重抓)
    → 重組 Combined;閘關 → 不重抓(現有共識不動)· 除錯報告寫一列「同意閘未開 · 操作員決定」。
  · 除錯報告:⑥f 經 VIA 網路工具(網路工具版號 · 閘開關 · 加速器)/ VIA 網路工具 DENY。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0111.py", "用法:python VRN2_RoundAll_v0112.py")
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
body = body.replace("v0154", "v0156")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0111"', 'VERSION = "v0112"')
rep('("VRN2_ConsensusJoin_v0103.py", 900)', '("VRN2_ConsensusJoin_v0104.py", 900)')
rep('''_PERMANENT = re.compile(r"HTTP Error (?:400|401|403|404|410)\\b")
''', '''_PERMANENT = re.compile(r"HTTP Error (?:400|401|403|404|410)\\b")
SCRAPE_OPEN = {"YES", "I_ACCEPT_RESPONSIBLE_SCRAPING"}                   # v0112 同 CGC_MDL224_ScrapeGate(只讀 · 不設)


def net_gate_open(env=None) -> bool:
    """v0112 VIA 網路工具的雙同意閘開不開(操作員設的環境變數;本檔永不代設)。"""
    env = os.environ if env is None else env
    return env.get("VIA_NET_CONSENT") == "YES" and (env.get("VIA_SCRAPE_CONSENT") or "") in SCRAPE_OPEN
''')
rep('''           "cj_v0103": "retries" in cons, "engine_no_output": cons.get("engine_no_output")}''',
    '''           "cj_v0103": "retries" in cons, "engine_no_output": cons.get("engine_no_output"), "net_deny": cons.get("net_deny"), "net_tool": cons.get("net_tool")}''')
rep('''            if ctx.get("engine_no_output"):                                   # v0110 引擎這次沒有產出(品質矩陣 / 矩陣都是上次的 · 不看)''',
    '''            nd = ctx.get("net_deny")                                         # v0112 經 VIA 網路工具的引擎被 DENY:不重試 · 不換道
            if nd:
                if nd.get("gate_closed"):
                    return "人工", ("VIA 網路工具同意閘未開(%s)· 操作員決定:要抓就在同一個 PowerShell 先設 $env:VIA_NET_CONSENT='YES' 與 "
                                   "$env:VIA_SCRAPE_CONSENT='YES' 再跑(VRN-2 不代設 · 不換道直連)" % str(nd.get("note") or "")[:60])
                return "VCGC", "VIA 網路工具合規 DENY(%s)→ 放不放行是 VCGC 的決定 · 不繞道" % str(nd.get("note") or "")[:80]
            if ctx.get("engine_no_output"):                                   # v0110 引擎這次沒有產出(品質矩陣 / 矩陣都是上次的 · 不看)''')
rep('''                elif "共識引擎這次沒有產出" in st_row:''', '''                elif "VIA 網路工具 DENY" in st_row:                              # v0112
                    closed = "操作員的決定" in st_row or "同意閘" in st_row
                    add(col, "VIA 網路工具 DENY(%s)" % ("同意閘未開 · 操作員決定" if closed else "合規 · VCGC"), "人工" if closed else "VCGC", fname)
                elif "共識引擎這次沒有產出" in st_row:''')
rep('''    cons_now = jread(cjson, {}) or {}
    q404, qtr, qother = gate_rows(v2)''', '''    cons_now = jread(cjson, {}) or {}
    if (fetch_py and not any(k == "consensus" for k, _ in plan) and cons_now and not cons_now.get("net_tool") and not cons_now.get("net_deny") and not cons_now.get("net_engine") and net_gate_open()
            and os.environ.get("VIA_VRN2_NO_CONSENSUS") != "1" and os.environ.get("VIA_VRN2_NO_CONSENSUS_REFRESH") != "1"):   # v0112 共識還是直連引擎抓的
        plan.append(("consensus_refresh", "⑥f 改經 VIA 網路工具重抓(共識引擎 v0122 · ConsensusJoin v0104 · 同意閘開)"))
    q404, qtr, qother = gate_rows(v2)''')
rep('''    if (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and (planned & {"market", "consensus"} or not comb.is_file() or max(_mtime(mjson), _mtime(cjson)) > _mtime(comb)):''',
    '''    if (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and (planned & {"market", "consensus", "consensus_refresh"} or not comb.is_file() or max(_mtime(mjson), _mtime(cjson)) > _mtime(comb)):''')
rep('''        elif key == "consensus":
            put, refused = place_consensus(state.get("pkg"), root)''', '''        elif key == "consensus_refresh":                                      # v0112 經 VIA 網路工具重抓(今天的 checkpoint 封存)
            put, refused = place_consensus(state.get("pkg"), root)
            cj = _latest_in(rt, "VRN2_ConsensusJoin_v[0-9][0-9][0-9][0-9].py")
            env_r = dict(env, VIA_VRN2_CONSENSUS_REFRESH="1")
            rc, lines = run_stream([vpy, "-X", "utf8", str(cj), "run", "--v2", str(v2), "--root", str(root)], cwd=rt, env=env_r, timeout=1800, prefix="    [⑥f] ")
            lamp, detail = _cli_lamp(lines)
            net_line = next((l.split(":", 1)[1].strip() for l in lines if "def Net tool" in l), "")
            detail = ("%s%s · %s%s" % (("補放 " + "、".join(put) + " · ") if put else "", (" · 不覆寫 " + "、".join(refused) + " · ") if refused else "", detail,
                                       (" · 網路工具 " + net_line) if net_line else "")).strip(" ·")
            step_updates["⑥f"] = (lamp if lamp != "RED" else "YELLOW", detail)
        elif key == "consensus":
            put, refused = place_consensus(state.get("pkg"), root)''')
rep('''    gap = cons_rec.get("source_gap") or {}
    if gap:                                                                   # v0110 ConsensusJoin v0103 重試後仍抓不到''', '''    nd = cons_rec.get("net_deny") or {}
    if nd:                                                                    # v0112
        f("YELLOW", "⑥f VIA 網路工具 DENY", "%s · %s" % (str(nd.get("note") or "")[:200], "同意閘未開(操作員決定)" if nd.get("gate_closed") else "合規 DENY(VCGC 決定)"),
          "不重試、不換道直連;同意閘是操作員的環境變數(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT)· VRN-2 不代設")
    elif cons_rec.get("net_tool"):
        f("GREEN", "⑥f 經 VIA 網路工具", str(cons_rec.get("net_tool"))[:200])
    elif cons_rec and not cons_rec.get("net_engine") and not net_gate_open():
        f("YELLOW", "⑥f 共識還沒經 VIA 網路工具", "這份共識是直連引擎抓的(%s)· 同意閘未開 → 這輪沒重抓(現有共識不動)" % Path(str(cons_rec.get("engine") or "?")).name,
          "要經網路工具重抓:操作員在同一個 PowerShell 先設 $env:VIA_NET_CONSENT='YES' 與 $env:VIA_SCRAPE_CONSENT='YES' 再跑 · VRN-2 不代設")
    gap = cons_rec.get("source_gap") or {}
    if gap:                                                                   # v0110 ConsensusJoin v0103 重試後仍抓不到''')
rep('''        if "Yahoo 代號" in step:
            return "資料源", "Yahoo 沒有這些代號"''', '''        if "Yahoo 代號" in step:
            return "資料源", "Yahoo 沒有這些代號"
        if "共識還沒經 VIA 網路工具" in step:                                 # v0112
            return "人工", "同意閘是操作員的決定(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT)· 開了 repair 會經網路工具重抓 · VRN-2 不代設"''')
rep('''    if re.search(r"MOPS|network bridge denied|網路工具 DENY", text):
''', '''    if re.search(r"MOPS|network bridge denied", text) or "網路工具 DENY" in text and not re.search(r"⑥f|⑥ Combined 冊", step):   # v0112 ⑥f 共識的 DENY 下面分
''')
# 自測 52 ~ 55
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()''', r'''        # 52 ~ 55 v0112 經 VIA 網路工具
        nd_closed = {"note": "VIA_NET_DENY: VIA 網路工具同意閘未開(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT · 操作員決定)", "gate_closed": True}
        row52 = {"lamp": "YELLOW", "step": "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)", "detail": "共識 YELLOW:VIA 網路工具 DENY(…)· 同意閘 … 是操作員的決定"}
        o52 = owner_of(row52, dict(cx10, net_deny=nd_closed, gate_transient=set(), gate_other=set()))
        o52b = owner_of(row52, dict(cx10, net_deny={"note": "VIA_NET_DENY: robots", "gate_closed": False}, gate_transient=set(), gate_other=set()))
        g52, ow52 = combined_gaps([{"TICKER": "2330", "TARGET_PRICE": "", "FACTSET_TARGET_PRICE_MEDIAN": "", "STATUS": "CONSENSUS: 缺:VIA 網路工具 DENY(x)· 同意閘 VIA_NET_CONSENT 是操作員的決定"}], set(), True)
        chk("52 收尾頁:共識經 VIA 網路工具被 DENY · 同意閘未開 → 人工(操作員決定 · 不代設)· 合規 DENY → VCGC · Combined 那幾格同樣分",
            o52[0] == "人工" and "VIA_NET_CONSENT" in o52[1] and o52b[0] == "VCGC" and ow52 == "人工" and "VIA 網路工具 DENY(同意閘未開 · 操作員決定)" in g52["FACTSET_TARGET_PRICE_MEDIAN"])
        env53 = {k: os.environ.get(k) for k in ("VIA_NET_CONSENT", "VIA_SCRAPE_CONSENT")}
        for k in env53:
            os.environ.pop(k, None)
        try:
            closed53 = net_gate_open()
            open53 = net_gate_open({"VIA_NET_CONSENT": "YES", "VIA_SCRAPE_CONSENT": "I_ACCEPT_RESPONSIBLE_SCRAPING"})
            half53 = net_gate_open({"VIA_NET_CONSENT": "YES", "VIA_SCRAPE_CONSENT": "OFF"})
            (v10 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"gate": "PASS", "engine": "x/VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0121.py"}), encoding="utf-8")
            qm.write_text("\ufeffcode,check_id,actual,expected,status,severity,note\n2330,HTTP_PAGE_200,200,200,PASS,FAIL,ok\n", encoding="utf-8")
            if not (v10 / RECEIPT).is_file():
                (v10 / RECEIPT).write_text(json.dumps({"version": "ActivateVRN-2 v0156", "rc": 2, "elapsed_s": 1, "steps": []}), encoding="utf-8")
            p53 = [k for k, _ in plan_fixes(r10, {"consensus": {"run": {"lamp": "GREEN", "gate": "PASS"}}}, "/x/py", A(), "")]
            rep53 = diagnose(r10, None)
            row53 = next((x for x in rep53.get("findings") or [] if x["area"].startswith("⑥f 共識還沒經 VIA 網路工具")), None)
        finally:
            for k, v in env53.items():
                if v is not None:
                    os.environ[k] = v
        chk("53 同意閘判斷同 VCGC 的 ScrapeGate(YES + YES / 合規 token 才算開 · OFF 不算)· 閘關 → 不排重抓 · 除錯報告寫「共識還沒經 VIA 網路工具 · 操作員決定」",
            not closed53 and open53 and not half53 and "consensus_refresh" not in p53 and row53 is not None and owner_of({"lamp": "YELLOW", "step": "⑥ " + row53["area"], "detail": row53["finding"]}, cx10)[0] == "人工")
        p54 = [k for k, _ in plan_fixes(r10, {"consensus": {"run": {"lamp": "GREEN", "gate": "PASS"}}}, "/x/py", A(), "")] if False else None
        os.environ["VIA_NET_CONSENT"], os.environ["VIA_SCRAPE_CONSENT"] = "SELFTEST-NOT-OPEN", "SELFTEST-NOT-OPEN"    # 不是開(值不對)· 只驗不誤開
        try:
            p54 = [k for k, _ in plan_fixes(r10, {"consensus": {"run": {"lamp": "GREEN", "gate": "PASS"}}}, "/x/py", A(), "")]
        finally:
            for k, v in env53.items():
                os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
        orig_gate = globals()["net_gate_open"]
        globals()["net_gate_open"] = lambda env=None: True                     # 函式替身擬開(不設環境變數)
        try:
            p54b = [k for k, _ in plan_fixes(r10, {"consensus": {"run": {"lamp": "GREEN", "gate": "PASS"}}}, "/x/py", A(), "")]
            (v10 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"gate": "PASS", "net_tool": "SUP_MDL740_NetUnified_v0119 · 閘 開"}), encoding="utf-8")
            p54c = [k for k, _ in plan_fixes(r10, {"consensus": {"run": {"lamp": "GREEN", "gate": "PASS"}}}, "/x/py", A(), "")]
            (v10 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"gate": "", "net_engine": "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py",
                                                                                     "why": "擷取環境缺 requests"}), encoding="utf-8")
            p54d = [k for k, _ in plan_fixes(r10, {"consensus": {"run": {"lamp": "YELLOW", "gate": ""}}}, "/x/py", A(), "")]
            rep54d = diagnose(r10, None)
        finally:
            globals()["net_gate_open"] = orig_gate
        areas54d = [x["area"] for x in rep54d.get("findings") or []]
        chk("54 ⑤ 自動修:共識是直連引擎抓的 + 同意閘開(替身)→ 經網路工具重抓 ⑥f + 重組 Combined · 閘值不對 → 不排 · 已經經網路工具 → 不排 · 經網路工具的引擎沒跑到出網(缺 requests)→ 不排 · 不列綠",
            "consensus_refresh" not in p54 and p54b[:2] == ["consensus_refresh", "combined"] and "consensus_refresh" not in p54c and "consensus_refresh" not in p54d
            and "⑥f 經 VIA 網路工具" not in areas54d and not any(a.startswith("⑥f 共識還沒經 VIA 網路工具") for a in areas54d))
        (v10 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"gate": "PASS", "net_tool": "SUP_MDL740_NetUnified_v0119 · 閘 開"}), encoding="utf-8")
        rep55 = diagnose(r10, None)
        row55 = next((x for x in rep55.get("findings") or [] if x["area"] == "⑥f 經 VIA 網路工具"), None)
        chk("55 除錯報告:共識是經 VIA 網路工具抓的 → 綠列(網路工具版號 · 閘 · 加速器)", row55 is not None and row55["lamp"] == "GREEN" and "NetUnified_v0119" in row55["finding"])
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0111.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0112.py"').replace('"VRN2_RoundAll_v0111.py" in html_', '"VRN2_RoundAll_v0112.py" in html_')
assert "VRN2_RoundAll_v0111.py" not in s, [m.start() for m in re.finditer("VRN2_RoundAll_v0111.py", s)]
(S / "v156/new/VRN2_RoundAll_v0112.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0112 lines", s.count("\n"))
