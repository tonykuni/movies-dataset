import hashlib, json, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); old, new, out = S / "v154/pkg154", S / "v156/new", S / "v156/pkg156"
out.mkdir(parents=True, exist_ok=True)
om = json.loads((old / "VRN2_Runtime_v0154.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
with zipfile.ZipFile(old / "VRN2_Runtime_v0154.zip") as z: members = {n: z.read(n) for n in old_names}
for e in om["files"]: assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"]
assert hashlib.sha256((old / "VRN2_Runtime_v0154.zip").read_bytes()).hexdigest() == om["zip_sha256"]
new_names = ["VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py", "VRN2_ConsensusJoin_v0104.py"]
for n in new_names: assert n not in members, n; members[n] = (new / n).read_bytes()
assert all("VRN2_ConsensusJoin_v010%d.py" % i in members for i in range(4)) and "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py" in members
assert "VRN_SystemManager_v0257.py" in members and "VRN2_IndependentVerifier_v0114.py" in members and len(old_names) == 190
names = sorted(members); zp = out / "VRN2_Runtime_v0156.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0156", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0154.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names,
       "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0156.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(str(old / n), str(out / n))
shutil.copy2(str(new / "ActivateVRN-2_v0156.py"), str(out / "ActivateVRN-2_v0156.py"))
print("runtime v0156", len(names), man["zip_sha256"][:12], "· pkg156", sorted(p.name for p in out.iterdir()))
