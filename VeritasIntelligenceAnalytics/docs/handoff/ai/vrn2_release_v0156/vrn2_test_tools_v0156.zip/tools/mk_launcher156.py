"""ActivateVRN-2_v0156.py = v0154 + ⑥f ConsensusJoin v0104(共識引擎 v0122 經 VIA 網路工具 + 加速器出網)· 操作員 2026-10-31。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v154/new/ActivateVRN-2_v0154.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0154: v0153 entry + the desktop run of 2026-10-30 20:09',
    '"""VRN-2 v0156: v0154 entry + the operator request of 2026-10-31 ("新版有版本號 · 加速器跟網路工具最新版都有版本號 · 直接透過 VCGC 的環境工具管理引擎\n'
    ' 下載所有不足工具及環境並確認無衝突 · 改成經網路工具和加速器出網再抓"). v0155 was the RoundAll-only round (no launcher v0155).\n\n'
    ' - step 6f VRN2_ConsensusJoin_v0104 (thin tail over v0103): the bundled consensus engine is now\n'
    '   VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122 (v0121 + every outbound request through the VIA network tool\n'
    '   SUP_MDL740_NetUnified, highest version, core = locked AegisNexus v1652; accelerator bridge = highest VeritasCeleritas):\n'
    '   cnyes -> http_bytes lane, YFinance -> yahoo_quote_summary_raw lane (no yfinance package). The network tool\'s double consent gate\n'
    '   (VIA_NET_CONSENT / VIA_SCRAPE_CONSENT) is the operator\'s; closed -> the engine stops before fetching, ⑥f YELLOW with net_deny\n'
    '   (never retried through another transport, never set by VRN-2). Today\'s checkpoint fetched by the direct engine v0120 + gate open ->\n'
    '   archived with the engine\'s own function and fetched again through the network tool; the fetch-Python probe checks requests.\n'
    ' Runtime v0156 = runtime v0154 (190 members byte-identical) + VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122 + VRN2_ConsensusJoin_v0104.\n\n'
    'v0154: v0153 entry + the desktop run of 2026-10-30 20:09')
for a, b in (('VERSION = "ActivateVRN-2 v0154"', 'VERSION = "ActivateVRN-2 v0156"'), ('RUNTIME_ZIP = "VRN2_Runtime_v0154.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0156.zip"'),
             ('RUNTIME_MANIFEST = "VRN2_Runtime_v0154.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0156.json"'), ('RECEIPT_NAME = "VRN2_Closeout_v0154.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0156.json"'),
             ('launcher = root / "package" / "ActivateVRN-2_v0154.py"', 'launcher = root / "package" / "ActivateVRN-2_v0156.py"'),
             ('return lamp, detail + " · launcher v0154"', 'return lamp, detail + " · launcher v0156"'), ('print("NEXT: [%s] VRN-2 v0154 · rc %s', 'print("NEXT: [%s] VRN-2 v0156 · rc %s'),
             ('note="VRN-2 private runtime; exact ship v0154; manager v0257 (over v0255); consensus join v0103; shared VRN retained"',
              'note="VRN-2 private runtime; exact ship v0156; manager v0257 (over v0255); consensus join v0104 + engine v0122 via VIA network tool; shared VRN retained"'),
             ('CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0103.py"   # v0154:',
              'CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0104.py"   # v0156: thin tail over v0103 (engine v0122 through the VIA network tool + accelerator · net_deny · provenance refresh) · v0154:')):
    rep(a, b)
rep('CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"',
    'CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"', 3)
rep('assert cj.VERSION == "v0103" and cj.PRIOR.VERSION == "v0102" and cj.PRIOR.PRIOR.VERSION == "v0101" and cj.ticker_map(output)',
    'assert cj.VERSION == "v0104" and cj.PRIOR.VERSION == "v0103" and cj.PRIOR.PRIOR.VERSION == "v0102" and cj.PRIOR.PRIOR.PRIOR.VERSION == "v0101" and cj.ticker_map(output)')
rep('assert cj.VERSION == "v0103" and sorted(cj.no_coverage(rows, ["2330", "6933", "4171"])) == ["4171", "6933"]',
    'assert cj.VERSION == "v0104" and sorted(cj.no_coverage(rows, ["2330", "6933", "4171"])) == ["4171", "6933"]')
rep('''        assert cj.PRIOR.run is cj.run and cj.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.join is cj.join
''', '''        assert cj.PRIOR.run is cj.run and cj.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.PRIOR.run is cj.run
        assert cj.PRIOR.PRIOR.PRIOR.PRIOR.join is cj.join and cj.join is cj.PRIOR.join                                          # v0156: v0104 run · v0103 join
        assert cj.provenance_refresh(Path(temporary) / "none", "/no/engine.py", gate_open=True).get("archived") is None          # no engine → nothing archived
''')
rep('''"no_coverage", "source_gap", "first_gate", "retries", "seed") if k in ran}''',
    '''"no_coverage", "source_gap", "first_gate", "retries", "seed", "net_tool", "net_deny", "net_engine", "refresh", "engine_no_output") if k in ran}''')
# v0154 block: v0103 is now the PRIOR (still checked by name), v0104 the active one
rep('''    cj103 = selftest_source(CONSENSUS_JOIN).read_text(encoding="utf-8")
    assert CONSENSUS_JOIN == "VRN2_ConsensusJoin_v0103.py" and 'VERSION = "v0103"' in cj103''', '''    cj104 = selftest_source(CONSENSUS_JOIN).read_text(encoding="utf-8")
    assert CONSENSUS_JOIN == "VRN2_ConsensusJoin_v0104.py" and 'VERSION = "v0104"' in cj104 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0103.py"' in cj104
    assert "def provenance_refresh(" in cj104 and "def mark_provenance(" in cj104 and "VIA_VRN2_CONSENSUS_REFRESH" in cj104 and 'NET_MARK = "[VIA:NET-TOOL:"' in cj104
    eng122 = selftest_source("VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py").read_text(encoding="utf-8")
    assert "[VIA:NET-TOOL:v0122]" in eng122 and "SUP_MDL740_NetUnified_v" in eng122 and "def def_via_net(" in eng122 and "VIA_NET_DENY" in eng122 and "[VIA:ACCEL-BRIDGE:" in eng122
    assert "import yfinance" not in eng122.split("[VIA:NET-TOOL:v0122]", 1)[1].split("def def_fetch_yfinance_info", 1)[1].split("\\ndef ", 1)[0]   # YFinance → network tool lane
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            names156 = bundle.namelist()
        cjs = sorted(n for n in names156 if re.fullmatch(r"VRN2_ConsensusJoin_v\\d{4}\\.py", n))
        engs = sorted(n for n in names156 if re.fullmatch(r"VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v\\d{4}\\.py", n))
        assert cjs[-1] == "VRN2_ConsensusJoin_v0104.py" and "VRN2_ConsensusJoin_v0103.py" in cjs, cjs[-3:]
        assert engs[-1] == "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py" and "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py" in engs, engs
    print("[PASS] v0156: ConsensusJoin v0104 is the active consensus join · engine v0122 (highest in the runtime) goes out through the VIA network tool "
          "SUP_MDL740_NetUnified + accelerator bridge · gate closed → net_deny, never another transport · direct engine v0120 kept as PRIOR")
    cj103 = selftest_source("VRN2_ConsensusJoin_v0103.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0103"' in cj103''')
rep('''        assert cjs[-1] == "VRN2_ConsensusJoin_v0103.py" and "VRN2_ConsensusJoin_v0102.py" in cjs, cjs[-3:]
    print("[PASS] v0154: ConsensusJoin v0103 is the active consensus join''', '''        assert "VRN2_ConsensusJoin_v0103.py" in cjs and "VRN2_ConsensusJoin_v0102.py" in cjs, cjs[-3:]                 # v0156: v0104 is the newest
    print("[PASS] v0154: ConsensusJoin v0103 kept (PRIOR of v0104)''')
rep('''    print("[PASS] v0154: ConsensusJoin v0103 kept (PRIOR of v0104) (today's payloads resumed''', '''    print("[PASS] v0154: ConsensusJoin v0103 kept as PRIOR of v0104 (today's payloads resumed''')
(S / "v156/new/ActivateVRN-2_v0156.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0156 lines", s.count("\n"))
