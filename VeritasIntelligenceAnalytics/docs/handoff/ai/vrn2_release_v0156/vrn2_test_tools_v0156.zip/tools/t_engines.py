"""共識引擎新版實測(不連外網):Fusion v0122 · Matrix v0112。
VIA 樹:<tv>/VIA/supportive modules → 倉裡唯讀那份(網路工具 NetUnified 最高版號 · 鎖冊 AegisNexus · 加速器)· functional modules/VRN2 → 新引擎。
① 閘關(不設 VIA_NET_CONSENT / VIA_SCRAPE_CONSENT):即時模式開跑前就停 · PermissionError VIA_NET_DENY · 本機假伺服器 0 次請求。
② 閘開(只用函式替身擬開 · 本行程內 · 結束還原 · 不設環境變數):鉅亨頁 / API 經網路工具 http_bytes 車道打本機假伺服器;
   Yahoo 經網路工具 yahoo_quote_summary_raw 車道(替身回 quoteSummary 範例 · 車道自己的閘檢查照跑)→ 引擎閘 PASS · 輸出檔 · DuckDB。
③ 外網全擋:代理指到關著的埠 · 只放行 127.0.0.1。
用法:python t_engines.py <tv 根> <引擎檔…>"""
import http.server
import importlib.util
import json
import os
import sys
import tempfile
import threading
import traceback
from pathlib import Path

TV = Path(sys.argv[1])
ENGINES = [Path(p) for p in sys.argv[2:]]
DEAD = "http://127.0.0.1:9"
os.environ.update(HTTPS_PROXY=DEAD, https_proxy=DEAD, HTTP_PROXY=DEAD, http_proxy=DEAD, NO_PROXY="127.0.0.1,localhost", no_proxy="127.0.0.1,localhost")
for k in ("VIA_NET_CONSENT", "VIA_SCRAPE_CONSENT"):
    os.environ.pop(k, None)
HITS = []


def payloads(port, code):
    sym = "TWS:%s:STOCK" % code
    page = ('<html><head><script>__NEXT_DATA__ = {"props":{"pageProps":{"symbol":"%s"}}};</script>'
            '<script>__ENV__ = {"marketInfoApiUrl":"http://127.0.0.1:%d"};</script></head><body>%s</body></html>') % (sym, port, code)
    target = {"statusCode": 200, "message": "OK", "data": {"chName": "台積電", "last": 1000.0, "feLow": 1160.0, "feMean": 1479.0, "feMedian": 1450.0, "feHigh": 1740.0, "feStdDev": 5.0,
                                                            "feUp": 3, "feDown": 1, "numEst": 20, "rateDate": "2026-10-20", "currency": "TWD"}}
    rating = {"statusCode": 200, "message": "OK", "data": {"chName": "台積電", "rateDate": [1761000000, 1758000000], "feMark": [1.4, 1.5], "feBuy": [12, 11], "feOver": [5, 5], "feHold": [3, 4],
                                                            "feUnder": [0, 0], "feSell": [0, 0], "feMedian": [1450.0, 1400.0], "currency": "TWD"}}
    eps = {"statusCode": 200, "message": "OK", "data": [{"financialYear": y, "feMedian": v, "feLow": v * 0.9, "feMean": v * 1.01, "feHigh": v * 1.1, "feStdDev": 0.5, "feUp": 2, "feDown": 1,
                                                         "numEst": 18, "rateDate": "2026-10-20", "currency": "TWD"} for y, v in ((2026, 60.0), (2027, 75.0), (2028, 90.0))]}
    sales = {"statusCode": 200, "message": "OK", "data": [dict(r, feMedian=r["feMedian"] * 1e5) for r in eps["data"]]}
    return {"/twstock/%s/summary/overview" % code: ("text/html; charset=utf-8", page),
            "/mi/api/v1/financialIndicator/targetPrice/%s" % sym: ("application/json", json.dumps(target)),
            "/mi/api/v1/financialIndicator/factSetEstimate/%s" % sym: ("application/json", json.dumps(rating)),
            "/mi/api/v1/financialIndicator/estimateProfit/%s?type=eps" % sym: ("application/json", json.dumps(eps)),
            "/mi/api/v1/financialIndicator/estimateProfit/%s?type=sales" % sym: ("application/json", json.dumps(sales))}


class H(http.server.BaseHTTPRequestHandler):
    routes = {}

    def do_GET(self):  # noqa: N802
        HITS.append(self.path)
        got = self.routes.get(self.path)
        if not got:
            self.send_response(404)
            self.end_headers()
            return
        ctype, body = got
        data = body.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):
        pass


QS = {"price": {"symbol": "2330.TW", "shortName": "TSMC", "longName": "Taiwan Semiconductor Manufacturing", "currency": "TWD", "regularMarketPrice": {"raw": 1000.0, "fmt": "1,000.00"}},
      "summaryDetail": {"beta": {"raw": 1.1}},
      "financialData": {"currentPrice": {"raw": 1000.0}, "targetLowPrice": {"raw": 1200.0}, "targetMeanPrice": {"raw": 1480.0}, "targetMedianPrice": {"raw": 1500.0},
                        "targetHighPrice": {"raw": 1700.0}, "numberOfAnalystOpinions": {"raw": 30}, "recommendationMean": {"raw": 1.6}, "recommendationKey": "buy"},
      "recommendationTrend": {"trend": [{"period": "0m", "strongBuy": 10, "buy": 15, "hold": 3, "sell": 0, "strongSell": 0}]},
      "earningsTrend": {"trend": [{"period": "0y", "endDate": "2026-12-31", "earningsEstimate": {"avg": {"raw": 60.0}, "low": {"raw": 55.0}, "high": {"raw": 65.0}, "numberOfAnalysts": {"raw": 20}},
                                   "revenueEstimate": {"avg": {"raw": 3.5e12}}, "epsTrend": {"current": {"raw": 60.0}}, "epsRevisions": {"upLast7days": {"raw": 1}}, "growth": {"raw": 0.2}}]}}


def load(path, alias):
    spec = importlib.util.spec_from_file_location(alias, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[alias] = mod
    spec.loader.exec_module(mod)
    return mod


srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
port = srv.server_address[1]
H.routes = payloads(port, "2330")
threading.Thread(target=srv.serve_forever, daemon=True).start()
bad = []


def chk(label, cond, extra=""):
    print(("[PASS] " if cond else "[FAIL] ") + label + ((" · " + extra) if extra else ""), flush=True)
    if not cond:
        bad.append(label)


for i, eng_path in enumerate(ENGINES):
    name = eng_path.stem
    mod = load(eng_path, "eng_test_%d" % i)
    mod.CNYES_PAGE_TEMPLATE = "http://127.0.0.1:%d/twstock/{code}/summary/overview" % port
    if hasattr(mod, "DUCKDB_REQUIRED"):
        mod.DUCKDB_REQUIRED = False
    st = mod.def_via_net_status()
    chk("%s ⓪ 網路工具 = NetUnified 最高版號 · 閘關 · 加速器在" % name, str(st.get("net_tool", "")).startswith("SUP_MDL740_NetUnified_v") and not st.get("gate_open") and bool(st.get("accelerator")), json.dumps(st, ensure_ascii=False)[:220])
    out = Path(tempfile.mkdtemp(prefix="eng_closed_"))
    HITS.clear()
    kw = dict(codes=["2330"], output_dir=str(out), run_unit_tests=False, fixture_map={})
    if "resume" in mod.def_run_pipeline.__code__.co_varnames:
        kw.update(resume=False)
    try:
        mod.def_run_pipeline(**kw)
        closed = "沒擋"
    except PermissionError as exc:
        closed = str(exc)
    except Exception as exc:  # noqa: BLE001
        closed = "%s: %s" % (type(exc).__name__, exc)
    chk("%s ① 閘關:即時模式開跑前就停(VIA_NET_DENY)· 本機伺服器 0 次請求 · 不換道直連" % name, closed.startswith("VIA_NET_DENY") and not HITS, closed[:140])
    net = mod.def_via_net()
    real_bytes = net.http_bytes
    g = real_bytes.__globals__
    saved_deny, saved_gate, saved_yahoo = g["_deny_if_closed"], net.gate_state, net.yahoo_quote_summary_raw
    yahoo_deny = saved_yahoo.__globals__["_deny_if_closed"]
    y_calls = []

    def fake_yahoo(symbols, modules, pause_s=0.0):
        d = saved_yahoo.__globals__["_deny_if_closed"]()                     # 車道自己的閘照跑
        if d:
            return d
        y_calls.append((tuple(symbols), modules))
        return {"state": "OK", "results": {s: QS for s in symbols}, "failed": [], "note": "selftest"}
    try:
        g["_deny_if_closed"] = lambda: None
        saved_yahoo.__globals__["_deny_if_closed"] = lambda: None
        net.gate_state = lambda: {"open": True, "gate1_net_consent": True, "gate2_scrape_token_set": True, "gate1_raw": "SELFTEST-STUB", "scrape_value": "SELFTEST-STUB"}
        net.yahoo_quote_summary_raw = fake_yahoo
        out2 = Path(tempfile.mkdtemp(prefix="eng_open_"))
        HITS.clear()
        kw2 = dict(kw, output_dir=str(out2))
        res, err = None, None
        try:
            res = mod.def_run_pipeline(**kw2)
        except Exception as exc:  # noqa: BLE001
            err = "%s: %s" % (type(exc).__name__, exc)
            traceback.print_exc()
        payload = ((res or {}).get("payloads") or [{}])[0] if res else {}
        target = payload.get("target") or {}
        yfc = payload.get("yfinance") or {}
        manifest = json.loads((out2 / mod.OUTPUT_MANIFEST_JSON).read_text(encoding="utf-8")) if (out2 / mod.OUTPUT_MANIFEST_JSON).is_file() else {}
        gate = (manifest.get("gate") or {}).get("gate")
        chk("%s ② 閘開(替身):鉅亨頁 + 4 個 API 經網路工具 http_bytes 打本機 · Yahoo 經 yahoo_quote_summary_raw · 引擎閘 %s · FactSet 中位數 %s · YFinance 中位數 %s"
            % (name, gate, target.get("target_median"), yfc.get("target_median")),
            err is None and len(HITS) == 5 and len(y_calls) == 1 and target.get("target_median") == 1450.0 and yfc.get("target_median") == 1500.0 and gate in ("PASS", "PASS_WITH_WARNINGS"),
            (err or "") + " · 請求 %s" % sorted(set(h.split("?")[0].rsplit("/", 1)[-1] for h in HITS)))
        files = sorted(p.name for p in out2.iterdir())
        chk("%s ③ 輸出:矩陣 CSV · 品質 CSV · HTML · manifest%s" % (name, " · DuckDB" if any(f.endswith(".duckdb") for f in files) else ""),
            all((out2 / getattr(mod, k)).is_file() for k in ("OUTPUT_MATRIX_CSV", "OUTPUT_QUALITY_CSV", "OUTPUT_HTML", "OUTPUT_MANIFEST_JSON")), ", ".join(files)[:200])
        if "analysis" in yfc or "yfinance_analysis" in payload:
            an = payload.get("yfinance_analysis") or {}
            chk("%s ④ YFinance 分析表(quoteSummary → 同名方法):目標價 · EPS 預估 · 評等摘要" % name,
                bool(an.get("get_analyst_price_targets")) and bool(an.get("get_earnings_estimate")) and bool(an.get("get_recommendations_summary")), json.dumps({k: bool(v) for k, v in an.items()}, ensure_ascii=False))
    finally:
        g["_deny_if_closed"] = saved_deny
        saved_yahoo.__globals__["_deny_if_closed"] = yahoo_deny
        net.gate_state = saved_gate
        net.yahoo_quote_summary_raw = saved_yahoo
    HITS.clear()
    after = net.http_bytes("http://127.0.0.1:%d/twstock/2330/summary/overview" % port)
    chk("%s ⑤ 替身還原後:網路工具照樣 DENY(閘關)· 0 次請求" % name, after.get("state") == "DENY" and not HITS, str(after)[:120])
srv.shutdown()
print("[%s] 共識引擎新版實測 · 不過 %d" % ("PASS" if not bad else "FAIL", len(bad)), flush=True)
sys.exit(1 if bad else 0)
