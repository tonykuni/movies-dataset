"""v0156 整包重建(冪等):pkg156 → 套件 VRN2_Closeout_v0156.zip → VRN2_RoundAll_v0112.py(填套件雜湊)→ Handle-All v0104(一行 + 可讀版)
→ 開機行(ASCII)+ 開機檔 + 最短一行 + cmd 一行 → md · 引擎交付檔(Fusion v0122 · Matrix v0112)· 發行清單。vrn2_release_v0155 及更早的發行夾不動。"""
import base64, hashlib, json, re, shutil, sys, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v156"; out, rel, new = W / "pkg156", W / "release156", W / "new"
rel.mkdir(exist_ok=True)
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402

REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
r154 = json.loads((REPO / "vrn2_release_v0154/VRN2_Release_v0154.json").read_text(encoding="utf-8"))
r155 = json.loads((REPO / "vrn2_release_v0155/VRN2_Release_v0155.json").read_text(encoding="utf-8"))
rt = json.loads((out / "VRN2_Runtime_v0156.json").read_text(encoding="utf-8"))
assert rt["new_members"] == ["VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py", "VRN2_ConsensusJoin_v0104.py"] and rt["retained_members"] == 190
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0156.py", "VRN2_Runtime_v0156.zip", "VRN2_Runtime_v0156.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0156 — VRN-2 closeout package (2026-10-31 · consensus engine through the VIA network tool + accelerator)\n\n"
  "Entry: python ActivateVRN-2_v0156.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0112.py · PowerShell 7 'handle all': VRN2_HandleAll_v0104.md (same release folder; tiny paste line inside).\n"
  "Runtime: VRN2_Runtime_v0156.zip = runtime v0154 (190 members byte-identical) + VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122 + VRN2_ConsensusJoin_v0104,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0156 (operator 2026-10-31: route the consensus fetch through the latest versioned VIA network tool + accelerator):\n"
  " - Fusion engine v0122 = v0121 + every outbound request through supportive modules/network/SUP_MDL740_NetUnified (highest version · core = locked\n"
  "   AegisNexus v1652 · accelerator bridge = highest VeritasCeleritas): cnyes -> http_bytes lane, YFinance -> yahoo_quote_summary_raw lane (no yfinance\n"
  "   package). Double consent gate VIA_NET_CONSENT / VIA_SCRAPE_CONSENT is the operator's (never set by VRN-2); closed -> stop before fetching.\n"
  "   DENY is never retried through another transport. Network tool missing -> VIA_NET_TOOL_MISSING (no direct fallback).\n"
  " - ConsensusJoin v0104 (thin tail over v0103): fetch-Python probe checks requests (not yfinance) for the network-tool engine; receipt net_tool /\n"
  "   net_deny {note, gate_closed}; today's checkpoint fetched by the direct engine v0120 + gate open -> archived (engine's own function) and fetched\n"
  "   again through the network tool; VIA_VRN2_CONSENSUS_REFRESH=1 forces that; VIA_VRN2_NO_CONSENSUS_REFRESH=1 keeps today's checkpoint.\n"
  " - RoundAll v0112: step 5 consensus_refresh (gate open + consensus not yet through the network tool) · close-out net_deny -> human (gate closed) /\n"
  "   VCGC (compliance DENY) · debug rows for the network tool.\n"
  "Verification: see VRN2_Verification_v0156.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0156.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0156", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0156.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0156/" + n, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
# ===== RoundAll v0112 =====
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (new / "VRN2_RoundAll_v0112.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0156"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0156"' in ra
(rel / "VRN2_RoundAll_v0112.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ps7 = (S / "v151/ps7/line_ps7_tpl.txt").read_text(encoding="utf-8").strip("\n").replace("vrn2_release_v0151", "vrn2_release_v0156").replace("@F@", "VRN2_RoundAll_v0112.py").replace("@H@", ra_sha)
assert ("$H = '%s'" % ra_sha) in ps7
(rel / "oneline_roundall_ps7.txt").write_text(ps7 + "\n", encoding="utf-8")
# ===== Handle-All v0104 + 開機行 + 最短一行 =====
ha_src = (W / "ps7/handleall_src.ps1").read_text(encoding="utf-8").replace("@H@", ra_sha)
assert ha_src.count(ra_sha) == 1 and "vrn2_release_v0156" in ha_src and "VRN2_RoundAll_v0112.py" in ha_src and "exit" not in ha_src.replace("Exception", "")
assert "VIA_NET_CONSENT = " not in ha_src.replace("`$env:VIA_NET_CONSENT = 'YES'", "")            # 只印給操作員看 · 不代設
ha_line = join(ha_src); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha_src, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt_src = (W / "ps7/boot_src.ps1").read_text(encoding="utf-8").replace("@HA@", ha_sha)
bt_line = join(bt_src); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800 and ha_sha in bt_line
(rel / "boot_src.ps1").write_text(bt_src, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0104_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(bt_line.encode("utf-16-le")).decode("ascii"); assert len(cmd_line) < 8191
(rel / "boot_cmd.txt").write_text(cmd_line + "\n", encoding="utf-8")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0156/VRN2_HandleAll_v0104_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
# ===== 引擎交付檔 =====
eng = {}
for n in ("VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py", "VIA_FactSet_YFinance_Consensus_Matrix_Engine_v0112.py"):
    shutil.copy2(str(new / n), str(rel / n)); eng[n] = hashlib.sha256((rel / n).read_bytes()).hexdigest()
md = (W / "ha_md_tpl.md").read_text(encoding="utf-8")
for k, v in (("@TINY@", tiny), ("@TLEN@", str(len(tiny))), ("@BT12@", bt_sha[:12]), ("@HA12@", ha_sha[:12]), ("@RA12@", ra_sha[:12]), ("@WANT12@", want[:12]), ("@BOOT@", bt_line),
             ("@BTLEN@", "{:,}".format(len(bt_line))), ("@CMD@", cmd_line), ("@LINE@", ha_line), ("@SRC@", ha_src.rstrip("\n")), ("@BTSRC@", bt_src.rstrip("\n"))):
    md = md.replace(k, v)
assert not re.search(r"@[A-Z0-9]+@", md)
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == bt_line
(rel / "VRN2_HandleAll_v0104.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = (W / "ra_md_tpl.md").read_text(encoding="utf-8").replace("@RA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PS7@", ps7)
assert not re.search(r"@[A-Z0-9]+@", ra_md)
(rel / "VRN2_RoundAll_v0112.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0156 (ConsensusJoin v0104 · consensus engine v0122 through the VIA network tool + accelerator) + VRN2_RoundAll_v0112 + VRN2_HandleAll_v0104", "date": "2026-10-31",
        "trigger": "操作員 2026-10-31:「新版有版本號 · 加速器跟網路工具最新版都有版本號 · 直接透過 VCGC 的環境工具管理引擎下載所有不足工具及環境並確認無衝突 · 改成經網路工具和加速器出網再抓」(上傳 Fusion v0120 · Matrix v0111)",
        "base_package": {"name": "VRN2_Closeout_v0154 (launcher v0154 · runtime v0154)", "retained": "runtime v0154 members byte-identical inside runtime v0156; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0154 package for the closeout entry; VRN2_RoundAll v0111 → v0112; VRN2_HandleAll v0103 → v0104",
        "network": {"tool": "supportive modules/network/SUP_MDL740_NetUnified (highest version · v0119 in the repo)", "core": "VeritasAegisNexus_v1652 (lock book VIA_ToolVersion_Lock_v0100.json · network)",
                    "accelerator": "VeritasCeleritas (highest version · lock book v1141) loaded by the engine's accelerator bridge; the network tool's text lane uses VIA_SuperAccel",
                    "lanes": {"cnyes FactSet page": "http_bytes (stdlib · retries · 404 not retried)", "YFinance": "yahoo_quote_summary_raw (requests · cookie + crumb)"},
                    "gate": "VIA_NET_CONSENT == 'YES' and VIA_SCRAPE_CONSENT in {'YES', 'I_ACCEPT_RESPONSIBLE_SCRAPING'} (same as CGC_MDL224_ScrapeGate) · operator's decision · never set by VRN-2",
                    "compliance": "AegisNexus v1652 overlay: cnyes / Yahoo policy rows are signals (allowed); MOPS keeps the body's DENY; VIA_COMPLIANCE_ENFORCE=YES restores blocking"},
        "vcgc_env": {"EnvPlan": "CGC_MDL049_EnvPlan_v0103 --offline · pip conflicts 0 · dry-run skipped (offline / consent)", "InstallGate_check": "CGC_MDL056_InstallGate_v0101 --check-only · conflicts 0 · aux network / accelerator OK",
                     "InstallGate_install": "duckdb 2.0.0 into the container's sandbox venv via InstallGate (conflicts 0 before / after); desktop: anything missing goes through via-install (VCGC)",
                     "engine_needs": "network-tool engine: requests in the fetch Python (yfinance no longer needed by v0122); duckdb optional"},
        "fixes": {"Fusion_v0122": "v0121 + NET-TOOL block: def_http_get → net.http_bytes (DENY → PermissionError VIA_NET_DENY · failure → RuntimeError HTTP_GET_FAILED … via=VIA_NET); def_fetch_yfinance_info → net.yahoo_quote_summary_raw + flatten + analysis tables; pre-check prints 'def Net tool' and stops on VIA_NET_TOOL_MISSING / closed gate (live mode)",
                  "Matrix_v0112": "v0111 + accelerator bridge + the same network-tool routing (delivered as a file · not wired into VRN-2)",
                  "ConsensusJoin_v0104": "thin tail over v0103: requests probe · net_tool / net_deny in the receipt · provenance refresh (today's checkpoint from the direct engine + gate open → archive → refetch through the network tool; sidecar consensus/VRN2_Consensus_NetTool.json) · VIA_VRN2_CONSENSUS_REFRESH=1 forced refresh · selftest ① ~ ⑧",
                  "RoundAll_v0112": "step 5 consensus_refresh · close-out net_deny → 人工 (gate closed) / VCGC (compliance) · Combined 'VIA 網路工具 DENY' gaps split the same way · debug rows · MOPS rule no longer swallows 6f / Combined DENY rows · selftests 52 ~ 55",
                  "launcher_v0156": "receipt VRN2_Closeout_v0156.json · CONSENSUS_JOIN v0104 · ⑥f receipt keeps net_tool / net_deny / refresh / engine_no_output · selftest checks engine v0122 is the newest and goes through the network tool",
                  "HandleAll_v0104": "v0103 pointed at RoundAll v0112 (vrn2_release_v0156) + ③b prints the consent gate state read-only and how the operator opens it"},
        "not_fixed_here": r155["not_fixed_here"] | {"live_fetch_unverified_in_container": "the container cannot open the operator's consent gate and is not the desktop network: the network-tool lanes were verified against a local fake server with the gate stubbed open, and against the real network tool with the gate closed (DENY · zero requests)"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0156.json inside the package"},
        "engines": [{"name": n, "sha256": h} for n, h in eng.items()],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0111.py", "sha256": r155["roundall"]["sha256"], "status": "superseded 2026-10-31 (package v0154 · consensus engine direct); file kept in vrn2_release_v0155"}],
        "roundall": {"name": "VRN2_RoundAll_v0112.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0112.md"},
        "handleall": {"name": "VRN2_HandleAll_v0104.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0104_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · VIA network tool v0119 with the gate closed", "results": {"status": "see VRN2_Verification_v0156.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0156/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0156.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0156.py"]).hexdigest()},
        "test_tools_zip": "vrn2_test_tools_v0156.zip", "logs_zip": "logs_v0156.zip"}
(rel / "VRN2_Release_v0156.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
for k, v in (("zip_sha.txt", want), ("ra_sha.txt", ra_sha), ("ha_sha.txt", ha_sha), ("bt_sha.txt", bt_sha)):
    (rel / k).write_text(v)
print("built", sorted(p.name for p in rel.iterdir()))
