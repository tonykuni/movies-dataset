"""v0156 收尾:測試結果寫進發行清單 · 驗證紀錄 v0156 · 交接 v0157(只增 · 從 v0156 抄)· 把發行夾放進倉 vrn2_release_v0156 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); W = S / "v156"; rel = W / "release156"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
def lines(p): return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()
def short(x): return re.sub(r"/tmp/claude-0/[^ ·)(/]+/[0-9a-f-]{36}/scratchpad/(venv_vrn2|pwsh)", r"<scratch>/\1", re.sub(r"/tmp/claude-0/[^ ·)(]*?/(t156a|v156|v155|v154|lst|outside|tv)/", r"<\1>/", x))
def pick(n, extra=""):
    pat = r"boot|③b VIA|④ 自動選模式|⑤ 自動修計畫|===== 收尾|^  \[(VRN-2|VCGC|人工|資料源)\] \d|Handle-All 結束" + extra
    return [short(l)[:240] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)]
R = json.loads((rel / "VRN2_Release_v0156.json").read_text(encoding="utf-8"))
st_ra = [l for l in lines(W / "rall112_selftest.log") if re.search(r"^\[PASS\] 5[2-5] |--selftest · ", l)]
st_cj = [l for l in lines(W / "cj104_selftest.log") if re.search(r"^\[(PASS|FAIL|SKIP)\] [①-⑨] |v0104 --selftest", l)]
st_cjo = [l for l in lines(W / "cj104_selftest_outside.log") if re.search(r"^\[(FAIL|SKIP)\]|v0104 --selftest", l)]
st_l = [l[:200] for l in lines(W / "launcher156_selftest.log") if re.search(r"^\[PASS\] v015[46]|^\[FAIL\]", l)]
st_e = [l for l in lines(W / "t_engines.log") if re.search(r"^\[(PASS|FAIL)\]|PASS \d+|FAIL", l)][:14]
env = {n: [l[:200] for l in lines(W / n) if re.search(r"conflict|衝突|PASS|OK|FAIL|duckdb|SKIP", l, re.I)][:8] for n in ("envplan_offline.log", "installgate_check.log", "installgate_duckdb.log")}
rc = lines(W / "tiny156.rc")
R["fixes"]["ConsensusJoin_v0104"] = R["fixes"]["ConsensusJoin_v0104"].replace("selftest ① ~ ⑧", "net_engine when the network-tool engine never reached its network step (no net_tool · not counted as fetched through the tool) · selftest ① ~ ⑨")
R["not_fixed_here"]["container_venv_side_effect"] = ("sandbox full run: launcher step 3 (envcheck --install, existing VRN-2 manager behaviour) pip-installed into the container test venv; numpy went 2.x -> 1.26.4 and pyarrow no longer imports. "
    "VCGC InstallGate installs with --user only and pip refuses that inside a venv, so the container venv was left as is (test env only). Desktop: if step 3 changes numpy, hand it to VCGC; RoundAll --launcher-args \"--no-install\" skips step 3 installs")
R["results"] = {"roundall_selftest": st_ra, "consensusjoin_selftest_in_via": st_cj, "consensusjoin_selftest_outside_via": st_cjo, "launcher_selftest": st_l, "engines_test": st_e, "vcgc_env": env,
                "pwsh_parse": "pwsh 7.4.6 剖析 0 錯 · Handle-All 一行 = 可讀版 · 開機行 = 可讀版(詞序列相同)· 最短一行 0 錯",
                "e2e_rc": rc, "e2e": {n: pick(n, r"|⑥f|def Net tool" if n == "full" else "") for n in ("report", "auto", "full", "tamper")}}
(rel / "VRN2_Release_v0156.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
E = R["results"]["e2e"]
md = """# VRN-2 v0156 驗證紀錄(2026-10-31 · 共識引擎經 VIA 網路工具 + 加速器出網 · 套件 v0156 · RoundAll v0112 · Handle-All v0104)

## 1. 要求

操作員 2026-10-31:「新版有版本號 · 加速器跟網路工具最新版都有版本號 · 直接透過 VCGC 的環境工具管理引擎下載所有不足工具及環境並確認無衝突 · 改成經網路工具和加速器出網再抓」
(上傳 `VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py` · `VIA_FactSet_YFinance_Consensus_Matrix_Engine_v0111.py`)。

## 2. 做了什麼

| 檔 | 版本 | SHA-256 | 說明 |
|---|---|---|---|
| 共識引擎 Fusion | v0122 | `%s` | v0121(v0120 + 加速器橋)+ 出網一律經 `SUP_MDL740_NetUnified` 最高版號(倉裡 v0119 · 核心鎖冊 AegisNexus v1652):鉅亨 → `http_bytes` · YFinance → `yahoo_quote_summary_raw`;閘關 / DENY = 停,不換道直連;網路工具不在 = `VIA_NET_TOOL_MISSING` |
| 共識引擎 Matrix | v0112 | `%s` | v0111 + 加速器橋 + 同一套出網改法(交付檔 · 不接進 VRN-2) |
| ConsensusJoin | v0104 | runtime v0156 | v0103 薄尾:requests 探測 · 收據 net_tool / net_deny · 今天的 checkpoint 是直連抓的 + 閘開 → 封存重抓 |
| 啟動器 | v0156 | `%s` | 收據 v0156 · ⑥f 用 v0104 |
| RoundAll | v0112 | `%s` | ⑤ consensus_refresh · 收尾頁 net_deny 負責方 · 除錯列 |
| Handle-All | v0104 | 一行 `%s` | ③b 只讀印同意閘 · 指向 RoundAll v0112 |
| 套件 | VRN2_Closeout_v0156.zip | `%s` | runtime v0156 = v0154 的 190 個成員不動 + 引擎 v0122 + ConsensusJoin v0104 |

## 3. VCGC 環境工具(裝缺的 · 查衝突)

```text
%s
```

## 4. 自測

```text
%s
%s
%s
%s
%s
%s
```

## 5. 引擎經網路工具(本機假伺服器 · 閘用替身擬開 · 真網路工具閘關)

```text
%s
```

## 6. 最短一行 e2e(沙盒 = 桌機 v0153 狀態 · 倉的網路工具 · 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設)

```text
%s
```

## 7. 桌機預期

貼 `VRN2_HandleAll_v0104.md` 最上面那行 → ③b 印同意閘 → auto → repair:
閘開 → ⑥f 經 VIA 網路工具重抓 → **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2**(除錯報告多一列綠的「⑥f 經 VIA 網路工具」);
閘關 → 不重抓 → **BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2**(多「同意閘未開 · 操作員決定」)。
容器做不到:打開操作員的同意閘、連到鉅亨 / Yahoo —— 真的抓要在桌機。
""" % (R["engines"][0]["sha256"][:12], R["engines"][1]["sha256"][:12], R["launcher"]["sha256"][:12], R["roundall"]["sha256"][:12], R["handleall"]["line_sha256"][:12], R["package"]["sha256"][:12],
       "\n".join("[%s] %s" % (k, x) for k, v in env.items() for x in v),
       "\n".join(st_ra), "\n".join(st_cj), "[VIA 樹外] " + " · ".join(st_cjo), "\n".join(st_l), R["results"]["pwsh_parse"], "e2e 結束碼:" + " · ".join(rc),
       "\n".join(st_e), "\n".join("[%s] " % n + l for n in ("report", "auto", "full", "tamper") for l in E[n]))
(rel / "VRN2_Verification_v0156.md").write_text(md, encoding="utf-8", newline="\n")
# ===== 交接 v0157(從 v0156 抄 · 只增)=====
src = (REPO / "VRN2_Handover_v0156.md").read_text(encoding="utf-8")
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80]); src = src.replace(a, b)
L = src.split("\n"); assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0154 + VRN2_RoundAll_v0111 + VRN2_HandleAll_v0103 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0156 + VRN2_RoundAll_v0112 + VRN2_HandleAll_v0104 · 2026-10-31(共識引擎 v0122 經 VIA 網路工具 SUP_MDL740_NetUnified + 加速器出網;"
        "ConsensusJoin v0104:同意閘關 = net_deny 不換道 · 今天直連抓的 checkpoint + 閘開 = 封存經網路工具重抓;RoundAll v0112:⑤ consensus_refresh · DENY 負責方;Handle-All v0104 ③b 只讀印閘;VCGC 環境工具衝突 0)")
src = "\n".join(L)
H = R["handleall"]
once("> **本輪(v0155 · 小輪)**",
     "> **本輪(v0156)**:操作員「新版有版本號 · 加速器跟網路工具最新版都有版本號 · 直接透過 VCGC 的環境工具管理引擎下載所有不足工具及環境並確認無衝突 · 改成經網路工具和加速器出網再抓」→ "
     "**Fusion v0122**(v0121 + 出網經 `SUP_MDL740_NetUnified` 最高版號 · 鉅亨 http_bytes · YFinance yahoo_quote_summary_raw · 不用 yfinance 套件 · 要 requests)· **Matrix v0112**(交付檔)· "
     "**ConsensusJoin v0104** · **啟動器 v0156** · **RoundAll v0112** · **Handle-All v0104**(最短一行 %d 字元 · 開機檔 `vrn2_release_v0156/VRN2_HandleAll_v0104_boot.txt`)。"
     "VCGC:EnvPlan --offline 衝突 0 · InstallGate --check-only 衝突 0 · InstallGate duckdb(沙盒 venv)前後衝突 0。同意閘是操作員的(VRN-2 / AI 永不代設):閘關 → repair 不重抓 · 整輪 ⑥f DENY → 人工。"
     "容器沒辦法開操作員的閘、也不是桌機網路 → 真抓沒在容器驗(假伺服器 + 閘替身驗車道 · 真網路工具閘關 = DENY 0 請求)。\n"
     "> **本輪(v0155 · 小輪)**" % H["tiny_line_chars"])
once("| **VRN2_HandleAll_v0103.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0103** |",
     "| **VRN2_HandleAll_v0104.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0104** | `vrn2_release_v0156` | 一行版 `%s` · 開機檔 `%s` | **新**(RoundAll v0112 · ③b 只讀印同意閘 · 最短一行 %d 字元)|\n"
     "| **VRN2_RoundAll_v0112.py**(發行夾 · 一支入口 · 不在套件內)| **v0112** | `vrn2_release_v0156` | `%s` | **新**(套件 v0156 · ⑤ consensus_refresh · net_deny → 人工 / VCGC · 自測 55 項)|\n"
     "| ActivateVRN-2_v0156.py(套件 · 底座 v0136)| **v0156** | 見發行清單 | `%s` | **新**(收據 v0156 · CONSENSUS_JOIN v0104 · 自測多一段 v0156)|\n"
     "| **VRN2_ConsensusJoin** | **v0104**(薄尾 · v0103 ~ v0100 留著)| runtime v0156 | 見 runtime 清單 | **新**(引擎經網路工具 · requests 探測 · net_tool / net_deny · 直連抓的 checkpoint + 閘開 → 封存重抓 · 自測 ① ~ ⑨)|\n"
     "| **VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine** | **v0122**(v0121 + 網路工具)| runtime v0156 · 發行夾 | `%s` | **新**(出網經 SUP_MDL740_NetUnified 最高版號 + 加速器橋 · 閘關 / DENY = 停 · v0120 留作直連前版)|\n"
     "| **VIA_FactSet_YFinance_Consensus_Matrix_Engine** | **v0112**(v0111 + 加速器橋 + 網路工具)| 發行夾(不接進 VRN-2)| `%s` | **新**(交付檔)|\n"
     "| **VRN2_HandleAll_v0103.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0103** |"
     % (H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], R["engines"][0]["sha256"][:12], R["engines"][1]["sha256"][:12]))
once("| **VRN2_RoundAll_v0111.py**(發行夾 · 一支入口 · 不在套件內)| **v0111** | `vrn2_release_v0155` | `1d094c0d5c36` | **新**(",
     "| **VRN2_RoundAll_v0111.py**(發行夾 · 一支入口 · 不在套件內)| **v0111** | `vrn2_release_v0155` | `1d094c0d5c36` | 被 v0112 取代(套件 v0154 · 共識直連)· (")
once("| 0 | **(v0155 · 2026-10-31 02:06 後)**",
     "| 0 | **(v0156)** 桌機 PowerShell 7 貼 `vrn2_release_v0156/VRN2_HandleAll_v0104.md` **最上面那行(%d 字元)**→ 看 ③b 同意閘:要經網路工具抓 → 操作員自己先設 `$env:VIA_NET_CONSENT='YES'; $env:VIA_SCRAPE_CONSENT='YES'` → auto → repair → "
     "閘開預期 BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2(除錯報告「⑥f 經 VIA 網路工具」綠)· 閘關預期人工 3;⑥f 黃 / VRN-2 有項 → 貼回包 | 貼回 |\n"
     "| 0 | **(v0155 · 2026-10-31 02:06 後)**" % H["tiny_line_chars"])
once("**v0155(2026-10-31)**:", "**v0156(2026-10-31)**:共識引擎 v0122 / Matrix v0112 經 VIA 網路工具 + 加速器出網 · ConsensusJoin v0104 · 啟動器 v0156 · RoundAll v0112 · Handle-All v0104 · VCGC 環境工具衝突 0;真抓待桌機。\n\n**v0155(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0156)** **出網一律經 VIA 網路工具(SUP_MDL740_NetUnified 最高版號)**:DENY = 停,不換道直連、不重試;同意閘 `VIA_NET_CONSENT` / `VIA_SCRAPE_CONSENT` 是操作員的決定,VRN-2 / AI **永不代設**,只讀、只告訴操作員怎麼開。\n"
     "- **(v0156)** **換了出網方式要看 checkpoint 是誰抓的**:引擎版號字串 v0120 / v0122 都是 2.0.0、input_hash 一樣 → 直接續跑就沿用了直連抓的 payload(等於沒「再抓」);ConsensusJoin v0104 用 `consensus\\VRN2_Consensus_NetTool.json` 記哪份 checkpoint 是經網路工具抓的。\n"
     "- **(v0156)** **裝套件只經 VCGC 的環境工具**(EnvPlan 計畫 / InstallGate 裝 · 前後 pip check 衝突 0);VRN-2 只檢查、不 pip。\n\n")
(REPO / "VRN2_Handover_v0157.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0156"; D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0156.zip", "VRN2_Release_v0156.json", "VRN2_RoundAll_v0112.py", "VRN2_RoundAll_v0112.md", "VRN2_HandleAll_v0104.md", "VRN2_HandleAll_v0104_boot.txt", "VRN2_Verification_v0156.md",
          "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122.py", "VIA_FactSet_YFinance_Consensus_Matrix_Engine_v0112.py"):
    shutil.copy(rel / n, D / n)
SCR = re.compile(rb"/tmp/claude-0/[^ \"'\n)(]*?/(t156a|v156|v155|v154|v153|lst|outside|tv)/")
SCR2 = re.compile(rb"/tmp/claude-0/[^ \"'\n)(/]+/[0-9a-f-]{36}/scratchpad/")
def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; z.writestr(zi, data)
with zipfile.ZipFile(D / "logs_v0156.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall112_selftest.log", "cj104_selftest.log", "cj104_selftest_outside.log", "launcher156_selftest.log", "t_engines.log", "envplan_offline.log", "installgate_check.log", "installgate_duckdb.log", "installgate_numpy.log", "pscheck156.log", "tiny156.rc")] + sorted(W.glob("tiny_*.log")):
        put(z, p.name, SCR2.sub(rb"<scratch>/", SCR.sub(rb"<\1>/", p.read_bytes())))
with zipfile.ZipFile(D / "vrn2_test_tools_v0156.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_engines.py", "t_engines.py", "mk_roundall112.py", "mk_launcher156.py", "runtime156.py", "build156.py", "finalize156.py", "e2e156.sh", "ha_md_tpl.md", "ra_md_tpl.md",
                              "ps7/handleall_src.ps1", "ps7/boot_src.ps1", "ps7/join_ps.py")] + [S / "v155/ps7/parse155.ps1", rel / "tiny_line.txt", rel / "boot_line.txt", rel / "boot_cmd.txt"]:
        put(z, "tools/" + p.name, SCR2.sub(rb"<scratch>/", SCR.sub(rb"<\1>/", p.read_bytes())))
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0157", src.count("\n"))
