# VRN-2 · PowerShell 7 一行處理全部 · VRN2_HandleAll_v0104(2026-10-31 · 套件 v0156 · RoundAll v0112)

v0104 = v0103 + 套件 **v0156**:共識引擎改成**經 VIA 網路工具 + 加速器出網**(操作員 2026-10-31:「新版有版本號 · 加速器跟網路工具最新版都有版本號 ·
直接透過 VCGC 的環境工具管理引擎下載所有不足工具及環境並確認無衝突 · 改成經網路工具和加速器出網再抓」)。

| 項目 | 版本 |
|---|---|
| 共識引擎 | `VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122`(v0121 + 出網經網路工具)· 前版 v0120(直連)留在 runtime 當前版 |
| 網路工具 | `supportive modules\network\SUP_MDL740_NetUnified` 最高版號(倉裡 v0119)· 核心 = 鎖冊 `VeritasAegisNexus_v1652` |
| 加速器 | 引擎的加速器橋載入最高版號 `VeritasCeleritas`(鎖冊 v1141)· 網路工具文字車道用 `VIA_SuperAccel` |
| 鉅亨 FactSet 頁 | 網路工具 `http_bytes` 車道(重試 · 404 不重試) |
| YFinance | 網路工具 `yahoo_quote_summary_raw` 車道(不再用 yfinance 套件 · 要 `requests`) |
| ⑥f 合併 | `VRN2_ConsensusJoin_v0104`(v0103 薄尾) |
| 一支 Python | `VRN2_RoundAll_v0112.py`(SHA-256 `@RA12@`)· 套件 `VRN2_Closeout_v0156.zip`(SHA-256 `@WANT12@`) |

## PowerShell 7 貼這一行(@TLEN@ 字元 · 4 行內 · 不會讓輸入列當掉)

```powershell
@TINY@
```

`git fetch` 分支 → `git show` 取 `VRN2_HandleAll_v0104_boot.txt`(開機行 · ASCII)→ 核對 SHA-256 `@BT12@` 才執行 →
開機行取本檔、核對 Handle-All 那一行的 SHA-256 `@HA12@` 才執行 → auto(上一輪收據 v0153 以後 + 輸出冊在 → repair)。
第一行應是 `[GREEN] boot: Handle-All v0104 SHA-256 OK`。

## 同意閘(操作員決定 · VRN-2 只讀 · 不代設)

網路工具有兩道同意閘:`VIA_NET_CONSENT = YES` **而且** `VIA_SCRAPE_CONSENT = YES`(或 `I_ACCEPT_RESPONSIBLE_SCRAPING`),跟 VCGC 的 `CGC_MDL224_ScrapeGate` 同一套判斷。
Handle-All 的 **③b** 只讀印出現在的狀態:

- **開**(綠):repair 的 ⑤ 會把 ⑥f 改經網路工具重抓(套件的 ConsensusJoin v0104 + 引擎 v0122 只增不覆寫地補放 → 今天的 checkpoint 封存 → 全部經網路工具抓)→ 重組 Combined。
- **未開**(黃):repair **不重抓**(現有共識不動),除錯報告 / 收尾頁列一項「⑥f 共識還沒經 VIA 網路工具 · 同意閘未開」= **人工**;整輪(full)的 ⑥f 會被網路工具 DENY(不換道直連)。
  要抓:**你**在同一個視窗先貼下面這行,再貼最上面那一行(AI / VRN-2 不會替你設):

```powershell
$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'
```

用完可 `Remove-Item Env:VIA_NET_CONSENT, Env:VIA_SCRAPE_CONSENT`。合規判定:鉅亨 / Yahoo 在網路工具的合規表裡是「訊號」(放行 · 記錄);MOPS 照舊 DENY(VCGC 的決定)。

## VCGC 環境工具(裝缺的 · 查衝突)

容器裡用 VCGC 的環境工具跑過:`CGC_MDL049_EnvPlan_v0103 --offline`(pip 衝突 0)· `CGC_MDL056_InstallGate_v0101 --check-only`(衝突 0 · 網路工具 / 加速器輔助模組 OK)·
`InstallGate duckdb`(裝進沙盒 venv · 前後衝突 0)。新引擎在擷取 Python 要的是 **`requests`**(Yahoo 車道);桌機缺什麼,⑥f 會黃、收尾頁列 **VCGC**,用 VCGC 的 `via-install <套件>` 裝(VRN-2 不 pip)。

## 這次桌機貼下去會怎樣

上一輪收據 `VRN2_Closeout_v0154.json`、輸出冊在 → auto 選 **repair**:

- 閘**開**:⑤ 排「⑥f 改經 VIA 網路工具重抓」→ 印 `def Net tool : SUP_MDL740_NetUnified_v0119 …` → 抓 43 檔 → 404 的照舊不納入閘 → 重組 Combined → 收尾頁。
  預期跟 v0103 那輪一樣 **BLOCKED · VRN-2 0 · VCGC 1(MOPS DENY)· 人工 2 · 資料源 2**,除錯報告多一列綠的「⑥f 經 VIA 網路工具」。
- 閘**未開**:不重抓 → 預期 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 3(多「同意閘未開」那項)· 資料源 2**。
- 擷取 Python 缺 `requests` → ⑥f 黃 · VCGC 多一項(用 via-install 裝)。

容器做不到的:打開你的同意閘、連到鉅亨 / Yahoo —— 真的抓要在桌機跑(容器裡用本機假伺服器 + 閘替身驗過網路工具車道,真網路工具閘關 = DENY · 0 個請求)。

## 開機行(同一段 · 已經在 PowerShell 7 也可直接貼 · @BTLEN@ 字元)

```powershell
@BOOT@
```

## cmd 視窗(內容 = 開機行 · 不經 PowerShell 輸入列)

```bat
@CMD@
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
@LINE@
```

## 可讀版 · Handle-All

```powershell
@SRC@
```

## 可讀版 · 開機行

```powershell
@BTSRC@
```
