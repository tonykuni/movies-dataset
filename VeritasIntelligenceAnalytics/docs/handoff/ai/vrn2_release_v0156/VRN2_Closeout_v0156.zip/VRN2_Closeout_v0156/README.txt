VRN2_Closeout_v0156 — VRN-2 closeout package (2026-10-31 · consensus engine through the VIA network tool + accelerator)

Entry: python ActivateVRN-2_v0156.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0112.py · PowerShell 7 'handle all': VRN2_HandleAll_v0104.md (same release folder; tiny paste line inside).
Runtime: VRN2_Runtime_v0156.zip = runtime v0154 (190 members byte-identical) + VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0122 + VRN2_ConsensusJoin_v0104,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0156 (operator 2026-10-31: route the consensus fetch through the latest versioned VIA network tool + accelerator):
 - Fusion engine v0122 = v0121 + every outbound request through supportive modules/network/SUP_MDL740_NetUnified (highest version · core = locked
   AegisNexus v1652 · accelerator bridge = highest VeritasCeleritas): cnyes -> http_bytes lane, YFinance -> yahoo_quote_summary_raw lane (no yfinance
   package). Double consent gate VIA_NET_CONSENT / VIA_SCRAPE_CONSENT is the operator's (never set by VRN-2); closed -> stop before fetching.
   DENY is never retried through another transport. Network tool missing -> VIA_NET_TOOL_MISSING (no direct fallback).
 - ConsensusJoin v0104 (thin tail over v0103): fetch-Python probe checks requests (not yfinance) for the network-tool engine; receipt net_tool /
   net_deny {note, gate_closed}; today's checkpoint fetched by the direct engine v0120 + gate open -> archived (engine's own function) and fetched
   again through the network tool; VIA_VRN2_CONSENSUS_REFRESH=1 forces that; VIA_VRN2_NO_CONSENSUS_REFRESH=1 keeps today's checkpoint.
 - RoundAll v0112: step 5 consensus_refresh (gate open + consensus not yet through the network tool) · close-out net_deny -> human (gate closed) /
   VCGC (compliance DENY) · debug rows for the network tool.
Verification: see VRN2_Verification_v0156.md. Hashes: PACKAGE_SHA256.json.
