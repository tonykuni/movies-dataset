#!/bin/bash
# 在測試樹用 pwsh -EncodedCommand 跑「cmd / PowerShell 都能貼的一行」:$1 = 樹
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
T="$1"; B64=$(cut -d' ' -f6 $S/boot127/oneline129.txt)
cd "$T/Downloads" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="/nonexistent/VIA" VIA_VRN_INPUT="$T/samples" VIA_ENVS_HOME="$T/envs" \
  VIA_VRN2_OCR_PY="$(command -v python3)" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 \
  VRN2_ROOT="$T/VIA" VRN2_LAUNCHER="$T/Downloads/ActivateVRN-2.py" VRN2_PY="$S/venv_vrn2/bin/python" VRN2_LAUNCHER_ARGS="--no-install" \
  timeout 3500 "$S/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -EncodedCommand "$B64"
