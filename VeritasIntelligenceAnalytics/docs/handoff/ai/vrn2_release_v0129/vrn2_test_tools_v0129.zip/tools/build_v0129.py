"""ActivateVRN-2 v0121 → v0129 組裝(AST 定位整段替換 · 不改 v0121 原檔)。

用法:python build_v0127.py <v0121 啟動器> <new 夾> <emb 夾> <輸出 v0122 啟動器>
  new 夾:VRN_SystemManager_v0232.py · VRN_ENG397_P1Segment_v0127.py · VRN2_UIAction_v0102.py · VRN2_Handover_v0122.md · launcher_v0122_funcs.py
  emb 夾:v0121 內嵌原件(VRN_SystemManager_v0231.py)
"""
import ast
import base64
import hashlib
import sys
from pathlib import Path

src_p, new_d, emb_d, out_p = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
src = src_p.read_text(encoding="utf-8")
lines = src.splitlines(keepends=True)
tree = ast.parse(src)


def b64(raw: bytes) -> str:
    s = base64.b64encode(raw).decode("ascii")
    return "\n".join(s[i:i + 120] for i in range(0, len(s), 120))


def blob(name: str, raw: bytes) -> tuple:
    return name, hashlib.sha256(raw).hexdigest(), b64(raw)


mgr239 = blob("VRN_SystemManager_v0239.py", (new_d / "VRN_SystemManager_v0239.py").read_bytes())
mgr238 = blob("VRN_SystemManager_v0238.py", (new_d / "VRN_SystemManager_v0238.py").read_bytes())
mgr237 = blob("VRN_SystemManager_v0237.py", (new_d / "VRN_SystemManager_v0237.py").read_bytes())
mgr236 = blob("VRN_SystemManager_v0236.py", (new_d / "VRN_SystemManager_v0236.py").read_bytes())
iv102 = blob("VRN2_IndependentVerifier_v0102.py", (new_d / "VRN2_IndependentVerifier_v0102.py").read_bytes())
mgr235 = blob("VRN_SystemManager_v0235.py", (new_d / "VRN_SystemManager_v0235.py").read_bytes())
mgr234 = blob("VRN_SystemManager_v0234.py", (new_d / "VRN_SystemManager_v0234.py").read_bytes())
mgr233 = blob("VRN_SystemManager_v0233.py", (new_d / "VRN_SystemManager_v0233.py").read_bytes())
mgr232 = blob("VRN_SystemManager_v0232.py", (new_d / "VRN_SystemManager_v0232.py").read_bytes())
eng062 = blob("VRN_ENG062_SummarizerV1_v0114.py", (new_d / "VRN_ENG062_SummarizerV1_v0114.py").read_bytes())
mgr231 = blob("VRN_SystemManager_v0231.py", (emb_d / "VRN_SystemManager_v0231.py").read_bytes())
eng127 = blob("VRN_ENG397_P1Segment_v0127.py", (new_d / "VRN_ENG397_P1Segment_v0127.py").read_bytes())
ui102 = blob("VRN2_UIAction_v0102.py", (new_d / "VRN2_UIAction_v0102.py").read_bytes())
hand = blob("VRN2_Handover_v0129.md", (new_d / "VRN2_Handover_v0129.md").read_bytes())
funcs_src = (new_d / "launcher_v0129_funcs.py").read_text(encoding="utf-8")
ftree = ast.parse(funcs_src)
flines = funcs_src.splitlines(keepends=True)


def seg(node, ls=None):
    ls = ls or lines
    start = node.lineno - 1
    if getattr(node, "decorator_list", None):
        start = min(d.lineno for d in node.decorator_list) - 1
    return start, node.end_lineno


fnodes = {}
order = []
pending = []
for n in ftree.body:
    s, e = seg(n, flines)
    text = "".join(flines[s:e])
    if isinstance(n, ast.FunctionDef):
        fnodes[n.name] = (pending + [text])
        order.append(n.name)
        pending = []
    else:
        pending.append(text)
assert not pending, "funcs 檔結尾不能有懸空敘述"

REPLACE = {"run", "optimize", "restore", "git_ship", "consolidate", "register_ui_protocol", "land_manager", "land_extras", "selftest", "main", "locate"}
edits = []                                                               # (start, end, new_text)
names_seen = set()
for n in tree.body:
    s, e = seg(n)
    if isinstance(n, ast.FunctionDef) and n.name in REPLACE:
        names_seen.add(n.name)
        edits.append((s, e, "\n\n".join(t.rstrip("\n") for t in fnodes[n.name]) + "\n"))
    elif isinstance(n, ast.FunctionDef) and n.name == "ocr_env":
        t = "".join(lines[s:e])
        a1 = 'def ocr_env() -> tuple:'
        a2 = '    os.environ["VIA_VRN2_OCR_PY"], os.environ["VIA_VRN2_OCR_BRIDGE"] = str(py), str(br)'
        a3 = '        return py.exists() and run([str(py), "-c", chk], 180)[0] == 0'
        assert t.count(a1) == 1 and t.count(a2) == 1 and t.count(a3) == 1, "ocr_env 錨點"
        t = t.replace(a1, 'def ocr_env(env=None) -> tuple:')
        t = t.replace(a2, '    (os.environ if env is None else env).update({"VIA_VRN2_OCR_PY": str(py), "VIA_VRN2_OCR_BRIDGE": str(br)})   # v0122 平行段:由主執行緒寫回 os.environ')
        t = t.replace(a3, '        return py.exists() and run([str(py), "-c", _pyc(chk)], 180)[0] == 0                       # v0122 -c 也接加速器')
        edits.append((s, e, t))
    elif isinstance(n, ast.Assign):
        tg = ast.unparse(n.targets[0]) if n.targets else ""
        if tg == "VERSION":
            edits.append((s, e, 'VERSION = "ActivateVRN-2 v0129"\n'))
        elif tg == "(MGR_NAME, MGR_SHA)":
            edits.append((s, e, 'MGR_NAME, MGR_SHA = "%s", "%s"\n' % mgr239[:2]))
        elif tg == "MGR_B64":
            ch = (mgr231, mgr232, mgr233, mgr234, mgr235, mgr236, mgr237, mgr238)
            edits.append((s, e, 'MGR_B64 = """\n%s\n"""\nMGR_CHAIN = [%s]   # v0129 薄尾鏈:v0231 → v0232 → v0233 → v0234 → v0235 → v0236 → v0237 → v0238 → 尾版 v0239(依序落地 · 每支自測過才落下一支)\n' % (
                mgr239[2], ", ".join('("%s", "%s", """\n%s\n""")' % c for c in ch))))
        elif tg == "ENGINES":
            edits.append((s, e, 'ENGINES = [("%s", "%s", """\n%s\n""")]   # v0122 只內嵌現役版(v0127 = 總頁數不靠 PyMuPDF)\n' % eng127))
        elif tg == "(HANDOVER_NAME, HANDOVER_SHA)":
            edits.append((s, e, 'HANDOVER_NAME, HANDOVER_SHA = "%s", "%s"\n' % hand[:2]))
        elif tg == "HANDOVER_B64":
            edits.append((s, e, 'HANDOVER_B64 = """\n%s\n"""\n' % hand[2]))
    elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and "VRN_ENG062_SummarizerV1_v0112.py" in "".join(lines[s:s + 1]):
        edits.append((s, e, 'EXTRAS.append(("%s", "%s", """\n%s\n"""))   # v0124 摘要器 v0114(八碼日期不當目標價 · v0113 只有評等的大字行不當標題)\nEXTRAS.append(("%s", "%s", """\n%s\n"""))   # v0129 獨立驗證器 v0102(不 import VRN-2 程式 · ⑪ 背景跑 · 判決寫回 U/I · v0101 表頭列 HDRVAL · v0102 段落標題 SECFAIL)\n' % (eng062 + iv102)))
    elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and "VRN2_UIAction_v0100.py" in "".join(lines[s:s + 1]):
        edits.append((s, e, 'EXTRAS.append(("%s", "%s", """\n%s\n"""))   # v0122 vrn2:// 處理器(帶加速器橋 · VRN2_FROM_UI)\nUI_HANDLER_NAME = "%s"\n' % (ui102 + (ui102[0],))))
    elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Constant) and isinstance(n.value.value, str) and n.lineno == 1:
        doc = (new_d / "launcher_v0129_doc.txt").read_text(encoding="utf-8")
        edits.append((s, e, doc))
missing = REPLACE - names_seen
assert not missing, "找不到要換的函式 %s" % missing
main_node = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
new_helpers = [nm for nm in order if nm not in REPLACE]
ins = "\n\n".join("\n\n".join(t.rstrip("\n") for t in fnodes[nm]) for nm in new_helpers) + "\n\n\n"
edits.append((main_node.lineno - 1, main_node.lineno - 1, ins))
kinds = sorted({(s, e) for s, e, _ in edits})
assert len(kinds) == len(edits), "重疊的替換"
out = lines[:]
for s, e, t in sorted(edits, key=lambda x: (-x[0], -x[1])):
    out[s:e] = [t]
res = "".join(out)
compile(res, out_p.name, "exec")
out_p.write_text(res, encoding="utf-8", newline="")
print("[計] %s · %d 位元組 · sha %s · 替換 %d 段 · 新函式 %s" % (out_p.name, len(res.encode()), hashlib.sha256(res.encode()).hexdigest()[:12], len(edits), "、".join(new_helpers)))
for b in (mgr239, mgr238, mgr237, mgr236, mgr235, mgr234, mgr233, mgr232, mgr231, eng127, eng062, iv102, ui102, hand):
    print("   %-34s %s" % (b[0], b[1][:12]))
