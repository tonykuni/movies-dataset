"""SECTION 欄位稽核(只讀):每筆有 SECTION 的年度數據 → 原文裡科目那一列(驗證器同一套定列)上方找段落標題字 → 比較標題與科目的 x(同一欄才對 · 並排表別一欄 = 錯)。
用法:python sec_audit.py <output 夾> <PDF 夾>"""
import collections, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs as V  # noqa: E402

od, pd = Path(sys.argv[1]), Path(sys.argv[2])
fin = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
res = collections.Counter(); ex = collections.defaultdict(list); seen = {}
for x in fin:
    sec = V.nfk(str(x.get("SECTION") or "")).strip()
    if not sec or x.get("SUBCOL") or "轉置" in str(x.get("VERIFY", "")):
        continue
    k_ = (x["FILENAME"], x["PAGE"], x.get("TABLE"), x.get("ROW"), x["ITEM"], sec)
    if k_ in seen:
        res[seen[k_]] += 1
        continue
    lines = V.page_lines(pd / x["FILENAME"], int(x["PAGE"]))
    si = V.squash(V.nfk(x["ITEM"]).strip()); key = si[:14]
    labs = []
    for k, (y, tk) in enumerate(lines):
        if key and key in V.squash("".join(t for _, _, t in tk)):
            lb = V._lab_block(tk, key)
            if lb and V._lab_ok(lb[2], si) in ("同", "單位"):
                labs.append((k, lb))
    rk = sorted({int(z["ROW"]) for z in fin if z["FILENAME"] == x["FILENAME"] and z["PAGE"] == x["PAGE"] and z.get("TABLE") == x.get("TABLE") and z["ITEM"] == x["ITEM"] and z.get("ROW") and not z.get("SUBCOL")})
    lab = labs[rk.index(int(x["ROW"]))] if labs and len(labs) == len(rk) and x.get("ROW") and int(x["ROW"]) in rk else (labs[0] if labs else None)
    if not lab:
        c = "NOLABEL"
    else:
        k, lb = lab
        ks = V.squash(sec)[:14]
        hit = None
        for j in range(k - 1, -1, -1):
            if lines[k][0] - lines[j][0] > 600:
                break
            sb = V._lab_block(lines[j][1], ks) if ks in V.squash("".join(t for _, _, t in lines[j][1])) else None
            if sb and V._lab_ok(sb[2], V.squash(sec)) in ("同", "單位"):
                hit = (j, sb)
                break
        if not hit:                                                        # 同名科目印了幾次 → 每一個科目列都試(段落標題在上方同一欄就算)
            for k2, lb2 in labs:
                for j in range(k2 - 1, -1, -1):
                    if lines[k2][0] - lines[j][0] > 600:
                        break
                    sb = V._lab_block(lines[j][1], ks) if ks in V.squash("".join(t for _, _, t in lines[j][1])) else None
                    if sb and V._lab_ok(sb[2], V.squash(sec)) in ("同", "單位"):
                        if abs(sb[0] - lb2[0]) <= 40:
                            hit, lb = (j, sb), lb2
                        break
                if hit:
                    break
        if not hit:
            c = "NOTFOUND"
        else:
            dx = hit[1][0] - lb[0]
            c = "SAMECOL" if abs(dx) <= 40 else "OTHERCOL"
            if c == "OTHERCOL":
                ex[c].append("%s p%s %s | %s | SECTION %s | 科目 x %.0f · 標題 x %.0f" % (x["FILENAME"][:22], x["PAGE"], x.get("TABLE"), x["ITEM"][:24], sec[:20], lb[0], hit[1][0]))
    if c == "NOTFOUND":
        ex[c].append("%s p%s %s | %s | SECTION %s" % (x["FILENAME"][:22], x["PAGE"], x.get("TABLE"), x["ITEM"][:24], sec[:24]))
    seen[k_] = c
    res[c] += 1
print("[SECTION 稽核] 有 SECTION 的筆數", sum(res.values()), dict(res))
for c in ("OTHERCOL", "NOTFOUND"):
    for l in ex[c][:40]:
        print("  %s %s" % (c, l))
