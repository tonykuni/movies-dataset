#!/bin/bash
# 打包 v0129 發行夾(啟動器 zip · 測試工具 zip · 發行清單)+ 一鍵 PS 填雜湊
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
R=$S/release129; N=$S/new; T=$S/tools
rm -rf $S/pkg129; mkdir -p $R $S/pkg129/zl $S/pkg129/tools/src $S/pkg129/tools/tools $S/pkg129/tools/fixture
cp $N/ActivateVRN-2_v0129.py $S/pkg129/zl/ActivateVRN-2.py
cp $N/VRN_SystemManager_v0239.py $N/mgr_v0239_body.py $N/VRN_SystemManager_v0238.py $N/mgr_v0238_body.py $N/VRN_SystemManager_v0237.py $N/mgr_v0237_body.py $N/VRN_SystemManager_v0236.py $N/mgr_v0236_body.py \
   $N/VRN2_IndependentVerifier_v0102.py $N/VRN2_IndependentVerifier_v0101.py $N/VRN2_IndependentVerifier_v0100.py $N/_bridge_block.txt $N/launcher_v0129_doc.txt $N/launcher_v0129_funcs.py $S/pkg129/tools/src/
cp $T/build_v0128.py $T/build_v0129.py $T/mktree.sh $T/runl.sh $T/ship_test.py $T/ui_test.js $T/verify_outputs.py $T/verify_outputs_v0126.py $T/verify_outputs_v0100.py $T/verify_outputs_v0101.py \
   $T/make_verifier_v0100.py $T/make_verifier_v0101.py $T/make_verifier_v0102.py $T/make_mgr_v0238.py $T/make_mgr_v0239.py $T/cmp_fin.py $T/cmp_sub.py $T/cmp_basic.py $T/cmp_summ.py $T/cmp_hdr.py $T/cmp_sec.py \
   $T/verify_mutation_suite.py $T/subcol_mutation_test.py $T/sec_audit.py $T/run_ps_test.sh $T/extract.py \
   $T/scen129b.sh $T/scen129u.sh $T/e2e129.sh $T/run_boot_test129.sh $T/run_boot_test129_badroot.sh $T/regen129.py $T/pack129.sh $S/pkg129/tools/tools/
cp $S/fixture/HDRROWS_v0237_output.json $S/fixture/SECROWS_v0238_output.json $S/pkg129/tools/fixture/
cp $S/fixture/VRN_SystemManager_v0230.py $S/pkg129/tools/fixture/TESTSTUB_VRN_SystemManager_v0230.py
python3 - $S $R $N <<'PY'
import zipfile, sys, os, json, hashlib
S, R, N = sys.argv[1:4]
def dz(out, root):
    files = sorted(os.path.relpath(os.path.join(dp, f), root) for dp, _, fs in os.walk(root) for f in fs)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in files:
            zi = zipfile.ZipInfo(f.replace(os.sep, "/"), (2026, 10, 19, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
            z.writestr(zi, open(os.path.join(root, f), "rb").read())
dz(R + "/ActivateVRN-2_v0129.zip", S + "/pkg129/zl"); dz(R + "/vrn2_test_tools_v0129.zip", S + "/pkg129/tools")
def meta(p, name=None):
    b = open(p, "rb").read(); return {"file": name or os.path.basename(p), "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}
rp = R + "/VRN2_Release_v0129.json"
if os.path.exists(rp):
    rel = json.load(open(rp, encoding="utf-8"))
else:
    old = json.load(open(S + "/release128/VRN2_Release_v0128.json", encoding="utf-8"))
    order = []
    for c in old["embedded_components_landing_order"]:
        f = {"VRN2_IndependentVerifier_v0101.py": "VRN2_IndependentVerifier_v0102.py", "VRN2_Handover_v0128.md": "VRN2_Handover_v0129.md"}.get(c["file"], c["file"])
        order.append(dict(c, file=f))
        if f == "VRN_SystemManager_v0238.py":
            order.append({"file": "VRN_SystemManager_v0239.py"})
    rel = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0129", "date": "2026-10-19", "operator_decision": old["operator_decision"],
           "operator_order_2026_10_19": old.get("operator_order_2026_10_19"), "operator_order_2026_10_19_b": old.get("operator_order_2026_10_19_b"),
           "operator_order_2026_10_19_c": "繼續完成(v0128 推上去後繼續邊測邊修 · 逐欄稽核輸出)",
           "supersedes": "ActivateVRN-2 v0128(docs/handoff/ai/vrn2_release_v0128 · 並排表段落標題跨到另一張表)", "embedded_components_landing_order": order,
           "tested_in": old["tested_in"], "results": {"draft": True}}
rel["launcher"] = meta(N + "/ActivateVRN-2_v0129.py"); rel["launcher_zip"] = meta(R + "/ActivateVRN-2_v0129.zip"); rel["test_tools_zip"] = meta(R + "/vrn2_test_tools_v0129.zip")
rel["embedded_components_landing_order"] = [meta(N + "/" + c["file"]) if c["file"] in ("VRN_SystemManager_v0238.py", "VRN_SystemManager_v0239.py", "VRN2_IndependentVerifier_v0102.py", "VRN2_Handover_v0129.md") else c for c in rel["embedded_components_landing_order"]]
json.dump(rel, open(rp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("launcher", rel["launcher"]["sha256"][:12], [c["file"] for c in rel["embedded_components_landing_order"]][6:])
PY
H=$(sha256sum $N/ActivateVRN-2_v0129.py | cut -d' ' -f1); sed -i "s/\$Want   = '[0-9a-f]\{64\}'/\$Want   = '$H'/" $S/Run-VRN2-v0129.ps1
