"""VRN2_IndependentVerifier v0101 → v0102(整檔複本 + 補丁 · v0101 原檔不動)。
用法:python make_verifier_v0102.py <VRN2_IndependentVerifier_v0101.py> <輸出 v0102>
v0102:SECFAIL(段落標題 SECTION):標題字要在科目上方、同一個科目欄(x 差 ≤ 40 pt)· 不能是公式項(1 - … · = … · x …)。
  實例(v0238 輸出 · v0101 不查 SECTION):凱基 2637 第 5 頁並排兩張表 13 列 65 筆拿到另一張表的標題 / 公式項。"""
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:70])
    s = s.replace(a, b)


rep('"""VRN2_IndependentVerifier_v0101 — VRN-2 輸出值獨立驗證(v0100 + 表頭列檢查 HDRVAL · 由 tools/verify_outputs v3 升版 · 啟動器 v0128 內嵌',
    '"""VRN2_IndependentVerifier_v0102 — VRN-2 輸出值獨立驗證(v0100 + 表頭列 HDRVAL + 段落標題 SECFAIL · 由 tools/verify_outputs v3 升版 · 啟動器 v0129 內嵌')
rep("用法:python VRN2_IndependentVerifier_v0101.py <output 夾>", "用法:python VRN2_IndependentVerifier_v0102.py <output 夾>")
rep("      python VRN2_IndependentVerifier_v0101.py --selftest", "      python VRN2_IndependentVerifier_v0102.py --selftest")
rep("  依檔分片平行(子行程", "  v0102:SECFAIL(段落標題):SECTION 的字要在科目上方、同一個科目欄(x 差 ≤ 40 pt · 並排表的另一張表不算)· 公式項(1 - … · = … · x …)不是段落標題\n"
    "        (v0101 不查 SECTION:凱基 2637 第 5 頁 財務比率 ∥ 投資回報率 兩張表並排 · 13 列 65 筆拿到另一張表的標題 / 公式項)\n  依檔分片平行(子行程")
rep('VERSION = "VRN2_IndependentVerifier_v0101"', 'VERSION = "VRN2_IndependentVerifier_v0102"')
rep('"DUPKEY", "QTRCOL", "DUPROW", "HDRVAL")   # v0100 + 季度欄 · 完全重複 · v0101 表頭列',
    '"DUPKEY", "QTRCOL", "DUPROW", "HDRVAL", "SECFAIL")   # v0100 + 季度欄 · 完全重複 · v0101 表頭列 · v0102 段落標題')
rep('''def run_files(od, pdfdir, files):''', '''_FORMV = re.compile(r"^\\s*(?:[-+=×xX÷/]\\s|\\d+\\s*[-+/×xX÷]\\s)")


def _sec_ok(lines, item, sec, val=None):
    """v0102 段落標題 sec 在科目 item 那一列上方 600 pt 內、同一個科目欄(x 差 ≤ 40)· 回 (是否, 說明)。
    科目那一列 = 科目字相同 / 單位 / 折行的列 · 有給值 → 只用那一列有這個值的(先定列再找值 · 標題「Others」不當成科目「Others」那一列)。"""
    if _FORMV.match(nfk(sec)):
        return False, "段落標題是公式項 %r(不是標題)" % sec
    si, ss = squash(nfk(item).strip()), squash(nfk(sec).strip())
    key, ks = si[:14], ss[:14]
    labs = []
    for k, (y, tk) in enumerate(lines):
        if key and key in squash("".join(t for _, _, t in tk)):
            lb = _lab_block(tk, key)
            if lb and _lab_ok(lb[2], si) in ("同", "單位", "折行"):
                labs.append((k, lb))
    if not labs:
        return True, "科目列找不到(年度數據另判)"
    if val:
        sv = squash(nfk(str(val)).strip())
        lv = [(k, lb) for k, lb in labs if (_row_hits(lines, k, lb, si, sv) or [None])[0]]
        labs = lv or labs
    other = None
    for k, lb in labs:
        for j in range(k - 1, -1, -1):
            if lines[k][0] - lines[j][0] > 600:
                break
            if ks not in squash("".join(t for _, _, t in lines[j][1])):
                continue
            sb = _lab_block(lines[j][1], ks)
            if sb and _lab_ok(sb[2], ss) in ("同", "單位"):
                if abs(sb[0] - lb[0]) <= 40:
                    return True, "段落標題在科目上方同一欄"
                other = other or (sb[0], lb[0])
    if other:
        return False, "段落標題 %r 在另一欄(標題 x %.0f · 科目 x %.0f · 並排表的另一張表)" % (sec, other[0], other[1])
    return False, "段落標題 %r 不在科目上方同一欄" % sec


def secchk(vf, pdfdir):
    """v0102 對位的年度數據(不含子欄 / 轉置表)有 SECTION → 查段落標題(同一列只查一次)· 不過 → SECFAIL。"""
    memo, out = {}, []
    for r in vf:
        sec = str(r.get("SECTION") or "").strip()
        if sec and r.get("_V") == "ALIGNED" and not r.get("SUBCOL") and "轉置" not in str(r.get("VERIFY", "")):
            k_ = (r["FILENAME"], int(r["PAGE"]), r.get("TABLE"), r.get("ROW"), r.get("ITEM"), sec, r.get("VALUE"))
            if k_ not in memo:
                memo[k_] = _sec_ok(page_lines(Path(pdfdir) / r["FILENAME"], int(r["PAGE"])), r.get("ITEM", ""), sec, r.get("VALUE"))
            ok_, why = memo[k_]
            if not ok_:
                r = dict(r, _V="SECFAIL", _N=why + " · " + r.get("_N", ""))
        out.append(r)
    return out


def run_files(od, pdfdir, files):''')
rep('''    vf = (verify_fin([x for x in fin if not x.get("SUBCOL") and not tr(x)], pdfdir) + verify_subcol([x for x in fin if x.get("SUBCOL")], pdfdir)''',
    '''    vf = (secchk(verify_fin([x for x in fin if not x.get("SUBCOL") and not tr(x)], pdfdir), pdfdir) + verify_subcol([x for x in fin if x.get("SUBCOL")], pdfdir)''')
rep('''    """不需 PDF:指紋 · 寫回 U/I(跳脫 · 重寫)· DUPKEY · v0101 HDRVAL · 兩個字詞的值''', '''    """不需 PDF:指紋 · 寫回 U/I(跳脫 · 重寫)· DUPKEY · v0101 HDRVAL · v0102 SECFAIL · 兩個字詞的值''')
rep('''    chk("兩個字詞的值:Net + cash''', '''    SL = [(420.0, [(420, 444, "Dec-23A"), (448, 472, "Dec-24A")]), (416.0, [(44, 80, "穩定能力")]), (412.0, [(319, 323, "1"), (325, 328, "-"), (331, 400, "營業成本/營業收入")]),
          (408.0, [(50, 90, "流動比率"), (92, 100, "(x)"), (154, 160, "0.6"), (182, 188, "0.8")]), (404.0, [(319, 322, "-"), (325, 390, "銷管費用/營業收入"), (427, 440, "1.0%"), (455, 468, "0.9%")]),
          (396.0, [(44, 90, "每股資料分析")]), (392.0, [(319, 322, "x"), (325, 370, "資本周轉率"), (433, 440, "0.2"), (461, 468, "0.3")]),
          (388.0, [(50, 90, "每股盈餘"), (92, 110, "(NT$)"), (154, 165, "4.38"), (182, 193, "8.08")])]
    s1, s2, s3, s4 = (_sec_ok(SL, "流動比率 (x)", "1 - 營業成本/營業收入"), _sec_ok(SL, "x 資本周轉率", "每股資料分析"),
                      _sec_ok(SL, "每股盈餘 (NT$)", "每股資料分析", "4.38"), _sec_ok(SL, "流動比率 (x)", "穩定能力", "0.6"))
    chk("v0102 SECFAIL:左表科目拿右表的公式項 → 不過 · 右表科目拿左表的標題 → 不過(另一欄)· 同一欄的標題 → 過 → %s" % [s1[0], s2[0], s3[0], s4[0]],
        s1[0] is False and "公式項" in s1[1] and s2[0] is False and "另一欄" in s2[1] and s3[0] is True and s4[0] is True and "SECFAIL" in BADV)
    chk("兩個字詞的值:Net + cash''')
out.write_text(s, encoding="utf-8", newline="\n")
compile(s, out.name, "exec")
print("[計] %s · %d 位元組" % (out.name, len(s.encode())))
