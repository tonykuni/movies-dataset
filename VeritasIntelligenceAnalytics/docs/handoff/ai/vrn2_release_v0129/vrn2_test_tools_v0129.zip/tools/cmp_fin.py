"""v3 vs v0102 verify_fin 逐筆比較 + 鄰列換值反向測試(下一列 / 上一列 / 同列鄰欄)。用法:python cmp_fin.py <output> <pdfdir> [樣本數]"""
import collections, json, random, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs_v0126 as V3, verify_outputs as V4
od, pd = sys.argv[1], sys.argv[2]
N = int(sys.argv[3]) if len(sys.argv) > 3 else 800
fin = json.loads(Path(od, "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
reg = [x for x in fin if not x.get("SUBCOL") and "轉置" not in x["VERIFY"]]
a, b = V3.verify_fin(reg, pd), V4.verify_fin(reg, pd)
print("原樣 v3", dict(collections.Counter(x["_V"] for x in a)), "· v0102", dict(collections.Counter(x["_V"] for x in b)))
ch = collections.Counter((x["_V"], y["_V"]) for x, y in zip(a, b) if x["_V"] != y["_V"])
print("  變動", dict(ch))
for x, y in list((x, y) for x, y in zip(a, b) if x["_V"] != y["_V"])[:25]:
    print("   %s | %s | %s | %s | %s | %s | %s → %s · %s" % (x["FILENAME"][:22], x["PAGE"], x["TABLE"], x["ITEM"][:26], x["PERIOD"], x["VALUE"], x["_V"], y["_V"], y["_N"][:70]))
by = collections.defaultdict(dict)
for x in reg:
    if x.get("ROW"):
        by[(x["FILENAME"], x["TABLE"], x["PERIOD"])][x["ROW"]] = x
random.seed(7)
for nm, dr in (("下一列的值", 1), ("上一列的值", -1)):
    mut = []
    for d in by.values():
        for r, x in d.items():
            y = d.get(r + dr)
            if y and y["VALUE"] != x["VALUE"]:
                mut.append(dict(x, VALUE=y["VALUE"]))
    smp = random.sample(mut, min(N, len(mut)))
    for vn, M in (("v3", V3), ("v0102", V4)):
        r = M.verify_fin(smp, pd) if vn == "v3" else M.verify_fin(smp, pd, allrows=reg)
        c = collections.Counter(x["_V"] for x in r)
        print("反向 %s(%d 筆)%s 仍 ALIGNED %d · %s" % (nm, len(smp), vn, c.get("ALIGNED", 0), dict(c)))
        if vn == "v0102":
            for x in [x for x in r if x["_V"] == "ALIGNED"][:12]:
                print("     ALIGNED %s | %s | %s | %s | %s | %s | %s" % (x["FILENAME"][:22], x["PAGE"], x["TABLE"], x["ITEM"][:26], x["PERIOD"], x["VALUE"], x["_N"][:70]))
# 同一列鄰欄的值(期間錯一欄)· 季度值標成年度期間(貿聯損益表季度段 Dec-27F)
byr = collections.defaultdict(list)
for x in reg:
    if x.get("ROW"):
        byr[(x["FILENAME"], x["TABLE"], x["ROW"])].append(x)
mut = []
for xs in byr.values():
    for a_, b_ in zip(xs, xs[1:]):
        if a_["VALUE"] != b_["VALUE"]:
            mut.append(dict(a_, VALUE=b_["VALUE"]))
smp = random.sample(mut, min(N, len(mut)))
for vn, M in (("v3", V3), ("v0102", V4)):
    r = M.verify_fin(smp, pd) if vn == "v3" else M.verify_fin(smp, pd, allrows=reg)
    c = collections.Counter(x["_V"] for x in r)
    print("反向 同列鄰欄的值(%d 筆)%s 仍 ALIGNED %d · %s" % (len(smp), vn, c.get("ALIGNED", 0), dict(c)))
    if vn == "v0102":
        for x in [x for x in r if x["_V"] == "ALIGNED"][:12]:
            print("     ALIGNED %s | %s | %s | %s | %s | %s | %s" % (x["FILENAME"][:22], x["PAGE"], x["TABLE"], x["ITEM"][:26], x["PERIOD"], x["VALUE"], x["_N"][:70]))
qv = [x for x in reg if x["FILENAME"].startswith("凱基投顧_3665") and x["PAGE"] == 8 and x["ITEM"] == "營業收入" and x["PERIOD"] in ("Dec-26F", "Dec-27F")]
qm = [dict(x, VALUE={"Dec-26F": "26,793", "Dec-27F": "36,448"}[x["PERIOD"]]) for x in qv]
for vn, M in (("v3", V3), ("v0102", V4)):
    r = M.verify_fin(qm, pd) if vn == "v3" else M.verify_fin(qm, pd, allrows=reg)
    print("反向 季度值標成年度期間(%d 筆)%s → %s" % (len(qm), vn, [x["_V"] for x in r]))
