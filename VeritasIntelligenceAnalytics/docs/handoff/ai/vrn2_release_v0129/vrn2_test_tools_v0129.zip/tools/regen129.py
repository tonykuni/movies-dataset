"""v0129 一鍵 md / 一行重算(每次都從 v0128 的 md 與一行原始碼重新產生 · 冪等):程式碼區塊 = Run-VRN2-v0129.ps1 · 一行 = boot129.ps1(-EncodedCommand)· 雜湊全部跟著換。"""
import base64, hashlib, re
S = "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"
sha = lambda t: hashlib.sha256(t.encode("utf-8")).hexdigest()
FENCE = r"(?s)```powershell\n(.*?)\n```"
md = open(S + "/release128/VRN2_OneClick_v0128.md", encoding="utf-8").read()
boot = open(S + "/boot127/boot128.ps1", encoding="utf-8").read()
one_old = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
code_old = re.search(FENCE, md).group(1)
ps = open(S + "/Run-VRN2-v0129.ps1", encoding="utf-8").read().rstrip("\n")
WANT = r"\$Want   = '([0-9a-f]{64})'"
l_old, l_new = re.search(WANT, code_old).group(1), re.search(WANT, ps).group(1)
cs_old, cs_new = sha(code_old), sha(ps)
assert boot.count(cs_old) == 1 and boot.count("vrn2_release_v0128") == 1
boot2 = boot.replace(cs_old, cs_new).replace("v0128", "v0129")
one_new = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot2.encode("utf-16-le")).decode("ascii")
md = md.replace(code_old, "\x00CODE\x00").replace(one_old, "\x00ONE\x00").replace(boot.rstrip("\n"), "\x00BOOT\x00")
md = md.replace(cs_old, cs_new).replace(cs_old[:12], cs_new[:12]).replace(l_old, l_new).replace(l_old[:12], l_new[:12]).replace("v0128", "v0129")
a = "落地 v0231 → **v0238**(表頭列移出年度數據)+ **獨立驗證器 v0101**(多查表頭列 HDRVAL)"
assert md.count(a) == 1
md = md.replace(a, "落地 v0231 → **v0239**(表頭列移出年度數據 · 段落標題改回同一欄)+ **獨立驗證器 v0102**(多查表頭列 HDRVAL · 段落標題 SECFAIL)")
md = md.replace("\x00CODE\x00", ps).replace("\x00ONE\x00", one_new).replace("\x00BOOT\x00", boot2.rstrip("\n"))
assert re.search(FENCE, md).group(1) == ps and md.count("```powershell\n") == 1 and "v0128" not in md.replace(ps, "")
assert base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot2
assert re.search(r"(?s)```text\n(.*?)\n```", md).group(1) == boot2.rstrip("\n") and cs_new in boot2 and "vrn2_release_v0129" in boot2
open(S + "/release129/VRN2_OneClick_v0129.md", "w", encoding="utf-8", newline="\n").write(md)
open(S + "/boot127/boot129.ps1", "w", encoding="utf-8", newline="\n").write(boot2)
open(S + "/boot127/oneline129.txt", "w").write(one_new + "\n")
print("launcher %s · code %s · one-liner %d 字 · md %d" % (l_new[:12], cs_new[:12], len(one_new), len(md)))
