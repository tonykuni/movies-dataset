"""v0102 段落標題(SECFAIL)反向測試:① v0238 輸出真的出現過的 13 列 65 筆(凱基 2637 第 5 頁並排表)換回原本的 SECTION → v0102 全抓 · v0101 對照(不查)
② 摩根 2308 第 5 頁並排表:右表科目換成左表才有的標題 · 左表科目換成右表才有的標題 → 全抓 ③ 原樣 → 0 筆。
用法:python cmp_sec.py <output 夾> <PDF 夾> [fixture/SECROWS_v0238_output.json]"""
import collections
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs as V  # noqa: E402
import verify_outputs_v0101 as V1  # noqa: E402

od, pd = Path(sys.argv[1]), sys.argv[2]
fx = Path(sys.argv[3]) if len(sys.argv) > 3 else Path(__file__).resolve().parent.parent / "fixture" / "SECROWS_v0238_output.json"
fin = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
old = json.loads(fx.read_text(encoding="utf-8"))
cnt = lambda rs: dict(collections.Counter(r["_V"] for r in rs))  # noqa: E731
reg = [x for x in fin if not x.get("SUBCOL") and "轉置" not in str(x.get("VERIFY", "")) and x.get("SECTION")]
base = V.secchk(V.verify_fin(reg, pd), pd)
print("原樣(段落標題)%s %s · 有 SECTION 的 %d 筆" % (V.VERSION[-5:], cnt(base), len(reg)))
o1 = V1.verify_fin(old, pd)
print("對照 v0101 段落標題放回(%d 筆)→ %s(v0101 不查 SECTION = 漏抓)" % (len(old), cnt(o1)))
n2 = V.secchk(V.verify_fin(old, pd), pd)
print("反向 段落標題放回(%d 筆)%s 仍 ALIGNED %d · %s" % (len(old), V.VERSION[-5:], sum(1 for r in n2 if r["_V"] == "ALIGNED"), cnt(n2)))
ms = [x for x in reg if x["FILENAME"].startswith("MS-2308") and x.get("TABLE") == "P5·FR·02·TB"]
sw = [dict(x, SECTION="Consolidated Balance Sheets") for x in ms]
n3 = V.secchk(V.verify_fin(sw, pd), pd)
print("反向 右表科目換成左表才有的標題(%d 筆)%s 仍 ALIGNED %d · %s" % (len(sw), V.VERSION[-5:], sum(1 for r in n3 if r["_V"] == "ALIGNED"), cnt(n3)))
lf = [x for x in fin if x["FILENAME"].startswith("MS-2308") and str(x.get("PAGE")) == "5" and x.get("TABLE") != "P5·FR·02·TB" and not x.get("SUBCOL")][:40]
sl = [dict(x, SECTION="Margins (%)") for x in lf]
n4 = V.secchk(V.verify_fin(sl, pd), pd)
print("反向 左表科目換成右表才有的標題(%d 筆)%s 仍 ALIGNED %d · %s" % (len(sl), V.VERSION[-5:], sum(1 for r in n4 if r["_V"] == "ALIGNED"), cnt(n4)))
ok = (cnt(base).get("SECFAIL", 0) == 0 and all(r["_V"] == "SECFAIL" for r in n2) and len(n2) > 0 and sw and all(r["_V"] == "SECFAIL" for r in n3)
      and sl and all(r["_V"] == "SECFAIL" for r in n4))
print("[計] 段落標題反向測試 %s" % ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 1)
