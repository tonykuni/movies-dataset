"""組 VRN_SystemManager_v0239.py = 檔頭說明 + 加速器橋(_bridge_block.txt)+ mgr_v0239_body.py。用法:python make_mgr_v0239.py <new 夾>"""
import hashlib
import sys
from pathlib import Path

N = Path(sys.argv[1])
doc = ('"""VRN-2 SystemManager v0239 — 薄尾(邊測邊修:段落標題 SECTION 跨到並排的另一張表):凱基 2637 第 5 頁左「財務比率」右「投資回報率」兩張表並排 · '
       '左表 流動比率 / 速動比率 / 淨負債 拿到右表的公式項「1 - 營業成本/營業收入」· 右表 1 / (營業運用資金 … = 稅後 ROIC 拿到左表的「每股資料分析」/「資產運用狀況」(共 13 列 65 筆)· '
       '第三讀法(pdfplumber 字詞框)找科目那一列 → 上方同一個科目欄找這個 SECTION 字 → 找不到或是公式項(1 - … · = … · x …)→ 改成同一欄最近的段落標題(到期間表頭為止 · 沒有 → 空白);值一個都不動。'
       '獨立驗證器 v0102 另查(pypdfium2 · SECFAIL)。\n'
       '  零替換:前版函式一個都不改;前版輸出冊(v0238)整段照跑後再補(直接叫前版包裝)· vrn2 / 成功登記用同一段程式碼重新綁定 · 前版必須是 v0238 · 其餘動詞照前版鏈。\n"""\n')
src = "#!/usr/bin/env python3\n# -*- coding: utf-8 -*-\n" + doc + "from __future__ import annotations\n\n\n" + (N / "_bridge_block.txt").read_text(encoding="utf-8").rstrip("\n") + "\n\n\n" + (N / "mgr_v0239_body.py").read_text(encoding="utf-8").lstrip("\n")
compile(src, "VRN_SystemManager_v0239.py", "exec")
(N / "VRN_SystemManager_v0239.py").write_text(src, encoding="utf-8", newline="\n")
print("[計] VRN_SystemManager_v0239.py · %d 位元組 · sha %s" % (len(src.encode()), hashlib.sha256(src.encode()).hexdigest()[:12]))
