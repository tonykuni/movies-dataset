#!/bin/bash
# 使用者機器情境(2026-10-19):上次成功 = v0125(管理器鏈到 v0235)· 一行(v0127)已把 Downloads 換成 v0127 · 環境變數 VIA_ROOT 指錯 · 遠端放 v0129 發行分支 · $1 = 樹
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
T="$1"; R=$S/release129
cd /tmp && $S/tools/mktree.sh $T $S/new/ActivateVRN-2_v0125.py 2>&1 | grep -v -e negotiat -e acknowledg
PY=$S/venv_vrn2/bin/python $S/tools/runl.sh $T > $T.pre_v0125.log 2>&1; sed -i 's/\x1b\[[0-9;]*m//g' $T.pre_v0125.log
cp $T/Downloads/ActivateVRN-2.py $T/Downloads/ActivateVRN-2_v0122_like.py.bak; cp $S/new/ActivateVRN-2_v0127.py $T/Downloads/ActivateVRN-2.py
B=$T.br; rm -rf $B; mkdir -p $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0129; cp $R/ActivateVRN-2_v0129.zip $R/VRN2_Release_v0129.json $R/vrn2_test_tools_v0129.zip $R/VRN2_OneClick_v0129.md $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0129/
cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1
echo "scenario ok · $(grep -E '→ GREEN ⑨' $T.pre_v0125.log | cut -c1-60) · Downloads = $(grep -o 'VERSION = "ActivateVRN-2 v[0-9]*"' $T/Downloads/ActivateVRN-2.py)"
