#!/bin/bash
# 操作員一鍵 v0100 實測:VRN-1 = GitHub 真複製(本機 main 退回 62475b0 · 停在別的分支 · 有一個沒提交的改動)
#                      VRN-2 = 沙盒樹(Downloads 是 v0131 · 發行 v0132 + 操作員一鍵放在假 GitHub 分支)· 貼「一行」
S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
P=$W/pair101; T=$P/t; V1=$P/clone_here/VIA-VDF-VRN; TAG=${1:-full}
OCRPY=$W/v131/ocrenv/vrn2_ocr/bin/python; OCRBR=$W/v131/ocrenv/vrn2_ocr/VRN2_OCRBridge_v0100.py
cd /tmp && $S2/tools/mktree.sh $T $W/v131/ActivateVRN-2_v0131.py > $P/setup_$TAG.log 2>&1
B=$T.br; rm -rf $B; A=$B/VeritasIntelligenceAnalytics/docs/handoff/ai; mkdir -p $A/vrn2_release_v0132 $A/vrn1_vrn2_oneclick_v0101
cp $W/v132/release132/ActivateVRN-2_v0132.zip $W/v132/release132/VRN2_Release_v0132.json $W/v132/release132/VRN2_OneClick_v0132.md $A/vrn2_release_v0132/
cp $P/out/VRN1_VRN2_OneClick_v0101.md $A/vrn1_vrn2_oneclick_v0101/
cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1
rm -rf $P/clone_here  # v0101:VRN-1 倉不在 → 一鍵自己複製
:
echo "VRN-1 before: $(git -C $V1 rev-parse --abbrev-ref HEAD)@$(git -C $V1 rev-parse --short HEAD) · dirty $(git -C $V1 status --porcelain --untracked-files=no | wc -l)" > $P/before_$TAG.txt
B64=$(cut -d' ' -f6 $P/out/oneline_pair.txt)
mkdir -p $P/home $P/tmp; rm -rf $P/out_vrn1_$TAG
cd "$T/Downloads" && env HOME="$P/home" TMPDIR="$P/tmp" TEMP="$P/tmp" VIA_ROOT="$T/VIA" VIA_VRN_INPUT="$T/samples" VIA_ENVS_HOME="$T/envs" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$OCRBR" PYTHONDONTWRITEBYTECODE=1 PATH="$S2/venv_vrn1/bin:$S2/pwsh:$PATH" \
  VIA_ACCEL_HOME="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules" VIA_TEMP_ROOT="$P/tmp" \
  VRN2_ROOT="$T/VIA" VRN2_LAUNCHER="$T/Downloads/ActivateVRN-2.py" VRN2_PY="$S2/venv_vrn2/bin/python" VRN2_LAUNCHER_ARGS="--no-install" \
  VIA_VRN1_ROOT="$V1" VRN1_OUT="$P/out_vrn1_$TAG" VRN1_ARGS="--no-open" ${PAIR_ENV} \
  timeout 5400 "$S2/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -EncodedCommand "$B64" > $P/scen_$TAG.log 2>&1
echo "rc $?" > $P/scen_$TAG.rc
sed -i 's/\x1b\[[0-9;]*m//g' $P/scen_$TAG.log
echo "VRN-1 after: $(git -C $V1 rev-parse --abbrev-ref HEAD)@$(git -C $V1 rev-parse --short HEAD) · dirty $(git -C $V1 status --porcelain --untracked-files=no | wc -l) · stash $(git -C $V1 stash list | wc -l) · work 分支 $(git -C $V1 rev-parse --short work)" >> $P/before_$TAG.txt
echo done >> $P/scen_$TAG.rc
