// VRN-1「驗證過的輸出」HTML U/I 真瀏覽器實測（Chromium · Playwright）
// 用法：node ui_verified.js <VRN_Verified_Output_v0100.html> <VRN_Verified_Output_v0100.json> <截圖夾>
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const file = path.resolve(process.argv[2]);
  const summary = JSON.parse(fs.readFileSync(path.resolve(process.argv[3]), 'utf8'));
  const shots = path.resolve(process.argv[4]);
  fs.mkdirSync(shots, { recursive: true });
  const res = [];
  const ok = (name, cond, extra) => res.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra).slice(0, 200) });
  const exe = fs.readdirSync('/opt/pw-browsers').filter(d => d.startsWith('chromium-')).map(d => `/opt/pw-browsers/${d}/chrome-linux/chrome`).find(p => fs.existsSync(p));
  const browser = await chromium.launch({ executablePath: exe });
  const errors = [];
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + file);
  await page.waitForLoadState('load');
  const data = await page.evaluate(() => JSON.parse(document.getElementById('data').textContent));
  const keys = Object.keys(data);
  const tabs = await page.$$eval('#tabs button', bs => bs.map(b => b.textContent));
  ok('分頁數 = 資料表數', tabs.length === keys.length && keys.length >= 6, tabs.join(' | '));
  const c = summary.counts;
  const want = { fin: c.financial.verified + c.financial.corrected, ann: c.annual.verified, rec: c.record.reports };
  for (const [k, n] of Object.entries(want)) {
    if (data[k]) ok(`${k} 列數 = JSON 計數 (${n})`, data[k].rows.length === n, data[k].rows.length);
  }
  for (let i = 0; i < keys.length; i++) {
    await page.click(`#tabs button:nth-child(${i + 1})`);
    const sel = await page.$eval(`#tabs button:nth-child(${i + 1})`, b => b.getAttribute('aria-selected'));
    const shown = await page.$$eval('#tb tr', trs => trs.length);
    const n = data[keys[i]].rows.length;
    ok(`分頁「${data[keys[i]].name}」：選中、每頁最多 50 筆`, sel === 'true' && shown === Math.min(50, n), `${shown}/${n}`);
    const pg = await page.textContent('#pg');
    ok(`分頁「${data[keys[i]].name}」：頁碼文字對`, pg.includes(`${n} 筆`), pg);
  }
  await page.click('#tabs button:nth-child(1)');
  const n0 = data[keys[0]].rows.length;
  if (n0 > 50) {
    await page.click('#next');
    ok('下一頁 → 第 2 頁', (await page.textContent('#pg')).startsWith('第 2 /'), await page.textContent('#pg'));
    const first2 = await page.$eval('#tb tr td', td => td.textContent);
    ok('第 2 頁第一列 = 資料第 51 列', first2 === String(data[keys[0]].rows[50][0]), first2);
    await page.click('#prev');
    ok('上一頁 → 第 1 頁', (await page.textContent('#pg')).startsWith('第 1 /'));
  }
  const files = await page.$$eval('#ff option', os => os.map(o => o.value).filter(Boolean));
  ok('檔案篩選是原檔名（不是雜湊）', files.length >= 1 && files.every(f => /\.(pdf|docx|txt|png|jpe?g)$/i.test(f)), files.slice(0, 3).join(' | '));
  if (files.length) {
    await page.selectOption('#ff', files[0]);
    const fi = data[keys[0]].cols.indexOf(data[keys[0]].cols.includes('file') ? 'file' : 'VerifyFile');
    const expect = data[keys[0]].rows.filter(r => r[fi] === files[0]).length;
    ok('選一個檔 → 只剩那個檔的列', (await page.textContent('#pg')).includes(`${expect} 筆`), `${files[0]} · ${expect}`);
    await page.selectOption('#ff', '');
  }
  await page.fill('#fq', 'CORRECTED');
  const corr = data[keys[0]].rows.filter(r => r.join(' ').toLowerCase().includes('corrected')).length;
  ok('搜尋 CORRECTED → 自動修正的列', (await page.textContent('#pg')).includes(`${corr} 筆`), corr);
  await page.fill('#fq', '<script>');
  ok('搜尋含 <script> 不出錯、0 筆', (await page.textContent('#pg')).includes('0 筆'));
  await page.fill('#fq', '');
  const html = await page.content();
  ok('資料嵌入安全（沒有被插入的 <script> 標籤）', (html.match(/<script/g) || []).length === 2);
  await page.screenshot({ path: path.join(shots, 'verified_desktop.png'), fullPage: false });
  const phone = await (await browser.newContext({ viewport: { width: 390, height: 844 }, colorScheme: 'dark' })).newPage();
  phone.on('pageerror', e => errors.push(e.message));
  await phone.goto('file://' + file);
  const overflow = await phone.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  ok('手機寬 390：頁面不會左右捲（表格自己捲）', overflow <= 1, overflow);
  const bg = await phone.evaluate(() => getComputedStyle(document.body).backgroundColor);
  ok('深色模式背景', bg === 'rgb(18, 19, 20)', bg);
  await phone.screenshot({ path: path.join(shots, 'verified_phone_dark.png'), fullPage: false });
  ok('沒有 JS 錯誤', errors.length === 0, errors.join(' | '));
  await browser.close();
  for (const r of res) console.log(`  [${r.ok ? 'PASS' : 'FAIL'}] ${r.name}${r.extra !== '' ? ' · ' + r.extra : ''}`);
  const pass = res.filter(r => r.ok).length;
  console.log(`[UI] ${pass}/${res.length} ${pass === res.length ? 'PASS' : 'FAIL'}`);
  process.exit(pass === res.length ? 0 : 1);
})();
