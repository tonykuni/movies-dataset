const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const out = {};
  for (const [w,h,name] of [[1440,900,'d'],[390,844,'m']]) {
    const p = await b.newPage({ viewport: { width: w, height: h } }); const errs=[]; p.on('pageerror', e => errs.push(e.message));
    await p.goto('file://' + process.argv[2]); await p.waitForTimeout(700);
    out[name] = await p.evaluate(() => { const hd=document.querySelector('header.vh'), lg=hd.querySelector('.logo.img'), im=lg.querySelector('img'), tx=lg.nextElementSibling;
      const r=x=>{const q=x.getBoundingClientRect(); return [Math.round(q.top), Math.round(q.bottom), Math.round(q.height)]};
      return {header:r(hd), logoBox:r(lg), img:r(im), text:r(tx), title:document.title, small:hd.querySelector('small').textContent, cs:getComputedStyle(im).boxShadow+'|'+getComputedStyle(im).filter+'|'+getComputedStyle(lg).backgroundColor}; });
    out[name].errs = errs;
    await p.screenshot({ path: process.argv[3] + '/h_' + name + '.png', clip: { x: 0, y: 0, width: w, height: name==='d'?140:230 } });
  }
  console.log(JSON.stringify(out, null, 1)); await b.close(); })();
