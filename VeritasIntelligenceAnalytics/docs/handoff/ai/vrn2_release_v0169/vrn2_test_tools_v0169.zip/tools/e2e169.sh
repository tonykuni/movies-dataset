#!/bin/bash
# v0169 e2e(RoundAll v0125 · Handle-All v0117 · 套件 v0168 照釘 · 沙盒含三份原文):auto 整輪(閘關 · 提示在非互動 stdin 下預設續跑)
# → --confirm list → auto 第二次(收據 v0168 → repair)→ VRN2_MODE=full + 管 A = 中止提示 → 竄改不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v169; W4=/home/user/vrn2_work/v164; T=$W/t169a; P=$S2/venv_vrn2/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
REL=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
cp /home/user/vrn2_work/v165/pdfs/daiwa6278.pdf "$T/samples/Daiwa-6278 20260521.pdf"; cp /home/user/vrn2_work/v165/pdfs/ctbc3264.pdf "$T/samples/欣銓(3264,B_買進)-CTBC260918.pdf"; cp /home/user/vrn2_work/v168/pdfs/hn6143.pdf "$T/samples/華南投顧-6143-振曜-1141128.pdf"; for f in "$T/VIA/VIA_Reports/vrn2/VRN2_Input_latest.json" "$T/VIA/functional modules/VRN2/SSOT/"*.json; do sed -i "s|$S/v153/t153d/samples|$T/samples|g; s|$S/v151/t151/samples|$T/samples|g" "$f"; done
$P -I $W4/seed164.py $T $W4/rt > $W/seed169.log 2>&1; cat $W/seed169.log
B=$T.br; D6=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168; D7=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169; mkdir -p $D6 $D7
cp $REL/vrn2_release_v0168/VRN2_Closeout_v0168.zip $REL/vrn2_release_v0168/VRN2_Release_v0168.json $D6/
cp $W/release169/VRN2_RoundAll_v0125.py $W/release169/VRN2_RoundAll_v0125.md $W/release169/VRN2_HandleAll_v0117.md $W/release169/VRN2_HandleAll_v0117_boot.txt $W/release169/VRN2_Release_v0169.json $D7/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release169/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2)
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 6000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" < /dev/null > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny169.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; cp -a $V2/output $W/out_$N 2>/dev/null; }
rm -rf "${W:?}/out_auto1" "${W:?}/out_auto2" "${W:?}/out_tamper"; rm -f $W/tiny169.rc
run auto1
RA=$T/home/Downloads/VRN2_RoundAll_v0125.py
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm list > $W/confirm_list.log 2>&1; echo "confirm list rc $?" >> $W/tiny169.rc
run auto2
cd "$T/home" && printf 'A\n' | "${ENVV[@]}" VRN2_MODE=full timeout 600 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_abort.log 2>&1; echo "abort rc $?" >> $W/tiny169.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_abort.log
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169/VRN2_HandleAll_v0117_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny169.rc
