"""v0169(冪等):套件 v0168 不動(雜湊照釘)→ RoundAll v0125 → Handle-All v0117(整輪 + 同意閘未開 → 先問要不要中止 · 不代設)
→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0169)。vrn2_release_v0168 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v169"); rel = W / "release169"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v168/release168")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r168 = json.loads((REPO / "vrn2_release_v0168/VRN2_Release_v0168.json").read_text(encoding="utf-8"))
want = r168["package"]["sha256"]
ra = (W / "new/VRN2_RoundAll_v0125.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0168"' in ra and 'VERSION = "v0125"' in ra
assert 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168"' in ra            # 套件 zip 照舊從 v0168 發行夾取
(rel / "VRN2_RoundAll_v0125.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169'")
rep("$F = 'VRN2_RoundAll_v0124.py'", "$F = 'VRN2_RoundAll_v0125.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0116", "Handle-All v0117", ha.count("Handle-All v0116"))
rep("$ra = @(switch ($Mode)", '''if ($Mode -eq 'full' -and -not $gate) {
Write-Host '[YELLOW] ④ 同意閘未開 + 整輪:⑥f 共識會被 DENY(Combined 共識欄留空 · 收尾頁列「人工」)' -ForegroundColor Yellow
$a4 = $env:VRN2_YES
if (-not $a4) { try { $a4 = Read-Host '    要先中止、自己把同意閘設好再重貼嗎?(A = 中止 · Enter 或其他 = 照跑 · 閘保持關 · VRN-2 不代設)' } catch { $a4 = '' } }
if ("$a4" -match '^[aA]$') { Write-Host "    已中止(視窗不會關)· 在這個視窗貼(PowerShell):`$env:VIA_NET_CONSENT = 'YES'; `$env:VIA_SCRAPE_CONSENT = 'YES'(cmd 視窗:set VIA_NET_CONSENT=YES 與 set VIA_SCRAPE_CONSENT=YES)· 設好再重貼同一行(操作員決定 · VRN-2 不代設)" -ForegroundColor Cyan; return }
}
$ra = @(switch ($Mode)''')
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if re.search(r"Handle-All v0116|v0124\.py", l) and not l.lstrip().startswith("#")]
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0168", "vrn2_release_v0169"), ("VRN2_HandleAll_v0116.md", "VRN2_HandleAll_v0117.md"), ("Handle-All v0116 SHA-256 OK", "Handle-All v0117 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0117_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169/VRN2_HandleAll_v0117_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0117(2026-11-02 · 收尾頁 ⑥f 同意閘列 → 人工 · 整輪遇閘未開先問中止 · 套件 v0168 不動 · RoundAll v0125)

桌機 2026-11-02 12:31(v0116 整輪 3117 秒):**資料面全完成** —— 6143 補回 40 值 · 年度 11,905 筆 · 剔除 2,508 · 缺項 0 · 冪等 GREEN · ⑪ 錯值 0。
收尾 OPEN「VRN-2 1 項」是標籤錯:這輪 PowerShell 視窗貼了 cmd 寫法的 set,VIA_SCRAPE_CONSENT 沒設成 → ⑥f 被 DENY;
那一列「⑥f VIA 網路工具 DENY」在負責方規則沒有分支 → 落到預設 VRN-2。同意閘是操作員的決定,不是 VRN-2 要修的程式。

| 項目 | 現在 |
|---|---|
| 負責方 | ⑥f 列「同意閘未開」→ **人工**(附兩種視窗的設法)·「合規 DENY」→ VCGC · 其他不變 |
| 整輪 + 閘未開 | Handle-All 先停下來問:`A` = 中止(自己設好同意閘再重貼)· Enter = 照跑(閘保持關)· **VRN-2 不代設** |
| 套件 | 照舊 `vrn2_release_v0168/VRN2_Closeout_v0168.zip`(SHA-256 `%s`)|
| 一支 Python | `VRN2_RoundAll_v0125.py`(SHA-256 `%s` · 自測 91 項)|
| 自動選模式 | 收據已是 v0168 → **repair**(閘開時會重抓 ⑥f 共識 · 補回 Combined 共識欄 · 約 10 ~ 15 分鐘)|

## PowerShell 7 視窗(%d 字元)——你現在用的視窗

先貼這一行(同意閘 · 操作員決定):

```powershell
$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'
```

再貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0117 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0125 `%s`)。

## cmd 視窗(%d 字元)

```bat
set VIA_NET_CONSENT=YES
set VIA_SCRAPE_CONSENT=YES
%s
```

`set "X=Y"` 是 cmd 的寫法,在 PowerShell 視窗貼不會生效(這輪就是這樣)· PowerShell 要用 `$env:X = 'Y'`。

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0125.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0125.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0117.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0125.py(套件 v0168 不動 · ⑥f 同意閘列 → 人工)

`VRN2_RoundAll_v0125.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0124 +:

| 改了什麼 | 說明 |
|---|---|
| 負責方 | ⑥f「VIA 網路工具 DENY」列:detail 帶「同意閘未開」→ 人工(附 PowerShell / cmd 兩種設法 · 開了跑 repair 會重抓共識);帶「合規 DENY」→ VCGC |
| 根 | 該列與 ⑥f 共識列同根 · 合併後整項人工(以前落到預設 VRN-2 · 合併時把整項帶成 VRN-2)|

桌機 12:31 狀態:資料面全完成(6143 補回 40 · 11,905 筆 · 錯值 0 · 缺項 0)。自測 91 項(v0124 的 90 項 + 89)。套件 `vrn2_release_v0168/VRN2_Closeout_v0168.zip`(SHA-256 `%s` · 本檔內已釘 · 不動)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0125.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0125 + VRN2_HandleAll_v0117 (package v0168 unchanged)", "date": "2026-11-02",
        "trigger": "桌機 2026-11-02 12:31(Handle-All v0116 整輪 · 套件 v0168 · 管理器 v0259)收尾 OPEN「VRN-2 1 項」= ⑥f VIA 網路工具 DENY 列 · 操作員「之前不是收尾了嗎 · 全景式檢視 · 儘快收尾」",
        "desktop_1231": {"data_side": "COMPLETE — 6143 40 values back (annual 11,865 → 11,905 · Rejected 2,548 → 2,508) · gaps 0 · idempotence GREEN · independent verifier 0 wrong (TRANSALIGNED 190 → 230) · completion 紅 0",
                         "gate": "operator pasted cmd-style set in a PowerShell window → VIA_SCRAPE_CONSENT unset → step 6f DENIED fail-closed → Combined consensus columns empty this round (store keeps both runs; repair with the gate open re-fetches and appends corrected rows)"},
        "root_cause": "the dedicated closeout row 「⑥f VIA 網路工具 DENY」 matched no owner branch → default VRN-2; it shares the ⑥f 共識 root, and merge_same takes the heaviest owner → the whole merged consensus item was labelled VRN-2",
        "fixes": {"RoundAll_v0125": "owner: a ⑥f row whose detail carries 同意閘未開 → 人工 (with both shells' syntax and the note that repair re-fetches consensus) · 合規 DENY → VCGC · root unchanged (merges into the one consensus item)",
                  "HandleAll_v0117": "v0116 pointed at RoundAll v0125 (vrn2_release_v0169) · full mode with the consent gate closed now PROMPTS first: A = abort so the operator sets the gate and re-pastes, Enter/other = run with the gate closed; the gate itself is never set by the script (VRN-2 不代設) · non-interactive stdin = continue (today's behaviour)"},
        "package": {"name": r168["package"]["name"], "sha256": want, "release_folder": "vrn2_release_v0168", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0124.py", "sha256": r168["roundall"]["sha256"], "status": "superseded 2026-11-02; file kept in vrn2_release_v0168"}],
        "roundall": {"name": "VRN2_RoundAll_v0125.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0125.md"},
        "handleall": {"name": "VRN2_HandleAll_v0117.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0117_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "results": {"status": "see VRN2_Verification_v0169.md"}}
(rel / "VRN2_Release_v0169.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
