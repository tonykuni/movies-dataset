"""v0168 收尾:驗證紀錄 · 工具包 · 日誌包 · 介面參考檔 → 發行夾;交接 v0169(v0168 + 本輪)· 桌機短版交接 §9 · latest;版本鎖 v0101(只增 · v0100 不動)。"""
import hashlib, json, shutil, subprocess, zipfile
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-movies-dataset/484f6e73-0cd5-53cb-a8dd-d4ee89d5500c/scratchpad")
W = S / "v169"; REL = W / "release169"
GIT = Path("/home/user/movies-dataset")
AI = GIT / "VeritasIntelligenceAnalytics/docs/handoff/ai"
OUT = AI / "vrn2_release_v0169"
UP = Path("/root/.claude/uploads/484f6e73-0cd5-53cb-a8dd-d4ee89d5500c/ddbd4915-taiwan_stock_data_matrix.html")
BR = "claude/vrn2-closeout-authorization-y4ixl7"
sha = lambda b: hashlib.sha256(b).hexdigest()  # noqa: E731
rel = json.loads((REL / "VRN2_Release_v0169.json").read_text(encoding="utf-8"))
assert not OUT.exists(), "發行夾已存在 · 不覆寫"
for p in (AI / "VRN2_Handover_v0170.md", AI / "VRN2_FreezeLock_v0102.json"):
    assert not p.exists(), p

ra_log = (S / "ra125.log").read_text(encoding="utf-8")
l_log = (S / "l169.log").read_text(encoding="utf-8")
wb_log = subprocess.run(["python3", "VRN2_Workbench_v0104.py", "--selftest"], cwd=str(S / "rtw"), capture_output=True, text=True, timeout=600).stdout
e2e = (S / "e2e9" / "run.log").read_text(encoding="utf-8")
pick = lambda text, keys: "\n".join(l for l in text.splitlines() if any(k in l for k in keys))  # noqa: E731

ver = """# VeritasReportNova(VRN)v0169 驗證紀錄(2026-11-01 · Workbench v0104 · 套件 v0169 · RoundAll v0125 · Handle-All v0117)

## 1. 要求

操作員 2026-11-01:「呈現在 HTML U/I 上的子系統名稱還原為 VeritasReportNova · 成為 VRN 唯一系統」「印章 logo 為透明去背無框無特效 ·
以紅字大小為依據跟 header 文字做 header 大小 logo 最佳化調節加入」(附印章圖)。另:桌機貼 v0168 那行得 `[RED] boot SHA-256 mismatch` ——
原因是 AI 在對話裡手打的雜湊打錯(發行夾 md 裡程式產生的那一行是對的);這一輪的一行一律從檔案複製。

## 2. 做了什麼

| 檔 | 版本 | SHA-256 | 說明 |
|---|---|---|---|
| Workbench | v0104(runtime 內)| `%s` | v0103 薄尾:畫面名稱 VeritasReportNova / VRN · 00 只讀互看列 VDF · VCGC · 內建印章 · 主印框高 = 頁首文字區塊高 |
| 內建印章 | VRN2_Logo_Seal_v0100.png | `%s` | 操作員附圖原樣(本來就透明去背 · 無白底 · 無框)· 裁到印泥範圍 · 218 × 240 |
| runtime | v0160 | `%s` | v0159 的 %d 個成員逐位元組不動 + 上面兩檔 |
| 啟動器 | v0169 | `%s` | 只換 WORKBENCH / runtime / 收據名 / 自測一段 |
| 套件 | VRN2_Closeout_v0169.zip | `%s` | 其他成員跟 v0168 逐位元組相同 |
| RoundAll | v0125 | `%s` | Workbench 鏈 + 印章只增補放 · 收尾頁沒有 v0104 標記 → 重渲染 · 取件分支 `%s`(退路 main)|
| Handle-All | v0117 | 一行 `%s` · 開機檔 `%s` | 指向 RoundAll v0125 |

不改:檔名與指令(ActivateVRN-2_v#### · VRN2_* · vrn2://)· 收據 · 輸出冊 · 內嵌的輸出冊資料 window.VRN2_DATA(U/I 匯出 = 輸出冊逐字)· 左面板 Gate 按鈕。

## 3. 測試(雲端容器 · Linux · Python 3.13)

```text
%s
%s
%s
```

### 3.1 端到端沙盒(仿桌機:runtime 夾只有 v0102 鏈 · 收據 v0166)

```text
%s
```

結果:runtime 夾補放 Workbench v0103 · v0104 · 內建印章(v0102 雜湊不變)· 收尾頁標題「VeritasReportNova · VRN Workbench」· 印章 data URI · 00 頁在。

### 3.2 瀏覽器(Chromium)

1440 寬:文字區塊 20–79 px · 主印框 20–79 px(上下緣對齊)· 小印垂到 85 px · 印章 box-shadow / filter 皆 none · 底色透明 · JS 錯誤 0。
390 寬:頁首原本就換行(印章一列、文字一列),主印框高 = 文字區塊高 72 px。

## 4. 限制

- 容器沒有 PowerShell:這一行沒在 pwsh 實跑(雜湊鏈在 Python 端照 PowerShell 的算法核過)。
- 桌機有自己的 VRN2_Logo.* 時照舊用桌機的(先後順序不變);要用這顆印章:把本機那張拿開,或放同一張圖。
- 「VRN 唯一系統」只改 VRN 自己畫面上的名字;CLAUDE.md / AGENTS.md 的四系統命名規則(政策 L123)是 VCGC 的冊,這裡不改,待 VCGC 收。
""" % (sha((S / "rtw" / "VRN2_Workbench_v0104.py").read_bytes())[:12], sha((W / "new" / "VRN2_Logo_Seal_v0100.png").read_bytes())[:12], rel["runtime"]["zip_sha256"][:12], rel["runtime"]["retained_members"],
       rel["launcher"]["sha256"][:12], rel["package"]["sha256"][:12], rel["roundall"]["sha256"][:12], BR, rel["handleall"]["line_sha256"][:12], rel["handleall"]["boot_line_sha256"][:12],
       wb_log.strip().splitlines()[-1], pick(l_log, ("[PASS] v0169",)) or "(啟動器 v0169 自測 rc 0)", ra_log.strip().splitlines()[-1],
       pick(e2e, ("] ① 套件", "[U/I]", "Workbench 重渲染(最新收據) ·")).replace(str(S), "<scratch>")[:2000])
OUT.mkdir(parents=True)
for n in ("VRN2_Closeout_v0169.zip", "VRN2_HandleAll_v0117.md", "VRN2_HandleAll_v0117_boot.txt", "VRN2_Release_v0169.json", "VRN2_RoundAll_v0125.md", "VRN2_RoundAll_v0125.py"):
    shutil.copy2(str(REL / n), str(OUT / n))
(OUT / "VRN2_Verification_v0169.md").write_text(ver, encoding="utf-8", newline="\n")
shutil.copy2(str(W / "new" / "VRN2_Logo_Seal_v0100.png"), str(OUT / "VRN2_Logo_Seal_v0100.png"))
with zipfile.ZipFile(OUT / "vrn2_test_tools_v0169.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "tools" / "mk169.py", W / "tools" / "finalize169.py", W / "new" / "VRN2_Workbench_v0104.py", S / "hdr.js", REL / "handleall_src.ps1", REL / "boot_src.ps1", REL / "tiny_line.txt", REL / "cmd_line.txt", S / "ui.js", S / "mob2.js"]:
        z.write(str(p), "tools/" + p.name)
with zipfile.ZipFile(OUT / "logs_v0169.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p, n in ((S / "ra125.log", "roundall_v0125_selftest.log"), (S / "l169.log", "launcher_v0169_selftest.log"), (S / "e2e9" / "run.log", "e2e_repair_sandbox.log")):
        z.writestr(n, p.read_text(encoding="utf-8").replace(str(S), "<scratch>"))
    z.writestr("workbench_v0104_selftest.log", wb_log)

# ---- 交接 v0170 = v0169 + 本輪 ----
h = (AI / "VRN2_Handover_v0169.md").read_text(encoding="utf-8")
lines = h.split("\n")
assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0168")
lines[0] = "# VeritasReportNova(VRN)交接報告 · ActivateVRN-2 v0169 + VRN2_RoundAll_v0125 + VRN2_HandleAll_v0117 · 2026-11-01(畫面名稱 VeritasReportNova · VRN 唯一系統 · 內建透明印章 · 頁首依紅字大小 · 套件 v0169 · 版本鎖 v0102)"
h = "\n".join(lines)
para = ("> **本輪(v0169)**:操作員 2026-11-01「U/I 子系統名稱還原為 VeritasReportNova · 成為 VRN 唯一系統」「印章 logo 透明去背無框無特效 · 以紅字大小為依據做 header 大小 logo 最佳化」。"
        "**Workbench v0104**(v0103 薄尾):畫面上 VRN-2 → VRN / VeritasReportNova(檔名 · 指令 · 收據 · 輸出冊資料不改)· 00 只讀互看列 VDF · VCGC · 本機沒有 VRN2_Logo.* 時用內建印章 "
        "VRN2_Logo_Seal_v0100.png(操作員附圖 · 本來就透明)· 主印框高 = 頁首文字區塊高(瀏覽器實量 · 44 ~ 120px · 小印垂右下)。**runtime v0160** · **啟動器 v0169** · **套件 v0169** · "
        "**RoundAll v0125** · **Handle-All v0117** · 版本鎖 **v0102**。桌機貼 v0168 那行 `[RED] boot SHA-256 mismatch` = AI 在對話裡手打的雜湊打錯;之後一律從檔案複製。"
        "CLAUDE.md / AGENTS.md 的四系統命名(政策 L123)是 VCGC 的冊,沒改。\n")
anchor = "> **本輪(v0168)**"
assert h.count(anchor) == 1
h = h.replace(anchor, para + anchor, 1)
row = ("| 0 | **(v0169)** PowerShell 7 先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)再貼 `vrn2_release_v0169/VRN2_HandleAll_v0117.md` 的最短一行 → auto 選 repair → "
       "Workbench v0104 · 標題 VeritasReportNova · 印章 · 收尾仍應是 REVIEW(VRN 0)| 貼回 |\n")
a8 = "| 0 | **(v0168)** PowerShell 7"
assert h.count(a8) == 1
h = h.replace(a8, row + a8, 1)
a9 = "**v0168(2026-11-01)**:"
assert h.count(a9) == 1
h = h.replace(a9, "**v0169(2026-11-01)**:Workbench v0104(VeritasReportNova · 印章 · 頁首)· 啟動器 v0169 · runtime v0160 · RoundAll v0125 · Handle-All v0117 · 版本鎖 v0102 · 收尾以桌機為準(REVIEW)。\n\n" + a9, 1)
(AI / "VRN2_Handover_v0170.md").write_text(h, encoding="utf-8", newline="\n")

v101 = json.loads((AI / "VRN2_FreezeLock_v0101.json").read_text(encoding="utf-8"))
base = "VeritasIntelligenceAnalytics/docs/handoff/ai/"
files = {k: v for k, v in v101["files"].items() if "/vrn2_release_v0168/" not in k}
for n in ("VRN2_HandleAll_v0117.md", "VRN2_HandleAll_v0117_boot.txt", "VRN2_RoundAll_v0125.py", "VRN2_Release_v0169.json", "VRN2_Closeout_v0169.zip"):
    files[base + "vrn2_release_v0169/" + n] = sha((OUT / n).read_bytes().replace(b"\r\n", b"\n"))
for k in files:
    assert (GIT / k).is_file(), k
    assert sha((GIT / k).read_bytes().replace(b"\r\n", b"\n")) == files[k], k
lock = dict(v101)
lock.update({"lock": "VRN2_FreezeLock_v0102", "supersedes": "VRN2_FreezeLock_v0101 (kept unchanged)", "display_name": "VeritasReportNova (VRN)",
             "unlocked_by": "操作員 2026-11-01 令「U/I 子系統名稱還原為 VeritasReportNova · 成為 VRN 唯一系統 · 印章 logo 透明去背無框無特效 · 以紅字大小為依據做 header 大小 logo 最佳化」= 這次 U/I 改動的解鎖;改完換上新版本再鎖",
             "main_commit": subprocess.run(["git", "-C", str(GIT), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip(),
             "active": dict(v101["active"], handle_all="v0117", roundall="v0125", package="VRN2_Closeout_v0169 (launcher v0169 · runtime v0160 · manager v0258 · Workbench v0104)", workbench="VRN2_Workbench_v0104 (VeritasReportNova · seal · page 00)"),
             "files": files,
             "check_status": "WORKBENCH_V0104_10_OK · V0103_15_OK · LAUNCHER_V0169_OK · ROUNDALL_V0125_89_OK · E2E_REPAIR_SANDBOX_V0104_RENDERED · BROWSER_SEAL_ALIGNED · PWSH_NOT_RUN",
             "check_message": "版本凍結,不是驗收。容器沒有 pwsh:PowerShell 一行沒有實跑(雜湊在 Python 端核過)。"})
(AI / "VRN2_FreezeLock_v0102.json").write_text(json.dumps(lock, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print("release folder", sorted(p.name for p in OUT.iterdir()))
print("lock v0102 files", len(files))
