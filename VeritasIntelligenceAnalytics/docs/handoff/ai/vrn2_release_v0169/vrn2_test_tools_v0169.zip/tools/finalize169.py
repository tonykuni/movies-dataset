"""v0169 收尾:驗證紀錄 · 交接 v0170(從 v0169 抄 · 只增)· 放進倉 vrn2_release_v0169 · logs / 工具 zip。桌機主控台的值不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v169"); rel = W / "release169"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    for a, b in ((str(W / "t169a"), "<sbx>"), (str(W), "<w>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        x = x.replace(a, b)
    return x


R = json.loads((rel / "VRN2_Release_v0169.json").read_text(encoding="utf-8"))
ra = [l for l in lines(W / "rall125_selftest_venv.log") if re.search(r"^\[PASS\] 89 |^\[FAIL\]|--selftest · ", l)]
ps = json.loads((W / "pscheck169.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny169.rc") if l.strip()]
pat = r"boot:|boot SHA|④ 自動選模式|④ 同意閘未開|已中止|① 套件 ·|v0259 轉置表|⑪ 獨立驗證 · 年度|===== 收尾|\[(VRN-2|人工|VCGC|資料源)\] \d"
e2e = {n: [short(l)[:220] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)][:14] for n in ("auto1", "auto2", "abort", "tamper")}
states = {}
for n in ("auto1", "auto2"):
    d = json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))
    states[n] = {"state": d["state"], "per_owner": d["per_owner"]}
R["results"] = {"roundall_v0125_selftest": ra, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "closeout_states": states,
                "merge_check": "owner_of + merge_same on the 12:31 rows (sandbox, read-only): the 「⑥f VIA 網路工具 DENY · 同意閘未開」 row and the step-⑥f row both → 人工 · merged into ONE 人工 item (was VRN-2)",
                "abort_prompt": "full mode + gate closed + piped 'A' → Handle-All stops before RoundAll with both shells' syntax printed · empty / non-interactive stdin → continues with the gate closed (previous behaviour) · the gate itself is never set by the script",
                "not_run": "the desktop itself (next: open the gates in the SAME PowerShell window with $env: syntax → auto = repair re-fetches consensus, ~10-15 min) · the operator's own --confirm"}
(rel / "VRN2_Release_v0169.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0169 驗證紀錄(2026-11-02 · ⑥f 同意閘列 → 人工 · 整輪遇閘未開先問中止 · 套件 v0168 不動 · RoundAll v0125 · Handle-All v0117)

## 1. 桌機 2026-11-02 12:31(v0116 整輪 3117 秒)——資料面已全部完成

| 項目 | 結果 |
|---|---|
| 年度數據 | 11,905 筆(6143 的 40 值補回 · v0259 轉置表再驗)· 剔除 2,508 · **缺項 0** |
| 驗證 | 冪等閘 GREEN · ⑪ 獨立驗證錯值 0(TRANSALIGNED 190 → 230)· 完成判定 紅 0 · 四項全綠 52 份 |
| 增量庫 | FinancialData 累計 11,953 · MOPS 列乾淨 · TP(ADJ) 同步還原 5 |
| 這輪唯一退步 | Combined 共識欄 52 列全空 —— ⑥f 被 DENY(見下)· 閘開 + repair 重抓即補回(增量庫兩輪都留 · 查詢用最新)|

## 2. 收尾 OPEN「VRN-2 1 項」是什麼

- 操作員在 **PowerShell 視窗**貼了 **cmd 寫法**的 `set "VIA_SCRAPE_CONSENT=YES"` → 沒設成(③b 已印黃字提醒)→ ⑥f 共識整輪被 VIA 網路工具 DENY(同意閘未開 · 引擎不代設 · 不換道)。
- 收尾頁那一列「⑥f VIA 網路工具 DENY · 同意閘未開(操作員決定)」在負責方規則**沒有分支** → 落到預設 VRN-2;它與 ⑥f 共識列同根,合併取最重負責方 → 整個共識項被標成 VRN-2。
- 同意閘是操作員的環境變數,從來不是 VRN-2 要修的程式 → 標籤錯。

## 3. 修正

- **RoundAll v0125**:⑥f 列 detail 帶「同意閘未開」→ **人工**(提示附 PowerShell 與 cmd 兩種設法 · 開了再跑 auto = repair 會重抓共識補回 Combined);帶「合規 DENY」→ VCGC。其他規則不變。
- **Handle-All v0117**:整輪 + 同意閘未開 → 先停下來問(`A` = 中止 · 自己設好再重貼;Enter / 非互動 = 照跑 · 閘保持關)。**腳本永遠不代設同意閘**(操作員 2026-10-31 規則)。
- 套件 v0168 不動(雜湊照釘)· 啟動器 / 管理器都不動。

## 4. 測試

| 項目 | 結果 |
|---|---|
| RoundAll v0125 自測 | %s |
| 12:31 那兩列重判(沙盒 · 只讀) | 兩列都 → 人工 · 合併成一項人工(以前 VRN-2)|
| PowerShell 剖析 | %s |
| e2e(最短一行 · 沙盒含三份原文) | %s · auto 整輪(閘關 · 非互動 stdin 預設照跑)→ repair → VRN2_MODE=full + 管入 A → 「已中止」且沒跑 RoundAll → 竄改開機檔不執行 · 收尾狀態 %s |

## 5. 一行指令(PowerShell 視窗 · 先開同意閘)

```powershell
$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'
```

再貼最短一行(%d 字元 · 開機檔 `vrn2_release_v0169/VRN2_HandleAll_v0117_boot.txt` SHA-256 `%s` · Handle-All 一行 `%s` · RoundAll v0125 `%s` · 套件 `%s` 不動)。
auto:收據已是 v0168 → repair(重抓 ⑥f 共識 · 約 10 ~ 15 分鐘)→ 收尾應 REVIEW(VRN-2 0)· 人工只剩 MQ-1560 四點。

## 6. VRN-2 收尾的終點定義(給操作員)

PASS 要所有外部缺口都消失,做不到(⑥e VDF rc 2 PARTIAL 與 AAPL 非台股是來源的事)。VRN-2 側的終點 = 收尾頁 **VRN-2 0 · VCGC 0**,
人工項由操作員 `--confirm` 記錄後 → **DATA_GAP(只剩資料源)**。SSOT 517 件待 VCGC 核號(四系統對等 · VRN-2 只讀等待)。

## 7. 沒做 / 待辦

- 人工確認只有操作員親手打 `--confirm`(MQ-1560 四點 · 上輪代碼 H-fd2ea35f · 以收尾頁列的為準)。
- 3014TT 四點(第 2 點從句中開始 · 第 1 / 3 點重複)· MQ-1560 OCR 字詞錯(chi players)→ 要改摘要器 + 整輪,操作員點頭才做。
""" % (" · ".join(x[:90] for x in ra[-1:]), pparse, " · ".join(rc), json.dumps(states, ensure_ascii=False),
       H["tiny_line_chars"], H["boot_line_sha256"][:12], H["line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12])
(rel / "VRN2_Verification_v0169.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0169.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0168 + VRN2_RoundAll_v0124 + VRN2_HandleAll_v0116 · 2026-11-02(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0168 + VRN2_RoundAll_v0125 + VRN2_HandleAll_v0117 · 2026-11-02(桌機 v0168 整輪資料面全完成 · "
        "收尾的「VRN-2 1 項」= ⑥f 同意閘列標籤錯 → 人工 · 整輪遇閘未開先問中止 · 套件 v0168 不動)")
src = "\n".join(L)
once("> **本輪(v0168)**",
     "> **本輪(v0169)**:桌機 12:31 跑 v0116 整輪(3117 秒)→ **資料面全完成**:6143 補回 40 值(11,905 筆 · 剔除 2,508)· 缺項 0 · 冪等 GREEN · ⑪ 錯值 0 · 完成判定 紅 0。"
     "這輪操作員在 PowerShell 視窗貼了 cmd 的 set → VIA_SCRAPE_CONSENT 沒設成 → ⑥f 被 DENY → Combined 共識欄空(閘開 + repair 重抓即補回)。收尾 OPEN「VRN-2 1 項」="
     "「⑥f VIA 網路工具 DENY」列在負責方規則沒有分支 → 預設 VRN-2 · 合併後整個共識項被帶成 VRN-2 —— 標籤錯。**RoundAll v0125**(⑥f 列「同意閘未開」→ 人工 ·「合規 DENY」→ VCGC)· "
     "**Handle-All v0117**(整輪 + 閘未開先問:A = 中止自己設好再重貼 · 腳本永不代設 · 最短一行 %d 字元 · cmd 一行 %d 字元)· 套件 v0168 不動。\n"
     "> **本輪(v0168)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
r168 = json.loads((REPO / "vrn2_release_v0168/VRN2_Release_v0168.json").read_text(encoding="utf-8"))
once("| **VRN2_HandleAll_v0116.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0116** | `vrn2_release_v0168` |",
     "| **VRN2_HandleAll_v0117.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0117** | `vrn2_release_v0169` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0125 · 整輪 + 閘未開先問中止)|\n"
     "| **VRN2_RoundAll_v0125.py**(發行夾 · 一支入口 · 不在套件內)| **v0125** | `vrn2_release_v0169` | `%s` | **新**(⑥f 同意閘列 → 人工 · 自測 91 項 · 套件 v0168 照釘)|\n"
     "| **VRN2_HandleAll_v0116.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0116** | `vrn2_release_v0168` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0124.py**(發行夾 · 一支入口 · 不在套件內)| **v0124** | `vrn2_release_v0168` | `%s` | **新**(" % r168["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0124.py**(發行夾 · 一支入口 · 不在套件內)| **v0124** | `vrn2_release_v0168` | `%s` | 被 v0125 取代(套件同為 v0168)· (" % r168["roundall"]["sha256"][:12])
once("| 0 | **(v0168)**",
     "| 0 | **(v0169)** PowerShell 視窗先貼 `$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'`(cmd 視窗:兩行 set · 同意閘是操作員決定)再貼 "
     "`vrn2_release_v0169/VRN2_HandleAll_v0117.md` 的最短一行 → auto = repair(重抓共識 · 約 10 ~ 15 分鐘)→ 收尾應 REVIEW(VRN-2 0)· MQ-1560 四點看過原圖後操作員自己打 `--confirm` | 貼回 / 人工 |\n"
     "| 0 | **(v0168)**")
once("**v0168(2026-11-02)**:", "**v0169(2026-11-02)**:桌機 v0168 整輪資料面全完成(6143 補回 · 11,905 筆 · 錯值 0 · 缺項 0)→ 收尾的 1 項 = ⑥f 同意閘列標籤錯 → RoundAll v0125(人工 / VCGC 分支)· Handle-All v0117(整輪 + 閘未開先問中止)· 套件 v0168 不動。\n\n**v0168(2026-11-02)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0169)** **收尾頁每一種列都要有負責方分支**:新加一種收尾列(f(...))時,owner_of 要同時加分支並寫自測;否則落到預設 VRN-2,而且合併(merge_same 取最重負責方)會把整項帶成 VRN-2。"
     "同意閘未開永遠是人工(操作員決定),合規 DENY 永遠是 VCGC。\n"
     "- **(v0169)** **同意閘永不代設**:Handle-All 只能「提示 + 問要不要中止」;設定動作一定由操作員自己貼(PowerShell 是 $env: 寫法 · cmd 是 set 寫法 · 兩種視窗語法不通用)。\n\n")
(REPO / "VRN2_Handover_v0170.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0169"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0125.py", "VRN2_RoundAll_v0125.md", "VRN2_HandleAll_v0117.md", "VRN2_HandleAll_v0117_boot.txt", "VRN2_Release_v0169.json", "VRN2_Verification_v0169.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 2, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t169a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0169.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall125_selftest_venv.log", "pscheck169.log", "tiny169.rc", "seed169.log", "confirm_list.log")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0169.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall125.py", "build169.py", "finalize169.py", "e2e169.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0170", src.count("\n"))
