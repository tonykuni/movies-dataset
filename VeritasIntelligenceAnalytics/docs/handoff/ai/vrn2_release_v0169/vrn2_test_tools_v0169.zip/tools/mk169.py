"""v0169(冪等):Workbench v0104(名稱 VeritasReportNova · 內建印章 · 頁首依紅字大小)→ runtime v0160 = v0159(全部成員不動)+ Workbench v0104 + VRN2_Logo_Seal_v0100.png
→ 啟動器 v0169 → 套件 v0169(其他成員跟 v0168 逐位元組相同)→ RoundAll v0125(套件 v0169 · Workbench 鏈 + 印章只增補放 · 收尾頁沒有 v0104 標記 → 重渲染)
→ Handle-All v0117 → 開機檔 · 最短一行 · cmd 一行 → md · 發行清單。底 = 倉裡的 vrn2_release_v0168(不動)。"""
import base64, hashlib, io, json, re, shutil, sys, zipfile
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-movies-dataset/484f6e73-0cd5-53cb-a8dd-d4ee89d5500c/scratchpad")
W = S / "v169"; NEW, PKG, REL = W / "new", W / "pkg169", W / "release169"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
BR = "claude/vrn2-closeout-authorization-y4ixl7"
sys.path.insert(0, str(S / "t167" / "tools"))
from join_ps import join  # noqa: E402
for d in (PKG, REL):
    shutil.rmtree(d, ignore_errors=True); d.mkdir(parents=True)
DT = (2026, 11, 1, 0, 0, 0)
sha = lambda b: hashlib.sha256(b).hexdigest()  # noqa: E731


def zwrite(path, members, prefix=""):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            zi = zipfile.ZipInfo(prefix + n, date_time=DT); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])


r168 = json.loads((REPO / "vrn2_release_v0168/VRN2_Release_v0168.json").read_text(encoding="utf-8"))
zp = REPO / "vrn2_release_v0168/VRN2_Closeout_v0168.zip"
assert sha(zp.read_bytes()) == r168["package"]["sha256"]
with zipfile.ZipFile(zp) as z:
    p168 = {n.split("/", 1)[1]: z.read(n) for n in z.namelist() if not n.endswith("/")}
m168 = {e["path"]: e["sha256"] for e in json.loads(p168["PACKAGE_SHA256.json"])["files"]}
for n, h in m168.items():
    assert sha(p168[n]) == h, n

# runtime v0160
om = json.loads(p168["VRN2_Runtime_v0159.json"])
assert sha(p168["VRN2_Runtime_v0159.zip"]) == om["zip_sha256"]
with zipfile.ZipFile(io.BytesIO(p168["VRN2_Runtime_v0159.zip"])) as z:
    members = {e["path"]: z.read(e["path"]) for e in om["files"]}
for e in om["files"]:
    assert sha(members[e["path"]]) == e["sha256"], e["path"]
n_old = len(members)
NEWM = ["VRN2_Logo_Seal_v0100.png", "VRN2_Workbench_v0104.py"]
for n in NEWM:
    assert n not in members, n
    members[n] = (NEW / n).read_bytes()
assert "VRN2_Workbench_v0103.py" in members
rz = PKG / "VRN2_Runtime_v0160.zip"; zwrite(rz, members)
rman = {"system": "VRN-2", "version": "v0160", "zip_sha256": sha(rz.read_bytes()), "based_on": "VRN2_Runtime_v0159.zip " + om["zip_sha256"], "retained_members": n_old, "new_members": NEWM,
        "files": [{"path": n, "sha256": sha(members[n])} for n in sorted(members)]}
(PKG / "VRN2_Runtime_v0160.json").write_text(json.dumps(rman, ensure_ascii=False, indent=1), encoding="utf-8")

# 啟動器 v0169
s = p168["ActivateVRN-2_v0168.py"].decode("utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0168: v0166 entry + Workbench VRN2_Workbench_v0103', '''"""VRN-2 v0169: v0168 entry + Workbench VRN2_Workbench_v0104. Operator 2026-11-01: "the subsystem name shown on the HTML U/I goes back to
VeritasReportNova · it becomes the only VRN system" and "the seal logo: transparent, no frame, no effects · size the header and the logo from the
red seal against the header text".
 - Display names only: VRN-2 → VRN / VeritasReportNova on screen (file names, commands, receipts and the embedded book data stay byte-identical).
 - Page 00 read-only matrix lists VDF and VCGC only (VRN is the only VRN system); the left-panel gates are unchanged.
 - Built-in seal VRN2_Logo_Seal_v0100.png (operator's image as given: already transparent, cropped to the ink) when no local VRN2_Logo.* exists;
   the main seal box is sized to the header text block (measured in the browser · 44 – 120 px) and the small seal hangs below it.
 Runtime v0160 = runtime v0159 (all members byte-identical) + VRN2_Workbench_v0104 + VRN2_Logo_Seal_v0100.png. Receipt VRN2_Closeout_v0169.json.

VRN-2 v0168: v0166 entry + Workbench VRN2_Workbench_v0103''')
rep('VERSION = "ActivateVRN-2 v0168"', 'VERSION = "ActivateVRN-2 v0169"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0159.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0160.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0159.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0160.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0168.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0169.json"')
rep('WORKBENCH = "VRN2_Workbench_v0103.py"   # v0168:', 'WORKBENCH = "VRN2_Workbench_v0104.py"   # v0169: VeritasReportNova names · built-in seal · header sized from the seal (over v0103) · v0168:')
rep('''    assert WORKBENCH == "VRN2_Workbench_v0103.py"
''', '''    w104 = selftest_source("VRN2_Workbench_v0104.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0104"' in w104 and 'PRIOR_NAME = "VRN2_Workbench_v0103.py"' in w104 and "def rename_display(" in w104 and "SEAL_MAIN_FRAC" in w104
    assert WORKBENCH == "VRN2_Workbench_v0104.py"
''')
rep('''        assert wbs[-1] == "VRN2_Workbench_v0103.py" and''', '''        assert "VRN2_Logo_Seal_v0100.png" in bundle.namelist() and wbs[-1] == "VRN2_Workbench_v0104.py" and "VRN2_Workbench_v0103.py" in wbs and''')
rep('''    print("[PASS] v0168: Workbench v0103 is the active Workbench''', '''    print("[PASS] v0169: Workbench v0104 is the active Workbench (VeritasReportNova names on screen · data untouched · page 00 read-only VDF / VCGC · built-in transparent seal sized to the header text) · v0103 kept as PRIOR")
    print("[PASS] v0168: Workbench v0103''')
rep('return lamp, detail + " · launcher v0168"', 'return lamp, detail + " · launcher v0169"')
rep('exact ship v0159 (launcher v0168 · Workbench v0103 page 00 summary', 'exact ship v0160 (launcher v0169 · Workbench v0104 VeritasReportNova + seal · v0103 page 00 summary')
rep('print("NEXT: [%s] VRN-2 v0168 · rc %s', 'print("NEXT: [%s] VRN-2 v0169 · rc %s')
(PKG / "ActivateVRN-2_v0169.py").write_text(s, encoding="utf-8", newline="\n")
launcher = s.encode("utf-8")

# 套件 v0169
keep = ["ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: p168[n] for n in keep}
files["ActivateVRN-2_v0169.py"] = launcher
files["VRN2_Runtime_v0160.zip"] = rz.read_bytes()
files["VRN2_Runtime_v0160.json"] = (PKG / "VRN2_Runtime_v0160.json").read_bytes()
files["README.txt"] = ("VRN2_Closeout_v0169 — VeritasReportNova (VRN) closeout package (2026-11-01 · Workbench v0104)\n\n"
  "Entry: python ActivateVRN-2_v0169.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0125.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0117.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0160.zip = v0159 (all members byte-identical) + VRN2_Workbench_v0104 + VRN2_Logo_Seal_v0100.png.\n\n"
  "v0169: screen names VeritasReportNova / VRN (files, commands, receipts and book data unchanged) · page 00 read-only VDF / VCGC · built-in\n"
  " transparent seal (no frame, no effects) whose main box matches the header text block. v0168: page 00 system summary. Books unchanged.\n"
  "Verification: see VRN2_Verification_v0169.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0169.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0169", "files": [{"path": n, "sha256": sha(files[n])} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = REL / "VRN2_Closeout_v0169.zip"; zwrite(zpr, files, "VRN2_Closeout_v0169/")
want = sha(zpr.read_bytes())
for n in keep:
    assert sha(files[n]) == m168[n], n

# RoundAll v0125
src = (REPO / "vrn2_release_v0168/VRN2_RoundAll_v0124.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0124'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0124 — ', '"""VRN2_RoundAll v0125 — ', 1)
at = doc.index("v0124(")
doc = doc[:at] + '''v0125(操作員 2026-11-01:「U/I 上的子系統名稱還原為 VeritasReportNova · 成為 VRN 唯一系統 · 印章 logo 透明去背無框無特效 · 以紅字大小為依據做 header 大小 logo 最佳化」):
  · 套件 v0169(啟動器 v0169 · runtime v0160 = v0159 全部成員不動 + VRN2_Workbench_v0104 + 內建印章 VRN2_Logo_Seal_v0100.png)· 輸出冊不變。
  · ⑤ Workbench 鏈多兩檔(v0104 + 印章)· 收尾頁沒有 v0104 標記 → 重渲染(repair 幾分鐘)。③ 自測改跑 Workbench v0104。自測 91 項(v0124 的 90 項 + 89)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0124.py", "用法:python VRN2_RoundAll_v0125.py")
s = head + doc + body
rep('VERSION = "v0124"', 'VERSION = "v0125"')
rep('PACKAGE = "VRN2_Closeout_v0168"', 'PACKAGE = "VRN2_Closeout_v0169"')
s = re.sub(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', 'PACKAGE_SHA256 = "%s"' % want, s, count=1)
rep('# 建置時填入 VRN2_Closeout_v0168.zip 的 SHA-256', '# 建置時填入 VRN2_Closeout_v0169.zip 的 SHA-256')
rep('RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168"', 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169"')
rep('RELEASE_JSON = "VRN2_Release_v0168.json"', 'RELEASE_JSON = "VRN2_Release_v0169.json"')
rep('LAUNCHER = "ActivateVRN-2_v0168.py"', 'LAUNCHER = "ActivateVRN-2_v0169.py"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0159.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0160.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0159.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0160.json"')
rep('RECEIPT = "VRN2_Closeout_v0168.json"', 'RECEIPT = "VRN2_Closeout_v0169.json"')
rep('SELFTESTS = (("VRN2_Workbench_v0103.py", 600),', 'SELFTESTS = (("VRN2_Workbench_v0104.py", 600),')
rep('PASTE_FILES = ("VRN2_Closeout_v0168.json", "VRN2_Closeout_v0168.before_roundall.json",', 'PASTE_FILES = ("VRN2_Closeout_v0169.json", "VRN2_Closeout_v0169.before_roundall.json", "VRN2_Closeout_v0168.json", "VRN2_Closeout_v0168.before_roundall.json",')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0124.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0124.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0125.py"', n_dl)
rep('"VRN2_RoundAll_v0124.py" in html_', '"VRN2_RoundAll_v0125.py" in html_')
rep("· v0123 起 89 項 · v0124 起 90 項。", "· v0123 起 89 項 · v0124 起 90 項 · v0125 起 91 項。")
rep('WORKBENCH_CHAIN = ("VRN2_Workbench_Assets_v0100.zip", "VRN2_Workbench_v0100.py", "VRN2_Workbench_v0101.py", "VRN2_Workbench_v0102.py", "VRN2_Workbench_v0103.py")',
    'WORKBENCH_CHAIN = ("VRN2_Workbench_Assets_v0100.zip", "VRN2_Logo_Seal_v0100.png", "VRN2_Workbench_v0100.py", "VRN2_Workbench_v0101.py", "VRN2_Workbench_v0102.py", "VRN2_Workbench_v0103.py", "VRN2_Workbench_v0104.py")')
rep('WORKBENCH_TAG = "<!-- VRN2_Workbench v0103 over v0102 -->"', 'WORKBENCH_TAG = "<!-- VRN2_Workbench v0104 over v0103 -->"')
rep('''            w88.write_text("<title>VRN-2 Workbench</title><!-- VRN2_Workbench v0102 over v0101 -->", encoding="utf-8")''',
    '''            w88.write_text("<title>VRN-2 Workbench</title><!-- VRN2_Workbench v0103 over v0102 -->", encoding="utf-8")''')
rep('''            p_old == ["workbench"] and p_new == [] and WORKBENCH_CHAIN[-1] == "VRN2_Workbench_v0103.py" and len(WORKBENCH_CHAIN) == 5 and PACKAGE == "VRN2_Closeout_v0168"
            and SELFTESTS[0] == ("VRN2_Workbench_v0103.py", 600) and _head_text(Path(t88) / "none.html") == "")''',
    '''            p_old == ["workbench"] and p_new == [] and "VRN2_Workbench_v0103.py" in WORKBENCH_CHAIN and len(WORKBENCH_CHAIN) >= 5 and PACKAGE >= "VRN2_Closeout_v0168"
            and SELFTESTS[0][0] >= "VRN2_Workbench_v0103.py" and _head_text(Path(t88) / "none.html") == "")
        chk("89 v0125:Workbench 鏈多內建印章 + v0104(只增補放 · 先後照舊)· 收尾頁還是 v0103 渲染的 → 重渲染 · 套件 v0169 · 自測跑 v0104",
            WORKBENCH_CHAIN[-1] == "VRN2_Workbench_v0104.py" and "VRN2_Logo_Seal_v0100.png" in WORKBENCH_CHAIN and WORKBENCH_TAG.endswith("v0104 over v0103 -->")
            and PACKAGE == "VRN2_Closeout_v0169" and SELFTESTS[0] == ("VRN2_Workbench_v0104.py", 600) and RUNTIME_ZIP == "VRN2_Runtime_v0160.zip")''')
(REL / "VRN2_RoundAll_v0125.py").write_text(s, encoding="utf-8", newline="\n")
ra_sha = sha(s.encode("utf-8"))

# Handle-All v0117
ha = (REPO / "vrn2_release_v0168/VRN2_HandleAll_v0116.md").read_text(encoding="utf-8")
ha = re.search(r"(?s)## 可讀版 · Handle-All\n\n```powershell\n(.*?)\n```", ha).group(1) + "\n"
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)
assert old_ra == r168["roundall"]["sha256"]


def rh(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rh("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169'")
rh("$F = 'VRN2_RoundAll_v0124.py'", "$F = 'VRN2_RoundAll_v0125.py'")
rh("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rh("Handle-All v0116", "Handle-All v0117", ha.count("Handle-All v0116"))
rh("套件 v0168 裝在新夾 VRN2_Closeout_v0168", "套件 v0169 裝在新夾 VRN2_Closeout_v0169")
rh("取套件 v0168", "取套件 v0169", 2)
rh("跑啟動器 v0168(Workbench v0103 · ", "跑啟動器 v0169(Workbench v0104 VeritasReportNova · ")
rh("套件 v0168 的 IndependentVerifier", "套件 v0169 的 IndependentVerifier")
rh("[VRN-2] Handle-All", "[VRN] Handle-All")
assert "v0124" not in ha and "v0116" not in ha
ha_line = join(ha); ha_sha = sha(ha_line.encode("utf-8"))
(REL / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n")
bt = (REPO / "vrn2_release_v0168/VRN2_HandleAll_v0116.md").read_text(encoding="utf-8")
bt = re.search(r"(?s)## 可讀版 · 開機行\n\n```powershell\n(.*?)\n```", bt).group(1) + "\n"
assert join(bt) == (REPO / "vrn2_release_v0168/VRN2_HandleAll_v0116_boot.txt").read_text(encoding="ascii").strip()
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0168", "vrn2_release_v0169"), ("VRN2_HandleAll_v0116.md", "VRN2_HandleAll_v0117.md"), ("Handle-All v0116 SHA-256 OK", "Handle-All v0117 SHA-256 OK"), ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = sha(bt_line.encode("ascii"))
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800 and sha(bytes(ord(c) & 0xFF for c in bt_line)) == bt_sha
(REL / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n")
(REL / "VRN2_HandleAll_v0117_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin %s;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169/VRN2_HandleAll_v0117_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % (BR, bt_sha)
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(REL / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n"); (REL / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")
md = """# VeritasReportNova(VRN)· 一行處理全部 · VRN2_HandleAll_v0117(2026-11-01 · Workbench v0104 · 套件 v0169 · RoundAll v0125)

操作員 2026-11-01:U/I 上的子系統名稱還原為 **VeritasReportNova**(VRN 唯一系統)· 印章 logo 透明去背無框無特效 · 以紅字大小為依據調頁首與 logo。

| 項目 | 現在 |
|---|---|
| Workbench v0104 | 畫面名稱 VeritasReportNova / VRN(檔名 · 指令 · 收據 · 輸出冊資料不改)· 00 只讀互看列 VDF · VCGC · 內建印章(透明 · 無框無特效)· 主印框高 = 頁首文字區塊高(實量)· 小印垂在右下 |
| 輸出冊 | 不變 |
| 自動選模式 | 收據已是 v0166 → **repair**(幾分鐘 · ⑤ 補放 Workbench 鏈與印章並重渲染)|
| 套件 | `vrn2_release_v0169/VRN2_Closeout_v0169.zip`(SHA-256 `%s` · 啟動器 v0169 · runtime v0160)|
| 一支 Python | `VRN2_RoundAll_v0125.py`(SHA-256 `%s` · 自測 91 項)|
| 取件分支 | `%s`(退路 main)|

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0125.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0125.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0117 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0125 `%s`)。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], BR, len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
assert re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md) == [ha_line]
(REL / "VRN2_HandleAll_v0117.md").write_text(md, encoding="utf-8", newline="\n")
(REL / "VRN2_RoundAll_v0125.md").write_text("""# VeritasReportNova 一支 Python · VRN2_RoundAll_v0125.py(套件 v0169 · Workbench v0104)

`VRN2_RoundAll_v0125.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0124 +:套件 `vrn2_release_v0169/VRN2_Closeout_v0169.zip`(SHA-256 `%s`)·
⑤ Workbench 鏈多內建印章與 v0104(只增補放)· 收尾頁沒有 v0104 標記 → 重渲染 · ③ 自測跑 v0104 · 取件分支 `%s`(退路 main)。自測 91 項。
""" % (ra_sha[:12], want[:12], BR), encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "display_name": "VeritasReportNova (VRN)", "independent": True,
        "release": "ActivateVRN-2 v0169 (Workbench v0104 · runtime v0160) + VRN2_RoundAll_v0125 + VRN2_HandleAll_v0117", "date": "2026-11-01",
        "trigger": "操作員 2026-11-01:U/I 子系統名稱還原為 VeritasReportNova(VRN 唯一系統)· 印章 logo 透明去背無框無特效 · 以紅字大小為依據做 header 大小 logo 最佳化",
        "base_package": {"name": "VRN2_Closeout_v0168", "retained": "runtime v0159's %d members byte-identical inside runtime v0160; package members except launcher / runtime byte-identical to v0168" % n_old},
        "fixes": {"Workbench_v0104": "screen names VRN-2 → VRN / VeritasReportNova (files, commands, receipts, window.VRN2_DATA untouched) · page 00 read-only VDF / VCGC · built-in seal (operator image, already transparent, cropped to the ink) when no local logo · main seal box = header text block height (browser-measured · 44 – 120 px)",
                  "launcher_v0169": "WORKBENCH v0104 · runtime v0160 · receipt VRN2_Closeout_v0169.json · selftest block v0169",
                  "RoundAll_v0125": "package v0169 · Workbench chain + seal (only-add) · re-render when the page lacks the v0104 marker · selftest runs Workbench v0104",
                  "HandleAll_v0117": "points at RoundAll v0125 (vrn2_release_v0169) · branch %s then main" % BR},
        "freeze": "VRN2_FreezeLock_v0101 → v0102 (operator order 2026-11-01)",
        "components": [{"path": n, "sha256": sha(files[n]), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rman[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"changed": True},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0124.py", "sha256": r168["roundall"]["sha256"], "status": "superseded 2026-11-01; kept in vrn2_release_v0168"}],
        "roundall": {"name": "VRN2_RoundAll_v0125.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0125.md"},
        "handleall": {"name": "VRN2_HandleAll_v0117.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0117_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line), "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line), "branch": BR},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0169/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0169.py", "sha256": sha(launcher)}, "results": {"status": "see VRN2_Verification_v0169.md"}}
(REL / "VRN2_Release_v0169.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("runtime v0160", len(members), rman["zip_sha256"][:12], "· launcher", sha(launcher)[:12], "· package", want[:12], "· roundall", ra_sha[:12], "· handle-all", ha_sha[:12], "· boot", bt_sha[:12], "· tiny", len(tiny))
