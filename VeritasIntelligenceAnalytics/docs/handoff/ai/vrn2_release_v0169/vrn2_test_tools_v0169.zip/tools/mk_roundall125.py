"""VRN2_RoundAll_v0125.py = v0124(倉裡 vrn2_release_v0168)+ 收尾頁負責方:⑥f「VIA 網路工具 DENY」那一列(同意閘未開 → 人工 · 合規 DENY → VCGC)。
套件仍是 v0168(雜湊照釘)。桌機 2026-11-02 12:31 整輪:資料面全完成(6143 補回 40 · 11905 筆 · 錯值 0 · 缺項 0),
收尾 OPEN「VRN-2 1 項」是這一列落到預設負責方、合併後把整個共識項帶成 VRN-2。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v169")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0168/VRN2_RoundAll_v0124.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0124')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0124 — ', '"""VRN2_RoundAll v0125 — ', 1)
at = doc.index("v0124(")
doc = doc[:at] + '''v0125(桌機 2026-11-02 12:31 · Handle-All v0116 整輪 3117 秒 · 管理器 v0259):資料面全完成 —— 6143 補回 40 值(年度 11905 · 剔除 2508 ·
  缺項 0 · 冪等 GREEN · ⑪ 錯值 0 · TRANSALIGNED 230)。收尾 OPEN「VRN-2 1 項」是標籤錯:
  · 這輪操作員在 PowerShell 視窗貼了 cmd 寫法的 set,VIA_SCRAPE_CONSENT 沒設成 → ⑥f 共識被 VIA 網路工具 DENY(同意閘未開 · 引擎不代設 · 不換道)
    → Combined 共識欄留空。收尾頁的「⑥f VIA 網路工具 DENY」那一列在負責方規則沒有分支 → 落到預設 VRN-2;合併(⑥f 共識同根)時 VRN-2 最重 →
    整個共識項被標成 VRN-2。同意閘是操作員的決定,從來不是 VRN-2 要修的程式。
  · v0125:⑥f 列 detail 帶「同意閘未開」→ 人工(附 PowerShell 與 cmd 兩種設法 · 開了再跑 auto = repair 會重抓共識補回 Combined)·
    帶「合規 DENY」→ VCGC。負責方其他規則不變 · 套件照舊 v0168(雜湊照釘)。
  · 自測 91 項(v0124 的 90 項 + 89)。共用 MarketFetch 與 VDF 引擎照舊只讀不改。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0124.py", "用法:python VRN2_RoundAll_v0125.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0124"', 'VERSION = "v0125"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0124.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0124.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0125.py"', n_dl)
rep('"VRN2_RoundAll_v0124.py" in html_', '"VRN2_RoundAll_v0125.py" in html_')
rep("v0123 起 89 項 · v0124 起 90 項。", "v0123 起 89 項 · v0124 起 90 項 · v0125 起 91 項。")
rep('("VRN_SystemManager_v0258.py", 1800) not in SELFTESTS and VERSION == "v0124"', '("VRN_SystemManager_v0258.py", 1800) not in SELFTESTS and VERSION >= "v0124"')
assert 'PACKAGE = "VRN2_Closeout_v0168"' in s and re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s) and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168"' in s
rep('''    if "⑥f" in step:
        if "Yahoo 代號" in step:''', '''    if "⑥f" in step and "同意閘未開" in detail:                             # v0125 ⑥f 的 DENY 說明列沒有對到共識字樣 → 以前落到預設 VRN-2(桌機 12:31 整輪 · 合併後整項被標 VRN-2)
        return "人工", ("同意閘是操作員的環境變數 · PowerShell 視窗貼 $env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'"
                        "(cmd 視窗:set VIA_NET_CONSENT=YES 與 set VIA_SCRAPE_CONSENT=YES)· 開了再跑一次(auto = repair)會重抓共識補回 Combined 共識欄 · VRN-2 不代設 · 不換道直連")
    if "⑥f" in step and "合規 DENY" in detail:
        return "VCGC", "VIA 網路工具合規 DENY → 放不放行是 VCGC 的決定 · 不繞道"
    if "⑥f" in step:
        if "Yahoo 代號" in step:''')
rep('''        chk("88 v0124:''', '''        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY", "detail": "VIA_NET_DENY: VIA 網路工具同意閘未開(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT · 操作員決定 · 引擎不代設 · 不換道直連) · 同意閘未開(操作員決定)"}
        o89 = owner_of(r89, {})
        o89b = owner_of({"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY", "detail": "VIA_NET_DENY: robots 不允許 · 合規 DENY(VCGC 決定)"}, {})
        chk("89 v0125:⑥f「VIA 網路工具 DENY · 同意閘未開」列 → 人工(操作員決定 · 兩種視窗的設法 · repair 會補回共識 · 桌機 12:31 被算成 VRN-2 1 項)· 根同 ⑥f 共識(合併後整項人工)· 合規 DENY → VCGC",
            o89[0] == "人工" and "$env:VIA_NET_CONSENT" in o89[1] and "set VIA_NET_CONSENT=YES" in o89[1] and "repair" in o89[1]
            and closeout_root(dict(r89, owner="人工"), {}) == "⑥f 共識" and o89b[0] == "VCGC")
        chk("88 v0124:''')
(W / "new").mkdir(exist_ok=True)
out = W / "new/VRN2_RoundAll_v0125.py"
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0125 lines", s.count("\n"))
