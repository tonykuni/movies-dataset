VRN2_Closeout_v0169 — VeritasReportNova (VRN) closeout package (2026-11-01 · Workbench v0104)

Entry: python ActivateVRN-2_v0169.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0125.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0117.md (same release folder).
Runtime: VRN2_Runtime_v0160.zip = v0159 (all members byte-identical) + VRN2_Workbench_v0104 + VRN2_Logo_Seal_v0100.png.

v0169: screen names VeritasReportNova / VRN (files, commands, receipts and book data unchanged) · page 00 read-only VDF / VCGC · built-in
 transparent seal (no frame, no effects) whose main box matches the header text block. v0168: page 00 system summary. Books unchanged.
Verification: see VRN2_Verification_v0169.md. Hashes: PACKAGE_SHA256.json.
