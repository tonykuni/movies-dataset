"""verify_outputs.verify_subcol 反向測試:把 v0234 開發中真的出過的三種錯放回輸出 → 驗證器必須抓到(SUBFAIL)。
用法:python subcol_mutation_test.py <output 夾> <PDF 夾>"""
import copy
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import verify_outputs as V  # noqa: E402

od, pdfdir = Path(sys.argv[1]), sys.argv[2]
fin = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
sub = [x for x in fin if x.get("SUBCOL")]
ok = True


def run(name, rows, want_bad):
    global ok
    r = V.verify_subcol(rows, pdfdir)
    bad = [x for x in r if x["_V"] == "SUBFAIL"]
    hit = bool(bad) if want_bad else not bad
    ok &= hit
    print("  [%s] %s → SUBFAIL %d 筆 %s" % ("OK" if hit else "FAIL", name, len(bad), (bad[0]["_N"][:120] if bad else "")))


run("原樣(v0234 輸出)", sub, False)
# ① 中點分組錯(貿聯 2027F 差異(%) 3.2 被歸到 2028F → 2028F 出現兩個差異(%))
m = copy.deepcopy(sub)
for x in m:
    if x["FILENAME"].startswith("凱基投顧_3665") and x["ITEM"] == "營收":
        if x["PERIOD"] == "2027F" and x["SUBCOL"] == "差異(%)":
            x["PERIOD"], x["SUBCOL"] = "2028F", "差異(%) #1"
        elif x["PERIOD"] == "2028F" and x["SUBCOL"] == "差異(%)":
            x["SUBCOL"] = "差異(%) #2"
run("① 中點分組錯(2027F 的值歸到 2028F)", m, True)
# ② 同表下半段季度(2Q26E …)的值被標成年度期間
m = copy.deepcopy(sub)
q = {"2026E": ("1.67", "2.26", "35.0%"), "2027E": ("2.53", "3.23", "27.6%"), "2028E": ("3.23", "4.01", "24.0%")}
for x in m:
    if x["FILENAME"].startswith("GS-6415") and x["TABLE"] == "P5·F·01·TB" and x["ITEM"].startswith("EPS"):
        x["VALUE"] = q[x["PERIOD"]][["Old", "New", "Diff (%)"].index(x["SUBCOL"])]
run("② 季度那段的值標成年度期間", m, True)
# ③ 子欄標籤對調(修正後 ↔ 修正前)
m = copy.deepcopy(sub)
for x in m:
    if x["FILENAME"].startswith("凱基投顧_2637") and x["ITEM"] == "毛利" and x["PERIOD"] == "2026F" and x["SUBCOL"] in ("修正後", "修正前"):
        x["SUBCOL"] = {"修正後": "修正前", "修正前": "修正後"}[x["SUBCOL"]]
run("③ 子欄標籤對調", m, True)
# ④ 漏一個值
m = [x for x in copy.deepcopy(sub) if not (x["FILENAME"].startswith("Daiwa") and x["ITEM"] == "Sales" and x["PERIOD"] == "2024E" and x["SUBCOL"] == "Change")]
run("④ 一格少拆一個值", m, True)
# ⑤~⑦ v2 基本資料:分析師是帳號推算的寫法(沒標推算 → FAIL · 標了推算 → EST)· 日期英文寫法 · 影像頁 → OCR(不是 FAIL)
basic = json.loads((od / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
gs = copy.deepcopy(next(x for x in basic if x["FILENAME"].startswith("GS-6415")))
gs["ANALYST"] = "Bruce X Lu"
r5 = V.verify_basic([gs], pdfdir)[0]["checks"]
gs["ANALYST"], gs["EMAIL"], gs["_STATUS"]["ANALYST"] = "Bruce Lu", "bruce.lu@gs.com", "推算(Email 帳號 · 原文未印此名)"
gs2 = copy.deepcopy(gs)
gs2["ANALYST"] = "Bruce Q Lu"
gs2["EMAIL"] = "bruce.q.lu@gs.com"
r6 = V.verify_basic([gs2], pdfdir)[0]["checks"]
hit = r5.get("ANALYST:Bruce X Lu", "").startswith("FAIL") and r6.get("ANALYST:Bruce Q Lu", "").startswith("EST")
ok &= hit
print("  [%s] ⑤ 分析師:原文沒印又沒標推算 → %s · 帳號推算且標推算 → %s" % ("OK" if hit else "FAIL", r5.get("ANALYST:Bruce X Lu", "")[:4], r6.get("ANALYST:Bruce Q Lu", "")[:3]))
d6 = V.date_in("2025-10-01", "x.pdf", "Taiwan Technology\n1 October 2025\nEquity Research") and V.date_in("2025-10-01", "x.pdf", "Oct 1, 2025") and not V.date_in("2025-10-02", "x.pdf", "Oct 1, 2025")
ok &= d6
print("  [%s] ⑥ 日期寫法:1 October 2025 / Oct 1, 2025 → 對 · 差一天 → 不對" % ("OK" if d6 else "FAIL"))
mq = [x for x in basic if x["FILENAME"].startswith("MQ-1560")]
if mq:
    m7 = copy.deepcopy(mq[0])
    m7["BLOOMBERG_TICKER"], m7["_STATUS"]["BLOOMBERG_TICKER"] = "1560 TT", "VERIFIED"
    r7 = V.verify_basic([m7], pdfdir)[0]["checks"].get("BLOOMBERG_TICKER", "")
    h7 = r7.startswith("OCR") or r7.startswith("PASS")
    ok &= h7
    print("  [%s] ⑦ 影像 PDF(MQ-1560)文字層沒有字 → %s(不是 FAIL)" % ("OK" if h7 else "FAIL", r7[:20]))
print("[計] 子欄驗證器反向測試 %s" % ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 1)
