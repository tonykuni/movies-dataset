"""v0168 收尾:驗證紀錄 · 工具包 · 日誌包 · 介面參考檔 → 發行夾;交接 v0169(v0168 + 本輪)· 桌機短版交接 §9 · latest;版本鎖 v0101(只增 · v0100 不動)。"""
import hashlib, json, shutil, subprocess, zipfile
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-movies-dataset/484f6e73-0cd5-53cb-a8dd-d4ee89d5500c/scratchpad")
W = S / "v168"; REL = W / "release168"
GIT = Path("/home/user/movies-dataset")
AI = GIT / "VeritasIntelligenceAnalytics/docs/handoff/ai"
OUT = AI / "vrn2_release_v0168"
UP = Path("/root/.claude/uploads/484f6e73-0cd5-53cb-a8dd-d4ee89d5500c/ddbd4915-taiwan_stock_data_matrix.html")
BR = "claude/vrn2-closeout-authorization-y4ixl7"
sha = lambda b: hashlib.sha256(b).hexdigest()  # noqa: E731
rel = json.loads((REL / "VRN2_Release_v0168.json").read_text(encoding="utf-8"))
assert not OUT.exists(), "發行夾已存在 · 不覆寫"
for p in (AI / "VRN2_Handover_v0169.md", AI / "VRN2_FreezeLock_v0101.json"):
    assert not p.exists(), p

ra_log = (S / "ra124.log").read_text(encoding="utf-8")
l_log = (S / "l168.log").read_text(encoding="utf-8")
wb_log = subprocess.run(["python3", "VRN2_Workbench_v0103.py", "--selftest"], cwd=str(S / "rtw"), capture_output=True, text=True, timeout=600).stdout
e2e = (S / "e2e" / "run2.log").read_text(encoding="utf-8")
pick = lambda text, keys: "\n".join(l for l in text.splitlines() if any(k in l for k in keys))  # noqa: E731

ver = """# VRN-2 v0168 驗證紀錄(2026-11-01 · Workbench v0103「00 系統現況」· 套件 v0168 · RoundAll v0124 · Handle-All v0116)

## 1. 要求

操作員 2026-11-01 上傳 `taiwan_stock_data_matrix.html`(VDS · VIA DATA MATRIX):「顯現部分資料擷取的端點來源 但並未顯示 DATAFRAME HEADERS ·
這種呈現方式更詳細更整合更優化可讓人一目了然 · 放在右面板第一個頁面的系統現況 SUMMARY 供 VRN-2 / VDF / VCGC 參考 · 以目前 HTML U/I 為基礎 ·
附件根據 LAYOUT 及字體階層大小視覺鎖定進行更新 · 原有功能設定不改」。附件原樣存在本夾 `VRN2_UI_Reference_taiwan_stock_data_matrix.html`(只當版面參考 · 不被任何程式載入)。

## 2. 做了什麼

| 檔 | 版本 | SHA-256 | 說明 |
|---|---|---|---|
| Workbench | v0103(runtime 內)| `%s` | v0102 薄尾:右面板最前面「00 系統現況」· 開頁預設 · 01 ~ 04 不動 |
| runtime | v0159 | `%s` | v0158 的 %d 個成員逐位元組不動 + Workbench v0103 |
| 啟動器 | v0168 | `%s` | 只換 WORKBENCH / runtime / 收據名 / 自測一段 |
| 套件 | VRN2_Closeout_v0168.zip | `%s` | 其他成員跟 v0166 逐位元組相同 |
| RoundAll | v0124 | `%s` | ⑤ 先只增補放 Workbench 鏈再重渲染 · 收尾頁沒有 v0103 標記 → 重渲染 · 取件分支 `%s`(退路 main)|
| Handle-All | v0116 | 一行 `%s` · 開機檔 `%s` | 指向 RoundAll v0124 |

00 頁內容:VRN-2 輸出冊矩陣(資料冊 · 來源 · 端點 · **DataFrame 表頭 = 冊裡真實欄名** · 燈)· 本輪流程步驟矩陣 · 其他系統只讀互看(VCGC 交接快照自報的燈 ·
VDF 固定位置有自報收據才讀 · 沒有就灰燈寫原因 · VRN-1 只看已登記入口)· 收尾狀態照 RoundAll 收尾頁收據(REVIEW 不寫成成功)· 點一列看全部欄(雙語名稱沿用 v0102 對照表)·
圖例篩選 · 摘要卡 · 窄螢幕一列一卡。版面 / 字體階層照附件;色盤與字型仍是範本鎖定的(不引外部字型 · 不新增色碼)。

## 3. 測試(雲端容器 · Linux · Python 3.13)

```text
%s
%s
%s
```

### 3.1 端到端沙盒(仿桌機:runtime 夾只有 v0102 鏈 · 收據 v0166 · 收尾頁是 v0102 渲染的)

`VRN2_RoundAll_v0124.py --only package,fix,report,closeout --offline --package <夾>`:

```text
%s
```

結果:runtime 夾補放 `VRN2_Workbench_v0103.py`(v0102 雜湊不變)· 收尾頁標記 `VRN2_Workbench v0103 over v0102` · 有「00 系統現況」分頁。
沙盒收尾 rc 2 是假資料的黃燈(不是本輪改動)。

### 3.2 瀏覽器(Chromium · 本容器)

1440 × 1000:開頁 = 00 系統現況 · 點 FinancialData 一列 → 明細列出全部 7 欄 · ESC 關 · 圖例 TWSE → 14 列裡 10 列淡出 · 01 ~ 04 切換照舊 · 02 資料冊表格照舊 · JS 錯誤 0。
390 寬:00 頁一列一卡、沒有溢出;整頁的水平捲動(513 px)來自原本的頁首,v0102 一樣(原有設定不改 · 沒動)。

## 4. 沒做 / 限制

- 容器沒有 PowerShell:Handle-All / 開機行**沒在 pwsh 剖析或實跑**(前幾輪有);它們是 v0115 原始檔逐字替換(取件分支 · 版號 · 雜湊),一行版用同一支 join_ps 產生,雜湊在 Python 端核過。
- RoundAll 自測在本容器實跑 88 項(其餘要 pwsh 的項目本機不跑)· 不過 0。
- 桌機的 `VRN2_Workbench_latest.html` 要桌機跑一次 repair 才會換成 v0103(收尾狀態仍以桌機收尾頁為準 · 目前 REVIEW)。
""" % (sha((S / "rtw" / "VRN2_Workbench_v0103.py").read_bytes())[:12], rel["runtime"]["zip_sha256"][:12], rel["runtime"]["retained_members"], rel["launcher"]["sha256"][:12],
       rel["package"]["sha256"][:12], rel["roundall"]["sha256"][:12], BR, rel["handleall"]["line_sha256"][:12], rel["handleall"]["boot_line_sha256"][:12],
       wb_log.strip().splitlines()[-1], pick(l_log, ("[PASS] v0168",)) or "(啟動器 v0168 自測 rc 0)", ra_log.strip().splitlines()[-1],
       pick(e2e, ("] ① 套件", "[U/I]", "Workbench 重渲染(最新收據) ·")).replace(str(S), "<scratch>")[:2000])
OUT.mkdir(parents=True)
for n in ("VRN2_Closeout_v0168.zip", "VRN2_HandleAll_v0116.md", "VRN2_HandleAll_v0116_boot.txt", "VRN2_Release_v0168.json", "VRN2_RoundAll_v0124.md", "VRN2_RoundAll_v0124.py"):
    shutil.copy2(str(REL / n), str(OUT / n))
(OUT / "VRN2_Verification_v0168.md").write_text(ver, encoding="utf-8", newline="\n")
shutil.copy2(str(UP), str(OUT / "VRN2_UI_Reference_taiwan_stock_data_matrix.html"))
with zipfile.ZipFile(OUT / "vrn2_test_tools_v0168.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "tools" / "mk168.py", W / "tools" / "finalize168.py", W / "new" / "VRN2_Workbench_v0103.py", REL / "handleall_src.ps1", REL / "boot_src.ps1", REL / "tiny_line.txt", REL / "cmd_line.txt", S / "ui.js", S / "mob2.js"]:
        z.write(str(p), "tools/" + p.name)
with zipfile.ZipFile(OUT / "logs_v0168.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p, n in ((S / "ra124.log", "roundall_v0124_selftest.log"), (S / "l168.log", "launcher_v0168_selftest.log"), (S / "e2e" / "run2.log", "e2e_repair_sandbox.log")):
        z.writestr(n, p.read_text(encoding="utf-8").replace(str(S), "<scratch>"))
    z.writestr("workbench_v0103_selftest.log", wb_log)

# ---- 交接 v0169 = v0168 + 本輪 ----
h = (AI / "VRN2_Handover_v0168.md").read_text(encoding="utf-8")
lines = h.split("\n")
assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0166")
lines[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0168 + VRN2_RoundAll_v0124 + VRN2_HandleAll_v0116 · 2026-11-01(Workbench v0103 右面板第一頁「00 系統現況」· DataFrame 表頭 · 版面與字體階層照操作員附件 · 01 ~ 04 不動 · 套件 v0168 · 版本鎖 v0101)"
h = "\n".join(lines)
para = ("> **本輪(v0168)**:操作員 2026-11-01 上傳 `taiwan_stock_data_matrix.html`,令「放在右面板第一個頁面的系統現況 SUMMARY · 含 DATAFRAME HEADERS · 以目前 HTML U/I 為基礎 · "
        "LAYOUT 及字體階層視覺鎖定 · 原有功能設定不改」。**Workbench v0103**(v0102 薄尾):右面板最前面「00 系統現況」(開頁預設)= 輸出冊 × 來源 × 端點 × 真實欄名 × 燈 · 本輪步驟 · "
        "其他系統只讀互看(VCGC 交接快照燈 · VDF 自報收據 · VRN-1 入口)· 點一列看全部欄 · 圖例篩選 · 摘要卡 · 窄螢幕一列一卡;拿掉 v0103 的部分 = v0102 頁面逐字相同。"
        "**runtime v0159**(v0158 全部成員不動 + v0103)· **啟動器 v0168** · **套件 v0168** · **RoundAll v0124**(⑤ 先只增補放 Workbench 鏈 · 收尾頁沒有 v0103 標記 → 重渲染 · "
        "取件分支 `%s` 退路 main)· **Handle-All v0116**。輸出冊不變 → auto 照樣選 repair。版本鎖 v0100 → **v0101**(操作員令 = 這次 U/I 改動的解鎖 · 換上新版本再鎖)。"
        "容器沒有 pwsh:PowerShell 一行沒有實跑(只在 Python 端核雜湊)。\n" % BR)
anchor = "> **本輪(v0167)**"
assert h.count(anchor) == 1
h = h.replace(anchor, para + anchor, 1)
row = ("| 0 | **(v0168)** PowerShell 7 先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)再貼 `vrn2_release_v0168/VRN2_HandleAll_v0116.md` 的最短一行(取件分支 `%s`)→ auto 選 repair(幾分鐘)→ "
       "Workbench 換 v0103 · 開頁就是「00 系統現況」· 收尾仍應是 REVIEW(VRN-2 0)· 人工兩項照舊(MQ-1560 四點 `--confirm` · 華南 6143 原文)| 貼回 |\n" % BR)
a8 = "| 0 | **(v0167)** cmd 視窗"
assert h.count(a8) == 1
h = h.replace(a8, row + a8, 1)
a9 = "**v0158(2026-10-31)**:"
assert h.count(a9) == 1
h = h.replace(a9, "**v0168(2026-11-01)**:Workbench v0103「00 系統現況」· 啟動器 v0168 · runtime v0159 · RoundAll v0124 · Handle-All v0116 · 輸出冊不變 · 版本鎖 v0101 · 收尾以桌機為準(REVIEW)。\n\n" + a9, 1)
(AI / "VRN2_Handover_v0169.md").write_text(h, encoding="utf-8", newline="\n")

# ---- 版本鎖 v0101(只增 · v0100 不動)----
v100 = json.loads((AI / "VRN2_FreezeLock_v0100.json").read_text(encoding="utf-8"))
base = "VeritasIntelligenceAnalytics/docs/handoff/ai/"
files = {k: v for k, v in v100["files"].items() if "/vrn2_release_v0166/" not in k and "/vrn2_release_v0167/" not in k}
for n in ("VRN2_HandleAll_v0116.md", "VRN2_HandleAll_v0116_boot.txt", "VRN2_RoundAll_v0124.py", "VRN2_Release_v0168.json", "VRN2_Closeout_v0168.zip"):
    files[base + "vrn2_release_v0168/" + n] = sha((OUT / n).read_bytes().replace(b"\r\n", b"\n"))
for k in files:
    assert (GIT / k).is_file(), k
    assert sha((GIT / k).read_bytes().replace(b"\r\n", b"\n")) == files[k], k
lock = dict(v100)
lock.update({"lock": "VRN2_FreezeLock_v0101", "supersedes": "VRN2_FreezeLock_v0100 (kept unchanged)", "locked_at": "2026-11-01",
             "unlocked_by": "操作員 2026-11-01 令「以目前 HTML U/I 為基礎 · 右面板第一頁系統現況 SUMMARY(含 DATAFRAME HEADERS)· 視覺鎖定更新 · 原有功能設定不改」= 這次 U/I 改動的解鎖;改完換上新版本再鎖",
             "main_commit": subprocess.run(["git", "-C", str(GIT), "rev-parse", "HEAD"], capture_output=True, text=True).stdout.strip(),
             "active": dict(v100["active"], handle_all="v0116", roundall="v0124", package="VRN2_Closeout_v0168 (launcher v0168 · runtime v0159 · manager v0258 · Workbench v0103)", workbench="VRN2_Workbench_v0103 (page 00 系統現況)"),
             "files": files,
             "check_status": "WORKBENCH_V0103_15_OK · LAUNCHER_V0168_OK · ROUNDALL_V0124_88_OK · E2E_REPAIR_SANDBOX_V0103_RENDERED · BROWSER_OK · PWSH_NOT_RUN",
             "check_message": "版本凍結,不是驗收。容器沒有 pwsh:PowerShell 一行沒有實跑(雜湊在 Python 端核過)。",
             "boot_branch": BR})
(AI / "VRN2_FreezeLock_v0101.json").write_text(json.dumps(lock, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
print("release folder", sorted(p.name for p in OUT.iterdir()))
print("lock v0101 files", len(files))
