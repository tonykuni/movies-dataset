"""v0168 收尾:驗證紀錄 · 交接 v0169(從 v0168 抄 · 只增)· 放進倉 vrn2_release_v0168 · logs / 工具 zip。原文 PDF / 輸出冊的值 / 桌機貼回包不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v168"); rel = W / "release168"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    for a, b in ((str(W / "t168a"), "<sbx>"), (str(W), "<w>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        x = x.replace(a, b)
    return x


R = json.loads((rel / "VRN2_Release_v0168.json").read_text(encoding="utf-8"))
mgr = [l for l in lines(W / "mgr259_selftest.log") if l.startswith(("[PASS]", "[FAIL]"))]
lau = [l for l in lines(W / "launcher168_selftest.log") if l.startswith("[FAIL]") or ("v0168" in l and l.startswith("[PASS]"))]
ra = [l for l in lines(W / "rall124_selftest_venv.log") if re.search(r"^\[PASS\] 88 |^\[FAIL\]|--selftest · ", l)]
ps = json.loads((W / "pscheck168.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny168.rc") if l.strip()]
pat = r"boot:|boot SHA|④ 自動選模式|① 套件 ·|v0259 轉置表|⑪ 獨立驗證 · 年度|===== 收尾|\[(VRN-2|人工|VCGC|資料源)\] \d|ForegroundColor"
e2e = {n: [short(l)[:220] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)][:14] for n in ("auto1", "auto2", "tamper")}
states = {}
for n in ("auto1", "auto2"):
    d = json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))
    states[n] = {"state": d["state"], "per_owner": d["per_owner"]}
R["results"] = {"manager_v0259_selftest": mgr[-1:], "launcher_v0168_selftest": lau, "roundall_v0124_selftest": ra, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "closeout_states": states,
                "original_6143": "sandbox, manager run on the original: 40 / 40 values back (rejected 40 → 0) · independent verifier v0114 TRANSALIGNED 40 · every cell equals the printed table",
                "regression_19": "14 real reports + 5 originals, v0258 vs v0259: FinancialData 5622 → 5662 (removed 0 · added 40 = 6143 P1·M·05·TB) · Rejected 806 → 766 (the same 40) · BasicInfo / Summary identical",
                "desktop_scope": "desktop 09:19 Rejected book: exactly 40 rows carry 「轉置表第三讀法(pdfplumber)對不上」, all 6143",
                "handleall_color": "pwsh: the v0115 REVIEW lines raise Write-Host ForegroundColor error · the v0116 lines print (colcheck)",
                "not_run": "the desktop itself (next: auto → full · books rebuilt by v0259) · the operator's own --confirm"}
(rel / "VRN2_Release_v0168.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0168 驗證紀錄(2026-11-02 · 管理器 v0259 轉置表再驗 · 套件 v0168 · RoundAll v0124 · Handle-All v0116)

## 1. 起因

- 桌機 2026-11-02 10:30(Handle-All v0115 repair · 75 秒):收尾 **REVIEW**(VRN-2 0 · 人工 2 · 資料源 3)· 缺項只剩華南投顧-6143 · 收尾行印了兩次
  「Write-Host 無法繫結參數 ForegroundColor」。
- 操作員上傳華南投顧-6143-振曜-1141128.pdf(只在容器沙盒用 · 不進倉)。

## 2. 6143 原文核對

第 1 頁「年度EPS預估」:年份在列(2022 · 2023 · 2024 · 2025(F) · 2026(F))· 科目在欄(營收 · 毛利率(%%) · 營益率(%%) · 業外收支率(%%) · 股本 · 稅前純益 · 稅前EPS · 稅後EPS)= 40 值。
**原文有年度表**。第二讀取器(pypdfium2)每一列都讀得到;v0236 轉置表第三讀法閘(pdfplumber)整張剔除「每個年份一行對不上」:2026(F) 那列的一位小數值上疊了一個
別的字型(Calibri · 低 2pt)的空白字(Word 留下的),pdfplumber 把那個數切成「3」「.0」兩個字(兩個字其實相連)→ 那一列數字序列不同 → 40 值全剔。
桌機 09:19 剔除冊裡帶這個理由的剛好 40 列 · 全是 6143。

## 3. 修正

- **管理器 VRN_SystemManager_v0259**(薄尾 · PRIOR v0258):只對「轉置表第三讀法(pdfplumber)對不上」的剔除列 · 依表分組 · 第三讀法同一行裡相連(間距 ≤ 0.5pt)的數字碎片接回
  (左邊有數字 · 接點是小數點 / 千分位 · 接起來是數字)再問 v0236 同一個閘;過了整張表回主冊(VERIFY 註明 v0259)· 該份的「年度數據」缺項清掉;還是不過 / 主冊已有同鍵 → 照留剔除冊;
  再驗出錯 → 輸出冊照 v0258。
- **Handle-All v0116**:v0113 起建置時把 --confirm 提示塞進了顏色表的 REVIEW(第一個 `REVIEW = '…'`)→ 收尾 REVIEW 時 Write-Host 顏色參數錯 · 改回 'Yellow' · 提示移到「下一步」那行。
- 套件 v0168(啟動器 v0168 · runtime v0159 = v0158 的 197 個成員不動 + v0259)· RoundAll v0124 · Handle-All v0116 · 啟動器版號跳過 v0167。

## 4. 測試

| 項目 | 結果 |
|---|---|
| 管理器 v0259 自測 | %s |
| 啟動器 v0168 自測 | %s |
| RoundAll v0124 自測 | %s |
| PowerShell 剖析 | %s |
| 6143 原文(沙盒 · 管理器直跑) | 40 / 40 值回主冊(剔除 40 → 0)· 獨立驗證 TRANSALIGNED 40 · 逐格等於原文 |
| 回歸(沙盒 14 份真報告 + 5 份原文) | 年度數據 5622 → 5662(少 0 · 多 40 = 6143)· 剔除冊 806 → 766(同那 40)· 基本資料 / 摘要不變 |
| Handle-All 顏色 | v0115 那兩行在 pwsh 照樣報 ForegroundColor 錯 · v0116 正常印 |
| e2e(最短一行 · 沙盒含三份原文) | %s · auto 第一次 → 整輪(收據 v0153)· 第二次 → repair(收據 v0168)· 竄改開機檔 → 不執行 · 整輪裡 v0259 補回 6143 的 40 值 · ⑪ 年度 5232 筆錯值 0(TRANSALIGNED 75 → 115)· 缺項不再有 6143 年度數據 · 收尾 %s(VRN-2 3 項 = 新加的三份在沙盒做不出摘要:容器測試環境 numpy 1.26.4 配 scikit-learn 1.9.1 · 環境問題 · 摘要器這輪沒動 · 桌機這三份已有四點)|

## 5. 一行指令

cmd 一行 %d 字元 · PowerShell 最短一行 %d 字元 · 開機檔 `vrn2_release_v0168/VRN2_HandleAll_v0116_boot.txt`(SHA-256 `%s`)· Handle-All 一行 `%s` · RoundAll v0124 `%s` · 套件 `%s`。
auto:上一輪收據不是啟動器 v0168 做的 → 整輪(輸出冊要由 v0259 重做 · 桌機約 90 分鐘)。PowerShell 視窗設同意閘要用 `$env:VIA_SCRAPE_CONSENT = 'YES'`(`set "…"` 是 cmd 的寫法)。

## 6. 沒做 / 待辦

- 人工確認只有操作員親手打 `--confirm`(AI 不代打)· MQ-1560 四點 H-fd2ea35f。
- 3014TT 四點(第 2 點從句中開始 · 第 1 / 3 點重複)· MQ-1560 OCR 字詞錯(chi players)→ 摘要器 / OCR 另一輪。
- 主控台前面那段 VDF / VCGC / SettleAll 的訊息是其他系統的(VDF_SystemManager rc 1 · claude/vrn2-closeout-authorization-y4ixl7 分支的 SettleAll 雜湊不符)· VRN-2 只讀不動。
""" % (mgr[-1][:120] if mgr else "—", " · ".join(x[:90] for x in lau) or "—", " · ".join(x[:90] for x in ra[-1:]), pparse, " · ".join(rc), json.dumps(states, ensure_ascii=False),
       H["cmd_line_chars"], H["tiny_line_chars"], H["boot_line_sha256"][:12], H["line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12])
(rel / "VRN2_Verification_v0168.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0168.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0166 + VRN2_RoundAll_v0123 + VRN2_HandleAll_v0115 · 2026-11-01(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0168 + VRN2_RoundAll_v0124 + VRN2_HandleAll_v0116 · 2026-11-02(華南 6143 原文有年度表 → 管理器 v0259 轉置表再驗 · "
        "Handle-All 收尾 REVIEW 顏色修正 · 套件 v0168)")
src = "\n".join(L)
once("> **本輪(v0167)**",
     "> **本輪(v0168)**:桌機 10:30 跑 v0123 repair → 收尾 **REVIEW**(VRN-2 0 · 人工 2 · 資料源 3)· 缺項只剩華南 6143。操作員上傳 6143 原文:第 1 頁年度表(年份在列 · 8 科目 · 40 值)原文有;"
     "第三讀法(pdfplumber)把 2026(F) 列一個疊了別字型空白字的「3.0」切成「3」「.0」→ 轉置表閘整張剔除。**管理器 v0259**(只對這種剔除列 · 相連的數字碎片接回再問同一個閘 · 原文 40 / 40 回主冊 · "
     "獨立驗證 TRANSALIGNED 40 · 19 份回歸只多這 40 值)· **Handle-All v0116**(收尾 REVIEW 的 Write-Host 顏色錯修好 · 最短一行 %d 字元 · cmd 一行 %d 字元)· **RoundAll v0124** · 套件 v0168(啟動器 v0168 · runtime v0159)。\n"
     "> **本輪(v0167)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
r167 = json.loads((REPO / "vrn2_release_v0167/VRN2_Release_v0167.json").read_text(encoding="utf-8"))
once("| **VRN2_HandleAll_v0115.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0115** | `vrn2_release_v0167` |",
     "| **VRN2_HandleAll_v0116.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0116** | `vrn2_release_v0168` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0124 · REVIEW 顏色修正 · auto:收據 < v0168 → 整輪)|\n"
     "| **VRN2_RoundAll_v0124.py**(發行夾 · 一支入口 · 不在套件內)| **v0124** | `vrn2_release_v0168` | `%s` | **新**(套件 v0168 · ③ 自測跑管理器 v0259 · 自測 90 項)|\n"
     "| **VRN2_Closeout_v0168.zip**(發行夾 · 套件)| **v0168** | `vrn2_release_v0168` | `%s` | **新**(啟動器 v0168 · runtime v0159 · 管理器 v0259)|\n"
     "| **VRN2_HandleAll_v0115.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0115** | `vrn2_release_v0167` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0123.py**(發行夾 · 一支入口 · 不在套件內)| **v0123** | `vrn2_release_v0167` | `%s` | **新**(" % r167["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0123.py**(發行夾 · 一支入口 · 不在套件內)| **v0123** | `vrn2_release_v0167` | `%s` | 被 v0124 取代(套件 v0166 → v0168)· (" % r167["roundall"]["sha256"][:12])
once("| ActivateVRN-2_v0166.py(套件 · 底座 v0136 · runtime v0158 · 版號跳過 v0165)| **v0166** |",
     "| ActivateVRN-2_v0168.py(套件 · 底座 v0136 · runtime v0159 · 版號跳過 v0167)| **v0168** | 見發行清單 | `%s` | **新**(管理器 v0259 · 收據 v0168 · 自測多一段 v0168)|\n"
     "| VRN2_Runtime_v0159.zip(套件 · runtime)| **v0159** | 套件內 | `%s` | **新**(v0158 的 197 個成員不動 + VRN_SystemManager_v0259)|\n"
     "| VRN_SystemManager_v0259.py(runtime · 薄尾 v0258)| **v0259** | runtime v0159 | 見 runtime 清單 | **新**(轉置表第三讀法對不上的剔除列 · 相連數字碎片接回再問同一個閘 · 過了回主冊)|\n"
     "| ActivateVRN-2_v0166.py(套件 · 底座 v0136 · runtime v0158 · 版號跳過 v0165)| **v0166** |" % (R["launcher"]["sha256"][:12], R["runtime"]["zip_sha256"][:12]))
once("| 0 | **(v0167)**",
     "| 0 | **(v0168)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"`(PowerShell 視窗是 `$env:VIA_SCRAPE_CONSENT = 'YES'`)再貼 `vrn2_release_v0168/VRN2_HandleAll_v0116.md` 的 cmd 一行 → auto 選整輪(約 90 分鐘 · 輸出冊由 v0259 重做)→ "
     "收尾應是 REVIEW · 缺項清空(6143 補回)· 只剩 MQ-1560 四點(操作員自己打 `--confirm H-fd2ea35f`)| 貼回 / 人工 |\n"
     "| 0 | **(v0167)**")
once("**v0167(2026-11-01)**:", "**v0168(2026-11-02)**:華南 6143 原文有年度表 → 管理器 v0259(轉置表第三讀法數字碎片接回)· 套件 v0168(啟動器 v0168 · runtime v0159)· RoundAll v0124 · Handle-All v0116(REVIEW 顏色修正)。\n\n**v0167(2026-11-01)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0168)** **讀取器之間的字詞切法會不同**:Word 輸出的 PDF 會留下別的字型的空白字疊在數字上;pdfplumber 依字元順序切詞會把相連的「3」「.0」分開,pypdfium2 不會。"
     "閘要比對數字序列時,先把同一行相連(≤ 0.5pt)的數字碎片接回再比;不要放寬比對本身(數字一定要完全相同)。\n"
     "- **(v0168)** **測試的固定資料不放原文的值**:自測 / 範例用合成的數字(形狀照原文 · 值不照抄),原文 PDF 與輸出冊的值不進倉。\n"
     "- **(v0168)** **建置時的字串替換要錨定**:Handle-All v0113 用「第一個 REVIEW = '…'」去改提示,改到的是顏色表(v0116 才修好);替換前先確認那個字串在檔裡只出現在要改的地方。\n\n")
(REPO / "VRN2_Handover_v0169.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0168"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0168.zip", "VRN2_RoundAll_v0124.py", "VRN2_RoundAll_v0124.md", "VRN2_HandleAll_v0116.md", "VRN2_HandleAll_v0116_boot.txt", "VRN2_Release_v0168.json", "VRN2_Verification_v0168.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 2, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t168a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0168.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mgr259_selftest.log", "launcher168_selftest.log", "rall124_selftest_venv.log", "pscheck168.log", "tiny168.rc", "seed168.log", "confirm_list.log")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0168.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("runtime159.py", "mk_launcher168.py", "mk_roundall124.py", "build168.py", "finalize168.py", "e2e168.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0169", src.count("\n"))
