"""VRN2_RoundAll_v0124.py = v0123(倉裡 vrn2_release_v0167)+ 套件 v0168(啟動器 v0168 · runtime v0159 · 管理器 v0259 轉置表再驗)。
操作員 2026-11-02 上傳華南投顧-6143 原文。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v168")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0167/VRN2_RoundAll_v0123.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0123')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0123 — ', '"""VRN2_RoundAll v0124 — ', 1)
at = doc.index("v0123(")
doc = doc[:at] + '''v0124(操作員 2026-11-02 上傳華南投顧-6143 原文 · 桌機 10:30 v0123 repair 收尾 REVIEW · VRN-2 0 · 缺項只剩 6143):
  · 6143 第 1 頁「年度EPS預估」年份在列(2022 ~ 2026(F))· 8 個科目在欄 = 40 值;v0236 轉置表第三讀法(pdfplumber)整張剔除「每個年份一行對不上」——
    2026(F) 那列「3.0」上面疊了一個別的字型的空白字(Word 留下的),pdfplumber 把它切成「3」「.0」(兩個字其實相連)。
  · 套件 v0168(啟動器 v0168 · runtime v0159 = v0158 的 197 個成員不動 + 管理器 VRN_SystemManager_v0259):只對「轉置表第三讀法對不上」那些剔除列,
    把第三讀法同一行裡相連(間距 ≤ 0.5pt)的數字碎片接回(小數點 / 千分位 · 接起來要是數字)再問同一個閘;過了整張表回主冊 · 還是不過照留剔除冊。
    原文實測 40 / 40 值回主冊 · 獨立驗證 TRANSALIGNED 40。
  · ③ 自測改跑管理器 v0259(它再跑 v0258 / v0257 / v0255 的自測)。給 Handle-All v0116 用(auto:上一輪收據不是啟動器 v0168 做的 → 整輪)。
  · 自測 90 項(v0123 的 89 項 + 88)。共用 MarketFetch 與 VDF 引擎照舊只讀不改。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0123.py", "用法:python VRN2_RoundAll_v0124.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


b0 = s.index('VERSION = "v0123"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0166", "v0168").replace("VRN2_Runtime_v0158", "VRN2_Runtime_v0159")
s = pre + post
rep('VERSION = "v0123"', 'VERSION = "v0124"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0123.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0123.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0124.py"', n_dl)
rep('"VRN2_RoundAll_v0123.py" in html_', '"VRN2_RoundAll_v0124.py" in html_')
rep("· v0122 起 88 項 · v0123 起 89 項。", "· v0122 起 88 項 · v0123 起 89 項 · v0124 起 90 項。")
rep('''and RELEASE_REL.endswith("/vrn2_release_v0168") and ("VRN_SystemManager_v0258.py", 1800) in SELFTESTS and''',
    '''and RELEASE_REL.endswith("/vrn2_release_v0168") and ("VRN_SystemManager_v0259.py", 1800) in SELFTESTS and''')
rep('''chk("84 v0122:套件 v0168(啟動器 v0168 · runtime v0158 · 收據 VRN2_Closeout_v0168.json)· ③ 自測跑管理器 v0258(它再跑 v0257 / v0255 的自測)· 不再單跑 v0257",''',
    '''chk("84 v0122 起:套件照釘(v0124 起 v0168 · 啟動器 v0168 · runtime v0159 · 收據 VRN2_Closeout_v0168.json)· ③ 自測跑最新管理器(v0124 起 v0259 · 它再跑前版的自測)· 不單跑 v0257",''')
rep('''"先把那幾份原 PDF 上傳給 AI 對:原文有年度表 = 擷取漏(要修 · 欣銓 3264 / Daiwa-6278 就是 · 管理器 v0258 已補);原文真的沒有年度表才算缺"''',
    '''"先把那幾份原 PDF 上傳給 AI 對:原文有年度表 = 擷取漏(要修 · 欣銓 3264 / Daiwa-6278 就是 · 管理器 v0258 已補 · 華南 6143 管理器 v0259 已補);原文真的沒有年度表才算缺"''')
rep('("VRN_SystemManager_v0258.py", 1800)', '("VRN_SystemManager_v0259.py", 1800)')
rep('''        chk("86 v0122:''', '''        chk("88 v0124:套件 v0168(啟動器 v0168 · runtime v0159)· ③ 自測跑管理器 v0259 · 缺項提示寫 6143 已由 v0259 補",
            PACKAGE == "VRN2_Closeout_v0168" and LAUNCHER == "ActivateVRN-2_v0168.py" and RUNTIME_ZIP == "VRN2_Runtime_v0159.zip" and RECEIPT == "VRN2_Closeout_v0168.json"
            and ("VRN_SystemManager_v0259.py", 1800) in SELFTESTS and ("VRN_SystemManager_v0258.py", 1800) not in SELFTESTS and VERSION == "v0124"
            and "v0259" in owner_of({"lamp": "YELLOW", "step": "⑥ 完成判定 · 輸出冊(基本資料 / 年度數據 / 一標題四重點)", "detail": "缺項 1 份"}, {})[1])
        chk("86 v0122:''')
(W / "new").mkdir(exist_ok=True)
out = W / "new/VRN2_RoundAll_v0124.py"
out.write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,40}v0166.{0,40}", s[s.index('VERSION = "v0124"'):])]
print("RoundAll v0124 lines", s.count("\n"), "· v0166 left in body:", len(left), left[:3])
