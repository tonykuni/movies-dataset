const { chromium } = require('playwright');
(async () => { const b = await chromium.launch(); const m = await b.newPage({ viewport: { width: 390, height: 844 } });
  await m.goto('file://' + process.argv[2]); await m.waitForTimeout(400);
  const el = await m.$('#sysmatrix'); await el.screenshot({ path: process.argv[3] });
  const box = await el.boundingBox(); console.log(JSON.stringify(box)); await b.close(); })();
