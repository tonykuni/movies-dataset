"""ActivateVRN-2_v0168.py = v0166 + 管理器 VRN_SystemManager_v0259(轉置表第三讀法數字碎片接回)· runtime v0159 = runtime v0158(197 個成員一字不改)+ v0259。
操作員 2026-11-02 上傳原文(華南投顧-6143)。啟動器版號跳過 v0167(v0167 是只換 RoundAll 的發行夾,沒有 v0167 啟動器)。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v166/pkg166/ActivateVRN-2_v0166.py")
OUT = Path("/home/user/vrn2_work/v168/pkg168/ActivateVRN-2_v0168.py")
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0166: v0164 entry + manager VRN_SystemManager_v0258', '''"""VRN-2 v0168: v0166 entry + manager VRN_SystemManager_v0259 (transposed tables asked again with the third reader's touching number fragments joined).
Operator 2026-11-02 uploaded 華南投顧-6143-振曜-1141128.pdf (the last "output books missing annual data"): page 1 prints the annual table (years as rows
2022 – 2026(F) · 8 items) = 40 values; v0236's third-reader gate (pdfplumber) rejected the whole table because a stray space glyph from another font lies
across 「3.0」 in the 2026(F) row and pdfplumber splits it into 「3」+「.0」 (the glyphs touch). v0259 asks the same gate again for such rows with
touching number fragments joined (gap ≤ 0.5 pt · decimal / thousands separator · result is a number); a passing table returns to the annual book.
 Real original: 40 / 40 values back · independent verifier TRANSALIGNED 40. Runtime v0159 = runtime v0158 (197 members byte-identical) + v0259.
 Receipt VRN2_Closeout_v0168.json. Launcher number v0167 is skipped (release folder v0167 only replaced RoundAll; there is no launcher v0167).

VRN-2 v0166: v0164 entry + manager VRN_SystemManager_v0258''')
rep('VERSION = "ActivateVRN-2 v0166"', 'VERSION = "ActivateVRN-2 v0168"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0158.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0159.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0158.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0159.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0166.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0168.json"')
rep('MANAGER = "VRN_SystemManager_v0258.py"   # v0166:', 'MANAGER = "VRN_SystemManager_v0259.py"   # v0168: transposed tables re-asked with joined number fragments over v0258 · v0166 v0258:')
rep('''    assert MANAGER == "VRN_SystemManager_v0258.py"''', '''    m259 = selftest_source("VRN_SystemManager_v0259.py").read_text(encoding="utf-8")
    assert 'TAG = "v0259"' in m259 and 'PRIOR_NAME = "VRN_SystemManager_v0258.py"' in m259 and "def _tj_recheck(" in m259 and '_out_books = _timed("輸出冊", _out_books_v0259)' in m259
    assert MANAGER == "VRN_SystemManager_v0259.py"''')
rep('''        assert mgr[-1] == "VRN_SystemManager_v0258.py" and "VRN_SystemManager_v0257.py" in mgr''', '''        assert mgr[-1] == "VRN_SystemManager_v0259.py" and "VRN_SystemManager_v0258.py" in mgr and "VRN_SystemManager_v0257.py" in mgr''')
rep('''    print("[PASS] v0166: manager v0258 is the active manager''', '''    print("[PASS] v0168: manager v0259 is the active manager (transposed tables re-asked with the third reader's touching number fragments joined · still failing stays in Rejected) · v0258 kept as PRIOR")
    print("[PASS] v0166: manager v0258 (PRIOR of v0259)''')
rep('return runtime / MANAGER, lamp, detail + " · active manager v0258"', 'return runtime / MANAGER, lamp, detail + " · active manager v0259"')
rep('return lamp, detail + " · launcher v0166"', 'return lamp, detail + " · launcher v0168"')
rep('note="VRN-2 private runtime; exact ship v0158 (launcher v0166 · no MOPS · store MOPS rows purged); manager v0258 table repair (over v0257 · v0255);',
    'note="VRN-2 private runtime; exact ship v0159 (launcher v0168 · no MOPS · store MOPS rows purged); manager v0259 transposed re-check (over v0258 table repair · v0257 · v0255);')
rep('print("NEXT: [%s] VRN-2 v0166 · rc %s', 'print("NEXT: [%s] VRN-2 v0168 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0168", len(s.splitlines()), "lines")
