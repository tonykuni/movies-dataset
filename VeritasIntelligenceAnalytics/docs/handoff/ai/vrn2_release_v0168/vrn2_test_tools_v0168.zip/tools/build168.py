"""v0168(冪等):套件 VRN2_Closeout_v0168.zip(啟動器 v0168 · runtime v0159 = v0158 + 管理器 v0259)→ RoundAll v0124(填套件雜湊)→ Handle-All v0116(REVIEW 顏色修正)
→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0168)。vrn2_release_v0167 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v168"); pkg, rel = W / "pkg168", W / "release168"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v167/release167")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r164 = json.loads((REPO / "vrn2_release_v0166/VRN2_Release_v0166.json").read_text(encoding="utf-8"))
r165 = json.loads((REPO / "vrn2_release_v0167/VRN2_Release_v0167.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0159.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0159.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0158.zip " + r164["runtime"]["zip_sha256"]
assert rt["retained_members"] == 197 and rt["new_members"] == ["VRN_SystemManager_v0259.py"]
old = {c["path"]: c["sha256"] for c in r164["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0168.py", "VRN2_Runtime_v0159.zip", "VRN2_Runtime_v0159.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0168.py", "VRN2_Runtime_v0159.zip", "VRN2_Runtime_v0159.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0166 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0168 — VRN-2 closeout package (2026-11-02 · manager v0259: transposed tables re-asked with joined number fragments)\n\n"
  "Entry: python ActivateVRN-2_v0168.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0124.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0116.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0159.zip = v0158 (197 members byte-identical) + VRN_SystemManager_v0259.\n\n"
  "v0168 (operator 2026-11-02 uploaded 華南投顧-6143): its annual table (years as rows · 40 values) was rejected by the transposed-table third-reader\n"
  " gate because pdfplumber splits 「3.0」 into 「3」+「.0」 at a stray space glyph of another font (the glyphs touch). Manager v0259 asks the same gate\n"
  " again for rows rejected that way, with touching number fragments joined (gap <= 0.5 pt · decimal / thousands separator · result is a number);\n"
  " a passing table returns to the annual book, a failing one stays in Rejected. Launcher number v0167 is skipped (no launcher v0167).\n"
  "v0166: manager v0258 table repair (half-line labels · two-level period header). v0164: TARGET_PRICE(ADJ) sync · store MOPS purge. v0163: no MOPS.\n"
  "Verification: see VRN2_Verification_v0168.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0168.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0168", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0168.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0168/" + n, date_time=(2026, 11, 2, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0124.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0168"' in ra and 'VERSION = "v0124"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168"' in ra
(rel / "VRN2_RoundAll_v0124.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0167'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168'")
rep("$F = 'VRN2_RoundAll_v0123.py'", "$F = 'VRN2_RoundAll_v0124.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0115", "Handle-All v0116", ha.count("Handle-All v0115"))
rep("$Mode = ($last -ge 166 -and $haveOut) ? 'repair' : 'full'", "$Mode = ($last -ge 168 -and $haveOut) ? 'repair' : 'full'")
rep("(上一輪輸出冊是啟動器 v0166 以前做的 · 管理器 v0258 要重做輸出冊:補回原文有、以前漏掉的年度表)", "(上一輪輸出冊是啟動器 v0168 以前做的 · 管理器 v0259 要重做輸出冊:補回華南 6143 這種轉置表 · 原文有、以前漏掉的年度表)")
rep("(輸出冊是啟動器 v0166 做的 → 不整輪)", "(輸出冊是啟動器 v0168 做的 → 不整輪)")
rep("管理器 v0258(輸出冊前表格修補)", "管理器 v0259(轉置表再驗 · v0258 表格修補)", ha.count("管理器 v0258(輸出冊前表格修補)"))
rep("v0166", "v0168", ha.count("v0166"))
rep("REVIEW = 'Yellow · 看過原文沒問題 → 照收尾頁那一項的 --confirm 指令記下(只有你打才算)'", "REVIEW = 'Yellow'")      # v0116 v0113 起顏色欄被塞了提示字 → Write-Host 顏色參數錯
rep("REVIEW = '下一步:VRN-2 側已結案 · 打開收尾頁看「人工核對」那幾項的原 PDF'", "REVIEW = '下一步:VRN-2 側已結案 · 打開收尾頁看「人工核對」那幾項的原 PDF · 看過原文沒問題 → 照收尾頁那一項的 --confirm 指令記下(只有你打才算)'")
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if re.search(r"Handle-All v0115|v0123\.py|v0166", l) and not l.lstrip().startswith("#")]
assert re.search(r"\$col = @\{[^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0167", "vrn2_release_v0168"), ("VRN2_HandleAll_v0115.md", "VRN2_HandleAll_v0116.md"), ("Handle-All v0115 SHA-256 OK", "Handle-All v0116 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0116_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168/VRN2_HandleAll_v0116_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0116(2026-11-02 · 管理器 v0259 轉置表再驗 · 套件 v0168 · RoundAll v0124)

桌機 2026-11-02 10:30(v0123 repair):收尾 **REVIEW**(VRN-2 0 · 人工 2 · 資料源 3)· 缺項只剩華南投顧-6143。操作員上傳 6143 原文 → 第 1 頁「年度EPS預估」
年份在列(2022 ~ 2026(F))· 8 個科目在欄 = 40 值 —— 原文有年度表,第三讀法把「3.0」切成「3」「.0」(Word 疊了一個別字型的空白字)→ 整張表被剔除。

| 項目 | 現在 |
|---|---|
| 管理器 v0259 | 只對「轉置表第三讀法對不上」的剔除列:第三讀法同一行相連(≤ 0.5pt)的數字碎片接回(小數點 / 千分位 · 接起來要是數字)再問同一個閘 · 過了整張表回主冊 |
| 原文實測 | 6143 → 40 / 40 值回主冊 · 獨立驗證 TRANSALIGNED 40 · 值逐格對原文 |
| Handle-All 顯示 | v0113 起收尾 REVIEW 時那兩行「Write-Host 無法繫結參數 ForegroundColor」修好(顏色欄被塞了提示字)· 提示移到「下一步」那行 |
| 自動選模式 | 上一輪收據不是啟動器 v0168 做的 → **整輪**(輸出冊要由 v0259 重做 · 桌機約 90 分鐘)|
| 套件 | `vrn2_release_v0168/VRN2_Closeout_v0168.zip`(SHA-256 `%s` · 啟動器 v0168 · runtime v0159)|
| 一支 Python | `VRN2_RoundAll_v0124.py`(SHA-256 `%s` · 自測 90 項)|

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定 · cmd 視窗的寫法;PowerShell 視窗要寫 `$env:VIA_SCRAPE_CONSENT = 'YES'`)· 第 2 行 = 下面 PowerShell 那一行的編碼版(一樣核對 SHA-256 才執行)。

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0124.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0124.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

第 1 行列出待核項與代碼 · 第 2 行記一筆確認(代碼照收尾頁那一項)· 撤銷:`--confirm revoke H-xxxxxxxx`。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0116 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0124 `%s`)。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0116.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0124.py(套件 v0168 · 管理器 v0259 轉置表再驗)

`VRN2_RoundAll_v0124.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0123 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0168/VRN2_Closeout_v0168.zip`(SHA-256 `%s` · 本檔內已釘)· 啟動器 v0168 · runtime v0159 = v0158 的 197 個成員不動 + 管理器 v0259 |
| ③ 自測 | 改跑管理器 v0259(它再跑 v0258 / v0257 / v0255 的自測)|
| 收尾頁 | 缺項提示多寫「華南 6143 管理器 v0259 已補」|

`--confirm` 照舊只有操作員親手打才記。自測 90 項(v0123 的 89 項 + 88)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0124.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0168 (manager v0259 · runtime v0159) + VRN2_RoundAll_v0124 + VRN2_HandleAll_v0116", "date": "2026-11-02",
        "trigger": "操作員 2026-11-02 上傳華南投顧-6143-振曜-1141128.pdf(收尾頁最後一個「輸出冊缺項 · 年度數據」)+ 桌機 10:30 v0123 repair 收尾 REVIEW(VRN-2 0)+ Handle-All 收尾行 Write-Host ForegroundColor 錯",
        "finding": {"6143": "page 1 annual table 「年度EPS預估」 (years as rows 2022 – 2026(F) · 8 items · 40 values) · v0236 transposed-table third-reader gate (pdfplumber) rejected the whole table: a stray space glyph (Calibri, 2 pt lower) lies across 「3.0」 in the 2026(F) row → pdfplumber words 「3」+「.0」 (glyphs touch: x1 406.6 / x0 406.5) → the row's number sequence differs",
                    "desktop_scope": "09:19 Rejected book: exactly 40 rows carry this reason, all 6143",
                    "handleall_color": "build of Handle-All v0113 put the --confirm hint into $col's REVIEW (the first REVIEW = '…' match) instead of $nx's → Write-Host -ForegroundColor 'Yellow · …' fails twice on REVIEW"},
        "base_package": {"name": "VRN2_Closeout_v0166 (launcher v0166 · runtime v0158)", "retained": "runtime v0158's 197 members byte-identical inside runtime v0159; every package member except launcher / runtime byte-identical to v0166"},
        "fixes": {"SystemManager_v0259": "thin tail over v0258: rows rejected with 「轉置表第三讀法(pdfplumber)對不上」 are grouped per table and asked again with v0236's _g3_trans on the pdfplumber lines with touching number fragments joined (gap <= 0.5 pt · left has a digit · decimal / thousands separator at the joint · result is a number token) · passing table → back to the annual book (VERIFY notes v0259) and the gap 「年度數據」 is cleared · failing / already in the book → stays in Rejected · recheck error → v0258 books stand",
                  "launcher_v0168": "runtime v0159 · manager v0259 · receipt VRN2_Closeout_v0168.json · selftest block v0168 (launcher number v0167 skipped)",
                  "RoundAll_v0124": "package v0168 · step 3 selftest runs manager v0259 · gap hint names 6143 / v0259",
                  "HandleAll_v0116": "v0115 pointed at RoundAll v0124 (vrn2_release_v0168) · auto: full when the last receipt is older than launcher v0168 · $col REVIEW = 'Yellow' again, the --confirm hint moved to $nx REVIEW"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"changed": True},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0123.py", "sha256": r165["roundall"]["sha256"], "status": "superseded 2026-11-02 (package v0166); file kept in vrn2_release_v0167"}],
        "roundall": {"name": "VRN2_RoundAll_v0124.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0124.md"},
        "handleall": {"name": "VRN2_HandleAll_v0116.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0116_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0168/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0168.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0168.py"]).hexdigest()},
        "results": {"status": "see VRN2_Verification_v0168.md"}}
(rel / "VRN2_Release_v0168.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
