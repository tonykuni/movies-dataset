"""v0168(冪等):Workbench v0103(右面板第一頁「00 系統現況」SUMMARY)→ runtime v0159 = v0158(全部成員逐位元組不動)+ VRN2_Workbench_v0103
→ 啟動器 v0168(只換 WORKBENCH / runtime / 收據名 / 自測一段)→ 套件 VRN2_Closeout_v0168.zip(其他成員跟 v0166 逐位元組相同)
→ RoundAll v0124(套件 v0168 · ⑤ 重渲染前先把 Workbench 鏈只增補放 · 收尾頁沒有 v0103 標記 → 重渲染)→ Handle-All v0116 → 開機檔 · 最短一行 · cmd 一行 → md · 發行清單。
取件分支:claude/vrn2-closeout-authorization-y4ixl7(這個對話推得到的分支)· 退路 main。vrn2_release_v0167 及更早不動。"""
import base64, hashlib, json, re, shutil, sys, zipfile
from pathlib import Path

S = Path("/tmp/claude-0/-home-user-movies-dataset/484f6e73-0cd5-53cb-a8dd-d4ee89d5500c/scratchpad")
W = S / "v168"; NEW, PKG, REL = W / "new", W / "pkg168", W / "release168"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
T167 = S / "t167" / "tools"
BR = "claude/vrn2-closeout-authorization-y4ixl7"
OLD_BR = "claude/optimistic-goodall-yhalc5"
sys.path.insert(0, str(T167))
from join_ps import join  # noqa: E402

for d in (PKG, REL):
    shutil.rmtree(d, ignore_errors=True); d.mkdir(parents=True)
DT = (2026, 11, 1, 0, 0, 0)


def zwrite(path, members, prefix=""):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            zi = zipfile.ZipInfo(prefix + n, date_time=DT); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])


sha = lambda b: hashlib.sha256(b).hexdigest()  # noqa: E731

# ---- ① 套件 v0166(倉裡的發行夾 · 雜湊照 v0166 發行清單)----
r166 = json.loads((REPO / "vrn2_release_v0166/VRN2_Release_v0166.json").read_text(encoding="utf-8"))
r167 = json.loads((REPO / "vrn2_release_v0167/VRN2_Release_v0167.json").read_text(encoding="utf-8"))
zp166 = REPO / "vrn2_release_v0166/VRN2_Closeout_v0166.zip"
assert sha(zp166.read_bytes()) == r166["package"]["sha256"]
with zipfile.ZipFile(zp166) as z:
    p166 = {n.split("/", 1)[1]: z.read(n) for n in z.namelist() if not n.endswith("/")}
m166 = json.loads(p166["PACKAGE_SHA256.json"])
for e in m166["files"]:
    assert sha(p166[e["path"]]) == e["sha256"], e["path"]

# ---- ② runtime v0159 = v0158 + Workbench v0103 ----
om = json.loads(p166["VRN2_Runtime_v0158.json"])
assert sha(p166["VRN2_Runtime_v0158.zip"]) == om["zip_sha256"]
import io  # noqa: E402
with zipfile.ZipFile(io.BytesIO(p166["VRN2_Runtime_v0158.zip"])) as z:
    members = {n: z.read(n) for n in [e["path"] for e in om["files"]]}
for e in om["files"]:
    assert sha(members[e["path"]]) == e["sha256"], e["path"]
n_old = len(members)
NEWM = ["VRN2_Workbench_v0103.py"]
assert all(n not in members for n in NEWM) and "VRN2_Workbench_v0102.py" in members and "VRN2_Workbench_v0101.py" in members and "VRN2_Workbench_Assets_v0100.zip" in members
members["VRN2_Workbench_v0103.py"] = (NEW / "VRN2_Workbench_v0103.py").read_bytes()
rz = PKG / "VRN2_Runtime_v0159.zip"
zwrite(rz, members)
rman = {"system": "VRN-2", "version": "v0159", "zip_sha256": sha(rz.read_bytes()), "based_on": "VRN2_Runtime_v0158.zip " + om["zip_sha256"], "retained_members": n_old, "new_members": NEWM,
        "files": [{"path": n, "sha256": sha(members[n])} for n in sorted(members)]}
(PKG / "VRN2_Runtime_v0159.json").write_text(json.dumps(rman, ensure_ascii=False, indent=1), encoding="utf-8")

# ---- ③ 啟動器 v0168 = v0166 + Workbench v0103 · runtime v0159 ----
s = p166["ActivateVRN-2_v0166.py"].decode("utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0166: v0164 entry + manager VRN_SystemManager_v0258', '''"""VRN-2 v0168: v0166 entry + Workbench VRN2_Workbench_v0103 (right panel page 00 "系統現況" SUMMARY). Operator 2026-11-01 uploaded
taiwan_stock_data_matrix.html: "shows the fetch endpoints but no DataFrame headers · put a system-status SUMMARY as the first page of the right panel
for VRN-2 / VDF / VCGC · keep the current U/I as the base · lock the attachment's layout and type scale · do not change the existing functions".
 - Page 00 (default on open): VRN-2 output books matrix (table · source · endpoint · the real DataFrame headers of each book · lamp), this run's
   step matrix, and a read-only matrix of the other systems (VCGC's own handoff lamp · VDF self-report if present · VRN-1 registered entry only).
 - Layout / type scale from the attachment (badge · 22 px title · mono subline · right stats · legend filter · section titles · click a row for
   details · summary cards); colours and fonts stay the locked template's. Tabs 01 – 04 are byte-identical to v0102 (self-test strips v0103 → equal).
 Runtime v0159 = runtime v0158 (all members byte-identical) + VRN2_Workbench_v0103. Receipt VRN2_Closeout_v0168.json. No v0167 launcher (release
 folder v0167 only replaced RoundAll). The books are unchanged (manager v0258), so a repair round only re-renders the Workbench.

VRN-2 v0166: v0164 entry + manager VRN_SystemManager_v0258''')
rep('VERSION = "ActivateVRN-2 v0166"', 'VERSION = "ActivateVRN-2 v0168"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0158.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0159.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0158.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0159.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0166.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0168.json"')
rep('WORKBENCH = "VRN2_Workbench_v0102.py"', 'WORKBENCH = "VRN2_Workbench_v0103.py"   # v0168: page 00 系統現況 SUMMARY over v0102 (v0102 byte-identical · PRIOR)')
rep('''    assert MANAGER == "VRN_SystemManager_v0258.py"
''', '''    assert MANAGER == "VRN_SystemManager_v0258.py"
    w103 = selftest_source("VRN2_Workbench_v0103.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0103"' in w103 and 'PRIOR_NAME = "VRN2_Workbench_v0102.py"' in w103 and "def summary_section(" in w103 and "def _strip_v0103(" in w103
    assert WORKBENCH == "VRN2_Workbench_v0103.py"
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            wbs = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN2_Workbench_v\\d{4}\\.py", n))
        assert wbs[-1] == "VRN2_Workbench_v0103.py" and "VRN2_Workbench_v0102.py" in wbs and "VRN2_Workbench_v0101.py" in wbs and "VRN2_Workbench_v0100.py" in wbs, wbs
''')
rep('''    print("[PASS] v0166: manager v0258 is the active manager''', '''    print("[PASS] v0168: Workbench v0103 is the active Workbench (page 00 系統現況 SUMMARY first and open by default · output books × source × endpoint × real DataFrame headers · step matrix · other systems read-only) · v0102 kept as PRIOR (tabs 01 – 04 unchanged)")
    print("[PASS] v0166: manager v0258 is the active manager''')
rep('return lamp, detail + " · launcher v0166"', 'return lamp, detail + " · launcher v0168"')
rep('note="VRN-2 private runtime; exact ship v0158 (launcher v0166 · no MOPS', 'note="VRN-2 private runtime; exact ship v0159 (launcher v0168 · Workbench v0103 page 00 summary · no MOPS')
rep('print("NEXT: [%s] VRN-2 v0166 · rc %s', 'print("NEXT: [%s] VRN-2 v0168 · rc %s')
(PKG / "ActivateVRN-2_v0168.py").write_text(s, encoding="utf-8", newline="\n")
launcher = s.encode("utf-8")

# ---- ④ 套件 v0168 ----
keep = ["ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: p166[n] for n in keep}
files["ActivateVRN-2_v0168.py"] = launcher
files["VRN2_Runtime_v0159.zip"] = rz.read_bytes()
files["VRN2_Runtime_v0159.json"] = (PKG / "VRN2_Runtime_v0159.json").read_bytes()
files["README.txt"] = ("VRN2_Closeout_v0168 — VRN-2 closeout package (2026-11-01 · Workbench v0103: right panel page 00 系統現況 SUMMARY)\n\n"
  "Entry: python ActivateVRN-2_v0168.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0124.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0116.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0159.zip = v0158 (all members byte-identical) + VRN2_Workbench_v0103.\n\n"
  "v0168 (operator 2026-11-01 uploaded taiwan_stock_data_matrix.html): the Workbench opens on a new page 00 'system status' — output books with\n"
  " source, endpoint and the real DataFrame headers of each book, this run's steps, and the other systems read-only (VCGC / VDF / VRN-1); layout and\n"
  " type scale follow the attachment, colours and fonts stay the locked template's; tabs 01 - 04 unchanged. Books unchanged (manager v0258).\n"
  "v0166: manager v0258 table repair · v0164: TARGET_PRICE(ADJ) sync · store MOPS rows purged · v0163: no MOPS.\n"
  "Verification: see VRN2_Verification_v0168.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0168.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0168", "files": [{"path": n, "sha256": sha(files[n])} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = REL / "VRN2_Closeout_v0168.zip"
zwrite(zpr, files, "VRN2_Closeout_v0168/")
want = sha(zpr.read_bytes())
for n in keep:
    assert sha(files[n]) == {e["path"]: e["sha256"] for e in m166["files"]}[n], n

# ---- ⑤ RoundAll v0124 = v0123 + 套件 v0168 + ⑤ Workbench 鏈補放 + 收尾頁沒有 v0103 標記 → 重渲染 ----
src = (REPO / "vrn2_release_v0167/VRN2_RoundAll_v0123.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0123'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0123 — ', '"""VRN2_RoundAll v0124 — ', 1)
at = doc.index("v0123(")
doc = doc[:at] + '''v0124(操作員 2026-11-01 上傳 taiwan_stock_data_matrix.html:「右面板第一頁放系統現況 SUMMARY · 含 DATAFRAME HEADERS · 原有功能設定不改 · 視覺鎖定更新」):
  · 套件 v0168(啟動器 v0168 · runtime v0159 = v0158 全部成員不動 + VRN2_Workbench_v0103「00 系統現況」)· 輸出冊不變(管理器 v0258)。
  · ⑤ 自動修:Workbench 重渲染前先把套件 runtime 的 Workbench 鏈(v0100 ~ v0103 + 字型資產包)只增不覆寫地補放進 functional modules\\\\VRN2
    (核對清單雜湊 · 同名不同內容不覆寫)· 收尾頁 VRN2_Workbench_latest.html 沒有 v0103 標記 → 計畫加「Workbench 重渲染」(repair 幾分鐘 · 不整輪)。
  · ③ 自測改跑 Workbench v0103(它先渲染 v0102 再比對:拿掉 v0103 的部分 = v0102 頁面逐字相同)。
  · 取件分支 claude/vrn2-closeout-authorization-y4ixl7(退路 main)。自測 90 項(v0123 的 89 項 + 88)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0123.py", "用法:python VRN2_RoundAll_v0124.py")
s = head + doc + body
rep('VERSION = "v0123"', 'VERSION = "v0124"')
rep('PACKAGE = "VRN2_Closeout_v0166"', 'PACKAGE = "VRN2_Closeout_v0168"')
s = re.sub(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', 'PACKAGE_SHA256 = "%s"' % want, s, count=1)
rep('# 建置時填入 VRN2_Closeout_v0166.zip 的 SHA-256', '# 建置時填入 VRN2_Closeout_v0168.zip 的 SHA-256')
rep('RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166"', 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168"')
rep('RELEASE_JSON = "VRN2_Release_v0166.json"', 'RELEASE_JSON = "VRN2_Release_v0168.json"')
rep('LAUNCHER = "ActivateVRN-2_v0166.py"', 'LAUNCHER = "ActivateVRN-2_v0168.py"')
rep('BRANCH = "%s"' % OLD_BR, 'BRANCH = "%s"   # v0124 這個對話推得到的分支(退路 main)' % BR)
rep('RECEIPT = "VRN2_Closeout_v0166.json"', 'RECEIPT = "VRN2_Closeout_v0168.json"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0158.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0159.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0158.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0159.json"')
rep('and "vrn2/VRN2_Closeout_v0166.before_roundall.json" in names', 'and "vrn2/" + Path(RECEIPT).stem + ".before_roundall.json" in names')
rep('and LAUNCHER == "ActivateVRN-2_v0166.py" and PACKAGE == "VRN2_Closeout_v0166")', 'and LAUNCHER >= "ActivateVRN-2_v0166.py" and PACKAGE >= "VRN2_Closeout_v0166")')
rep('PACKAGE == "VRN2_Closeout_v0166" and LAUNCHER == "ActivateVRN-2_v0166.py" and RUNTIME_ZIP == "VRN2_Runtime_v0158.zip"\n            and ("VRN2_OutputStore_v0102.py", 300)',
    'PACKAGE >= "VRN2_Closeout_v0166" and LAUNCHER >= "ActivateVRN-2_v0166.py" and RUNTIME_ZIP >= "VRN2_Runtime_v0158.zip"\n            and ("VRN2_OutputStore_v0102.py", 300)')
rep('PACKAGE == "VRN2_Closeout_v0166" and LAUNCHER == "ActivateVRN-2_v0166.py" and RUNTIME_ZIP == "VRN2_Runtime_v0158.zip" and RECEIPT == "VRN2_Closeout_v0166.json"\n            and RELEASE_REL.endswith("/vrn2_release_v0166")',
    'PACKAGE >= "VRN2_Closeout_v0166" and LAUNCHER >= "ActivateVRN-2_v0166.py" and RUNTIME_ZIP >= "VRN2_Runtime_v0158.zip" and RECEIPT >= "VRN2_Closeout_v0166.json"\n            and RELEASE_REL[-4:] >= "0166"')
rep('PACKAGE == "VRN2_Closeout_v0166" and "VRN2_HumanConfirm.json" in PASTE_FILES', 'PACKAGE >= "VRN2_Closeout_v0166" and "VRN2_HumanConfirm.json" in PASTE_FILES')
rep('SELFTESTS = (("VRN2_Workbench_v0102.py", 600),', 'SELFTESTS = (("VRN2_Workbench_v0103.py", 600),')
rep('PASTE_FILES = ("VRN2_Closeout_v0166.json", "VRN2_Closeout_v0166.before_roundall.json",', 'PASTE_FILES = ("VRN2_Closeout_v0168.json", "VRN2_Closeout_v0168.before_roundall.json", "VRN2_Closeout_v0166.json", "VRN2_Closeout_v0166.before_roundall.json",')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0123.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0123.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0124.py"', n_dl)
rep('"VRN2_RoundAll_v0123.py" in html_', '"VRN2_RoundAll_v0124.py" in html_')
rep("· v0122 起 88 項 · v0123 起 89 項。", "· v0122 起 88 項 · v0123 起 89 項 · v0124 起 90 項。")
rep('''    wb = v2 / "VRN2_Workbench_latest.html"
    if plan or not wb.is_file():''', '''    wb = v2 / "VRN2_Workbench_latest.html"
    if plan or not wb.is_file() or WORKBENCH_TAG not in _head_text(wb):   # v0124 收尾頁還是 v0103 以前渲染的 → 重渲染''')
rep('''        elif key == "workbench":
            wb = _latest_in(rt, "VRN2_Workbench_v[0-9][0-9][0-9][0-9].py")''', '''        elif key == "workbench":
            placed = [install_runtime_member(state.get("pkg"), root, n) for n in WORKBENCH_CHAIN] if state.get("pkg") else []   # v0124 Workbench 鏈只增補放
            refused = [why for dest, why in placed if dest is None]
            wb = _latest_in(rt, "VRN2_Workbench_v[0-9][0-9][0-9][0-9].py")''')
rep('''                lamp, detail = _cli_lamp(lines)
            else:
                lamp, detail = "YELLOW", "私有 runtime 沒有 VRN2_Workbench_v*.py"''', '''                lamp, detail = _cli_lamp(lines)
                if refused:
                    lamp, detail = ("YELLOW" if lamp == "GREEN" else lamp), detail + " · Workbench 鏈沒補放:" + "; ".join(refused)[:160]
            else:
                lamp, detail = "YELLOW", "私有 runtime 沒有 VRN2_Workbench_v*.py"''')
rep('''def market_fetch_sec() -> int:''', '''WORKBENCH_CHAIN = ("VRN2_Workbench_Assets_v0100.zip", "VRN2_Workbench_v0100.py", "VRN2_Workbench_v0101.py", "VRN2_Workbench_v0102.py", "VRN2_Workbench_v0103.py")
WORKBENCH_TAG = "<!-- VRN2_Workbench v0103 over v0102 -->"


def _head_text(path, n: int = 65536) -> str:
    """v0124 收尾頁前 n 字(Workbench 版本標記在 <title> 後面)。讀不到 → 空字串(= 要重渲染)。"""
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            return handle.read(n)
    except OSError:
        return ""


def market_fetch_sec() -> int:''')
rep('''        chk("87 v0123:''', '''        with tempfile.TemporaryDirectory() as t88:
            r88 = Path(t88); (r88 / "VIA_Reports" / "vrn2").mkdir(parents=True)
            w88 = r88 / "VIA_Reports" / "vrn2" / "VRN2_Workbench_latest.html"
            w88.write_text("<title>VRN-2 Workbench</title><!-- VRN2_Workbench v0102 over v0101 -->", encoding="utf-8")
            a88 = type("A", (), {"integrate": "skip"})()
            p_old = [k for k, _ in plan_fixes(r88, {"steps": []}, None, a88)]
            w88.write_text("<title>VRN-2 Workbench</title>" + WORKBENCH_TAG, encoding="utf-8")
            p_new = [k for k, _ in plan_fixes(r88, {"steps": []}, None, a88)]
        chk("88 v0124:收尾頁還是 v0102 渲染的 → 計畫只有「Workbench 重渲染」(repair · 不整輪)· 已是 v0103 → 不重渲染 · Workbench 鏈 5 檔(資產包 + v0100 ~ v0103)· 套件 v0168 · 自測跑 v0103",
            p_old == ["workbench"] and p_new == [] and WORKBENCH_CHAIN[-1] == "VRN2_Workbench_v0103.py" and len(WORKBENCH_CHAIN) == 5 and PACKAGE == "VRN2_Closeout_v0168"
            and SELFTESTS[0] == ("VRN2_Workbench_v0103.py", 600) and _head_text(Path(t88) / "none.html") == "")
        chk("87 v0123:''')
(REL / "VRN2_RoundAll_v0124.py").write_text(s, encoding="utf-8", newline="\n")
ra = s; ra_sha = sha(ra.encode("utf-8"))

# ---- ⑥ Handle-All v0116 · 開機檔 · 最短一行 · cmd 一行 ----
ha = (T167 / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rh(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rh("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0167'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168'")
rh("$F = 'VRN2_RoundAll_v0123.py'", "$F = 'VRN2_RoundAll_v0124.py'")
rh("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rh("Handle-All v0115", "Handle-All v0116", ha.count("Handle-All v0115"))
rh("'%s', 'main'" % OLD_BR, "'%s', 'main'" % BR)
rh("套件 v0166 裝在新夾 VRN2_Closeout_v0166", "套件 v0168 裝在新夾 VRN2_Closeout_v0168")
rh("取套件 v0166", "取套件 v0168", 2)
rh("跑啟動器 v0166(", "跑啟動器 v0168(Workbench v0103 · ")
rh("套件 v0166 的 IndependentVerifier", "套件 v0168 的 IndependentVerifier")
assert OLD_BR not in ha and "v0123" not in ha and "v0115" not in ha and "exit" not in ha.replace("Exception", "")
ha_line = join(ha); ha_sha = sha(ha_line.encode("utf-8"))
(REL / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n")
bt = (T167 / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0167", "vrn2_release_v0168"), ("VRN2_HandleAll_v0115.md", "VRN2_HandleAll_v0116.md"), ("Handle-All v0115 SHA-256 OK", "Handle-All v0116 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha), ("'%s', 'main'" % OLD_BR, "'%s', 'main'" % BR)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = sha(bt_line.encode("ascii"))
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(REL / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n")
(REL / "VRN2_HandleAll_v0116_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin %s;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0168/VRN2_HandleAll_v0116_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % (BR, bt_sha)
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(REL / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n"); (REL / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")
# 開機行雜湊照 PowerShell 的算法(逐字元取低位元組)再核一次
assert sha(bytes(ord(c) & 0xFF for c in bt_line)) == bt_sha

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0116(2026-11-01 · Workbench v0103「00 系統現況」· 套件 v0168 · RoundAll v0124)

操作員 2026-11-01 上傳 `taiwan_stock_data_matrix.html`:右面板第一頁放**系統現況 SUMMARY**(含每本輸出冊的 **DataFrame 表頭**)· 以目前 U/I 為基礎 · 版面與字體階層照附件 · 原有功能不改。

| 項目 | 現在 |
|---|---|
| Workbench v0103 | 右面板最前面多「00 系統現況」(開頁預設):輸出冊 × 來源 × 端點 × 真實欄名 × 燈 · 本輪步驟 · 其他系統只讀互看(VCGC 自報燈 · VDF 自報收據 · VRN-1 入口)· 點一列看全部欄 · 圖例篩選 · 01 ~ 04 不動 |
| 視覺 | 版面 / 字體階層照附件(徽章 · 22px 標題 · 等寬副標 · 右上統計 · 區標 · 矩陣 · 摘要卡)· 色盤與字型仍是範本鎖定的 |
| 輸出冊 | 不變(管理器 v0258)|
| 自動選模式 | 收據已是 v0166 → **repair**(幾分鐘 · ⑤ 只補放 Workbench 鏈並重渲染)|
| 套件 | `vrn2_release_v0168/VRN2_Closeout_v0168.zip`(SHA-256 `%s` · 啟動器 v0168 · runtime v0159)|
| 一支 Python | `VRN2_RoundAll_v0124.py`(SHA-256 `%s` · 自測 90 項)|
| 取件分支 | `%s`(退路 main)|

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定)· 第 2 行 = 下面 PowerShell 那一行的編碼版(一樣核對 SHA-256 才執行)。

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0124.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0124.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0116 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0124 `%s`)。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], BR, len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(REL / "VRN2_HandleAll_v0116.md").write_text(md, encoding="utf-8", newline="\n")
(REL / "VRN2_RoundAll_v0124.md").write_text("""# VRN-2 一支 Python · VRN2_RoundAll_v0124.py(套件 v0168 · Workbench v0103「00 系統現況」)

`VRN2_RoundAll_v0124.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0123 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0168/VRN2_Closeout_v0168.zip`(SHA-256 `%s` · 本檔內已釘)· 啟動器 v0168 · runtime v0159 = v0158 全部成員不動 + VRN2_Workbench_v0103 |
| ⑤ 自動修 | Workbench 重渲染前先把套件 runtime 的 Workbench 鏈(資產包 + v0100 ~ v0103)只增不覆寫地補放 · 收尾頁沒有 v0103 標記 → 計畫加「Workbench 重渲染」|
| ③ 自測 | 改跑 Workbench v0103(先渲染 v0102 再比:拿掉 v0103 的部分 = v0102 頁面逐字相同)|
| 取件分支 | `%s`(退路 main)|

`--confirm` 照舊只有操作員親手打才記。自測 90 項(v0123 的 89 項 + 88)。
""" % (ra_sha[:12], want[:12], BR), encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0168 (Workbench v0103 · runtime v0159) + VRN2_RoundAll_v0124 + VRN2_HandleAll_v0116", "date": "2026-11-01",
        "trigger": "操作員 2026-11-01 上傳 taiwan_stock_data_matrix.html:右面板第一頁系統現況 SUMMARY(含 DATAFRAME HEADERS)供 VRN-2 / VDF / VCGC 參考 · 以目前 U/I 為基礎 · 版面與字體階層視覺鎖定 · 原有功能設定不改",
        "base_package": {"name": "VRN2_Closeout_v0166 (launcher v0166 · runtime v0158)", "retained": "runtime v0158's %d members byte-identical inside runtime v0159; every package member except launcher / runtime byte-identical to v0166" % n_old},
        "fixes": {"Workbench_v0103": "thin tail over v0102: page 00 系統現況 first and open by default · output books × source × endpoint × real DataFrame headers × lamp · step matrix · other systems read-only (VCGC handoff lamp · VDF self-report if present · VRN-1 entry) · detail panel with every header (bilingual names from v0102) · legend filter · summary cards · phone width one card per row · tabs 01 – 04 byte-identical (self-test strips v0103 → equal to v0102)",
                  "launcher_v0168": "WORKBENCH v0103 · runtime v0159 · receipt VRN2_Closeout_v0168.json · selftest block v0168",
                  "RoundAll_v0124": "package v0168 · step 5 places the Workbench chain from the package runtime (only-add · hash-checked) before re-rendering · re-render when the page lacks the v0103 marker · selftest runs Workbench v0103 · fetch branch %s (fallback main)" % BR,
                  "HandleAll_v0116": "points at RoundAll v0124 (vrn2_release_v0168) · branch %s then main · auto stays repair when the last receipt is v0166+" % BR},
        "freeze": "VRN2_FreezeLock_v0100 → v0101 (operator order 2026-11-01 = unlock for this U/I change · re-locked on the new versions)",
        "components": [{"path": n, "sha256": sha(files[n]), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rman[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"changed": True},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0123.py", "sha256": r167["roundall"]["sha256"], "status": "superseded 2026-11-01 (package v0166); file kept in vrn2_release_v0167"}],
        "roundall": {"name": "VRN2_RoundAll_v0124.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0124.md"},
        "handleall": {"name": "VRN2_HandleAll_v0116.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0116_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line), "branch": BR},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0168/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0168.py", "sha256": sha(launcher)},
        "results": {"status": "see VRN2_Verification_v0168.md"}}
(REL / "VRN2_Release_v0168.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("runtime v0159", len(members), rman["zip_sha256"][:12], "· launcher", sha(launcher)[:12], "· package", want[:12], "· roundall", ra_sha[:12],
      "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
