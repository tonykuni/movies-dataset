const { chromium } = require('playwright');
(async () => {
  const f = process.argv[2], S = process.argv[3];
  const b = await chromium.launch(); const errs = [];
  const p = await b.newPage({ viewport: { width: 1440, height: 1000 } }); p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
  await p.goto('file://' + f); await p.waitForTimeout(600);
  const active = await p.$eval('.tabs button.active', e => e.textContent.trim());
  const onSec = await p.$eval('.tabsec.on', e => e.getAttribute('data-tab'));
  await p.screenshot({ path: S + '/s_top.png' });
  await p.click('.sm-row[data-kind="book"][data-i="1"] .sm-c'); await p.waitForTimeout(300);
  const det = await p.$eval('#smDetailT', e => e.textContent); const detRows = await p.$$eval('#smDetailB tbody tr', r => r.length);
  await p.screenshot({ path: S + '/s_detail.png' });
  await p.keyboard.press('Escape'); const hidden = await p.$eval('#smDetail', e => e.hidden);
  await p.click('.sm-leg[data-src="TWSE"]'); await p.waitForTimeout(200);
  const dim = await p.$$eval('.sm-row', r => [r.length, r.filter(x => x.classList.contains('dim')).length]);
  await p.click('.sm-leg[data-src="all"]');
  await p.evaluate(() => document.querySelector('#sysmatrix').scrollIntoView()); await p.mouse.wheel(0, 700); await p.waitForTimeout(200);
  await p.screenshot({ path: S + '/s_lower.png' });
  const tabs = {};
  for (const t of ['overview', 'data', 'export', 'handover', 'summary']) { await p.click(`.tabs button[data-tab="${t}"]`); await p.waitForTimeout(150); tabs[t] = await p.$eval('.tabsec.on', e => e.getAttribute('data-tab')); }
  await p.click('.tabs button[data-tab="data"]'); const dataRows = await p.$$eval('.tabsec.on table tbody tr', r => r.length);
  const m = await b.newPage({ viewport: { width: 390, height: 844 } }); m.on('pageerror', e => errs.push('m:' + e.message));
  await m.goto('file://' + f); await m.waitForTimeout(500);
  const ov = await m.evaluate(() => [document.documentElement.scrollWidth, window.innerWidth]);
  await m.screenshot({ path: S + '/s_mobile.png', fullPage: false });
  console.log(JSON.stringify({ active, onSec, det, detRows, hidden, dim, tabs, dataRows, mobileScroll: ov, errs }));
  await b.close();
})();
