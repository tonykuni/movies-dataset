VRN2_Closeout_v0168 — VRN-2 closeout package (2026-11-02 · manager v0259: transposed tables re-asked with joined number fragments)

Entry: python ActivateVRN-2_v0168.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0124.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0116.md (same release folder).
Runtime: VRN2_Runtime_v0159.zip = v0158 (197 members byte-identical) + VRN_SystemManager_v0259.

v0168 (operator 2026-11-02 uploaded 華南投顧-6143): its annual table (years as rows · 40 values) was rejected by the transposed-table third-reader
 gate because pdfplumber splits 「3.0」 into 「3」+「.0」 at a stray space glyph of another font (the glyphs touch). Manager v0259 asks the same gate
 again for rows rejected that way, with touching number fragments joined (gap <= 0.5 pt · decimal / thousands separator · result is a number);
 a passing table returns to the annual book, a failing one stays in Rejected. Launcher number v0167 is skipped (no launcher v0167).
v0166: manager v0258 table repair (half-line labels · two-level period header). v0164: TARGET_PRICE(ADJ) sync · store MOPS purge. v0163: no MOPS.
Verification: see VRN2_Verification_v0168.md. Hashes: PACKAGE_SHA256.json.
