VRN2_Closeout_v0168 — VRN-2 closeout package (2026-11-01 · Workbench v0103: right panel page 00 系統現況 SUMMARY)

Entry: python ActivateVRN-2_v0168.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0124.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0116.md (same release folder).
Runtime: VRN2_Runtime_v0159.zip = v0158 (all members byte-identical) + VRN2_Workbench_v0103.

v0168 (operator 2026-11-01 uploaded taiwan_stock_data_matrix.html): the Workbench opens on a new page 00 'system status' — output books with
 source, endpoint and the real DataFrame headers of each book, this run's steps, and the other systems read-only (VCGC / VDF / VRN-1); layout and
 type scale follow the attachment, colours and fonts stay the locked template's; tabs 01 - 04 unchanged. Books unchanged (manager v0258).
v0166: manager v0258 table repair · v0164: TARGET_PRICE(ADJ) sync · store MOPS rows purged · v0163: no MOPS.
Verification: see VRN2_Verification_v0168.md. Hashes: PACKAGE_SHA256.json.
