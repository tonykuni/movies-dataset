VRN2_Closeout_v0149 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0149.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0102.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.
Runtime: VRN2_Runtime_v0149.zip = runtime v0148 (181 members byte-identical) + VRN2_VerbatimVerifier_v0105 + VRN2_IndependentVerifier_v0111 + VRN2_MarketFetchRun_v0100,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0149 (desktop run of VRN2_RoundAll_v0101 · 2026-10-29 17:01 · red 4 · yellow 11):
 - closeout gate VerbatimVerifier v0105 (thin tail over v0104, both in the package): 3014TT-20231005.pdf point 3 was the only FAIL (closeout rc 1). PDFium writes a
   line-end hyphen as U+FFFE and drops the line break ("Type\ufffeC"); the excerpt has "Type-" + newline + "C". v0105 compares both as the same text.
 - step 11 IndependentVerifier v0111: v0110 with its excerpt reader on VerbatimVerifier v0105.
 - step 6e MarketFetchRun v0100: MarketFetch v0112's own fetch_python() took envs/via_tw_fetch (nothing installed) although the launcher gave it via_core_312.
   The runner replaces only that function with the first Python passing the VDF engine's own dependency check (bounds read from the engine file); none → no engine start (no pip).
Verification: see VRN2_Verification_v0149.md. Hashes: PACKAGE_SHA256.json.
