#!/bin/bash
# v0149 放進倉:docs/handoff/ai/vrn2_release_v0149/ + vrn1_vrn2_oneclick_v0110/(固定時間戳 · 冪等)· 新成員只在私有 runtime zip 與 test tools zip
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v149
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0149; OP=$REPO/vrn1_vrn2_oneclick_v0110; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v149")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0149"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0110")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("ra149_first.log", "ra149_fix.log", "ra149.rc", "t149_setup.log", "mk_market149.log", "pscheck149.log", "scen149.rc", "scen149_first.log", "scen149_again.log", "scen149_tamper.log", "scen149_setup.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0149_selftest.log", "ActivateVRN-2_v0149_selftest_iso.log", "roundall102_selftest.log", "VRN2_VerbatimVerifier_v0105_selftest.log", "VRN2_IndependentVerifier_v0111_selftest.log", "VRN2_MarketFetchRun_v0100_selftest.log",
                                 "vv_regress149.log", "repro_marketfetch149.log", "repro_syntaxwarning149.log", "run_roundall149.sh", "scen149.sh", "repro149.sh", "drive149.sh")]
logs += [("release/oneline_roundall_pwsh.txt", W / "release149" / "oneline_roundall_pwsh.txt"), ("release/oneline_roundall.txt", W / "release149" / "oneline_roundall.txt"), ("release/boot_roundall.ps1", W / "release149" / "boot_roundall.ps1")]
v2 = W / "t149/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0149.json", "VRN2_Closeout_v0149.before_roundall.json", "VRN2_RoundAll_latest.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Output_Config.json", "VRN2_Phase_Timing_latest.json", "VRN2_HistoryAlign_latest.json", "VRN2_Integrate_latest.json", "consensus/VRN2_Consensus_latest.json", "consensus/factset_yfinance_consensus_quality_matrix.csv", "market/VRN2_Market_latest.json", "output/VRN2_Combined_latest.csv", "output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "VRN2_Workbench_latest.html", "VRN2_FailEvidence_latest.json"):
    logs.append(("t149/" + n, v2 / n))
z(D / "logs_v0149.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))] + [("release/" + q.name, q) for q in (W / "release149" / "boot_roundall.ps1", W / "release149" / "oneline_roundall.txt", W / "release149" / "oneline_roundall_pwsh.txt", W / "release149" / "Run-VRN2-v0149.ps1", W / "release149" / "boot149.ps1")]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py")) if q.name in ("VRN2_VerbatimVerifier_v0105.py", "VRN2_IndependentVerifier_v0111.py", "VRN2_MarketFetchRun_v0100.py", "ActivateVRN-2_v0149.py", "VRN2_RoundAll_v0102.py")]
z(D / "vrn2_test_tools_v0149.zip", tools)
z(OP / "tools_v0110.zip", [("tools/" + q.name, q) for q in (W / "operator110" / "boot_pair110.ps1", W / "operator110" / "oneline_pair110.txt", W / "operator110" / "Run-VRN1-VRN2-v0110.ps1")])
for n in ("VRN1_VRN2_OneClick_v0110.md", "VRN1_VRN2_Verification_v0110.md"): shutil.copy(W / "operator110" / n, OP / n)
for n in ("VRN2_Closeout_v0149.zip", "VRN2_Release_v0149.json", "VRN2_OneClick_v0149.md", "VRN2_Verification_v0149.md", "VRN2_RoundAll_v0102.py", "VRN2_RoundAll_v0102.md"): shutil.copy(W / "release149" / n, D / n)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
