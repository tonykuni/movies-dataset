"""ActivateVRN-2_v0149.py = v0148 + VerbatimVerifier v0105 · ⑥e MarketFetchRun v0100(桌機 2026-10-29 17:01 RoundAll v0101 貼回)。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v148/new/ActivateVRN-2_v0148.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0148: v0147 entry + fixes from the first desktop run of VRN2_RoundAll_v0100 (2026-10-29 14:40 · red 4 · yellow 10).',
    '"""VRN-2 v0149: v0148 entry + fixes from the desktop run of VRN2_RoundAll_v0101 (2026-10-29 17:01 · red 4 · yellow 11).\n\n'
    ' - closeout gate VRN2_VerbatimVerifier_v0105 (thin tail over v0104, which stays next to it): 3014TT-20231005.pdf point 3 was the only FAIL and the reason for\n'
    '   rc 1. The stored excerpt (pdfplumber) ends a line with "Type-" and goes on with "C PD"; PDFium writes that line-end hyphen as U+FFFE and drops the line break.\n'
    '   v0104 only joined "-" + newline before a lowercase letter and did not know U+FFFE. v0105 compares U+FFFE as "-" + newline and drops "-" + newline before any\n'
    '   character on both sides (comparison form only; stored excerpts unchanged). Reproduced in the container with a generated PDF: v0104 FAIL, v0105 PASS.\n'
    ' - step 11 VRN2_IndependentVerifier_v0111 (latest in the runtime, picked by the base as before): v0110 with its excerpt reader on VerbatimVerifier v0105.\n'
    ' - step 6e VRN2_MarketFetchRun_v0100: the desktop gave MarketFetch v0112 envs/via_core_312 (all packages present), but MarketFetch\'s own fetch_python()\n'
    '   returns envs/via_tw_fetch whenever that folder exists; it has no packages, so the fetch said "擷取環境缺套件" (and the VDF engine\'s bootstrap pip had failed\n'
    '   there before). The runner loads the shared MarketFetch from its own file (read-only, unchanged), replaces only its fetch_python() with the first Python\n'
    '   that passes the VDF engine\'s own dependency check (same modules, same >= / < bounds read from the engine file, Python 3.11+), and runs MarketFetch.main;\n'
    '   when none passes, --fetch stays YELLOW with what each candidate misses and the engine is not started (no pip), --fill runs with a Python that has\n'
    '   pandas + pyarrow. Without the runner in the runtime, 6e runs MarketFetch directly as v0148 did.\n'
    ' Runtime v0149 = runtime v0148 (181 members byte-identical) + VRN2_VerbatimVerifier_v0105 + VRN2_IndependentVerifier_v0111 + VRN2_MarketFetchRun_v0100.\n\n'
    'v0148: v0147 entry + fixes from the first desktop run of VRN2_RoundAll_v0100 (2026-10-29 14:40 · red 4 · yellow 10).')
rep('VERSION = "ActivateVRN-2 v0148"', 'VERSION = "ActivateVRN-2 v0149"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0148.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0149.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0148.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0149.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0148.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0149.json"')
rep('VERBATIM = "VRN2_VerbatimVerifier_v0104.py"', 'VERBATIM = "VRN2_VerbatimVerifier_v0105.py"   # v0149: thin tail over v0104 (line-end hyphen · U+FFFE) · v0104 stays next to it')
rep('MARKET_FETCH_GLOB = "VRN2_MarketFetch_v[0-9][0-9][0-9][0-9].py"   # borrowed from the shared desktop-line folder functional modules/VRN (read-only · latest number)',
    'MARKET_FETCH_GLOB = "VRN2_MarketFetch_v[0-9][0-9][0-9][0-9].py"   # borrowed from the shared desktop-line folder functional modules/VRN (read-only · latest number)\n'
    'MARKET_RUNNER = "VRN2_MarketFetchRun_v0100.py"   # v0149: runs the borrowed MarketFetch with a Python that passes the VDF engine\'s own dependency check')
rep('launcher = root / "package" / "ActivateVRN-2_v0148.py"', 'launcher = root / "package" / "ActivateVRN-2_v0149.py"')
rep('return lamp, detail + " · launcher v0148"', 'return lamp, detail + " · launcher v0149"')
rep('print("NEXT: [%s] VRN-2 v0148 · rc %s', 'print("NEXT: [%s] VRN-2 v0149 · rc %s')

# ⑥e: pick the fetch Python with the runner
rep('''def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:''', r'''def pick_market_python(runner: Path, tool: Path, preferred: str) -> dict:
    """v0149: ask VRN2_MarketFetchRun which Python passes the VDF engine's own dependency check (same modules · same bounds · Python 3.11+) · nothing installed."""
    try:
        done = subprocess.run([sys.executable, "-X", "utf8", str(runner), "--tool", str(tool), "--python", preferred, "--pick-python"], capture_output=True, text=True,
                              encoding="utf-8", errors="replace", timeout=900, cwd=str(runner.parent))
        got = json.loads((done.stdout.strip().splitlines() or ["{}"])[-1])
    except Exception as error:  # noqa: BLE001
        got = {"python": None, "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    rows = [{k: row.get(k) for k in ("python", "how", "ok", "py_version", "missing", "import_failed")} for row in got.get("candidates") or []]
    got = {"python": got.get("python"), "fill_python": got.get("fill_python"), "requirements_from": got.get("requirements_from", ""), "why": got.get("why", ""),
           "candidates": rows, "skipped": got.get("skipped") or []}
    if got["python"]:
        print("[計] ⑥e 擷取 Python · %s · 合 VDF 引擎版本界線(%s)" % (got["python"], got["requirements_from"]), flush=True)
    else:
        print("[計] ⑥e 擷取 Python · 沒有合 VDF 引擎版本界線的 · 不啟動引擎 · %s" % got["why"][:500], flush=True)
    return got


def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:''')
rep('''        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        fetch_py = market_python()
        results = {}
        for verb in ("--fetch", "--fill"):
            command = [fetch_py, "-X", "utf8", str(tool), verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)]''',
    '''        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        fetch_py = fill_py = market_python()
        runner = Path(root) / "functional modules" / PRIVATE_FOLDER / MARKET_RUNNER
        picked = pick_market_python(runner, tool, fetch_py) if runner.is_file() else {}
        if picked.get("python"):
            fetch_py = fill_py = picked["python"]
        elif picked.get("fill_python"):
            fill_py = picked["fill_python"]                                     # --fill needs only pandas + pyarrow
        results = {}
        for verb in ("--fetch", "--fill"):
            py = fetch_py if verb == "--fetch" else fill_py
            head = [py, "-X", "utf8", str(runner), "--tool", str(tool), "--python", py] if runner.is_file() else [py, "-X", "utf8", str(tool)]
            command = head + [verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)]''')
rep('''        detail = "%s · Python %s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, Path(fetch_py).parent.parent.name if fetch_py != sys.executable else "本行程", fetched.get("lamp", "—"), fetched.get("msg", ""), filled.get("lamp", "—"), filled.get("msg", "沒跑"))''',
    '''        py_label = Path(fetch_py).parent.parent.name if fetch_py != sys.executable else "本行程"
        if runner.is_file() and not picked.get("python"):
            py_label = "沒有合 VDF 界線的(填值用 %s)" % (Path(fill_py).parent.parent.name if fill_py != sys.executable else "本行程")
        detail = "%s · Python %s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, py_label, fetched.get("lamp", "—"), fetched.get("msg", ""), filled.get("lamp", "—"), filled.get("msg", "沒跑"))''')
rep('''        extra = {"tool": str(tool), "results": results, "market_json": str(market / "VRN2_Market_latest.json") if (market / "VRN2_Market_latest.json").is_file() else ""}''',
    '''        extra = {"tool": str(tool), "results": results, "market_json": str(market / "VRN2_Market_latest.json") if (market / "VRN2_Market_latest.json").is_file() else "",
                 "runner": runner.name if runner.is_file() else "", "fetch_python": picked}''')

# v0149 selftest block (before the v0148 PASS line)
rep('''    print("[PASS] v0148: UIAction v0110 (hermetic selftest''', r'''    saved_fetch = os.environ.get("VIA_FETCH_PY")
    with tempfile.TemporaryDirectory(prefix="vrn2-v0149-check-") as temporary:
        folder = Path(temporary)
        root = folder / "VIA"
        runtime = root / "functional modules" / PRIVATE_FOLDER
        runtime.mkdir(parents=True)
        for name in (VERBATIM, "VRN2_VerbatimVerifier_v0104.py", MARKET_RUNNER):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        vv = _load_runtime_module(runtime, VERBATIM, "vrn2_verbatim_v0149_check")
        assert vv.VERSION == "v0105" and vv.comparable("Type-\nC PD") == vv.comparable("Type\ufffeC PD") == vv.comparable("Type\x02C PD") and vv.comparable("Type-C") != vv.comparable("TypeC")
        mr = _load_runtime_module(runtime, MARKET_RUNNER, "vrn2_marketrun_v0149_check")
        assert mr.VERSION == "v0100" and mr.requirements(None)[0] == mr.FALLBACK_REQUIREMENTS and len(mr.FALLBACK_REQUIREMENTS) == 6
        shared = root / "functional modules" / "VRN"
        (shared / "_vdf_fetch").mkdir(parents=True)
        (shared / "_vdf_fetch" / "VDF_TW_AllInOne_v099.py").write_text("DEPENDENCY_REQUIREMENTS = ()\n", encoding="utf-8")
        (shared / "VRN2_MarketFetch_v0199.py").write_text(
            "import sys\nfrom pathlib import Path\nHERE = Path(__file__).resolve().parent\nPROBE = \"import json; print('ok')\"\n"
            "def engine_path():\n    return HERE / '_vdf_fetch' / 'VDF_TW_AllInOne_v099.py'\n"
            "def fetch_python():\n    return 'WRONG-via_tw_fetch'\n"
            "def main(argv):\n    print('[計] 市場%s · GREEN · py=%s' % ('擷取' if '--fetch' in argv else '填值', fetch_python()))\n    return 0\n", encoding="utf-8")
        output = root / "VIA_Reports" / "vrn2"
        (output / "output").mkdir(parents=True)
        (output / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TICKER": "2330"}]), encoding="utf-8")
        os.environ["VIA_FETCH_PY"] = sys.executable
        steps = []
        got = market_fetch(root, output, steps, limits())
        if sys.version_info >= (3, 11):
            assert got["lamp"] == "GREEN" and got["runner"] == MARKET_RUNNER and got["fetch_python"]["python"] == sys.executable, got
            assert got["results"]["--fetch"]["msg"] == "py=" + sys.executable, got["results"]
    if saved_fetch is None:
        os.environ.pop("VIA_FETCH_PY", None)
    else:
        os.environ["VIA_FETCH_PY"] = saved_fetch
    print("[PASS] v0149: VerbatimVerifier v0105 (line-end hyphen · U+FFFE) · ⑥e MarketFetchRun v0100 (MarketFetch's fetch_python → a Python that passes the VDF engine's bounds)")
    print("[PASS] v0148: UIAction v0110 (hermetic selftest''')
(S / "v149/new").mkdir(parents=True, exist_ok=True)
(S / "v149/new/ActivateVRN-2_v0149.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0149 lines", s.count("\n"))
