"""VRN2_Handover_v0150.md:從 v0149 只增不減。"""
import json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v149")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0149.md").read_text(encoding="utf-8")
R = json.loads((S / "release149/VRN2_Release_v0149.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg149/VRN2_Runtime_v0149.json").read_text(encoding="utf-8"))["files"]}
vv105 = next(c["sha256"][:12] for c in R["components"] if c["path"] == "VRN2_VerbatimVerifier_v0105.py")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)


lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0148 + VRN2_RoundAll_v0101 · 2026-10-29(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0149 + VRN2_RoundAll_v0102 · 2026-10-29(v0148 + 本輪:桌機 17:01 跑 VRN2_RoundAll_v0101(52 份 · 2345 秒 · 紅 4 黃 11)的貼回 + 操作員「我的PS是7.6.9請用一個指令完成剩餘工作完成系統」→ "
            "VerbatimVerifier v0105 / IndependentVerifier v0111(行尾連字號 U+FFFE · 3014TT 第 3 點)· MarketFetchRun v0100(⑥e 擷取 Python 照 VDF 引擎版本界線)· RoundAll v0102(pwsh 一行 · ⑪ FAIL 印原文證據 · ⑥f 閘失敗列 · docstring 反斜線)· "
            "一鍵 v0149 · 操作員一鍵 v0110 · 本地實測一輪改指;runtime v0148 的 181 個成員一個位元組都不動 · +3 個新檔)")
src = "\n".join(lines)
old_round = "> **桌機貼回(2026-10-29 14:40 · 第一次跑 VRN2_RoundAll_v0100"
assert src.count(old_round) == 1
e2e = res["roundall_e2e"]; fx = res.get("roundall_fix_pass") or {}
new_round = ("> **桌機貼回(2026-10-29 17:01 · 跑 VRN2_RoundAll_v0101 · 52 份 · 2345 秒 · 紅 4 黃 11 · 殼印 PowerShell 5.1,操作員說自己的是 7.6.9)**:紅 = ④ 啟動器 rc 1 · ⑥ 收尾收據 rc 1 · ⑥ 四點原文核對 FAIL(3014TT-20231005.pdf 第 3 點 · rc 1 的唯一原因)· ⑥ 四點 FAIL 摘錄;"
             "黃 = ⑥e 擷取「缺套件」(MarketFetch 自己用了 envs\\via_tw_fetch)· ⑥f gate FAIL_CLOSED(共識 41 / 43 · 缺 6933 · 4171)· ⑪ 基本資料 FAIL 4(MS-3661 / 6669 / 8358 現價 · MS-8210 上漲)· 年度 FAIL 1(daiwa aspeed `n#a#`)…;另 `SyntaxWarning: invalid escape sequence '\\l'`。\n"
             "> **本輪(v0149 · 套件 = 啟動器 v0149 + runtime v0149 = v0148 的 181 個成員不動 + VerbatimVerifier v0105 + IndependentVerifier v0111 + MarketFetchRun v0100 · 一支 Python `vrn2_release_v0149/VRN2_RoundAll_v0102.py` · 一鍵 v0149 · 操作員一鍵 v0110)**:"
             "① **VerbatimVerifier v0105**(收尾閘 · 薄尾 · v0104 也在套件):摘錄(pdfplumber)「Type-」換行「C PD」,PDFium 寫成「Type\\ufffeC」;v0104 只在下一字小寫時接合 · 不認 U+FFFE → FAIL。v0105 比對時 U+FFFE → 「-」+ 換行,任何「-」+ 換行都接(兩邊同法)· 冊裡的摘錄不動 · 用 PyMuPDF 產生的 PDF 重現 v0104 FAIL / v0105 PASS · 沙盒 52 點回歸不變。"
             "② **IndependentVerifier v0111**:v0110 的摘錄讀法換成 v0105(⑪ 一標題四重點 FAIL 1 就是同一點)。"
             "③ **MarketFetchRun v0100**:MarketFetch v0112 的 `fetch_python()` 只要 `envs\\via_tw_fetch\\Scripts\\python.exe` 在就用它(啟動器給的 VIA_FETCH_PY 不管)→ 桌機那個環境什麼都沒裝(VDF 引擎上一輪在那裡 pip 失敗);容器用 Windows 版面重現(`repro_marketfetch149.log`)。"
             "runner 載入共用 MarketFetch(不改不抄)只換 `fetch_python()` → 第一個通過 VDF 引擎自己 `def_missing_dependencies()` 的 Python(界線從引擎檔 ast 讀 · 3.11+ · 再加 MarketFetch 自己的匯入探測);都不合 → 不啟動引擎(不 pip)· 填值用能匯入 pandas + pyarrow 的 Python · 收據 ⑥e 多 `fetch_python`(每個候選缺什麼,裝了但不在界線內寫出版本)。"
             "④ **RoundAll v0102**:套件 v0149 · docstring 反斜線成對(⑯ 編譯不准出 SyntaxWarning)· ② 用同一支 runner 照 VDF 界線診斷 + 交 VCGC 的指令帶界線加引號 · ⑥ 印 ⑪ 基本資料 FAIL 證據(冊值 + 原 PDF 前 4 頁那行 → `VRN2_FailEvidence_latest.json`)· ⑪ 驗證器版本 · ⑥f 共識閘 FAIL 列 · ③ 多跑 VerbatimVerifier v0105 / MarketFetchRun v0100 · 20 項過 · 一行指令 **pwsh** 與 powershell 兩種。"
             "⑤ **端到端(沙盒仿桌機:殼有 VIA_ROOT · envs 有退役環境 + 沒裝套件的 via_tw_fetch · 用 pwsh 一行指令從假 GitHub 分支取 RoundAll)**:%s;只修回合:%s。"
             "**沒修 / 要證據**:MS 四份 ⑪ FAIL(容器同檔 PASS → v0102 下一輪會印證據)· 桌機沒有合 VDF 界線的 Python 時 ⑥e 會一直黃(要 VCGC 建 via_tw_fetch;VRN-2 不裝、不改 VDF)· ⑥f 閘 FAIL_CLOSED(FactSet 沒覆蓋的代號;引擎語意不改)· daiwa aspeed 年度 1 格。\n"
             % (e2e.get("summary", "見驗證紀錄"), fx.get("summary", "見驗證紀錄")))
src = src.replace(old_round, new_round + old_round, 1)
once("> **本輪(v0148 · 套件 = 啟動器 v0148 + runtime v0148", "> **前一輪(v0148 · 套件 = 啟動器 v0148 + runtime v0148")
anchor = "| **VRN2_RoundAll_v0101.py**(發行夾 · 一支入口 · 不在套件內)| **v0101** |"
assert src.count(anchor) == 1
rows = ("| **VRN2_RoundAll_v0102.py**(發行夾 · 一支入口 · 不在套件內)| **v0102** | `vrn2_release_v0149` | `%s` | **新**(套件 v0149 · pwsh 一行 · ② / ⑤ 擷取 Python 照 VDF 界線 · ⑥ ⑪ FAIL 證據 / 驗證器版本 / ⑥f 閘列 · docstring 反斜線 · 自測 20 項)|\n"
        "| ActivateVRN-2_v0149.py(套件 · 底座 v0136)| **v0149** | 見發行清單 | `%s` | **新**(收尾閘 VerbatimVerifier v0105 · ⑥e 經 MarketFetchRun · 收據 v0149 · 自測 7 段)|\n"
        "| **VRN2_VerbatimVerifier** | **v0105**(薄尾 · v0104 留著)| 套件 + runtime v0149 | `%s` | **新**(行尾連字號 U+FFFE / U+0002 / 「-」+ 換行 · 5 項)|\n"
        "| **VRN2_IndependentVerifier** | **v0111**(結構複本 · v0110 留著)| runtime v0149 | `%s` | **新**(摘錄讀法 = VerbatimVerifier v0105 · 自測 30/30 + v0110 + v0111)|\n"
        "| **VRN2_MarketFetchRun** | **v0100**(新家族 · 只用標準庫)| runtime v0149 | `%s` | **新**(⑥e:共用 MarketFetch 的 fetch_python 換成合 VDF 界線的 Python · 都不合不啟動引擎 · 9 項)|\n") % (
    R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], vv105, rt["VRN2_IndependentVerifier_v0111.py"], rt["VRN2_MarketFetchRun_v0100.py"])
src = src.replace(anchor, rows + anchor, 1)
once("## 7. 本輪(v0147 → v0148 + VRN2_RoundAll_v0101 · 桌機 2026-10-29 14:40 第一次跑 RoundAll 的貼回)",
     "## 7. 本輪(v0148 → v0149 + VRN2_RoundAll_v0102 · 桌機 2026-10-29 17:01 跑 RoundAll v0101 的貼回 · 操作員「我的PS是7.6.9請用一個指令完成剩餘工作完成系統」)\n\n| # | 桌機看到的 | 根因 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | 收尾 rc 1:四點原文核對 3014TT 第 3 點 FAIL(⑪ 一標題四重點 FAIL 1)| PDFium 把行尾連字號寫成 U+FFFE、吃掉換行;v0104 只在下一字小寫時接合 | VerbatimVerifier v0105 + IndependentVerifier v0111 | 產生的 PDF:v0104 FAIL · v0105 PASS · 沙盒 52 點不變 · 啟動器自測 v0149 段 |\n"
     "| b | ⑥e「擷取環境缺套件(…\\envs\\via_tw_fetch\\Scripts\\python.exe)」· last_error = VDF pip exit 1 | MarketFetch v0112 的 fetch_python() 只要 via_tw_fetch 在就用,不管啟動器給的 Python | MarketFetchRun v0100(只換 fetch_python · 照 VDF 引擎自己的界線挑 · 都不合不啟動引擎)| Windows 版面重現 · runner 9 項(假 venv:沒裝 / 下界 / 上界 / 退役 / VIA_FETCH_PY 不合)· 端到端 ⑥e 收據帶每個候選缺什麼 |\n"
     "| c | `SyntaxWarning: invalid escape sequence '\\l'` | v0101 docstring 的 `market\\vdf\\…` 單一反斜線 | RoundAll v0102 全部成對 | `-W error` 編譯:v0101 SyntaxError 重現 · v0102 乾淨 · 自測 ⑯ |\n"
     "| d | ⑪ 基本資料 FAIL 4(MS 三份現價 · MS-8210 上漲)| 容器同一份 MS-3661 擷取 3190.00 · PASS → 桌機的冊值不同,看不到 | RoundAll v0102 ⑥ 印證據(冊值 + 原文那行)+ `VRN2_FailEvidence_latest.json` | 自測 ⑱ · 真 MS-3661:「Shr price, close (Dec 3, 2025) NT$3,190.00」|\n"
     "| e | ⑥f gate FAIL_CLOSED | 共識引擎品質閘:FactSet 沒覆蓋的代號 | 不改引擎語意;⑥ 印閘不過的列 | 自測 ⑰ |\n"
     "| f | 「我的 PS 是 7.6.9」 | 舊一行用 powershell(5.1)| pwsh 與 powershell 兩行(同一段開機碼)| pwsh 7.4.6 跑 pwsh 那行完成端到端 · 兩行解碼 = 開機碼 |\n"
     "| — | ⑥e 沒有合界線的 Python · MS FAIL 真因 · daiwa 年度 1 格 | 要 VCGC 建環境 / 要證據 | **沒修**(VRN-2 不裝不改 VDF;證據下一輪印)| — |\n\n---\n\n"
     "## 7.0l 前一輪(v0147 → v0148 + VRN2_RoundAll_v0101 · 桌機 2026-10-29 14:40 第一次跑 RoundAll 的貼回)")
once("| 0 | **(v0148)** 桌機貼 `vrn2_release_v0148/VRN2_RoundAll_v0101.md` 的一行",
     "| 0 | **(v0149)** 桌機(PowerShell 7.6.9)貼 `vrn2_release_v0149/VRN2_RoundAll_v0102.md` 的 **pwsh 那一行**(一個指令:取 RoundAll v0102 → 核對 → 跑完全流程 → 貼回包)· 跑完看 `⑥ ⑪ 基本資料 FAIL 證據` 那幾行(或上傳 `Downloads\\VRN2_PasteBack_<時間>.zip`)| 貼回 |\n"
     "| 0a | **(v0149)** ⑥e:② 若印「沒有合 pandas>=2.2,<3 … 的 Python」→ 交 VCGC 照印的指令建 `envs\\via_tw_fetch`(帶界線、加引號);建好後 ⑥e 會自動選它 | VCGC |\n"
     "| 0 | **(v0148)** 桌機貼 `vrn2_release_v0148/VRN2_RoundAll_v0101.md` 的一行")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0149)** **第二讀取器的比對形式要涵蓋各家 PDF 函式庫的寫法**:PDFium 把行尾連字號寫成 U+FFFE(舊版 U+0002)並吃掉換行;pdfplumber 留「-」+ 換行。只改比對形式,不改冊裡的摘錄。\n"
     "- **(v0149)** **借來的工具會自己挑 Python 時,要換掉它挑的那一步**(MarketFetch 的 fetch_python 不看 VIA_FETCH_PY);挑的標準用**被呼叫的引擎自己的檢查**(VDF 的 DEPENDENCY_REQUIREMENTS 界線),不要只看能不能 import。\n"
     "- **(v0149)** **不要讓別的系統的引擎在我們這輪自己 pip**:都不合界線就不啟動它,印每個候選缺什麼 + 交 VCGC 的指令(界線加引號:cmd 的 `<` 是導向)。\n"
     "- **(v0149)** **Python 原始碼裡的 Windows 路徑一律成對反斜線**(docstring 也是);建置後用 `-W error` 編譯一次。\n"
     "- **(v0149)** **使用者說 PowerShell 版本就給那一版的指令**:PS 7 = `pwsh`,5.1 = `powershell`;同一段 -EncodedCommand 兩邊都能跑。\n"
     "- **(v0149)** **看不到桌機的值就讓下一輪印出來**:⑪ FAIL 印冊值 + 原文那一行,比猜擷取 / 驗證哪邊錯可靠。\n\n")
(REPO / "VRN2_Handover_v0150.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0150 lines", src.count("\n"))
