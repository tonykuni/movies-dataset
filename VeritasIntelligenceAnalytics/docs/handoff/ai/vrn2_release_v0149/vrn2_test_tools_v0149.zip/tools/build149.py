"""v0149 整包重建(冪等):pkg149 → 套件 zip → VRN2_RoundAll_v0102.py(填套件雜湊)+ 一行啟動(pwsh / powershell)md → 發行清單 → 一鍵 v0149 md → 操作員 v0110 md → 本地實測一輪改指。"""
import base64, hashlib, json, re, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); out, rel, op10, new = S / "v149/pkg149", S / "v149/release149", S / "v149/operator110", S / "v149/new"
rel.mkdir(exist_ok=True); op10.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
rt = json.loads((out / "VRN2_Runtime_v0149.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN2_VerbatimVerifier_v0105.py", "VRN2_IndependentVerifier_v0111.py", "VRN2_MarketFetchRun_v0100.py"]
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0149.py", "VRN2_Runtime_v0149.zip", "VRN2_Runtime_v0149.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
with zipfile.ZipFile(out / "VRN2_Runtime_v0149.zip") as z:
    assert z.read("VRN2_VerbatimVerifier_v0105.py") == files["VRN2_VerbatimVerifier_v0105.py"] == (new / "VRN2_VerbatimVerifier_v0105.py").read_bytes()   # 套件與 runtime 是同一支 v0105
files["README.txt"] = ("VRN2_Closeout_v0149 — VRN-2 closeout package (2026-10-29)\n\nEntry: python ActivateVRN-2_v0149.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0102.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.\n"
  "Runtime: VRN2_Runtime_v0149.zip = runtime v0148 (181 members byte-identical) + VRN2_VerbatimVerifier_v0105 + VRN2_IndependentVerifier_v0111 + VRN2_MarketFetchRun_v0100,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0149 (desktop run of VRN2_RoundAll_v0101 · 2026-10-29 17:01 · red 4 · yellow 11):\n"
  " - closeout gate VerbatimVerifier v0105 (thin tail over v0104, both in the package): 3014TT-20231005.pdf point 3 was the only FAIL (closeout rc 1). PDFium writes a\n"
  "   line-end hyphen as U+FFFE and drops the line break (\"Type\\ufffeC\"); the excerpt has \"Type-\" + newline + \"C\". v0105 compares both as the same text.\n"
  " - step 11 IndependentVerifier v0111: v0110 with its excerpt reader on VerbatimVerifier v0105.\n"
  " - step 6e MarketFetchRun v0100: MarketFetch v0112's own fetch_python() took envs/via_tw_fetch (nothing installed) although the launcher gave it via_core_312.\n"
  "   The runner replaces only that function with the first Python passing the VDF engine's own dependency check (bounds read from the engine file); none → no engine start (no pip).\n"
  "Verification: see VRN2_Verification_v0149.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0149.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0149", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0149.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0149/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll v0102:填套件雜湊 · 一行啟動(pwsh / powershell)· md =====
ra_src = (new / "VRN2_RoundAll_v0102.py").read_text(encoding="utf-8")
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0102.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
boot0 = (S / "v148/release148/boot_roundall.ps1").read_text(encoding="utf-8")
ra_boot = boot0.replace("vrn2_release_v0148", "vrn2_release_v0149").replace("VRN2_RoundAll_v0101.py", "VRN2_RoundAll_v0102.py")
ra_boot = ra_boot.replace("$ErrorActionPreference = 'Continue'\n", "$ErrorActionPreference = 'Continue'\n$ProgressPreference = 'SilentlyContinue'   # Expand-Archive 的進度條在 PS 5.1 很慢 · 輸出導向時 pwsh 會印 CLIXML\n", 1); assert "$ProgressPreference" in ra_boot
ra_boot = re.sub(r"\$H  = '[0-9a-f]{64}'", "$H  = '%s'" % ra_sha, ra_boot, count=1)
assert ra_sha in ra_boot and "v0148" not in ra_boot and "v0101" not in ra_boot
enc = base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii")
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_one) < 8191
ra_pwsh = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_pwsh) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8"); (rel / "oneline_roundall_pwsh.txt").write_text(ra_pwsh + "\n", encoding="utf-8")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0102.py(一個指令跑完剩下的:取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯報告 → 貼回包)

`VRN2_RoundAll_v0102.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪;套件 = `VRN2_Closeout_v0149.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。
v0102 = v0101 + 桌機 2026-10-29 17:01 跑 v0101 的貼回修正(紅 4 · 黃 11 · 2345 秒):

| 桌機看到的 | 根因 | v0149 / v0102 怎麼修 |
|---|---|---|
| 收尾 rc 1:四點原文核對 `3014TT-20231005.pdf` 第 3 點 FAIL(⑪ 一標題四重點 FAIL 1 也是它)| 摘錄(pdfplumber)「…聯陽Type-」換行「C PD 至少」;第二讀取器 PDFium 把行尾連字號寫成 U+FFFE、吃掉換行 →「Type\\ufffeC」。v0104 只在下一字是小寫時接合,也不認 U+FFFE | **VerbatimVerifier v0105**(收尾閘)/ **IndependentVerifier v0111**(⑪):行尾連字號不管寫成 U+FFFE、U+0002 還是「-」+ 換行,下一字大小寫都一樣,當成同一段字;只改比對形式,冊裡的摘錄不動。容器用產生的 PDF 重現:v0104 FAIL · v0105 PASS;沙盒 52 點回歸不變 |
| ⑥e 黃:「擷取環境缺套件(…\\envs\\via_tw_fetch\\Scripts\\python.exe)」· last_error.txt = VDF 引擎 `pip install pandas>=2.2,<3 …` exit 1 | 啟動器給 MarketFetch 的是 `via_core_312`(套件都在),但 MarketFetch v0112 自己的 `fetch_python()` 只要 `envs\\via_tw_fetch` 夾在就用它;那個環境什麼都沒裝(VDF 引擎上一輪在那裡自己 pip 失敗)| **MarketFetchRun v0100**(VRN-2 私有 runtime):載入共用 MarketFetch(不改不抄),只換掉它的 `fetch_python()`,換成第一個通過 **VDF 引擎自己的檢查**的 Python(同模組 · 同 `>=` / `<` 界線,從引擎檔讀 · Python 3.11+)。都不合 → 不啟動引擎(免得它又 pip)· 填值照用現有 Parquet · 印每個候選缺什麼。② 也用同一支工具診斷 |
| `SyntaxWarning: invalid escape sequence '\\l'` | v0101 docstring 裡 `market\\vdf\\last_error.txt` 等路徑只有一個反斜線 | 全部成對;③ 自測 ⑯ 編譯本檔不准出 SyntaxWarning |
| ⑪ 基本資料 FAIL 4(MS-3661 / MS-6669 / MS-8358 現價 · MS-8210 上漲空間)| 容器裡同一份 `MS-3661 20251203.pdf` 擷取 3190.00、驗證 PASS → 桌機的冊值不同;沒有桌機的冊值 / 原文看不出是擷取錯還是驗證器誤判 | ⑥ 除錯**印證據**:冊值 + 原 PDF 前 4 頁含這些數或價格標籤的行 → `VRN2_FailEvidence_latest.json`(進貼回包)。下次貼主控台就看得到 |
| ⑥f gate FAIL_CLOSED(共識 41 / 43 · 缺 6933 · 4171)| 共識引擎(原樣內附)的品質閘:FactSet 沒覆蓋的代號(未評等 / 新上市)檢查不過就整批 FAIL_CLOSED;Combined 照組(52 列)| 引擎語意不改;⑥ 除錯印**不過的檢查列**(代號 · 檢查 · 實際 · 應為)|
| 你的 PowerShell 是 7.6.9 | 舊的一行用 `powershell`(= Windows PowerShell 5.1)| 一行指令兩種:**`pwsh`**(PowerShell 7)與 `powershell`(5.1),內容相同 |

## 一個指令(PowerShell 7.6.9 · 建議)

在 PowerShell 7(`pwsh`)、Windows PowerShell 或 cmd 貼這一行(要有 `pwsh` 在 PATH;PowerShell 7 安裝時會加):
它從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)取 `VRN2_RoundAll_v0102.py` → **核對 SHA-256**(`@RASHA12@`)→ 存到 `Downloads` → 用你的 python 執行 → 跑完印總表、`NEXT:` 與貼回包位置。

```bat
@PWSH@
```

沒有 PowerShell 7 時用這一行(Windows PowerShell 5.1 · 內容一樣):

```bat
@ONE@
```

VIA 根不在 `C:\\Users\\tonyk\\OneDrive\\Documents\\movies-dataset\\VeritasIntelligenceAnalytics` 就先設(PowerShell:`$env:VRN2_ROOT='…'` · cmd:`set VRN2_ROOT=…`);
要帶參數就設 `VRN2_ROUNDALL_ARGS`(例 PowerShell:`$env:VRN2_ROUNDALL_ARGS='--integrate yes --source C:\\測試樣本報告'`)。舊資料庫待決定時預設會問你(y / n / 先不決定)。

| 步驟 | 做什麼 | 不做什麼 |
|---|---|---|
| ⓪ VIA 根 | `--root` → `VRN2_ROOT` / `VIA_ROOT` → 本檔所在的倉 → 啟動器記的 `Downloads\\VRN2_Closeout_v0*\\VRN2_Runtime_Context.json` → vrn2:// 註冊 → 預設位置 | 找不到不猜:印出查過的地方 |
| ① 套件 | 本機 `Downloads\\VRN2_Closeout_v0149` 的 zip 雜湊對 + 逐檔對 → 直接用;否則 git archive 發行夾(分支 → main)→ 核對 → 解壓;本機夾有檔不對 → 整夾改名備份再解壓 | 不刪舊套件夾 |
| ② 診斷 | VRN-2 Python 的必裝套件 · 擷取 Python(`VIA_FETCH_PY` / envs · 退役 / 備份夾略過)· **⑥e 擷取 Python 照 VDF 版本界線**(每個候選缺什麼 · 交 VCGC 的指令帶界線、加引號)· 共用 MarketFetch / VDF 引擎 · 啟動器鎖 · 輸出夾 · 來源夾 · 磁碟 · CPU · git | 不裝套件 |
| ③ 自測 | runtime zip 解到 TEMP(逐檔核對)→ 十二支 `--selftest`(+ VerbatimVerifier v0105 · MarketFetchRun v0100)+ 啟動器 `--selftest` | 不碰真資料 |
| ④ 跑 | `ActivateVRN-2_v0149.py`(預設不上船 `VIA_VRN2_NO_PUSH=1`)· 逐行即時印 · 60 秒沒輸出印心跳 · 另一個啟動器在跑就不跑 | `--ship` 才推 |
| ⑤ 自動修 | 同 v0101;重抓 ⑥e 經 MarketFetchRun(合界線的 Python)| 收尾收據先備份成 `.before_roundall.json` 再標註;不刪任何資料 |
| ⑥ 除錯 | 同 v0101 + **⑪ 基本資料 FAIL 證據**(冊值 + 原文那行)· ⑪ 驗證器版本 · ⑥f 共識閘不過的列 · ⑥e 擷取 Python 每個候選缺什麼 | — |
| ⑦ 貼回包 | `Downloads\\VRN2_PasteBack_<時間>.zip`(多收 `VRN2_FailEvidence_latest.json` · `consensus\\factset_yfinance_consensus_quality_matrix.csv`)| 不上傳任何地方(要你自己上傳給 AI)|

結束碼 0 綠 · 2 黃 · 1 紅;最後一行 `NEXT: [燈] …`(前面三行「下次」是完整路徑的重跑指令)。

## 已經有這個檔時

PowerShell(7 或 5.1 · 提示字元 `PS C:\\Users\\…>`;`%USERPROFILE%` 在這裡不會展開):

```powershell
python "$env:USERPROFILE\\Downloads\\VRN2_RoundAll_v0102.py"
python "$env:USERPROFILE\\Downloads\\VRN2_RoundAll_v0102.py" --skip-run --integrate yes
python "$env:USERPROFILE\\Downloads\\VRN2_RoundAll_v0102.py" --only preflight,selftest
```

cmd(提示字元 `C:\\Users\\…>`):

```bat
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0102.py"
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0102.py" --skip-run --integrate yes
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0102.py" --only preflight,selftest
```

常用參數:`--source <報告夾>` · `--integrate ask|yes|no|skip`(舊資料庫)· `--no-open` · `--ship`(允許上船)· `--offline`(不連 GitHub)· `--python <VRN-2 的 python>` · `--skip-selftest` · `--selftest`(本檔自測)。

## 程式碼決定不了的(⑥ 會印證據 · 貼回包有全文)

- ⑥e:沒有合 VDF 界線(`pandas>=2.2,<3` 等)的 Python 時,擷取會黃 —— 要 VCGC 建好 `envs\\via_tw_fetch`(VRN-2 不裝;② 印出帶界線的指令)。
- ⑪ 基本資料 FAIL:看 `⑪ 基本資料 FAIL 證據` 那幾行 —— 冊值和原文那行對不上 = 擷取取錯數;原文那行就是冊值 = 驗證器誤判。把那幾行(或貼回包)給 AI。
- ⑥f gate FAIL_CLOSED:FactSet 沒覆蓋的代號是真的沒有;其餘看 `⑥f 共識閘 FAIL 列`。

## 一行解開來的程式碼(核對用 · pwsh / powershell 兩行解開都是這段)

```text
@BOOT@
```
"""
ra_md = ra_md.replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PWSH@", ra_pwsh).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
for block in re.findall(r"(?s)```bat\n(pwsh|powershell) -NoProfile -ExecutionPolicy Bypass -EncodedCommand (\S+)\n```", ra_md):
    assert base64.b64decode(block[1]).decode("utf-16-le") == ra_boot
assert len(re.findall(r"EncodedCommand", ra_md)) == 2
(rel / "VRN2_RoundAll_v0102.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0149 + VRN2_RoundAll_v0102", "date": "2026-10-29",
        "trigger": "桌機 2026-10-29 17:01 跑 VRN2_RoundAll_v0101(52 份 · 2345 秒 · 紅 4 黃 11)+ 操作員「我的PS是7.6.9請用一個指令完成剩餘工作完成系統」→ 能在容器重現 / 驗證的缺陷修成 v0149(見 fixes)",
        "base_package": {"name": "VRN2_Closeout_v0148 (launcher v0148 · runtime v0148)", "retained": "runtime v0148 members byte-identical inside runtime v0149; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0148 for the closeout entry; VRN2_RoundAll v0101 → v0102; VRN-2 one-click v0148 → v0149; operator one-click v0109 → v0110",
        "fixes": {"VerbatimVerifier_v0105": "line-end hyphen equivalence (PDFium U+FFFE / U+0002 / '-' + newline, any next character) — 3014TT-20231005.pdf point 3 was the only FAIL and the reason for closeout rc 1; reproduced with a generated PDF (v0104 FAIL · v0105 PASS); sandbox 52 points unchanged",
                  "IndependentVerifier_v0111": "v0110 with its excerpt reader on VerbatimVerifier v0105 (step 11 summary FAIL 1 = the same 3014TT point)",
                  "MarketFetchRun_v0100": "6e: MarketFetch v0112's own fetch_python() took envs/via_tw_fetch (nothing installed; VDF's bootstrap pip had failed there) although the launcher gave it via_core_312; the runner replaces only that function with the first Python passing the VDF engine's own dependency check (bounds read from the engine file); none → engine not started (no pip), --fill with a pandas + pyarrow Python",
                  "RoundAll_v0102_docstring": "Windows paths in the docstring had single backslashes → SyntaxWarning '\\l' on the desktop; all doubled, selftest compiles the file with warnings as errors",
                  "RoundAll_v0102_evidence": "diagnosis prints step-11 basic FAIL evidence (book values + source PDF lines, pages 1-4, VRN2_FailEvidence_latest.json), the step-11 verifier version, the consensus quality-gate FAIL rows and each 6e fetch-Python candidate's missing / out-of-bound packages",
                  "RoundAll_v0102_oneliner": "pwsh (PowerShell 7.x, the operator's 7.6.9) and powershell (5.1) one-liners with the same boot"},
        "not_fixed_here": {"MS_basic_fails": "MS-3661 / MS-6669 / MS-8358 CURRENT_PRICE · MS-8210 UPSIDE FAIL on the desktop; the same MS-3661 PDF extracts 3190.00 and passes in the container → needs the evidence lines printed by v0102 (or the paste-back zip)",
                           "VDF_fetch_env": "if no Python on the desktop meets the VDF engine's bounds (pandas>=2.2,<3 …), 6e stays YELLOW until VCGC builds envs/via_tw_fetch; VRN-2 does not install and does not modify VDF files",
                           "consensus_gate": "the bundled consensus engine's quality gate FAIL_CLOSED for codes without FactSet coverage (6933 · 4171 on the desktop); engine semantics unchanged, Combined still built",
                           "annual_fail_1": "260914_daiwa_aspeed.pdf one annual cell with null marker 'n#a#' UNCLEAR → FAIL in step 11 (not in the container samples)"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0149.json inside the package"},
        "roundall": {"name": "VRN2_RoundAll_v0102.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0102.md", "oneliner_pwsh": "oneline_roundall_pwsh.txt (in logs_v0149.zip) = the pwsh line of the md"},
        "tested_in": "Linux container · python 3.13 venv_vrn2 (pandas 3 · pyarrow · no duckdb · no yfinance) · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0149.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0149/<files> (no .ps1 · the one-click md / RoundAll py are the entries)"},
        "launcher": {"name": "ActivateVRN-2_v0149.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0149.py"]).hexdigest()},
        "oneclick": "VRN2_OneClick_v0149.md", "test_tools_zip": "vrn2_test_tools_v0149.zip", "logs_zip": "logs_v0149.zip"}
(rel / "VRN2_Release_v0149.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
# ===== one-click v0149 from v0148 =====
md = (REPO / "vrn2_release_v0148/VRN2_OneClick_v0148.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); old_cs = hashlib.sha256(ps.encode("utf-8")).hexdigest(); assert old_cs in boot
HEAD8 = "  # ===== VRN-2 一鍵 v0148(套件 v0148 = 啟動器 v0148 + runtime v0148 = v0147 + UIAction v0110 + ConsensusJoin v0101 + HistoryAlign v0102;"
BAN8 = "[計] VRN-2 一鍵 v0148 · ActivateVRN-2 v0148(套件 · 私有 runtime v0148 = v0147 + "
outl = []
for line in ps.split("\n"):
    if line.startswith(HEAD8):
        line = ("  # ===== VRN-2 一鍵 v0149(套件 v0149 = 啟動器 v0149 + runtime v0149 = v0148 + VerbatimVerifier v0105 + IndependentVerifier v0111 + MarketFetchRun v0100;v0149 = 桌機 2026-10-29 17:01 跑 VRN2_RoundAll_v0101 的貼回修正:"
                "四點原文核對認得 PDFium 的行尾連字號(3014TT 第 3 點)· ⑥e 擷取 Python 照 VDF 引擎版本界線挑(MarketFetch 自己會改用沒裝套件的 via_tw_fetch)· 另一支 Python 升 VRN2_RoundAll_v0102(pwsh 一行);"
                "v0148 = 套件 v0148 = 啟動器 v0148 + runtime v0148 = v0147 + UIAction v0110 + ConsensusJoin v0101 + HistoryAlign v0102;" + line[len(HEAD8):])
    elif BAN8 in line:
        i = line.index(BAN8)
        line = line[:i] + "[計] VRN-2 一鍵 v0149 · ActivateVRN-2 v0149(套件 · 私有 runtime v0149 = v0148 + VerbatimVerifier v0105(行尾連字號)· IndependentVerifier v0111 · MarketFetchRun v0100(⑥e 擷取 Python 照 VDF 界線);另一支 Python VRN2_RoundAll_v0102.py;v0148 = v0147 + " + line[i + len(BAN8):].replace("另一支 Python VRN2_RoundAll_v0101.py;", "")
    else:
        line = line.replace("VRN2_Handover_v0148.md", "VRN2_Handover_v0150.md").replace("v0148", "v0149").replace("VRN2_RoundAll_v0101", "VRN2_RoundAll_v0102")
    outl.append(line)
ps = "\n".join(outl)
ps = re.sub(r"\$Want   = '[0-9a-f]{64}'   # VRN2_Closeout_v0149\.zip SHA-256[^\n]*", lambda m: "$Want   = '%s'   # VRN2_Closeout_v0149.zip SHA-256(套件 · 內含啟動器 v0149 + runtime v0149 清單 = v0148 + VerbatimVerifier v0105 · IndependentVerifier v0111 · MarketFetchRun v0100)" % want, ps, count=1)
assert want in ps and old_want not in ps
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0148" in code and "v0148 =" not in code), line[:200]
assert "VRN2_UIAction_v0110\\.py" in ps and "VRN2_RoundAll_v0102.py" in ps
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(old_cs, cs).replace("vrn2_release_v0148", "vrn2_release_v0149").replace("VRN2_OneClick_v0148.md", "VRN2_OneClick_v0149.md").replace("v0148", "v0149") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", md, count=1)
head = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", head, count=1)
head = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", head, count=1)
head = head.replace(old_want, "@WANT@").replace(old_cs, "@CS@").replace(old_cs[:12], "@CS@")


def hrep(a, b):
    global head
    assert head.count(a) == 1, (head.count(a), a[:80]); head = head.replace(a, b)


def hline(prefix, b):
    global head
    ls = head.split("\n"); idx = [i for i, l in enumerate(ls) if l.startswith(prefix)]; assert len(idx) == 1, (prefix, idx); ls[idx[0]] = b; head = "\n".join(ls)


hline("# VRN-2 一鍵 v0148(", "# VRN-2 一鍵 v0149(cmd / PowerShell 都能貼 · 套件 v0149 = 啟動器 v0149 + runtime v0149 = v0148 + VerbatimVerifier v0105 · IndependentVerifier v0111 · MarketFetchRun v0100)")
hrep("v0148 = v0147 入口 + runtime v0148(= runtime v0147 的 178 個成員逐位元保留 + 3 個新檔):",
     "桌機 2026-10-29 17:01 跑 `VRN2_RoundAll_v0101.py`(52 份 · 2345 秒 · 紅 4 · 黃 11)→ 能在容器重現 / 驗證的修成 v0149;另一支 Python 升 **`VRN2_RoundAll_v0102.py`**(同發行夾 · **一個指令**:`VRN2_RoundAll_v0102.md` 的 `pwsh` 那一行)。\n\n"
     "v0149 = v0148 入口 + runtime v0149(= runtime v0148 的 181 個成員逐位元保留 + 3 個新檔):\n\n| 元件 | 版本 | 修了什麼 |\n|---|---|---|\n"
     "| 收尾四點原文核對 | VRN2_VerbatimVerifier v0105(v0104 留著 · 兩支都在套件)| 3014TT-20231005.pdf 第 3 點 FAIL(收尾 rc 1 的唯一原因):摘錄「Type-」換行「C PD」,PDFium 把行尾連字號寫成 U+FFFE 並吃掉換行;v0105 把 U+FFFE / U+0002 / 「-」+ 換行(下一字大小寫都算)當成同一段字 · 只改比對形式 |\n"
     "| ⑪ 獨立驗證 | VRN2_IndependentVerifier v0111(v0110 留著)| 摘錄比對改用 VerbatimVerifier v0105 · 其餘照 v0110 |\n"
     "| ⑥e 市場擷取 | VRN2_MarketFetchRun v0100(共用 MarketFetch v0112 與 VDF 引擎都不動)| MarketFetch 自己的 `fetch_python()` 只要 `envs\\\\via_tw_fetch` 在就用它(桌機那個環境什麼都沒裝)→ 換成第一個通過 VDF 引擎自己檢查(同模組 · 同界線 · 3.11+)的 Python;都不合 → 不啟動引擎(不 pip)· 填值用有 pandas + pyarrow 的 Python |\n"
     "| 啟動器 | ActivateVRN-2 v0149 | 指向上面三個新版 · 收據 `VRN2_Closeout_v0149.json`(⑥e 多 `fetch_python`:每個候選缺什麼)· 自測多一段 v0149 |\n\n"
     "前一版 v0148 = v0147 入口 + runtime v0148(= runtime v0147 的 178 個成員逐位元保留 + 3 個新檔):")
hrep("| 啟動器 | ActivateVRN-2 v0148 |", "| 啟動器(v0148)| ActivateVRN-2 v0148 |")
hrep("| 步驟 | v0148 做什麼 |", "| 步驟 | v0149 做什麼 |")
hrep("| ① ② ③ ③b | 同 v0147(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|", "| ① ② ③ ③b | 同 v0148(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|")
hline("| ④ | `python ActivateVRN-2_v0148.py", "| ④ | `python ActivateVRN-2_v0149.py [--source …]`:單機閘 → ①~⑤ → ⑤b SSOT-ID 核號同步(含提案冊)→ ⑥ → ⑦(管理器 v0255)→ ⑥e 市場擷取(MarketFetchRun:合 VDF 界線的 Python)→ ⑥f 共識合併(上櫃 .TWO · Combined 冊)→ ⑧~⑫ → ⑫b 補放 → 四點原文核對(v0105)→ 收據 → ⑬b 歷史對齊(v0102)→ ⑬ 輸出位置 · 長線 Parquet 庫(七冊 · 補缺)→ ⑬c 舊資料庫整合掃描(限深)→ Workbench v0102 渲染 + 開啟 |")
hline("| ⑤ | 摘要多七行", "| ⑤ | 摘要多七行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID · 階段耗時 · ⑥e 市場擷取 · ⑥f 共識合併 · ⑬b 歷史對齊 · ⑬c 舊資料庫整合(都讀 `VRN2_Closeout_v0149.json`)+ 一行指向 `VRN2_RoundAll_v0102.py` |")
hline("| ⑤b ⑤c |", "| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\\\VRN2\\\\VRN2_UIAction_v0110.py`(設定檔 v0149 · `vrn2://integrate` 取最新的 DataIntegrate = v0101)· U/I 有輸入區塊 · 沒開就代開 |")
for a, b in (("VRN2_OneClick_v0148", "VRN2_OneClick_v0149"), ("套件 `VRN2_Closeout_v0148.zip`", "套件 `VRN2_Closeout_v0149.zip`"), ("從 `vrn2_release_v0148` 取", "從 `vrn2_release_v0149` 取"), ("Downloads\\VRN2_Closeout_v0148`", "Downloads\\VRN2_Closeout_v0149`")):
    head = head.replace(a, b)
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and "@" + "WANT@" not in newmd and cs in boot
(rel / "VRN2_OneClick_v0149.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot149.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline149.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0149.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0149", cs[:12])
# ===== operator v0110 from v0109 =====
md9 = (REPO / "vrn1_vrn2_oneclick_v0109/VRN1_VRN2_OneClick_v0109.md").read_text(encoding="utf-8")
p9 = re.search(r"(?s)```powershell\n(.*?)\n```", md9).group(1); boot9 = re.search(r"(?s)```text\n(.*?)\n```", md9).group(1)
cs9_old = hashlib.sha256(p9.encode("utf-8")).hexdigest(); assert cs9_old in boot9
p10 = p9


def rep10(a, b):
    global p10
    assert p10.count(a) == 1, (p10.count(a), a[:80]); p10 = p10.replace(a, b)


rep10("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0148'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0149'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0148 程式碼 SHA-256", p10).group(1); assert old_h2 == old_cs
rep10("  $H2 = '%s'   # VRN-2 一鍵 v0148 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0149 程式碼 SHA-256" % cs)
rep10("  # ===== VRN-1 / VRN-2 操作員一鍵 v0109(2026-10-29 · ② 改指 VRN-2 一鍵 v0148:",
      "  # ===== VRN-1 / VRN-2 操作員一鍵 v0110(2026-10-29 · ② 改指 VRN-2 一鍵 v0149:四點原文核對認得行尾連字號 · ⑥e 擷取 Python 照 VDF 界線;另一支 Python VRN2_RoundAll_v0102.py;v0109 · ② 改指 VRN-2 一鍵 v0148:")
rep10("操作員一鍵 v0109 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0110 · {0} · VRN-1 {1} · VIA {2}")
outl = []
for line in p10.split("\n"):
    if "操作員一鍵 v0110(2026-10-29 · ② 改指 VRN-2 一鍵 v0149" not in line:
        line = line.replace("VRN2_OneClick_v0148.md", "VRN2_OneClick_v0149.md").replace("VRN-2 一鍵 v0148", "VRN-2 一鍵 v0149").replace("套件 v0148 = 啟動器 v0148 + runtime v0148", "套件 v0149 = 啟動器 v0149 + runtime v0149").replace("ActivateVRN-2_v0148 單機閘", "ActivateVRN-2_v0149 單機閘")
    outl.append(line)
p10 = "\n".join(outl)
for line in p10.splitlines():
    code = line.split("#", 1)[0]
    assert "v0148" not in code, line[:160]
cs10 = hashlib.sha256(p10.encode("utf-8")).hexdigest()
boot10 = boot9.replace(cs9_old, cs10).replace("vrn1_vrn2_oneclick_v0109", "vrn1_vrn2_oneclick_v0110").replace("VRN1_VRN2_OneClick_v0109.md", "VRN1_VRN2_OneClick_v0110.md").replace("操作員一鍵 v0109", "操作員一鍵 v0110") + "\n"
assert "v0109" not in boot10
one10 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot10.encode("utf-16-le")).decode("ascii"); assert len(one10) < 8191
title9, rest9 = md9.split("\n\n", 1)
assert title9.startswith("# VRN-1 / VRN-2 操作員一鍵 v0109(")
rest = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", rest9, count=1)
rest = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", rest, count=1)
rest = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", rest, count=1)
rest = rest.replace(cs9_old, cs10).replace(cs9_old[:12], cs10[:12])
text = ("# VRN-1 / VRN-2 操作員一鍵 v0110(cmd / PowerShell 都能貼 · v0109 + ② 改指 VRN-2 一鍵 v0149:四點原文核對認得行尾連字號 · ⑥e 擷取 Python 照 VDF 界線)\n\n"
        "桌機 2026-10-29 17:01 跑 `VRN2_RoundAll_v0101.py`(紅 4 · 黃 11)→ VRN-2 v0149 + `VRN2_RoundAll_v0102.py`(`vrn2_release_v0149` · 一個指令見 `VRN2_RoundAll_v0102.md` 的 pwsh 那行)。v0110 = v0109 + ② 改指 **VRN-2 一鍵 v0149**"
        "(套件 v0149 = 啟動器 v0149 + runtime v0149 = v0148 + VerbatimVerifier v0105 · IndependentVerifier v0111 · MarketFetchRun v0100);其餘一字不改。\n\n" + rest)
text = text.replace("@PS@", p10).replace("@BOOT@", boot10.rstrip("\n")).replace("@ONE@", one10)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p10 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot10
(op10 / "VRN1_VRN2_OneClick_v0110.md").write_text(text, encoding="utf-8", newline="\n"); (op10 / "boot_pair110.ps1").write_text(boot10, encoding="utf-8", newline="\n"); (op10 / "oneline_pair110.txt").write_text(one10 + "\n", encoding="utf-8"); (op10 / "Run-VRN1-VRN2-v0110.ps1").write_text(p10 + "\n", encoding="utf-8", newline="\n"); (op10 / "code_sha.txt").write_text(cs10)
(op10 / "VRN1_VRN2_Verification_v0110.md").write_text(
    "# VRN-1 / VRN-2 操作員一鍵 v0110 · 容器驗證(2026-10-29)\n\nv0110 = v0109 的程式碼只改四處:② 發行夾 `vrn2_release_v0148` → `vrn2_release_v0149`、`$H2` → VRN-2 一鍵 v0149 程式碼 SHA-256(`%s`)、橫幅「操作員一鍵 v0109」→「v0110」、② 的步驟名 / 檔名 v0148 → v0149;歷史子句與 md 歷史段落照舊。\n\n"
    "| 檢查 | 結果 |\n|---|---|\n| pwsh 7.4.6 語法剖析(Run-VRN1-VRN2-v0110.ps1 · boot_pair110.ps1)| 見 `vrn2_release_v0149/logs_v0149.zip` 的 `pscheck149.log` |\n| 本段程式碼 SHA-256 = boot 裡的 `$H` | 同上 |\n| 一行(-EncodedCommand)解碼 = boot | 同上 |\n"
    "| `$H2` = `VRN2_OneClick_v0149.md` 程式碼 SHA-256 | 同上 |\n| 橫幅版號 | `操作員一鍵 v0110` |\n| 本地實測一輪 v0100 的 `$H_OP` = 本段程式碼 SHA-256 | 同上 |\n\n沒有 .ps1 進倉:一鍵程式碼只在本夾的 md 裡,`tools_v0110.zip` 是容器測試用副本。\n" % cs[:12], encoding="utf-8", newline="\n")
print("operator v0110", cs10[:12])
# ===== LocalRound re-point =====
lr = REPO / "VRN2_LocalRound_v0100.md"; s = lr.read_text(encoding="utf-8")
if "VRN1_VRN2_OneClick_v0110.md" in s:
    s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0110 程式碼 SHA-256", "$H_OP = '%s'   # 操作員一鍵 v0110 程式碼 SHA-256" % cs10, s, count=1); assert cs10 in s
    lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP refreshed", cs10[:12]); raise SystemExit(0)


def lrep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)


lrep("# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0148(開 Workbench)→ 打包貼回材料)", "# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0149(開 Workbench)→ 打包貼回材料)")
lrep("> **2026-10-29 v0148 改指(", "> **2026-10-29 v0149 改指(桌機 17:01 跑 VRN2_RoundAll_v0101 的貼回):** 本段現在指 操作員一鍵 **v0110** → VRN-2 一鍵 **v0149**(四點原文核對認得 PDFium 的行尾連字號 · ⑥e 擷取 Python 照 VDF 引擎版本界線)。另一支 Python 升 **`vrn2_release_v0149/VRN2_RoundAll_v0102.py`**(一個指令:`VRN2_RoundAll_v0102.md` 的 pwsh 那行 · ⑪ FAIL 印原文證據);本段 ④ 貼回包多收 `VRN2_FailEvidence_latest.json`。\n> **2026-10-29 v0148 改指(")
lrep("本段現在指 操作員一鍵 **v0109** → VRN-2 一鍵 **v0148**", "本段當時指 操作員一鍵 **v0109** → VRN-2 一鍵 **v0148**")
lrep("從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0109.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0148 套件**(啟動器 v0148 → ", "從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0110.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0149 套件**(啟動器 v0149 → 四點原文核對 v0105 · ⑥e 擷取 Python 照 VDF 界線;v0148 的 ")
lrep("最後 300 行貼包 · `VRN2_Closeout_v0148.json` ·", "最後 300 行貼包 · `VRN2_Closeout_v0149.json` ·")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0109 程式碼 SHA-256\(VRN1_VRN2_OneClick_v0109\.md powershell 區塊 · ② 指 VRN-2 一鍵 v0148\)", "$H_OP = '%s'   # 操作員一鍵 v0110 程式碼 SHA-256(VRN1_VRN2_OneClick_v0110.md powershell 區塊 · ② 指 VRN-2 一鍵 v0149)" % cs10, s, count=1); assert cs10 in s
lrep("  $k3 = '③ 跑 VRN-2 v0148'", "  $k3 = '③ 跑 VRN-2 v0149'")
lrep("  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0109' 'VRN1_VRN2_OneClick_v0109.md' $H_OP", "  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0110' 'VRN1_VRN2_OneClick_v0110.md' $H_OP")
lrep("  foreach ($rel in 'VRN2_Closeout_v0148.json', 'VRN2_RoundAll_latest.json',", "  foreach ($rel in 'VRN2_Closeout_v0149.json', 'VRN2_RoundAll_latest.json', 'VRN2_FailEvidence_latest.json',")
lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP", cs10[:12])
