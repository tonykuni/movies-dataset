"""收尾 v0149:results → VRN2_Release_v0149.json.results · VRN2_Verification_v0149.md(套件 zip 已定,不重算)。"""
import glob, json, re, zipfile
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v149")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def lines(p):
    try: return [l for l in Path(p).read_text(encoding="utf-8", errors="replace").splitlines() if "<Objs" not in l and "</S>" not in l and "<S N=" not in l]
    except OSError: return []
def grep(p, pat, all_=False):
    hits = [l for l in lines(p) if re.search(pat, l)]
    return hits if all_ else (hits[-1] if hits else "")
def esc(x): return str(x).replace("|", "\\|")
v2 = W / "t149/VIA/VIA_Reports/vrn2"
ra1 = W / "ra149_first.log"; ra2 = W / "ra149_fix.log"
top = lambda p: [l for l in lines(p) if re.match(r"^\[(GREEN|YELLOW|RED|GRAY)\] |^NEXT:|^總表", l)]
first_rows, fix_rows = top(ra1), top(ra2)
def count(rows):
    c = {k: sum(1 for l in rows if l.startswith("[%s]" % k)) for k in ("GREEN", "YELLOW", "RED", "GRAY")}
    return c
reds1 = [l[:200] for l in first_rows if l.startswith("[RED]")]
st = j(v2 / "VRN2_OutputStore_latest.json", {}) or {}; hist = j(v2 / "VRN2_HistoryAlign_latest.json", {}) or {}; integ = j(v2 / "VRN2_Integrate_latest.json", {}) or {}
comb = j(v2 / "output/VRN2_Combined_latest.json", []) or []; cl = j(v2 / "VRN2_Closeout_v0149.json", {}) or {}
zips = sorted(glob.glob(str(W / "t149/home/Downloads/VRN2_PasteBack_*.zip")))
pz = zipfile.ZipFile(zips[-1]).namelist() if zips else []
selft = {n: grep(W / f, r"--selftest · .*不過 0|\[PASS\] v0149|\[PASS\] v0111") [:200] for n, f in (("VRN2_RoundAll_v0102", "roundall102_selftest.log"), ("VRN2_VerbatimVerifier_v0105", "VRN2_VerbatimVerifier_v0105_selftest.log"), ("VRN2_IndependentVerifier_v0111(VIA 樹內)", "VRN2_IndependentVerifier_v0111_selftest.log"), ("VRN2_MarketFetchRun_v0100(VIA 樹內 · 共用 MarketFetch v0112 在)", "VRN2_MarketFetchRun_v0100_selftest.log"), ("ActivateVRN-2_v0149(建置夾)", "ActivateVRN-2_v0149_selftest.log"), ("ActivateVRN-2_v0149(套件夾複本 · VRN2_OUTPUT_DIR / VIA_ROOT 已設)", "ActivateVRN-2_v0149_selftest_iso.log"))}
repro = {"四點原文核對 v0104 vs v0105 · 產生的 PDF(行尾「Type-」下一行「C PD」)": grep(W / "VRN2_VerbatimVerifier_v0105_selftest.log", r"⑤ 真 PDF")[:220],
         "沙盒 52 點回歸(v0148 輸出 · 19 份樣本)": grep(W / "vv_regress149.log", r"四點原文核對")[:220],
         "MarketFetch v0112 自己挑 Python(Windows 版面 · VIA_FETCH_PY 已設 · via_tw_fetch 沒裝)": grep(W / "repro_marketfetch149.log", r"^MarketFetch v0112")[:260],
         "MarketFetchRun v0100 照 VDF 引擎界線挑": grep(W / "repro_marketfetch149.log", r"^MarketFetchRun")[:300],
         "RoundAll v0101 SyntaxWarning(-W error 編譯)": grep(W / "repro_syntaxwarning149.log", r"SyntaxError")[:120] + " · " + grep(W / "repro_syntaxwarning149.log", r"v0102 compile clean"),
         "端到端:pwsh 一行指令取 RoundAll v0102": grep(ra1, r"\[VRN-2\] PowerShell")[:120] + " · " + re.sub(r" → .*", "", grep(ra1, r"SHA-256 .* 相符"))[:140],
         "端到端:⑥e 沒有合界線的 Python → 不啟動引擎": grep(ra1, r"⑥e 擷取 Python · 沒有合 VDF")[:260]}
c1, c2 = count(first_rows), count(fix_rows)
st_rows = [l for l in first_rows if "③ 自測 ·" in l]; st_green = sum(1 for l in st_rows if l.startswith("[GREEN]"))
red_names = sorted({re.sub(r"^\[RED\] ", "", l).split(" · ")[0] for l in reds1})
skipped = [Path(str(s_.get("path", ""))).name for s_ in (integ.get("skipped") or [])]
e2e = {"summary": "RoundAll 全流程 %s(綠 %d · 黃 %d · 紅 %d · 灰 %d)· ③ 自測 %d 支 · 綠 %d · 紅的步驟:%s · Combined %d 列 · 整合 %s(套用 %d · 略過 %s)"
              % (re.sub(r" · 貼回包 .*", "", grep(ra1, r"^NEXT:")), c1["GREEN"], c1["YELLOW"], c1["RED"], c1["GRAY"], len(st_rows), st_green, " / ".join(red_names) or "無", len(comb),
                 integ.get("state"), len(integ.get("applied") or []), "、".join(skipped) or "無"), "reds": reds1, "rows": first_rows}
fix = {"summary": "只修回合 %s(綠 %d · 黃 %d · 紅 %d):⑤ 計畫 %s · 歷史對齊 %s · 長線庫 %s(Combined 值變了的列另存一版,舊版留著)"
              % (re.sub(r" · 貼回包 .*", "", grep(ra2, r"^NEXT:")), c2["GREEN"], c2["YELLOW"], c2["RED"], grep(ra2, r"⑤ 自動修計畫")[len("[計] ⑤ 自動修計畫:"):][:200], str(hist.get("why", ""))[:160], json.dumps(st.get("totals") or {}, ensure_ascii=False)), "rows": fix_rows}
R = {"selftests": selft, "pwsh_hash_chain": [l for l in lines(W / "pscheck149.log") if l.strip()],
     "roundall_e2e": e2e, "roundall_fix_pass": fix,
     "store_after_fix": {k: st.get(k) for k in ("lamp", "store_engine", "appended", "backfilled", "totals")}, "history_after_fix": {k: hist.get(k) for k in ("lamp", "why", "totals")},
     "integrate": {"state": integ.get("state"), "applied": len(integ.get("applied") or []), "skipped": [(Path(str(s.get("path", ""))).name, s.get("why")) for s in integ.get("skipped") or []]},
     "combined_first_row": {k: (comb[0].get(k) if comb else None) for k in ("FILENAME", "TARGET_PRICE", "TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN", "2026_DILUTED_EPS_FACTSET", "2026_PER_FACTSET", "UPSIDE_PCT(ADJ)")},
     "receipt_roundall": cl.get("roundall"), "desktop_reproduction": repro, "pasteback_zip": {"name": Path(zips[-1]).name if zips else None, "members": len(pz), "has": [m for m in pz if m.endswith(("transcript.txt", "VRN2_RoundAll_latest.json", "VRN2_Closeout_v0149.before_roundall.json", "VRN2_FinancialAligned_latest.csv", "VRN2_Deleted_latest.csv", "factset_yfinance_consensus_quality_matrix.csv"))]},
     "oneclick_scenario_pwsh": {"rc": (W / "scen149.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen149.rc").exists() else "not run",
                                "first": grep(W / "scen149_first.log", r"③ 套件 v0149 就位|③ 本機已是 v0149")[:200], "again": grep(W / "scen149_again.log", r"③ 本機已是 v0149")[:200],
                                "tamper": grep(W / "scen149_tamper.log", r"③ 舊套件夾已改名備份")[:160], "closeout": grep(W / "scen149_first.log", r"⑧b 收尾收據 v0149")[:200], "roundall_hint": grep(W / "scen149_first.log", r"VRN2_RoundAll_v0102")[:160]},
     "not_claimed": ["Windows desktop run of v0149 / RoundAll v0102: not yet (next paste-back) · the pwsh line was run with pwsh 7.4.6 on Linux, not 7.6.9 on Windows",
                     "MS-3661 / MS-6669 / MS-8358 / MS-8210 step-11 FAIL on the desktop: not reproduced (the same MS-3661 PDF extracts 3190.00 and passes here); v0102 prints the book values + source lines next run",
                     "6e real fetch: no Python in the container meets the VDF bounds (pandas 3 · no yfinance / duckdb) and there is no network → the 'found' path is proven by the runner selftest with scratch venvs + fake distributions, not by a live VDF fetch",
                     "6f live cnyes / Yahoo and the desktop's gate FAIL_CLOSED rows: offline fixtures only; the quality-row print is proven by the RoundAll selftest",
                     "260914_daiwa_aspeed.pdf annual null-marker cell: not in the container samples",
                     "Windows-only paths (os.startfile, winreg vrn2:// lookup, Scripts\\python.exe layout) are exercised by code review, the Windows-layout reproduction and the posix equivalents only"]}
rel_p = W / "release149/VRN2_Release_v0149.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
md = ["# VRN-2 v0149 + VRN2_RoundAll_v0102 容器實測紀錄(2026-10-29)", "",
      "桌機 2026-10-29 17:01 跑 VRN2_RoundAll_v0101 的貼回(52 份 · 2345 秒 · 紅 4 黃 11)+ 操作員「我的PS是7.6.9請用一個指令完成剩餘工作完成系統」→ 能在容器重現 / 驗證的修成 v0149(見發行清單 `fixes` · `not_fixed_here`)。", "",
      "## 0. 桌機問題在容器重現 / 驗證", "", "| 項目 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有)") for k, v in repro.items()] + ["",
      "## 1. 自測", "", "| 檔 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有 PASS 行)") for k, v in selft.items()] + ["",
      "## 2. PowerShell 雜湊鏈(pwsh 7.4.6)", "", "```", *R["pwsh_hash_chain"], "```", "",
      "## 3. 端到端:一個指令(pwsh -EncodedCommand)在仿桌機沙盒取 RoundAll v0102 跑全流程(殼有 VIA_ROOT · envs 有退役環境 + 沒裝套件的 via_tw_fetch · 套件從假 GitHub 分支取 · 共用 MarketFetch v0112 + VDF v039 在 · 輸出夾在 OneDrive · 舊 Google Sheet CSV · 19 份真實樣本)", "",
      e2e["summary"], "", "```", *[l[:260] for l in first_rows], "```", "",
      "## 4. 只修回合(`--skip-package --skip-selftest --skip-run`,先放一份合成的市場資料)", "", fix["summary"], "", "```", *[l[:260] for l in fix_rows], "```", "",
      "| 項目 | 值 |", "|---|---|", "| 長線庫(修後)| %s |" % esc(json.dumps(R["store_after_fix"], ensure_ascii=False)), "| 歷史對齊(修後)| %s |" % esc(json.dumps(R["history_after_fix"], ensure_ascii=False)[:600]),
      "| 舊資料庫整合 | %s |" % esc(json.dumps(R["integrate"], ensure_ascii=False)), "| Combined 第一列 | %s |" % esc(json.dumps(R["combined_first_row"], ensure_ascii=False)),
      "| 收尾收據的 roundall 欄 | %s |" % esc(json.dumps(R["receipt_roundall"], ensure_ascii=False)[:500]), "| 貼回包 | %s |" % esc(json.dumps(R["pasteback_zip"], ensure_ascii=False)), "",
      "## 5. 一鍵 v0149 使用者情境(pwsh · 假 GitHub 分支 → 跑 → 再貼 → 竄改)", "", "| 項目 | 值 |", "|---|---|"] + ["| %s | %s |" % (k, esc(v)) for k, v in R["oneclick_scenario_pwsh"].items()] + ["",
      "## 6. 沒做到 / 沒驗到(照實)", ""] + ["- %s" % x for x in R["not_claimed"]]
(W / "release149/VRN2_Verification_v0149.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
print("finalize149 ok ·", e2e["summary"][:120], "·", fix["summary"][:120])
