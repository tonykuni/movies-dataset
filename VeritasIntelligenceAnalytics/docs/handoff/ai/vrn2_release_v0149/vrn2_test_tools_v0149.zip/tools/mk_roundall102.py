"""VRN2_RoundAll_v0102.py = v0101 + 桌機 2026-10-29 17:01 貼回修正(套件 v0149 · VDF 版本界線挑擷取 Python · ⑪ 失敗證據 · ⑥f 閘失敗列 · docstring 反斜線)。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v148/new/VRN2_RoundAll_v0101.py").read_text(encoding="utf-8")
start = src.index('"""VRN2_RoundAll v0101')
end = src.index('"""', start + 3) + 3
head, doc, body = src[:start], src[start:end], src[end:]

# ---- docstring ----
v0101_at = doc.index("v0101(桌機 2026-10-29 14:40")
general_at = doc.index("操作員令(2026-10-29)")
old_head, v0101_part, general = doc[:v0101_at], doc[v0101_at:general_at], doc[general_at:]
assert old_head.startswith('"""VRN2_RoundAll v0101 — ')
new_head = old_head.replace('"""VRN2_RoundAll v0101 — ', '"""VRN2_RoundAll v0102 — ', 1)
v0102_part = r'''v0102(桌機 2026-10-29 17:01 跑 v0101 的貼回 · 紅 4 黃 11 ·「我的 PS 是 7.6.9 請用一個指令完成剩餘工作完成系統」):
  · 套件 v0149(啟動器 v0149 · runtime v0149 = v0148 的 181 個成員不動 + VerbatimVerifier v0105 · IndependentVerifier v0111 · MarketFetchRun v0100)。
  · 收尾 rc 1 的唯一原因 = 四點原文核對 3014TT-20231005.pdf 第 3 點 FAIL:摘錄(pdfplumber)「…聯陽Type-」換行「C PD 至少」,PDFium 把行尾連字號寫成
    U+FFFE 並吃掉換行 →「Type\ufffeC」;v0104 只在下一字小寫時接合、也不認 U+FFFE。VerbatimVerifier v0105 / IndependentVerifier v0111 把兩種寫法當同一段字
    (只改比對形式,冊裡的摘錄不動)· 容器用產生的 PDF 重現:v0104 FAIL · v0105 PASS。
  · ⑥e 擷取黃的根因:啟動器給 MarketFetch 的是 envs\\via_core_312(套件都在),但 MarketFetch 自己的 fetch_python() 只要 envs\\via_tw_fetch 夾在就用它 ——
    那個環境什麼都沒裝(VDF 引擎上一輪在那裡 pip 失敗)。runtime 的 VRN2_MarketFetchRun_v0100 載入共用 MarketFetch(不改不抄)、只換掉它的
    fetch_python(),換成第一個通過 VDF 引擎自己檢查的 Python(同模組 · 同 >= / < 界線,從引擎檔讀 · Python 3.11+)。都不合 → 不啟動引擎(它會自己 pip)·
    印每個候選缺什麼 + 交 VCGC 的指令(帶版本界線 · 加引號,cmd 的 < 不會被當成導向)。② 也用同一支工具診斷。
  · ⑥ 除錯多印:⑪ 基本資料 FAIL 的冊值 + 原 PDF 前 4 頁對到的行(→ VRN2_FailEvidence_latest.json · 進貼回包)· ⑪ 用的驗證器版本 ·
    ⑥f 共識閘 FAIL_CLOSED 的不過檢查列(quality_matrix.csv)· ⑥e 擷取 Python 每個候選缺什麼。
  · ③ 自測多跑 VerbatimVerifier v0105 · MarketFetchRun v0100(IndependentVerifier v0111 要 VIA 樹 → 在 ⑪ 真跑時用,⑥ 印它的版本)。
  · 本檔 docstring 的 Windows 路徑反斜線全部成對(v0101 在桌機印 SyntaxWarning: invalid escape sequence '\\l')。
  · 一行指令兩種:pwsh(PowerShell 7.x · 例 7.6.9)與 Windows PowerShell 5.1,內容相同(見 VRN2_RoundAll_v0102.md)。

'''
general = general.replace("這些都在 VRN-2 套件 v0148 裡", "這些都在 VRN-2 套件 v0149 裡").replace("Downloads\\\\VRN2_Closeout_v0148", "Downloads\\\\VRN2_Closeout_v0149")
general = general.replace("ActivateVRN-2_v0148(", "ActivateVRN-2_v0149(").replace("用法:python VRN2_RoundAll_v0101.py", "用法:python VRN2_RoundAll_v0102.py")
general = general.replace("十支 --selftest + 啟動器 --selftest", "十二支 --selftest + 啟動器 --selftest")
assert "v0148" not in general, re.findall(r".{20}v0148.{20}", general)
doc = new_head + v0102_part + v0101_part + general
doc = re.sub(r"(?<!\\)\\(?!\\)", r"\\\\", doc)                        # 單一反斜線 → 成對(v0102_part 本來就成對,不受影響)
assert "\\l" not in doc.replace("\\\\", "")

# ---- body ----
body = body.replace("v0148", "v0149")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0101"', 'VERSION = "v0102"')
rep('''             ("VRN2_UIAction_v0110.py", 300), ("VRN2_SSOTSync_v0101.py", 300), ("VRN2_OutputStore_v0101.py", 300), ("VRN2_ConsensusJoin_v0101.py", 900), ("VRN_SystemManager_v0255.py", 1800))''',
    '''             ("VRN2_UIAction_v0110.py", 300), ("VRN2_SSOTSync_v0101.py", 300), ("VRN2_OutputStore_v0101.py", 300), ("VRN2_ConsensusJoin_v0101.py", 900), ("VRN_SystemManager_v0255.py", 1800),
             ("VRN2_VerbatimVerifier_v0105.py", 300), ("VRN2_MarketFetchRun_v0100.py", 600))
MARKET_RUNNER = "VRN2_MarketFetchRun_v0100.py"                       # v0102:⑥e 擷取 Python 照 VDF 引擎自己的版本界線挑(runtime 裡 · 只用標準庫)
VDF_BOUNDS = ("pandas>=2.2,<3", "pyarrow>=17,<27", "duckdb>=1.1,<3", "yfinance>=0.2.54,<2", "lxml>=5,<7", "tzdata>=2024.1")   # VDF_TW_AllInOne_v039 · 實際以引擎檔為準''')
rep('''               "output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "market/vdf/last_error.txt", "consensus/VRN2_YFTickerMap_latest.json")''',
    '''               "output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "market/vdf/last_error.txt", "consensus/VRN2_YFTickerMap_latest.json",
               "VRN2_FailEvidence_latest.json", "consensus/factset_yfinance_consensus_quality_matrix.csv")''')
rep('''VCGC_FETCH_ENV = ('python -m venv "%USERPROFILE%\\\\envs\\\\via_tw_fetch"', '"%USERPROFILE%\\\\envs\\\\via_tw_fetch\\\\Scripts\\\\python.exe" -m pip install ' + " ".join(FETCH_REQUIRED))''',
    '''VCGC_FETCH_ENV = ('python -m venv "%USERPROFILE%\\\\envs\\\\via_tw_fetch"', '"%USERPROFILE%\\\\envs\\\\via_tw_fetch\\\\Scripts\\\\python.exe" -m pip install ' + " ".join('"%s"' % b for b in VDF_BOUNDS))   # v0102:帶 VDF 界線 · 加引號''')

# ---- ② 擷取 Python 照 VDF 界線 ----
rep('''# ===== 4. ① 套件 =====''', r'''def runner_from_package(pkg):
    """v0102:⑥e 挑 Python 的工具(VRN2_MarketFetchRun)從套件的 runtime zip 取出 → TEMP(對清單雜湊 · 不對不用)。"""
    manifest = jread(Path(pkg) / RUNTIME_MANIFEST, {}) or {}
    want = {e.get("path"): e.get("sha256") for e in manifest.get("files") or []}.get(MARKET_RUNNER)
    try:
        with zipfile.ZipFile(Path(pkg) / RUNTIME_ZIP) as z:
            data = z.read(MARKET_RUNNER)
    except (OSError, KeyError, zipfile.BadZipFile):
        return None
    if not want or hashlib.sha256(data).hexdigest() != want:
        return None
    folder = Path(tempfile.mkdtemp(prefix="vrn2_roundall_mr_"))
    (folder / MARKET_RUNNER).write_bytes(data)
    return folder / MARKET_RUNNER


def pick_fetch_python(pkg, vpy: str, tool, preferred=None) -> dict:
    """v0102:哪個 Python 通過 VDF 引擎自己的套件檢查(同模組 · 同界線 · 3.11+)→ {python, fill_python, requirements, candidates, why}。不裝任何東西。"""
    runner = runner_from_package(pkg) if pkg else None
    if not runner:
        return {"python": None, "why": "套件 runtime 裡沒有 %s(或雜湊不對)" % MARKET_RUNNER, "candidates": [], "requirements": []}
    cmd = [vpy, "-X", "utf8", str(runner), "--tool", str(tool)] + (["--python", str(preferred)] if preferred else []) + ["--pick-python"]
    try:
        done = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
        return json.loads((done.stdout.strip().splitlines() or ["{}"])[-1])
    except Exception as error:  # noqa: BLE001
        return {"python": None, "why": "%s: %s" % (type(error).__name__, str(error)[:160]), "candidates": [], "requirements": []}
    finally:
        shutil.rmtree(str(runner.parent), ignore_errors=True)


def vcgc_fetch_commands(bounds=None) -> list:
    """交 VCGC 建 via_tw_fetch 的指令(cmd 與 PowerShell 各一組 · 界線加引號)。"""
    pins = " ".join('"%s"' % b for b in (bounds or VDF_BOUNDS))
    return ['cmd        : python -m venv "%USERPROFILE%\\envs\\via_tw_fetch"',
            'cmd        : "%USERPROFILE%\\envs\\via_tw_fetch\\Scripts\\python.exe" -m pip install ' + pins,
            'PowerShell : python -m venv "$env:USERPROFILE\\envs\\via_tw_fetch"',
            'PowerShell : & "$env:USERPROFILE\\envs\\via_tw_fetch\\Scripts\\python.exe" -m pip install ' + pins]


# ===== 4. ① 套件 =====''')
rep('''        state["market_tool"] = str(tools[-1]) if tools else ""
        say("GREEN" if tools and eng else "YELLOW", "② 共用市場擷取工具",''', '''        state["market_tool"] = str(tools[-1]) if tools else ""
        if tools and pkg:
            picked = pick_fetch_python(pkg, vpy, tools[-1], fpy)
            state["bounds_python"] = picked.get("python")
            bounds = [r[1] for r in picked.get("requirements") or []] or list(VDF_BOUNDS)
            if picked.get("python"):
                say("GREEN", "② 擷取 Python · VDF 版本界線(⑥e)", "%s · 合 %s(%s)" % (picked["python"], " ".join(bounds), picked.get("requirements_from", "")))
            else:
                say("YELLOW", "② 擷取 Python · VDF 版本界線(⑥e)", "沒有合 %s 的 Python:%s" % (" ".join(bounds), str(picked.get("why", ""))[:500]),
                    "⑥e 會黃(不啟動 VDF 引擎 · 免得它自己 pip);填值照用現有 Parquet。交 VCGC 建 via_tw_fetch(VRN-2 不裝):\\n         " + "\\n         ".join(vcgc_fetch_commands(bounds)))
        say("GREEN" if tools and eng else "YELLOW", "② 共用市場擷取工具",''')

# ---- ⑤ 重抓 ⑥e 經 runner ----
rep('''            for verb in ("--fetch", "--fill"):
                rc, lines = run_stream([fetch_py, "-X", "utf8", str(tool), verb, "--basic", str(basic), "--out", str(v2 / "market")], cwd=tool.parent, env=env, timeout=2400, prefix="    [⑥e] ")''',
    '''            runner = rt / MARKET_RUNNER                                  # v0102:runtime 有 MarketFetchRun → 經它跑(fetch_python 換成合 VDF 界線的)
            py = state.get("bounds_python") or fetch_py
            for verb in ("--fetch", "--fill"):
                head = [py, "-X", "utf8", str(runner), "--tool", str(tool), "--python", py] if runner.is_file() else [py, "-X", "utf8", str(tool)]
                rc, lines = run_stream(head + [verb, "--basic", str(basic), "--out", str(v2 / "market")], cwd=tool.parent, env=env, timeout=2400, prefix="    [⑥e] ")''')

# ---- ⑥ 除錯:⑪ 證據 · 驗證器版本 · ⑥f 閘 · ⑥e 候選 ----
rep('''def diagnose(root: Path) -> dict:
    v2 = Path(root) / "VIA_Reports" / "vrn2"''', r'''EVIDENCE_PY = r"""
import json, re, sys
pdf, values = sys.argv[1], json.loads(sys.argv[2])
labels = re.compile(r"price|target|close|upside|股價|目標|收盤|現價|潛在|漲幅|上漲", re.I)
def norm(s):
    return re.sub(r"[,\s]", "", str(s))
def core(v):
    v = norm(v)
    return v.rstrip("0").rstrip(".") if re.fullmatch(r"-?\d+\.\d+", v) else v
want = [core(v) for v in values if norm(v)]
out = []
try:
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(pdf)
    for i in range(min(4, len(doc))):
        for line in doc[i].get_textpage().get_text_range().replace("\r", "").split("\n"):
            hit = [w for w in want if w and w in norm(line)]
            if hit or (labels.search(line) and re.search(r"\d", line)):
                out.append({"page": i + 1, "line": line.strip()[:200], "values": hit})
except Exception as error:
    out.append({"error": "%s: %s" % (type(error).__name__, str(error)[:160])})
out.sort(key=lambda r: (not r.get("values"), r.get("page", 0)))
print(json.dumps(out[:40], ensure_ascii=False))
"""
EVIDENCE_FIELDS = ("CURRENT_PRICE_REPORT", "TARGET_PRICE", "UPSIDE_PCT", "RATING", "REPORT_DATE", "CURRENCY")


def fail_evidence(root: Path, vpy=None) -> list:
    """v0102:⑪ 基本資料 FAIL 的證據 = 冊值 + 原 PDF 前 4 頁含這些數或價格標籤的行(VRN-2 的 Python 用 pypdfium2 讀 · 只讀)→ VRN2_FailEvidence_latest.json。"""
    v2 = Path(root) / "VIA_Reports" / "vrn2"
    reps = sorted((v2 / "verify_independent").glob("VRN2_IndependentVerify_*.json"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    report = jread(reps[-1], {}) if reps else {}
    basic = {str(r.get("FILENAME")): r for r in (jread(v2 / "output" / "VRN2_BasicInfo_latest.json", []) or []) if isinstance(r, dict)}
    src_dir = (jread(v2 / "VRN2_Input_latest.json", {}) or {}).get("source_dir") or ""
    out = []
    for row in (report or {}).get("basic") or []:
        fails = {k: v for k, v in (row.get("checks") or {}).items() if str(v).startswith("FAIL")}
        if not fails:
            continue
        name = str(row.get("FILENAME"))
        rec = basic.get(name, {})
        values = {k: rec.get(k) for k in EVIDENCE_FIELDS if rec.get(k) not in (None, "")}
        pdf = next((p for p in (v2 / "scope_in" / name, Path(src_dir) / name if src_dir else None) if p and p.is_file()), None)
        lines = []
        if pdf and vpy:
            try:
                done = subprocess.run([vpy, "-X", "utf8", "-c", EVIDENCE_PY, str(pdf), json.dumps([values.get(k) for k in ("CURRENT_PRICE_REPORT", "TARGET_PRICE", "UPSIDE_PCT") if values.get(k)])],
                                      capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
                lines = json.loads((done.stdout.strip().splitlines() or ["[]"])[-1])
            except Exception as error:  # noqa: BLE001
                lines = [{"error": "%s: %s" % (type(error).__name__, str(error)[:160])}]
        out.append({"file": name, "fails": fails, "values": values, "pdf": str(pdf or ""), "lines": lines if pdf else [{"error": "找不到原檔(scope_in / 來源夾)"}]})
    if out:
        try:
            (v2 / "VRN2_FailEvidence_latest.json").write_text(json.dumps({"at": _dt.datetime.now().isoformat(timespec="seconds"), "verifier": (report or {}).get("version"), "files": out}, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError:
            pass
    return out


def quality_fails(v2: Path) -> list:
    """v0102:⑥f 共識引擎品質矩陣裡 status = FAIL 的列(gate FAIL_CLOSED 的原因)。"""
    import csv
    path = Path(v2) / "consensus" / "factset_yfinance_consensus_quality_matrix.csv"
    if not path.is_file():
        return []
    try:
        with path.open(encoding="utf-8-sig", newline="") as fh:
            return [r for r in csv.DictReader(fh) if str(r.get("status", "")).upper() == "FAIL"]
    except (OSError, csv.Error):
        return []


def diagnose(root: Path, vpy=None) -> dict:
    v2 = Path(root) / "VIA_Reports" / "vrn2"''')
rep('''    digests = sorted((v2 / "verify_independent").glob("*.digest.txt"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    if digests:''', r'''    fpick = (receipt.get("market") or {}).get("fetch_python") or {}
    if fpick and not fpick.get("python"):
        rows = fpick.get("candidates") or []
        f("YELLOW", "⑥e 擷取 Python(VDF 版本界線)", "沒有合界線的 · " + " | ".join("%s(%s):%s" % (r.get("how"), r.get("py_version"), " ".join((r.get("missing") or []) + ["匯入失敗 " + x for x in r.get("import_failed") or []]) or "?") for r in rows)[:600],
          "交 VCGC 建 via_tw_fetch(帶界線):" + " ; ".join(vcgc_fetch_commands()[2:]))
    elif fpick.get("python"):
        f("GREEN", "⑥e 擷取 Python(VDF 版本界線)", "%s · %s" % (fpick.get("python"), fpick.get("requirements_from", "")))
    qf = quality_fails(v2)
    if qf:
        codes = sorted({str(r.get("code")) for r in qf})
        f("YELLOW", "⑥f 共識閘 FAIL 列", "%d 列 · 代號 %s · %s" % (len(qf), ",".join(codes[:12]), " | ".join("%s %s 實際 %s 應為 %s(%s)" % (r.get("code"), r.get("check_id"), r.get("actual"), r.get("expected"), str(r.get("note", ""))[:60]) for r in qf[:6]))[:700],
          "共識引擎(原樣內附)品質閘不過就 FAIL_CLOSED;FactSet 沒有覆蓋的代號(未評等 / 新上市)= 真的沒有,其餘看 quality_matrix.csv")
    reps = sorted((v2 / "verify_independent").glob("VRN2_IndependentVerify_*.json"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    if reps:
        ver = str((jread(reps[-1], {}) or {}).get("version") or "?")
        num = re.search(r"_v(\d{4})$", ver)
        new_enough = bool(num) and int(num.group(1)) >= 111
        f("GREEN" if new_enough else "YELLOW", "⑪ 驗證器版本", "%s · %s" % (ver, reps[-1].name),
          "" if new_enough else "還是舊驗證器(行尾連字號會誤判)→ 套件 v0149 的 runtime 沒還原進 functional modules\\VRN2?看 ④ 的 runtime 那行")
    for ev in fail_evidence(root, vpy):
        hits = [r for r in ev["lines"] if r.get("values")][:3] or [r for r in ev["lines"] if r.get("line")][:3]
        err = next((r["error"] for r in ev["lines"] if r.get("error")), "")
        f("YELLOW", "⑪ 基本資料 FAIL 證據", "%s · %s · 冊值 %s · 原文 %s" % (ev["file"], " / ".join("%s %s" % (k, str(v)[:70]) for k, v in ev["fails"].items()), json.dumps(ev["values"], ensure_ascii=False)[:200],
          " | ".join("第 %s 頁「%s」" % (r.get("page"), r.get("line")) for r in hits)[:500] or err or "前 4 頁沒有對到的行"),
          "冊值與原文那行對不上 = 擷取取錯數;原文那行就是對的值 = 驗證器誤判。整份在 VRN2_FailEvidence_latest.json(貼回包裡)")
    digests = sorted((v2 / "verify_independent").glob("*.digest.txt"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    if digests:''')
rep('''    if want["report"] and root:
        report = diagnose(root)''', '''    if want["report"] and root:
        report = diagnose(root, vpy)''')

# ---- 自測:docstring 反斜線 · ⑥f 閘列 · ⑪ 證據 · VCGC 指令 ----
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · 16 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(bad)), flush=True)''', r'''        # ⑯ ~ ⑲ v0102
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("error")
            try:
                compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
                clean = True
            except SyntaxError:
                clean = False
        chk("⑯ 本檔編譯不出 SyntaxWarning(docstring 的 Windows 路徑反斜線成對 · v0101 在桌機印 invalid escape sequence)", clean)
        (v2 / "consensus" / "factset_yfinance_consensus_quality_matrix.csv").write_text("\ufeffcode,check_id,actual,expected,status,severity,note\n6933,FACTSET_TARGET,0,>0,FAIL,FAIL,no coverage\n2330,HTTP_PAGE_200,200,200,PASS,FAIL,ok\n", encoding="utf-8")
        vi = v2 / "verify_independent"
        vi.mkdir(exist_ok=True)
        (vi / "VRN2_IndependentVerify_20261029_000000.json").write_text(json.dumps({"version": "VRN2_IndependentVerifier_v0111", "basic": [{"FILENAME": "MS-3661 20251203.pdf", "checks": {"CURRENT_PRICE_REPORT": "FAIL · 前 4 頁沒有這個數", "TARGET_PRICE": "PASS · 第 1 頁"}}]}), encoding="utf-8")
        (v2 / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "MS-3661 20251203.pdf", "CURRENT_PRICE_REPORT": "3190.00", "TARGET_PRICE": "4388.00", "UPSIDE_PCT": "38"}]), encoding="utf-8")
        pdf_ok = False
        try:
            try:
                import pymupdf as fitz  # noqa: WPS433
            except ImportError:
                import fitz  # noqa: WPS433
            (v2 / "scope_in").mkdir(exist_ok=True)
            doc = fitz.open()
            page = doc.new_page()
            for i, line in enumerate(("Morgan Stanley Taiwan", "Price target NT$4,388.00", "Shr price, close (Dec 3, 2025) NT$3,190.00", "Up/downside to price target (%) 38")):
                page.insert_text((72, 72 + 16 * i), line, fontsize=11)
            doc.save(str(v2 / "scope_in" / "MS-3661 20251203.pdf"))
            import pypdfium2  # noqa: F401,WPS433
            pdf_ok = True
        except Exception:  # noqa: BLE001
            pass
        sys.stdout = io.StringIO()
        try:
            rep3 = diagnose(root, sys.executable)
        finally:
            sys.stdout = sys_stdout
        a3 = {x["area"]: x for x in rep3["findings"]}
        chk("⑰ 除錯:⑥f 共識閘 FAIL 列(只列 status FAIL:6933 FACTSET_TARGET)· ⑪ 驗證器版本 v0111 = 綠", "6933 FACTSET_TARGET" in a3.get("⑥f 共識閘 FAIL 列", {}).get("finding", "") and "2330" not in a3.get("⑥f 共識閘 FAIL 列", {}).get("finding", "")
            and a3.get("⑪ 驗證器版本", {}).get("lamp") == "GREEN")
        ev = a3.get("⑪ 基本資料 FAIL 證據", {}).get("finding", "")
        if pdf_ok:
            chk("⑱ 除錯:⑪ 基本資料 FAIL 證據 = 冊值 + 原 PDF 那一行(「Shr price, close (Dec 3, 2025) NT$3,190.00」)· 寫 VRN2_FailEvidence_latest.json", "MS-3661" in ev and "3,190.00" in ev and (v2 / "VRN2_FailEvidence_latest.json").is_file())
        else:
            chk("⑱ 除錯:⑪ 基本資料 FAIL 證據(本 Python 沒有 PyMuPDF / pypdfium2 → 只驗冊值與「找不到 / 讀不到」說明)", "MS-3661" in ev and "3190.00" in ev)
        cmds = vcgc_fetch_commands()
        chk("⑲ 交 VCGC 的擷取環境指令:cmd / PowerShell 各一組 · 帶 VDF 界線且加引號(cmd 的 < 不會變導向)", len(cmds) == 4 and '"pandas>=2.2,<3"' in cmds[1] and "$env:USERPROFILE" in cmds[3] and '"pandas>=2.2,<3"' in VCGC_FETCH_ENV[1])
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · 20 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(bad)), flush=True)''')
rep('hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0101.py"))', 'hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0102.py"))')
(S / "v149/new/VRN2_RoundAll_v0102.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0102 lines", s.count("\n"))
