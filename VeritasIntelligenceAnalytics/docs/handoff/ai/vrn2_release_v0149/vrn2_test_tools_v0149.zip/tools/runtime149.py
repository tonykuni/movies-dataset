import hashlib, json, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); old, new, out = S / "v148/pkg148", S / "v149/new", S / "v149/pkg149"
out.mkdir(parents=True, exist_ok=True)
om = json.loads((old / "VRN2_Runtime_v0148.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
with zipfile.ZipFile(old / "VRN2_Runtime_v0148.zip") as z: members = {n: z.read(n) for n in old_names}
for e in om["files"]: assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"]
new_names = ["VRN2_VerbatimVerifier_v0105.py", "VRN2_IndependentVerifier_v0111.py", "VRN2_MarketFetchRun_v0100.py"]
for n in new_names: assert n not in members, n; members[n] = (new / n).read_bytes()
assert members["VRN2_VerbatimVerifier_v0104.py"] == (old / "VRN2_VerbatimVerifier_v0104.py").read_bytes()   # 前版 = 套件裡那支(v0105 在兩處都疊在同一支 v0104 上)
assert "VRN2_IndependentVerifier_v0110.py" in members and "VIA_ExecutionBridge_v0103.py" in members
names = sorted(members); zp = out / "VRN2_Runtime_v0149.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0149", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0148.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names, "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0149.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(str(old / n), str(out / n))
for n in ("ActivateVRN-2_v0149.py", "VRN2_VerbatimVerifier_v0105.py"):
    shutil.copy2(str(new / n), str(out / n))
print("runtime v0149", len(names), man["zip_sha256"][:12], "· pkg149", sorted(p.name for p in out.iterdir()))
