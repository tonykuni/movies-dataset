#!/bin/bash
# 端到端(v0149):桌機情境 —— 用「一個指令」(pwsh -EncodedCommand 的 RoundAll 開機段)從假 GitHub 分支取 VRN2_RoundAll_v0102.py → 核對 SHA-256 → 跑全流程
# $1 = 回合名(first = 建沙盒 + 一行指令 · 其他 = 直接 python 跑 RoundAll,其餘參數照傳)
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v149; T=$W/t149; N="$1"; shift
OCRPY=$S/v131/ocrenv/vrn2_ocr/bin/python; P=$S2/venv_vrn2/bin/python
if [ "$N" = "first" ]; then
  rm -rf "${T:?}" "${T:?}.br" "${T:?}.setup.log"
  bash $S/v142/mktree142.sh $T $W/pkg149 "$S2/shipF/samples" > $W/t149_setup.log 2>&1 || { cat $W/t149_setup.log; exit 1; }
  rm -rf "${T:?}/pkg"
  R="/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN"
  mkdir -p "$T/VIA/functional modules/VRN/_vdf_fetch"; cp "$R/VRN2_MarketFetch_v0112.py" "$T/VIA/functional modules/VRN/"; cp "$R/_vdf_fetch/VDF_TW_AllInOne_v039.py" "$T/VIA/functional modules/VRN/_vdf_fetch/"
  (cd "$T/VIA" && git add -A >/dev/null 2>&1 && git -c user.email=t@t -c user.name=t commit -qm "shared tools" >/dev/null 2>&1; git push -q origin main >/dev/null 2>&1)
  B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0149; mkdir -p $D
  cp $W/release149/VRN2_Closeout_v0149.zip $W/release149/VRN2_Release_v0149.json $W/release149/VRN2_OneClick_v0149.md $W/release149/VRN2_RoundAll_v0102.py $W/release149/VRN2_RoundAll_v0102.md $D/
  (cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1)
  (cd "$T/VIA" && git fetch -q origin >/dev/null 2>&1)
  mkdir -p "$T/OneDrive/VRN2_out" "$T/home/OneDrive" "$T/home/Downloads"
  mkdir -p "$T/home/envs/via_core.retired-20260914_111946/bin" && ln -sf "$P" "$T/home/envs/via_core.retired-20260914_111946/bin/python"   # 退役環境不可當擷取 Python
  /usr/bin/python3 -m venv --without-pip "$T/home/envs/via_tw_fetch"                                                                       # 桌機情形:VDF 的 via_tw_fetch 在、但什麼都沒裝
  printf '\xef\xbb\xbfTicker,Date,Broker,Target Price,Rating\n2330,2025-10-01,CLSA,1200,BUY\n3008,2025-10-05,KGI,2500,HOLD\n' > "$T/OneDrive/VRN2_out/舊基本資料 - Sheet1.csv"
  FX=$(cat $S/v148/fx148.list)
  B64=$(cut -d' ' -f6 $W/release149/oneline_roundall_pwsh.txt)
  head -c 4 $W/release149/oneline_roundall_pwsh.txt | grep -q pwsh || { echo "not a pwsh line"; exit 1; }
  cd "$T/home" && env HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ENVS_HOME="$T/envs" VIA_TOOLS_ROOT="$T/VIA" VIA_ROOT="$T/VIA" \
    VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 \
    VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_OUTPUT_DIR="$T/OneDrive/VRN2_out" VRN2_CONSENSUS_FIXTURES="$FX" VRN2_CONSENSUS_YEAR=2026 VRN2_INTEGRATE_TEMP="$T/tmp" \
    VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_SOURCE="$T/samples" VRN2_ROUNDALL_ARGS="--python $P --no-open --integrate yes --launcher-args --no-install" \
    timeout 7000 "$S2/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -EncodedCommand "$B64" > $W/ra149_$N.log 2>&1
  echo "$N rc $?" >> $W/ra149.rc
  exit 0
fi
FX=$(cat $S/v148/fx148.list)
RA=$(ls "$T/home/Downloads/VRN2_RoundAll_v0102.py" "$T/home/"*VRN2_RoundAll_v0102.py 2>/dev/null | head -1)
cd "$T/home" && env HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ENVS_HOME="$T/envs" VIA_TOOLS_ROOT="$T/VIA" VIA_ROOT="$T/VIA" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 \
  VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_OUTPUT_DIR="$T/OneDrive/VRN2_out" VRN2_CONSENSUS_FIXTURES="$FX" VRN2_CONSENSUS_YEAR=2026 VRN2_INTEGRATE_TEMP="$T/tmp" \
  timeout 7000 $P "$RA" --root "$T/VIA" --python "$P" --no-open "$@" > $W/ra149_$N.log 2>&1
echo "$N rc $?" >> $W/ra149.rc
