#!/bin/bash
# 桌機問題在容器重現(v0149):① 行尾連字號 v0104 vs v0105(產生的 PDF + 沙盒 52 點回歸)② MarketFetch v0112 自己挑 via_tw_fetch ③ RoundAll v0101 SyntaxWarning
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; P=$S2/venv_vrn2/bin/python; W=$S/v149
R="$W/t_ivtree/VIA/functional modules/VRN2"
(cd $W/t_vv && cp $W/new/VRN2_VerbatimVerifier_v0105.py . && $P VRN2_VerbatimVerifier_v0105.py --selftest) > $W/VRN2_VerbatimVerifier_v0105_selftest.log 2>&1
(cd "$R" && cp $W/new/VRN2_VerbatimVerifier_v0105.py $W/new/VRN2_IndependentVerifier_v0111.py $W/new/VRN2_MarketFetchRun_v0100.py . && $P VRN2_IndependentVerifier_v0111.py --selftest) > $W/VRN2_IndependentVerifier_v0111_selftest.log 2>&1
(cd "$R" && $P VRN2_MarketFetchRun_v0100.py --selftest) > $W/VRN2_MarketFetchRun_v0100_selftest.log 2>&1
cd "$R" && $P - "$S/v148/t148/VIA/VIA_Reports/vrn2" > $W/vv_regress149.log 2>&1 <<'PY'
import sys, importlib.util, collections
from pathlib import Path
o = Path(sys.argv[1])
def load(n, name):
    sp = importlib.util.spec_from_file_location(name, n); m = importlib.util.module_from_spec(sp); sys.modules[name] = m; sp.loader.exec_module(m); return m
r4 = load("VRN2_VerbatimVerifier_v0104.py", "vv4").verify(o / "output", o / "scope_in")
r5 = load("VRN2_VerbatimVerifier_v0105.py", "vv5").verify(o / "output", o / "scope_in")
print("沙盒 v0148 輸出(19 份樣本)四點原文核對:v0104 %s · v0105 %s · 狀態不同的點 %d" % (dict(collections.Counter(x["state"] for x in r4["rows"])), dict(collections.Counter(x["state"] for x in r5["rows"])),
      sum(1 for a, b in zip(r4["rows"], r5["rows"]) if a["state"] != b["state"])))
PY
H=$W/repro_home; rm -rf "${H:?}"; mkdir -p "$H/envs"; /usr/bin/python3 -m venv --without-pip "$H/envs/via_tw_fetch"; mkdir -p "$H/envs/via_tw_fetch/Scripts" && ln -sf ../bin/python "$H/envs/via_tw_fetch/Scripts/python.exe"   # Windows 版面(MarketFetch 只認 Scripts\\python.exe)
cd "$R" && env USERPROFILE="$H" HOME="$H" VIA_FETCH_PY="$P" $P - "$W/t_ivtree/VIA/functional modules/VRN/VRN2_MarketFetch_v0112.py" > $W/repro_marketfetch149.log 2>&1 <<'PY'
import importlib.util, sys
from pathlib import Path
sp = importlib.util.spec_from_file_location("mf", sys.argv[1]); mf = importlib.util.module_from_spec(sp); sp.loader.exec_module(mf)
print("MarketFetch v0112 fetch_python()(VIA_FETCH_PY = VRN-2 的 python · envs/via_tw_fetch 在、沒裝套件)→ %s" % mf.fetch_python())
sp2 = importlib.util.spec_from_file_location("mr", "VRN2_MarketFetchRun_v0100.py"); mr = importlib.util.module_from_spec(sp2); sp2.loader.exec_module(mr)
reqs, src = mr.requirements(mf.engine_path())
py, rep, skipped = mr.pick(reqs, None, mr.probe_modules_of(Path(sys.argv[1])))
print("MarketFetchRun v0100 照 %s 的界線挑 → %s · %s" % (src, py, mr.explain(rep, skipped)[:600]))
PY
$P -W error -c "import sys,pathlib;compile(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'),'VRN2_RoundAll_v0101.py','exec')" "$S/v148/release148/VRN2_RoundAll_v0101.py" > $W/repro_syntaxwarning149.log 2>&1; echo "v0101 rc $?" >> $W/repro_syntaxwarning149.log
$P -W error -c "import sys,pathlib;compile(pathlib.Path(sys.argv[1]).read_text(encoding='utf-8'),'VRN2_RoundAll_v0102.py','exec');print('v0102 compile clean')" "$W/release149/VRN2_RoundAll_v0102.py" >> $W/repro_syntaxwarning149.log 2>&1; echo "v0102 rc $?" >> $W/repro_syntaxwarning149.log
echo repro done
