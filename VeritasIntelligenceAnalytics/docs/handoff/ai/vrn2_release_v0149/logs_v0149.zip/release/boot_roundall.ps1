$ErrorActionPreference = 'Continue'
$ProgressPreference = 'SilentlyContinue'   # Expand-Archive 的進度條在 PS 5.1 很慢 · 輸出導向時 pwsh 會印 CLIXML
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$R  = if ($env:VRN2_ROOT) { $env:VRN2_ROOT } else { 'C:\Users\tonyk\OneDrive\Documents\movies-dataset\VeritasIntelligenceAnalytics' }
$Br = 'claude/optimistic-goodall-yhalc5'
$P  = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0149'
$F  = 'VRN2_RoundAll_v0102.py'
$H  = 'd8848103bcb01e919623e9801e4a8158ac7a1234d3aae7e64b7ac6271bc943e3'
Write-Host ('[VRN-2] PowerShell ' + $PSVersionTable.PSVersion + ' · 從 GitHub 讀 VRN2_RoundAll_v0102.py(核對 SHA-256 後執行)') -ForegroundColor Yellow
$top = git -C $R rev-parse --show-toplevel 2>$null
if (-not $top) { Write-Host "[RED] $R 不是 git 倉或找不到 git(先設 `$env:VRN2_ROOT)" -ForegroundColor Red; exit 1 }
$top = "$top".Trim()
$t = Join-Path ([IO.Path]::GetTempPath()) ('vrn2_roundall_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Force -Path $t | Out-Null
$z = Join-Path $t 'roundall.zip'; $okz = $false
foreach ($b in $Br, 'main') {
  foreach ($w in 0, 2, 4, 8, 16) { if ($w) { Start-Sleep -Seconds $w }; git -C $top fetch -q origin $b 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { break } }
  git -C $top archive --format=zip -o $z ('origin/' + $b + ':' + $P) $F 2>&1 | Out-Null
  if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $z)) { $okz = $true; Write-Host ('[計] 來源 GitHub ' + $b) -ForegroundColor DarkGray; break }
}
if (-not $okz) { Write-Host "[RED] 讀不到 GitHub 分支 $Br 或 main 的 $F(網路 / git)" -ForegroundColor Red; exit 1 }
Expand-Archive -LiteralPath $z -DestinationPath $t -Force
$code = [IO.File]::ReadAllText((Join-Path $t $F), [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$bytes = (New-Object Text.UTF8Encoding($false)).GetBytes($code)
$sha = -join ([Security.Cryptography.SHA256]::Create().ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') })
if ($sha -ne $H) { Write-Host "[RED] $F SHA-256 不對($sha)· 不執行" -ForegroundColor Red; exit 1 }
$dst = Join-Path $env:USERPROFILE ('Downloads\' + $F)
[IO.File]::WriteAllBytes($dst, $bytes)
$exe = if ($env:VRN2_PY) { $env:VRN2_PY } else { (Get-Command python, py -ErrorAction SilentlyContinue | Where-Object { $_.Source -notmatch 'WindowsApps' } | Select-Object -First 1).Source }
if (-not $exe) { Write-Host '[RED] 找不到 python(不要用 WindowsApps 的假 python)' -ForegroundColor Red; exit 1 }
Write-Host ('[GREEN] ' + $F + ' SHA-256 ' + $H.Substring(0, 12) + ' 相符 → ' + $dst + ' · 用 ' + $exe + ' 執行') -ForegroundColor Green
$ra = @($dst, '--root', $R)
if ($env:VRN2_ROUNDALL_ARGS) { $ra += ($env:VRN2_ROUNDALL_ARGS -split '\s+' | Where-Object { $_ }) }
& $exe @ra
exit $LASTEXITCODE
