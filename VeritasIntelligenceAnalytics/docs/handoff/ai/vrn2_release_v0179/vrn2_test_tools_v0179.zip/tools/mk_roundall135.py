"""VRN2_RoundAll_v0135.py = v0134(倉裡 vrn2_release_v0178)+ 收尾頁三處:⑥e 提示只在 last_error.txt 真的在時才指它 · 人工核對的 --confirm 指令單獨一格(點一下整行選取 · 不夾提示字)·
--confirm 連提示字一起貼上時只記代碼、忽略其他字。套件 v0178 不動(啟動器 / runtime 一字不改)。"""
import re
from pathlib import Path

REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0178/VRN2_RoundAll_v0134.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0134')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0134 — ', '"""VRN2_RoundAll v0135 — ', 1)
at = doc.index("v0134(")
doc = doc[:at] + '''v0135(桌機 2026-11-04 01:53:套件 v0178 整輪 + repair 收尾 REVIEW(VRN-2 0 · 人工 1 · 資料源 3)· 操作員截圖:檔案總管跳「Windows 找不到
  …\\\\market\\\\vdf\\\\last_error.txt」;操作員從收尾頁複製 --confirm 那行時連後面的提示字一起貼進 PowerShell):
  · ⑥ 除錯:⑥e 那列的提示「網路 → 看 …\\\\last_error.txt」只在檔案真的在時才出現(附完整路徑);不在 → 寫「這輪沒有擷取錯誤檔(擷取沒失敗 · 不用開)」。
    上一輪的 last_error.txt 本來就會在 ④ / ⑤ 被移成 last_error.before_<時間>.txt(v0117)· 提示卻照舊指向它 → 照著開就跳「找不到」。
  · 收尾頁:人工核對項的 --confirm 指令另放一格(<code class="cmd"> · 點一下選取整行 · 只有指令本身);說明字留在原欄。
  · ⑥ 收尾 KPI(操作員 2026-11-04「結果驗證正確性及運作速度在 CPU/DRAM 架構下是否最快化為所有 VIA 系統收尾驗證 KPI」):兩列灰燈(只是指標 · 不改結案判定)——
    正確性 = 獨立驗證三類 + 四點原文核對的 對上 / 待人工 / 不符(不符 0 才寫「達標」);速度 = 收據耗時 · 管理器最慢階段占比 · 最慢步驟 ·
    ① CPU 核 / 執行緒上限 / 可用 RAM / 平行路數 · ④b 平行段倍數 · 沒計時的秒數照實列。只讀這輪已寫的檔 → 另存 VRN2_KPI_latest.json(進貼回包)。
  · --confirm:不是 H-xxxxxxxx 樣子的字(連提示文字一起貼上的「·」「FAIL」「=」…)→ 一行黃字說忽略了幾個 · 代碼照記;
    樣子對但不在清單的代碼照舊紅字不記。
  · 套件照用 v0178(啟動器 v0178 · runtime v0167)· 自測 111 項(v0134 的 107 項 + 108 · 108b · 108c · 108d)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0134.py", "用法:python VRN2_RoundAll_v0135.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0134"', 'VERSION = "v0135"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0134.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0134.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0135.py"', n_dl)
rep('"VRN2_RoundAll_v0134.py" in html_', '"VRN2_RoundAll_v0135.py" in html_')
rep("· v0133 起 105 項 · v0134 起 107 項。", "· v0133 起 105 項 · v0134 起 107 項 · v0135 起 111 項。")
# ── ⑥e 提示:last_error.txt 不在就不指它 ───────────────────────────────
rep('''def advice_for(step: str) -> str:
    for prefix, text in ADVICE:
        if str(step).startswith(prefix):
            return text
    return "看主控台該步那一行"''', '''def advice_for(step: str) -> str:
    for prefix, text in ADVICE:
        if str(step).startswith(prefix):
            return text
    return "看主控台該步那一行"


LAST_ERROR_HINT = "網路 → 看 VIA_Reports\\\\vrn2\\\\market\\\\vdf\\\\last_error.txt"


def advice_here(step: str, v2) -> str:
    """v0135 跟 advice_for 一樣 · 但 ⑥e 那句「看 last_error.txt」只在檔案真的在時才留(附完整路徑);不在 → 照實說這輪沒有(照著開會跳「找不到」)。"""
    text = advice_for(step)
    if LAST_ERROR_HINT in text:
        err = Path(v2) / "market" / "vdf" / "last_error.txt" if v2 else None
        if err is not None and err.is_file():
            text = text.replace(LAST_ERROR_HINT, "網路 → 看 %s" % err)
        else:
            text = text.replace(LAST_ERROR_HINT, "這輪沒有擷取錯誤檔 last_error.txt(擷取沒失敗 · 上一輪的已改名 last_error.before_<時間>.txt · 不用開)")
    return text''')
rep('''            f(s.get("lamp", "GRAY"), "步驟 " + str(s.get("step", ""))[:40], keep_facts(s.get("detail", "")), advice_for(s.get("step", "")))''',
    '''            f(s.get("lamp", "GRAY"), "步驟 " + str(s.get("step", ""))[:40], keep_facts(s.get("detail", "")), advice_here(s.get("step", ""), v2))''')
# ── ⑥ 收尾 KPI(正確性 + 速度 · CPU / DRAM)────────────────────────────
rep('''PASTE_FILES = ("VRN2_BookSource_latest.json", ''', '''PASTE_FILES = ("VRN2_KPI_latest.json", "VRN2_BookSource_latest.json", ''')
rep("""def advice_for(step: str) -> str:""", """KPI_JSON = "VRN2_KPI_latest.json"
KPI_GOOD = {"PASS", "ALIGNED", "TRANSALIGNED", "PRESENT", "SUBALIGNED"}            # 獨立驗證 v0114 / 四點原文核對:對上
KPI_REVIEW = {"OCR", "EST", "OCR_PENDING"}                                           # 影像頁等人看 · 推算已標示 → 待人工(不是錯 · 也不是對)
_KPI_DIGEST = re.compile(r"^(基本資料|一標題四重點|年度數據) (\\d+) (?:份|筆) (\\{.*\\})\\s*$")
_KPI_CPU = re.compile(r"CPU (\\d+) 核 · 執行緒上限 (\\d+) · 可用 RAM ([0-9.]+) GB(?: · CPU 使用 ([0-9.]+)%)?")
_KPI_PAR = re.compile(r"平行 (\\d+) 路")
_KPI_SEC = re.compile(r"耗時 ([0-9.]+) 秒")


def closeout_kpi(v2, receipt=None) -> dict:
    \"\"\"v0135 ⑥ 收尾 KPI:只讀這輪已寫的檔(獨立驗證摘要 · 四點原文核對 · 階段計時 · 啟動器收據 · 平行段)· 不重算 · 不連外。
    正確性 = 對上 / 待人工 / 不符(不符 0 才「達標」· 待人工照列 · REVIEW 不寫成成功);速度 = 實測秒數與 CPU / DRAM 用量(瓶頸照實點名)。\"\"\"
    import ast
    v2 = Path(v2)
    receipt = receipt if receipt is not None else (jread(receipt_path(v2), {}) or {})
    sec = {}
    digests = sorted((v2 / "verify_independent").glob("*.digest.txt"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    if digests:
        for line in digests[-1].read_text(encoding="utf-8", errors="replace").splitlines()[:6]:
            m = _KPI_DIGEST.match(line.strip())
            if m:
                try:
                    cnt = {str(k): int(v) for k, v in ast.literal_eval(m.group(3)).items()}
                except (ValueError, SyntaxError, TypeError, AttributeError):
                    continue
                sec[m.group(1)] = cnt
    vv = jread(v2 / "VRN2_VerbatimVerify_latest.json", {}) or {}
    if isinstance(vv.get("counts"), dict):
        sec["四點原文核對"] = {str(k): int(v or 0) for k, v in vv["counts"].items()}
    correct = {}
    for name, cnt in sec.items():
        ok = sum(v for k, v in cnt.items() if k in KPI_GOOD)
        review = sum(v for k, v in cnt.items() if k in KPI_REVIEW)
        bad = sum(v for k, v in cnt.items() if k not in KPI_GOOD and k not in KPI_REVIEW)
        correct[name] = {"ok": ok, "review": review, "bad": bad, "total": ok + review + bad, "counts": cnt}
    bad_n = sum(c["bad"] for c in correct.values())
    review_n = sum(c["review"] for c in correct.values())
    c_verdict = "沒有驗證資料" if not correct else ("達標(不符 0)" if bad_n == 0 else "未達標(不符 %d)" % bad_n)
    speed = {"elapsed_s": receipt.get("elapsed_s"), "passes": len(receipt.get("passes") or [])}
    steps = []
    for s in receipt.get("steps") or []:
        m = _KPI_SEC.search(str(s.get("detail") or ""))
        if m:
            steps.append((float(m.group(1)), str(s.get("step") or "")))
        if str(s.get("step") or "").startswith("① CPU"):
            mc, mp = _KPI_CPU.search(str(s.get("detail") or "")), _KPI_PAR.search(str(s.get("detail") or ""))
            if mc:
                speed.update(cores=int(mc.group(1)), threads=int(mc.group(2)), ram_free_gb=float(mc.group(3)), cpu_busy_pct=float(mc.group(4)) if mc.group(4) else None)
            if mp:
                speed["parallel"] = int(mp.group(1))
    steps.sort(reverse=True)
    speed["slowest_steps"] = [{"step": n, "s": t} for t, n in steps[:3]]
    speed["timed_steps_s"] = round(sum(t for t, _ in steps), 1)
    if isinstance(speed.get("elapsed_s"), (int, float)):
        speed["untimed_s"] = round(max(0.0, float(speed["elapsed_s"]) - speed["timed_steps_s"]), 1)   # ⑪ 在背景跑 · 步驟會重疊 → 只是下限
    pt = jread(v2 / "VRN2_Phase_Timing_latest.json", {}) or {}
    if pt.get("phases"):
        top = max(pt["phases"], key=lambda p: float(p.get("seconds") or 0))
        tot = float(pt.get("total_s") or 0) or sum(float(p.get("seconds") or 0) for p in pt["phases"])
        speed["manager"] = {"total_s": tot, "slowest": top.get("phase"), "slowest_s": float(top.get("seconds") or 0), "share": round(float(top.get("seconds") or 0) / tot, 3) if tot else None}
    act = jread(v2 / "VRN2_Activate_latest.json", {}) or {}
    if isinstance(act.get("par"), dict) and act.get("par_wall"):
        seq = round(sum(float(v or 0) for v in act["par"].values()), 1)
        speed["par_block"] = {"paths": len(act["par"]), "workers": act.get("par_workers"), "wall_s": float(act["par_wall"]), "sequential_s": seq, "x": round(seq / float(act["par_wall"]), 2) if float(act["par_wall"]) else None}
    uses_cpu = bool(speed.get("cores")) and int(speed.get("threads") or 0) >= int(speed["cores"]) - 1
    speed["verdict"] = ("執行緒上限已開到 核數 − 1(設定值 · 不是實測占用)" if uses_cpu else ("執行緒上限沒開滿(%s / %s 核)" % (speed.get("threads"), speed.get("cores")) if speed.get("cores") else "沒有 ① CPU / DRAM 那列"))
    doc = {"at": _dt.datetime.now().isoformat(timespec="seconds"), "tool": "%s %s" % (NAME, VERSION), "correct": correct, "correct_verdict": c_verdict, "bad": bad_n, "review": review_n, "speed": speed,
           "rule": "正確性不符 0 才達標 · 待人工照列(REVIEW 不是成功)· 速度只報實測(不推估)· 只讀這輪已寫的檔"}

    def frac(name, short):
        c = correct.get(name)
        if not c:
            return ""
        return "%s %d / %d%s%s" % (short, c["ok"], c["total"], (" · 待人工 %d" % c["review"]) if c["review"] else "", (" · 不符 %d" % c["bad"]) if c["bad"] else "")
    doc["correct_text"] = "%s:%s" % (c_verdict, " · ".join(x for x in (frac("基本資料", "基本資料"), frac("一標題四重點", "四點"), frac("年度數據", "年度數據"), frac("四點原文核對", "原文核對")) if x) or "—")
    mg, pb = speed.get("manager") or {}, speed.get("par_block") or {}
    doc["speed_text"] = " · ".join(x for x in (
        ("收據 %.0f 秒(%d 輪)" % (float(speed["elapsed_s"]), speed["passes"])) if isinstance(speed.get("elapsed_s"), (int, float)) else "",
        ("最慢步驟 " + " / ".join("%s %.0f" % (re.split(r"[((]", r["step"])[0].strip()[:14], r["s"]) for r in speed["slowest_steps"])) if speed["slowest_steps"] else "",
        ("沒計時 ≥ %.0f 秒" % speed["untimed_s"]) if speed.get("untimed_s") else "",
        ("管理器 %.1f 秒 · 最慢 %s %.0f 秒(%.0f%%)" % (mg["total_s"], mg["slowest"], mg["slowest_s"], 100 * (mg["share"] or 0))) if mg else "",
        ("CPU %s 核 · 執行緒上限 %s · 可用 RAM %s GB%s · 平行 %s 路" % (speed["cores"], speed["threads"], speed["ram_free_gb"], (" · 忙 %.0f%%" % speed["cpu_busy_pct"]) if speed.get("cpu_busy_pct") is not None else "", speed.get("parallel", "?"))) if speed.get("cores") else "",
        ("④b %d 段 %.0f 秒(依序 %.0f 秒 · %.1f 倍)" % (pb["paths"], pb["wall_s"], pb["sequential_s"], pb["x"] or 0)) if pb else "",
        speed["verdict"]) if x)
    try:
        v2.mkdir(parents=True, exist_ok=True)
        (v2 / KPI_JSON).write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError as error:
        doc["write_error"] = str(error)[:160]
    return doc


def advice_for(step: str) -> str:""")
rep("""        f("GRAY", "階段耗時", "總 %s 秒 · 最慢 %s" % (pt.get("total_s"), " · ".join("%s %.0f" % (p.get("phase"), float(p.get("seconds") or 0)) for p in top)))""",
    """        f("GRAY", "階段耗時", "總 %s 秒 · 最慢 %s" % (pt.get("total_s"), " · ".join("%s %.0f" % (p.get("phase"), float(p.get("seconds") or 0)) for p in top)))
    kpi = closeout_kpi(v2, receipt)                                           # v0135 收尾 KPI(灰燈 · 指標 · 不改結案判定)
    rep["kpi"] = {k: kpi.get(k) for k in ("correct_verdict", "bad", "review", "correct_text", "speed_text")}
    f("GRAY", "收尾 KPI · 正確性", kpi["correct_text"], "不符 > 0 → 看 ⑪ / 四點那幾列的證據;待人工 = 影像頁 OCR / 推算已標示 → 人工核對項")
    f("GRAY", "收尾 KPI · 速度(CPU / DRAM)", kpi["speed_text"] or "沒有計時資料", "最慢那一段就是下一輪要優化的地方;沒計時的秒數 = 等外部(擷取 / 共識)或沒印耗時的步驟")""")
rep("""    facts = [(r["step"], r["detail"]) for r in results if any(str(r.get("step", "")).startswith(s) for s in fact_steps)][:14]""",
    """    facts = [(r["step"], r["detail"]) for r in results if str(r.get("step", "")).startswith("⑥ 收尾 KPI")][:2]        # v0135 KPI 放最前面
    facts += [(r["step"], r["detail"]) for r in results if any(str(r.get("step", "")).startswith(s) for s in fact_steps)][:14]""")
# ── 收尾頁:--confirm 指令單獨一格 ─────────────────────────────────────
rep('''            it["why"] = (str(it.get("why") or "") + " · 你核對過原文 / 做了決定 → 複製這行記下(只有你打才算):" + confirm_cmd(script, code))[:700]''',
    '''            it["why"] = (str(it.get("why") or "") + " · 你核對過原文 / 做了決定 → 記下(只有你打才算 · 指令在下面那一格 · --confirm %s · 要寫結論就在後面加 --note \\"…\\")" % code)[:700]
            it["cmd"] = confirm_cmd(script, code)                              # v0135 指令單獨一格 · 只有指令本身''')
rep('''"items": [{k: i.get(k) for k in ("owner", "lamp", "step", "detail", "hint", "why", "also", "code")} for i in items]''',
    '''"items": [{k: i.get(k) for k in ("owner", "lamp", "step", "detail", "hint", "why", "also", "code", "cmd")} for i in items]''')
rep('''_h(i["detail"][:700]), _h(" · ".join(x for x in (i.get("why"), i.get("hint")) if x)[:500]))''',
    '''_h(i["detail"][:700]), _h(" · ".join(x for x in (i.get("why"), i.get("hint")) if x)[:500]) + ('<code class="cmd" title="點一下選取整行 · Ctrl+C 複製">%s</code>' % _h(i["cmd"]) if i.get("cmd") else ""))''')
rep('''td.lampcell{white-space:nowrap}''', '''td.next code.cmd{display:block;margin-top:6px;padding:6px 8px;border:1px solid var(--line);border-radius:6px;background:var(--panel-2,transparent);color:var(--ink);font:12px/1.4 Consolas,monospace;user-select:all;-webkit-user-select:all;overflow-wrap:anywhere;cursor:text}td.lampcell{white-space:nowrap}''')
# ── --confirm:提示字一起貼上 → 只記代碼 ─────────────────────────────────
rep('''    action = "revoke" if words[0] == "revoke" else "confirm"
    codes = words[1:] if action == "revoke" else words''', '''    action = "revoke" if words[0] == "revoke" else "confirm"
    codes = words[1:] if action == "revoke" else words
    junk = [w for w in codes if not re.fullmatch(r"H-[0-9a-f]{8}", w)]                # v0135 連提示文字一起貼上(「·」「FAIL」「=」…)
    codes = [w for w in codes if re.fullmatch(r"H-[0-9a-f]{8}", w)]
    if junk:
        print("[YELLOW] 忽略 %d 個不是代碼的字(%s%s)· 多半是連收尾頁的提示文字一起複製了 · 代碼照記" % (len(junk), " ".join(junk[:5])[:80], " …" if len(junk) > 5 else ""), flush=True)
    if not codes:
        print("[RED] 沒有 H-xxxxxxxx 樣子的代碼 · 沒記(先 --confirm list 看代碼)", flush=True)
        return 1''')
rep('''        with tempfile.TemporaryDirectory() as td101c:''', '''        with tempfile.TemporaryDirectory() as td108:
            v108 = Path(td108) / "vrn2"
            (v108 / "market" / "vdf").mkdir(parents=True)
            a108none = advice_here("⑥e 市場擷取(TWSE / TPEX / Yahoo", v108)
            (v108 / "market" / "vdf" / "last_error.txt").write_text("x", encoding="utf-8")
            a108has = advice_here("⑥e 市場擷取(TWSE / TPEX / Yahoo", v108)
        chk("108 v0135:⑥e 提示 —— last_error.txt 不在 → 不指它(寫「這輪沒有」)· 在 → 附完整路徑 · 其他步驟提示不變",
            "last_error.txt(擷取沒失敗" in a108none and "看 VIA_Reports" not in a108none and str(v108 / "market" / "vdf" / "last_error.txt") in a108has
            and advice_here("⑨ 上船", None) == advice_for("⑨ 上船"))
        with tempfile.TemporaryDirectory() as td108b:
            r108 = Path(td108b) / "VIA"
            v108b = r108 / "VIA_Reports" / "vrn2"
            v108b.mkdir(parents=True)
            (r108 / "functional modules").mkdir()
            (r108 / "supportive modules").mkdir()
            it108 = {"owner": "人工", "lamp": "YELLOW", "step": "⑥ 四點原文核對", "detail": "REVIEW_OCR · 4 點"}
            code108 = confirm_code(it108, {})[0]
            (v108b / CLOSEOUT_JSON).write_text(json.dumps({"items": [dict(it108, code=code108)]}), encoding="utf-8")
            import contextlib as _ctx108
            import io as _io108
            buf108 = _io108.StringIO()
            with _ctx108.redirect_stdout(buf108):
                rc108 = step_confirm(parse_args(["--root", str(r108), "--confirm", code108, "·", "FAIL", "=", "第二讀取器在原文找不到完整摘錄", "→", "貼回包"]), script="X.py")
                rc108j = step_confirm(parse_args(["--root", str(r108), "--confirm", "·", "FAIL"]), script="X.py")
            book108 = jread(v108b / CONFIRM_BOOK, {}) or {}
            out108 = buf108.getvalue()
        chk("108b v0135:--confirm 連提示字一起貼上 → 代碼照記(1 筆 · rc 0)· 其他字一行黃字忽略 · 只有提示字沒代碼 → 紅 · 不記",
            rc108 == 0 and [e["code"] for e in book108.get("entries", [])] == [code108] and "[YELLOW] 忽略 6 個不是代碼的字" in out108 and rc108j == 1 and "沒有 H-xxxxxxxx 樣子的代碼" in out108)
        items108 = [{"owner": "人工", "lamp": "YELLOW", "step": "⑥ 四點原文核對", "detail": "REVIEW_OCR · 4 點", "why": "x · --confirm H-0000abcd", "code": "H-0000abcd", "cmd": 'python "X.py" --confirm H-0000abcd'}]
        doc108 = {"state": "REVIEW", "state_label": "等人工核對", "state_text": "1 項", "counts": {"GREEN": 1, "YELLOW": 1, "RED": 0, "GRAY": 0}, "per_owner": {"人工": 1}, "items": items108,
                  "links": [], "steps": [], "facts": [], "next": [], "at": "2026-11-04T02:00:00", "tool": "t", "package": "p", "launcher": "l", "elapsed_s": 1, "rule": "r", "context": {}, "vrn2_closed": True}
        try:
            html108 = render_closeout(doc108)
        except Exception as error108:  # noqa: BLE001
            html108 = "ERR %s" % error108
        chk("108c v0135:收尾頁人工項 → 指令單獨一格 <code class=\\"cmd\\">(點一下選整行 · 只有指令)· 說明欄不再把指令接在提示字後面",
            '<code class="cmd" title="點一下選取整行 · Ctrl+C 複製">python &quot;X.py&quot; --confirm H-0000abcd</code>' in html108 and "user-select:all" in html108)
        with tempfile.TemporaryDirectory() as td108d:
            v108d = Path(td108d) / "vrn2"
            (v108d / "verify_independent").mkdir(parents=True)
            (v108d / "verify_independent" / "VRN2_IndependentVerify_x.json.digest.txt").write_text("[驗證摘要] VRN2_IndependentVerifier_v0114 · 平行 6 路\\n基本資料 52 份 {'PASS': 708, 'EST': 1, 'OCR': 2}\\n一標題四重點 52 份 {'PASS': 255, 'OCR': 5}\\n年度數據 11971 筆 {'ALIGNED': 10916, 'TRANSALIGNED': 230, 'PRESENT': 73, 'SUBALIGNED': 752}\\n", encoding="utf-8")
            (v108d / "VRN2_VerbatimVerify_latest.json").write_text(json.dumps({"verdict": "REVIEW_OCR", "counts": {"PASS": 204, "OCR_PENDING": 4}}), encoding="utf-8")
            (v108d / "VRN2_Phase_Timing_latest.json").write_text(json.dumps({"total_s": 326.5, "phases": [{"phase": "輸出冊", "seconds": 243.2}, {"phase": "冪等閘", "seconds": 35.8}]}), encoding="utf-8")
            (v108d / "VRN2_Activate_latest.json").write_text(json.dumps({"par": {"a": 12.5, "b": 17.5, "c": 23.7, "d": 0.6}, "par_workers": 6, "par_wall": 23.7}), encoding="utf-8")
            rc108d = {"elapsed_s": 2286.87, "passes": [{}, {}], "steps": [{"step": "① CPU / DRAM 優化", "detail": "CPU 8 核 · 執行緒上限 7 · 可用 RAM 6.8 GB · CPU 使用 22.2%(psutil)· 平行 3 路(擷取 / 驗收)· 耗時 2 秒"},
                                                                         {"step": "⑦ 啟動 VRN-2", "detail": "x · 耗時 344 秒"}, {"step": "⑪ 獨立驗證(背景 · 只讀)", "detail": "y · 耗時 289 秒"}]}
            k108 = closeout_kpi(v108d, rc108d)
            (v108d / "VRN2_VerbatimVerify_latest.json").write_text(json.dumps({"counts": {"PASS": 3, "FAIL": 1}}), encoding="utf-8")
            k108bad = closeout_kpi(v108d, rc108d)
            saved108 = jread(v108d / KPI_JSON, {}) or {}
        chk("108d v0135:⑥ 收尾 KPI —— 正確性 基本 708 / 711 · 四點 255 / 260 · 年度 11971 / 11971 · 原文核對 204 / 208 · 不符 0 → 達標(待人工 12 照列)· 有 FAIL → 未達標 · 速度 CPU 8 核 / 執行緒 7 / RAM 6.8 GB · 輸出冊 74% · ④b 2.3 倍 · 寫 KPI json",
            k108["bad"] == 0 and k108["review"] == 12 and k108["correct_verdict"] == "達標(不符 0)" and "基本資料 708 / 711 · 待人工 3" in k108["correct_text"] and "年度數據 11971 / 11971" in k108["correct_text"]
            and "原文核對 204 / 208 · 待人工 4" in k108["correct_text"] and k108["speed"]["cores"] == 8 and k108["speed"]["threads"] == 7 and k108["speed"]["ram_free_gb"] == 6.8 and k108["speed"]["parallel"] == 3
            and "輸出冊 243 秒(74%)" in k108["speed_text"] and "2.3 倍" in k108["speed_text"] and "執行緒上限已開到 核數 − 1" in k108["speed_text"] and "最慢步驟 ⑦ 啟動 VRN-2 344 / ⑪ 獨立驗證 289" in k108["speed_text"] and k108["speed"]["untimed_s"] == round(2286.87 - 635, 1)
            and "沒計時 ≥ 1652 秒" in k108["speed_text"] and closeout_kpi(v108d, {"elapsed_s": 100, "steps": [{"step": "⑦", "detail": "耗時 150 秒"}]})["speed"]["untimed_s"] == 0 and k108bad["correct_verdict"] == "未達標(不符 1)" and saved108.get("bad") == 1 and "VRN2_KPI_latest.json" in PASTE_FILES)
        with tempfile.TemporaryDirectory() as td101c:''')
Path("/home/user/vrn2_work/v179/new/VRN2_RoundAll_v0135.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0135", len(s.splitlines()), "lines")
