from pathlib import Path
p = Path("mk_roundall135.py")
g = p.read_text(encoding="utf-8")
def once(a, b):
    global g
    assert g.count(a) == 1, (g.count(a), a[:80])
    g = g.replace(a, b)
once("自測 110 項(v0134 的 107 項 + 108 · 108b · 108c)。", "自測 111 項(v0134 的 107 項 + 108 · 108b · 108c · 108d)。")
once("  · --confirm:不是 H-xxxxxxxx 樣子的字", "  · ⑥ 收尾 KPI(操作員 2026-11-04「結果驗證正確性及運作速度在 CPU/DRAM 架構下是否最快化為所有 VIA 系統收尾驗證 KPI」):兩列灰燈(只是指標 · 不改結案判定)——\n"
     "    正確性 = 獨立驗證三類 + 四點原文核對的 對上 / 待人工 / 不符(不符 0 才寫「達標」);速度 = 收據耗時 · 管理器最慢階段占比 · 最慢步驟 ·\n"
     "    ① CPU 核 / 執行緒上限 / 可用 RAM / 平行路數 · ④b 平行段倍數 · 沒計時的秒數照實列。只讀這輪已寫的檔 → 另存 VRN2_KPI_latest.json(進貼回包)。\n"
     "  · --confirm:不是 H-xxxxxxxx 樣子的字")
once('"· v0133 起 105 項 · v0134 起 107 項 · v0135 起 110 項。"', '"· v0133 起 105 項 · v0134 起 107 項 · v0135 起 111 項。"')
marker = "# ── 收尾頁:--confirm 指令單獨一格"
once(marker, Path("kpi_add.py.txt").read_text(encoding="utf-8") + marker)
end = "        with tempfile.TemporaryDirectory() as td101c:''')\nPath("
once(end, Path("kpi_test.py.txt").read_text(encoding="utf-8") + end)
p.write_text(g, encoding="utf-8")
print("ok")
