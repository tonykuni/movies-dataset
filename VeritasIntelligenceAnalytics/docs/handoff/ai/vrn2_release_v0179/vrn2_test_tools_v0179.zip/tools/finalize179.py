"""v0179 收尾:四系統 KPI 報告 · 驗證紀錄 v0179 · 交接 v0180(從 v0179 抄 · 只增)· 收尾規格 §16 · 詳細交接 §9 · 放進倉 vrn2_release_v0179 · logs / 工具 zip。
桌機 / 上傳資料不進倉(只寫結論與筆數)。KPI 數字全部從 kpi/*.json 與這輪的日誌讀(不手抄)。"""
import json, re, shutil, zipfile
from pathlib import Path

W = Path("/home/user/vrn2_work/v179"); rel = W / "release179"; K = W / "kpi"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"
R = json.loads((rel / "VRN2_Release_v0179.json").read_text(encoding="utf-8"))
H = R["handleall"]


def kp(name):
    return json.loads((K / name).read_text(encoding="utf-8"))


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def last(p, pat):
    hits = [l.strip() for l in lines(p) if re.search(pat, l)]
    return hits[-1] if hits else "—"


ra, vdf, vcgc, aos, v261 = (kp(n) for n in ("vrn2_roundall_selftest.json", "vdf_selftest2.json", "vcgc_test_quick.json", "agentos_selftest.json", "vrn_manager_v0261_selftest.json"))
for k in (ra, vdf, vcgc, aos, v261):
    assert k["rc"] in (0, 2), k
desk = json.loads(Path(SCR0, "pbkpi", "VRN2_KPI_latest.json").read_text(encoding="utf-8"))
ra_line = last(W / "rall135_kpi.log", r"VRN2_RoundAll v0135 --selftest")
vcgc_line = last(K / "vcgc_test_quick.json.log", r"\[VCGC 全功能串測\]")
aos_j = json.loads((K / "agentos_selftest.json.log").read_text(encoding="utf-8")[(K / "agentos_selftest.json.log").read_text(encoding="utf-8").index("{"):])
aos_line = "tests_run %s · failures %s · errors %s" % (aos_j.get("tests_run"), aos_j.get("failures"), aos_j.get("errors"))
v261_line = last(K / "vrn_manager_v0261_selftest.json.log", r"\[計\] VRN-2 SystemManager v0261")
vdf_line = last(Path(SCR0) / "vdf_selftest2.log", r"PASS|FAIL|rc")
ssot_before = last(Path(SCR0) / "ssot_before179.log", r"\[SSOT 全景\]")
ssot_after = last(Path(SCR0) / "ssot_after179.log", r"\[SSOT 全景\]")
reg_line = last(Path(SCR0) / "regsync179.log", r"\[VCGC 元件自動編號冊\]")
num_line = last(Path(SCR0) / "num_audit179.log", r"\[編號只增稽核\]")
hand_line = last(Path(SCR0) / "handoff179.log", r"\[交接防遺漏\]")
hand_tally = {}
for l in lines(Path(SCR0) / "handoff179.log"):
    m = re.match(r"^\[(RED|YELLOW)\] ([A-Z_]+)", l)
    if m:
        hand_tally[m.group(2)] = hand_tally.get(m.group(2), 0) + 1
e2e = {"rc": lines(W / "tiny179.rc"), "cmd_cells": (W / "closeout_repair1.html").read_text(encoding="utf-8").count('<code class="cmd"'),
       "kpi_first": [f[0] for f in json.loads((W / "closeout_repair1.json").read_text(encoding="utf-8"))["facts"][:2]],
       "junk_ignored": sum(1 for l in lines(W / "confirm_junk.log") if "[YELLOW] 忽略" in l), "tamper": lines(W / "tiny_tamper.log")[:1]}
ps = json.loads((W / "pscheck179.log").read_text(encoding="utf-8"))
ps_ok = all(x["e"] == 0 for x in ps) and ps[0]["h"] == ps[1]["h"] and ps[2]["h"] == ps[3]["h"]
cov = json.loads((W / "coverage_audit.json").read_text(encoding="utf-8")) if (W / "coverage_audit.json").is_file() else {}


def krow(name, k, what):
    return "| %s | %s | %.1f | %.1f | %.2f / %d | %.0f |" % (name, what, k["wall_s"], k["cpu_s"], k["cores_used_avg"], k["cores_available"], k["peak_rss_mb"])


ds = desk["speed"]
dc = desk["correct"]
kpi_md = f"""# VIA 四系統收尾 KPI · v0179(2026-11-04)

操作員令:「結果驗證正確性及運作速度在 CPU/DRAM 架構下是否最快化為所有 VIA 系統收尾驗證 KPI」。
四系統對等獨立(VRN-1 · VRN-2 · VDF · VCGC;VRN-1 是另一團隊的倉,不在本倉、只讀 —— 本表不列它的數)。
**規則**:正確性「不符 0」才算達標;待人工照列(REVIEW 不是成功);速度只報實測(不推估);灰燈 = 指標,不改任何系統的結案判定。

## 1. VRN-2 · 桌機實跑(2026-11-04 01:53 · 套件 v0178 整輪 + repair · 8 核桌機)

正確性(只讀這輪已寫的驗證檔 · RoundAll v0135 ⑥ 收尾 KPI 同一支函式重算 = 貼回包內容):

| 項目 | 對上 / 全部 | 待人工 | 不符 |
|---|---|---|---|
| 獨立驗證 · 基本資料 | {dc['基本資料']['ok']} / {dc['基本資料']['total']} | {dc['基本資料']['review']}(OCR 影像頁 2 · 推算已標示 1)| {dc['基本資料']['bad']} |
| 獨立驗證 · 一標題四重點 | {dc['一標題四重點']['ok']} / {dc['一標題四重點']['total']} | {dc['一標題四重點']['review']}(MQ-1560 影像頁)| {dc['一標題四重點']['bad']} |
| 獨立驗證 · 年度數據 | {dc['年度數據']['ok']} / {dc['年度數據']['total']} | {dc['年度數據']['review']} | {dc['年度數據']['bad']} |
| 四點原文核對(第二讀取器) | {dc['四點原文核對']['ok']} / {dc['四點原文核對']['total']} | {dc['四點原文核對']['review']}(MQ-1560 OCR_PENDING)| {dc['四點原文核對']['bad']} |
| **判定** | **{desk['correct_verdict']}** | 待人工 {desk['review']}(全在 MQ-1560 影像頁 + 1 個已標示推算)| — |

速度(CPU / DRAM):

| 指標 | 實測 |
|---|---|
| 收據耗時 | {ds['elapsed_s']} 秒({ds['passes']} 輪)|
| 最慢步驟 | {' · '.join('%s %.0f 秒' % (s['step'], s['s']) for s in ds['slowest_steps'])} |
| 有計時步驟合計 / 沒計時 | {ds['timed_steps_s']} 秒 / ≥ {ds['untimed_s']} 秒(⑥e / ⑥f 擷取與共識 · 第 1 輪 · 這幾步沒印耗時)|
| 管理器(VRN-2 SystemManager v0259)| {ds['manager']['total_s']} 秒 · 最慢「{ds['manager']['slowest']}」{ds['manager']['slowest_s']} 秒(占 {100 * ds['manager']['share']:.0f}%)|
| CPU / DRAM(① 步實測)| {ds['cores']} 核 · 執行緒上限 {ds['threads']} · 可用 RAM {ds['ram_free_gb']} GB · 啟動時 CPU 忙 {ds['cpu_busy_pct']}% · 平行 {ds['parallel']} 路 |
| ④b 平行段 | {ds['par_block']['paths']} 段 {ds['par_block']['wall_s']} 秒(依序要 {ds['par_block']['sequential_s']} 秒 · {ds['par_block']['x']} 倍)|
| 加速器 / 網路工具 | ①b VeritasCeleritas_v1141(= 鎖冊 accelerator)· 網路 VeritasAegisNexus_v1652(= 鎖冊 network)· 都是最新 |

**是不是 CPU / DRAM 下最快?照實說:還不是。** 已做到:執行緒上限開到 核數 − 1、④b 平行 2.3 倍、加速器與網路工具是鎖冊最新版。
還沒做到:①「輸出冊」一個階段占管理器 {100 * ds['manager']['share']:.0f}%(單一階段 · 下一輪優化目標)· ② 這輪跑了 {ds['passes']} 輪(第 2 輪是 RoundAll 補修後重跑)·
③ ≥ {ds['untimed_s']:.0f} 秒沒有逐步計時(⑥e / ⑥f 主要是等外部網站)→ 先補計時才能判斷是 CPU 還是網路。

## 2. 各系統自己的檢查 · 本容器同一把尺(4 核 · 依序一支一支跑 · 不互相干擾)

| 系統 | 跑什麼 | 牆鐘秒 | CPU 秒 | 平均用核 / 可用 | 峰值 RSS MB |
|---|---|---|---|---|---|
{krow('VRN-2', ra, 'RoundAll v0135 --selftest(111 項 · 多半在等逾時 / 心跳測試)')}
{krow('VRN-2 底座', v261, 'VRN_SystemManager v0261 --selftest(6 項 · 含 v0256 6 項)')}
{krow('VDF', vdf, '經 VCGC run VDF_SystemManager --selftest')}
{krow('VCGC', vcgc, 'test --quick(10 站 · 沒變的 9 站沿用 · 平行 4)')}
{krow('VIA Agent OS', aos, 'VIA_AgentOS_v0100 selftest(15 項)')}

結果:VRN-2 `{ra_line[:110]}` · 底座 `{v261_line[:110]}` · VDF rc {vdf['rc']} · VCGC `{vcgc_line[:150]}` · Agent OS `{aos_line}`。
**瓶頸照實列**:VDF 自測平均只用 {vdf['cores_used_avg']:.2f} 核(依序執行 · 4 核只用 1 核)· Agent OS bootstrap 乾跑 1500 模組單執行緒 64 秒(v0178 量)· VRN-2 RoundAll 自測單執行緒。
這三處是「可平行但還沒平行」—— 屬各自系統的下一輪,不在本輪範圍內硬改(範圍不擴張)。

## 3. 四系統燈(各自自報 · 互相只讀)

| 系統 | 燈 | 說明 |
|---|---|---|
| VRN-2 | **REVIEW**(VRN-2 側結案)| 桌機收尾 VRN-2 0 · 人工 1(MQ-1560 影像頁 · 操作員 `--confirm`)· 資料源 3(外部來源本來沒有)|
| VDF | 自測 **綠**(rc 0)· 收尾收據 **灰**(沒有自報收據)| SUP_MDL753 v0113 修好 DuckDB 2.x;VDF 自己的收尾收據要桌機 ActivateVDF 真跑才有 |
| VCGC | 串測 **黃**(9 綠 1 黃 0 紅)· SSOT 全景 **黃**(前一刻紅)· 交接閘 **紅** | 交接閘紅 = 結構性(見 §4)· 不是這輪改壞 |
| VIA Agent OS | 自測 15 / 15 · Skill 23 / 23 | v0100 · 只讀 AST · `.via\\ssot.json` 不進倉 |

## 4. 照實列的缺口(不寫成成功)

- VCGC 交接閘:{json.dumps(hand_tally, ensure_ascii=False)}。204 支「改了沒有宣告測試」是舊檔(VRN 101 · VDF 82 · VCGC 19 · 規則 2),要 VCGC 線替它們宣告測試案或豁免;
  93 個證據案要重跑(多數是 VDF 桌機 / 資料庫實跑);`manager` 案的標記只在 VRN_SystemManager v0110 印過 → v0231 起的 VRN-2 鏈一直對不上(2026-10-08 的證據就已經是「沒看到標記」)。checkpoint 沒打(閘紅不假裝成功)。
- 加速器覆蓋(AST 靜態):VRN-2 runtime 17 / 18(VerbatimVerifier v0105 · 桌機 ④ 自動注入 v0106)· VRN 共用 94 / 95(VRN_ENG112_FinancialRead_v0100)· VDF / VCGC / Agent OS 100%。已出貨的檔不改位元組 → 以新版號補(下一輪)。
- 網路:各橋都解到鎖冊最新(NetUnified v0119 → Aegis v1652);VDF MDL008 擷取系統在載入時 AST 改道到網路工具。**真缺口**:VRN-2 ⑥e 借用的 VDF AllInOne_v039(子行程 · yfinance / urllib)不經網路工具 —— 是 VDF 的引擎(VRN-2 只讀不改),記給 VDF 線。
- VDF MDL008 FetchSystem v0103 自測缺測資 `tw_fullmarket_snapshot.parquet`(環境資料 · 不是程式錯)。
"""
(rel / "VIA_FourSystem_KPI_v0179.md").write_text(kpi_md, encoding="utf-8", newline="\n")

ver_md = f"""# VRN-2 v0179 驗證紀錄(2026-11-04)

套件 **v0178 不動**(啟動器 v0178 · runtime v0167 · SHA-256 `{R['roundall']['pinned_package_sha256'][:12]}`)· **RoundAll v0135**(`{R['roundall']['sha256'][:12]}`)· **Handle-All v0127**(一行 `{H['line_sha256'][:12]}` · 開機行 `{H['boot_line_sha256'][:12]}`)。

| 檢查 | 結果 |
|---|---|
| RoundAll v0135 自測 | {ra_line[:120]} |
| 新增 108 · 108b · 108c · 108d | ⑥e 提示只在 last_error.txt 在時指它 · `--confirm` 連提示字貼上只記代碼 · 指令單獨一格 · ⑥ 收尾 KPI(正確性 + 速度)|
| PowerShell 7 解析(6 支一行 / 原始檔)| {'0 錯 · 一行 = 原始檔雜湊相同' if ps_ok else 'FAIL'} |
| 沙盒端到端(沿用 v0178 沙盒 · 收據 v0178)| {' · '.join(e2e['rc'])} · 指令格 {e2e['cmd_cells']} · 收尾頁「這輪的數據」最前兩列 = {' / '.join(e2e['kpi_first'])} · 提示字貼上 → 黃字忽略 {e2e['junk_ignored']} 行、代碼照記 · 竄改開機檔 → `{e2e['tamper'][0] if e2e['tamper'] else '—'}` |
| 桌機貼回包重算 KPI | {desk['correct_text']} |
| 桌機速度 KPI | {desk['speed_text']} |
| VRN_SystemManager v0261(VRN-2 底座 · 補 VCGC 對接口)| {v261_line[:140]} · ChainShip check MISSING 0(黃 = 桌機才有的冊 · 同前)|
| SUP_MDL753 v0113(DuckDB 2.x)| 自測 PASS(v0112 44 項經包裝 + 2.x 3 項)· VDF_SystemManager 自測經 VCGC rc {vdf['rc']} |
| VCGC registry-sync --apply | {reg_line[:160]} |
| VCGC 編號稽核 | {num_line[:160]} |
| VCGC SSOT 全景 | 前 `{ssot_before[:80]}` → 後 `{ssot_after[:80]}` |
| VCGC 交接閘 | `{hand_line[:120]}`(結構性 · 見 VIA_FourSystem_KPI_v0179.md §4)|

沒做 / 做不到(照實):MQ-1560 四點要操作員看原圖後親手 `--confirm`;VCGC 交接閘的舊檔測試宣告是 VCGC 線的事;VDF 自報收尾收據要桌機 ActivateVDF;華南投顧報告(背景花)WORD / TXT / IMAGE 讀取要原 PDF 上傳後才能測。
"""
(rel / "VRN2_Verification_v0179.md").write_text(ver_md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0179.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


Ls = src.split("\n")
assert Ls[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0178 + VRN2_RoundAll_v0134 + VRN2_HandleAll_v0126 · 2026-11-04(")
Ls[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0178 + VRN2_RoundAll_v0135 + VRN2_HandleAll_v0127 · 2026-11-04(收尾頁三處小修 · ⑥ 收尾 KPI · VRN 底座 v0261 對接口 · 四系統 KPI)"
src = "\n".join(Ls)
once("> **本輪(v0178)**",
     "> **本輪(v0179)**:桌機 v0178 整輪 + repair = **REVIEW**(VRN-2 0 · 人工 1 · 資料源 3)→ VRN-2 側結案。這輪只修收尾頁(套件 v0178 不動):"
     "**RoundAll v0135** ⑥e 提示不再指不存在的 last_error.txt(檔案總管「找不到」)· `--confirm` 指令單獨一格、連提示字貼上也只記代碼 · **⑥ 收尾 KPI**(正確性 + CPU / DRAM 速度 · 灰燈)· "
     "**Handle-All v0127**。另:**VRN_SystemManager v0261**(VRN-2 底座 · 補回 VCGC 子系統對接口 collect() → VCGC SSOT 全景 RED 轉黃)· SUP_MDL753 v0113(DuckDB 2.x · VDF 自測轉綠)· "
     "四系統 KPI 見 `vrn2_release_v0179/VIA_FourSystem_KPI_v0179.md`。\n"
     "> **本輪(v0178)**")
rows = ("| **VRN2_HandleAll_v0127.md**(發行夾 · 開閘一行 + 最短一行 + cmd 一行 + 開機行 · 不是 .ps1)| **v0127** | `vrn2_release_v0179` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0135)|\n"
        "| **VRN2_RoundAll_v0135.py**(發行夾 · 一支入口)| **v0135** | `vrn2_release_v0179` | `%s` | **新**(套件 v0178 不動 · ⑥e 提示 · 指令格 · ⑥ 收尾 KPI · 自測 111)|\n"
        "| VRN_SystemManager_v0261.py(倉 functional modules\\VRN · v0256 薄尾)| **v0261** | 倉 | 見倉 | **新**(collect() / read() 交 v0109 對接口 · main 照 v0256)|\n") % (
    H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12])
once("| **VRN2_HandleAll_v0126.md**(發行夾", rows + "| **VRN2_HandleAll_v0126.md**(發行夾")
once("| 0 | **(v0178)**", "| 0 | **(v0179)** 貼 `vrn2_release_v0179/VRN2_HandleAll_v0127.md` 的開閘一行 → 收尾頁「這輪的數據」最前兩列是 KPI · MQ-1560 看過原圖後打 `--confirm H-fd2ea35f`(只貼指令格那一行 · 操作員)| 貼回 / 人工 |\n| 0 | **(v0178)**")
once("**v0178(2026-11-04)**:", "**v0179(2026-11-04)**:RoundAll v0135(⑥e 提示 · 指令格 · --confirm 只記代碼 · ⑥ 收尾 KPI)· Handle-All v0127 · VRN_SystemManager v0261(VCGC 對接口)· SUP_MDL753 v0113 · VCGC registry-sync / 編號 +28。\n\n**v0178(2026-11-04)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0179)** **functional modules\\VRN 的管理器尾版要回 VCGC 的 collect()**:VCGC SSOT 全景(managers 探針)與主控台 vrn_system 段都呼叫它;v0231 起的 VRN-2 鏈沒有 → v0261 交給 v0109 對接口。再出新尾版要保留 collect() / read()。\n"
     "- **(v0179)** **管理器號**:v0255、v0257–v0260 是 VRN-2 私有 runtime 線 · v0261 是倉 functional modules\\VRN → **VRN-2 runtime 下一個管理器號 v0262 起**。\n"
     "- **(v0179)** **KPI 只報實測**:收尾頁 ⑥ 收尾 KPI 是灰燈指標(不改結案判定)· 不符 0 才寫達標 · 沒計時的秒數照列(⑥e / ⑥f 先補計時才能判斷 CPU 還是網路)。\n"
     "- **(v0179)** **版號**:本線下一版 RoundAll v0136+ · Handle-All v0128+ · Workbench v0112+ · runtime v0168+ · 啟動器 / 套件 / 收據 v0179+ · VerbatimVerifier v0107+ · 管理器 v0262+。\n\n")
(REPO / "VRN2_Handover_v0180.md").write_text(src, encoding="utf-8", newline="\n")

spec = (REPO / "VIA_Closeout_Spec_20261103.md").read_text(encoding="utf-8")
if "## 16. v0179 輪更新" not in spec:
    spec = spec.rstrip("\n") + "\n\n" + f"""## 16. v0179 輪更新(2026-11-04 · 四系統收尾 · KPI)

| 項目 | 現況 |
|---|---|
| VRN-2 | 桌機 v0178 = REVIEW(VRN-2 0 · 人工 1 · 資料源 3)· RoundAll v0135 / Handle-All v0127(套件 v0178 不動)· 正確性 KPI {desk['correct_verdict']} |
| 速度 KPI | 收據 {ds['elapsed_s']} 秒 · 管理器最慢「{ds['manager']['slowest']}」占 {100 * ds['manager']['share']:.0f}% · {ds['cores']} 核 / 執行緒 {ds['threads']} / RAM {ds['ram_free_gb']} GB · ④b {ds['par_block']['x']} 倍 · 還不是最快(見 KPI §1)|
| VDF | 自測經 VCGC rc {vdf['rc']}(SUP_MDL753 v0113 · DuckDB 2.x)· 自報收尾收據仍灰(要桌機 ActivateVDF)|
| VCGC | 串測 9 綠 1 黃 0 紅 · SSOT 全景 紅 → 黃(VRN_SystemManager v0261 對接口)· registry-sync / 編號 +28(遺失 0 · 改身分 0 · 重號 0)· 交接閘 紅(結構性)|
| VIA Agent OS | v0100 · 自測 15 / 15 · Skill 23 / 23 |
| 加速器 / 網路工具 | 都解到鎖冊最新(Celeritas v1141 · Aegis v1652);缺口照列(VRN-2 runtime VerbatimVerifier v0105 · VRN_ENG112 · ⑥e AllInOne_v039 不經網路工具)|
| 桌機要做 | 開閘一行(vrn2_release_v0179/VRN2_HandleAll_v0127.md)· MQ-1560 `--confirm H-fd2ea35f`(操作員)· VDF 桌機 ActivateVDF(VDF 線)|
"""
    (REPO / "VIA_Closeout_Spec_20261103.md").write_text(spec, encoding="utf-8", newline="\n")
dh = (REPO / "VRN2_DetailedHandover_20261104.md").read_text(encoding="utf-8")
if "## 9. v0179 補充" not in dh:
    dh = dh.rstrip("\n") + "\n\n" + f"""## 9. v0179 補充(2026-11-04 · 桌機 v0178 REVIEW 之後 · 四系統收尾)

- **桌機 v0178 結果**:收據 rc 2 · {ds['elapsed_s']} 秒 · {ds['passes']} 輪 · 收尾 REVIEW(VRN-2 0 · 人工 1 · 資料源 3)· VRN-2 側結案。
- **檔案總管「Windows 找不到 …\\last_error.txt」**:⑥e 那列的提示寫死指向 last_error.txt,但上一輪的檔在 ④ / ⑤ 會被改名成 last_error.before_<時間>.txt → RoundAll v0135 只在檔案真的在時才指它(附完整路徑)。
- **`--confirm` 連提示字一起貼上**:v0135 只記 H-xxxxxxxx 代碼、其他字一行黃字忽略;收尾頁把指令單獨放一格(點一下選整行)。
- **⑥ 收尾 KPI**(灰燈 · 不改結案判定):正確性 {desk['correct_text']};速度 {desk['speed_text']}。
- **VRN 底座 v0261**:VCGC 的 SSOT 全景 managers 探針 / 主控台 vrn_system 段呼叫尾版 collect();v0231 起的鏈沒有 → AttributeError → 全景 RED。v0261 交給 v0109 對接口(只讀 · 七處 7 / 7)。
- **SUP_MDL753 v0113**:DuckDB 2.0 `fetchone()` 留下未讀完結果 → 下一個操作 ResourceInUse;包一層連線 → VDF 自測轉綠。
- **下一步**:開閘一行 → 收尾頁看 KPI 兩列;MQ-1560 看原圖後打 `--confirm H-fd2ea35f`;華南投顧報告(背景花)要原 PDF 上傳才能測 WORD / TXT / IMAGE 讀取。
"""
    (REPO / "VRN2_DetailedHandover_20261104.md").write_text(dh, encoding="utf-8", newline="\n")

D = REPO / "vrn2_release_v0179"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0135.py", "VRN2_RoundAll_v0135.md", "VRN2_HandleAll_v0127.md", "VRN2_HandleAll_v0127_boot.txt", "VRN2_Release_v0179.json", "VRN2_Verification_v0179.md", "VIA_FourSystem_KPI_v0179.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 4, 12, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(Path("<sbx>")), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")) + (((str(W.parent), "<work>"),) if not name.startswith("tools/") else ()):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    if not name.startswith("tools/"):
        data = re.sub(rb"/home/user/[^\s'\"]*", b"<work>", data)
    z.writestr(zi, data)


logs = [W / n for n in ("rall135_kpi.log", "pscheck179.log", "tiny179.rc", "confirm_junk.log", "e2e179.out", "coverage_audit.json")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")) + sorted(K.glob("*.json")) + \
       [Path(SCR0) / n for n in ("vcgc_testq179.log", "ssot_before179.log", "ssot_after179.log", "regsync179.log", "num_apply179.log", "num_audit179.log", "handoff179.log", "kpi_v261.log", "kpi_aos.log", "vdf_selftest2.log")]
with zipfile.ZipFile(D / "logs_v0179.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in logs:
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0179.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall135.py", "kpi_add.py.txt", "kpi_test.py.txt", "splice_kpi.py", "build179.py", "finalize179.py", "e2e179.sh", "selcheck.js", "coverage_audit.py")] + \
             [Path(SCR0) / "kpirun.py", Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "tiny_gates_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        if p.is_file():
            put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0180", src.count("\n"))
