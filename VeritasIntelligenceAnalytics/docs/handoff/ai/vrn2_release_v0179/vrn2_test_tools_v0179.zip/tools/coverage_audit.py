"""只讀稽核:每個系統的尾版(同家族最高版號)· 加速器橋(ACCEL-BRIDGE 標記 / 匯入 VeritasCeleritas)· 直接連網匯入(requests / urllib.request / http.client / socket / yfinance / aiohttp / httpx)vs 經 VIA 網路工具
(VeritasAegisNexus / NetUnified)。.py 用 ast · .ps1 用文字。不改任何檔。"""
import ast, io, json, re, sys, zipfile
from collections import defaultdict
from pathlib import Path
VIA = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics")
NET_DIRECT = {"requests", "urllib.request", "http.client", "socket", "yfinance", "aiohttp", "httpx", "urllib3", "selenium", "playwright"}
NET_TOOL = re.compile(r"VeritasAegisNexus|NetUnified|SUP_MDL740")
ACC = re.compile(r"\[VIA:ACCEL-BRIDGE|VeritasCeleritas|VIA_SuperAccel|Invoke-VIAPython|VIA_PS_Accel")
VER = re.compile(r"^(.*)_v(\d{3,4})\.(py|ps1)$")


def tails(paths):
    fam = defaultdict(list)
    for name, getb in paths:
        m = VER.match(Path(name).name)
        if m:
            fam[(m.group(1), m.group(3))].append((int(m.group(2)), name, getb))
    return [sorted(v)[-1] for v in fam.values()]


def audit(label, paths):
    rows = []
    for _v, name, getb in tails(paths):
        b = getb()
        s = b.decode("utf-8", "replace")
        acc = bool(ACC.search(s))
        direct = set()
        if name.endswith(".py"):
            try:
                t = ast.parse(s)
                for n in ast.walk(t):
                    if isinstance(n, ast.Import):
                        direct |= {a.name for a in n.names if a.name in NET_DIRECT or a.name.split(".")[0] in {"requests", "yfinance", "aiohttp", "httpx", "socket", "selenium"}}
                    elif isinstance(n, ast.ImportFrom) and n.module:
                        if n.module in NET_DIRECT or n.module.split(".")[0] in {"requests", "yfinance", "aiohttp", "httpx", "selenium"} or n.module == "urllib.request":
                            direct.add(n.module)
            except SyntaxError:
                direct.add("SYNTAX?")
        else:
            if re.search(r"Invoke-WebRequest|Invoke-RestMethod|Net\.WebClient|HttpClient", s):
                direct.add("PS-web")
        rows.append({"file": Path(name).name, "accelerator": acc, "direct_net": sorted(direct), "via_net_tool": bool(NET_TOOL.search(s))})
    n = len(rows)
    acc_n = sum(r["accelerator"] for r in rows)
    net_direct = [r for r in rows if r["direct_net"] and not r["via_net_tool"]]
    return {"system": label, "tails": n, "accelerator": acc_n, "accelerator_pct": round(100.0 * acc_n / n, 1) if n else None,
            "no_accelerator": sorted(r["file"] for r in rows if not r["accelerator"])[:40], "no_accelerator_n": n - acc_n,
            "direct_net_without_tool_n": len(net_direct), "direct_net_without_tool": sorted("%s(%s)" % (r["file"], ",".join(r["direct_net"])) for r in net_direct)[:40],
            "via_net_tool_n": sum(r["via_net_tool"] for r in rows)}


def disk(folder):
    base = VIA / folder
    return [(str(p), (lambda p=p: p.read_bytes())) for p in base.rglob("*") if p.suffix in (".py", ".ps1") and p.is_file()
            and not re.search(r"(references|intake|quarantine|VIA_RetiredEngines|backup|archive)", str(p.relative_to(base)), re.I)]


z = zipfile.ZipFile("/home/user/vrn2_work/v178/pkg178/VRN2_Runtime_v0167.zip")
rt = [(n, (lambda n=n: z.read(n))) for n in z.namelist() if n.endswith((".py", ".ps1"))]
out = [audit("VRN-2(runtime v0167 · 桌機 ④ 會再補注入)", rt), audit("VRN 共用夾(functional modules/VRN)", disk("functional modules/VRN")),
       audit("VDF(functional modules/VDF)", disk("functional modules/VDF")), audit("VCGC(supportive modules/registry)", disk("supportive modules/registry")),
       audit("VIA Agent OS(supportive modules/agent_os)", disk("supportive modules/agent_os"))]
json.dump(out, open("/home/user/vrn2_work/v179/coverage_audit.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for r in out:
    print("%-44s 尾版 %4d · 加速器 %4d(%s%%)· 缺 %d · 直接連網(沒經網路工具)%d · 經網路工具 %d" % (r["system"], r["tails"], r["accelerator"], r["accelerator_pct"], r["no_accelerator_n"], r["direct_net_without_tool_n"], r["via_net_tool_n"]))
    if r["direct_net_without_tool"]:
        print("    直接連網:", "; ".join(r["direct_net_without_tool"][:8]))
