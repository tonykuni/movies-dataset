#!/bin/bash
# v0179 e2e(RoundAll v0135 · Handle-All v0127 · 套件 v0178 不動):接著 v0178 沙盒(收據 v0178)→ repair1(auto → repair)→ --confirm 連提示字一起貼上 → 竄改不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v179; T=<sbx>; P=$S2/venv_vrn2/bin/python
B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0179; mkdir -p $D
cp $W/release179/VRN2_RoundAll_v0135.py $W/release179/VRN2_RoundAll_v0135.md $W/release179/VRN2_HandleAll_v0127.md $W/release179/VRN2_HandleAll_v0127_boot.txt $W/release179/VRN2_Release_v0179.json $D/
(cd $B && git add -A && git -c user.email=t@t -c user.name=t commit -qm v179 && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release179/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
ls $V2/market/vdf/last_error.txt 2>/dev/null && echo "last_error present" || echo "no last_error.txt"
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2)
rm -f $W/tiny179.rc
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 6000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny179.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; cp $V2/VRN2_CloseoutUI_latest.html $W/closeout_$N.html 2>/dev/null; }
run repair1
RA=$T/home/Downloads/VRN2_RoundAll_v0135.py
CODE=$(python3 -c "import json,sys;j=json.load(open(sys.argv[1],encoding='utf-8'));print(next(i['code'] for i in j['items'] if i.get('owner')=='人工' and i.get('code')))" $W/closeout_repair1.json)
echo "code $CODE"
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm $CODE · FAIL = 第二讀取器在原文找不到完整摘錄 → 貼回包 > $W/confirm_junk.log 2>&1; echo "confirm junk rc $?" >> $W/tiny179.rc
cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_after_confirm.json; cp $V2/VRN2_HumanConfirm.json $W/humanconfirm.json 2>/dev/null
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0179/VRN2_HandleAll_v0127_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny179.rc
echo E2E179_DONE
