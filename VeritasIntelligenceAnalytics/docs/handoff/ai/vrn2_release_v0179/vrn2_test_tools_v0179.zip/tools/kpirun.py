"""KPI 量測:跑一個指令 · 回 rc · 牆鐘秒 · 子行程 CPU 秒(user+sys)· 峰值 RSS(MB)· CPU 平均使用核數 = CPU 秒 / 牆鐘。"""
import json, os, resource, subprocess, sys, time
out, cmd = sys.argv[1], sys.argv[2:]
t0 = time.time()
p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=dict(os.environ))
wall = time.time() - t0
ru = resource.getrusage(resource.RUSAGE_CHILDREN)
cpu = ru.ru_utime + ru.ru_stime
open(out + ".log", "wb").write(p.stdout)
res = {"rc": p.returncode, "wall_s": round(wall, 1), "cpu_s": round(cpu, 1), "cores_used_avg": round(cpu / wall, 2) if wall else None, "peak_rss_mb": round(ru.ru_maxrss / 1024, 1),
       "cores_available": os.cpu_count()}
json.dump(res, open(out, "w")); print(json.dumps(res))
