"""v0179(冪等):套件 v0178 不動 → RoundAll v0135(套件雜湊同 v0134)→ Handle-All v0127(指到 vrn2_release_v0179 的 RoundAll v0135)→ 開機行 + 開機檔 + 最短一行 + 開閘一行 + cmd 一行 → md · 發行清單。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v179"); rel = W / "release179"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v178/release178")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r178 = json.loads((REPO / "vrn2_release_v0178/VRN2_Release_v0178.json").read_text(encoding="utf-8"))
want = r178["package"]["sha256"]
assert hashlib.sha256((REPO / "vrn2_release_v0178/VRN2_Closeout_v0178.zip").read_bytes()).hexdigest() == want
ra = (W / "new/VRN2_RoundAll_v0135.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0178"' in ra and 'VERSION = "v0135"' in ra
(rel / "VRN2_RoundAll_v0135.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0178'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0179'")
rep("$F = 'VRN2_RoundAll_v0134.py'", "$F = 'VRN2_RoundAll_v0135.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0126", "Handle-All v0127", ha.count("Handle-All v0126"))
left = [l for l in ha.split("\n") if re.search(r"Handle-All v0126|v0134[.]py|release_v0178", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0178", "vrn2_release_v0179"), ("VRN2_HandleAll_v0126.md", "VRN2_HandleAll_v0127.md"), ("Handle-All v0126 SHA-256 OK", "Handle-All v0127 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0127_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0179/VRN2_HandleAll_v0127_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
gates = "$env:VIA_NET_CONSENT='YES';$env:VIA_SCRAPE_CONSENT='YES';" + tiny
assert all(ord(c) < 128 for c in gates) and len(tiny) < 500 and len(gates) < 560
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n"); (rel / "tiny_gates_line.txt").write_text(gates + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")
md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0127(2026-11-04 · 收尾頁三處小修 · 套件 v0178 不動 · RoundAll v0135)

桌機 2026-11-04 01:53 回報:套件 v0178 整輪 + repair → **收尾 REVIEW · VRN-2 0 · VCGC 0 · 人工 1(MQ-1560 四點影像頁)· 資料源 3** —— VRN-2 側已結案。

| 回報 | v0179 |
|---|---|
| 檔案總管跳「Windows 找不到 …\\\\market\\\\vdf\\\\last_error.txt」| ⑥e 那列的提示寫「網路 → 看 …\\\\last_error.txt」,但這輪擷取失敗 0 · 那個檔不存在(上一輪的已改名 last_error.before_<時間>.txt)→ RoundAll v0135:檔案在才指它(附完整路徑),不在就寫「這輪沒有 · 不用開」|
| 複製 --confirm 那行連提示字一起貼上 | 收尾頁人工項的指令另放一格(點一下選整行 · 只有指令本身)· `--confirm` 遇到不是 H-xxxxxxxx 的字 → 一行黃字說忽略 · 代碼照記 |

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0178/VRN2_Closeout_v0178.zip`(SHA-256 `%s` · 不動)|
| 一支 Python | `vrn2_release_v0179/VRN2_RoundAll_v0135.py`(SHA-256 `%s` · 自測 111 項)|
| 自動選模式 | 上一輪收據 v0178 · ⑦ 跑完 → repair(幾分鐘)|

## PowerShell 7 視窗 · 開閘一行(%d 字元)

```powershell
%s
```

## PowerShell 7 視窗 · 閘不動(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0127 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0135 `%s`)。

## cmd 視窗(%d 字元 · 閘不動)

```bat
%s
```

## 人工核對(看過原圖之後 · 只有你打才算)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0135.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0135.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(gates), gates, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0127.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0135.py(套件 v0178 不動)

`VRN2_RoundAll_v0135.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0134 +:

| 改了什麼 | 說明 |
|---|---|
| ⑥e 提示 | 「網路 → 看 last_error.txt」只在檔案真的在時出現(附完整路徑);不在 → 「這輪沒有擷取錯誤檔 · 不用開」|
| 收尾頁人工項 | `--confirm` 指令單獨一格(`<code class="cmd">` · 點一下選整行)· 說明字另放 |
| `--confirm` | 連提示字一起貼上 → 只記 H-xxxxxxxx 代碼 · 其他字一行黃字忽略;沒有代碼 → 紅 · 不記 |
| ⑥ 收尾 KPI | 兩列灰燈(只是指標 · 不改結案判定):**正確性** = 獨立驗證三類 + 四點原文核對的 對上 / 待人工 / 不符(不符 0 才寫「達標」· 待人工照列);**速度** = 收據耗時 · 最慢步驟 · 沒計時秒數 · 管理器最慢階段占比 · ① CPU 核 / 執行緒上限 / 可用 RAM / 平行路數 · ④b 平行段倍數 → 收尾頁「這輪的數據」最前面 + `VRN2_KPI_latest.json`(進貼回包)|
| 套件 | 照用 `vrn2_release_v0178/VRN2_Closeout_v0178.zip`(SHA-256 `%s`)|
| 自測 | 111 項(v0134 的 107 項 + 108 · 108b · 108c · 108d)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0135.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0135 + VRN2_HandleAll_v0127 (package VRN2_Closeout_v0178 unchanged)", "date": "2026-11-04",
        "trigger": "桌機 2026-11-04 01:53:套件 v0178 收尾 REVIEW(VRN-2 0 · 人工 1 · 資料源 3)· 操作員截圖:檔案總管「Windows 找不到 …last_error.txt」· --confirm 連提示字一起貼上",
        "fixes": {"RoundAll_v0135": "⑥e hint points at last_error.txt only when it exists · closeout confirm command in its own <code class=cmd> cell · --confirm ignores pasted hint words · closeout KPI rows (correctness + speed on CPU/DRAM, GRAY) + VRN2_KPI_latest.json · selftest 111",
                  "HandleAll_v0127": "points to RoundAll v0135 in vrn2_release_v0179 · same rules"},
        "package": {"name": "VRN2_Closeout_v0178.zip", "sha256": want, "release_folder": "vrn2_release_v0178", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0134.py", "sha256": r178["roundall"]["sha256"], "status": "superseded 2026-11-04; file kept in vrn2_release_v0178"}],
        "roundall": {"name": "VRN2_RoundAll_v0135.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0135.md"},
        "handleall": {"name": "VRN2_HandleAll_v0127.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0127_boot.txt", "boot_line_sha256": bt_sha,
                      "boot_line_chars": len(bt_line), "tiny_line_chars": len(tiny), "gates_line_chars": len(gates), "cmd_line_chars": len(cmd_line)},
        "results": {"status": "see VRN2_Verification_v0179.md"}}
(rel / "VRN2_Release_v0179.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· gates", len(gates), "· cmd", len(cmd_line))
