const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1366, height: 900 } });
  const errs = []; p.on('pageerror', e => errs.push(String(e)));
  await p.goto('file://' + process.argv[2]); await p.waitForTimeout(500);
  await p.evaluate(() => { const t = document.querySelector('a[href="#todo"]'); if (t) t.click(); });
  const el = p.locator('code.cmd').first(); await el.scrollIntoViewIfNeeded(); await el.click();
  const sel = await p.evaluate(() => window.getSelection().toString());
  const txt = await el.textContent();
  await el.screenshot({ path: process.argv[3] });
  console.log(JSON.stringify({ selected_equals_command: sel.trim() === txt.trim(), command: txt.slice(0, 120), errs }));
  await b.close();
})();
