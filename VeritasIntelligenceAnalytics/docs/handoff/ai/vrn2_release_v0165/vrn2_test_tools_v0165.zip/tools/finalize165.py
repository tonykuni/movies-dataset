"""v0165 收尾:驗證紀錄 · 交接 v0166(從 v0165 抄 · 只增)· 放進倉 vrn2_release_v0165 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v165"); rel = W / "release165"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    return x.replace(str(W / "t165a"), "<sbx>").replace(str(W), "<w>").replace(SCR, "<scratch>").replace(SCR0, "<scratch0>")


R = json.loads((rel / "VRN2_Release_v0165.json").read_text(encoding="utf-8"))
st = [l for l in lines(W / "rall121_selftest.log") if re.search(r"^\[PASS\] (79|8[0-3]) |^\[FAIL\]|--selftest · ", l)]
stv = [l for l in lines(W / "rall121_selftest_venv.log") if "--selftest · " in l]
ps = json.loads((W / "pscheck165.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny165.rc") if l.strip()]
pat = r"boot:|boot SHA|⑤ 修 · SSOT|SSOT-ID 請求|===== 收尾|\[(VRN-2|人工|VCGC|資料源)\] \d"
e2e = {n: [short(l)[:220] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)] for n in ("repair", "report", "tamper")}
conf = [short(l)[:200] for n in ("confirm_list", "confirm_bad", "confirm_ok") for l in lines(W / ("%s.log" % n))]
states = {}
for n in ("repair", "confirmed", "report"):
    d = json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))
    states[n] = {"state": d["state"], "per_owner": d["per_owner"], "codes": [(i["owner"], i.get("code")) for i in d["items"] if i.get("code")]}
R["results"] = {"selftest": st, "selftest_venv": stv, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "confirm": conf, "closeout_states": states,
                "dry_run_desktop_0308": "RoundAll v0121 build_closeout on the 03:08 paste-back state: REVIEW (人工 2 · 資料源 3) → both 人工 items confirmed → DATA_GAP (資料源 3)",
                "not_run": "the desktop itself (next repair: ⑤ ssot → 提案 17 · closeout shows the --confirm lines) · the operator's own confirmation (by design only the operator runs --confirm)"}
(rel / "VRN2_Release_v0165.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0165 驗證紀錄(2026-11-01 · RoundAll v0121 · Handle-All v0113 · 套件 v0164 不動)

## 1. 起因

桌機 2026-11-01 04:11(v0164 repair):收尾 **REVIEW**(VRN-2 0 · VCGC 0 · 人工 2 · 資料源 3)· 操作員「繼續下一步,依照你的建議進行」。
上一輪建議:① 人工確認紀錄(看過原文、親手確認後不再列)· ② 這輪新增的 8 條 SSOT 規則要送 VCGC(repair 不放提案冊 → 核號請求仍「提案 9」)。

## 2. 修法(只換 RoundAll · 套件 / runtime / 啟動器不動)

| 檔 | 內容 |
|---|---|
| RoundAll v0121(`%s`)| `--confirm list / H-代碼 [--note] / revoke H-代碼`(只有操作員親手打 · 只增 `VIA_Reports\\\\vrn2\\\\VRN2_HumanConfirm.json` · 打錯 / 內容已變的代碼不記 · 確認後用上一輪結果重做收尾頁)· 收尾頁人工項帶代碼(根 + 內容指紋)與可複製的指令 · 有效確認 → 「人工已核」不計 · 「輸出冊 · 缺項 N 份」寫出哪幾份(讀最新啟動器日誌)· ⑤ ssot:套件 runtime 的提案冊比核號請求新 → 補放提案冊 v0101 + SSOTSync 鏈 → ⑤b sync · 自測 83 |
| Handle-All v0113(一行 `%s` · 開機檔 `%s`)| 指向 RoundAll v0121 · REVIEW 的下一步提示提 `--confirm` · 最短一行 %d 字元 · cmd 一行 %d 字元 |

AI / 自動流程永不寫確認冊(自測 82 驗證只有 step_confirm 寫 · 流程裡不呼叫)。內容一變(份數 / 檔 / 點)代碼就變 → 舊確認不算。

## 3. 測試

```text
%s
venv(py3.12):%s
%s
e2e:%s
```

## 4. e2e(桌機 v0153 狀態沙盒 · 發行夾 v0164 套件 + v0165 · pwsh 7.4.6)

```text
%s
```

確認流程:
```text
%s
```

收尾狀態:%s

桌機狀態預演(03:08 貼回包):%s

**沒跑到的**:%s。
""" % (R["roundall"]["sha256"][:12], H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], H["cmd_line_chars"],
       "\n".join(st), " ".join(stv), pparse, " · ".join(rc), "\n".join("[%s] " % n + l for n in e2e for l in e2e[n]), "\n".join(conf),
       json.dumps(states, ensure_ascii=False), R["results"]["dry_run_desktop_0308"], R["results"]["not_run"])
(rel / "VRN2_Verification_v0165.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0165.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0164 + VRN2_RoundAll_v0120 + VRN2_HandleAll_v0112 · 2026-11-01(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0164 + VRN2_RoundAll_v0121 + VRN2_HandleAll_v0113 · 2026-11-01(桌機 v0164 收尾 REVIEW · VRN-2 0 → "
        "人工確認紀錄 --confirm · repair 也送 SSOT 新提案 · 套件 v0164 不動)")
src = "\n".join(L)
once("> **本輪(v0164)**",
     "> **本輪(v0165)**:桌機 04:11 跑 v0164 repair → 收尾 **REVIEW**(VRN-2 0 · 人工 2 · 資料源 3 · 增量庫清 MOPS 列 4584 / 38 · TARGET_PRICE(ADJ) 同步還原 5)。"
     "**RoundAll v0121**:人工確認紀錄(收尾頁人工項帶代碼 `H-xxxxxxxx` 與一行 `--confirm` 指令 · 只有操作員親手打才記 · 只增 · 內容變了就重列)· "
     "「輸出冊 · 缺項 N 份」寫出哪幾份 · ⑤ ssot(repair 也把提案冊 v0101 送 ⑤b 核號請求 · 提案 9 → 17)· **Handle-All v0113**(最短一行 %d 字元 · cmd 一行 %d 字元)· 套件 v0164 不動。\n"
     "> **本輪(v0164)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
r164 = json.loads((REPO / "vrn2_release_v0164/VRN2_Release_v0164.json").read_text(encoding="utf-8"))
once("| **VRN2_HandleAll_v0112.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0112** | `vrn2_release_v0164` |",
     "| **VRN2_HandleAll_v0113.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0113** | `vrn2_release_v0165` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0121)|\n"
     "| **VRN2_RoundAll_v0121.py**(發行夾 · 一支入口 · 不在套件內)| **v0121** | `vrn2_release_v0165` | `%s` | **新**(--confirm 人工確認紀錄 · ⑤ ssot · 缺項是哪幾份 · 自測 83 項 · 套件 v0164)|\n"
     "| **VRN2_HandleAll_v0112.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0112** | `vrn2_release_v0164` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0120.py**(發行夾 · 一支入口 · 不在套件內)| **v0120** | `vrn2_release_v0164` | `%s` | **新**(" % r164["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0120.py**(發行夾 · 一支入口 · 不在套件內)| **v0120** | `vrn2_release_v0164` | `%s` | 被 v0121 取代(套件同為 v0164)· (" % r164["roundall"]["sha256"][:12])
once("| 0 | **(v0164)**",
     "| 0 | **(v0165)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"` 再貼 `vrn2_release_v0165/VRN2_HandleAll_v0113.md` 的 cmd 一行 → repair(⑤ ssot · 收尾頁人工項帶 `--confirm` 指令)· "
     "操作員看過原 PDF 後自己打 `--confirm H-…`(AI 不代打)· 上傳貼回包(含 `market\\\\VRN2_TPAdjSync_latest.json` 核 5 筆同步還原的比值)| 貼回 / 人工 |\n"
     "| 0 | **(v0164)**")
once("**v0164(2026-11-01)**:", "**v0165(2026-11-01)**:桌機 v0164 收尾 REVIEW(VRN-2 0)→ RoundAll v0121(--confirm 人工確認紀錄 · ⑤ ssot · 缺項是哪幾份)· Handle-All v0113 · 套件 v0164 不動。\n\n**v0164(2026-11-01)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0165)** **人工核對只能由操作員親手確認**:`--confirm H-…` 只有操作員自己打;AI 不代打、不寫 `VRN2_HumanConfirm.json`、不把人工項改成已核。代碼 = 項目的根 + 內容指紋,"
     "內容變了舊確認自動失效(重新列出)。REVIEW → DATA_GAP 也不是成功(外部來源缺口照列);VCGC 的 closeout_lamp 才是 VCGC 驗收。\n"
     "- **(v0165)** **新提案不必等整輪**:套件 runtime 的提案冊比 ⑤b 核號請求新 → repair 的 ⑤ ssot 補放提案冊與 SSOTSync 鏈(只增不覆寫)再跑 ⑤b sync;編號仍等 VCGC 核發。\n\n")
(REPO / "VRN2_Handover_v0166.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0165"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0121.py", "VRN2_RoundAll_v0121.md", "VRN2_HandleAll_v0113.md", "VRN2_HandleAll_v0113_boot.txt", "VRN2_Release_v0165.json", "VRN2_Verification_v0165.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t165a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0165.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "rall121_selftest.log", W / "rall121_selftest_venv.log", W / "pscheck165.log", W / "tiny165.rc", W / "seed165.log"] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("confirm_*.log")) + sorted(W.glob("closeout_*.json")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0165.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall121.py", "build165.py", "finalize165.py", "e2e165.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0166", src.count("\n"))
