"""v0165(冪等):套件 v0164 不動(雜湊照釘)→ RoundAll v0121 → Handle-All v0113 → 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0165)。
vrn2_release_v0164 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v165"); rel = W / "release165"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v164/release164")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r164 = json.loads((REPO / "vrn2_release_v0164/VRN2_Release_v0164.json").read_text(encoding="utf-8"))
want = r164["package"]["sha256"]
ra = (W / "new/VRN2_RoundAll_v0121.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0164"' in ra and 'VERSION = "v0121"' in ra
assert 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164"' in ra            # 套件 zip 照舊從 v0164 發行夾取
(rel / "VRN2_RoundAll_v0121.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0165'")
rep("$F = 'VRN2_RoundAll_v0120.py'", "$F = 'VRN2_RoundAll_v0121.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0112", "Handle-All v0113", ha.count("Handle-All v0112"))
rep("· 增量庫(先清 MOPS 算的列 · 備份)· Workbench;閘關", "· 增量庫(先清 MOPS 算的列 · 備份)· SSOT 新提案送核號請求 · Workbench;閘關")
m = re.search(r"REVIEW = '([^']*)'", ha)
rep("REVIEW = '%s'" % m.group(1), "REVIEW = '%s · 看過原文沒問題 → 照收尾頁那一項的 --confirm 指令記下(只有你打才算)'" % m.group(1))
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if "v0112" in l and not l.lstrip().startswith("#")]
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0164", "vrn2_release_v0165"), ("VRN2_HandleAll_v0112.md", "VRN2_HandleAll_v0113.md"), ("Handle-All v0112 SHA-256 OK", "Handle-All v0113 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0113_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0165/VRN2_HandleAll_v0113_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0113(2026-11-01 · 人工確認紀錄 · repair 也送 SSOT 新提案 · 套件 v0164 · RoundAll v0121)

桌機 2026-11-01 04:11(v0164 repair):收尾 **REVIEW** · VRN-2 0 · VCGC 0 · 人工 2 · 資料源 3。這版只換 RoundAll(套件 v0164 不動):

| 項目 | 現在 |
|---|---|
| 人工確認紀錄 | 收尾頁每一項「人工核對」有代碼 `H-xxxxxxxx`(項目 + 內容指紋)和一行 `--confirm` 指令 · **看過原 PDF、確認沒問題才由你親手打** → 記進 `VIA_Reports\\\\vrn2\\\\VRN2_HumanConfirm.json`(只增 · 可 `revoke`)· 那一項改「人工已核」不再計入結案 · 內容變了(多一份 / 別頁)代碼就變、會重新列出 · AI 與自動流程永不寫 |
| 缺項是哪幾份 | 「輸出冊 · 缺項 N 份」現在寫出是哪幾份(管理器寫在啟動器日誌的「輸出冊缺項 · 檔:缺什麼」)|
| SSOT 新提案 | repair 也會把提案冊 v0101(v0164 這輪新規則 8 條 · ssot_id 空白)送進 ⑤b 核號請求(提案 9 → 17)· 等 VCGC 偵測衝突後核發 · 不必為它跑整輪 |
| 套件 | 照舊 `vrn2_release_v0164/VRN2_Closeout_v0164.zip`(SHA-256 `%s`)|
| 一支 Python | `VRN2_RoundAll_v0121.py`(SHA-256 `%s` · 自測 83 項)|

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定)· 第 2 行 = 下面 PowerShell 那一行的編碼版(一樣核對 SHA-256 才執行)。要整輪才在第 2 行之前多貼 `set "VRN2_MODE=full"`。

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0121.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0121.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

第 1 行列出待核項與代碼 · 第 2 行記一筆確認(代碼照收尾頁那一項)· 撤銷:`--confirm revoke H-xxxxxxxx`。確認後收尾頁用上一輪的結果重做。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)· 要整輪再貼 `$env:VRN2_MODE = 'full'`。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0113 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0121 `%s`)。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0113.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0121.py(套件 v0164 · 人工確認紀錄 · repair 也送 SSOT 新提案)

`VRN2_RoundAll_v0121.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0120 +:

| 改了什麼 | 說明 |
|---|---|
| `--confirm` | `list` 列出上一輪收尾頁的人工核對項(代碼 · 內容 · 指令)· `H-xxxxxxxx [--note …]` 記一筆確認 · `revoke H-xxxxxxxx` 記一筆撤銷 · 打錯 / 內容已變的代碼不記 · 確認後用上一輪的結果重做收尾頁 |
| 收尾頁 | 人工項帶代碼 + 一行可複製的 `--confirm` 指令 · 有效確認 → 「人工已核」不計入結案狀態(例:REVIEW → DATA_GAP)· 「輸出冊 · 缺項 N 份」寫出哪幾份 |
| ⑤ ssot | 套件 runtime 的提案冊比 ⑤b 核號請求用的新 → 補放提案冊 v0101 + SSOTSync 鏈(只增不覆寫)→ 跑一次 ⑤b sync(VRN-2 自己的核號請求 · 不改 VCGC 的冊)|
| 貼回包 | 多收 `VRN2_HumanConfirm.json` |

只有操作員親手打 `--confirm` 才會寫確認冊;RoundAll 的流程(含 ⑤ 自動修)永遠不呼叫它。自測 83 項(v0120 的 78 項 + 79 ~ 83)。套件 `vrn2_release_v0164/VRN2_Closeout_v0164.zip`(SHA-256 `%s` · 本檔內已釘死)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0121.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0121 + VRN2_HandleAll_v0113 (package v0164 unchanged)", "date": "2026-11-01",
        "trigger": "桌機 2026-11-01 04:11(v0164 repair):收尾 REVIEW · VRN-2 0 · 人工 2 · 資料源 3 · 操作員「繼續下一步,依照你的建議進行」(上一輪建議:人工確認紀錄 · 不必整輪就送 SSOT 新提案)",
        "fixes": {"RoundAll_v0121": "--confirm list / H-code [--note] / revoke H-code (operator only · append-only VRN2_HumanConfirm.json · unknown code not recorded · closeout rebuilt from the last results) · closeout: 人工 items carry a code (root + content fingerprint) and a copyable --confirm line · confirmed → 人工已核 (not counted) · output-book gap files read from the newest launcher log · step 5 ssot: newer proposals book in the package runtime → place proposals v0101 + SSOTSync chain add-only → ⑤b sync · paste-back + confirm book · selftest 83",
                  "HandleAll_v0113": "v0112 pointed at RoundAll v0121 (vrn2_release_v0165) · REVIEW hint mentions --confirm · repair text mentions SSOT proposals"},
        "policy": {"human_confirm": "only the operator's own --confirm command writes the confirmation book; AI and automated steps never do; a confirmation applies only while the item's content fingerprint is unchanged",
                   "ssot": "VRN-2 proposes with ssot_id blank; VCGC detects conflicts and grants numbers; VRN-2 applies them (unchanged)"},
        "package": {"name": r164["package"]["name"], "sha256": want, "release_folder": "vrn2_release_v0164", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0120.py", "sha256": r164["roundall"]["sha256"], "status": "superseded 2026-11-01; file kept in vrn2_release_v0164"}],
        "roundall": {"name": "VRN2_RoundAll_v0121.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0121.md"},
        "handleall": {"name": "VRN2_HandleAll_v0113.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0113_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "results": {"status": "see VRN2_Verification_v0165.md"}}
(rel / "VRN2_Release_v0165.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
