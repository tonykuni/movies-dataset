#!/bin/bash
# v0165 e2e:沙盒(桌機 v0153 狀態 + 髒增量庫 + 6669 分割)· 發行夾 v0164(套件)+ v0165(RoundAll v0121 / Handle-All v0113)→ repair(⑤ ssot · 人工項帶代碼)→ --confirm list / 確認 / 撤銷 → 竄改不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v165; W4=/home/user/vrn2_work/v164; T=$W/t165a; P=$S2/venv_vrn2/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
$P -I $W4/seed164.py $T $W4/rt > $W/seed165.log 2>&1; cat $W/seed165.log
printf '[計] VRN-2 輸出冊 · BasicInfo(14 列)\n[計] 輸出冊缺項 · MQ-1560 20260520.pdf:年度數據\n' > "$T/VIA/VIA_Reports/vrn2/ActivateVRN-2_20261101_030000.log"
B=$T.br; D4=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164; D5=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0165; mkdir -p $D4 $D5
cp /home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164/VRN2_Closeout_v0164.zip /home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164/VRN2_Release_v0164.json $D4/
cp $W/release165/VRN2_RoundAll_v0121.py $W/release165/VRN2_RoundAll_v0121.md $W/release165/VRN2_HandleAll_v0113.md $W/release165/VRN2_HandleAll_v0113_boot.txt $W/release165/VRN2_Release_v0165.json $D5/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release165/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2)
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 3000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny165.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; }
rm -f $W/tiny165.rc
run repair
RA=$T/home/Downloads/VRN2_RoundAll_v0121.py
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm list > $W/confirm_list.log 2>&1; echo "confirm list rc $?" >> $W/tiny165.rc
CODES=$(grep -o "H-[0-9a-f]\{8\}" $W/confirm_list.log | sort -u | tr '\n' ' ')
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm H-deadbeef > $W/confirm_bad.log 2>&1; echo "confirm bad rc $?" >> $W/tiny165.rc
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm $CODES --note "e2e 原文已核" > $W/confirm_ok.log 2>&1; echo "confirm ok rc $? · $CODES" >> $W/tiny165.rc
cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_confirmed.json
run report VRN2_MODE=report
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0165/VRN2_HandleAll_v0113_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny165.rc
