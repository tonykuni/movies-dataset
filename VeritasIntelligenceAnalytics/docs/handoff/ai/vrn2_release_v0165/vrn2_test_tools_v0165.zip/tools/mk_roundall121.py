"""VRN2_RoundAll_v0121.py = v0120(倉裡 vrn2_release_v0164)+ 人工確認紀錄(--confirm · 只有操作員親手打才記)+ repair 也把 SSOT 提案冊 v0101 送核號請求。
套件仍是 v0164(雜湊照釘)。操作員 2026-11-01「繼續下一步,依照你的建議進行」(上一輪建議:人工確認紀錄 · 不必整輪也能送 8 條新提案)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v165")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0164/VRN2_RoundAll_v0120.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0120')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0120 — ', '"""VRN2_RoundAll v0121 — ', 1)
at = doc.index("v0120(操作員 2026-11-01:「Yahoo 和共識照用")
doc = doc[:at] + '''v0121(桌機 2026-11-01 04:11 · RoundAll v0120 repair · 收尾 REVIEW · VRN-2 0 · 人工 2 · 資料源 3 · 操作員「繼續下一步,依照你的建議進行」):
  · 人工確認紀錄:收尾頁每一項「人工核對」給一個代碼 H-xxxxxxxx(= 項目的根 + 內容指紋)· 操作員看過原 PDF 後親手打
      python "…\\\\VRN2_RoundAll_v0121.py" --confirm H-xxxxxxxx [--note "說明"]
    才記進 VIA_Reports\\\\vrn2\\\\VRN2_HumanConfirm.json(只增 · revoke 也是加一筆 · AI / 自動流程永不寫)→ 收尾頁那一項改「人工已核」不再計入結案狀態;
    內容變了(多一份 / 別頁 / 別的點)指紋就變 → 舊確認不算、重新列出。--confirm list 列出待核項與代碼;確認後用上一輪的結果重做收尾頁。
  · ⑤ 自動修多一項 ssot:套件 runtime 的 SSOT 提案冊比 ⑤b 核號請求用的新(v0164 這輪新規則 8 條 · ssot_id 空白)→ 提案冊 v0101 + SSOTSync 鏈
    只增不覆寫地補放 → 照 ⑤b 跑一次 sync(核號請求「提案 9 → 17」· 等 VCGC 偵測衝突後核發 · VRN-2 不自己編號)· 不必為它跑整輪。
  · 「輸出冊 · 缺項 N 份」寫出是哪幾份(管理器寫在啟動器日誌的「輸出冊缺項 · 檔:缺什麼」)· 人工看原 PDF 才知道看哪份。
  · 套件照舊 v0164(雜湊照釘)· 自測 83 項(v0120 的 78 項 + 79 ~ 83)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0120.py", "用法:python VRN2_RoundAll_v0121.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0120"', 'VERSION = "v0121"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0120.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0121.py"', 2)
rep('"VRN2_RoundAll_v0120.py" in html_', '"VRN2_RoundAll_v0121.py" in html_')
rep("· v0119 起 74 項 · v0120 起 78 項。", "· v0119 起 74 項 · v0120 起 78 項 · v0121 起 83 項。")
assert 'PACKAGE = "VRN2_Closeout_v0164"' in s and re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s)
rep('''               "output/VRN2_MarketConsensus_latest.csv")''', '''               "output/VRN2_MarketConsensus_latest.csv", "VRN2_HumanConfirm.json")''')

# ---- 共用:人工確認紀錄 · SSOT 提案冊 ----
rep('''def store_clean(v2) -> bool:''', '''CONFIRM_BOOK = "VRN2_HumanConfirm.json"                                     # v0121 操作員親手確認的人工核對(只有 --confirm 會寫 · 只增)
SSOT_CHAIN = ("VRN2_SSOT_Proposals_v0101.json", "VRN2_SSOTSync_v0102.py", "VRN2_SSOTSync_v0101.py", "VRN2_SSOTSync_v0100.py")
_PROPOSALS = re.compile(r"VRN2_SSOT_Proposals_v(\\d{4})\\.json")


def confirm_code(item: dict, ctx: dict) -> tuple:
    """v0121 人工項 → (代碼 H-xxxxxxxx, 根, 內容指紋)。內容變了(多 / 少一份 · 別頁 · 別的點)指紋就變 → 舊確認不再算。"""
    root_k = closeout_root(item, ctx) or str(item.get("step", ""))
    body = re.sub(r"\\s+", " ", str(item.get("detail") or "")).strip()
    fp = hashlib.sha256(body.encode("utf-8")).hexdigest()[:16]
    return "H-" + hashlib.sha256(("%s|%s" % (root_k, fp)).encode("utf-8")).hexdigest()[:8], root_k, fp


def confirmations(v2) -> dict:
    """v0121 有效的確認 {代碼: 紀錄}:照順序讀 · 同代碼最後一筆是 revoke → 不算。"""
    act = {}
    for e in (jread(Path(v2) / CONFIRM_BOOK, {}) or {}).get("entries") or []:
        if isinstance(e, dict) and e.get("code"):
            if e.get("action") == "revoke":
                act.pop(e["code"], None)
            else:
                act[e["code"]] = e
    return act


_GAP_LINE = re.compile(r"輸出冊缺項 · (.+?)\\s*$")


def output_gaps(v2) -> list:
    """v0121 「輸出冊 · 缺項 N 份」是哪幾份:管理器寫在啟動器日誌的「輸出冊缺項 · 檔名:缺什麼」(只讀最新的 ActivateVRN-2_*.log · 最多 8 行)。"""
    logs = sorted(Path(v2).glob("ActivateVRN-2_*.log"), key=_mtime) if Path(v2).is_dir() else []
    for p in reversed(logs[-3:]):
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError as error:
            info("輸出冊缺項:%s 讀不到(%s)· 看前一份日誌" % (p.name, type(error).__name__))
            text = ""
        got = [m.group(1).strip() for m in (_GAP_LINE.search(_ANSI.sub("", l)) for l in text.splitlines()) if m]
        if got or "VRN-2 輸出冊 ·" in text:
            return got[:8]
    return []


def confirm_cmd(script, code: str) -> str:
    return 'python "%s" --confirm %s' % (Path(script or __file__).resolve(), code)


def ssot_due(root, pkg) -> str:
    """v0121 套件 runtime 最新的 SSOT 提案冊比 ⑤b 核號請求用的新 → 回那本冊名(不然 '')。"""
    names = [e.get("path", "") for e in (jread(Path(pkg) / RUNTIME_MANIFEST, {}) or {}).get("files") or []] if pkg else []
    books = sorted((n for n in names if _PROPOSALS.fullmatch(n)), key=lambda n: int(_PROPOSALS.fullmatch(n).group(1)))
    if not books:
        return ""
    req = jread(Path(root) / "functional modules" / "VRN2" / "contract" / "VRN2_NUMBER_REQUEST_latest.json", {}) or {}
    have = _PROPOSALS.fullmatch(str(req.get("proposals_book") or ""))
    return books[-1] if (not have or int(have.group(1)) < int(_PROPOSALS.fullmatch(books[-1]).group(1))) else ""


def store_clean(v2) -> bool:''')

# ---- 收尾頁:人工項給代碼 · 有確認 → 人工已核(不計)----
rep('''          ("提醒", "提醒(不擋)", "管理器自己標「提醒 · 不擋完成」/ 剔除列帶理由在 Rejected 冊"),''',
    '''          ("提醒", "提醒(不擋)", "管理器自己標「提醒 · 不擋完成」/ 剔除列帶理由在 Rejected 冊"),
          ("人工已核", "人工已核", "操作員看過原文、親手打 --confirm 記下(VRN2_HumanConfirm.json)· 內容變了會再列出 · 不計入結案狀態"),''')
rep('''    items = merge_same(items, ctx)                                            # v0109 同一件事只列一次
    real = [i for i in items if i["owner"] not in ("提醒", "彙總")]''', '''    items = merge_same(items, ctx)                                            # v0109 同一件事只列一次
    conf = confirmations(v2)                                                  # v0121 人工確認紀錄(只有操作員的 --confirm 會寫)
    gaps = output_gaps(v2)
    for it in items:
        if it.get("owner") == "人工" and str(it.get("step", "")).startswith("⑥ 完成判定 · 輸出冊") and gaps:
            it["detail"] = str(it.get("detail") or "") + " · 缺項:" + " | ".join(gaps)   # 哪幾份(代碼跟著變:份數 / 檔變了要重核)
    for it in items:
        if it.get("owner") != "人工":
            continue
        code = confirm_code(it, ctx)[0]
        it["code"] = code
        c = conf.get(code)
        if c:
            it["owner"] = "人工已核"
            it["why"] = ("操作員 %s 已核對原文(%s)%s · 內容變了會再列出" % (str(c.get("at") or "")[:16].replace("T", " "), code, (" · " + str(c["note"])[:120]) if c.get("note") else ""))
        else:
            it["why"] = (str(it.get("why") or "") + " · 你核對過原文 / 做了決定 → 複製這行記下(只有你打才算):" + confirm_cmd(script, code))[:700]
    real = [i for i in items if i["owner"] not in ("提醒", "彙總", "人工已核")]''')
rep('''           "items": [{k: i.get(k) for k in ("owner", "lamp", "step", "detail", "hint", "why", "also")} for i in items], "links": link_rows,''',
    '''           "items": [{k: i.get(k) for k in ("owner", "lamp", "step", "detail", "hint", "why", "also", "code")} for i in items], "links": link_rows,''')
rep('''    open_n = sum(1 for i in items if i["owner"] not in ("提醒", "彙總"))''', '''    open_n = sum(1 for i in items if i["owner"] not in ("提醒", "彙總", "人工已核"))''')
rep('''    per = {o: (doc["per_owner"].get(o, 0) if o not in ("提醒", "彙總") else sum(1 for i in items if i["owner"] == o)) for o, _, _ in OWNERS}''',
    '''    per = {o: (doc["per_owner"].get(o, 0) if o not in ("提醒", "彙總", "人工已核") else sum(1 for i in items if i["owner"] == o)) for o, _, _ in OWNERS}''')

# ---- --confirm(操作員親手)----
rep('''    ap.add_argument("--selftest", action="store_true", help="本檔自測(不碰真環境)")''', '''    ap.add_argument("--confirm", nargs="*", default=None, metavar="H-代碼",
                    help="v0121 人工核對:看過原文後親手確認(list = 列出待核與代碼 · H-xxxxxxxx [--note 說明] · revoke H-xxxxxxxx)· 只記你打的 · 確認後重做收尾頁")
    ap.add_argument("--note", default="", help="v0121 --confirm 的說明(例:原圖四點與摘錄一致)")
    ap.add_argument("--selftest", action="store_true", help="本檔自測(不碰真環境)")''')
rep('''    if args.selftest:
        return selftest()
    only = {s.strip() for s in args.only.split(",") if s.strip()}''', '''    if args.selftest:
        return selftest()
    if args.confirm is not None:                                             # v0121 人工確認紀錄(只做這件事 · 不跑流程)
        return step_confirm(args)
    only = {s.strip() for s in args.only.split(",") if s.strip()}''')
rep('''def rerun_hint(script: Path) -> list:''', '''def step_confirm(args, script=None) -> int:
    """v0121 --confirm:list → 列上一輪收尾頁的人工核對項(代碼 · 檔 · 指令);H-xxxxxxxx → 記一筆確認;revoke H-xxxxxxxx → 記一筆撤銷 · 然後用上一輪結果重做收尾頁。
    只有操作員親手打這個指令才會寫 VRN2_HumanConfirm.json;RoundAll 的流程(含 ⑤ 自動修)永遠不呼叫它。"""
    root, tried = find_root(args.root)
    if not root:
        print("[RED] 找不到 VIA 根(查過:%s)· 加 --root" % " | ".join(tried)[:400], flush=True)
        return 1
    v2 = Path(root) / "VIA_Reports" / "vrn2"
    doc = jread(v2 / CLOSEOUT_JSON, {}) or {}
    pend = {i.get("code"): i for i in doc.get("items") or [] if isinstance(i, dict) and i.get("code")}
    words = [w for w in (args.confirm or []) if w]
    if not words or words[0] == "list":
        if not pend:
            print("[GRAY] 上一輪收尾頁沒有人工核對項(或收尾頁是 v0121 以前做的 · 先跑一輪:--only closeout)", flush=True)
            return 0
        for code, it in pend.items():
            print("[%s] %s · %s · %s" % ("已核" if it.get("owner") == "人工已核" else "待核", code, it.get("step"), str(it.get("detail") or "")[:240]), flush=True)
            if it.get("owner") != "人工已核":
                print("       你核對過原文 / 做了決定 → %s" % confirm_cmd(script, code), flush=True)
        return 0
    action = "revoke" if words[0] == "revoke" else "confirm"
    codes = words[1:] if action == "revoke" else words
    book = jread(v2 / CONFIRM_BOOK, {}) or {}
    book.setdefault("schema", "VIA.VRN2.HumanConfirm.v1")
    book.setdefault("rule", "只有操作員親手打 --confirm 才寫 · AI / 自動流程永不寫 · 只增(revoke 也是加一筆)· 代碼 = 項目的根 + 內容指紋 · 內容變了舊確認就不算")
    entries = book.setdefault("entries", [])
    bad = []
    for code in codes:
        it = pend.get(code)
        if not it:
            bad.append(code)
            print("[RED] %s 不在上一輪收尾頁的人工核對項(打錯 · 或內容已變 → 先 --confirm list 看現在的代碼)· 沒記" % code, flush=True)
            continue
        entries.append({"code": code, "action": action, "step": it.get("step"), "detail": str(it.get("detail") or "")[:400], "at": _dt.datetime.now().isoformat(timespec="seconds"),
                        "note": str(args.note or "")[:300], "by": "operator(--confirm 指令)", "tool": "%s %s" % (NAME, VERSION)})
        print("[GREEN] %s %s · %s" % ("撤銷" if action == "revoke" else "已記確認", code, it.get("step")), flush=True)
    if len(bad) == len(codes):
        return 1
    v2.mkdir(parents=True, exist_ok=True)
    (v2 / CONFIRM_BOOK).write_text(json.dumps(book, ensure_ascii=False, indent=1), encoding="utf-8")
    summ = jread(v2 / "VRN2_RoundAll_latest.json", {}) or {}
    if summ.get("results"):
        page = build_closeout(root, summ["results"], summ, None, script or __file__)
        print("收尾頁(用上一輪的結果重做)· %s · %s · %s → %s" % (page["state"], page["state_label"], page["state_text"], page["html"]), flush=True)
    return 0 if not bad else 2


def rerun_hint(script: Path) -> list:''')

# ---- ⑤ ssot:提案冊比核號請求新 → 補放 + ⑤b sync ----
rep('''    plan = plan_fixes(root, receipt, fetch_py, args, state.get("market_tool") or "")
    if not plan:''', '''    plan = plan_fixes(root, receipt, fetch_py, args, state.get("market_tool") or "")
    due = ssot_due(root, state.get("pkg")) if os.environ.get("VIA_VRN2_NO_SSOT") != "1" else ""
    if due:                                                                   # v0121 新提案(編號留白)不必等整輪
        plan.insert(len([p for p in plan if p[0] != "workbench"]), ("ssot", "SSOT 提案冊 %s(這輪新規則 · ssot_id 空白)送 ⑤b 核號請求 · 等 VCGC 核發" % due))
    if not plan:''')
rep('''        elif key == "store":
            refused = []''', '''        elif key == "ssot":                                                   # v0121 ⑤b 照啟動器的做法(VRN-2 自己的核號請求 · 不改 VCGC 的冊)
            refused = []
            for name in SSOT_CHAIN:
                try:
                    dest, why = install_runtime_member(state.get("pkg"), root, name)
                except (OSError, KeyError, zipfile.BadZipFile) as error:
                    dest, why = None, "%s: %s" % (type(error).__name__, str(error)[:80])
                if dest is None:
                    refused.append(why)
            sp = _latest_in(rt, "VRN2_SSOTSync_v[0-9][0-9][0-9][0-9].py")
            rc, lines = run_stream([vpy, "-X", "utf8", str(sp), "sync", "--vrn", str(rt)], cwd=rt, env=env, timeout=600, prefix="    [⑤b] ") if sp else (1, ["沒有 SSOTSync"])
            req = jread(rt / "contract" / "VRN2_NUMBER_REQUEST_latest.json", {}) or {}
            want_book = ssot_due(root, state.get("pkg"))
            lamp = "GREEN" if req.get("proposals_book") and not want_book else "YELLOW"
            detail = "提案冊 %s · 提案 %s · 待核號 %d(ssot_id 空白 · 等 VCGC 核發)%s" % (req.get("proposals_book") or "—", (req.get("counts") or {}).get("proposals", 0), len(req.get("pending") or []),
                                                                      (" · 不覆寫:" + " / ".join(refused)[:160]) if refused else "")
            step_updates["⑤b"] = (lamp, detail)
        elif key == "store":
            refused = []''')

# ---- 自測 79 ~ 82 ----
rep('''        src64 = Path(__file__).read_text(encoding="utf-8")''', '''        ctx79 = {}
        it79 = {"owner": "人工", "lamp": "YELLOW", "step": "⑥ 完成判定 · 輸出冊(基本資料 / 年度數據 / 一標題四重點)", "detail": "個股 52 份 · 缺項 3 份"}
        c79a, c79b = confirm_code(it79, ctx79)[0], confirm_code(dict(it79, detail="個股 52 份 ·  缺項 3 份 "), ctx79)[0]
        c79c = confirm_code(dict(it79, detail="個股 53 份 · 缺項 4 份"), ctx79)[0]
        v79 = td / "v79" / "VIA_Reports" / "vrn2"
        v79.mkdir(parents=True)
        (v79 / CONFIRM_BOOK).write_text(json.dumps({"entries": [{"code": c79a, "action": "confirm"}, {"code": "H-00000000", "action": "confirm"}, {"code": "H-00000000", "action": "revoke"}]}), encoding="utf-8")
        chk("79 人工確認代碼:同內容(空白不同)同代碼 · 內容變了代碼就變 · revoke 之後不算",
            re.fullmatch(r"H-[0-9a-f]{8}", c79a) is not None and c79a == c79b and c79a != c79c and set(confirmations(v79)) == {c79a})
        r80 = td / "r80"
        for d_ in ("functional modules", "supportive modules", "VIA_Reports/vrn2"):
            (r80 / d_).mkdir(parents=True, exist_ok=True)
        res80 = [{"lamp": "YELLOW", "step": "⑥ 四點原文核對", "detail": "REVIEW_OCR · {\\"PASS\\": 204, \\"OCR_PENDING\\": 4} · MQ-1560 第 1 點 OCR_PENDING"},
                 {"lamp": "YELLOW", "step": "⑥ 市場資料", "detail": "{\\"OK\\": 51, \\"MISSING\\": 1}"}]
        (r80 / "VIA_Reports" / "vrn2" / "VRN2_RoundAll_latest.json").write_text(json.dumps({"results": res80, "at": "2026-11-01T05:00:00"}), encoding="utf-8")
        p80a = build_closeout(r80, res80, {"at": "2026-11-01T05:00:00"}, None, "C:/Users/x/Downloads/VRN2_RoundAll_v0121.py")
        code80 = next(i["code"] for i in p80a["items"] if i["owner"] == "人工")
        class A80:
            root = str(r80)
            note = "原圖四點與摘錄一致"
            confirm = ["H-ffffffff"]
        rc80bad = step_confirm(A80(), "C:/Users/x/Downloads/VRN2_RoundAll_v0121.py")
        A80.confirm = [code80]
        rc80 = step_confirm(A80(), "C:/Users/x/Downloads/VRN2_RoundAll_v0121.py")
        p80b = json.loads((r80 / "VIA_Reports" / "vrn2" / CLOSEOUT_JSON).read_text(encoding="utf-8"))
        A80.confirm = ["revoke", code80]
        rc80r = step_confirm(A80(), "C:/Users/x/Downloads/VRN2_RoundAll_v0121.py")
        p80c = json.loads((r80 / "VIA_Reports" / "vrn2" / CLOSEOUT_JSON).read_text(encoding="utf-8"))
        book80 = json.loads((r80 / "VIA_Reports" / "vrn2" / CONFIRM_BOOK).read_text(encoding="utf-8"))
        chk("80 收尾頁:人工項帶代碼 + 複製用的 --confirm 指令 · 打錯代碼不記(rc 1)· 確認後重做收尾頁 → 人工已核 · REVIEW → DATA_GAP · revoke → 回 REVIEW · 紀錄只增(2 筆)",
            p80a["state"] == "REVIEW" and ("--confirm " + code80) in next(i["why"] for i in p80a["items"] if i["owner"] == "人工") and rc80bad == 1
            and rc80 == 0 and p80b["state"] == "DATA_GAP" and any(i["owner"] == "人工已核" and "原圖四點與摘錄一致" in i["why"] for i in p80b["items"])
            and rc80r == 0 and p80c["state"] == "REVIEW" and [e["action"] for e in book80["entries"]] == ["confirm", "revoke"] and all(e["by"].startswith("operator") for e in book80["entries"]))
        pk81 = td / "pk81"
        pk81.mkdir()
        (pk81 / RUNTIME_MANIFEST).write_text(json.dumps({"files": [{"path": "VRN2_SSOT_Proposals_v0100.json"}, {"path": "VRN2_SSOT_Proposals_v0101.json"}, {"path": "VRN2_SSOTSync_v0102.py"}]}), encoding="utf-8")
        cr81 = r80 / "functional modules" / "VRN2" / "contract"
        cr81.mkdir(parents=True)
        (cr81 / "VRN2_NUMBER_REQUEST_latest.json").write_text(json.dumps({"proposals_book": "VRN2_SSOT_Proposals_v0100.json"}), encoding="utf-8")
        d81a = ssot_due(r80, pk81)
        (cr81 / "VRN2_NUMBER_REQUEST_latest.json").write_text(json.dumps({"proposals_book": "VRN2_SSOT_Proposals_v0101.json"}), encoding="utf-8")
        d81b = ssot_due(r80, pk81)
        chk("81 ⑤ ssot:套件 runtime 的提案冊 v0101 比核號請求用的 v0100 新 → 排 ssot · 一樣新 → 不排 · 沒有套件 → 不排",
            d81a == "VRN2_SSOT_Proposals_v0101.json" and d81b == "" and ssot_due(r80, None) == "")
        (r80 / "VIA_Reports" / "vrn2" / "ActivateVRN-2_20261031_101010.log").write_text(
            "[計] VRN-2 輸出冊 · BasicInfo(52 列)\\n  → \\x1b[33m[計] 輸出冊缺項 · Daiwa-6278 20260521.pdf:年度數據\\x1b[0m\\n[計] 輸出冊缺項 · 凱基投顧_Takeaway_3605:年度數據\\n", encoding="utf-8")
        res83 = [{"lamp": "YELLOW", "step": "⑥ 完成判定 · 輸出冊(基本資料 / 年度數據 / 一標題四重點)", "detail": "個股 52 份 · 缺項 2 份"}]
        p83 = build_closeout(r80, res83, {"at": "2026-11-01T05:10:00"}, None, "C:/Users/x/Downloads/VRN2_RoundAll_v0121.py")
        i83 = next(i for i in p83["items"] if i["owner"] == "人工")
        chk("83 「輸出冊 · 缺項 N 份」寫出哪幾份(讀最新啟動器日誌的「輸出冊缺項 · 檔:缺什麼」· 去色碼)· 代碼含檔名(檔變了要重核)",
            "缺項:Daiwa-6278 20260521.pdf:年度數據 | 凱基投顧_Takeaway_3605:年度數據" in i83["detail"] and i83["code"] != confirm_code(dict(i83, detail="個股 52 份 · 缺項 2 份"), {})[0]
            and output_gaps(td / "nowhere") == [])
        src82 = Path(__file__).read_text(encoding="utf-8")
        chk("82 v0121:套件照舊 v0164 · 貼回包收人工確認紀錄 · 只有 step_confirm 寫確認冊(流程裡不呼叫)· ⑤ ssot 補放提案冊鏈",
            PACKAGE == "VRN2_Closeout_v0164" and "VRN2_HumanConfirm.json" in PASTE_FILES and src82.count("(v2 / CONFIRM_BOOK)" + ".write_text(") == 1
            and src82.count("return step_" + "confirm(args)") == 1 and SSOT_CHAIN[0] == "VRN2_SSOT_Proposals_v0101.json" and VERSION == "v0121")
        src64 = Path(__file__).read_text(encoding="utf-8")''')
out = W / "new" / "VRN2_RoundAll_v0121.py"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0121 lines", s.count("\n"))
