VRN2_Closeout_v0152 — VRN-2 closeout package (2026-10-30 · operator: GENERATE A PS CODE TO HANDLE ALL)

Entry: python ActivateVRN-2_v0152.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0108.py · PowerShell 7 'handle all' code: VRN2_HandleAll_v0100.md (same release folder).
Runtime: VRN2_Runtime_v0152.zip = runtime v0151 (187 members byte-identical) + VRN2_IndependentVerifier_v0114,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0152 (desktop 2026-10-30 17:06 · RoundAll v0107 quick run: close-out OPEN 'VRN-2 1' = annual FAIL, verifier reading):
 - step 11 IndependentVerifier v0114: an annual FAIL is aligned by column in the second reading (PDFium whole-page text / pdfplumber lines,
   one reader at a time, equal counts only). 260914_daiwa_aspeed.pdf PBR (x) 26E: header 'Year to 31 Dec 26E 27E 28E', row 'PBR (x) n.a. 29.2 16.8'
   -> 26E is 'n.a.' = book value -> NILVAL. A different value or no alignment keeps FAIL (with what the source holds there).
 - RoundAll v0108: new step 'verify' (re-run only step 11 with the package's newest verifier on the last round's output) and the receipt of
   the previous launcher is used when this launcher has not run yet.
Verification: see VRN2_Verification_v0152.md. Hashes: PACKAGE_SHA256.json.
