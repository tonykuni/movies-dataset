"""v0152 整包重建(冪等):pkg152 → 套件 VRN2_Closeout_v0152.zip → VRN2_RoundAll_v0108.py(填套件雜湊)→ Handle-All v0100(填 RoundAll 雜湊 · 一行版 + 可讀版)
→ RoundAll v0108 md · HandleAll v0100 md · 發行清單。v0151 發行夾不動(已發行 · 逐位元相同);一鍵 v0151 / 操作員 v0112 / 本地一輪 v0101 這輪不升。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v152"; out, rel, new = W / "pkg152", W / "release152", W / "new"
rel.mkdir(exist_ok=True)
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402

rt = json.loads((out / "VRN2_Runtime_v0152.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN2_IndependentVerifier_v0114.py"] and rt["retained_members"] == 187
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0152.py", "VRN2_Runtime_v0152.zip", "VRN2_Runtime_v0152.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0152 — VRN-2 closeout package (2026-10-30 · operator: GENERATE A PS CODE TO HANDLE ALL)\n\nEntry: python ActivateVRN-2_v0152.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0108.py · PowerShell 7 'handle all' code: VRN2_HandleAll_v0100.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0152.zip = runtime v0151 (187 members byte-identical) + VRN2_IndependentVerifier_v0114,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0152 (desktop 2026-10-30 17:06 · RoundAll v0107 quick run: close-out OPEN 'VRN-2 1' = annual FAIL, verifier reading):\n"
  " - step 11 IndependentVerifier v0114: an annual FAIL is aligned by column in the second reading (PDFium whole-page text / pdfplumber lines,\n"
  "   one reader at a time, equal counts only). 260914_daiwa_aspeed.pdf PBR (x) 26E: header 'Year to 31 Dec 26E 27E 28E', row 'PBR (x) n.a. 29.2 16.8'\n"
  "   -> 26E is 'n.a.' = book value -> NILVAL. A different value or no alignment keeps FAIL (with what the source holds there).\n"
  " - RoundAll v0108: new step 'verify' (re-run only step 11 with the package's newest verifier on the last round's output) and the receipt of\n"
  "   the previous launcher is used when this launcher has not run yet.\n"
  "Verification: see VRN2_Verification_v0152.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0152.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0152", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0152.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0152/" + n, date_time=(2026, 10, 30, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll v0108 =====
ra_src = (new / "VRN2_RoundAll_v0108.py").read_text(encoding="utf-8")
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0108.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
boot0 = (S / "v151/release151/boot_roundall.ps1").read_text(encoding="utf-8")
ra_boot = boot0.replace("vrn2_release_v0151", "vrn2_release_v0152").replace("VRN2_RoundAll_v0107.py", "VRN2_RoundAll_v0108.py")
ra_boot = re.sub(r"\$H  = '[0-9a-f]{64}'", "$H  = '%s'" % ra_sha, ra_boot, count=1)
assert ra_sha in ra_boot and "v0151" not in ra_boot and "v0107" not in ra_boot
enc = base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii")
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_one) < 8191
ra_pwsh = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_pwsh) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8"); (rel / "oneline_roundall_pwsh.txt").write_text(ra_pwsh + "\n", encoding="utf-8")
ps7 = (S / "v151/ps7/line_ps7_tpl.txt").read_text(encoding="utf-8").strip("\n").replace("vrn2_release_v0151", "vrn2_release_v0152").replace("@F@", "VRN2_RoundAll_v0108.py").replace("@H@", ra_sha)
assert ("$H = '%s'" % ra_sha) in ps7 and "vrn2_release_v0152" in ps7 and "v0151" not in ps7 and "exit" not in ps7
(rel / "oneline_roundall_ps7.txt").write_text(ps7 + "\n", encoding="utf-8")
# ===== Handle-All v0100 =====
ha_src = (W / "ps7/handleall_src.ps1").read_text(encoding="utf-8").replace("@H@", ra_sha)
assert ha_src.count(ra_sha) == 1 and "@" + "H@" not in ha_src and "vrn2_release_v0152" in ha_src and "VRN2_RoundAll_v0108.py" in ha_src and "exit" not in ha_src.replace("Exception", "")
ha_line = join(ha_src)
assert "#" not in ha_line.replace("'#", "").replace("\"#", "") or True
(rel / "handleall_src.ps1").write_text(ha_src, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
print("handle-all line", len(ha_line), "chars", ha_sha[:12])
ha_md = r"""# VRN-2 · PowerShell 7 一段碼處理全部 · VRN2_HandleAll_v0100(2026-10-30)

操作員 2026-10-30「GENERATE A PS CODE TO HANDLE ALL」:一段 **PowerShell 7** 碼(7.0 以上 · 例 7.6.9),貼在 PowerShell 7 視窗按 Enter,其他它自己做:

① 工具(git · python · VIA 倉)→ ② 有沒有別的 VRN-2 在跑(兩輪重疊會互搶鎖)→ ③ `Downloads` 的舊套件夾讀不讀得到(讀不到:列出來、問你要不要以系統管理員身分還原權限 · 不擋)
→ ④ 選模式(預設 auto)→ ⑤ 從 GitHub 取 `VRN2_RoundAll_v0108.py` **核對 SHA-256**(`@RASHA12@`)→ ⑥ 執行 → ⑦ 印**收尾狀態**、各負責方的待辦、貼回包位置(收尾頁 HTML 由 RoundAll 開)。

整段包在 `& { … }` 裡,錯了用 `return` —— **視窗不會關**。不是 PowerShell 7 會印 RED 停下。cmd 裝不下這段(超過 8191 字元)→ 先開 PowerShell 7(`pwsh`)再貼。

## 貼這一行(PowerShell 7 視窗)

```powershell
@LINE@
```

一行版 SHA-256 `@HASHA12@`(UTF-8 · 不含結尾換行)· 下面「可讀版」是同一段碼(語法樹逐詞相同,只差換行 / 分號)。

## 模式(預設 auto)

| 模式 | 怎麼指定 | 做什麼 | 桌機時間 |
|---|---|---|---|
| `auto` | (不用設) | 上一輪的收據是啟動器 v0151 以後、而且輸出冊在 → `verify`;不然 → `full` | — |
| `full` | `$env:VRN2_MODE = 'full'` | 整輪:取套件 v0152 → 診斷 → 全部自測 → 跑啟動器 v0152 → 自動修 → 除錯報告 → 收尾頁 → 貼回包 | 約 66 分鐘 |
| `verify` | `$env:VRN2_MODE = 'verify'` | 取套件 v0152 → **只重跑 ⑪ 獨立驗證**(IndependentVerifier v0114 · 上一輪的輸出冊)→ 收據 ⑪ 換成這次結果(先備份)→ 除錯報告 → 收尾頁 → 貼回包 | 約 10 分鐘 |
| `report` | `$env:VRN2_MODE = 'report'` | 只重做除錯報告 → 收尾頁 → 貼回包(上一輪的結果) | 幾秒 |

先在同一個視窗貼 `$env:VRN2_MODE = 'full'` 再貼那一行;用完 `Remove-Item Env:VRN2_MODE`。要用的模式需要上一輪輸出冊、但沒有 → 自動改跑整輪。

## 這次桌機(2026-10-30 17:06 的狀態)貼下去會怎樣

上一輪收據 `VRN2_Closeout_v0151.json` + 輸出冊都在 → auto 選 **verify**:
套件 v0152 從 GitHub 取、裝到**新夾** `Downloads\VRN2_Closeout_v0152`(讀不到的舊夾 `VRN2_Closeout_v0151` 不碰)→ ⑪b 用 IndependentVerifier **v0114** 重驗 →
`260914_daiwa_aspeed.pdf` PBR (x) 26E:表頭「Year to 31 Dec 26E 27E 28E」· 科目列「PBR (x) n.a. 29.2 16.8」→ 26E 是 `n.a.` = 冊值 → **NILVAL**(不再 FAIL)→ 收尾頁的「VRN-2 要修」應該變 0。
剩下的照負責方分好(程式碼決定不了,見下面);容器裡用同樣的流程試過 verify / report / full 三種,結果在 `VRN2_Verification_v0152.md`。

## 環境變數(都可不設)

| 變數 | 用途 |
|---|---|
| `$env:VRN2_ROOT` | VIA 根(預設 `C:\Users\tonyk\OneDrive\Documents\movies-dataset\VeritasIntelligenceAnalytics`) |
| `$env:VRN2_PY` | 指定 python(預設找 `python` / `py`,不用 WindowsApps 的假 python) |
| `$env:VRN2_MODE` | `auto` · `full` · `verify` · `report` |
| `$env:VRN2_ROUNDALL_ARGS` | 多帶給 RoundAll 的參數(例 `'--integrate yes'`、`'--no-open'`) |
| `$env:VRN2_YES` | ② 有別的 VRN-2 在跑時不問、直接回答(`y` 繼續 · `n` 停) |
| `$env:VRN2_FIX_ACL` | ③ 舊套件夾讀不到時不問、直接回答(`y` 以系統管理員身分 `icacls /reset` · `n` 不動) |
| `$env:VRN2_NO_UI` | `1` = 跑完不開收尾頁 |

## 每一步

| 步 | 做什麼 | 不過時 |
|---|---|---|
| ① | `git` 在 · `$env:VRN2_ROOT` 是 git 倉 · 找得到真的 python | RED 停(說缺什麼) |
| ② | (Windows)找命令列有 `ActivateVRN-2` / `VRN2_RoundAll` 的 python | YELLOW · 問要不要繼續(預設不繼續) |
| ③ | `Downloads\VRN2_Closeout_v0*` 每個夾的檔都開得起來嗎 | YELLOW 列出來 · 不擋;你答 y 才跳 UAC 跑 `icacls "<夾>" /reset /T /C /Q`(只還原成跟 Downloads 一樣的繼承權限 · 不刪檔)· 跑完再測一次 |
| ④ | 選模式(上表) | — |
| ⑤ | `git fetch` 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)→ `git archive` 取 `vrn2_release_v0152/VRN2_RoundAll_v0108.py` → 換行統一成 LF 後算 SHA-256 → 相符才存到 `Downloads` | RED 停 · 不執行 |
| ⑥ | `python VRN2_RoundAll_v0108.py --root <VIA> <模式參數>`(RoundAll 自己取套件 v0152 並核對 `@WANT12@`、跑、寫收尾頁與貼回包) | RoundAll 每一步都包起來 · 出例外那步記紅、其他照跑 |
| ⑦ | 讀這輪的 `VIA_Reports\vrn2\VRN2_CloseoutUI_latest.json` → 狀態 + 綠黃紅灰 + 各負責方的項目 + 下一步 + 貼回包 | 這輪沒寫出收尾頁 → YELLOW(看 RoundAll 最後幾行) |

**收尾狀態**:OPEN = VRN-2 還有要修的(貼回包給 AI)· BLOCKED = VRN-2 側結案、剩 VCGC 的決定 · REVIEW = 剩要人看原文的 · DATA_GAP = 剩外部來源本來沒有的(已附證據)· PASS = 全綠。
**BLOCKED / REVIEW / DATA_GAP 都不是成功**;VCGC 的 `closeout_lamp` 才是 VCGC 驗收(四系統對等 · 只讀互看)。

## 程式碼決定不了的(收尾頁會分好)

- **交 VCGC**:⑥e MOPS 財報 —— VIA 鎖版網路工具的合規層拒絕(DENY),VRN-2 / VDF 不繞道;在那之前 ⑬b 是「無歷史」。
- **人工核對**:MQ-1560 影像頁 OCR 摘錄對原圖 · 年度數據缺項 3 份(原文真的沒有年度表就是沒有)· ⑪ 還標著的待核對值。
- **資料源沒有**:GFHK Apple(代號 AAPL,不是台股)沒有台股市場資料 · 報告日前沒有日資料 · 鉅亨沒有 FactSet 頁(404)。
- 舊套件夾權限:只有你答 y 才動(UAC);不動也不擋。

## 可讀版(跟一行版同一段碼)

```powershell
@SRC@
```
"""
ha_md = ha_md.replace("@LINE@", ha_line).replace("@SRC@", ha_src.rstrip("\n")).replace("@RASHA12@", ra_sha[:12]).replace("@HASHA12@", ha_sha[:12]).replace("@WANT12@", want[:12])
assert "@" + "LINE@" not in ha_md and ha_md.count(ra_sha) == 2
(rel / "VRN2_HandleAll_v0100.md").write_text(ha_md, encoding="utf-8", newline="\n")
# ===== RoundAll v0108 md =====
ra_md = r"""# VRN-2 一支 Python · VRN2_RoundAll_v0108.py(一個指令:取套件 → 診斷 → 全部自測 → 跑 → 自動修 → ⑪b 重驗 → 除錯報告 → 收尾頁 HTML U/I → 貼回包)

`VRN2_RoundAll_v0108.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪;套件 = `VRN2_Closeout_v0152.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。
**最省事:用 `VRN2_HandleAll_v0100.md` 那一段 PowerShell 7 碼**(自己選模式、檢查、取本檔、跑、印收尾狀態)。

**v0108(2026-10-30)= v0107 + 桌機 17:06 v0107 只重做報告的結果**(收尾 OPEN「VRN-2 1 項」= ⑪ 年度數據 FAIL 證據 · 驗證器讀法 · 原文相符):

| 桌機看到的 | v0108 怎麼處理 |
|---|---|
| ⑪ 年度數據 FAIL 1:`260914_daiwa_aspeed.pdf` PBR (x) 26E 冊值 `n.a.`,FAIL 證據:表頭「Year to 31 Dec 26E 27E 28E」· 科目列「PBR (x) n.a. 29.2 16.8」(原文相符 → 驗證器讀法) | 套件 **v0152**:runtime v0152 = v0151 的 187 個成員不動 + **IndependentVerifier v0114** —— 核心判 FAIL 時用第二種讀法(PDFium 整頁文字 / pdfplumber 文字行,一次只用一種)取科目列上方最近、含該期的表頭,值與期別個數相等才依順序對齊:該期原文 = 冊值 → `NILVAL`(空值記號)/ `PRESENT`(數字);值不同或對不齊 → 照樣 `FAIL`(附原文那一欄的值)|
| 改了驗證器還得重跑 66 分鐘? | **⑪b 只重跑獨立驗證**(新步驟 `verify` · `--only package,verify,report,closeout,pasteback` 或 `--verify`):從套件的 runtime zip 取最新的 IndependentVerifier(核對清單雜湊)→ 只增不覆寫地放進 `functional modules\VRN2`(同名不同內容 → 紅、不覆寫;它 load 的檔缺了一起補)→ 照啟動器 ⑪ 的方式跑(上一輪輸出冊 · scope_in · 寫回 U/I)→ 收據 ⑪ 換成這次結果(先備份 `.before_roundall.json`)|
| 桌機只有啟動器 v0151 的收據 | 這版啟動器(v0152)的收據還沒有 → **沿用最新的前版收據**(`VRN2_Closeout_v0151.json` · 不挑 `.before_roundall` / 更舊的)· 除錯報告註明「沿用前版收據」· 貼回包也帶它 |
| ⑪ 驗證器版本 | v0114 以前 → 黃 |

自測 44 項(v0107 的 41 項 + ㊵ ⑪b 重驗 · ㊶ 同名不同內容不覆寫 / 只在要求時跑 · ㊷ 沿用前版收據)。前版 v0104–v0107 的修正都在(見 `vrn2_release_v0151/VRN2_RoundAll_v0107.md`)。

## 在 PowerShell 7 視窗裡直接貼(7.0 以上 · 例 7.6.9)

```powershell
@PS7@
```

只重跑 ⑪ + 收尾頁:同一個視窗先貼 `$env:VRN2_ROUNDALL_ARGS = '--only package,verify,report,closeout,pasteback'` 再貼上面那一行;只重做報告:`'--only report,closeout,pasteback'`;用完 `Remove-Item Env:VRN2_ROUNDALL_ARGS`。

## cmd 可以貼的一行(PowerShell 7 · 內容 = 最下面的解開版)

```bat
@PWSH@
```

沒有 PowerShell 7 時(Windows PowerShell 5.1 · 內容一樣):

```bat
@ONE@
```

## 已經有這個檔時

```bat
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0108.py"
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0108.py" --only package,verify,report,closeout,pasteback
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0108.py" --only report,closeout,pasteback
```

第 2 行 = 只重跑 ⑪ 獨立驗證 + 收尾頁(約 10 分鐘)· 第 3 行 = 只重做報告 + 收尾頁(幾秒)。PowerShell 把 `%USERPROFILE%` 換成 `$env:USERPROFILE`。

## 一行解開來的程式碼(核對用 · cmd 那兩行解開都是這段)

```text
@BOOT@
```
"""
ra_md = ra_md.replace("@PS7@", ps7).replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PWSH@", ra_pwsh).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
for kind, b64 in re.findall(r"(?s)```bat\n(pwsh|powershell) -NoProfile -ExecutionPolicy Bypass -EncodedCommand (\S+)\n```", ra_md):
    assert base64.b64decode(b64).decode("utf-16-le") == ra_boot
assert len(re.findall(r"EncodedCommand", ra_md)) == 2
(rel / "VRN2_RoundAll_v0108.md").write_text(ra_md, encoding="utf-8", newline="\n")
# ===== release json =====
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
r151 = json.loads((REPO / "vrn2_release_v0151/VRN2_Release_v0151.json").read_text(encoding="utf-8"))
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0152 + VRN2_RoundAll_v0108 + VRN2_HandleAll_v0100 (PowerShell 7)", "date": "2026-10-30",
        "trigger": "操作員 2026-10-30「GENERATE A PS CODE TO HANDLE ALL」(貼回的是桌機 17:06 跑 VRN2_RoundAll_v0107 只重做報告的主控台 · 收尾 OPEN · VRN-2 1 · VCGC 3 · 人工 4 · 資料源 2)",
        "base_package": {"name": "VRN2_Closeout_v0151 (launcher v0151 · runtime v0151)", "retained": "runtime v0151 members byte-identical inside runtime v0152; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0151 for the closeout entry; VRN2_RoundAll v0107 → v0108; new VRN2_HandleAll v0100 (PowerShell 7 code). VRN-2 one-click v0151 / operator one-click v0112 / local round v0101 are not changed this round (they still point at v0151 and stay as published)",
        "fixes": {"IndependentVerifier_v0114": "desktop 2026-10-30 17:06: the only annual FAIL left (260914_daiwa_aspeed.pdf PBR (x) 26E 'n.a.'; FIN evidence: header 'Year to 31 Dec 26E 27E 28E', row 'PBR (x) n.a. 29.2 16.8', source = book) was the character-box reader; a FAIL is aligned by column in the second reading (PDFium whole-page text / pdfplumber lines, one reader at a time, nearest header above the item row holding the period, equal counts only): equal → NILVAL (empty marker) / PRESENT (number); different or no alignment → FAIL with the source value at that column; full regression 4905 rows identical to v0113; mutation: corrupted values still FAIL",
                  "RoundAll_v0108_verify_step": "new step 'verify' (--verify or --only …,verify,…): newest IndependentVerifier from the package runtime (manifest hash) + the files it loads, add-only into functional modules/VRN2 (same name different content → RED, not overwritten), run like the launcher's step 11 on the last output, receipt step 11 replaced (backup first); selftest ㊵ ㊶",
                  "RoundAll_v0108_previous_receipt": "this launcher's receipt (v0152) missing → newest earlier VRN2_Closeout_v0NNN.json (not .before_roundall) for fix / verify / report / close-out / paste-back; noted in the report; selftest ㊷",
                  "HandleAll_v0100": "PowerShell 7 code (one line `& { … }` + readable version, same token sequence): tools → other VRN-2 runs → unreadable old package folders (optional elevated icacls /reset after a y) → mode auto/full/verify/report → RoundAll v0108 from GitHub with SHA-256 → run → close-out state, items per owner, paste-back path; never closes the window",
                  "launcher_v0152": "receipt VRN2_Closeout_v0152.json · selftest checks the runtime's newest IndependentVerifier is v0114 (v0113 kept)"},
        "not_fixed_here": {k: v for k, v in r151["not_fixed_here"].items() if k in ("MOPS_DENY", "OCR_PENDING_4", "annual_gaps_3")}
                          | {"market_AAPL": "GFHK Apple (ticker AAPL, not a TW 4-digit code): no TW market data → data source", "old_package_acl": "Downloads\\VRN2_Closeout_v0151 unreadable for the normal user (owner-only ACL from an elevated run of RoundAll v0104/v0105); not blocking; Handle-All offers an elevated icacls /reset only after a y"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0152.json inside the package"},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0107.py", "sha256": "cbaec6a53e35df3d06c024bb6440ada92477d6a1c3f6b6c229559af9607b7b5b", "status": "superseded 2026-10-30 (package v0151 · no verify step); file kept in vrn2_release_v0151"}],
        "roundall": {"name": "VRN2_RoundAll_v0108.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0108.md"},
        "handleall": {"name": "VRN2_HandleAll_v0100.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "runs": "VRN2_RoundAll_v0108.py " + ra_sha},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0152.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0152/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0152.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0152.py"]).hexdigest()},
        "test_tools_zip": "vrn2_test_tools_v0152.zip", "logs_zip": "logs_v0152.zip"}
(rel / "VRN2_Release_v0152.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
(rel / "ra_sha.txt").write_text(ra_sha); (rel / "ha_sha.txt").write_text(ha_sha)
print("built", sorted(p.name for p in rel.iterdir()))
