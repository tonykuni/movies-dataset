#!/bin/bash
# 桌機情境(只有啟動器 v0151 的收據 + 上一輪輸出 · 跟桌機 17:06 一樣):auto(→ verify)· report · 錯模式 · 非 git 倉 · 竄改 RoundAll
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=$S/v152; T=$W/t152d
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v151/t151 $T && git -C $T/VIA remote set-url origin $T/remote.git && bash $W/mkbranch152.sh t152d
cp $T/VIA/VIA_Reports/vrn2/VRN2_Closeout_v0151.json $W/d_receipt_before.json
bash $W/ha152.sh t152d d_auto
bash $W/ha152.sh t152d d_report VRN2_MODE=report
bash $W/ha152.sh t152d d_bogus VRN2_MODE=xyz
bash $W/ha152.sh t152d d_nogit VRN2_ROOT=$T/tmp
(cd $T.br && printf '\n# tampered\n' >> VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0152/VRN2_RoundAll_v0108.py && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5)
mv $T/home/Downloads/VRN2_RoundAll_v0108.py $T/home/Downloads/VRN2_RoundAll_v0108.py.keep
bash $W/ha152.sh t152d d_tamper
ls $T/home/Downloads/VRN2_RoundAll_v0108.py > $W/d_tamper_file.txt 2>&1; mv $T/home/Downloads/VRN2_RoundAll_v0108.py.keep $T/home/Downloads/VRN2_RoundAll_v0108.py
bash $W/mkbranch152.sh t152d
echo done-d >> $W/ha152.rc
