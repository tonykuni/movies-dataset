"""收尾 v0152:測試結果 → VRN2_Release_v0152.json.results · VRN2_Verification_v0152.md(套件 / RoundAll / Handle-All 已定,不重算)。"""
import glob, json, re, zipfile
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v152"); rel = W / "release152"


def j(p, d=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return d


def lines(p):
    try:
        return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []


def grep(p, pat, all_=False):
    hits = [l for l in lines(p) if re.search(pat, l)]
    return hits if all_ else (hits[-1] if hits else "")


def esc(x):
    return str(x).replace("|", "\\|")


def short(s):
    return re.sub(r"/tmp/claude-0/[^ ·)(]*?/(t152d?|v152)/", r"<\1>/", str(s))


def ha(name):
    p = W / ("ha152_%s.log" % name)
    keep = [l for l in lines(p) if re.match(r"^\[(GREEN|YELLOW|RED|GRAY|計)\] (①|②|③|④|⑤|⑥ ⑪|⑪b|⑧|VRN2_MODE|Handle)|^總表|^===== 收尾|^  \[(VRN-2|VCGC|人工|資料源)\]|^  下一步", l)]
    return [short(l)[:230] for l in keep if not l.startswith(("[GREEN] ③ 自測 · VRN2", "[GREEN] ② "))]


selft = {"VRN2_IndependentVerifier_v0114(VIA 樹內 · 含 v0105 · v0110 ~ v0113)": " / ".join(x[:150] for x in grep(W / "iv114_selftest.log", r"^\[PASS\] v011[34]", True)),
         "VRN2_RoundAll_v0108": grep(W / "rall108_selftest.log", r"--selftest · .*不過 0")[:200],
         "ActivateVRN-2_v0152(建置夾)": grep(W / "ActivateVRN-2_v0152_selftest.log", r"\[PASS\] v0152")[:220],
         "ActivateVRN-2_v0152(套件夾複本 · 不靠 ../new)": grep(W / "ActivateVRN-2_v0152_selftest_iso.log", r"\[PASS\] v0152")[:220]}
regress = [l for l in lines(W / "regress114.log") if re.match(r"^[0ABC]\)", l)]
r13, r14 = j(W / "regress/rep_0113.json", {}), j(W / "regress/rep_0114.json", {})
srt = lambda L: sorted(json.dumps(x, sort_keys=True, ensure_ascii=False) for x in L or [])
full = {"fin_rows 相同": r13.get("fin_rows") == r14.get("fin_rows"), "fin_counts": r14.get("fin_counts"), "basic 相同(排序後)": srt(r13.get("basic")) == srt(r14.get("basic")),
        "summary 相同(排序後)": srt(r13.get("summary")) == srt(r14.get("summary")), "筆數": len(r14.get("fin_rows") or [])}
rc = (W / "ha152.rc").read_text(encoding="utf-8").strip().replace("\n", " · ")
page_d = j(W / "t152d/VIA/VIA_Reports/vrn2/VRN2_CloseoutUI_latest.json", {}) or {}
page_f = j(W / "t152/VIA/VIA_Reports/vrn2/VRN2_CloseoutUI_latest.json", {}) or {}
rec_d = j(W / "t152d/VIA/VIA_Reports/vrn2/VRN2_Closeout_v0151.json", {}) or {}
rec_f = j(W / "t152/VIA/VIA_Reports/vrn2/VRN2_Closeout_v0152.json", {}) or {}
zd = sorted(glob.glob(str(W / "t152d/home/Downloads/VRN2_PasteBack_*.zip"))); zf = sorted(glob.glob(str(W / "t152/home/Downloads/VRN2_PasteBack_*.zip")))
mem = lambda z: [m for m in zipfile.ZipFile(z).namelist() if "Closeout" in m] if z else []
st_rows = [l for l in lines(W / "ha152_f_auto_full.log") if re.match(r"^\[(GREEN|YELLOW|RED)\] ③ 自測 · ", l)]
desk = {"auto → 模式": grep(W / "ha152_d_auto.log", r"④ 自動選模式")[:160],
        "⑤ 取 RoundAll": short(re.sub(r" → .*", "", grep(W / "ha152_d_auto.log", r"⑤ VRN2_RoundAll_v0108.py SHA-256")))[:160],
        "① 套件": short(grep(W / "ha152_d_auto.log", r"^\[GREEN\] ① 套件"))[:200],
        "⑪b": short(grep(W / "ha152_d_auto.log", r"^\[GREEN\] ⑪b"))[:300],
        "收尾收據(沿用前版)": short(grep(W / "ha152_d_auto.log", r"^\[(RED|YELLOW|GREEN)\] ⑥ 收尾收據"))[:260],
        "v0151 收據 ⑪ 改後": [(s["step"], s["lamp"], s["detail"][:120]) for s in rec_d.get("steps") or [] if str(s.get("step", "")).startswith("⑪")],
        "v0151 收據 roundall.fixed": sorted((rec_d.get("roundall") or {}).get("fixed") or {}),
        "收尾頁": "%s · %s · %s" % (page_d.get("state"), page_d.get("state_text"), json.dumps(page_d.get("per_owner"), ensure_ascii=False)),
        "貼回包帶收據": mem(zd[-1] if zd else None),
        "report 模式": grep(W / "ha152_d_report.log", r"^\[計\] Handle")[:120],
        "錯模式": grep(W / "ha152_d_bogus.log", r"^\[RED\]")[:120],
        "不是 git 倉": short(grep(W / "ha152_d_nogit.log", r"^\[RED\]"))[:160],
        "RoundAll 被竄改": grep(W / "ha152_d_tamper.log", r"^\[RED\] ⑤")[:160] + " · 存檔:" + ("沒有(不執行)" if "No such file" in (W / "d_tamper_file.txt").read_text() else "有?")}
fresh = {"auto → 模式(沒有收據)": grep(W / "ha152_f_auto_full.log", r"④ 自動選模式")[:120],
         "③ 自測": "%d 支 · 綠 %d · 紅 / 黃 %d" % (len(st_rows), sum(1 for l in st_rows if l.startswith("[GREEN]")), sum(1 for l in st_rows if not l.startswith("[GREEN]"))),
         "④ 啟動器 v0152": short(re.sub(r" · NEXT: .*", "", grep(W / "ha152_f_auto_full.log", r"④ 跑啟動器")))[:160],
         "⑪(啟動器內 · 背景)": short(grep(W / "ha152_f_auto_full.log", r"\[計\] ⑪ 獨立驗證 · 年度數據"))[:160],
         "⑥ ⑪ 驗證器版本": short(grep(W / "ha152_f_auto_full.log", r"⑥ ⑪ 驗證器版本"))[:120],
         "總表": grep(W / "ha152_f_auto_full.log", r"^總表")[:120],
         "再貼(auto → 模式)": grep(W / "ha152_f_auto_verify.log", r"④ 自動選模式")[:140],
         "再貼 ⑪b": short(grep(W / "ha152_f_auto_verify.log", r"^\[GREEN\] ⑪b"))[:200],
         "report": grep(W / "ha152_f_report.log", r"^總表")[:120],
         "收尾頁(最後)": "%s · %s · %s" % (page_f.get("state"), page_f.get("state_text"), json.dumps(page_f.get("per_owner"), ensure_ascii=False)),
         "v0152 收據 roundall.fixed": sorted((rec_f.get("roundall") or {}).get("fixed") or {}),
         "貼回包帶收據": mem(zf[-1] if zf else None),
         "容器才有的 VCGC 項": "③ 環境檢查缺 7(accelerator / curl_cffi / cv2 / duckdb / lz4 / pyvips / watchdog)· ⑥e 擷取 Python 沒有合 VDF 界線的 —— 容器沒裝,桌機有"}
acl = {"偵測(uid 0 拿掉 CAP_DAC_OVERRIDE / CAP_DAC_READ_SEARCH · 模擬一般身分)": "讀不到 zip 的夾 + 列不出的夾 → 列出 2 個;讀得到的夾 / 名字不符的夾 → 不列",
       "以系統管理員身分要跑的指令(只在 Windows · 答 y 才跑)": "icacls '<夾>' /reset /T /C /Q(單引號路徑跳脫 · -EncodedCommand 往返一致 · 剖析 0 錯)· UAC 本身只在桌機"}
R = {"selftests": selft, "regress_v0114": regress, "regress_full_run_v0113_vs_v0114": full, "pwsh_hash_chain": lines(W / "pscheck152.log"), "rc": rc,
     "desktop_like_sandbox": desk, "fresh_sandbox": fresh, "acl_check": acl,
     "handover_line": "桌機情境(複製 v0151 沙盒:只有啟動器 v0151 的收據 + 上一輪輸出)貼 Handle-All → auto 選 verify → 套件 v0152 → ⑪b v0114 → 收尾 %s(VRN-2 0)· 34 秒;report 1 秒;RoundAll 被竄改 → ⑤ 紅、不執行。全新沙盒 auto → full(③ 自測 %s · 啟動器 v0152 · ⑪ v0114)→ 再貼 auto → verify → report,收尾都是 %s、VRN-2 0。"
                      % (page_d.get("state"), fresh["③ 自測"], page_f.get("state")),
     "not_claimed": ["Windows desktop run of Handle-All v0100 / RoundAll v0108 / package v0152: not yet (next paste-back); the Daiwa aspeed PDF is only on the desktop — v0114 is proven by its selftest case built from the desktop's FIN evidence lines and by the container regression (4905 rows unchanged · mutations still FAIL)",
                     "Windows-only parts of Handle-All (Get-CimInstance process check, UAC Start-Process -Verb RunAs, icacls) are checked by parsing / encoding round-trip and by the capability-dropped detection test only",
                     "MOPS DENY (VCGC) · MQ-1560 OCR 4 points / annual gaps 3 (human) · Apple not a TW stock / no daily data before the report date (data source): not changed",
                     "the container's VCGC items (missing accelerator packages, fetch Python outside VDF bounds) are container-only; the desktop has them"]}
relj = j(rel / "VRN2_Release_v0152.json"); relj["results"] = R
(rel / "VRN2_Release_v0152.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
md = ["# VRN-2 v0152 + VRN2_RoundAll_v0108 + VRN2_HandleAll_v0100 容器實測紀錄(2026-10-30)", "",
      "操作員 2026-10-30「GENERATE A PS CODE TO HANDLE ALL」(貼回的是桌機 17:06 跑 RoundAll v0107 只重做報告:收尾 OPEN · VRN-2 1 = ⑪ 年度數據 FAIL 證據 · 驗證器讀法 · 原文相符)→ v0152(見發行清單 `fixes` · `not_fixed_here`)。", "",
      "## 1. 自測", "", "| 檔 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有 PASS 行)") for k, v in selft.items()] + ["",
      "## 2. IndependentVerifier v0114 回歸 + 變造(14 份真實 PDF · 4905 筆)", "", "```", *regress, "```", "",
      "整支跑(平行子行程)v0113 vs v0114:`%s`" % json.dumps(full, ensure_ascii=False), "",
      "## 3. PowerShell 雜湊鏈與剖析(pwsh 7.4.6)", "", "```", *R["pwsh_hash_chain"], "```", "",
      "## 4. 桌機情境:貼 Handle-All(只有啟動器 v0151 的收據 + 上一輪輸出 · 跟桌機 17:06 一樣)", "", "| 項目 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(short(v))) for k, v in desk.items()] + ["",
      "```", *ha("d_auto"), "```", "",
      "## 5. 全新沙盒:貼 Handle-All(auto → full)→ 再貼(auto → verify)→ report", "", "| 項目 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(short(v))) for k, v in fresh.items()] + ["",
      "```", *ha("f_auto_full"), "```", "",
      "## 6. ③ 舊套件夾讀不到", "", "| 項目 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v)) for k, v in acl.items()] + ["",
      "回合結束碼:`%s`" % rc, "", "## 7. 沒做到 / 沒驗到(照實)", ""] + ["- %s" % x for x in R["not_claimed"]]
(rel / "VRN2_Verification_v0152.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
print("finalize152 ok ·", R["handover_line"][:300])
