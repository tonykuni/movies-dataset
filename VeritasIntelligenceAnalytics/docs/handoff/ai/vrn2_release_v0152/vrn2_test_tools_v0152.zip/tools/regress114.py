"""v0114 regression + mutation on the sandbox's real PDFs (in process · inside the VIA-like tree)."""
import importlib.util, json, random, sys
from collections import Counter
from pathlib import Path
tree, od, pdfdir = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
spec = importlib.util.spec_from_file_location("iv114_regress", tree / "VRN2_IndependentVerifier_v0114.py"); m = importlib.util.module_from_spec(spec); sys.modules["iv114_regress"] = m; spec.loader.exec_module(m)
C = m.PRIOR
book = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
rows = [dict(r, _I=i) for i, r in enumerate(book) if not r.get("SUBCOL") and "轉置" not in str(r.get("VERIFY", ""))]
native, mine = m._native_verify_fin(rows, pdfdir), m.verify_fin(rows, pdfdir)
diff = [(a["_I"], a["_V"], b["_V"]) for a, b in zip(native, mine) if a["_V"] != b["_V"]]
print("0) 原樣 %d 筆 · core %s · v0114 %s · 判決不同 %d" % (len(rows), dict(Counter(r["_V"] for r in native)), dict(Counter(r["_V"] for r in mine)), len(diff)))
assert not diff, diff[:5]
random.seed(152)
aligned = [r for r in native if r["_V"] == "ALIGNED" and any(ch.isdigit() for ch in str(r["VALUE"]))]
OK = ("NILVAL", "PRESENT", "ALIGNED")
for tag, make in (("A) 冊值改成 n.a.", lambda r: "n.a."), ("B) 冊值改成別的數字", lambda r: "%.2f" % (float(str(r["VALUE"]).replace(",", "").strip("()%") or 0) * 1.37 + 3.11))):
    pick = random.sample(aligned, min(60, len(aligned)))
    ids = {r["_I"] for r in pick}
    mut = [dict(r, VALUE=make(r)) if r["_I"] in ids else r for r in rows]
    a_n = {r["_I"]: r["_V"] for r in m._native_verify_fin(mut, pdfdir) if r["_I"] in ids}
    a_m = {r["_I"]: r["_V"] for r in m.verify_fin(mut, pdfdir) if r["_I"] in ids}
    wrong = [i for i in ids if a_n[i] not in OK and a_m[i] in OK]
    print("%s %d 筆 · core %s · v0114 %s · v0114 誤放行 %d" % (tag, len(ids), dict(Counter(a_n.values())), dict(Counter(a_m.values())), len(wrong)))
    assert not wrong, wrong[:5]
# C) the desktop's character-box miss: the value's digits garbled in the char-box cache only
pickc = random.sample(aligned, min(60, len(aligned)))
idc = {r["_I"] for r in pickc}
saved = dict(C._PAGES)
for r in pickc:
    key = (str(pdfdir / r["FILENAME"]), int(r["PAGE"]))
    lines = C.page_lines(Path(key[0]), key[1])
    v = C.squash(str(r["VALUE"]))
    C._PAGES[key] = [(y, [(a, b, ("§" * len(t)) if C.squash(t) == v else t) for a, b, t in tk]) for y, tk in lines]
c_n = {r["_I"]: r for r in m._native_verify_fin(rows, pdfdir) if r["_I"] in idc}
c_m = {r["_I"]: r for r in m.verify_fin(rows, pdfdir) if r["_I"] in idc}
C._PAGES.clear(); C._PAGES.update(saved)
fails = [i for i, r in c_n.items() if r["_V"] == "FAIL"]
back = [i for i in fails if c_m[i]["_V"] in ("PRESENT", "NILVAL")]
print("C) 字元框讀法把值讀壞 %d 筆(桌機的樣子)· core %s · v0114 %s · core FAIL %d → v0114 依欄位對齊救回 %d(其餘對不齊 → 照樣 FAIL)" % (len(idc), dict(Counter(r["_V"] for r in c_n.values())), dict(Counter(r["_V"] for r in c_m.values())), len(fails), len(back)))
for i in back[:2]:
    print("   例:%s p%s %r %s=%r → %s · %s" % (c_m[i]["FILENAME"][:30], c_m[i]["PAGE"], c_m[i]["ITEM"], c_m[i]["PERIOD"], c_m[i]["VALUE"], c_m[i]["_V"], c_m[i]["_N"][:170]))
assert all(m._same_value(m.column_value(pdfdir / c_m[i]["FILENAME"], int(c_m[i]["PAGE"]), c_m[i]["ITEM"], c_m[i]["PERIOD"])[3], c_m[i]["VALUE"]) for i in back)
print("[PASS] v0114 回歸 + 變造")
