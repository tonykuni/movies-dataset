#!/bin/bash
# 全新沙盒:Handle-All auto(沒有收據 → full)→ 市場假資料 → Handle-All auto(收據 v0152 → verify)→ report
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=$S/v152; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
bash $W/setup152.sh > $W/setup152.log 2>&1 || { echo "setup failed" >> $W/ha152.rc; exit 1; }
bash $W/ha152.sh t152 f_auto_full
$S2/venv_vrn2/bin/python $S/v148/mk_market148.py "$W/t152/VIA/VIA_Reports/vrn2" > $W/mk_market152.log 2>&1
bash $W/ha152.sh t152 f_auto_verify
bash $W/ha152.sh t152 f_report VRN2_MODE=report
echo done-drive >> $W/ha152.rc
