"""VRN2_IndependentVerifier_v0114.py = structural copy of v0113 (the --shard children run this file) + a second reading for annual FAIL (column alignment)."""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v151/new/VRN2_IndependentVerifier_v0113.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('''"""Independent verifier v0113: v0112 + a second reading for BADITEM (v0112 kept byte-identical).
''', '''"""Independent verifier v0114: v0113 + a second reading for annual FAIL by column alignment (v0113 kept byte-identical).

v0114: desktop 2026-10-30 17:06 (RoundAll v0107 · FIN evidence): the only annual FAIL left — 260914_daiwa_aspeed.pdf PBR (x) 26E 'n.a.' "value
not on the page / cannot locate the item row or the period header" — is the character-box reader again: the page's own text reads header
"Year to 31 Dec 26E 27E 28E" and row "PBR (x) n.a. 29.2 16.8", so 26E is 'n.a.', exactly the book value. When the core says FAIL, v0114 reads the
page a second way (PDFium whole-page text, then pdfplumber text lines — each reader on its own), takes the nearest header line above the item row
that holds the period, and aligns the row's values with the header's periods by order (only when the counts are equal). The source value at the
period equal to the book value → empty marker: NILVAL · number: PRESENT (note says which reader, header and row). Different value or no
alignment → FAIL stays, with what the source holds there (a corrupted / shifted value is still caught).
''')
for a, b in (('"independent_v0113_execution"', '"independent_v0114_execution"'), ('"independent_v0113_financial_core"', '"independent_v0114_financial_core"'),
             ('"independent_v0113_source_reader"', '"independent_v0114_source_reader"'), ('VERSION = "VRN2_IndependentVerifier_v0113"', 'VERSION = "VRN2_IndependentVerifier_v0114"')):
    rep(a, b)
rep('''def verify_fin(rows, pdfdir, allrows=None):
    """v0113: v0105's verify_fin, then every BADITEM is read a second way (item_on_page); FAIL notes get the item's source line (verdict kept)."""
    res = _native_verify_fin(rows, pdfdir, allrows)
    for r in res:
        if r.get("_V") not in ("BADITEM", "FAIL"):
            continue
        pdf, pno = Path(pdfdir) / r["FILENAME"], int(r["PAGE"])
        found, line = item_on_page(pdf, pno, r.get("ITEM", ""))
        if r["_V"] == "FAIL":
            if found:
                r["_N"] = "%s · 第二種讀法的科目列「%s」" % (r["_N"], line)
            continue''', r'''_PER = re.compile(r"^(?:fy)?(?:(?:19|20)\d{2}[aefp]?|\d{2}[aefp])$", re.I)
_VALTOK = re.compile(r"^(?:\(?-?[\d,]*\.?\d+\)?%?|n\.?a\.?|n/a|nm|n\.m\.|-+|–|—)$", re.I)
_NILS = {"n.a", "na", "n/a", "nm", "n.m", "-", "--", "---", "–", "—"}
_READERS = {}


def reader_lines(pdf, pno):
    """v0114: the page's lines per reader (PDFium whole-page text · pdfplumber text lines) — kept apart so a header and a row come from one reader."""
    key = (str(pdf), pno)
    if key not in _READERS:
        out = {}
        try:
            doc = pdfium.PdfDocument(str(pdf))
            if 1 <= pno <= len(doc):
                out["pdfium"] = [nfk(l) for l in doc[pno - 1].get_textpage().get_text_range().replace("\r", "\n").split("\n") if l.strip()]
            doc.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            import pdfplumber
            with pdfplumber.open(str(pdf)) as d:
                if pno <= len(d.pages):
                    out["pdfplumber"] = [nfk(l) for l in (d.pages[pno - 1].extract_text() or "").split("\n") if l.strip()]
        except Exception:  # noqa: BLE001
            pass
        _READERS[key] = out
    return _READERS[key]


def _pkey(t):
    return (re.sub(r"\D", "", t)[-2:], re.sub(r"[^aefp]", "", t.lower()))


def _same_value(a, b):
    na, nb = re.sub(r"[\s,]", "", str(a).lower()).rstrip("."), re.sub(r"[\s,]", "", str(b).lower()).rstrip(".")
    if na in _NILS or nb in _NILS:
        return na in _NILS and nb in _NILS
    def num(x):
        neg = x.startswith("(") and x.endswith(")")
        try:
            v = float(x.strip("()%"))
        except ValueError:
            return None
        return -v if neg else v
    va, vb = num(na), num(nb)
    return va is not None and vb is not None and abs(va - vb) < 1e-9


def column_value(pdf, pno, item, period):
    """v0114: (reader, header line, row line, value at the period) by column order — nearest header above the item row holding the period,
    equal counts only; None when no reader aligns."""
    words = [w for w in re.findall(r"[a-z]+|\d+|[㐀-鿿]+", nfk(item).lower()) if len(w) >= 2][:3]
    want = _pkey(period)
    if not words or not want[0]:
        return None
    for how, lines in reader_lines(pdf, pno).items():
        head = None
        for line in lines:
            toks = line.split()
            pers = [t for t in toks if _PER.match(t)]
            if len(pers) >= 2 and any(_pkey(t) == want for t in pers):
                head = (line, pers)
                continue
            low = line.lower()
            if head and all(w in low for w in words):
                vals = [t for t in toks if _VALTOK.match(t)]
                idx = next((i for i, t in enumerate(head[1]) if _pkey(t) == want), None)
                if idx is not None and len(vals) == len(head[1]):
                    return how, head[0], line, vals[idx]
    return None


def verify_fin(rows, pdfdir, allrows=None):
    """v0113: v0105's verify_fin, then every BADITEM is read a second way (item_on_page); FAIL notes get the item's source line (verdict kept).
    v0114: a FAIL is aligned by column in the second reading — the source value at the period equals the book value → NILVAL (empty marker) /
    PRESENT (number); otherwise FAIL stays with what the source holds there."""
    res = _native_verify_fin(rows, pdfdir, allrows)
    for r in res:
        if r.get("_V") not in ("BADITEM", "FAIL"):
            continue
        pdf, pno = Path(pdfdir) / r["FILENAME"], int(r["PAGE"])
        found, line = item_on_page(pdf, pno, r.get("ITEM", ""))
        if r["_V"] == "FAIL":
            col = column_value(pdf, pno, r.get("ITEM", ""), r.get("PERIOD", ""))
            if col and _same_value(col[3], r.get("VALUE", "")):
                nil = re.sub(r"[\s,]", "", str(r.get("VALUE", "")).lower()).rstrip(".") in _NILS
                r["_V"] = "NILVAL" if nil else "PRESENT"
                r["_N"] = "第二種讀法依欄位對齊(%s):表頭「%s」· 科目列「%s」· %s 這一欄是 %r = 冊值%s · 原判:%s" % (
                    col[0], col[1][:90], col[2][:90], r.get("PERIOD"), col[3], "(空值記號 · 不算錯值)" if nil else "", r["_N"][:160])
            elif col:
                r["_N"] = "%s · 第二種讀法依欄位對齊(%s):%s 這一欄是 %r ≠ 冊值 %r(表頭「%s」· 科目列「%s」)" % (r["_N"], col[0], r.get("PERIOD"), col[3], r.get("VALUE"), col[1][:80], col[2][:80])
            elif found:
                r["_N"] = "%s · 第二種讀法的科目列「%s」" % (r["_N"], line)
            continue''')
rep('''    print("[PASS] v0113: BADITEM read a second way''', r'''    saved_rd = dict(_READERS)
    native = globals()["_native_verify_fin"]
    try:
        key = str(Path("t") / "daiwa.pdf")
        _READERS[(key, 1)] = {"pdfium": ["Daiwa Capital Markets", "Year to 31 Dec 26E 27E 28E", "EPS (TWD) 102.3 120.4 141.0", "PBR (x) n.a. 29.2 16.8", "Tel +886 2 2345 6789"]}
        _TEXT_LINES[(key, 1)] = _READERS[(key, 1)]["pdfium"]
        globals()["_native_verify_fin"] = lambda rows, pdfdir, allrows=None: [dict(x, _V="FAIL", _N="空值記號 %r · 定不出科目列 · 值不在該頁(驗證器讀法)" % x["VALUE"]) for x in rows]
        rows = [{"FILENAME": "daiwa.pdf", "PAGE": 1, "ITEM": "PBR (x)", "PERIOD": "26E", "VALUE": "n.a."},
                {"FILENAME": "daiwa.pdf", "PAGE": 1, "ITEM": "PBR (x)", "PERIOD": "27E", "VALUE": "29.2"},
                {"FILENAME": "daiwa.pdf", "PAGE": 1, "ITEM": "PBR (x)", "PERIOD": "27E", "VALUE": "n.a."},
                {"FILENAME": "daiwa.pdf", "PAGE": 1, "ITEM": "PBR (x)", "PERIOD": "28E", "VALUE": "29.2"},
                {"FILENAME": "daiwa.pdf", "PAGE": 1, "ITEM": "EPS (TWD)", "PERIOD": "28E", "VALUE": "141.0"},
                {"FILENAME": "daiwa.pdf", "PAGE": 1, "ITEM": "ROE (%)", "PERIOD": "26E", "VALUE": "n.a."}]
        got = [r["_V"] for r in verify_fin(rows, "t")]
        assert got == ["NILVAL", "PRESENT", "FAIL", "FAIL", "PRESENT", "FAIL"], got
        notes = verify_fin(rows[:3], "t")
        assert "26E 這一欄是 'n.a.' = 冊值" in notes[0]["_N"] and "27E 這一欄是 '29.2' ≠ 冊值 'n.a.'" in notes[2]["_N"], (notes[0]["_N"], notes[2]["_N"])
        assert _same_value("(1,234.5)", "-1234.5") and not _same_value("n.a.", "0") and _same_value("NA", "n.a.") and not _same_value("29.2", "16.8")
    finally:
        _READERS.clear(); _READERS.update(saved_rd)
        _TEXT_LINES.clear(); _TEXT_LINES.update(saved_lines)
        globals()["_native_verify_fin"] = native
    print("[PASS] v0114: annual FAIL aligned by column in the second reading — Daiwa aspeed PBR 26E 'n.a.' = source → NILVAL · number equal → PRESENT · a value moved to another column / a marker where the source has a number / no item row → FAIL stays")
    print("[PASS] v0113: BADITEM read a second way''')
assert "v0113_" not in s.replace("independent_v0113", "")
out = S / "v152/new/VRN2_IndependentVerifier_v0114.py"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("IndependentVerifier v0114 lines", s.count("\n"))
