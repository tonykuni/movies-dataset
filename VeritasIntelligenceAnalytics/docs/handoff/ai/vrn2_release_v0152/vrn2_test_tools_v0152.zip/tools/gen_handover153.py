"""VRN2_Handover_v0153.md:從 v0152 只增不減(v0152 已推上分支 · 不改)。數字來自 release152/VRN2_Release_v0152.json 的 results(finalize152 寫)。"""
import json
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v152")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0152.md").read_text(encoding="utf-8")
R = json.loads((W / "release152/VRN2_Release_v0152.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((W / "pkg152/VRN2_Runtime_v0152.json").read_text(encoding="utf-8"))["files"]}


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)


lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0151 + VRN2_RoundAll_v0104 · 2026-10-29(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0152 + VRN2_RoundAll_v0108 + VRN2_HandleAll_v0100 · 2026-10-30(v0151 + 操作員「GENERATE A PS CODE TO HANDLE ALL」→ "
            "IndependentVerifier v0114(年度 FAIL 依欄位對齊 · Daiwa aspeed PBR 26E n.a. = 原文)· RoundAll v0108(⑪b 只重跑獨立驗證 · 沿用前版收據)· "
            "PowerShell 7 一段碼 Handle-All v0100(自動選模式 · 取 RoundAll 核對 SHA-256 · 印收尾狀態);runtime v0151 的 187 個成員一個位元組都不動 · +1 個新檔;"
            "v0151 發行夾 / 一鍵 v0151 / 操作員 v0112 / 本地實測 v0101 這輪不升、逐位元不變)")
src = "\n".join(lines)
anchor = "> **桌機 2026-10-30 14:41(RoundAll v0105 · 3977 秒)**"
new_round = ("> **桌機 2026-10-30 17:06(RoundAll v0107 只重做報告 · 快速模式)**:① 用新夾 `VRN2_Closeout_v0151_20261030_133517`(原夾讀不到)· Combined 代號缺口 = GFHK Apple(TICKER `AAPL`)→ 資料源 · "
             "收尾 OPEN「VRN-2 1 · VCGC 3 · 人工 4 · 資料源 2」—— VRN-2 那 1 項 = ⑪ 年度數據 FAIL 證據(驗證器讀法 · 原文相符):`260914_daiwa_aspeed.pdf` 表頭「Year to 31 Dec 26E 27E 28E」· 科目列「PBR (x) n.a. 29.2 16.8」→ 26E 原文就是 n.a. = 冊值。操作員:「GENERATE A PS CODE TO HANDLE ALL」。\n"
             "> **本輪(v0152)**:① **IndependentVerifier v0114**(結構複本 · v0113 留著):核心判 FAIL 時用第二種讀法(PDFium 整頁文字 / pdfplumber 文字行 · 一次只用一種)取科目列上方最近、含該期的表頭,值與期別個數相等才依順序對齊 → "
             "該期原文 = 冊值:NILVAL(空值記號)/ PRESENT(數字);不同或對不齊照樣 FAIL(附那一欄的原文值)。容器整輪回歸 4905 筆與 v0113 完全相同;變造(冊值改成 n.a. · 換欄 · 亂碼)照樣 FAIL。"
             "② **RoundAll v0108**:新步驟 `verify`(⑪b 只重跑獨立驗證 · 套件 runtime 最新的驗證器只增不覆寫地放進 `functional modules\\VRN2` → 上一輪輸出冊重驗 → 收據 ⑪ 換成這次結果、先備份)· 這版收據還沒有就**沿用前版收據**(桌機只有 v0151 的)· 收據修正紀錄合併不覆蓋 · 自測 44 項。"
             "③ **Handle-All v0100**(`vrn2_release_v0152/VRN2_HandleAll_v0100.md` · PowerShell 7 一段碼 · 一行版 + 可讀版語法樹相同):工具 → 別的 VRN-2 在跑嗎 → 舊套件夾讀不讀得到(答 y 才以系統管理員身分 icacls /reset)→ 模式 auto / full / verify / report → 取 RoundAll v0108 核對 SHA-256 → 跑 → 印收尾狀態與各負責方待辦。"
             "④ **沙盒**:%s\n") % res.get("handover_line", "見 VRN2_Verification_v0152.md")
assert src.count(anchor) == 1
src = src.replace(anchor, new_round + anchor, 1)
anchor = "| **VRN2_RoundAll_v0107.py**(發行夾 · 一支入口 · 不在套件內)| **v0107** | `vrn2_release_v0151` | `cbaec6a53e35` | **新**("
rows = ("| **VRN2_HandleAll_v0100.md**(發行夾 · PowerShell 7 一段碼 · 不是 .ps1)| **v0100** | `vrn2_release_v0152` | 一行版 `%s` | **新**(自動選模式 · 取 RoundAll v0108 核對 SHA-256 · 舊套件夾權限可選擇還原 · 印收尾狀態)|\n"
        "| **VRN2_RoundAll_v0108.py**(發行夾 · 一支入口 · 不在套件內)| **v0108** | `vrn2_release_v0152` | `%s` | **新**(套件 v0152 · ⑪b 只重跑獨立驗證 · 沿用前版收據 · 自測 44 項)|\n"
        "| ActivateVRN-2_v0152.py(套件 · 底座 v0136)| **v0152** | 見發行清單 | `%s` | **新**(收據 v0152 · 自測多一段 v0152 · 步驟不變)|\n"
        "| **VRN2_IndependentVerifier** | **v0114**(結構複本 · v0113 留著)| runtime v0152 | `%s` | **新**(年度 FAIL 依欄位對齊 · 值不同 / 對不齊照樣 FAIL)|\n") % (
    R["handleall"]["line_sha256"][:12], R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], rt["VRN2_IndependentVerifier_v0114.py"])
assert src.count(anchor) == 1
src = src.replace(anchor, rows + anchor.replace("| **新**(", "| 被 v0108 取代(沒有 ⑪b · 套件 v0151)· ", 1), 1)
once("## 7. 本輪(v0150 → v0151 + VRN2_RoundAll_v0104 · 收尾輪 · 操作員「解決剩餘系統問題 HTML U/I CLOSE OUT」)",
     "## 7. 本輪(v0151 → v0152 + VRN2_RoundAll_v0108 + VRN2_HandleAll_v0100 · 操作員「GENERATE A PS CODE TO HANDLE ALL」)\n\n| # | 剩下的 | 根因 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | ⑪ 年度數據 FAIL 1(Daiwa aspeed PBR (x) 26E 冊值 n.a.)| 字元框讀法讀不出該頁科目列 / 表頭;原文 26E 就是 n.a. | IndependentVerifier v0114:FAIL 用第二種讀法依欄位對齊(同一讀法 · 個數相等才對)| 自測 · 整輪 4905 筆與 v0113 相同 · 變造照樣 FAIL |\n"
     "| b | 改驗證器要重跑整輪 66 分鐘 | RoundAll 沒有單獨重驗的步驟 | RoundAll v0108 `verify`(⑪b)· 沿用前版收據 | 自測 ㊵ ㊶ ㊷ · 沙盒桌機情境 |\n"
     "| c | 每次要記好幾行指令 / 環境變數 | — | Handle-All v0100(PowerShell 7 一段碼 · auto 選模式)| 沙盒 auto(verify / full)· report · 竄改 · 錯模式 · 非 git 倉 · 讀不到的舊夾 |\n"
     "| — | MOPS DENY(VCGC)· MQ-1560 OCR 4 點 / 年度缺項 3 份(人工)· Apple 非台股 / 報告日前沒有日資料(資料源)· 舊套件夾 ACL | VCGC 決定 / 要人看原文 / 外部來源 / 以前用系統管理員身分跑過 | **沒修**(收尾頁分給負責方 · ACL 答 y 才動)| — |\n\n---\n\n"
     "## 7.0o 前一輪(v0150 → v0151 + VRN2_RoundAll_v0104 · 收尾輪 · 操作員「解決剩餘系統問題 HTML U/I CLOSE OUT」)")
once("| 0 | **(v0151 · 2026-10-30 14:41 後)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0151/VRN2_RoundAll_v0107.md` 的 **PowerShell 7 原生一行**",
     "| 0 | **(v0152 · 2026-10-30 17:06 後)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0152/VRN2_HandleAll_v0100.md` 的**那一行**(auto → verify:套件 v0152 · ⑪b 用 v0114 重驗 · 收尾頁)· 收尾頁「VRN-2 要修」應為 0;不是 0 → 貼回包 | 貼回 |\n"
     "| 0 | **(v0151 · 2026-10-30 14:41 後)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0151/VRN2_RoundAll_v0107.md` 的 **PowerShell 7 原生一行**")
once("目前(桌機 19:00 那輪試算 · v0151 還沒在桌機跑):",
     "**v0152(2026-10-30)**:桌機 17:06 v0107 快速模式 = OPEN(VRN-2 1 · VCGC 3 · 人工 4 · 資料源 2);VRN-2 那 1 項由 v0114 處理 → 預期 BLOCKED(VRN-2 0),以桌機跑 Handle-All 後的收尾頁為準。\n\n"
     "目前(桌機 19:00 那輪試算 · v0151 還沒在桌機跑):")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0152)** **驗證器說 FAIL 也要被驗**:FAIL 證據顯示原文 = 冊值時,是驗證器讀法的問題 → 修驗證器(出新版號 · 結構複本),不是改輸出;放寬一定配變造(冊值改 n.a. · 換欄 · 亂碼)確認還是 FAIL。\n"
     "- **(v0152)** **只改了驗證器就不要叫使用者重跑整輪**:RoundAll `verify`(⑪b)用上一輪輸出冊重驗;收據沒有這版的就沿用前版的,改之前先備份、修正紀錄合併。\n"
     "- **(v0152)** **給 PowerShell 7 的一段碼**:包在 `& { … }`、錯了 `return` 不 `exit`(視窗不關)· 一行版由可讀版機械合併(上一行 `{` 結尾或下一行 `}` 開頭用空白,其他用 `; `)· `} else {` / `} catch {` 要同一行 · 兩版用 PowerShell 剖析器比對詞序列 · 中文緊接變數時寫 `$($x)`。\n"
     "- **(v0152)** **權限修復要使用者同意**:讀不到的舊夾只列出來、不擋;答 y 才跳 UAC 跑 `icacls /reset`(還原成繼承 · 不刪檔)。\n\n")
(REPO / "VRN2_Handover_v0153.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0153 lines", src.count("\n"))
