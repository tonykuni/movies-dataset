#!/bin/bash
# v0152 放進倉:docs/handoff/ai/vrn2_release_v0152/ + VRN2_Handover_v0153.md(固定時間戳 · 冪等)· .ps1 只在 zip 裡 · 不放桌機貼回內容
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v152
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0152; mkdir -p $D
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v152")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0152")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 30, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(p.name, p) for p in sorted(W.glob("ha152_*.log"))] + [(n, W / n) for n in ("ha152.rc", "rall108_selftest.log", "iv114_selftest.log", "ActivateVRN-2_v0152_selftest.log", "ActivateVRN-2_v0152_selftest_iso.log",
        "regress114.log", "pscheck152.log", "setup152.log", "t152_setup.log", "mk_market152.log", "drive152.log", "drived152.log", "d_tamper_file.txt")]
logs += [("regress/" + n, W / "regress" / n) for n in ("run_0113.log", "run_0114.log", "rep_0113.json.digest.txt", "rep_0114.json.digest.txt")]
for box in ("t152", "t152d"):
    v2 = W / box / "VIA/VIA_Reports/vrn2"
    for n in ("VRN2_Closeout_v0151.json", "VRN2_Closeout_v0151.before_roundall.json", "VRN2_Closeout_v0152.json", "VRN2_Closeout_v0152.before_roundall.json", "VRN2_RoundAll_latest.json", "VRN2_CloseoutUI_latest.html", "VRN2_CloseoutUI_latest.json"):
        logs.append((box + "/" + n, v2 / n))
z(D / "logs_v0152.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh"))]
tools += [("tools/ps7/" + q.name, q) for q in sorted((W / "ps7").glob("*")) if q.suffix in (".py", ".ps1", ".txt") and not q.name.endswith(".sig")]
tools += [("release/" + n, W / "release152" / n) for n in ("handleall_src.ps1", "handleall_line.txt", "boot_roundall.ps1", "oneline_roundall.txt", "oneline_roundall_pwsh.txt", "oneline_roundall_ps7.txt")]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py"))]
z(D / "vrn2_test_tools_v0152.zip", tools)
for n in ("VRN2_Closeout_v0152.zip", "VRN2_Release_v0152.json", "VRN2_RoundAll_v0108.py", "VRN2_RoundAll_v0108.md", "VRN2_HandleAll_v0100.md", "VRN2_Verification_v0152.md"):
    shutil.copy(W / "release152" / n, D / n)
print("staged")
PY
ls -la $D | awk '{print $5, $9}'
