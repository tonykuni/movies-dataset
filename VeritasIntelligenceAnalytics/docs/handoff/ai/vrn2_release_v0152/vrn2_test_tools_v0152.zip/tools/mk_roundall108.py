"""VRN2_RoundAll_v0108.py = v0107 + 套件 v0152(驗證器 v0114)+ ⑪b 只重跑獨立驗證(--verify / --only …,verify,…)· 操作員 2026-10-30「GENERATE A PS CODE TO HANDLE ALL」。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v151/new/VRN2_RoundAll_v0107.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0107'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0107 — ', '"""VRN2_RoundAll v0108 — ', 1)
at = doc.index("v0107(同日")
doc = doc[:at] + r'''v0108(桌機 2026-10-30 17:06 · v0107 只重做報告:收尾 OPEN「VRN-2 1 項」= ⑪ 年度數據 FAIL 證據(驗證器讀法 · 原文相符)· 操作員「GENERATE A PS CODE TO HANDLE ALL」):
  · 套件 v0152(啟動器 v0152 · runtime v0152 = v0151 的 187 個成員不動 + IndependentVerifier v0114:年度 FAIL 用第二種讀法依欄位對齊 ——
    Daiwa aspeed PBR 26E 原文「Year to 31 Dec 26E 27E 28E」/「PBR (x) n.a. 29.2 16.8」→ 26E 是 n.a. = 冊值 → NILVAL;值不同 / 對不齊照樣 FAIL)。
  · ⑪b 只重跑獨立驗證(新步驟 verify · 只在 --verify 或 --only 有 verify 時跑):從套件的 runtime zip 取最新的 IndependentVerifier(核對清單雜湊)
    → 只增不覆寫地放進 functional modules\\VRN2(同名不同內容 → 紅、不覆寫;它 load 的檔缺了也一起補)→ 照啟動器 ⑪ 的方式跑(輸出冊 · scope_in · 寫回 U/I)
    → 收據的 ⑪ 換成這次的結果(先備份)。整輪 66 分鐘 → 只驗約 11 分鐘。
  · ⑥ ⑪ 驗證器版本:v0114 以前 → 黃。
  · 給 PowerShell 7 的「Handle-All」一段碼用(VRN2_HandleAll_v0100.md):full / verify / report 三種模式。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0107.py", "用法:python VRN2_RoundAll_v0108.py")
doc = doc.replace("[--only package,preflight,selftest,run,fix,report,closeout,pasteback]", "[--only package,preflight,selftest,run,fix,verify,report,closeout,pasteback] [--verify]")
doc = doc.replace("Downloads\\\\VRN2_Closeout_v0151 的 zip", "Downloads\\\\VRN2_Closeout_v0152 的 zip").replace("ActivateVRN-2_v0151(預設不上船", "ActivateVRN-2_v0152(預設不上船").replace("這些都在 VRN-2 套件 v0151 裡", "這些都在 VRN-2 套件 v0152 裡")
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
body = body.replace("v0151", "v0152")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0107"', 'VERSION = "v0108"')
rep('''        new_enough = bool(num) and int(num.group(1)) >= 113                # v0104:v0113 起 BADITEM 先用第二種讀法找科目''',
    '''        new_enough = bool(num) and int(num.group(1)) >= 114                # v0108:v0114 起年度 FAIL 依欄位對齊(v0113 起 BADITEM 先用第二種讀法)''')
rep('''還是舊驗證器(v0113 以前:BADITEM 只用字元框讀法)''', '''還是舊驗證器(v0114 以前:年度 FAIL / BADITEM 只用字元框讀法)''')
rep('STEPS = ("package", "preflight", "selftest", "run", "fix", "report", "closeout", "pasteback")', 'STEPS = ("package", "preflight", "selftest", "run", "fix", "verify", "report", "closeout", "pasteback")')
rep('''    ap.add_argument("--no-open", action="store_true", help="不開瀏覽器")''', '''    ap.add_argument("--no-open", action="store_true", help="不開瀏覽器")
    ap.add_argument("--verify", action="store_true", help="v0108 也跑 ⑪b 只重跑獨立驗證(預設不跑:整輪時啟動器 ⑪ 已經驗過)")''')
rep('''    want = {s: ((not only or s in only) and not getattr(args, "skip_" + s, False)) for s in STEPS}''', '''    want = {s: ((not only or s in only) and not getattr(args, "skip_" + s, False)) for s in STEPS}
    want["verify"] = ("verify" in only) or bool(args.verify)                 # v0108 ⑪b 只在要求時跑''')
rep('''    report = {}
    if want["report"] and root:''', '''    if want["verify"] and root:
        guarded("⑪b 重跑獨立驗證", step_verify, root, pkg, vpy)
    report = {}
    if want["report"] and root:''')
rep('''# ===== 9. ⑥ 除錯報告 =====''', r'''# ===== 8b. ⑪b 只重跑獨立驗證(v0108)=====
def install_runtime_member(pkg, root, name: str) -> tuple:
    """套件 runtime zip 的一個成員(核對清單雜湊)→ 只增不覆寫地放進 functional modules\\VRN2。回 (路徑 | None, 說明)。"""
    rz, rm = Path(pkg) / RUNTIME_ZIP, Path(pkg) / RUNTIME_MANIFEST
    want_sha = {e["path"]: e["sha256"] for e in (jread(rm, {}) or {}).get("files") or []}
    with zipfile.ZipFile(rz) as z:
        data = z.read(name)
    got = hashlib.sha256(data).hexdigest()
    if want_sha.get(name) != got:
        return None, "%s 與 runtime 清單雜湊不符 · 不用" % name
    dest = Path(root) / "functional modules" / "VRN2" / name
    if dest.is_file():
        return (dest, "已在") if sha256_file(dest) == got else (None, "%s 已在但內容不同(同名不同內容 · 不覆寫)" % name)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return dest, "補放"


def step_verify(root, pkg, vpy) -> dict:
    """v0108 ⑪b:只重跑獨立驗證 —— 套件 runtime 最新的 IndependentVerifier(與它 load 的檔)只增不覆寫地放進 functional modules\\VRN2 →
    照啟動器 ⑪ 的方式跑(輸出冊 · scope_in · 寫回 U/I · 新報告)→ 收據 ⑪ 換成這次結果(先備份)。"""
    v2 = Path(root) / "VIA_Reports" / "vrn2"
    if not pkg or not (Path(pkg) / RUNTIME_ZIP).is_file():
        say("YELLOW", "⑪b 重跑獨立驗證", "沒有套件 runtime(%s)· 不驗" % (Path(pkg or ".") / RUNTIME_ZIP), "用 --only package,verify,report,closeout,pasteback(先取套件)")
        return {}
    with zipfile.ZipFile(Path(pkg) / RUNTIME_ZIP) as z:
        ivs = sorted(n for n in z.namelist() if re.fullmatch(r"VRN2_IndependentVerifier_v\d{4}\.py", n))
        newest = ivs[-1] if ivs else ""
        code = z.read(newest).decode("utf-8") if newest else ""
    if not newest:
        say("RED", "⑪b 重跑獨立驗證", "套件 runtime 裡沒有 IndependentVerifier")
        return {}
    notes = []
    for name in [newest] + re.findall(r'load\("[^"]+",\s*"([^"]+\.py)"\)', code):
        got, why = install_runtime_member(pkg, root, name)
        if got is None:
            say("RED", "⑪b 重跑獨立驗證", why, "同名不同內容的檔不覆寫(只增)→ 貼回包給 AI")
            return {}
        if why == "補放":
            notes.append(name)
    od, scope = v2 / "output", v2 / "scope_in"
    if not (od / "VRN2_FinancialData_latest.json").is_file() or not scope.is_dir():
        say("YELLOW", "⑪b 重跑獨立驗證", "沒有上一輪的輸出冊或 scope_in(%s)· 不驗" % od, "先跑一次整輪")
        return {}
    vd = v2 / "verify_independent"
    vd.mkdir(parents=True, exist_ok=True)
    rep_path = vd / ("VRN2_IndependentVerify_%s.json" % stamp())
    fm = Path(root) / "functional modules" / "VRN2"
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    info("⑪b %s 重跑(%s)· 輸出冊 %s · 原檔 %s%s" % (newest, vpy, od, scope, (" · 補放 " + "、".join(notes)) if notes else ""))
    t0 = time.time()
    rc, lines = run_stream([vpy, "-W", "ignore", str(fm / newest), str(od), str(scope), str(rep_path), "--ui", str(v2 / "VRN2_UI_latest.html")], cwd=fm, env=env,
                           timeout=int(os.environ.get("VIA_VRN2_VERIFY_WAIT") or 3600), prefix="    ")
    got = jread(rep_path, {}) or {}
    vl = [l.strip() for l in lines if l.startswith("[驗證]")]
    cnt = " · ".join(l.split("]", 1)[1].strip() for l in vl if any(k in l for k in ("基本資料", "一標題四重點", "年度數據")))[:400]
    if rc not in (0, 1) or not got:
        say("RED", "⑪b 重跑獨立驗證", "%s 沒跑完 rc %s · %s" % (newest, rc, " | ".join(lines[-3:])[:300]), "看上面幾行;貼回包給 AI")
        return {}
    lamp = "GREEN" if rc == 0 else "YELLOW"
    detail = "%s · %s · %s · 報告 %s · %.0f 秒" % (newest.replace(".py", ""), "錯值 0" if rc == 0 else "有待核對(先看原文再判 · 驗證器也要被驗)", cnt, rep_path.name, time.time() - t0)
    say(lamp, "⑪b 重跑獨立驗證", detail)
    rpath = v2 / RECEIPT
    receipt = jread(rpath, {}) or {}
    if receipt.get("steps"):
        _patch_receipt(rpath, receipt, {"⑪": (lamp, detail)})
    return {"rc": rc, "report": str(rep_path), "version": got.get("version")}


# ===== 9. ⑥ 除錯報告 =====''')
# v0108 收據沿用前版(桌機只有 v0151 的收據時,只重跑 ⑪b / 只重做報告不該變成「沒有收據」)
rep('''def _patch_receipt(rpath: Path, receipt: dict, updates: dict) -> None:''', '''def receipt_path(v2) -> Path:
    """v0108:這版啟動器的收據;還沒有(這輪只重跑 ⑪b / 只重做報告,啟動器 v0152 還沒跑過)→ 最新的前版收據 VRN2_Closeout_v0NNN.json(不含 .before_roundall)。"""
    p = Path(v2) / RECEIPT
    if p.is_file() or not Path(v2).is_dir():
        return p
    olds = sorted(q for q in Path(v2).glob("VRN2_Closeout_v0[0-9][0-9][0-9].json") if q.name < RECEIPT)
    return olds[-1] if olds else p


def _patch_receipt(rpath: Path, receipt: dict, updates: dict) -> None:''')
rep('''    rpath = v2 / RECEIPT
    receipt = jread(rpath, {}) or {}
    if not receipt:
        say("GRAY", "⑤ 自動修", "沒有收尾收據 %s(啟動器沒跑完)· 不修" % RECEIPT)''', '''    rpath = receipt_path(v2)
    receipt = jread(rpath, {}) or {}
    if not receipt:
        say("GRAY", "⑤ 自動修", "沒有收尾收據 %s(啟動器沒跑完)· 不修" % RECEIPT)''')
rep('''    rpath = v2 / RECEIPT
    receipt = jread(rpath, {}) or {}
    if receipt.get("steps"):
        _patch_receipt(rpath, receipt, {"⑪": (lamp, detail)})''', '''    rpath = receipt_path(v2)
    receipt = jread(rpath, {}) or {}
    if receipt.get("steps"):
        _patch_receipt(rpath, receipt, {"⑪": (lamp, detail)})''')
rep('''    receipt = jread(v2 / RECEIPT, {}) or {}
    if not receipt:
        f("RED", "收尾收據", "沒有 %s" % (v2 / RECEIPT), "啟動器沒跑完:看 ④ 的最後幾行")
        return rep''', '''    rp = receipt_path(v2)
    receipt = jread(rp, {}) or {}
    if not receipt:
        f("RED", "收尾收據", "沒有 %s" % (v2 / RECEIPT), "啟動器沒跑完:看 ④ 的最後幾行")
        return rep''')
rep('''(" · RoundAll 補修 %d 步(rc 不改 · 原收據 %s.before_roundall.json)" % (len((receipt.get("roundall") or {}).get("fixed") or {}), Path(RECEIPT).stem)) if receipt.get("roundall") else ""))''',
    '''(" · RoundAll 補修 %d 步(rc 不改 · 原收據 %s.before_roundall.json)" % (len((receipt.get("roundall") or {}).get("fixed") or {}), rp.stem)) if receipt.get("roundall") else "")
      + ("" if rp.name == RECEIPT else " · 沿用前版收據 %s(這輪沒跑啟動器 %s)" % (rp.name, Path(RECEIPT).stem.split("_")[-1])))''')
rep('''    receipt = jread(v2 / RECEIPT, {}) or {}
    fpick = (receipt.get("market") or {}).get("fetch_python")''', '''    receipt = jread(receipt_path(v2), {}) or {}
    fpick = (receipt.get("market") or {}).get("fetch_python")''')
rep('''("啟動器收尾收據", v2 / RECEIPT),''', '''("啟動器收尾收據", receipt_path(v2)),''')
rep('''            for rel in PASTE_FILES:
                p = v2 / rel''', '''            rp = receipt_path(v2)
            extra = () if rp.name == RECEIPT else (rp.name, rp.stem + ".before_roundall.json")   # v0108 沿用的前版收據也包
            for rel in PASTE_FILES + extra:
                p = v2 / rel''')
rep('''    receipt["roundall"] = {"version": "%s %s" % (NAME, VERSION), "at": _dt.datetime.now().isoformat(timespec="seconds"), "fixed": {k: {"lamp": v[0], "detail": v[1]} for k, v in updates.items()}}''',
    '''    fixed = dict((receipt.get("roundall") or {}).get("fixed") or {})       # v0108 合併:⑪b 不蓋掉之前 ⑤ 自動修的紀錄
    fixed.update({k: {"lamp": v[0], "detail": v[1]} for k, v in updates.items()})
    receipt["roundall"] = {"version": "%s %s" % (NAME, VERSION), "at": _dt.datetime.now().isoformat(timespec="seconds"), "fixed": fixed}''')
# 自測 ㊵ ㊶
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''', r'''        # ㊵ ㊶ v0108 ⑪b
        vroot = td / "vroot"
        (vroot / "functional modules" / "VRN2").mkdir(parents=True)
        (vroot / "supportive modules").mkdir(parents=True)
        vv2 = vroot / "VIA_Reports" / "vrn2"
        (vv2 / "output").mkdir(parents=True)
        (vv2 / "scope_in").mkdir(parents=True)
        (vv2 / "output" / "VRN2_FinancialData_latest.json").write_text("[]", encoding="utf-8")
        (vv2 / RECEIPT).write_text(json.dumps({"version": "x", "rc": 2, "steps": [{"step": "⑪ 獨立驗证", "lamp": "YELLOW", "detail": "有待核對 · FAIL 1"}, {"step": "⑪ 獨立驗證(背景 · 只讀)", "lamp": "YELLOW", "detail": "有待核對 · FAIL 1"}]}, ensure_ascii=False), encoding="utf-8")
        fake = ('import json, sys\nfrom pathlib import Path\nB = load("x", "VRN2_Dep_v0100.py") if False else None\n'
                'od, sc, rp = sys.argv[1:4]\nprint("[驗證] 基本資料 1 份 · 欄位檢查 {\'PASS\': 3}")\nprint("[驗證] 年度數據 2 筆 · {\'ALIGNED\': 1, \'NILVAL\': 1}")\n'
                'Path(rp).write_text(json.dumps({"version": "VRN2_IndependentVerifier_v0999", "fin_counts": {"ALIGNED": 1, "NILVAL": 1}}), encoding="utf-8")\nsys.exit(0)\n')
        fake = fake.replace('load("x", "VRN2_Dep_v0100.py") if False else None', 'None  # load("x", "VRN2_Dep_v0100.py")')
        members = {"VRN2_IndependentVerifier_v0998.py": "print('old')\n", "VRN2_IndependentVerifier_v0999.py": fake, "VRN2_Dep_v0100.py": "X = 1\n"}
        vpkg = td / "vpkg"
        vpkg.mkdir()
        with zipfile.ZipFile(vpkg / RUNTIME_ZIP, "w") as z:
            for n_, t_ in members.items():
                z.writestr(n_, t_)
        (vpkg / RUNTIME_MANIFEST).write_text(json.dumps({"files": [{"path": n_, "sha256": hashlib.sha256(t_.encode("utf-8")).hexdigest()} for n_, t_ in members.items()]}), encoding="utf-8")
        RESULTS.clear()
        sys.stdout = io.StringIO()
        try:
            out_v = step_verify(vroot, vpkg, sys.executable)
        finally:
            sys.stdout = sys_stdout
        rec_v = jread(vv2 / RECEIPT, {})
        fmv = vroot / "functional modules" / "VRN2"
        chk("㊵ ⑪b 只重跑獨立驗證:套件 runtime 最新的驗證器(v0999)+ 它 load 的檔補放進 functional modules\\VRN2(核對清單雜湊)→ 照 ⑪ 的方式跑 → 綠 · 收據 ⑪ 換成這次結果(先備份)",
            out_v.get("rc") == 0 and (fmv / "VRN2_IndependentVerifier_v0999.py").is_file() and (fmv / "VRN2_Dep_v0100.py").is_file() and not (fmv / "VRN2_IndependentVerifier_v0998.py").exists()
            and RESULTS[-1]["lamp"] == "GREEN" and "NILVAL" in RESULTS[-1]["detail"] and rec_v["steps"][1]["detail"].startswith("RoundAll 修正後") and (vv2 / (Path(RECEIPT).stem + ".before_roundall.json")).is_file())
        (fmv / "VRN2_IndependentVerifier_v0999.py").write_text("tampered\n", encoding="utf-8")
        RESULTS.clear()
        sys.stdout = io.StringIO()
        try:
            out_x = step_verify(vroot, vpkg, sys.executable)
        finally:
            sys.stdout = sys_stdout
        a1 = parse_args(["--only", "package,verify,report"])
        chk("㊶ ⑪b:同名不同內容不覆寫(紅 · 原檔留著)· --only 有 verify / --verify 才跑(整輪預設不跑,啟動器 ⑪ 已經驗過)",
            out_x == {} and RESULTS[-1]["lamp"] == "RED" and "不覆寫" in RESULTS[-1]["detail"] and (fmv / "VRN2_IndependentVerifier_v0999.py").read_text(encoding="utf-8") == "tampered\n"
            and "verify" in STEPS and a1.only == "package,verify,report" and parse_args(["--verify"]).verify and not parse_args([]).verify)
        # ㊷ v0108 沿用前版收據
        wroot = td / "wroot"
        (wroot / "functional modules" / "VRN2").mkdir(parents=True)
        wv2 = wroot / "VIA_Reports" / "vrn2"
        (wv2 / "output").mkdir(parents=True)
        (wv2 / "scope_in").mkdir(parents=True)
        (wv2 / "output" / "VRN2_FinancialData_latest.json").write_text("[]", encoding="utf-8")
        old_name = "VRN2_Closeout_v01" + "51.json"
        (wv2 / "VRN2_Closeout_v0150.json").write_text(json.dumps({"version": "ActivateVRN-2 v0150", "rc": 2, "steps": []}), encoding="utf-8")
        (wv2 / old_name).write_text(json.dumps({"version": "ActivateVRN-2 v01" + "51", "rc": 2, "elapsed_s": 3900, "passes": [{}], "steps": [{"step": "⑪ 獨立驗證", "lamp": "YELLOW", "detail": "有待核對 · FAIL 1"}],
                                                "roundall": {"version": "VRN2_RoundAll v0107", "fixed": {"⑬": {"lamp": "YELLOW", "detail": "pyarrow"}}}}, ensure_ascii=False), encoding="utf-8")
        (wv2 / (Path(old_name).stem + ".before_roundall.json")).write_text("{}", encoding="utf-8")
        pick1 = receipt_path(wv2)
        RESULTS.clear()
        sys.stdout = io.StringIO()
        try:
            out_w = step_verify(wroot, vpkg, sys.executable)
            diagnose(wroot, sys.executable)
        finally:
            sys.stdout = sys_stdout
        rec_w = jread(wv2 / old_name, {})
        rline = [r for r in RESULTS if r["step"] == "⑥ 收尾收據"]
        zw = td / "w_paste.zip"
        sys.stdout = io.StringIO()
        try:
            step_pasteback(wroot, td / "no_transcript.txt", zw)
        finally:
            sys.stdout = sys_stdout
        names_w = zipfile.ZipFile(zw).namelist() if zw.is_file() else []
        (wv2 / RECEIPT).write_text(json.dumps({"version": "now", "rc": 0, "steps": []}), encoding="utf-8")
        chk("㊷ 這版收據還沒有(桌機只跑過啟動器 v0151)→ 沿用最新的前版收據(不挑 .before_roundall · 不挑更舊的)· ⑪b 改它的 ⑪(之前 ⑤ 修過的紀錄留著)· 除錯報告「收尾收據」不算紅 · 貼回包有它;有這版收據就用這版",
            pick1.name == old_name and out_w.get("rc") == 0 and rec_w["steps"][0]["detail"].startswith("RoundAll 修正後") and sorted(rec_w["roundall"]["fixed"]) == ["⑪", "⑬"]
            and (not rline or (rline[-1]["lamp"] != "RED" and "沿用前版收據 " + old_name in rline[-1]["detail"]))
            and "vrn2/" + old_name in names_w and "vrn2/" + Path(old_name).stem + ".before_roundall.json" in names_w and receipt_path(wv2).name == RECEIPT and bool(rline))
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0107.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0108.py"').replace('"VRN2_RoundAll_v0107.py" in html_', '"VRN2_RoundAll_v0108.py" in html_')
s = s.replace('chk("⑰ 除錯:⑥f 共識閘 FAIL 列(只列 status FAIL:6933 FACTSET_TARGET)· ⑪ 驗證器版本 v0113 = 綠(v0104 起 v0113 以前算舊)"', 'chk("⑰ 除錯:⑥f 共識閘 FAIL 列(只列 status FAIL:6933 FACTSET_TARGET)· ⑪ 驗證器版本 v0114 = 綠(v0108 起 v0114 以前算舊)"')
s = s.replace('''(vi / "VRN2_IndependentVerify_20261029_000000.json").write_text(json.dumps({"version": "VRN2_IndependentVerifier_v0113",''', '''(vi / "VRN2_IndependentVerify_20261029_000000.json").write_text(json.dumps({"version": "VRN2_IndependentVerifier_v0114",''')
(S / "v152/new/VRN2_RoundAll_v0108.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0108 lines", s.count("\n"))
