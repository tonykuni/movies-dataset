"""ActivateVRN-2_v0152.py = v0151 + ⑪ IndependentVerifier v0114(runtime 最新 · 年度 FAIL 依欄位對齊)· 操作員 2026-10-30「GENERATE A PS CODE TO HANDLE ALL」。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v151/new/ActivateVRN-2_v0151.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0151: v0150 entry + the close-out round (operator 2026-10-29: "solve the remaining system issues · HTML U/I · CLOSE OUT").',
    '"""VRN-2 v0152: v0151 entry + the desktop runs of 2026-10-30 (RoundAll v0105 / v0107 · operator: "GENERATE A PS CODE TO HANDLE ALL").\n\n'
    ' - step 11 VRN2_IndependentVerifier_v0114 (latest in the runtime): the only annual FAIL left on the desktop (260914_daiwa_aspeed.pdf PBR (x)\n'
    '   26E \'n.a.\') was the character-box reader again — the page reads header "Year to 31 Dec 26E 27E 28E" and row "PBR (x) n.a. 29.2 16.8", so\n'
    '   the book value is right. A FAIL is now aligned by column in the second reading (one reader at a time, equal counts only): source value at\n'
    '   the period = book value → NILVAL (empty marker) / PRESENT (number); a different value or no alignment keeps FAIL.\n'
    ' - nothing else changes how steps run; VRN2_RoundAll_v0108 and the PowerShell 7 "handle all" code drive this package.\n'
    ' Runtime v0152 = runtime v0151 (187 members byte-identical) + VRN2_IndependentVerifier_v0114.\n\n'
    'v0151: v0150 entry + the close-out round (operator 2026-10-29: "solve the remaining system issues · HTML U/I · CLOSE OUT").')
rep('VERSION = "ActivateVRN-2 v0151"', 'VERSION = "ActivateVRN-2 v0152"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0151.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0152.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0151.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0152.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0151.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0152.json"')
rep('launcher = root / "package" / "ActivateVRN-2_v0151.py"', 'launcher = root / "package" / "ActivateVRN-2_v0152.py"')
rep('return lamp, detail + " · launcher v0151"', 'return lamp, detail + " · launcher v0152"')
rep('print("NEXT: [%s] VRN-2 v0151 · rc %s', 'print("NEXT: [%s] VRN-2 v0152 · rc %s')
rep('''    verifier = selftest_source("VRN2_IndependentVerifier_v0113.py").read_text(encoding="utf-8")''', r'''    v114 = selftest_source("VRN2_IndependentVerifier_v0114.py").read_text(encoding="utf-8")
    assert 'VERSION = "VRN2_IndependentVerifier_v0114"' in v114 and "def column_value(" in v114 and "def reader_lines(" in v114 and "PRIOR.verify_fin = verify_fin" in v114
    assert 'PRIOR = load("independent_v0114_financial_core", "VRN2_IndependentVerifier_v0105.py")' in v114 and 'if sys.argv[1:2] == ["--shard"]:' in v114
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            ivs2 = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN2_IndependentVerifier_v\d{4}\.py", n))
        assert ivs2[-1] == "VRN2_IndependentVerifier_v0114.py" and "VRN2_IndependentVerifier_v0113.py" in ivs2, ivs2[-3:]
    print("[PASS] v0152: runtime's newest IndependentVerifier = v0114 (annual FAIL aligned by column in the second reading · structural copy, its own --shard) · v0113 kept")
    verifier = selftest_source("VRN2_IndependentVerifier_v0113.py").read_text(encoding="utf-8")''')
rep('''        assert ivs[-1] == "VRN2_IndependentVerifier_v0113.py" and "VRN2_IndependentVerifier_v0112.py" in ivs, ivs[-3:]''',
    '''        assert "VRN2_IndependentVerifier_v0113.py" in ivs and "VRN2_IndependentVerifier_v0112.py" in ivs, ivs[-3:]''')
(S / "v152/new").mkdir(parents=True, exist_ok=True)
(S / "v152/new/ActivateVRN-2_v0152.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0152 lines", s.count("\n"))
