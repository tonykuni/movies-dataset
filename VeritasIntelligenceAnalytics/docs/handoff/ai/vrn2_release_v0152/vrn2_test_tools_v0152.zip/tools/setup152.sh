#!/bin/bash
# 全新沙盒 t152(跟 v0151 的 run_roundall151.sh first 同一套樹:52 份個股 + 共用擷取工具 + 退役環境 + 舊資料庫 csv)+ 假分支 vrn2_release_v0152
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v152; T=$W/t152; P=$S2/venv_vrn2/bin/python
rm -rf "${T:?}" "${T:?}.br" "${T:?}.setup.log"
bash $S/v142/mktree142.sh $T $W/pkg152 "$S2/shipF/samples" > $W/t152_setup.log 2>&1 || { cat $W/t152_setup.log; exit 1; }
rm -rf "${T:?}/pkg"
R="/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN"
mkdir -p "$T/VIA/functional modules/VRN/_vdf_fetch"; cp "$R/VRN2_MarketFetch_v0112.py" "$T/VIA/functional modules/VRN/"; cp "$R/_vdf_fetch/VDF_TW_AllInOne_v039.py" "$T/VIA/functional modules/VRN/_vdf_fetch/"
(cd "$T/VIA" && git add -A >/dev/null 2>&1 && git -c user.email=t@t -c user.name=t commit -qm "shared tools" >/dev/null 2>&1; git push -q origin main >/dev/null 2>&1)
bash $W/mkbranch152.sh t152
(cd "$T/VIA" && git fetch -q origin >/dev/null 2>&1)
mkdir -p "$T/OneDrive/VRN2_out" "$T/home/OneDrive" "$T/home/Downloads" "$T/tmp"
mkdir -p "$T/home/envs/via_core.retired-20260914_111946/bin" && ln -sf "$P" "$T/home/envs/via_core.retired-20260914_111946/bin/python"
/usr/bin/python3 -m venv --without-pip "$T/home/envs/via_tw_fetch"
printf '\xef\xbb\xbfTicker,Date,Broker,Target Price,Rating\n2330,2025-10-01,CLSA,1200,BUY\n3008,2025-10-05,KGI,2500,HOLD\n' > "$T/OneDrive/VRN2_out/舊基本資料 - Sheet1.csv"
echo "setup ok"
