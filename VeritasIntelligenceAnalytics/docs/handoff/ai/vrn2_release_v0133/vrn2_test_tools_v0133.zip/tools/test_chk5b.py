"""一鍵 v0133 ⑤b 單元測試(Codex #550 修正):從 Run-VRN2-v0133.ps1 抽出 Chk5b 函式與最後的 $lamp / $msg 兩段,用假的 HKCU 指令 / U/I / 輸入紀錄在 pwsh 跑 19 個情境。
用法:python test_chk5b.py <Run-VRN2-v0133.ps1> <pwsh>"""
import re, subprocess, sys, tempfile, pathlib, os
ps1, pwsh = pathlib.Path(sys.argv[1]), sys.argv[2]
lines = ps1.read_text(encoding="utf-8").splitlines()
i0 = next(i for i, l in enumerate(lines) if l.startswith("    function Chk5b("))
i1 = next(i for i in range(i0 + 1, len(lines)) if lines[i] == "    }")
fn = "\n".join(lines[i0:i1 + 1])
lamp = next(l for l in lines if l.startswith("    $lamp = "))
j0 = next(i for i, l in enumerate(lines) if l.startswith("    $msg = @{"))
j1 = next(i for i in range(j0, len(lines)) if lines[i].rstrip().endswith("}[$lamp]"))
msg = "\n".join(lines[j0:j1 + 1])
assert "$c5.lamp -eq 'RED'" in lamp and "$c5.inpOk" in lamp and "⑤b" in msg
test = r'''
$ErrorActionPreference = 'Stop'
function Say($lamp, $msg) { }
@FN@
$R = $env:T_R; $py = Join-Path $R 'py/python'
$good = '"' + $py + '" "' + [IO.Path]::Combine($R, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '" "%1"'
$ui = "<div id='vrn2-input'>個股報告/訊息 產業報告/展望 其他投資報告 <a href='vrn2://pick?kind=folder&amp;cat=stock'>x</a></div>"
$inp = [pscustomobject]@{ cat_label = '個股報告/訊息'; source_dir = 'X'; how = 'h'; audit_line = 'a' }
$res = @(); $c5cBad = $false; $uiP = 'X:\\ui.html'
function Chk($name, $cond, $extra) { $script:res += [pscustomobject]@{ n = $name; ok = [bool]$cond; x = [string]$extra } }
function Final($rcL, $ok8, $vok, $c5) {
@LAMP@
@MSG@
  [pscustomobject]@{ lamp = $lamp; msg = $msg; rc = @{ GREEN = 0; YELLOW = 2; RED = 1 }[$lamp] }
}
$c = Chk5b $R $py $good $ui $inp;            Chk '1 正確註冊 + 區塊 + 輸入紀錄 → GREEN(整條路徑相同 · python 同夾)' ($c.lamp -eq 'GREEN' -and $c.hSame -and $c.exeOk -and $c.samePy -and $c.inpOk) $c.msg
$f = Final 0 $true $true $c;                 Chk '1b 最後燈 GREEN · rc 0' ($f.lamp -eq 'GREEN' -and $f.rc -eq 0) $f.msg
$stale = '"' + $py + '" "' + [IO.Path]::Combine($env:T_R2, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '" "%1"'
$c = Chk5b $R $py $stale $ui $inp;           Chk '2 同檔名、別的(搬走的)檢出 · 檔在 · 沒有 v0133 設定檔 → RED「舊的 / 搬走的檢出」' ($c.lamp -eq 'RED' -and -not $c.hOk -and $c.msg -match '舊的 / 搬走的檢出') $c.msg
$f = Final 0 $true $true $c;                 Chk '2b 最後燈 RED · rc 1 · 訊息點名 ⑤b' ($f.lamp -eq 'RED' -and $f.rc -eq 1 -and $f.msg -match '⑤b') $f.msg
$gone = '"' + $py + '" "' + [IO.Path]::Combine($R, 'nowhere', 'VRN2_UIAction_v0103.py') + '" "%1"'
$c = Chk5b $R $py $gone $ui $inp;            Chk '3 指向不存在的檔 → RED「指向不存在的」' ($c.lamp -eq 'RED' -and $c.msg -match '指向不存在的') $c.msg
$old = '"' + $py + '" "' + [IO.Path]::Combine($R, 'functional modules', 'VRN', 'VRN2_UIAction_v0102.py') + '" "%1"'
$c = Chk5b $R $py $old $ui $inp;             Chk '4 指向舊處理器 v0102(檔在)→ RED' ($c.lamp -eq 'RED' -and -not $c.hOk) $c.msg
$c = Chk5b $R $py '' $ui $inp;               Chk '5 沒註冊(HKCU 空)+ 區塊在 → YELLOW' ($c.lamp -eq 'YELLOW' -and $c.msg -match '沒註冊') $c.msg
$f = Final 0 $true $true $c;                 Chk '5b 最後燈 YELLOW · rc 2 · 訊息「vrn2:// 沒註冊」(不再 GREEN)' ($f.lamp -eq 'YELLOW' -and $f.rc -eq 2 -and $f.msg -match 'vrn2:// 沒註冊') $f.msg
$c = Chk5b $R $py '' '<html>no block</html>' $inp;  Chk '6 沒註冊 + 沒區塊 → RED「不在」' ($c.lamp -eq 'RED' -and $c.msg -match '不在') $c.msg
$nopy = '"' + (Join-Path $R 'py/pythonw') + '" "' + [IO.Path]::Combine($R, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '" "%1"'
$c = Chk5b $R $py $nopy $ui $inp;            Chk '7 處理器對、python 檔不在 → RED「python 不在」' ($c.lamp -eq 'RED' -and $c.hOk -and -not $c.exeOk -and $c.msg -match 'python 不在') $c.msg
$c = Chk5b $R $py $good $ui $null;           Chk '8 全對但沒有輸入紀錄 → YELLOW + 「沒有輸入紀錄」' ($c.lamp -eq 'YELLOW' -and -not $c.inpOk -and $c.inpMsg -match '沒有輸入紀錄') $c.inpMsg
$f = Final 0 $true $true $c;                 Chk '8b 最後燈 YELLOW · 訊息「沒有輸入紀錄」' ($f.lamp -eq 'YELLOW' -and $f.msg -match '沒有輸入紀錄') $f.msg
$dots = '"' + $py + '" "' + [IO.Path]::Combine($R, 'functional modules', 'VRN', '..', 'VRN', 'VRN2_UIAction_v0103.py') + '" "%1"'
$c = Chk5b $R $py $dots $ui $inp;            Chk '9 路徑含 .. → 正規化後相同 → GREEN' ($c.lamp -eq 'GREEN' -and $c.hSame) $c.msg
$cfg = '"' + $py + '" "' + [IO.Path]::Combine($env:T_R3, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '" "%1"'
$c = Chk5b $R $py $cfg $ui $inp;             Chk '10 別的夾、但有啟動器本輪 v0133 設定檔 → GREEN(hCfg)' ($c.lamp -eq 'GREEN' -and $c.hCfg -and -not $c.hSame -and $c.msg -match '啟動器本輪登記的') $c.msg
$cfg4 = '"' + $py + '" "' + [IO.Path]::Combine($env:T_R4, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '" "%1"'
$c = Chk5b $R $py $cfg4 $ui $inp;            Chk '11 別的夾、設定檔是 v0132 → RED' ($c.lamp -eq 'RED' -and -not $c.hOk) $c.msg
$otherpy = '"' + (Join-Path $env:T_R2 'py/python') + '" "' + [IO.Path]::Combine($R, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '" "%1"'
$c = Chk5b $R $py $otherpy $ui $inp;         Chk '12 python 在別的夾(檔在)→ GREEN 並註明不同夾' ($c.lamp -eq 'GREEN' -and -not $c.samePy -and $c.msg -match '不同夾') $c.msg
$c = Chk5b $R $py $good $ui $inp
$f = Final 0 $true $false $c;                Chk '13 ⑤b 綠、獨立驗證有待核對 → YELLOW「獨立驗證有待核對」' ($f.lamp -eq 'YELLOW' -and $f.msg -match '獨立驗證有待核對') $f.msg
$f = Final 1 $true $true $c;                 Chk '14 啟動器 rc 1 → RED「有紅燈」' ($f.lamp -eq 'RED' -and $f.msg -match '有紅燈') $f.msg
$c = Chk5b $R $py $good $ui $inp; $c5cBad = $true; $f = Final 0 $true $true $c; $c5cBad = $false
Chk '19 ⑤b 綠但 U/I 開不了(⑤c)→ 最後燈 YELLOW「U/I 開不了」' ($f.lamp -eq 'YELLOW' -and $f.msg -match 'U/I 開不了') $f.msg
$c = Chk5b $R $py 'python VRN2_UIAction_v0103.py %1' $ui $inp;  Chk '15 沒引號解析不出 → RED「解析不出處理器」' ($c.lamp -eq 'RED' -and $c.msg -match '解析不出處理器') $c.msg
$no1 = '"' + $py + '" "' + [IO.Path]::Combine($R, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '"'
$c = Chk5b $R $py $no1 $ui $inp;             Chk '16 python / 處理器都對、少了 "%1" → RED「少了 "%1"」' ($c.lamp -eq 'RED' -and $c.hOk -and $c.exeOk -and -not $c.u1Ok -and $c.msg -match '少了 "%1"') $c.msg
$fixed = '"' + $py + '" "' + [IO.Path]::Combine($R, 'functional modules', 'VRN', 'VRN2_UIAction_v0103.py') + '" "vrn2://run"'
$c = Chk5b $R $py $fixed $ui $inp;           Chk '17 第三段被換成固定網址 → RED(訊息列出第三段)' ($c.lamp -eq 'RED' -and -not $c.u1Ok -and $c.msg -match 'vrn2://run') $c.msg
$c = Chk5b $R $py $good $ui $inp;            Chk '18 正確指令第三段是 %1 → u1Ok · GREEN 訊息寫「帶 "%1"」' ($c.u1Ok -and $c.lamp -eq 'GREEN' -and $c.msg -match '帶 "%1"') $c.msg
$n = ($res | Where-Object ok).Count
foreach ($r in $res) { Write-Output ("  [{0}] {1}{2}" -f $(if ($r.ok) { 'OK' } else { 'FAIL' }), $r.n, $(if ($r.ok) { '' } else { ' · ' + $r.x.Substring(0, [Math]::Min(200, $r.x.Length)) })) }
Write-Output ("[計] 一鍵 v0133 ⑤b Chk5b + 最後燈 單元測試 {0}/{1} · {2}" -f $n, $res.Count, $(if ($n -eq $res.Count) { 'PASS' } else { 'FAIL' }))
exit $(if ($n -eq $res.Count) { 0 } else { 1 })
'''.replace("@FN@", fn).replace("@LAMP@", lamp).replace("@MSG@", msg)
with tempfile.TemporaryDirectory() as td:
    td = pathlib.Path(td)
    def mk(root, handler, cfg=None):
        d = root / "functional modules" / "VRN"; d.mkdir(parents=True)
        (d / handler).write_text("#", encoding="utf-8")
        if cfg: (d / "VRN2_UIAction_Config.json").write_text(cfg, encoding="utf-8")
        (root / "py").mkdir(); (root / "py" / "python").write_text("#", encoding="utf-8")
    mk(td / "R", "VRN2_UIAction_v0103.py"); (td / "R" / "functional modules" / "VRN" / "VRN2_UIAction_v0102.py").write_text("#", encoding="utf-8")
    mk(td / "R2", "VRN2_UIAction_v0103.py")
    mk(td / "R3", "VRN2_UIAction_v0103.py", '{"version": "ActivateVRN-2 v0133", "handler": "VRN2_UIAction_v0103.py"}')
    mk(td / "R4", "VRN2_UIAction_v0103.py", '{"version": "ActivateVRN-2 v0132", "handler": "VRN2_UIAction_v0102.py"}')
    (td / "t.ps1").write_text(test, encoding="utf-8")
    env = dict(os.environ, T_R=str(td / "R"), T_R2=str(td / "R2"), T_R3=str(td / "R3"), T_R4=str(td / "R4"))
    p = subprocess.run([pwsh, "-NoProfile", "-File", str(td / "t.ps1")], env=env, capture_output=True, text=True)
    print(p.stdout, end=""); print(p.stderr[:3000], end="", file=sys.stderr)
    print("[抽出] Chk5b L%d-%d · $lamp L%d · $msg L%d-%d · 來源 %s" % (i0 + 1, i1 + 1, lines.index(lamp) + 1, j0 + 1, j1 + 1, ps1.name))
    sys.exit(p.returncode)
