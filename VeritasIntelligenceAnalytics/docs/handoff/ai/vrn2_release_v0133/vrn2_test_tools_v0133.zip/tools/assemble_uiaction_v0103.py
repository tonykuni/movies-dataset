"""VRN2_UIAction_v0103.py = 新檔頭說明 + v0102 的加速器橋區塊(逐字抄 · 不改)+ 本版主體。
用法:python assemble_uiaction_v0103.py <v0102.py> <body.py> <輸出 v0103.py>"""
import hashlib
import sys
from pathlib import Path

v102, body, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = v102.read_text(encoding="utf-8")
a = s.index("# ===== [VIA:ACCEL-BRIDGE:v0111]")
b = s.index("# ===== [VIA:ACCEL-BRIDGE:END] =====") + len("# ===== [VIA:ACCEL-BRIDGE:END] =====\n")
bridge = s[a:b]
head = r'''"""VRN2_UIAction v0103 — VRN-2 U/I 操作協定 vrn2:// 的處理器(由 ActivateVRN-2 註冊到目前使用者 HKCU · 不碰 via://)。

v0103(操作員 2026-10-21:「用 ActivateVRN-2.ps1 啟動前後端並連結 · 讓使用者在 HTML 上用 window I/O 輸入檔案夾或檔案(pdf / word / txt / image / 檔案夾)·
      分三種:個股報告/訊息 · 產業報告/展望 · 其他投資報告 · 現在進行的是個股報告/訊息,其他功能關閉」):
  vrn2://pick?kind=folder&cat=stock   Windows 原生對話框選資料夾 → 稽核(型別 / 個股範圍)→ VIA_Reports\\vrn2\\VRN2_Input_latest.json → U/I 左側「輸入」區塊 → 重開 U/I
  vrn2://pick?kind=files&cat=stock    原生對話框多選檔(pdf / docx / doc / txt / png / jpg / jpeg / tif / tiff / bmp)→ 複製到 VIA_Reports\\vrn2\\input_pick\\<時間>\\ → 同上
  vrn2://audit                        重新稽核目前輸入(不開對話框)
  cat 只開放 stock;industry / other 一律拒絕「尚未開放」(U/I 上 disabled)。啟動器 ②b 讀 VRN2_Input_latest.json 當來源夾(寫新一版 VRN2_SSOT · 管理器不動)。
  --set-source <夾> [--how <來源>] [--v2 <輸出根>]   啟動器 ②b:來源夾 → 紀錄 + 稽核(與 U/I 同一把尺)· 印 JSON(--v2 = 設定檔還沒寫之前由啟動器直接給)
  --refresh-ui                        啟動器 ⑫b:⑦ 重寫 U/I 後把輸入區塊補回(同一塊 · 不疊加)
  --audit <夾|檔…> · --selftest
  v0102 的 run / run?nopush=1 / run-clean / restore-archive 照舊(帶 VRN2_FROM_UI=1 · 新主控台)。
只接受白名單動作;路徑取自啟動器寫的 VRN2_UIAction_Config.json 與對話框實際選到的,不從網址讀路徑。
型別照 ENG397 的 EXT;本版 VRN-2 主體只擷取 PDF,非 PDF 照實記「已收下 · 本版主體只擷取 PDF」(不假裝有處理)。
個股 / 範圍外:檔名規則取管理器 v0231 的 _SK_EXCL(同一條 · 從檔案文字讀 · 不 import)+ 上輪判定 VRN2_Scope_latest.json non_stock。
測試掛鉤:VRN2_PICK_PATH(資料夾)· VRN2_PICK_FILES(以 | 分隔)· VRN2_UIACTION_DRY=1 只印 run 類指令。動作寫入 ui_actions.log。
"""

'''
txt = head + bridge + body.read_text(encoding="utf-8")
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(txt, encoding="utf-8", newline="\n")
compile(txt, out.name, "exec")
print("[計] %s · %d 位元組 · sha256 %s · 橋 %d 字" % (out.name, len(txt.encode("utf-8")), hashlib.sha256(txt.encode("utf-8")).hexdigest()[:12], len(bridge)))
