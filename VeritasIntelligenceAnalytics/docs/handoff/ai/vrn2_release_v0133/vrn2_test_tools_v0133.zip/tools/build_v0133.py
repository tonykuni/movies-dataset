"""ActivateVRN-2 v0132 → v0133 組裝(錨點替換 · 每個錨點只准出現一次 · 不改 v0132 原檔)。

用法:python build_v0133.py <v0132 啟動器> <new 夾> <輸出 v0133 啟動器>
  new 夾:VRN2_UIAction_v0103.py · VRN2_Handover_v0133.md
v0133 = 操作員 2026-10-21「用 ActivateVRN-2.ps1 啟動前後端並連結 · 在 HTML 上用 window I/O 輸入檔案夾或檔案(pdf / word / txt / image / 檔案夾)·
  三種:個股報告/訊息 · 產業報告/展望 · 其他投資報告 · 現在只做個股報告/訊息,其他關閉 · 留意是否都有註冊成功」:
  ① 內嵌 U/I 處理器 v0103(v0102 留著 · 只增不改)· vrn2:// 註冊指向 v0103 · 寫完讀回核對
  ② ②b 輸入來源:--source > 環境 VIA_VRN_INPUT > U/I 選的 VRN2_Input_latest.json > VRN2_SSOT > 預設 · 寫新一版 VRN2_SSOT(管理器 vrn2scope 讀它 · 不改管理器)· 稽核走處理器
  ③ ⑫b ⑦ 重寫 U/I 之後把「輸入(window I/O)」區塊補回(三類 · 只開個股)
  ④ 貼包多一行「註冊核對」(元件登記 · vrn2:// · 定位登記)· NEXT 註冊未全綠會說
  管理器鏈 / ENG397 / 摘要器 / 獨立驗證器 / 工具橋 / OCR 橋 一個位元組都不動。
"""
import base64
import hashlib
import sys
from pathlib import Path

src_p, new_d, out_p = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src_p.read_text(encoding="utf-8")


def b64(raw: bytes) -> str:
    t = base64.b64encode(raw).decode("ascii")
    return "\n".join(t[i:i + 120] for i in range(0, len(t), 120))


def rep(a: str, b: str) -> None:
    global s
    assert s.count(a) == 1, (s.count(a), a[:90])
    s = s.replace(a, b)


ua = (new_d / "VRN2_UIAction_v0103.py").read_bytes()
hand = (new_d / "VRN2_Handover_v0133.md").read_bytes()
usha, hsha = hashlib.sha256(ua).hexdigest(), hashlib.sha256(hand).hexdigest()

rep('r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0132 工具橋 v0101:',
    'r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0133 前後端連結 · window I/O 輸入:U/I 左側「輸入」區塊 → vrn2://pick 開 Windows 原生對話框選檔案夾 / 檔案(pdf · word · txt · 影像)→ '
    '稽核(型別 · 個股範圍)→ VRN2_Input_latest.json → ②b 當來源夾(寫新一版 VRN2_SSOT · 管理器不動)· 三類只開「個股報告/訊息」(產業報告/展望 · 其他投資報告 尚未開放)· '
    'vrn2:// 註冊寫完讀回核對 · 貼包多一行「註冊核對」· 其餘同 v0132 · VRN-2 主體一個位元組都不動)\n'
    'v0132 工具橋 v0101:')
rep('VERSION = "ActivateVRN-2 v0132"', 'VERSION = "ActivateVRN-2 v0133"')

rep('UI_HANDLER_NAME = "VRN2_UIAction_v0102.py"\n',
    'EXTRAS.append(("VRN2_UIAction_v0103.py", "%s", """\n%s\n"""))   # v0133 U/I 處理器 v0103(vrn2://pick · 三類只開個股 · --set-source / --refresh-ui · 帶加速器橋)· v0102 留著(只增不改)\n'
    'UI_HANDLER_NAME = "VRN2_UIAction_v0103.py"\n' % (usha, b64(ua)))

i = s.index('HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0132.md"')
j = s.index('"""', s.index('HANDOVER_B64 = """') + len('HANDOVER_B64 = """')) + 3
s = s[:i] + 'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0133.md", "%s"\nHANDOVER_B64 = """\n%s\n"""' % (hsha, b64(hand)) + s[j:]

# ⑥c 註冊寫完讀回核對
rep('''        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\vrn2\\shell\\open\\command") as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, cmd)
        return "GREEN", "vrn2:// 已註冊到目前使用者(HKCU)· 處理器 %s · U/I 左側按鈕可直接操作(重跑 / 不上船 / 清快取 / 還原封存)" % handler.name
''', '''        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\vrn2\\shell\\open\\command") as k:
            winreg.SetValueEx(k, "", 0, winreg.REG_SZ, cmd)
        back = winreg.QueryValue(winreg.HKEY_CURRENT_USER, r"Software\\Classes\\vrn2\\shell\\open\\command")   # v0133 寫完讀回核對(註冊成功才算)
        if back != cmd:
            return "YELLOW", "vrn2:// 寫了但讀回不同(%s)· U/I 請用「複製執行指令」或 $env:VRN2_SOURCE" % back[:100]
        return "GREEN", "vrn2:// 已註冊到目前使用者(HKCU)· 讀回核對相同 · 處理器 %s · U/I 左側按鈕可直接操作(重跑 / 不上船 / 清快取 / 還原封存 / 選擇檔案夾 / 選擇檔案 / 重新稽核)" % handler.name
''')

# ②b 輸入來源(在 land_extras 之後 · ③ 之前)
rep('''        v2.mkdir(parents=True, exist_ok=True)
        try:
            prev = json.loads((v2 / "VRN2_Activate_latest.json")''',
    '''        v2.mkdir(parents=True, exist_ok=True)
        il2_, id2_ = _input_source(argv, vrn, v2)                             # v0133 ②b 輸入來源(個股報告/訊息):U/I 選的 / --source / 環境 / VRN2_SSOT / 預設 → 寫 VRN2_SSOT · 稽核
        step("②b 輸入來源(個股報告/訊息)", il2_, id2_)
        try:
            prev = json.loads((v2 / "VRN2_Activate_latest.json")''')

# ⑫b U/I 輸入區塊(⑦ 重寫 U/I 之後 · 開 U/I 之前)
rep('''            say("  [U/I] %s" % _ui_open(v2, no_open), Y)
''', '''            rc_u, ln_u = run([sys.executable, "-W", "ignore", str(vrn / UI_HANDLER_NAME), "--refresh-ui", "--v2", str(v2)], 120, envx, cwd=str(vrn))   # v0133 ⑫b U/I 輸入區塊(三類 · 只開個股)
            step("⑫b U/I 輸入區塊(window I/O)", "GREEN" if rc_u == 0 else "YELLOW", next((l.strip() for l in ln_u if l.strip().startswith("[")), "rc %d" % rc_u)[:160])
            say("  [U/I] %s" % _ui_open(v2, no_open), Y)
''')

# 貼包:註冊核對一行 · NEXT 註冊未全綠會說
rep('''        say("══════ 貼給 AI(%d 行 · %.0f 秒)══════" % (min(len(PACK), 290), time.time() - t0), Y)
''', '''        _rg = {k_: next((s_ for s_ in STEPS if s_["step"].startswith(k_)), None) for k_ in ("⑤ 元件登記", "⑥c U/I 操作協定", "② 定位 VRN-2 程式夾")}   # v0133 註冊核對
        _rbad = [k_ for k_, s_ in _rg.items() if not s_ or s_["lamp"] in ("RED", "YELLOW")]
        PACK.append("[%s] 註冊核對 · %s · 處理器 %s · %s" % ("計" if not _rbad else "RED", " · ".join("%s %s" % (k_, (s_ or {}).get("lamp", "沒跑到")) for k_, s_ in _rg.items()),
                                                      UI_HANDLER_NAME, "全部登記成功" if not _rbad else "未全綠:" + "、".join(_rbad)))
        say("══════ 貼給 AI(%d 行 · %.0f 秒)══════" % (min(len(PACK), 290), time.time() - t0), Y)
''')
rep('''        say("NEXT: " + nxt, Y)
''', '''        if _rbad:
            nxt += " · 註冊核對未全綠(" + "、".join(_rbad) + ")→ 看貼包那一行"
        say("NEXT: " + nxt, Y)
''')

# _input_source 定義(放在 main 之前)
rep('''def main(argv: list) -> int:
    if "--restore-archive" in argv:''', '''def _input_source(argv: list, vrn, v2) -> tuple:
    """v0133 ②b 輸入來源(現在只做 個股報告/訊息):--source <夾> > 環境 VIA_VRN_INPUT(有設才算)> U/I 選的 VIA_Reports\\\\vrn2\\\\VRN2_Input_latest.json(cat = stock)
    > VRN2_SSOT source_dir > 預設 C:\\\\測試樣本報告。來源和 VRN2_SSOT 不同 → 寫新一版 VRN2_SSOT(只增 · 管理器 vrn2scope 讀它 · 不改管理器)·
    稽核與紀錄交給處理器 --set-source(與 U/I 同一把尺 · U/I 輸入區塊也讀這份紀錄)。回 (燈, 說明)。"""
    global INPUT_DIR
    vrn, v2 = _cb_Path(vrn), _cb_Path(v2)
    how, src = "", None
    if "--source" in argv and argv.index("--source") + 1 < len(argv):
        src, how = _cb_Path(argv[argv.index("--source") + 1]), "啟動器 --source"
    elif os.environ.get("VIA_VRN_INPUT"):
        src, how = _cb_Path(os.environ["VIA_VRN_INPUT"]), "環境 VIA_VRN_INPUT"
    else:
        try:
            rec = json.loads((v2 / "VRN2_Input_latest.json").read_text(encoding="utf-8"))
            if rec.get("cat") == "stock" and rec.get("source_dir"):
                src, how = _cb_Path(rec["source_dir"]), "U/I 選的(%s · %s)" % ("資料夾" if rec.get("kind") == "folder" else "檔案 → 暫存夾", rec.get("ts", ""))
        except Exception:  # noqa: BLE001
            pass
    books = sorted((vrn / "SSOT").glob("VRN2_SSOT_v[0-9][0-9][0-9][0-9].json"), key=_vnum)
    try:
        ss = json.loads(books[-1].read_text(encoding="utf-8")) if books else {}
    except Exception:  # noqa: BLE001
        ss = {}
    if src is None:
        if ss.get("source_dir"):
            src, how = _cb_Path(ss["source_dir"]), "VRN2_SSOT 來源夾"
        else:
            src, how = INPUT_DIR, "預設"
    INPUT_DIR = src
    os.environ["VIA_VRN_INPUT"] = str(src)
    note = ""
    if str(src) != str(ss.get("source_dir") or ""):
        (vrn / "SSOT").mkdir(parents=True, exist_ok=True)
        nv = (_vnum(books[-1]) + 1) if books else 100
        (vrn / "SSOT" / ("VRN2_SSOT_v%04d.json" % nv)).write_text(json.dumps(dict(ss, source_dir=str(src)), ensure_ascii=False, indent=1), encoding="utf-8")
        note = " · VRN2_SSOT → v%04d(來源夾換成這個)" % nv
    if not src.is_dir():
        return "RED", "個股報告/訊息 · %s · %s 不是資料夾(U/I「選擇檔案夾」或 --source 指一個在的夾)%s" % (how, src, note)
    rc, ln = run([sys.executable, "-W", "ignore", str(vrn / UI_HANDLER_NAME), "--set-source", str(src), "--how", how, "--v2", str(v2)], 300, {"VIA_NO_OPEN": "1"}, cwd=str(vrn))
    rec = {}
    for l in ln:
        if l.strip().startswith("{"):
            try:
                rec = json.loads(l.strip())
            except ValueError:
                pass
    a = rec.get("audit") or {}
    line = rec.get("audit_line") or ("稽核失敗 rc %d" % rc)
    return ("GREEN" if a.get("stock", 0) > 0 else "YELLOW"), "個股報告/訊息 · %s · %s · %s%s%s" % (how, src, line, note, "" if a.get("stock", 0) else " · 個股範圍 0 份(產業 / 其他 尚未開放)")


def main(argv: list) -> int:
    if "--restore-archive" in argv:''')

# 自測
rep('''def selftest() -> int:
    import tempfile
''', '''def selftest() -> int:
    global INPUT_DIR
    import tempfile
''')
rep('''    print("[計] %s 自測 %d/%d · %s" % (VERSION, ok, tot, "PASS" if ok == tot else "FAIL"))
    return 0 if ok == tot else 1
''', '''    uab = next((e for e in EXTRAS if e[0] == UI_HANDLER_NAME), None)
    uasrc = base64.b64decode("".join(uab[2].split())).decode("utf-8") if uab else ""
    chk("v0133 內嵌 U/I 處理器 %s(vrn2://pick · 三類只開個股 · --set-source / --refresh-ui · 帶加速器橋 · 不 import VRN-2 程式)· v0102 留著" % UI_HANDLER_NAME,
        bool(uab) and UI_HANDLER_NAME.endswith("v0103.py") and all(x in uasrc for x in ("def pick(", "def audit(", "def patch_ui(", "--set-source", "--refresh-ui", "個股報告/訊息", "產業報告/展望", "其他投資報告", "[VIA:ACCEL-BRIDGE:v0111]"))
        and "import VRN_" not in uasrc and "from VRN_" not in uasrc and any(e[0] == "VRN2_UIAction_v0102.py" for e in EXTRAS))
    with tempfile.TemporaryDirectory(prefix="act133ua-") as td_:
        p_ = _cb_Path(td_) / UI_HANDLER_NAME
        p_.write_bytes(base64.b64decode("".join(uab[2].split())) if uab else b"")
        rc_ua, ln_ua = run([sys.executable, "-W", "ignore", str(p_), "--selftest"], 300, {"VIA_NO_OPEN": "1"}, cwd=td_, silent_max=300)
    chk("v0133 U/I 處理器自測(選資料夾 / 選檔案 → 暫存 · 稽核 · 拒絕未開放 · U/I 區塊不疊加)→ %s" % next((l.strip() for l in reversed(ln_ua) if "自測" in l), "rc %d" % rc_ua)[-60:], rc_ua == 0)
    chk("v0133 ②b 輸入來源在 ② 落地之後、③ 之前 · ⑫b 寫回 U/I 輸入區塊在 ⑫ 之後、開 U/I 之前 · 貼包有註冊核對",
        _ms.index("land_extras(vrn)") < _ms.index('step("②b 輸入來源') < _ms.index('bar(2, N, "③') and _ms.index('step("⑫ PIVOT') < _ms.index('"--refresh-ui"') < _ms.index("_ui_open(")
        and "註冊核對" in _ms)
    with tempfile.TemporaryDirectory(prefix="act133src-") as td_:
        t_ = _cb_Path(td_)
        (t_ / "VRN" / "SSOT").mkdir(parents=True)
        (t_ / "v2").mkdir()
        (t_ / "VRN" / UI_HANDLER_NAME).write_bytes(base64.b64decode("".join(uab[2].split())) if uab else b"")
        (t_ / "VRN" / "SSOT" / "VRN2_SSOT_v0100.json").write_text(json.dumps({"source_dir": str(t_ / "old"), "scope": "stock_only"}), encoding="utf-8")
        (t_ / "in").mkdir()
        for n_ in ("A-2330 20250718.pdf", "20260916兆豐台灣產業專題-航太產業.pdf", "m.docx"):
            (t_ / "in" / n_).write_bytes(b"x")
        (t_ / "v2" / "VRN2_Input_latest.json").write_text(json.dumps({"cat": "stock", "kind": "folder", "source_dir": str(t_ / "in"), "ts": "t"}), encoding="utf-8")
        _env0, _in0 = os.environ.pop("VIA_VRN_INPUT", None), INPUT_DIR
        l_, d_ = _input_source([], t_ / "VRN", t_ / "v2")
        ss_ = sorted((t_ / "VRN" / "SSOT").glob("VRN2_SSOT_v*.json"))
        ss_names, ss_src, in_dir = [p.name for p in ss_], json.loads(ss_[-1].read_text(encoding="utf-8")).get("source_dir"), str(t_ / "in")
        rec_ = json.loads((t_ / "v2" / "VRN2_Input_latest.json").read_text(encoding="utf-8"))
        l2_, d2_ = _input_source(["--source", str(t_ / "nowhere")], t_ / "VRN", t_ / "v2")
        INPUT_DIR = _in0
        if _env0 is None:
            os.environ.pop("VIA_VRN_INPUT", None)
        else:
            os.environ["VIA_VRN_INPUT"] = _env0
    chk("v0133 ②b 來源(設定檔還沒寫 · 走 --v2):U/I 選的夾 → 綠 · 寫 VRN2_SSOT v0101(來源夾換掉 · 只增)· 紀錄 how 寫明 · 稽核 個股 1 · 範圍外 1 · 非 PDF 1 · --source 指不在的夾 → 紅 → %s" % d_[:60],
        l_ == "GREEN" and "U/I 選的" in d_ and "個股範圍 1" in d_ and "範圍外 1" in d_ and "非 PDF 1" in d_ and ss_names == ["VRN2_SSOT_v0100.json", "VRN2_SSOT_v0101.json"]
        and ss_src == in_dir and rec_["how"].startswith("U/I 選的") and rec_["audit"]["stock"] == 1 and l2_ == "RED" and "不是資料夾" in d2_)
    print("[計] %s 自測 %d/%d · %s" % (VERSION, ok, tot, "PASS" if ok == tot else "FAIL"))
    return 0 if ok == tot else 1
''')

out_p.write_text(s, encoding="utf-8", newline="\n")
compile(s, out_p.name, "exec")
print("[計] %s · %d 位元組 · 處理器 %s · 交接 %s · sha256 %s" % (out_p.name, len(s.encode("utf-8")), usha[:12], hsha[:12], hashlib.sha256(s.encode("utf-8")).hexdigest()[:12]))
