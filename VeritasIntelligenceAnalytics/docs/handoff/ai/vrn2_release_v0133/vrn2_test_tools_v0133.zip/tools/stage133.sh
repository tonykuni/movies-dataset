#!/bin/bash
# 把 v0133 發行夾放進 movies-dataset 倉(不放 .ps1 · 一鍵程式碼嵌在 md 裡)· logs / 測試工具壓成 zip(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v133
D=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
R=$D/vrn2_release_v0133; mkdir -p $R
python3 - <<'PY'
import zipfile, pathlib, re
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v133")
R = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0133")
def z(name, files):
    with zipfile.ZipFile(R / name, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            data = p.read_bytes()
            if p.suffix == ".log":
                data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 20, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(zi, data)
logs = [("selftest_v0133.log", W / "selftest_v0133.log")] + [("e2e_%s.log" % k, W / ("e2e_%s.log" % k)) for k in ("A1", "P1", "P2", "P1pick", "P2pick", "R", "R2", "audit")] + \
       [("scen_oneclick_v0132_to_v0133.log", W / "scen_oneclick.log"), ("ui_input_v0133.log", W / "ui_input.log"), ("ui_input_oneclick_v0133.log", W / "ui_input_oc.log"), ("chk5b_unit_v0133.log", W / "chk5b_unit.log"), ] + [("boot_fail_%s_v0133.log" % k, W / ("boot_fail_%s.log" % k)) for k in "abcde"] + [("scen_oneclick_v0132_to_v0133_pre_codex550.log", W / "scen_oneclick_pre_codex.log"), ("ui_test_v0133.log", W / "ui_test.log")]
z("logs_v0133.zip", [(a, p) for a, p in logs if p.exists()])
tools = sorted((W / "tools").glob("*"))
z("vrn2_test_tools_v0133.zip", [("tools/" + p.name, p) for p in tools if p.is_file() and p.suffix != ".ps1"])
PY
for f in ActivateVRN-2_v0133.zip VRN2_Release_v0133.json VRN2_OneClick_v0133.md VRN2_Verification_v0133.md; do cp $W/release133/$f $R/; done
cp $W/new/VRN2_Handover_v0133.md $D/VRN2_Handover_v0133.md
cp $W/new/VRN2_Handover_v0133.md $D/VRN2_Handover_latest.md
ls -la $R; sha256sum $D/VRN2_Handover_latest.md $D/VRN2_Handover_v0133.md | cut -c1-16
