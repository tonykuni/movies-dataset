"""vrn2_release_v0133:ActivateVRN-2_v0133.zip(ActivateVRN-2.py · 固定時間戳)+ VRN2_Release_v0133.json(冪等)。
用法:python make_release133.py <ActivateVRN-2_v0133.py> <results.json> <輸出夾>"""
import ast
import base64
import hashlib
import json
import sys
import zipfile
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)
raw = src.read_bytes()
sha = hashlib.sha256(raw).hexdigest()
zp = out / "ActivateVRN-2_v0133.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    zi = zipfile.ZipInfo("ActivateVRN-2.py", date_time=(2026, 10, 21, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    z.writestr(zi, raw)
tree = ast.parse(raw.decode("utf-8"))
consts, extras = {}, []
for n in tree.body:
    if isinstance(n, ast.Assign):
        try:
            v = ast.literal_eval(n.value)
        except Exception:  # noqa: BLE001
            continue
        for tg in n.targets:
            if isinstance(tg, ast.Name):
                consts[tg.id] = v
            elif isinstance(tg, ast.Tuple):
                for e, vv in zip(tg.elts, v):
                    consts[e.id] = vv
    elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and getattr(n.value.func, "attr", "") == "append":
        extras.append(ast.literal_eval(n.value.args[0]))


def comp(name, h, b64):
    b = base64.b64decode("".join(b64.split()))
    assert hashlib.sha256(b).hexdigest() == h, name
    return {"file": name, "bytes": len(b), "sha256": h}


order = [comp(*c) for c in consts["MGR_CHAIN"]] + [comp(consts["MGR_NAME"], consts["MGR_SHA"], consts["MGR_B64"])]
order += [comp(*c) for c in consts["ENGINES"]] + [comp(*c) for c in list(consts["EXTRAS"]) + extras]
order += [comp(consts["OCR_BRIDGE_NAME"], consts["OCR_BRIDGE_SHA"], consts["OCR_BRIDGE_B64"]), comp(consts["HANDOVER_NAME"], consts["HANDOVER_SHA"], consts["HANDOVER_B64"])]
R = json.loads(res_p.read_text(encoding="utf-8"))
man = {
    "system": "VRN-2",
    "independent": True,
    "release": "ActivateVRN-2 v0133",
    "date": "2026-10-21",
    "operator_order_2026_10_21": ["用vcgc的節省token工具來進行工作之後都是: 做好啟動系統實測準備善用vcwg節省token工具進行最後一大修，檢查用ActivateVRN-2.psl啟動前後端並連結讓使用者在html上用window i/o輸入檔案夾或檔案可以為pdf word txt image檔案夾 分為三種  個股報告/訊息  產業報告/展望  其他投資報告  現在進行的是個股報告/訊息其他功能關閉準備好測試無誤後留意是否都有註冊成功百並上傳github  guthub有無衝突問題一併解決  下一步換輸入檔案audit\"C:\\測試樣本報告\""],
    "supersedes": "ActivateVRN-2 v0132(docs/handoff/ai/vrn2_release_v0132)· 主體 16 個元件逐位元組相同(管理器鏈 · ENG397 · 摘要器 · 獨立驗證器 · 處理器 v0102 · 工具橋 v0101 · OCR 橋 · 規則目錄)· 新增 U/I 處理器 v0103 與交接報告 v0133",
    "design": {
        "frontend": "VIA_Reports/vrn2/VRN2_UI_latest.html(管理器 ⑦ 產生 · 啟動器 ⑪ 寫回驗證 · ⑫ PIVOT 連結 · ⑫b 輸入區塊)",
        "backend": "vrn2:// 協定(HKCU 註冊 · 寫完讀回核對)→ VRN2_UIAction_v0103.py → 啟動器 ActivateVRN-2.py(①~⑫)",
        "window_io": "vrn2://pick?kind=folder|files&cat=stock → Windows 原生對話框(System.Windows.Forms · tkinter 備援)→ 稽核 → VRN2_Input_latest.json → ②b 當來源夾(寫新一版 VRN2_SSOT · 管理器不動)",
        "categories": {"stock": "個股報告/訊息(開放)", "industry": "產業報告/展望(尚未開放 · U/I disabled · 處理器拒絕)", "other": "其他投資報告(尚未開放 · 同上)"},
        "file_types": "pdf · docx · doc · txt · png · jpg · jpeg · tif · tiff · bmp(同 ENG397 EXT · 自測逐鍵核對)· 本版主體只擷取 PDF · 非 PDF 照實記「已收下 · 本版主體只擷取 PDF」",
        "registration_check": "貼包多一行「註冊核對」:⑤ 元件登記 · ⑥c vrn2://(讀回核對)· ② 定位登記;一鍵 ⑤b 再查 HKCU 與 U/I 區塊",
        "rules": "只增不減(處理器 v0102 留著)· VRN-2 主體一個位元組都不動 · 路徑只從對話框與啟動器寫的設定讀 · 不從網址讀路徑"
    },
    "embedded_components_landing_order": order,
    "tested_in": {
        "where": "Claude Code 雲端容器 · Linux · Python 3.13 · 測試用隔離 venv(repo 與系統 Python 未動)· OCR 隔離環境另建 Python 3.11 venv(rapidocr_onnxruntime · numpy<2)只在暫存區",
        "inputs": "repo 內真實 PDF 19 份(個股 14)· U/I 選資料夾子集 6 PDF(個股 5)+ txt / docx / png · U/I 選檔案 2 PDF + 1 txt → 暫存夾",
        "chain_stub": "使用者機器的管理器前版鏈 v0154–v0230 不在 repo → 測試替身(只供 p1loop / _rep / input_dir 等)· 不可提交",
        "vrn1": "VIA-VDF-VRN 倉 claude/optimistic-goodall-yhalc5 @ e10679c(PR tonykuni/VIA-VDF-VRN#79 · 第十四輪 · 工具冊 ssot/VRN_ToolManifest_v0100.json)· 另一份 = main 62475b0(沒有工具冊 · 實測 ⑫ 灰 + git switch 指令)",
    },
    "results": R,
    "launcher": {"file": "ActivateVRN-2_v0133.py", "bytes": len(raw), "sha256": sha},
    "launcher_zip": {"file": zp.name, "sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "member": "ActivateVRN-2.py"},
    "oneclick": "VRN2_OneClick_v0133.md",
    "test_tools_zip": "vrn2_test_tools_v0133.zip",
    "logs_zip": "logs_v0133.zip",
}
(out / "VRN2_Release_v0133.json").write_text(json.dumps(man, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
print("[計] launcher %s · zip %s · 元件 %d" % (sha[:12], man["launcher_zip"]["sha256"][:12], len(order)))
