"""VRN2_Handover_v0133.md = v0132 交接報告 + v0133(前後端連結 · U/I window I/O 輸入 · 三類只開個股 · 註冊核對)· 逐行錨點替換 · 冪等。
用法:python make_handover_v0133.py <v0132.md> <結果 json> <輸出 md>
結果 json:{"selftest": "...", "e2e": "...", "ui": "...", "oneclick": "...", "ua_sha12": "..."}(容器實測數字)"""
import json
import re
import sys
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
R = json.loads(res_p.read_text(encoding="utf-8"))
lines = src.read_text(encoding="utf-8").split("\n")


def one(prefix: str) -> int:
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    assert len(hits) == 1, (prefix[:40], len(hits))
    return hits[0]


def sub(prefix: str, new):
    i = one(prefix)
    lines[i] = new(lines[i]) if callable(new) else new


def after(prefix: str, extra: list):
    i = one(prefix)
    lines[i + 1:i + 1] = extra


sub("# VRN-2 交接報告 · ActivateVRN-2 v0132 · 2026-10-20(",
    "# VRN-2 交接報告 · ActivateVRN-2 v0133 · 2026-10-21(前後端連結:U/I 左側「輸入(window I/O)」→ vrn2://pick 開 Windows 對話框選檔案夾 / 檔案(pdf · word · txt · 影像)→ 稽核 → 當來源夾 · "
    "三類只開「個股報告/訊息」· vrn2:// 註冊讀回核對 · 貼包「註冊核對」· v0132:工具橋 v0101 借不到時說清楚下一步 · v0131:工具相互取用 · 四系統各自獨立 · VRN-2 主體一個位元組都不動)")
sub("> **本輪(v0132 · 工具橋 VRN2_ToolBridge_v0101", lambda l: (
    "> **操作員令(2026-10-21)**:「用vcgc的節省token工具來進行工作之後都是:做好啟動系統實測準備善用vcgc節省token工具進行最後一大修,檢查用ActivateVRN-2.ps1啟動前後端並連結"
    "讓使用者在html上用window i/o輸入檔案夾或檔案可以為pdf word txt image檔案夾 分為三種 個股報告/訊息 產業報告/展望 其他投資報告 現在進行的是個股報告/訊息其他功能關閉"
    "準備好測試無誤後留意是否都有註冊成功並上傳github github有無衝突問題一併解決 下一步換輸入檔案audit\"C:\\測試樣本報告\"」。\n"
    "> **本輪(v0133 · 啟動器 + U/I 處理器 VRN2_UIAction_v0103 · 交接報告 v0133 · 管理器鏈 / ENG397 / 摘要器 / 獨立驗證器 / 工具橋 / OCR 橋一個位元組都不動)**:"
    "① 前端 = `VIA_Reports\\vrn2\\VRN2_UI_latest.html`,後端 = vrn2:// 協定(HKCU)→ 處理器 v0103 → 啟動器;一鍵 ⑤b 檢查兩端有接上(HKCU 的指令解析成 python + 處理器 · 處理器整條路徑 = 本機 VRN-2 程式夾的 v0103 且檔在 · python 檔在 · U/I 有輸入區塊)· ⑤b 的燈併進最後 NEXT(Codex #550 修正)。"
    "② U/I 左側新區塊「輸入(window I/O)」:三類 radio(只有 個股報告/訊息 可選;產業報告/展望 · 其他投資報告 disabled「尚未開放」,處理器收到也拒絕)· "
    "📁 選擇檔案夾(`vrn2://pick?kind=folder&cat=stock` → Windows 原生資料夾對話框)· 📄 選擇檔案(`kind=files` → 多選 pdf / docx / doc / txt / png / jpg / jpeg / tif / tiff / bmp → 複製到 `VIA_Reports\\vrn2\\input_pick\\<時間>\\`)· "
    "🔎 重新稽核;選好 → 稽核(型別 · 個股範圍 / 範圍外 · 非 PDF)→ `VRN2_Input_latest.json` → 區塊更新 → 重開 U/I → 按「▶ 完整重跑」。"
    "③ 啟動器 ②b 輸入來源:`--source`(一鍵 `$env:VRN2_SOURCE`)> 環境 VIA_VRN_INPUT > U/I 選的 > VRN2_SSOT > 預設 `C:\\測試樣本報告`;來源不同就寫新一版 VRN2_SSOT(管理器 vrn2scope 讀它,管理器本身不動)。"
    "④ ⑥c vrn2:// 寫完讀回核對 · ⑫b ⑦ 重寫 U/I 之後把輸入區塊補回(同一塊不疊加)· 貼包多一行「註冊核對」(⑤ 元件登記 · ⑥c 協定 · ② 定位登記)。"
    "⑤ 非 PDF 照實記「已收下 · 本版主體只擷取 PDF」(ENG397 / 管理器 vrn2scope 只收 PDF,本輪不動主體);型別表與 ENG397 的 EXT 逐鍵核對。容器實測:%s\n" % R["e2e"]
    + l.replace("> **本輪(v0132", "> **前一輪(v0132", 1)))
sub("> **前一輪(v0131 · 啟動器 + 工具橋 VRN2_ToolBridge_v0100", lambda l: l.replace("> **前一輪(v0131", "> **v0131(", 1))
sub("| **啟動器(MAIN)** |", lambda l: l.replace("v0132", "v0133"))
after("| **工具橋** |", [
    "| **U/I 處理器** | `<ROOT>\\functional modules\\VRN\\VRN2_UIAction_v0103.py` | v0133 落地(v0102 照舊留著 · 只增不改)· `vrn2://pick?kind=folder|files&cat=stock`(Windows 原生對話框)· `vrn2://audit` · `--set-source` / `--refresh-ui`(啟動器 ②b / ⑫b 叫)· 進船包 |",
    "| **輸入紀錄** | `<ROOT>\\VIA_Reports\\vrn2\\VRN2_Input_latest.json`(+ `VRN2_Input_History.jsonl` 只增 · 多檔暫存 `input_pick\\<時間>\\`) | U/I 選的來源 + 稽核(型別 · 個股範圍 / 範圍外 · 非 PDF)· 啟動器 ②b 讀它當來源夾 · U/I 區塊顯示它 |",
])
sub("| U/I 處理器 / 協定 |", "| U/I 處理器 / 協定 | `…\\VRN\\VRN2_UIAction_v0103.py`(v0102 留著)+ `VRN2_UIAction_Config.json` · `HKCU\\Software\\Classes\\vrn2`(⑥c 寫完讀回核對) | 動作:run · run?nopush=1 · run-clean · restore-archive · **pick · audit** |")
sub("| **交接報告** |", lambda l: l.replace("VRN2_Handover_v0132.md", "VRN2_Handover_v0133.md"))
sub("| 本輪證據 |", lambda l: "| 本輪證據 | `<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0133\\`(v0132:`vrn2_release_v0132\\` · v0131:`vrn2_release_v0131\\` · v0130:一鍵判定)|" + l.split(")|", 1)[1])
sub("### 3.1 現役版本(v0132 內嵌", "### 3.1 現役版本(v0133 內嵌 · 依序自動落地)")
sub("| ActivateVRN-2.py | **v0132** |", "| ActivateVRN-2.py | **v0133** | 見發行清單 | 見發行清單(本檔內嵌在啟動器裡,不寫啟動器自己的雜湊)| 新(內嵌 U/I 處理器 v0103 · ②b 輸入來源 · ⑥c 讀回核對 · ⑫b U/I 輸入區塊 · 註冊核對 · 其餘流程同 v0132)|")
sub("| VRN2_UIAction · VRN2_OCRBridge · rule_catalog |",
    "| VRN2_UIAction · VRN2_OCRBridge · rule_catalog | **v0103**(v0102 留著)· v0100 · — | — | `%s` · `4b21f0694d0e` · `e5b881716c84` | **新**:處理器 v0103(vrn2://pick / audit · --set-source / --refresh-ui)· OCR 橋 / 規則目錄未變 |" % R["ua_sha12"])
sub("| **v0132** | 同 v0239 |", lambda l: l.replace("| **v0132** |", "| v0132 |", 1) + "\n| **v0133** | 同 v0239 | v0127 | v0114 | 前後端連結:U/I「輸入(window I/O)」區塊 · 處理器 v0103 · ②b 輸入來源 · ⑥c 讀回核對 · ⑫b · 註冊核對 |")
sub("## 7. 本輪修正(v0131 → v0132 · 借不到時說清楚下一步)",
    "## 7. 本輪修正(v0132 → v0133 · 前後端連結 · U/I window I/O 輸入)\n\n"
    "| # | 需求 / 發現 | 做法 | 實測 |\n|---|---|---|---|\n"
    "| 1 | 用 ActivateVRN-2.ps1 啟動前後端並連結 | 一鍵 v0133 = 取得啟動器 → 執行 ①~⑫(前端 U/I · 後端 vrn2:// 處理器 + 啟動器)→ **⑤b 連結檢查**(HKCU 的 vrn2:// 解析成 python + 處理器 · 處理器整條路徑 = 本機 VRN-2 程式夾的 `VRN2_UIAction_v0103.py` 且檔在 · python 檔在 · U/I 有輸入區塊 · 印目前輸入與稽核 · **燈併進最後 NEXT**:紅 → 紅 · 黃 → 最多黃)· `$env:VRN2_SOURCE` 直接指定來源夾 | %s |\n"
    "| 2 | 在 HTML 上用 window I/O 輸入檔案夾或檔案(pdf / word / txt / image / 檔案夾)| 處理器 v0103:`vrn2://pick` 開 Windows 原生對話框(FolderBrowserDialog / OpenFileDialog 多選 · STA · tkinter 備援)· 多檔複製到暫存夾 · 稽核 · `VRN2_Input_latest.json` · U/I 區塊更新 · 重開 U/I | 處理器自測 %s |\n"
    "| 3 | 分三種:個股報告/訊息 · 產業報告/展望 · 其他投資報告;現在只做個股,其他關閉 | U/I 三個 radio(只有個股可選 · 另外兩類 disabled「尚未開放」)· 處理器收到 cat=industry / other 一律拒絕(rc 3)· 稽核的「範圍外」= 管理器 v0231 同一條檔名規則 + 上輪判定 | U/I 真瀏覽器 %s |\n"
    "| 4 | 選好的輸入要真的被用到 | 啟動器 ②b:U/I 選的 → 寫新一版 VRN2_SSOT(只增)→ 管理器 vrn2scope 讀它(管理器不動)· 貼包第一段就印來源與稽核 | 沙盒:選子集 6 PDF → ⑥b 範圍夾只剩 5 份 · 選 2 PDF + 1 txt → 來源 = 暫存夾(見 §6)|\n"
    "| 5 | 留意是否都有註冊成功 | ⑥c vrn2:// 寫完讀回核對(不同 → 黃)· 貼包「註冊核對」一行(⑤ 元件登記 · ⑥c 協定 · ② 定位登記)· NEXT 未全綠會說 | 啟動器自測 %s |\n"
    "| 6 | 非 PDF(word / txt / 影像)| 對話框與稽核都收;主體(ENG397 / vrn2scope)只擷取 PDF → 照實記「已收下 · 本版主體只擷取 PDF」,不假裝有處理;要真的擷取 Word / TXT / 影像是主體的下一輪 | 稽核行:非 PDF n(已收下 · 本版主體只擷取 PDF)|\n"
    "| 7 | Codex #550(P1 / P2):一鍵最後的燈沒把 ⑤b 算進去(vrn2:// 沒註冊也 GREEN / rc 0)· 處理器只比檔名(舊的 / 搬走的檢出也算接上)| ⑤b 併進 NEXT(紅 → 紅 · 黃 → 最多黃 · GREEN / rc 0 只在前後端真的接上 + 有輸入紀錄)· HKCU 指令解析成 python + 處理器 · 整條路徑正規化後比對 + 檔在(或那一夾有啟動器本輪寫的 `VRN2_UIAction_Config.json` v0133)· python 檔在 · 訊息寫明要的是哪一條路徑 | %s |\n"
    "| 8 | Codex #551(P2 ×2):一行(boot)的早退 `return` 讓 rc 變 0 · ⑤b 沒檢查 `\"%%1\"` | boot 三個紅燈 `exit 1` · 一鍵四個早退紅燈先設 `$global:LASTEXITCODE = 1` · ③ 缺 zip / 發行冊 → 紅燈 · boot `try / catch` 例外 → RED rc 1;`Chk5b` 第三段必須是 `%%1` 才綠 | %s |\n"
    "| 9 | 操作員 Windows 實跑(C:\\測試樣本報告):U/I 沒跳出來 —— VIA 的 PS 設定檔把 `VIA_NO_OPEN=1` 設在環境,啟動器尊重它 | 一鍵跑啟動器前拿掉 `VIA_NO_OPEN`(結束還原)· 啟動器紀錄仍寫「沒有自動開啟」就 ⑤c 一鍵 `Start-Process` 開 U/I · `$env:VRN2_NO_UI = 1` 才不開 | %s |\n\n"
    "## 7.0b v0131 → v0132(借不到時說清楚下一步)" % (R["oneclick"], R["selftest_ua"], R["ui"], R["selftest"], R["codex550"], R["codex551"], R["windows_run"]))
sub("| 0 | **使用者用 v0132 的一行跑**",
    "| 0 | **使用者用 v0133 的一行跑**(`vrn2_release_v0133/VRN2_OneClick_v0133.md` · 可存成 `ActivateVRN-2.ps1`)| **已執行 2026-10-21 13:06(C:\\測試樣本報告 · 534 檔 · 個股 55 · ②b / ⑥c / ⑤b / 註冊核對全綠 · ⑦ 綠 44 黃 11 紅 0 · ⑪ 黃 106 筆待核對 · U/I 沒自動開 → ⑤c 修)** | 預期:②b 輸入來源 綠(預設 `C:\\測試樣本報告` 或 `$env:VRN2_SOURCE`)· ⑥c vrn2:// 讀回核對相同 · ⑫b U/I 輸入區塊 · ⑤b 前後端已連結(整條路徑 · 檔在)· NEXT 綠(⑤b 不綠 NEXT 就不綠);"
    "然後在 U/I 按「📁 選擇檔案夾…」選 `C:\\測試樣本報告` → 區塊顯示稽核 → 「▶ 完整重跑」。貼回 ②b / ⑥c / ⑫b / 註冊核對 / ⑤b 幾行。 |")
sub("一鍵(取得 v0132 → 驗雜湊", "一鍵(取得 v0133 → 驗雜湊 → ③b 定位 → 執行(啟動器自己跑 ①~⑫ · 開 U/I)→ 摘要 → 印驗證摘要 → ⑤b 前後端連結檢查 → NEXT 燈 = ⑧ + 獨立驗證 + ⑤b):`docs/handoff/ai/vrn2_release_v0133/VRN2_OneClick_v0133.md`(= ActivateVRN-2.ps1)")
after("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)", [
    "",
    "- **GitHub 衝突與分支的交接**(2026-10-21 · PR #550 在 Codex 修正推上前就被合併 → 修正改走 PR #551;不改寫歷史、不強推、每次推之前先 `git fetch origin main` + `git merge-tree` 核對 0 衝突):詳細時間線、檢查方法、其他開著的 PR 狀態與規則見 `docs/handoff/ai/VRN2_GitHub_ConflictHandover_20261021.md`。",
    "- **前後端連結是可驗的,不是假設的**:前端 = U/I 檔,後端 = vrn2:// 協定 + 處理器 + 啟動器;每次都要讀回 HKCU 核對註冊指向目前的處理器、U/I 檔裡要有輸入區塊,兩樣都在才叫「已連結」;**核對整條路徑不只檔名**(別的檢出 / 搬走的 / 不存在的處理器 → 紅)· **⑤b 的燈併進一鍵最後的 NEXT**(⑤b 紅 → NEXT 紅 · 黃 → 最多黃;vrn2:// 沒註冊就不能 GREEN / rc 0 —— Codex #550)。",
    "- **輸入只從對話框與啟動器寫的設定來**:處理器不從網址讀路徑;U/I 選的落在 `VRN2_Input_latest.json`,啟動器 ②b 讀它寫 VRN2_SSOT,管理器照常讀 VRN2_SSOT —— 主體不動。",
    "- **三類只開個股**:產業報告/展望 · 其他投資報告 在 U/I disabled、處理器拒絕;要開放是主體(範圍 / 擷取 / 驗證)的工作,不是把 radio 打開。",
    "- **非 PDF 不假裝處理**:對話框收 word / txt / 影像,稽核照實記「本版主體只擷取 PDF」;真的擷取要改 ENG397 與 vrn2scope(下一輪)。",
])
out.write_text("\n".join(lines), encoding="utf-8", newline="\n")
print("[計] %s · %d 字" % (out.name, sum(len(l) for l in lines)))
