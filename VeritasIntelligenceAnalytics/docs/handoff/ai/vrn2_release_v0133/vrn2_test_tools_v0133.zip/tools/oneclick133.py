"""一鍵 v0133:Run-VRN2-v0133.ps1(由 v0132 換版號 + ⑤b 前後端連結檢查 + $env:VRN2_SOURCE → --source)+ VRN2_OneClick_v0133.md + boot133.ps1 + oneline133.txt(冪等)。
用法:python oneclick133.py <ActivateVRN-2 v0133 SHA-256> <輸出夾>"""
import base64
import hashlib
import re
import sys
from pathlib import Path

W = "/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v132/release132/"
want, out = sys.argv[1], Path(sys.argv[2])
assert re.fullmatch(r"[0-9a-f]{64}", want)
out.mkdir(parents=True, exist_ok=True)
ps = open(W + "Run-VRN2-v0132.ps1", encoding="utf-8").read().rstrip("\n")
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1)
ps = ps.replace(old_want, want)
n132 = ps.count("v0132")
ps = ps.replace("v0132", "v0133")


def rep(a, b):
    global ps
    assert ps.count(a) == 1, (ps.count(a), a[:80])
    ps = ps.replace(a, b)


rep("# ===== VRN-2 一鍵 v0133(啟動器 v0133 · 工具橋 v0101:借不到 VRN-1 的工具時說清楚下一步 · VRN-1 / VRN-2 / VDF / VCGC 各自獨立)",
    "# ===== VRN-2 一鍵 v0133(啟動器 v0133 · 前後端連結:U/I 左側「輸入(window I/O)」→ vrn2://pick 開 Windows 對話框選檔案夾 / 檔案(pdf · word · txt · 影像)→ 稽核 → 當來源夾 · "
    "三類只開「個股報告/訊息」· ⑤b 檢查 vrn2:// 註冊與 U/I 區塊 · $env:VRN2_SOURCE 直接指定來源夾)· v0132(工具橋 v0101:借不到 VRN-1 的工具時說清楚下一步 · VRN-1 / VRN-2 / VDF / VCGC 各自獨立)")
rep("  $LArgs  = @(); if ($env:VRN2_LAUNCHER_ARGS) { $LArgs = $env:VRN2_LAUNCHER_ARGS -split ' ' }   # 例:--no-install\n",
    "  $LArgs  = @(); if ($env:VRN2_LAUNCHER_ARGS) { $LArgs = $env:VRN2_LAUNCHER_ARGS -split ' ' }   # 例:--no-install\n"
    "  if ($env:VRN2_SOURCE) { $LArgs += @('--source', $env:VRN2_SOURCE) }                        # v0133 直接指定來源夾(例:C:\\測試樣本報告)· 沒設就用 U/I 選的 / VRN2_SSOT / 預設\n")
rep("    $d = [int]((Get-Date) - $t0).TotalSeconds\n",
    "    # ⑤b 前後端連結檢查(v0133):vrn2:// 註冊(HKCU)指向處理器 v0103 · U/I 有「輸入(window I/O)」區塊(三類 · 只開個股)· 目前輸入與稽核(VRN2_Input_latest.json)\n"
    "    $v2p = [IO.Path]::Combine($R, 'VIA_Reports', 'vrn2'); $uiP = Join-Path $v2p 'VRN2_UI_latest.html'\n"
    "    $regCmd = ''; try { $regCmd = [string](Get-ItemProperty -Path 'HKCU:\\Software\\Classes\\vrn2\\shell\\open\\command' -ErrorAction Stop).'(default)' } catch { }\n"
    "    $hOk = $regCmd -match 'VRN2_UIAction_v0103\\.py'\n"
    "    $uiTxt = if (Test-Path -LiteralPath $uiP) { [IO.File]::ReadAllText($uiP, [Text.Encoding]::UTF8) } else { '' }\n"
    "    $blkOk = ($uiTxt -match \"id='vrn2-input'\") -and ($uiTxt -match '個股報告/訊息') -and ($uiTxt -match '產業報告/展望') -and ($uiTxt -match '其他投資報告') -and ($uiTxt -match 'vrn2://pick\\?kind=folder')\n"
    "    $inpP = Join-Path $v2p 'VRN2_Input_latest.json'; $inp = $null; try { $inp = Get-Content -Raw -Encoding UTF8 -LiteralPath $inpP | ConvertFrom-Json } catch { }\n"
    "    if ($hOk -and $blkOk) { Say GREEN '⑤b 前後端已連結:vrn2:// → VRN2_UIAction_v0103.py(讀回核對)· U/I 有「輸入(window I/O)」區塊(個股報告/訊息 可選 · 產業報告/展望 / 其他投資報告 尚未開放)' }\n"
    "    elseif ($blkOk -and -not $regCmd) { Say YELLOW '⑤b U/I 有輸入區塊,但 vrn2:// 沒註冊(HKCU)→ 按鈕不會有反應;在 Windows 重跑一次啟動器(⑥c 會註冊)或用 $env:VRN2_SOURCE' }\n"
    "    else { Say RED ('⑤b 前後端沒接上:vrn2:// 註冊 {0} · U/I 輸入區塊 {1}' -f $(if ($hOk) { '指向 v0103' } elseif ($regCmd) { '指向舊處理器 ' + $regCmd } else { '沒有' }), $(if ($blkOk) { '在' } else { '不在' })) }\n"
    "    if ($inp) { Say GREEN ('⑤b 目前輸入 · {0} · {1}({2})· {3}' -f $inp.cat_label, $inp.source_dir, $inp.how, $inp.audit_line) } else { Say YELLOW '⑤b 沒有輸入紀錄(VRN2_Input_latest.json)· 啟動器 ②b 沒跑到' }\n"
    "    $d = [int]((Get-Date) - $t0).TotalSeconds\n")
rep("GREEN = 'VRN-2 一鍵 v0133 跑完 · ⑧ 本輪完成 · 獨立驗證錯值 0 · U/I 已開在「驗證過的輸出」(最後有 PIVOT 資料庫連結)",
    "GREEN = 'VRN-2 一鍵 v0133 跑完 · ⑧ 本輪完成 · 獨立驗證錯值 0 · U/I 已開在「驗證過的輸出」(最後有 PIVOT 資料庫連結 · 左側「輸入」可選檔案夾 / 檔案 · 目前只開個股報告/訊息)")
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = open(W + "boot132.ps1", encoding="utf-8").read()
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1)
boot = boot.replace(h_old, cs).replace("v0132", "v0133")
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii")
assert len(one) < 8191, len(one)
md = """# VRN-2 一鍵 v0133(cmd / PowerShell 都能貼 · 啟動器 v0133 · 前後端連結 · U/I 用 window I/O 選輸入)

v0133 = 操作員令(2026-10-21)「用 ActivateVRN-2.ps1 啟動前後端並連結 · 讓使用者在 HTML 上用 window I/O 輸入檔案夾或檔案(pdf / word / txt / image / 檔案夾)·
分三種:個股報告/訊息 · 產業報告/展望 · 其他投資報告 · 現在進行的是個股報告/訊息,其他功能關閉 · 留意是否都有註冊成功」。
啟動器 `ActivateVRN-2.py` **v0133**(SHA-256 `@WANT@` · 從 `vrn2_release_v0133` 取)。這份程式碼就是操作員說的 **ActivateVRN-2.ps1**:
存成 `ActivateVRN-2.ps1` 跑也可以;貼進 PowerShell 跑也可以;下面那一行(cmd 也能貼)會從 GitHub 讀本檔再核對 SHA-256 才執行。

| 步驟 | v0133 改了什麼 |
|---|---|
| ③ / ④ | 取得啟動器 v0133(雜湊核對)→ 執行 ①~⑫(前端 = `VIA_Reports\\vrn2\\VRN2_UI_latest.html` · 後端 = vrn2:// 協定處理器 `VRN2_UIAction_v0103.py` + 啟動器)|
| ②b(啟動器)| 輸入來源:`$env:VRN2_SOURCE` / `--source` > U/I 選的 `VRN2_Input_latest.json` > `VRN2_SSOT` 來源夾 > 預設 `C:\\測試樣本報告`;寫新一版 VRN2_SSOT(管理器不動)· 稽核(PDF / Word / TXT / 影像 · 個股範圍 / 範圍外)|
| ⑥c(啟動器)| vrn2:// 註冊到 HKCU 指向處理器 v0103 · **寫完讀回核對** |
| ⑫b(啟動器)| U/I 左側多一塊「輸入(window I/O)」:三類(只有 個股報告/訊息 可選 · 另外兩類灰掉「尚未開放」)· 📁 選擇檔案夾 · 📄 選擇檔案(pdf / word / txt / 影像)· 🔎 重新稽核 |
| ⑤b(本一鍵)| 前後端連結檢查:HKCU 的 vrn2:// 指向 v0103 · U/I 有輸入區塊 · 印目前輸入與稽核 |

在 U/I 上的用法:左側「輸入」→ 📁 選擇檔案夾…(Windows 對話框)→ 選 `C:\\測試樣本報告` → 區塊立刻顯示稽核 → 按「▶ 完整重跑」。
非 PDF(word / txt / 影像)會被收下並照實記「本版主體只擷取 PDF」(不假裝有處理);產業報告/展望 · 其他投資報告 兩類關閉(處理器也拒絕)。
VRN-2 主體(管理器鏈 v0231 → v0239 · ENG397 · 摘要器 · 獨立驗證器 · 工具橋 v0101 · OCR 橋)**一個位元組都不動**;新增處理器 v0103(v0102 留著)。

開關:`$env:VRN2_SOURCE = 'C:\\測試樣本報告'` 直接指定來源夾 · 檔頭 `$NoPush = $true` 只實測不上船 · `$Verify = $false` 啟動器沒驗到時 PS 也不補驗 · `$env:VIA_VRN2_NO_VERIFY = '1'` 不跑 ⑪ · `$env:VIA_VRN2_NO_BORROW = '1'` ⑫ 不借 VRN-1。

## 在「命令提示字元(cmd)」或 PowerShell 都能貼的一行(建議用這個)

這一行在 cmd 或 PowerShell 貼上都可以:它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)讀本檔的一鍵程式碼 → **核對 SHA-256** → 才執行(不改任何檔 · 不切換分支)。

```bat
@ONE@
```

或:在 cmd 先輸入 `powershell` 按 Enter(提示字元變成 `PS C:\\Users\\tonyk>`),再貼下面整段程式碼(或存成 `ActivateVRN-2.ps1` 後 `powershell -ExecutionPolicy Bypass -File ActivateVRN-2.ps1`)。

程式碼 SHA-256(本文 · 一行核對的就是這個):`@CS12@`

```powershell
@PS@
```

## 一行的原始碼(`-EncodedCommand` 解碼後 · 只讀取並核對 · 不改任何檔)

```text
@BOOT@
```
"""
md = md.replace("@WANT@", want).replace("@CS12@", cs[:12]).replace("@CS@", cs).replace("@ONE@", one).replace("@BOOT@", boot.rstrip("\n")).replace("@PS@", ps)
assert re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) == ps and md.count("```powershell\n") == 1
assert base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot
assert re.search(r"(?s)```text\n(.*?)\n```", md).group(1) == boot.rstrip("\n")
(out / "VRN2_OneClick_v0133.md").write_text(md, encoding="utf-8", newline="\n")
(out / "boot133.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline133.txt").write_text(one + "\n", encoding="utf-8")
(out / "Run-VRN2-v0133.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
(out / "ActivateVRN-2.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("launcher %s · code %s · one-liner %d 字 · md %d · 換版號 %d 處" % (want[:12], cs[:12], len(one), len(md), n132))
