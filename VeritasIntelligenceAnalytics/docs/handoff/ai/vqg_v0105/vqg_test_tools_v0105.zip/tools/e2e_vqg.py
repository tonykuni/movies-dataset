"""VQG v0105 端到端(容器 · 零網路):
A. 用 VDF 自己的寫檔程式(ENG054 TWDailyBackfill v0100 的 write_parquet / upsert_duckdb · OUT 指到沙盒)產生 VDF 資料庫 →
   兩個批次(第二批把舊日還原價重算 = 除權息後)→ VQG doctor / 嚴格 / auto / auto+latest / closeout。
B. VDF CentralHub 形狀的樣本(VAP sim_vdf 的副本)→ doctor / calc NVDA / closeout。
每段都核對:VQG 沒在 VDF 庫裡多寫或改任何檔(檔名 + 大小 + mtime 前後相同)。"""
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

PY = sys.argv[1]
WORK = Path(sys.argv[2])
PY_GEN = sys.argv[3]
VQG = Path("/home/user/vrn2_work/vqg/VQG_AllInOne_v0105.py")
ENG054 = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VDF/engine/VDF_ENG054_TWDailyBackfill_v0100.py")
SIM = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VAP/VeritasAutoPlot_v42_EcoSystem/temp/sim_vdf/output")
if WORK.exists():
    shutil.rmtree(WORK)
WORK.mkdir(parents=True)
res = {}


def snap(root):
    return {str(p.relative_to(root)): (p.stat().st_size, p.stat().st_mtime_ns) for p in sorted(root.rglob("*")) if p.is_file()}


def vqg(*args, via=None):
    cmd = [PY, "-I", str(VQG)] + [str(a) for a in args] + (["--via-root", str(via)] if via else [])
    t0 = time.time()
    p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", timeout=600, cwd=str(WORK))
    return {"rc": p.returncode, "s": round(time.time() - t0, 2), "out": p.stdout[-2500:], "err": p.stderr[-800:]}


# ── A. VDF 自己的寫檔程式產生資料庫(另一支 Python:要 pyarrow 才寫 parquet · 沒有會退成 CSV)──
vdfA = WORK / "A_vdf_database"
from datetime import date, timedelta  # noqa: E402
d0 = date(2026, 6, 1)
g = subprocess.run([PY_GEN, "-I", str(Path(__file__).with_name("gen_vdf_A.py")), str(ENG054), str(vdfA)], capture_output=True, text=True, encoding="utf-8", timeout=300)
res["A_gen"] = {"rc": g.returncode, "s": 0, "out": g.stdout[-600:], "err": g.stderr[-600:]}
res["A_vdf_files"] = sorted(str(p.relative_to(vdfA)) for p in vdfA.rglob("*") if p.is_file())
viaA = WORK / "A_VIA"
(viaA / "functional modules" / "VDF").mkdir(parents=True)
(viaA / "supportive modules").mkdir()
(viaA / "functional modules" / "VDF" / "VDF_DataHome_SSOT_v0101.json").write_text(json.dumps({"homes": [{"id": "workstation", "db_home": str(vdfA)}]}), encoding="utf-8")
before = snap(vdfA)
asof = (d0 + timedelta(days=170)).isoformat()
res["A_doctor"] = vqg("doctor", "--root", vdfA)
res["A_strict"] = vqg("calc", "--root", vdfA, "--ticker", "2330.TW", "--metrics", "sma", "rsi", "--as-of", asof)
res["A_auto"] = vqg("calc", "--root", vdfA, "--ticker", "2330.TW", "--metrics", "sma", "rsi", "--as-of", asof, "--calendar", "auto")
res["A_auto_latest"] = vqg("calc", "--root", vdfA, "--ticker", "2330.TW", "--metrics", "sma", "rsi", "macd", "--as-of", asof, "--calendar", "auto", "--snapshots", "latest")
res["A_halt_2317"] = vqg("calc", "--root", vdfA, "--ticker", "2317.TW", "--metrics", "sma", "--windows", "20", "--as-of", asof, "--calendar", "derive", "--snapshots", "latest")
res["A_closeout"] = vqg("closeout", "--as-of", asof, via=viaA)                          # 不給 --root → 照 VDF 的冊
res["A_vdf_untouched"] = snap(vdfA) == before
res["A_receipt"] = json.loads((viaA / "VIA_Reports" / "vqg" / "VQG_Closeout_latest.json").read_text(encoding="utf-8"))
# ── B. VDF CentralHub 樣本 ─────────────────────────────────────────────────
vdfB = WORK / "B_vdf_sim"
shutil.copytree(SIM, vdfB)
beforeB = snap(vdfB)
viaB = WORK / "B_VIA"
(viaB / "functional modules").mkdir(parents=True)
(viaB / "supportive modules").mkdir()
res["B_doctor"] = vqg("doctor", "--root", vdfB)
res["B_strict_NVDA"] = vqg("calc", "--root", vdfB, "--ticker", "NVDA", "--metrics", "sma", "--as-of", "2023-11-01")
res["B_auto_NVDA"] = vqg("calc", "--root", vdfB, "--ticker", "NVDA", "--metrics", "sma", "rsi", "macd", "bollinger", "--as-of", "2023-11-01", "--calendar", "auto")
res["B_closeout"] = vqg("closeout", "--root", vdfB, "--ticker", "TSM", "--as-of", "2023-11-01", via=viaB)
res["B_vdf_untouched"] = snap(vdfB) == beforeB
res["B_receipt"] = json.loads((viaB / "VIA_Reports" / "vqg" / "VQG_Closeout_latest.json").read_text(encoding="utf-8"))
(WORK / "e2e_vqg.json").write_text(json.dumps(res, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
for k, v in res.items():
    if isinstance(v, dict) and "rc" in v:
        last = [l for l in (v["out"] + v["err"]).splitlines() if l.strip()]
        print("%-16s rc %s · %5.2fs · %s" % (k, v["rc"], v["s"], (last[-1] if last else "")[:230]))
    elif k.endswith("_receipt"):
        print("%-16s lamp %s · %s" % (k, v["lamp"], [(s["step"][:18], s["lamp"]) for s in v["steps"]]))
    else:
        print("%-16s %s" % (k, v if not isinstance(v, list) else v[:6]))
