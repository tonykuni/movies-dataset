"""用 VDF ENG054 TWDailyBackfill v0100 自己的 write_parquet / upsert_duckdb(OUT 指到沙盒)產生兩個批次的 VDF 日線庫。"""
import importlib.util, sys, time
from datetime import date, timedelta
from pathlib import Path
eng_path, root = Path(sys.argv[1]), Path(sys.argv[2])
spec = importlib.util.spec_from_file_location("vdf_eng054_for_vqg_e2e", eng_path)
eng = importlib.util.module_from_spec(spec); spec.loader.exec_module(eng)
eng.OUT = root / "output_hub" / "mega"; eng.DB_TW = eng.OUT / "vdf_tw_market.duckdb"
d0 = date(2026, 6, 1)
def bars(tk, base, n=160, skip=(), revise=None):
    out = []
    for i in range(n):
        if i in skip:
            continue
        p = round(base + 0.25 * i + 1.5 * ((i * 7) % 5 - 2), 2)
        adj = round(p * (revise.get(i, 1.0) if revise else 1.0), 4)
        out.append({"date": (d0 + timedelta(days=i)).isoformat(), "ticker": tk, "open": p, "high": p + 1, "low": p - 1, "close": p, "adj_close": adj, "volume": 1000.0 + i})
    return out
b1 = bars("2330.TW", 600) + bars("2317.TW", 120, skip=(150,)) + bars("0050.TW", 150)
print(eng.write_parquet(b1, "tw_daily_prices").name, eng.upsert_duckdb("tw_daily_prices", b1, ["date", "ticker"]))
time.sleep(1.2)
b2 = bars("2330.TW", 600, revise={i: 0.98 for i in range(140)}) + bars("2317.TW", 120, skip=(150,)) + bars("0050.TW", 150)
print(eng.write_parquet(b2, "tw_daily_prices").name, eng.upsert_duckdb("tw_daily_prices", b2, ["date", "ticker"]))
