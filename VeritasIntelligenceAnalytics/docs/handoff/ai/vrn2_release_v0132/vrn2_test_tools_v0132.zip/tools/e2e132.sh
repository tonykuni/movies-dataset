#!/bin/bash
# v0132 e2e:沙盒樹 · 啟動器 v0132 · A:VRN-1 = /home/user/via-vdf-vrn(工具冊在)+ 真的 OCR 隔離環境 · 跑兩次(冪等)
#            B:VRN-1 = main 的工作樹(沒有工具冊)→ ⑫ 灰 + git switch 指令 · C:VIA_VRN2_NO_BORROW=1 → ⑫ 不借 · VRN-2 照常完成
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v132; T=$W/t132
OCRPY=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/bin/python
OCRBR=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/VRN2_OCRBridge_v0100.py
: > $W/e2e.rc
cd /tmp && $S/tools/mktree.sh $T $W/ActivateVRN-2_v0132.py > $W/e2e_setup.log 2>&1
go() {   # $1 = 名稱 · $2 = VRN-1 倉 · $3 = 借不借
  cd "$T/Downloads" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VIA_VRN_INPUT="$T/samples" VIA_ENVS_HOME="$T/envs" \
    VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$OCRBR" PYTHONDONTWRITEBYTECODE=1 VIA_VRN1_ROOT="$2" VIA_VRN2_NO_BORROW="$3" \
    timeout 3500 $S/venv_vrn2/bin/python ActivateVRN-2.py --no-install > $W/e2e_$1.log 2>&1
  echo "$1 rc $?" >> $W/e2e.rc
  sed -i 's/\x1b\[[0-9;]*m//g' $W/e2e_$1.log
}
go A1 /home/user/via-vdf-vrn ""
go A2 /home/user/via-vdf-vrn ""
cp -r "$T/VIA/VIA_Reports/vrn2/tools" $W/tools_manifest_A 2>/dev/null
go B $W/vrn1_main ""
go C /home/user/via-vdf-vrn 1
echo done >> $W/e2e.rc
