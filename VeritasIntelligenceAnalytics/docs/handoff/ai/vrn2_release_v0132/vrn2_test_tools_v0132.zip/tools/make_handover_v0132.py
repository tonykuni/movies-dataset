"""VRN2_Handover_v0132.md = v0131 交接報告 + v0132(工具橋 v0101 · 借不到時說清楚下一步)· 錨點替換 · 冪等。
用法:python make_handover_v0132.py <v0131.md> <結果 json> <輸出 md>
結果 json:{"e2e": "...", "vrn1": "...", "facilitate": "...", "independence": "..."}(容器實測數字)"""
import json
import sys
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src.read_text(encoding="utf-8")
R = json.loads(res_p.read_text(encoding="utf-8"))


def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80])
    s = s.replace(a, b)


rep("# VRN-2 交接報告 · ActivateVRN-2 v0131 · 2026-10-20(工具相互取用:VRN-2 借 VRN-1 的 PIVOT 資料庫工具 ⑫ · 借出段落標題 / OCR 給 VRN-1 · 兩個獨立 MAIN · v0129:並排表的段落標題改回同一欄)",
    "# VRN-2 交接報告 · ActivateVRN-2 v0132 · 2026-10-20(工具橋 v0101:借不到 VRN-1 的工具時說清楚下一步 · v0131:工具相互取用(⑫ 借 VRN-1 的 PIVOT · 借出段落標題 / OCR)· 四系統各自獨立、各有 MAIN)")
rep("> **本輪(v0131 · 啟動器 + 工具橋 VRN2_ToolBridge_v0100 · 管理器鏈 / ENG397 / 摘要器 / 驗證器 / 處理器一個位元組都不動)**",
    "> **操作員重申(2026-10-20)**:「重申VCGC VRN-1  VRN-2 VDF皆是獨立系統有獨立的MAIN獨立運作互不影響」→ 工具相互取用只在執行時**讀**對方的工具冊與檔(逐檔核對 sha256),"
    "不改、不複製、不寫對方的夾;對方不在 / 沒有工具冊 / 檔換過 → 各自只用自己的工具照常跑完(灰 / 黃,不是紅)。容器實測兩邊各自單獨跑:%s\n"
    "> **操作員令(2026-10-20)**:「用中文回復 一路實測修復到底 TEST DEBUG OPTIMIZE … FACILITATE … USER-TEST … ACTIVATE … TILL THEY WORKS PERFECTLY. 授權全自動完成」。\n"
    "> **本輪(v0132 · 工具橋 VRN2_ToolBridge_v0101 · 交接報告 v0132 · 啟動器流程 ①~⑫ 與 VRN-2 主體一個位元組都不動)**:%s ② VRN-1 這邊(另一團隊的倉 · VRN-1 自己的 MAIN):%s\n"
    "> **前一輪(v0131 · 啟動器 + 工具橋 VRN2_ToolBridge_v0100 · 管理器鏈 / ENG397 / 摘要器 / 驗證器 / 處理器一個位元組都不動)**" % (R["independence"], R["facilitate"], R["vrn1"]))
rep("> **前一輪(v0129 · 邊測邊修:管理器 v0239 · 獨立驗證器 v0102 · 啟動器邏輯同 v0128)**", "> **v0129(邊測邊修:管理器 v0239 · 獨立驗證器 v0102 · 啟動器邏輯同 v0128)**")
rep("| **啟動器(MAIN)** | `C:\\Users\\tonyk\\Downloads\\ActivateVRN-2.py` | **v0131** · 雜湊見 `docs/handoff/ai/vrn2_release_v0131/VRN2_Release_v0131.json` · 一鍵:`vrn2_release_v0131/VRN2_OneClick_v0131.md`",
    "| **啟動器(MAIN)** | `C:\\Users\\tonyk\\Downloads\\ActivateVRN-2.py` | **v0132** · 雜湊見 `docs/handoff/ai/vrn2_release_v0132/VRN2_Release_v0132.json` · 一鍵:`vrn2_release_v0132/VRN2_OneClick_v0132.md`")
rep("| **工具橋** | `<ROOT>\\functional modules\\VRN\\VRN2_ToolBridge_v0100.py` | v0131 落地 · 借出 `section.near` / `ocr.image` · 借入 VRN-1 `table.pivot_db` · 進船包 |",
    "| **工具橋** | `<ROOT>\\functional modules\\VRN\\VRN2_ToolBridge_v0101.py` | v0132 落地(v0131 落的 `VRN2_ToolBridge_v0100.py` 照舊留著 · 只增不改)· 借出 `section.near` / `ocr.image` · 借入 VRN-1 `table.pivot_db` · 進船包 |")
rep("VRN-1 的 `build` 寫 · **操作員套用 VRN-1 的 patch 之後才有**(沒有 → ⑫ 灰「借不到」· VRN-2 照常)",
    "VRN-1 的 `build` 寫 · **VRN-1 倉 `claude/optimistic-goodall-yhalc5` 分支(PR tonykuni/VIA-VDF-VRN#79)起才有**(沒有 → ⑫ 灰「借不到」並印出 `git switch` 指令 · VRN-2 照常)")
rep("| **交接報告** | `<ROOT>\\docs\\handoff\\ai\\VRN2_Handover_latest.md`(+ `VRN2_Handover_v0131.md`) |",
    "| **交接報告** | `<ROOT>\\docs\\handoff\\ai\\VRN2_Handover_latest.md`(+ `VRN2_Handover_v0132.md`) |")
rep("| 本輪證據 | `<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0131\\`(v0130:一鍵判定 · v0129:`vrn2_release_v0129\\` · v0128:`vrn2_release_v0128\\`)|",
    "| 本輪證據 | `<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0132\\`(v0131:`vrn2_release_v0131\\` · v0130:一鍵判定 · v0129:`vrn2_release_v0129\\`)|")
rep("### 3.1 現役版本(v0131 內嵌 · 依序自動落地)", "### 3.1 現役版本(v0132 內嵌 · 依序自動落地)")
rep("| ActivateVRN-2.py | **v0131** | 見發行清單 | 見發行清單(本檔內嵌在啟動器裡,不寫啟動器自己的雜湊)| 新(② 借出工具冊 · ⑫ 借 VRN-1 PIVOT · U/I 連結 · 其餘邏輯同 v0129)|",
    "| ActivateVRN-2.py | **v0132** | 見發行清單 | 見發行清單(本檔內嵌在啟動器裡,不寫啟動器自己的雜湊)| 新(內嵌工具橋 v0101 · 交接報告 v0132 · 流程與 v0131 相同)|")
rep("| **VRN2_ToolBridge** | **v0100** | 見發行清單 | 見發行清單 | **新**(工具橋 · 不 import VRN-1 程式 · 借的時候依工具冊路徑載入 · sha256 核對)|",
    "| **VRN2_ToolBridge** | **v0101** | 見發行清單 | 見發行清單 | **新**(= v0100 + 借不到時說清楚下一步 · 借用規則不變)· v0100(v0131)照舊留著 |")
rep("| **v0131** | 同 v0239 | v0127 | v0114 | 工具相互取用:② 借出工具冊 · ⑫ 借 VRN-1 PIVOT 資料庫 · 工具橋 v0100 |",
    "| v0131 | 同 v0239 | v0127 | v0114 | 工具相互取用:② 借出工具冊 · ⑫ 借 VRN-1 PIVOT 資料庫 · 工具橋 v0100 |\n"
    "| **v0132** | 同 v0239 | v0127 | v0114 | 工具橋 v0101:借不到 VRN-1 的工具時說清楚下一步 |")
rep("## 7. 本輪修正(v0129 → v0131 · 工具相互取用)",
    "## 7. 本輪修正(v0131 → v0132 · 借不到時說清楚下一步)\n\n"
    "| # | 需求 / 發現 | 做法 | 實測 |\n|---|---|---|---|\n"
    "| 1 | FACILITATE:VRN-1 的倉在、但那一版沒有工具冊(VRN-1 main 還沒合併第十三輪)→ v0131 的 ⑫ 只說「找不到 VRN-1 的工具冊」,沒說要做什麼 | 工具橋 v0101 找 VRN-1 時記下「有 `functional modules\\VRN\\VRN_Main_v0100.py` 但沒有工具冊」的那一個倉 → 灰燈的說明印出 `cd <倉>; git fetch origin; git switch claude/optimistic-goodall-yhalc5`(已合併進 main 就 `git pull`)| 工具橋自測 15/15(隔離的暫存倉:有 MAIN 沒工具冊 → 說明裡有 git switch)|\n"
    "| 2 | FACILITATE:VRN-1 的檔換過、工具冊沒重寫(sha256 不符)| 灰燈說明多一句:在 VRN-1 倉 `functional modules\\VRN` 跑 `python VRN_Main_v0100.py build`(VRN-1 自己的 MAIN 重寫它自己的工具冊)| 自測:改一個位元組 → 不借 · 說明有 build 指令 |\n"
    "| 3 | VRN-1 第十四輪(VRN-1 自己的 MAIN · PR tonykuni/VIA-VDF-VRN#79 的 Codex 三條)| VRN-1 那邊修(科目括號只去單位 · 代號要在代號的位置 · 組合段落要同一頁依序的原文片段)· VRN-2 借的 `table.pivot_db` 檔沒變(工具冊 sha256 相同)| %s |\n\n"
    "## 7.0 v0129 → v0131(工具相互取用)" % R["e2e"])
rep("| 0 | **使用者用 v0131 的一行跑**(`vrn2_release_v0131/VRN2_OneClick_v0131.md`)| 待執行 | 預期:② 借出工具冊 綠 · ⑫ 在 VRN-1 套用 patch 之前是灰「借不到 VRN-1 的 PIVOT 工具」(VRN-2 照常完成)· 套用之後 ⑫ 綠、U/I 最後有 PIVOT 連結 |",
    "| 0 | **使用者用 v0132 的一行跑**(`vrn2_release_v0132/VRN2_OneClick_v0132.md`)| 待執行 | 預期:② 借出工具冊 綠 · VRN-1 倉還在 main(沒有工具冊)→ ⑫ 灰,說明印出 `git switch` 指令(VRN-2 照常完成)· VRN-1 切到 `claude/optimistic-goodall-yhalc5`(或 PR #79 合併後 `git pull`)→ ⑫ 綠、U/I 最後有 PIVOT 連結 |")
rep("| 0b | **VRN-1 套用 patch**(另一團隊的倉 · 操作員自己套)| 待操作員 | 套用後 VRN-1 的 `build` 寫工具冊 → VRN-2 ⑫ 才借得到;",
    "| 0b | **VRN-1 合併 PR tonykuni/VIA-VDF-VRN#79**(另一團隊的倉 · 第十三 / 十四輪 · 操作員決定)| 待操作員 | 合併(或切到該分支)後 VRN-1 的工具冊就在 → VRN-2 ⑫ 才借得到;")
rep("一鍵(取得 v0131 → 驗雜湊 → ③b 定位 → 執行(啟動器自己跑 ①~⑫ · 開 U/I)→ 摘要 → 印驗證摘要):`docs/handoff/ai/vrn2_release_v0131/VRN2_OneClick_v0131.md`",
    "一鍵(取得 v0132 → 驗雜湊 → ③b 定位 → 執行(啟動器自己跑 ①~⑫ · 開 U/I)→ 摘要 → 印驗證摘要):`docs/handoff/ai/vrn2_release_v0132/VRN2_OneClick_v0132.md`")
rep("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
    "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
    "- **四系統各自獨立(操作員 2026-10-20 重申)**:VCGC · VRN-1 · VRN-2 · VDF 各有自己的 MAIN、各自運作、互不影響。工具相互取用只在執行時讀對方的工具冊與檔;"
    "對方不在、沒有工具冊、檔換過 → 自己照常跑完(灰 / 黃)。每一輪都要實測「對方不在」與「關掉借用」兩種情形各自跑得完。\n"
    "- **借不到要說下一步**:灰燈不是終點 —— 說明裡要有操作員可以照貼的指令(切到有工具冊的版本 · 在對方的倉用它自己的 MAIN 重寫工具冊),不替對方改。\n")
out.write_text(s, encoding="utf-8", newline="\n")
print("[計] %s · %d 字" % (out.name, len(s)))
