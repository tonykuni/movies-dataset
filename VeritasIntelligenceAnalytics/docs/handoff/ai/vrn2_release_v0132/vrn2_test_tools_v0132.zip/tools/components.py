import ast, sys
def comps(p):
    t = ast.parse(open(p, encoding="utf-8").read()); c, ex = {}, []
    for n in t.body:
        if isinstance(n, ast.Assign):
            try: v = ast.literal_eval(n.value)
            except Exception: continue
            for tg in n.targets:
                if isinstance(tg, ast.Name): c[tg.id] = v
                elif isinstance(tg, ast.Tuple):
                    for e, vv in zip(tg.elts, v): c[e.id] = vv
        elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and getattr(n.value.func, "attr", "") == "append":
            ex.append(ast.literal_eval(n.value.args[0]))
    out = {x[0]: x[1] for x in c["MGR_CHAIN"]}; out[c["MGR_NAME"]] = c["MGR_SHA"]
    out.update({x[0]: x[1] for x in c["ENGINES"]}); out.update({x[0]: x[1] for x in list(c["EXTRAS"]) + ex})
    out[c["OCR_BRIDGE_NAME"]] = c["OCR_BRIDGE_SHA"]; out[c["HANDOVER_NAME"]] = c["HANDOVER_SHA"]
    return out
a, b = comps(sys.argv[1]), comps(sys.argv[2])
same = [k for k in a if b.get(k) == a[k]]
print("same %d · only old %s · only new %s" % (len(same), sorted(set(a) - set(b)), sorted(set(b) - set(a))))
print("changed", [k for k in a if k in b and a[k] != b[k]])
