"""一鍵 v0132:Run-VRN2-v0132.ps1(由 v0131 換版號 · 判定一字不改)+ VRN2_OneClick_v0132.md + boot132.ps1 + oneline132.txt(冪等)。
用法:python oneclick132.py <ActivateVRN-2 v0132 SHA-256> <輸出夾>"""
import base64
import hashlib
import re
import sys
from pathlib import Path

W = "/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/release131/"
want, out = sys.argv[1], Path(sys.argv[2])
assert re.fullmatch(r"[0-9a-f]{64}", want)
out.mkdir(parents=True, exist_ok=True)
ps = open(W + "Run-VRN2-v0131.ps1", encoding="utf-8").read().rstrip("\n")
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1)
ps = ps.replace(old_want, want)
n131 = ps.count("v0131")
ps = ps.replace("v0131", "v0132")
a = "# ===== VRN-2 一鍵 v0132(啟動器 v0132 · 工具相互取用:"
assert ps.count(a) == 1
ps = ps.replace(a, "# ===== VRN-2 一鍵 v0132(啟動器 v0132 · 工具橋 v0101:借不到 VRN-1 的工具時說清楚下一步 · VRN-1 / VRN-2 / VDF / VCGC 各自獨立)· v0131(工具相互取用:")
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = open(W + "boot131.ps1", encoding="utf-8").read()
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1)
boot = boot.replace(h_old, cs).replace("v0131", "v0132")
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii")
assert len(one) < 8191, len(one)
md = """# VRN-2 一鍵 v0132(cmd / PowerShell 都能貼 · 啟動器 v0132 · 借不到時說清楚下一步)

v0132 = 操作員令(2026-10-20)「一路實測修復到底 … FACILITATE … 授權全自動完成」+ 重申「VCGC VRN-1 VRN-2 VDF 皆是獨立系統,有獨立的 MAIN,獨立運作互不影響」。
啟動器 `ActivateVRN-2.py` **v0132**(SHA-256 `@WANT@` · 從 `vrn2_release_v0132` 取):

| 步驟 | v0132 改了什麼 | 借不到時 |
|---|---|---|
| ② 借出工具冊 | 落地 `VRN2_ToolBridge_v0101.py`(v0131 的 v0100 留著 · 只增不改)→ 寫 `VIA_Reports\\vrn2\\tools\\VRN2_ToolManifest_v0100.json` | — |
| ⑫ PIVOT 資料庫 | 同 v0131:借 VRN-1 的 `table.pivot_db`(逐檔 sha256 · 只讀 VRN-1 的檔)→ `VIA_Reports\\vrn2\\pivot\\` · 只收 ⑪ 判對位的格 | 灰,**說明裡印出下一步**:VRN-1 的倉在、那一版沒有工具冊 → `cd <VRN-1 倉>; git fetch origin; git switch claude/optimistic-goodall-yhalc5`(已合併進 main 就 `git pull`)· 檔換過 → 在 VRN-1 倉 `functional modules\\VRN` 跑 `python VRN_Main_v0100.py build` · VRN-2 照常完成 |

VRN-2 主體(管理器鏈 v0231 → v0239 · ENG397 · 摘要器 · 獨立驗證器 · 處理器 · OCR 橋)**一個位元組都不動**(15 個元件與 v0131 相同);一鍵的判定與 v0131 / v0130 相同(只換版號)。容器實測見 `VRN2_Verification_v0132.md`。

開關:檔頭 `$NoPush = $true` 只實測不上船 · `$Verify = $false` 啟動器沒驗到時 PS 也不補驗 · `$env:VIA_VRN2_NO_VERIFY = '1'` 啟動器不跑 ⑪ · `$env:VIA_VRN2_NO_BORROW = '1'` 這次不借 VRN-1 的工具 · `$env:VIA_VRN1_ROOT = '<VRN-1 倉>'` VRN-1 不在預設位置 · `$env:VRN2_VERIFY_PAR = '2'` 驗證平行路數 · `$env:VIA_VRN2_VERIFY_WAIT = '3600'` ⑪ 等待上限(秒)。

## 在「命令提示字元(cmd)」或 PowerShell 都能貼的一行(建議用這個)

這一行在 cmd 或 PowerShell 貼上都可以:它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)讀本檔的一鍵程式碼 → **核對 SHA-256 `@CS@`** → 相符才在 PowerShell 裡執行(不相符就停 · 不執行)。內容是本檔最後「一行的原始碼」用 UTF-16LE 編成 Base64(`-EncodedCommand`)。**不要把下面整段程式碼貼進 cmd**(cmd 不認得 PowerShell)。

```bat
@ONE@
```

或:在 cmd 先輸入 `powershell` 按 Enter(提示字元變成 `PS C:\\Users\\tonyk>`),再貼下面整段程式碼。

程式碼 SHA-256(本文 · 一行核對的就是這個):`@CS12@`

```powershell
@PS@
```

## 一行的原始碼(`-EncodedCommand` 解碼後 · 只讀取並核對 · 不改任何檔)

```text
@BOOT@
```
"""
md = md.replace("@WANT@", want).replace("@CS12@", cs[:12]).replace("@CS@", cs).replace("@ONE@", one).replace("@BOOT@", boot.rstrip("\n")).replace("@PS@", ps)
assert re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) == ps and md.count("```powershell\n") == 1
assert base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot
assert re.search(r"(?s)```text\n(.*?)\n```", md).group(1) == boot.rstrip("\n")
(out / "VRN2_OneClick_v0132.md").write_text(md, encoding="utf-8", newline="\n")
(out / "boot132.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline132.txt").write_text(one + "\n", encoding="utf-8")
(out / "Run-VRN2-v0132.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("launcher %s · code %s · one-liner %d 字 · md %d · 換版號 %d 處" % (want[:12], cs[:12], len(one), len(md), n131))
