"""ActivateVRN-2 v0131 → v0132 組裝(錨點替換 · 每個錨點只准出現一次 · 不改 v0131 原檔)。

用法:python build_v0132.py <v0131 啟動器> <new 夾> <輸出 v0132 啟動器>
  new 夾:VRN2_ToolBridge_v0101.py · VRN2_Handover_v0132.md
v0132 = 工具橋 v0101(操作員 2026-10-20「一路實測修復到底 … FACILITATE … 授權全自動完成」):找不到 VRN-1 的工具冊時說清楚下一步
  (VRN-1 的倉在但那一版沒有工具冊 → git switch 指令 · sha256 不符 → 在 VRN-1 倉重寫工具冊的指令)· 交接報告 v0132。
  借用規則、啟動器流程 ①~⑫、管理器鏈 / ENG397 / 摘要器 / 驗證器 / 處理器一個位元組都不動。v0100 工具橋不刪(只增不改)。
"""
import base64
import hashlib
import sys
from pathlib import Path

src_p, new_d, out_p = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src_p.read_text(encoding="utf-8")


def b64(raw: bytes) -> str:
    t = base64.b64encode(raw).decode("ascii")
    return "\n".join(t[i:i + 120] for i in range(0, len(t), 120))


def rep(a: str, b: str) -> None:
    global s
    assert s.count(a) == 1, (s.count(a), a[:90])
    s = s.replace(a, b)


bridge = (new_d / "VRN2_ToolBridge_v0101.py").read_bytes()
hand = (new_d / "VRN2_Handover_v0132.md").read_bytes()
bsha, hsha = hashlib.sha256(bridge).hexdigest(), hashlib.sha256(hand).hexdigest()

rep('r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0131 工具相互取用:',
    'r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0132 工具橋 v0101:借不到 VRN-1 的工具時說清楚下一步(VRN-1 的倉在、那一版沒有工具冊 → git switch 的指令 · '
    '檔換過、工具冊沒重寫 → 在 VRN-1 倉重寫工具冊的指令)· 其餘同 v0131 · VRN-1 / VRN-2 / VDF / VCGC 各自獨立、各有自己的 MAIN、互不影響)\n'
    'v0131 工具相互取用:')
rep('VERSION = "ActivateVRN-2 v0131"', 'VERSION = "ActivateVRN-2 v0132"')

i = s.index('EXTRAS.append(("VRN2_ToolBridge_v0100.py", ')
j = s.index('TOOLBRIDGE_NAME = "VRN2_ToolBridge_v0100.py"\n') + len('TOOLBRIDGE_NAME = "VRN2_ToolBridge_v0100.py"\n')
assert s.count('EXTRAS.append(("VRN2_ToolBridge_v0100.py", ') == 1 and i < j
s = (s[:i] + 'EXTRAS.append(("VRN2_ToolBridge_v0101.py", "%s", """\n%s\n"""))   # v0132 工具橋 v0101(= v0100 + 借不到時說清楚下一步 · 借出 section.near / ocr.image · '
     '借入 VRN-1 table.pivot_db · sha256 核對 · 帶加速器橋)\nTOOLBRIDGE_NAME = "VRN2_ToolBridge_v0101.py"\n' % (bsha, b64(bridge)) + s[j:])

i = s.index('HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0131.md"')
j = s.index('"""', s.index('HANDOVER_B64 = """') + len('HANDOVER_B64 = """')) + 3
s = s[:i] + 'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0132.md", "%s"\nHANDOVER_B64 = """\n%s\n"""' % (hsha, b64(hand)) + s[j:]

out_p.write_text(s, encoding="utf-8", newline="\n")
print("[計] %s · %d 位元組 · 工具橋 %s · 交接 %s · sha256 %s" % (out_p.name, len(s.encode("utf-8")), bsha[:12], hsha[:12],
                                                     hashlib.sha256(s.encode("utf-8")).hexdigest()[:12]))
