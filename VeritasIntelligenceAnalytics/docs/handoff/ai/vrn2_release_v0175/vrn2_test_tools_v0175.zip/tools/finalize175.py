"""v0175 收尾:驗證紀錄 · 交接 v0176(從 v0175 抄 · 只增)· 收尾規格 §12(只增)· 放進倉 vrn2_release_v0175 · logs / 工具 zip。桌機 / 上傳資料不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v175"); rel = W / "release175"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def last(p):
    return [l for l in lines(p) if l.strip()][-1]


R = json.loads((rel / "VRN2_Release_v0175.json").read_text(encoding="utf-8"))
R["ui"]["css_sha256"] = re.search(r'CSS_SHA256 = "([0-9a-f]{64})"', (W / "new" / "VRN2_Workbench_v0109.py").read_text(encoding="utf-8")).group(1)
H = R["handleall"]
ra = [l for l in lines(W / "rall131_selftest.log") if re.search(r"^\[FAIL\]|--selftest · ", l)]
assert ra and "· 不過 0" in ra[-1], ra[-1:]
lsum = [l for l in lines(W / "launcher175_selftest.log") if l.startswith("[PASS] v0175")]
assert lsum and not [l for l in lines(W / "launcher175_selftest.log") if l.startswith("[FAIL]")]
mods = {"BookSource v0100": last(W / "booksource_selftest.log"), "OutputStore v0103": last(W / "store103_selftest.log"), "Workbench v0109": last(W / "wb109_selftest.log"),
        "Workbench v0108 回歸": last(W / "wb108_regress.log"), "OutputStore v0102 回歸": last(W / "store102_regress.log")}
assert all(("全過" in v) or ("不過 0" in v) for v in mods.values()), mods
ps = json.loads((W / "pscheck175.log").read_text())
by = {x["f"]: x for x in ps}
assert all(x["e"] == 0 for x in ps) and by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"] and by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"]
pparse = "pwsh 剖析錯 %s · Handle-All 一行 = 可讀版 True · 開機行 = 可讀版 True" % sorted(x["e"] for x in ps)
rc = [l for l in lines(W / "tiny175.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
assert "[RED] boot SHA-256 mismatch - not run" in (W / "tiny_tamper.log").read_text(encoding="utf-8")
states = {n: json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
base = {n: json.loads(Path("/home/user/vrn2_work/v174/closeout_%s.json" % n).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
assert states["auto1"].get("VRN-2") == base["auto1"].get("VRN-2") and states["auto2"].get("VRN-2") == base["auto2"].get("VRN-2"), (states, base)
E = json.loads((W / "e2e175_check.json").read_text(encoding="utf-8"))
assert E["auto1_page_v0109"] and E["auto2_page_v0109"] and E["auto2_books_cols"] and E["store_no_double"] and E["plan_ok"], E
browser = json.loads((W / "browser175.json").read_text(encoding="utf-8"))
assert browser["errors"] == [] and browser["overflowN"] == 0 and browser["csv_source_count"] == 1
desk = json.loads((W / "deskshape175.json").read_text(encoding="utf-8"))
assert desk["other_values_identical"] and desk["last_two_columns"] and desk["unmapped"] == []
R["results"] = {"roundall_v0131_selftest": ra[-1:], "launcher_v0175_selftest": lsum, "module_selftests": mods, "pwsh_parse": pparse, "e2e_rc": rc, "closeout_per_owner": states,
                "closeout_vrn2_items_same_as_v0174_baseline": True, "e2e": E, "browser": browser, "desktop_shape_check": desk,
                "not_run": "the desktop itself (one line · auto = repair · ⑬a + ⑬ fill + Workbench v0109) · the operator's own --confirm (H-fd2ea35f)"}
(rel / "VRN2_Release_v0175.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0175 驗證紀錄(2026-11-03 · ⑬a 輸出冊實體 SOURCE / BROKER_EN · 增量庫 OutputStore v0103 · Workbench v0109 · 套件 v0175 · RoundAll v0131 · Handle-All v0123)

## 1. 操作員要求 → 做法

| 要求 | 做法 |
|---|---|
| BROKER 一律英文縮寫 | 輸出冊每列多 `BROKER_EN`(候選對照表 · 等 VCGC 核發 · 對不到留空列收據)· 畫面券商欄顯示縮寫 · `BROKER` 原文不改 |
| 輸出冊和增量庫也實體加 Source 欄 | ⑬a `VRN2_BookSource_v0100`(⑬b 之後 · ⑬ 之前):七本報告冊最後兩欄 `BROKER_EN` · `SOURCE`;JSON 保留縮排 · CSV 保留 BOM / CRLF · Parquet 保留欄型別 · 其他值逐位元組不變 · MarketConsensus 自己的 SOURCE 不動 · 增量庫 `VRN2_OutputStore_v0103`:列雜湊不算兩欄(不重複追加)· 舊列就地補欄(先備份 · restore-fill)|
| 細節 / Detail 字型字級為主 · 整字小一點 | Consolas + 微軟正黑體 10.45px(內文)· 11(區段標題)· 9(表頭 / 標籤)· 8(標記)· 19(品牌 / 大標 / 統計)· 模板 15 色 · CSS SHA-256 `%s` |
| 資料驗證狀況 → 系統摘要 · 矩陣化燈號化 | 00 頁改名「系統摘要」· 驗證矩陣(燈號 · 項目 · 細節)+ 共識矩陣(FactSet 目標價中位數 · Yahoo 目標價中位數 · FactSet 分析師人數 · Yahoo 分析師人數 · 兩源檢核)|
| 尚未跨越的驗收條件特別亂 | 04 頁「待驗收項目」矩陣(燈號 · 類別 · 項目 · 細節 · 次數 · 同項合併 · 紅先)|
| 括號說明 / 備註 / 全形 / 表頭 | 表頭英文一行 + 中文一行 · 標題括號說明移到卡片底下的註 · 中文旁括號冒號逗號改全形(檔名 / 路徑 / 資料值不動)|
| 資料不可超過卡片及格子 | 自動換行 · 瀏覽器實測溢出格 0 |
| 左面板步驟 | 1 選擇報告來源 · 2 確認輸入 · 3 啟動處理 · 4 輸出位置 · 5 開啟資料夾 · 6 其他系統(完成的步驟綠框)· 說明移到底下 |
| Word / 影像 · STOCK / NON-STOCK / NEWS | 01 頁輸入分類矩陣(檔名初判 · 候選)· 本版主體只擷取 PDF;Word 需轉 PDF、影像需 OCR |

## 2. 測試

| 項目 | 結果 |
|---|---|
| 模組自測 | %s |
| 啟動器 v0175 自測 | 全過 · %s |
| RoundAll v0131 自測 | %s |
| PowerShell 剖析 | %s |
| 桌機形狀資料(操作員上傳的 FinancialData 匯出 · 只在沙盒)| %s 列 · 最後兩欄 BROKER_EN / SOURCE · 其他值逐一相同 · SOURCE 與 v0108 匯出一致 %s · 13 家券商全有縮寫 |
| 瀏覽器(Chromium · 另一線 v0104 鏈 + v0109)| JS 錯 0 · 溢出格 0 · 內文 %s · 表頭雙行 · SOURCE 只一欄 · BROKER_EN 不另列 · 整冊 CSV SOURCE 1 次 |
| e2e(最短一行 · 沙盒)| %s · auto1 整輪(啟動器 v0175:⑬a → ⑬ v0103 → Workbench v0109)→ 模擬桌機 v0174 狀態(冊沒有兩欄 · 頁是 v0108)→ auto2 repair:%s → 竄改開機檔不執行 |
| 增量庫 | %s |
| 收尾負責方 | VRN-2 項與 v0174 基準相同(沙盒限定 · 沒有真 OCR 環境)|

## 3. 桌機下一步

1. 貼 `vrn2_release_v0175/VRN2_HandleAll_v0123.md` 的最短一行(收據 ≥ v0170 → repair · ⑬a 寫兩欄 → ⑬ 舊列補欄 → Workbench v0109)。
2. MQ-1560 看過原圖:`python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0131.py" --confirm H-fd2ea35f --note "…"`(只有操作員打才算)。
3. 券商縮寫表要成為正式同義字 → 交 VCGC 核。Word / 影像要擷取 → 下一步(Word 轉 PDF · 影像 OCR · 環境交 VCGC)。
""" % (R["ui"]["css_sha256"][:12], " · ".join("%s:%s" % (k, v[-40:]) for k, v in mods.items()), lsum[0][:110], ra[-1][:100], pparse,
       "{:,}".format(desk["rows"]), desk["same_as_v0108_export_source"], browser["fonts"]["td"][:60], " · ".join(rc), E["plan"][:200], E["store"][:220])
(rel / "VRN2_Verification_v0175.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0175.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0174 + VRN2_RoundAll_v0130 + VRN2_HandleAll_v0122 · 2026-11-03(")
L[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0175 + VRN2_RoundAll_v0131 + VRN2_HandleAll_v0123 · 2026-11-03(⑬a 輸出冊實體 SOURCE / BROKER_EN · 增量庫 v0103 · Workbench v0109 細節字型 · 系統摘要矩陣 · 左欄步驟)"
src = "\n".join(L)
once("> **本輪(v0174)**",
     "> **本輪(v0175)**:操作員 11/03 要求 → **⑬a VRN2_BookSource v0100**(新家族 · ⑬b 之後 ⑬ 之前):七本報告冊最後兩欄 BROKER_EN(英文縮寫 · 候選表)· SOURCE(歷史 TWSE/TPEX · 報告預估 · 報告實際 …)"
     "· 其他值逐位元組不變 · BROKER 原文不改 · MarketConsensus 自己的 SOURCE 不動;**OutputStore v0103**(列雜湊不算兩欄 → 不重複追加 · 舊列就地補欄 · 先備份 · restore-fill);"
     "**Workbench v0109**(細節欄字型 Consolas + 正黑體 10.45px · 00 頁「系統摘要」驗證 / 共識矩陣 · 04「待驗收項目」矩陣 · 表頭英文 + 中文兩行 · 說明移到卡片底下 · 全形標點 · 左欄步驟 1–6 · 01 輸入分類矩陣)。"
     "**RoundAll v0131**(⑤ source → store 補欄 → workbench v0109 · 自測 103)· **Handle-All v0123** · 套件 v0175(啟動器 v0175 · runtime v0164)。\n"
     "> **本輪(v0174)**")
rows = ("| **VRN2_HandleAll_v0123.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0123** | `vrn2_release_v0175` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0131)|\n"
        "| **VRN2_RoundAll_v0131.py**(發行夾 · 一支入口 · 不在套件內)| **v0131** | `vrn2_release_v0175` | `%s` | **新**(套件 v0175 · ⑤ source / store 補欄 / Workbench v0109 · 自測 103)|\n"
        "| ActivateVRN-2_v0175.py(套件 · 底座 v0136 · runtime v0164)| **v0175** | 見發行清單 | `%s` | **新**(⑬a · OutputStore v0103 · Workbench v0109)|\n"
        "| VRN2_Runtime_v0164.zip(套件 · runtime)| **v0164** | 套件內 | `%s` | **新**(v0163 的 204 個成員不動 + BookSource v0100 + OutputStore v0103 + Workbench v0109)|\n"
        "| VRN2_BookSource_v0100.py(runtime · 新家族)| **v0100** | runtime v0164 | 見 runtime 清單 | **新**(⑬a 輸出冊最後兩欄 BROKER_EN · SOURCE)|\n"
        "| VRN2_OutputStore_v0103.py(runtime · v0102 薄尾)| **v0103** | runtime v0164 | 見 runtime 清單 | **新**(雜湊不算兩欄 · 舊列補欄 · restore-fill)|\n"
        "| VRN2_Workbench_v0109.py(runtime · v0108 薄尾)| **v0109** | runtime v0164 | 見 runtime 清單 | **新**(細節字型 · 系統摘要矩陣 · 待驗收矩陣 · 表頭雙行 · 左欄步驟 · 輸入分類)|\n") % (
    H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12],
    next(c["sha256"] for c in R["components"] if c["path"] == "ActivateVRN-2_v0175.py")[:12], R["runtime"]["zip_sha256"][:12])
once("| **VRN2_HandleAll_v0122.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0122** | `vrn2_release_v0174` |",
     rows + "| **VRN2_HandleAll_v0122.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0122** | `vrn2_release_v0174` |")
once("| 0 | **(v0174)**",
     "| 0 | **(v0175)** 貼 `vrn2_release_v0175/VRN2_HandleAll_v0123.md` 的最短一行(repair · ⑬a 寫兩欄 → ⑬ 補欄 → Workbench v0109)→ 看系統摘要 / 待驗收矩陣 / 左欄步驟 / 輸入分類 · "
     "MQ-1560 `--confirm H-fd2ea35f`(操作員)· 券商縮寫表交 VCGC 核 · Word / 影像擷取(下一步 · 環境交 VCGC)| 貼回 / 人工 / VCGC |\n"
     "| 0 | **(v0174)**")
once("**v0174(2026-11-03)**:", "**v0175(2026-11-03)**:⑬a BookSource v0100(輸出冊實體 SOURCE / BROKER_EN)· OutputStore v0103(不重複追加 · 舊列補欄)· Workbench v0109(細節字型 · 系統摘要矩陣 · 表頭雙行 · 左欄步驟 · 輸入分類)· RoundAll v0131 · Handle-All v0123 · 套件 v0175。\n\n**v0174(2026-11-03)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0175)** **輸出冊最後兩欄是推得欄**:`BROKER_EN` · `SOURCE` 由 ⑬a BookSource 依該列自己的欄位算(規則與 Workbench v0108 相同 · 自測逐例對照);任何會重寫輸出冊的步驟"
     "(⑬b · ⑥f Combined · 管理器)之後都要再跑 ⑬a(RoundAll v0131 已排)。增量庫列雜湊不算這兩欄(OutputStore v0103),新加推得欄也要照這個做,否則整庫會被重複追加。\n"
     "- **(v0175)** **U/I 字型以細節欄為準**:內文 Consolas + 微軟正黑體 10.45px · 11 / 9 / 8 · 19 只給品牌 / 大標 / 統計(Workbench v0109 `CSS_SHA256` 釘住);表頭一律英文一行 + 中文一行;"
     "說明放卡片底下的註;中文旁標點全形。改版要出新號並重算雜湊。\n"
     "- **(v0175)** **版號**:本線下一版 BookSource v0101+ · OutputStore v0104+ · Workbench v0110+ · RoundAll v0132+ · Handle-All v0124+ · runtime v0165+ · 啟動器 / 套件 / 收據 v0176+;出號前照舊查本分支與 main。\n\n")
(REPO / "VRN2_Handover_v0176.md").write_text(src, encoding="utf-8", newline="\n")

spec = (REPO / "VIA_Closeout_Spec_20261103.md").read_text(encoding="utf-8")
if "## 12. v0175 輪更新" not in spec:
    spec = spec.rstrip("\n") + "\n\n" + """## 12. v0175 輪更新(2026-11-03 · 只增)

| 項目 | 狀態 |
|---|---|
| 實體 SOURCE / BROKER_EN | **操作員決定加**(§11 待決)→ ⑬a `VRN2_BookSource_v0100` 寫進七本報告冊最後兩欄(其他值不變 · BROKER 原文不改)· 增量庫 `VRN2_OutputStore_v0103` 列雜湊不算兩欄(不重複追加)· 舊列就地補欄(先備份 · restore-fill)|
| U/I | `VRN2_Workbench_v0109`:細節欄字型 10.45px · 00「系統摘要」驗證 / 共識矩陣 · 04「待驗收項目」矩陣 · 表頭英文 + 中文兩行 · 說明放底下 · 全形標點 · 左欄步驟 1–6 · 溢出格 0 |
| 輸入分類 | 01 頁矩陣:個股報告 · 非個股報告 · 新聞與盤勢 · 頁面影像 · 未分類 × PDF / Word / TXT / 影像 / 其他(檔名初判 · 候選)· 本版主體只擷取 PDF |
| Word / 影像 | 已收下 · **未擷取**(Word 需轉 PDF · 影像需 OCR · 環境交 VCGC)→ 收尾佇列 VRN P1 |
| MQ-1560 | 操作員 11/03 貼的原文與摘錄四點逐字比:差異只在 OCR 斷字(英文字被空白拆開或黏在一起 · 不改字義)· 內容一致 → 等操作員 `--confirm H-fd2ea35f` |
| 桌機要做 | 貼 `vrn2_release_v0175/VRN2_HandleAll_v0123.md` 最短一行(repair)|
"""
    (REPO / "VIA_Closeout_Spec_20261103.md").write_text(spec, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0175"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0175.zip", "VRN2_RoundAll_v0131.py", "VRN2_RoundAll_v0131.md", "VRN2_HandleAll_v0123.md", "VRN2_HandleAll_v0123_boot.txt", "VRN2_Release_v0175.json", "VRN2_Verification_v0175.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 2, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t175a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")) + (((str(W.parent), "<work>"),) if not name.startswith("tools/") else ()):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    if not name.startswith("tools/"):
        data = re.sub(rb"/home/user/[^\s'\"]*", b"<work>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0175.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall131_selftest.log", "launcher175_selftest.log", "booksource_selftest.log", "store103_selftest.log", "wb109_selftest.log", "wb108_regress.log", "store102_regress.log",
                              "pscheck175.log", "tiny175.rc", "seed175.log", "sim175.log", "confirm_list.log", "browser175.json", "e2e175_check.json", "deskshape175.json")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0175.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall131.py", "mk_launcher175.py", "runtime164.py", "gen_build175.py", "build175.py", "build175_tail.py", "finalize175.py", "e2e175.sh", "shot109.js", "deskshape.py", "e2e175_check.py")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0176", src.count("\n"))
