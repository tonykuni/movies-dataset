md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0123(2026-11-03 · ⑬a 輸出冊實體 SOURCE / BROKER_EN · 增量庫 v0103 · Workbench v0109 · 套件 v0175 · RoundAll v0131)

操作員 2026-11-03 要求 → 做法:

| 要求 | v0175 |
|---|---|
| BROKER 一律用英文縮寫 | 輸出冊每一列多一欄 **BROKER_EN**(中信 CTBC · 凱基 KGI · 兆豐 Mega · 華南 HNS · 國泰 Cathay · Goldman Sachs GS · Morgan Stanley MS · J.P. Morgan JPM · Macquarie MQ …;BROKER 原文不改,驗證器照舊拿它對 PDF)· 畫面券商欄一律顯示縮寫 · 對不到的留空並列在收據(縮寫表是候選 · 等 VCGC 核發)|
| 輸出冊和增量庫也實體加 Source 欄 | ⑬a `VRN2_BookSource_v0100`:七本報告冊(JSON / CSV / Parquet)最後兩欄 BROKER_EN · SOURCE(其他值逐位元組不變 · 沒變就不寫)· 增量庫 `VRN2_OutputStore_v0103`:列雜湊不算這兩欄(**不會整庫重複追加**)· 庫裡舊列就地補兩欄(先備份 DuckDB 檔 · 可 restore-fill)|
| 字體大小及格式一致 · 以「細節 / Detail」字型字級為主 · 整字小一點 | 全頁內文 = Consolas + 微軟正黑體 10.45px(細節欄那一套)· 區段標題 11px · 表頭 / 標籤 9px · 標記 8px · 只留頁首品牌與大標 19px · 顏色仍是 ENG049 模板 15 色 |
| 資料驗證狀況放入系統現況 · 改名系統摘要 · 矩陣化燈號化 | 00 頁改名「系統摘要」· 原本頁首上方那一排燈改成系統摘要裡的矩陣(燈號 · 項目 · 細節)· 共識矩陣(FactSet 目標價中位數 · Yahoo 目標價中位數 · FactSet 分析師人數 · Yahoo 分析師人數 · 兩源檢核)|
| 尚未跨越的驗收條件特別亂 | 04 頁改成「待驗收項目」矩陣(燈號 · 類別 · 項目 · 細節 · 次數)· 同項合併計次 · 紅先黃後 · 細節兩行、點一下展開 |
| 不用括號說明 · 備註放底下 · 全形標點 · 表頭統一寫完整 | 表頭一律英文一行 + 中文一行 · 標題括號說明移到卡片底下的「註」· 中文旁的括號、冒號、逗號改全形(檔名、路徑、資料值不動)|
| 資料不可超過卡片及格子 | 卡片 / 格子 / 矩陣內文自動換行 · 瀏覽器實測 0 個溢出格 |
| 左面板文字雜亂 → 步驟編號 | 1 選擇報告來源 → 2 確認輸入 → 3 啟動處理 → 4 輸出位置 → 5 開啟資料夾 → 6 其他系統 · 小圓圈編號(完成的步驟綠框)· 說明移到左欄最底下 |
| Word / 影像有處理嗎 · 分 STOCK / NON-STOCK / NEWS 嗎 | 01 頁「輸入分類」矩陣:個股報告 · 非個股報告 · 新聞與盤勢 · 頁面影像 · 未分類 × PDF / Word / TXT / 影像 / 其他 · 處理方式(本版主體只擷取 PDF;Word 要先轉 PDF、影像要 OCR)|

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0175/VRN2_Closeout_v0175.zip`(SHA-256 `%s` · 啟動器 v0175 · runtime v0164 = v0163 + BookSource v0100 + OutputStore v0103 + Workbench v0109)|
| 一支 Python | `VRN2_RoundAll_v0131.py`(SHA-256 `%s` · 自測 103 項 · repair:⑬a 寫兩欄 → ⑬ 補欄 → 重渲染 v0109)|
| 自動選模式 | 收據 ≥ v0170 → **repair(幾分鐘)**:⑬a + ⑬ + Workbench |

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0123 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0131 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0131.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0131.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0123.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0131.py(套件 v0175 · ⑬a BookSource · OutputStore v0103 · Workbench v0109)

`VRN2_RoundAll_v0131.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0130 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0175/VRN2_Closeout_v0175.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0175 · runtime v0164 = v0163 + BookSource v0100 + OutputStore v0103 + Workbench v0109 |
| ⑤ source(新)| 輸出冊還沒有 SOURCE / BROKER_EN、或比上次寫欄新、或本輪重算 ⑬b / Combined → 只增不覆寫補放 BookSource v0100 → 寫最後兩欄 · 舊收據沒有 ⑬a 步驟就補一列在 ⑬ 前面 · 排在 store 之前 |
| ⑤ store | 補放鏈多 OutputStore v0103(雜湊不算兩欄 · 舊列補欄 · 先備份)· 增量庫收據沒有 derived_fill 也排 |
| ⑤ workbench | 頁面沒有 v0109 標記(`id="wb109-tpl"`)→ 補放 v0109 + v0108 + v0107 → 重渲染 |
| ③ 自測清單 | Workbench v0109 · OutputStore v0103 · BookSource v0100 |
| 貼回包 | 多 VRN2_BookSource_latest.json |
| 自測 | 103 項(v0130 的 100 項 + 101 · 101b · 101c · 舊項目在 VIA_VRN2_NO_BOOKSOURCE=1 下跑)|
| ⑥ 除錯 | Combined 最後兩欄是 ⑬a 實體欄 → 欄序照 ConsensusJoin 清單比(兩欄另記)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0131.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0175 (launcher v0175 · runtime v0164) + VRN2_RoundAll_v0131 + VRN2_HandleAll_v0123", "date": "2026-11-03",
        "trigger": "操作員 2026-11-03:BROKER 一律用英文縮寫 · 輸出冊和增量庫也實體加 Source 欄 · 字型字級以細節 / Detail 為準 · 資料驗證狀況放入系統現況並改名系統摘要 · 所有資訊矩陣化燈號化 · "
                   "不用括號說明 · 備註放底下 · 全形標點 · 表頭統一寫完整 · 資料不可超過卡片及格子 · 左面板步驟編號 · Word / 影像處理與 STOCK / NON-STOCK / NEWS 分類",
        "data_rule": "BookSource writes BROKER_EN + SOURCE as the last two columns of the seven report books; every other value is byte-identical (JSON keeps its indent, CSV keeps BOM / CRLF, Parquet keeps column types); "
                     "BROKER stays as written in the report; MarketConsensus keeps its own SOURCE; window.VRN2_DATA still equals the output books",
        "store_rule": "OutputStore v0103 row hash ignores SOURCE / BROKER_EN (no re-append); stored rows get the two columns filled in place after a DuckDB file backup (restore-fill)",
        "ui": {"font": "Consolas + Microsoft JhengHei 10.45 px (the Detail column) · section 11 · labels 9 · tags 8 · display 19 (brand / title / stats)", "palette": "ENG049 template 15 colours (unchanged)",
               "summary": "00 tab 系統摘要: verification matrix (status · item · detail) + consensus matrix (FactSet 目標價中位數 · FactSet 分析師人數 …)",
               "acceptance": "04 tab 待驗收項目 matrix (status · category · item · detail · count)", "headers": "English line + Chinese line everywhere", "left_panel": "numbered steps 1–6",
               "input_classes": "stock report · non-stock report · news and market notes · page image · unclassified × PDF / Word / TXT / image / other (filename candidates; PDF only is extracted)"},
        "fixes": {"BookSource_v0100": "new family · ⑬a · selftest 14 (rules cross-checked with Workbench v0108)", "OutputStore_v0103": "thin tail over v0102 · selftest v0102 + 2 engines × 5",
                  "Workbench_v0109": "thin tail over v0108 · selftest 12 · CSS SHA-256 pinned", "launcher_v0175": "⑬a between ⑬b and ⑬ · OutputStore v0103 / Workbench v0109 active",
                  "RoundAll_v0131": "package v0175 pin · ⑤ source / store fill / workbench v0109 · selftest 103 · Combined column check ignores the two ⑬a columns", "HandleAll_v0123": "points at RoundAll v0131 / release v0175"},
        "package": {"name": "VRN2_Closeout_v0175.zip", "sha256": want, "release_folder": "vrn2_release_v0175", "changed": True, "launcher": "ActivateVRN-2_v0175.py"},
        "runtime": {"name": "VRN2_Runtime_v0164.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 204, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0130.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0174"}],
        "roundall": {"name": "VRN2_RoundAll_v0131.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0131.md"},
        "handleall": {"name": "VRN2_HandleAll_v0123.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0123_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "BookSource v0100 (new family) · OutputStore v0103 · Workbench v0109 · runtime v0164 · launcher / package / receipt v0175 · RoundAll v0131 · HandleAll v0123 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0175.md"}}
(rel / "VRN2_Release_v0175.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
