"""ActivateVRN-2_v0175.py = v0174 + ⑬a 輸出冊實體 SOURCE / BROKER_EN(BookSource v0100)+ OutputStore v0103(雜湊不算推得欄 · 舊列補欄)+ Workbench v0109。
runtime v0164 = runtime v0163(204 個成員一字不改)+ VRN2_BookSource_v0100 + VRN2_OutputStore_v0103 + VRN2_Workbench_v0109。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v174/pkg174/ActivateVRN-2_v0174.py")
OUT = Path("/home/user/vrn2_work/v175/pkg175/ActivateVRN-2_v0175.py")
OUT.parent.mkdir(parents=True, exist_ok=True)
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0174: v0172 entry + Workbench v0108', '''"""VRN-2 v0175: v0174 entry + ⑬a book Source / Broker columns + OutputStore v0103 + Workbench v0109 (operator 2026-11-03: "BROKER 一律用英文縮寫 · 輸出冊和增量庫也實體加
 Source 欄 · 字型字級以細節 / Detail 為準 · 資料驗證狀況放入系統摘要 · 所有資訊矩陣化燈號化 · 表頭統一 · 左面板步驟編號 · 說明放底下 · 全形標點").
 - ⑬a VRN2_BookSource_v0100 (new · runs after ⑬b, which rewrites FinancialAligned / Deleted, and before ⑬): BROKER_EN (English broker abbreviation, candidate table
   pending VCGC; unmapped → blank + listed in the receipt) and SOURCE (歷史 TWSE/TPEX · 報告預估 · 報告實際 · 報告 …, same rule as Workbench v0108) are written as the
   last two columns of BasicInfo · FinancialData · Summary · Combined · Rejected · FinancialAligned · Deleted (JSON keeps its indent · CSV keeps BOM / CRLF · Parquet keeps
   column types; every other value byte-identical; unchanged → not rewritten). MarketConsensus keeps its own SOURCE column. Never RED; VIA_VRN2_NO_BOOKSOURCE=1 opts out.
 - ⑬ VRN2_OutputStore_v0103 (thin tail over v0102): the row hash ignores SOURCE / BROKER_EN, so books that gained the two columns are not appended again; rows already in
   the store get the two columns filled in place from their own fields (DuckDB file copied first · affected run partitions moved to the backup and rewritten · restore-fill).
 - VRN2_Workbench_v0109 (thin tail over v0108): text font = the Detail column's Consolas + Microsoft JhengHei 10.45 px; 00 tab renamed 系統摘要 with the verification
   lamps as a matrix (status · item · detail) and a consensus matrix (FactSet 目標價中位數 · FactSet 分析師人數 …); 04 acceptance list → matrix; headers English line +
   Chinese line everywhere; parenthetical notes moved under the card; full-width punctuation beside Chinese; left panel as numbered steps; input classification matrix
   (stock report · non-stock report · news · page image · unclassified × PDF / Word / TXT / image); physical SOURCE / BROKER_EN used when present (no duplicate column).
 Runtime v0164 = runtime v0163 (204 members byte-identical) + VRN2_BookSource_v0100 + VRN2_OutputStore_v0103 + VRN2_Workbench_v0109. Receipt VRN2_Closeout_v0175.json.

VRN-2 v0174: v0172 entry + Workbench v0108''')
rep('VERSION = "ActivateVRN-2 v0174"', 'VERSION = "ActivateVRN-2 v0175"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0163.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0164.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0163.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0164.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0174.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0175.json"')
rep('WORKBENCH = "VRN2_Workbench_v0108.py"   # v0174:', 'WORKBENCH = "VRN2_Workbench_v0109.py"   # v0175: Detail-column font · 系統摘要 matrices · two-line headers · step-numbered left panel · v0174:')
rep('OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0102.py"   # v0164:', 'OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0103.py"   # v0175: row hash ignores SOURCE / BROKER_EN · old rows filled in place (backup · restore-fill) · v0164:')
rep('HISTORY_ALIGN = "VRN2_HistoryAlign_v0103.py"', 'BOOK_SOURCE = "VRN2_BookSource_v0100.py"   # v0175 ⑬a: BROKER_EN + SOURCE written as the last two columns of the output books\nHISTORY_ALIGN = "VRN2_HistoryAlign_v0103.py"')
rep('''def integrate_scan(runtime: Path, output: Path, steps: list) -> dict:''', '''def book_source(runtime: Path, output: Path, steps: list) -> dict:
    """⑬a(v0175): BROKER_EN + SOURCE as the last two columns of the output books (JSON / CSV / Parquet · values otherwise untouched); never RED."""
    if os.environ.get("VIA_VRN2_NO_BOOKSOURCE") == "1":
        result = {"lamp": "GRAY", "why": "VIA_VRN2_NO_BOOKSOURCE=1 · 本輪不寫 SOURCE / BROKER_EN 欄"}
    else:
        try:
            module = _load_runtime_module(runtime, BOOK_SOURCE, "vrn2_book_source_entry")
            result = module.apply(Path(output))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = str(result.get("why", ""))
    steps.append({"step": "⑬a 輸出冊 Source / Broker 欄(實體)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬a 輸出冊 Source / Broker 欄 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **{k: result.get(k) for k in ("columns", "unmapped") if k in result}}


def integrate_scan(runtime: Path, output: Path, steps: list) -> dict:''')
rep('''    receipt["history_align"] = history_align(runtime, root, output, base.STEPS)   # v0147: before ⑬ so FinancialAligned / Deleted reach the store
''', '''    receipt["history_align"] = history_align(runtime, root, output, base.STEPS)   # v0147: before ⑬ so FinancialAligned / Deleted reach the store
    receipt["book_source"] = book_source(runtime, output, base.STEPS)   # v0175 ⑬a: after ⑬b (it rewrites FinancialAligned / Deleted) · before ⑬ (the store keeps the columns)
''')
rep('''SELFTEST_ENV_CLEAR = ("VRN2_OUTPUT_DIR", "VIA_VRN2_NO_MARKET",''', '''SELFTEST_ENV_CLEAR = ("VRN2_OUTPUT_DIR", "VIA_VRN2_NO_BOOKSOURCE", "VIA_VRN2_NO_MARKET",''')
rep('OUTPUT_STORE_ACTIVE, OUTPUT_STORE, "VRN2_OutputStore_v0100.py")', 'OUTPUT_STORE_ACTIVE, "VRN2_OutputStore_v0102.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py", BOOK_SOURCE)', 2)
rep('''        assert st.TAG == "v0102" and st.BOOKS[-1] == "MarketConsensus"''', '''        assert st.TAG == "v0103" and st.PRIOR.PRIOR.TAG.startswith("v0103") and st.BOOKS[-1] == "MarketConsensus"''')
rep('''    assert WORKBENCH == "VRN2_Workbench_v0108.py"''', '''    wb109 = selftest_source("VRN2_Workbench_v0109.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0109"' in wb109 and 'PRIOR_NAME = "VRN2_Workbench_v0108.py"' in wb109 and wb109.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    assert 'id="wb109-tpl"' in wb109 and "def acceptance_rows(" in wb109 and "def input_classes(" in wb109 and "def summary_section(" in wb109 and "@CSS_SHA256@" not in wb109
    bs100 = selftest_source(BOOK_SOURCE).read_text(encoding="utf-8")
    assert 'VERSION = "v0100"' in bs100 and 'COLS = ("BROKER_EN", "SOURCE")' in bs100 and "def apply(" in bs100 and bs100.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    st103 = selftest_source("VRN2_OutputStore_v0103.py").read_text(encoding="utf-8")
    assert 'TAG = "v0103"' in st103 and 'PRIOR_NAME = "VRN2_OutputStore_v0102.py"' in st103 and 'DERIVED = ("BROKER_EN", "SOURCE")' in st103 and "def fill_source(" in st103
    assert WORKBENCH == "VRN2_Workbench_v0109.py" and OUTPUT_STORE_ACTIVE == "VRN2_OutputStore_v0103.py" and BOOK_SOURCE == "VRN2_BookSource_v0100.py"
    body175 = Path(__file__).read_text(encoding="utf-8")
    assert body175.rindex('receipt["history_align"] = history_align(') < body175.rindex('receipt["book_source"] = book_source(') < body175.rindex("    store = output_store(runtime, output,")
    with tempfile.TemporaryDirectory(prefix="vrn2-v0175-check-") as temporary175:
        runtime175, output175 = Path(temporary175) / "rt", Path(temporary175) / "VIA_Reports" / "vrn2"
        runtime175.mkdir()
        shutil.copy2(str(selftest_source(BOOK_SOURCE)), str(runtime175 / BOOK_SOURCE))
        steps175 = []
        assert book_source(runtime175, output175, steps175)["lamp"] == "GRAY" and steps175[-1]["step"].startswith("⑬a")
        (output175 / "output").mkdir(parents=True)
        (output175 / "output" / "VRN2_FinancialData_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "BROKER": "凱基", "PERIOD": "2026E", "VALUE": "1"}], ensure_ascii=False), encoding="utf-8")
        got175 = book_source(runtime175, output175, steps175)
        row175 = json.loads((output175 / "output" / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))[0]
        assert got175["lamp"] == "GREEN" and list(row175)[-2:] == ["BROKER_EN", "SOURCE"] and row175["BROKER_EN"] == "KGI" and row175["SOURCE"] == "報告預估" and row175["BROKER"] == "凱基"
        os.environ["VIA_VRN2_NO_BOOKSOURCE"] = "1"
        try:
            assert book_source(runtime175, output175, steps175)["lamp"] == "GRAY"
        finally:
            os.environ.pop("VIA_VRN2_NO_BOOKSOURCE", None)''')
rep('''    print("[PASS] v0174: Workbench v0108''', '''    print("[PASS] v0175: ⑬a BookSource v0100 (no books → GRAY · BROKER_EN KGI + SOURCE 報告預估 as the last two columns · BROKER kept · opt-out → GRAY · after ⑬b, before ⑬) · OutputStore v0103 active · Workbench v0109 active")
    print("[PASS] v0174: Workbench v0108''')
rep('return lamp, detail + " · launcher v0174"', 'return lamp, detail + " · launcher v0175"')
rep('note="VRN-2 private runtime; exact ship v0163 (launcher v0174 · Workbench v0108 template lock + Source · HistoryAlign v0103 · ConsensusJoin v0107 UPSIDE_ADJ · no MOPS);',
    'note="VRN-2 private runtime; exact ship v0164 (launcher v0175 · BookSource v0100 · OutputStore v0103 · Workbench v0109 · HistoryAlign v0103 · ConsensusJoin v0107 UPSIDE_ADJ · no MOPS);')
rep('print("NEXT: [%s] VRN-2 v0174 · rc %s', 'print("NEXT: [%s] VRN-2 v0175 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0175", len(s.splitlines()), "lines")
