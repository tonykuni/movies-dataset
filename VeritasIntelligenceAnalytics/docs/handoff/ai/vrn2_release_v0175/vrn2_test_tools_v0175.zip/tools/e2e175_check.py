"""e2e v0175 結果檢查(只讀沙盒產物 · 寫 e2e175_check.json · 路徑遮掉)。"""
import csv, io, json, re
from pathlib import Path
W = Path("/home/user/vrn2_work/v175"); V2 = W / "t175a" / "VIA" / "VIA_Reports" / "vrn2"


def txt(p):
    return Path(p).read_text(encoding="utf-8", errors="replace") if Path(p).is_file() else ""


wb1, wb2 = txt(W / "wb_auto1_full.html"), txt(W / "wb_auto2.html")
log1, log2 = txt(W / "tiny_auto1.log"), txt(W / "tiny_auto2.log")
fd = json.loads(txt(W / "out_auto2" / "VRN2_FinancialData_latest.json") or "[]")
csvh = next(csv.reader(io.StringIO(txt(W / "out_auto2" / "VRN2_FinancialData_latest.csv").lstrip("﻿"))), [])
store = json.loads(txt(V2 / "VRN2_OutputStore_latest.json") or "{}")
bsr = json.loads(txt(V2 / "VRN2_BookSource_latest.json") or "{}")
plan = next((l for l in log2.splitlines() if "⑤ 自動修計畫" in l), "")
src_fix = next((l for l in log2.splitlines() if "⑤ 修 · ⑬a" in l), "")
wb_fix = next((l for l in log2.splitlines() if "⑤ 修 · Workbench" in l), "")
st_fix = next((l for l in log2.splitlines() if "⑤ 修 · ⑬ 增量庫" in l), "")
a1_13a = next((l for l in log1.splitlines() if "⑬a 輸出冊 Source / Broker 欄 ·" in l), "")
report_books = ("BasicInfo", "FinancialData", "Summary", "Combined", "Rejected", "FinancialAligned", "Deleted")
app = store.get("appended") or {}
out = {"auto1_13a": re.sub(r"\x1b\[[0-9;]*m", "", a1_13a).strip()[:200],
       "auto1_page_v0109": wb1.count('id="wb109-tpl"') == 1 and 'id="wb109v"' in wb1,
       "auto2_page_v0109": wb2.count('id="wb109-tpl"') == 1 and 'id="wb109v"' in wb2 and 'id="wb109a"' in wb2 and 'id="wb109i"' in wb2,
       "auto2_books_cols": bool(fd) and all(list(r)[-2:] == ["BROKER_EN", "SOURCE"] for r in fd) and csvh[-2:] == ["BROKER_EN", "SOURCE"],
       "rows_FinancialData": len(fd), "booksource_receipt": {k: bsr.get(k) for k in ("lamp", "why", "unmapped")},
       "plan": plan.split("⑤ 自動修計畫", 1)[-1].strip(":: ")[:400],
       "plan_ok": all(x in plan for x in ("⑬a 輸出冊 SOURCE / BROKER_EN", "⑬ 增量庫", "Workbench 重渲染")) and plan.index("⑬a") < plan.index("⑬ 增量庫"),
       "source_fix": src_fix.strip()[:220], "store_fix": st_fix.strip()[:260], "workbench_fix": wb_fix.strip()[:200],
       "store": "auto2 追加 %s · 補欄 %s · 累計 %s" % (json.dumps({b: app.get(b) for b in report_books if b in app}, ensure_ascii=False),
                                                  json.dumps((store.get("derived_fill") or {}).get("filled") or {}, ensure_ascii=False), json.dumps(store.get("totals") or {}, ensure_ascii=False)),
       "store_no_double": bool(app) and all(not app.get(b) for b in report_books) and "derived_fill" in store}
s = json.dumps(out, ensure_ascii=False, indent=1).replace(str(W / "t175a"), "<sbx>")
(W / "e2e175_check.json").write_text(s, encoding="utf-8")
print(s)
