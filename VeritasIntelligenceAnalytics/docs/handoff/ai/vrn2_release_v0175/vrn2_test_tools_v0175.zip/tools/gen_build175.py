"""從 build174.py 生 build175.py(套件 v0175 · RoundAll v0131 · Handle-All v0123)。"""
import re
from pathlib import Path

s = Path("/home/user/vrn2_work/v174/build174.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep(s.split('"""', 2)[1], "v0175(冪等):套件 VRN2_Closeout_v0175.zip(啟動器 v0175 · runtime v0164 = v0163 + BookSource v0100 + OutputStore v0103 + Workbench v0109)\n"
    "→ RoundAll v0131(填套件雜湊)→ Handle-All v0123(指到 v0131 · 收據 ≥ v0170 照舊 repair)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0175)。vrn2_release_v0174 及更早不動。")
rep('W = Path("/home/user/vrn2_work/v174"); pkg, rel = W / "pkg174", W / "release174"', 'W = Path("/home/user/vrn2_work/v175"); pkg, rel = W / "pkg175", W / "release175"')
rep('PREV = Path("/home/user/vrn2_work/v173/release173")', 'PREV = Path("/home/user/vrn2_work/v174/release174")')
rep('(REPO / "vrn2_release_v0172/VRN2_Release_v0172.json")', '(REPO / "vrn2_release_v0174/VRN2_Release_v0174.json")')
rep('(REPO / "vrn2_release_v0173/VRN2_Release_v0173.json")', '(REPO / "vrn2_release_v0174/VRN2_Release_v0174.json")')
rep('(pkg / "VRN2_Runtime_v0163.json")', '(pkg / "VRN2_Runtime_v0164.json")')
rep('(pkg / "VRN2_Runtime_v0163.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0162.zip "', '(pkg / "VRN2_Runtime_v0164.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0163.zip "')
rep('rt["retained_members"] == 203 and rt["new_members"] == ["VRN2_Workbench_v0108.py"]',
    'rt["retained_members"] == 204 and rt["new_members"] == ["VRN2_BookSource_v0100.py", "VRN2_OutputStore_v0103.py", "VRN2_Workbench_v0109.py"]')
rep('"ActivateVRN-2_v0174.py", "VRN2_Runtime_v0163.zip", "VRN2_Runtime_v0163.json"', '"ActivateVRN-2_v0175.py", "VRN2_Runtime_v0164.zip", "VRN2_Runtime_v0164.json"', 2)
rep("# 其他成員跟 v0172 逐位元組相同", "# 其他成員跟 v0174 逐位元組相同")
i0 = s.index('files["README.txt"] = ('); i1 = s.index('files["VALIDATION_RESULT.json"]')
s = s[:i0] + '''files["README.txt"] = ("VRN2_Closeout_v0175 — VRN-2 closeout package (2026-11-03 · ⑬a book Source / Broker columns · OutputStore v0103 · Workbench v0109)\\n\\n"
  "Entry: python ActivateVRN-2_v0175.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0131.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0123.md (same release folder).\\n"
  "Runtime: VRN2_Runtime_v0164.zip = v0163 (204 members byte-identical) + VRN2_BookSource_v0100 + VRN2_OutputStore_v0103 + VRN2_Workbench_v0109.\\n\\n"
  "v0175 (operator 2026-11-03: broker abbreviations · physical Source column in the books and the store · Detail-column font · 系統摘要 matrices · step panel):\\n"
  " - ⑬a VRN2_BookSource_v0100 (after ⑬b, before ⑬): BROKER_EN + SOURCE as the last two columns of the seven report books (JSON / CSV / Parquet;\\n"
  "   other values byte-identical; BROKER kept as written in the report; MarketConsensus keeps its own SOURCE). VIA_VRN2_NO_BOOKSOURCE=1 opts out.\\n"
  " - VRN2_OutputStore_v0103: the row hash ignores SOURCE / BROKER_EN (no re-append); rows already stored get the two columns filled in place\\n"
  "   (DuckDB file backed up first · affected run partitions rewritten · restore-fill --folder <_source_fill_ folder>).\\n"
  " - VRN2_Workbench_v0109: Detail-column font (Consolas + Microsoft JhengHei 10.45 px) everywhere; 00 tab = 系統摘要 with verification and consensus\\n"
  "   matrices; 04 open acceptance items as a matrix; English + Chinese two-line headers; notes under each card; full-width punctuation beside Chinese;\\n"
  "   numbered left-panel steps; input classification matrix (stock report / non-stock report / news / page image / unclassified x file type).\\n"
  "v0174: Workbench v0108 (ENG049 template lock · Freshness · Ticker / YFinance · broker abbreviations · YYYY dates · Source). v0172: HistoryAlign v0103 ·\\n"
  "ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107. v0163: no MOPS.\\n"
  "Verification: see VRN2_Verification_v0175.md. Hashes: PACKAGE_SHA256.json.\\n").encode("utf-8")
''' + s[i1:]
s = s.replace("VRN2_Verification_v0174.md", "VRN2_Verification_v0175.md")
rep('manifest = {"system": "VRN-2", "version": "v0174",', 'manifest = {"system": "VRN-2", "version": "v0175",')
rep('zpr = rel / "VRN2_Closeout_v0174.zip"', 'zpr = rel / "VRN2_Closeout_v0175.zip"')
rep('zipfile.ZipInfo("VRN2_Closeout_v0174/" + n, date_time=(2026, 11, 3, 1, 0, 0))', 'zipfile.ZipInfo("VRN2_Closeout_v0175/" + n, date_time=(2026, 11, 3, 2, 0, 0))')
rep('(W / "new/VRN2_RoundAll_v0130.py")', '(W / "new/VRN2_RoundAll_v0131.py")')
rep("'PACKAGE = \"VRN2_Closeout_v0174\"' in ra and 'VERSION = \"v0130\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174\"' in ra",
    "'PACKAGE = \"VRN2_Closeout_v0175\"' in ra and 'VERSION = \"v0131\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175\"' in ra")
rep('(rel / "VRN2_RoundAll_v0130.py").write_text(ra', '(rel / "VRN2_RoundAll_v0131.py").write_text(ra')
m0 = re.search(r'^rep\("\$P = ', s, re.M).start()
m1 = s.index("ha_line = join(ha)")
s = s[:m0] + '''rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175'")
rep("$F = 'VRN2_RoundAll_v0130.py'", "$F = 'VRN2_RoundAll_v0131.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0122", "Handle-All v0123", ha.count("Handle-All v0122"))
rep("套件 v0174 裝在新夾 VRN2_Closeout_v0174", "套件 v0175 裝在新夾 VRN2_Closeout_v0175")
rep("取套件 v0174 → 診斷 → 全部自測 → 跑啟動器 v0174(", "取套件 v0175 → 診斷 → 全部自測 → 跑啟動器 v0175(")
rep("Workbench v0108(ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / YYYY 日期 / Source · 含 v0107)",
    "⑬a BookSource v0100(輸出冊實體 SOURCE / BROKER_EN)· 增量庫 OutputStore v0103(不重複追加 · 舊列補欄)· Workbench v0109(細節字型 · 系統摘要矩陣 · 表頭雙行 · 左欄步驟 · 輸入分類 · 含 v0108)")
rep("repair = '取套件 v0174 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;Workbench v0108 模板鎖定 + 時效 / Ticker / Source;",
    "repair = '取套件 v0175 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 輸出冊寫 SOURCE / BROKER_EN 兩欄 · 增量庫 v0103 舊列補欄(先備份)· Workbench v0109 細節字型 + 系統摘要矩陣 + 左欄步驟;")
rep("只重跑 ⑪ 獨立驗證(套件 v0174 的", "只重跑 ⑪ 獨立驗證(套件 v0175 的")
left = [l for l in ha.split("\\n") if re.search(r"Handle-All v0122|v0130[.]py|release_v0174|套件 v0174|Closeout_v0174", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
''' + s[m1:]
rep('("vrn2_release_v0173", "vrn2_release_v0174"), ("VRN2_HandleAll_v0121.md", "VRN2_HandleAll_v0122.md"), ("Handle-All v0121 SHA-256 OK", "Handle-All v0122 SHA-256 OK")',
    '("vrn2_release_v0174", "vrn2_release_v0175"), ("VRN2_HandleAll_v0122.md", "VRN2_HandleAll_v0123.md"), ("Handle-All v0122 SHA-256 OK", "Handle-All v0123 SHA-256 OK")')
rep('(rel / "VRN2_HandleAll_v0122_boot.txt")', '(rel / "VRN2_HandleAll_v0123_boot.txt")')
rep("vrn2_release_v0174/VRN2_HandleAll_v0122_boot.txt", "vrn2_release_v0175/VRN2_HandleAll_v0123_boot.txt")
i0 = s.index('md = """'); i1 = s.index('print("package"')
s = s[:i0] + Path("/home/user/vrn2_work/v175/build175_tail.py").read_text(encoding="utf-8") + s[i1:]
Path("/home/user/vrn2_work/v175/build175.py").write_text(s, encoding="utf-8")
print("ok")
