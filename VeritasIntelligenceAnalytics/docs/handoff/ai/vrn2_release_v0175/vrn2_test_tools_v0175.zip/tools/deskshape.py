"""桌機形狀檢查:操作員上傳的 FinancialData 匯出(只在沙盒)→ 去掉 v0108 匯出加的 SOURCE → 當成輸出冊 → BookSource v0100 寫兩欄 → 只記筆數與結論。"""
import collections, importlib.util, json, sys, tempfile
from pathlib import Path
up = Path(sys.argv[1]); mod = Path(sys.argv[2])
rows = json.loads(up.read_text(encoding="utf-8-sig"))["rows"]
spec = importlib.util.spec_from_file_location("bs", mod); bs = importlib.util.module_from_spec(spec); spec.loader.exec_module(bs)
with tempfile.TemporaryDirectory() as td:
    v2 = Path(td) / "vrn2"; (v2 / "output").mkdir(parents=True)
    book = [{k: v for k, v in r.items() if k not in ("SOURCE", "BROKER_EN")} for r in rows]
    (v2 / "output" / "VRN2_FinancialData_latest.json").write_text(json.dumps(book, ensure_ascii=False), encoding="utf-8")
    rec = bs.apply(v2)
    got = json.loads((v2 / "output" / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
    same = all({k: v for k, v in g.items() if k not in bs.COLS} == b for g, b in zip(got, book))
    exp_src = collections.Counter(r.get("SOURCE") for r in rows)
    new_src = collections.Counter(g["SOURCE"] for g in got)
    match_v108 = sum(1 for g, r in zip(got, rows) if g["SOURCE"] == r.get("SOURCE"))
    print(json.dumps({"rows": len(rows), "lamp": rec["lamp"], "last_two_columns": all(list(g)[-2:] == ["BROKER_EN", "SOURCE"] for g in got), "other_values_identical": same,
                      "source_counts": dict(new_src), "same_as_v0108_export_source": "%d / %d" % (match_v108, len(rows)),
                      "brokers": len({g.get("BROKER") for g in got}), "broker_en_mapped_rows": sum(1 for g in got if g["BROKER_EN"]), "unmapped": rec["unmapped"]}, ensure_ascii=False))
