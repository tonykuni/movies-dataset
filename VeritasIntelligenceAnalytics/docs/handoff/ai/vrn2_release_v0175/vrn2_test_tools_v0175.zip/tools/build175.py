"""v0175(冪等):套件 VRN2_Closeout_v0175.zip(啟動器 v0175 · runtime v0164 = v0163 + BookSource v0100 + OutputStore v0103 + Workbench v0109)
→ RoundAll v0131(填套件雜湊)→ Handle-All v0123(指到 v0131 · 收據 ≥ v0170 照舊 repair)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0175)。vrn2_release_v0174 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v175"); pkg, rel = W / "pkg175", W / "release175"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v174/release174")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0174/VRN2_Release_v0174.json").read_text(encoding="utf-8"))
r171 = json.loads((REPO / "vrn2_release_v0174/VRN2_Release_v0174.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0164.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0164.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0163.zip " + r170["runtime"]["zip_sha256"]
assert rt["retained_members"] == 204 and rt["new_members"] == ["VRN2_BookSource_v0100.py", "VRN2_OutputStore_v0103.py", "VRN2_Workbench_v0109.py"]
old = {c["path"]: c["sha256"] for c in r170["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0175.py", "VRN2_Runtime_v0164.zip", "VRN2_Runtime_v0164.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0175.py", "VRN2_Runtime_v0164.zip", "VRN2_Runtime_v0164.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0174 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0175 — VRN-2 closeout package (2026-11-03 · ⑬a book Source / Broker columns · OutputStore v0103 · Workbench v0109)\n\n"
  "Entry: python ActivateVRN-2_v0175.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0131.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0123.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0164.zip = v0163 (204 members byte-identical) + VRN2_BookSource_v0100 + VRN2_OutputStore_v0103 + VRN2_Workbench_v0109.\n\n"
  "v0175 (operator 2026-11-03: broker abbreviations · physical Source column in the books and the store · Detail-column font · 系統摘要 matrices · step panel):\n"
  " - ⑬a VRN2_BookSource_v0100 (after ⑬b, before ⑬): BROKER_EN + SOURCE as the last two columns of the seven report books (JSON / CSV / Parquet;\n"
  "   other values byte-identical; BROKER kept as written in the report; MarketConsensus keeps its own SOURCE). VIA_VRN2_NO_BOOKSOURCE=1 opts out.\n"
  " - VRN2_OutputStore_v0103: the row hash ignores SOURCE / BROKER_EN (no re-append); rows already stored get the two columns filled in place\n"
  "   (DuckDB file backed up first · affected run partitions rewritten · restore-fill --folder <_source_fill_ folder>).\n"
  " - VRN2_Workbench_v0109: Detail-column font (Consolas + Microsoft JhengHei 10.45 px) everywhere; 00 tab = 系統摘要 with verification and consensus\n"
  "   matrices; 04 open acceptance items as a matrix; English + Chinese two-line headers; notes under each card; full-width punctuation beside Chinese;\n"
  "   numbered left-panel steps; input classification matrix (stock report / non-stock report / news / page image / unclassified x file type).\n"
  "v0174: Workbench v0108 (ENG049 template lock · Freshness · Ticker / YFinance · broker abbreviations · YYYY dates · Source). v0172: HistoryAlign v0103 ·\n"
  "ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107. v0163: no MOPS.\n"
  "Verification: see VRN2_Verification_v0175.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0175.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0175", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0175.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0175/" + n, date_time=(2026, 11, 3, 2, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0131.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0175"' in ra and 'VERSION = "v0131"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175"' in ra
(rel / "VRN2_RoundAll_v0131.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175'")
rep("$F = 'VRN2_RoundAll_v0130.py'", "$F = 'VRN2_RoundAll_v0131.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0122", "Handle-All v0123", ha.count("Handle-All v0122"))
rep("套件 v0174 裝在新夾 VRN2_Closeout_v0174", "套件 v0175 裝在新夾 VRN2_Closeout_v0175")
rep("取套件 v0174 → 診斷 → 全部自測 → 跑啟動器 v0174(", "取套件 v0175 → 診斷 → 全部自測 → 跑啟動器 v0175(")
rep("Workbench v0108(ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / YYYY 日期 / Source · 含 v0107)",
    "⑬a BookSource v0100(輸出冊實體 SOURCE / BROKER_EN)· 增量庫 OutputStore v0103(不重複追加 · 舊列補欄)· Workbench v0109(細節字型 · 系統摘要矩陣 · 表頭雙行 · 左欄步驟 · 輸入分類 · 含 v0108)")
rep("repair = '取套件 v0174 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;Workbench v0108 模板鎖定 + 時效 / Ticker / Source;",
    "repair = '取套件 v0175 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 輸出冊寫 SOURCE / BROKER_EN 兩欄 · 增量庫 v0103 舊列補欄(先備份)· Workbench v0109 細節字型 + 系統摘要矩陣 + 左欄步驟;")
rep("只重跑 ⑪ 獨立驗證(套件 v0174 的", "只重跑 ⑪ 獨立驗證(套件 v0175 的")
left = [l for l in ha.split("\n") if re.search(r"Handle-All v0122|v0130[.]py|release_v0174|套件 v0174|Closeout_v0174", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0174", "vrn2_release_v0175"), ("VRN2_HandleAll_v0122.md", "VRN2_HandleAll_v0123.md"), ("Handle-All v0122 SHA-256 OK", "Handle-All v0123 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0123_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175/VRN2_HandleAll_v0123_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0123(2026-11-03 · ⑬a 輸出冊實體 SOURCE / BROKER_EN · 增量庫 v0103 · Workbench v0109 · 套件 v0175 · RoundAll v0131)

操作員 2026-11-03 要求 → 做法:

| 要求 | v0175 |
|---|---|
| BROKER 一律用英文縮寫 | 輸出冊每一列多一欄 **BROKER_EN**(中信 CTBC · 凱基 KGI · 兆豐 Mega · 華南 HNS · 國泰 Cathay · Goldman Sachs GS · Morgan Stanley MS · J.P. Morgan JPM · Macquarie MQ …;BROKER 原文不改,驗證器照舊拿它對 PDF)· 畫面券商欄一律顯示縮寫 · 對不到的留空並列在收據(縮寫表是候選 · 等 VCGC 核發)|
| 輸出冊和增量庫也實體加 Source 欄 | ⑬a `VRN2_BookSource_v0100`:七本報告冊(JSON / CSV / Parquet)最後兩欄 BROKER_EN · SOURCE(其他值逐位元組不變 · 沒變就不寫)· 增量庫 `VRN2_OutputStore_v0103`:列雜湊不算這兩欄(**不會整庫重複追加**)· 庫裡舊列就地補兩欄(先備份 DuckDB 檔 · 可 restore-fill)|
| 字體大小及格式一致 · 以「細節 / Detail」字型字級為主 · 整字小一點 | 全頁內文 = Consolas + 微軟正黑體 10.45px(細節欄那一套)· 區段標題 11px · 表頭 / 標籤 9px · 標記 8px · 只留頁首品牌與大標 19px · 顏色仍是 ENG049 模板 15 色 |
| 資料驗證狀況放入系統現況 · 改名系統摘要 · 矩陣化燈號化 | 00 頁改名「系統摘要」· 原本頁首上方那一排燈改成系統摘要裡的矩陣(燈號 · 項目 · 細節)· 共識矩陣(FactSet 目標價中位數 · Yahoo 目標價中位數 · FactSet 分析師人數 · Yahoo 分析師人數 · 兩源檢核)|
| 尚未跨越的驗收條件特別亂 | 04 頁改成「待驗收項目」矩陣(燈號 · 類別 · 項目 · 細節 · 次數)· 同項合併計次 · 紅先黃後 · 細節兩行、點一下展開 |
| 不用括號說明 · 備註放底下 · 全形標點 · 表頭統一寫完整 | 表頭一律英文一行 + 中文一行 · 標題括號說明移到卡片底下的「註」· 中文旁的括號、冒號、逗號改全形(檔名、路徑、資料值不動)|
| 資料不可超過卡片及格子 | 卡片 / 格子 / 矩陣內文自動換行 · 瀏覽器實測 0 個溢出格 |
| 左面板文字雜亂 → 步驟編號 | 1 選擇報告來源 → 2 確認輸入 → 3 啟動處理 → 4 輸出位置 → 5 開啟資料夾 → 6 其他系統 · 小圓圈編號(完成的步驟綠框)· 說明移到左欄最底下 |
| Word / 影像有處理嗎 · 分 STOCK / NON-STOCK / NEWS 嗎 | 01 頁「輸入分類」矩陣:個股報告 · 非個股報告 · 新聞與盤勢 · 頁面影像 · 未分類 × PDF / Word / TXT / 影像 / 其他 · 處理方式(本版主體只擷取 PDF;Word 要先轉 PDF、影像要 OCR)|

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0175/VRN2_Closeout_v0175.zip`(SHA-256 `%s` · 啟動器 v0175 · runtime v0164 = v0163 + BookSource v0100 + OutputStore v0103 + Workbench v0109)|
| 一支 Python | `VRN2_RoundAll_v0131.py`(SHA-256 `%s` · 自測 103 項 · repair:⑬a 寫兩欄 → ⑬ 補欄 → 重渲染 v0109)|
| 自動選模式 | 收據 ≥ v0170 → **repair(幾分鐘)**:⑬a + ⑬ + Workbench |

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0123 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0131 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0131.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0131.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0123.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0131.py(套件 v0175 · ⑬a BookSource · OutputStore v0103 · Workbench v0109)

`VRN2_RoundAll_v0131.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0130 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0175/VRN2_Closeout_v0175.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0175 · runtime v0164 = v0163 + BookSource v0100 + OutputStore v0103 + Workbench v0109 |
| ⑤ source(新)| 輸出冊還沒有 SOURCE / BROKER_EN、或比上次寫欄新、或本輪重算 ⑬b / Combined → 只增不覆寫補放 BookSource v0100 → 寫最後兩欄 · 舊收據沒有 ⑬a 步驟就補一列在 ⑬ 前面 · 排在 store 之前 |
| ⑤ store | 補放鏈多 OutputStore v0103(雜湊不算兩欄 · 舊列補欄 · 先備份)· 增量庫收據沒有 derived_fill 也排 |
| ⑤ workbench | 頁面沒有 v0109 標記(`id="wb109-tpl"`)→ 補放 v0109 + v0108 + v0107 → 重渲染 |
| ③ 自測清單 | Workbench v0109 · OutputStore v0103 · BookSource v0100 |
| 貼回包 | 多 VRN2_BookSource_latest.json |
| 自測 | 103 項(v0130 的 100 項 + 101 · 101b · 101c · 舊項目在 VIA_VRN2_NO_BOOKSOURCE=1 下跑)|
| ⑥ 除錯 | Combined 最後兩欄是 ⑬a 實體欄 → 欄序照 ConsensusJoin 清單比(兩欄另記)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0131.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0175 (launcher v0175 · runtime v0164) + VRN2_RoundAll_v0131 + VRN2_HandleAll_v0123", "date": "2026-11-03",
        "trigger": "操作員 2026-11-03:BROKER 一律用英文縮寫 · 輸出冊和增量庫也實體加 Source 欄 · 字型字級以細節 / Detail 為準 · 資料驗證狀況放入系統現況並改名系統摘要 · 所有資訊矩陣化燈號化 · "
                   "不用括號說明 · 備註放底下 · 全形標點 · 表頭統一寫完整 · 資料不可超過卡片及格子 · 左面板步驟編號 · Word / 影像處理與 STOCK / NON-STOCK / NEWS 分類",
        "data_rule": "BookSource writes BROKER_EN + SOURCE as the last two columns of the seven report books; every other value is byte-identical (JSON keeps its indent, CSV keeps BOM / CRLF, Parquet keeps column types); "
                     "BROKER stays as written in the report; MarketConsensus keeps its own SOURCE; window.VRN2_DATA still equals the output books",
        "store_rule": "OutputStore v0103 row hash ignores SOURCE / BROKER_EN (no re-append); stored rows get the two columns filled in place after a DuckDB file backup (restore-fill)",
        "ui": {"font": "Consolas + Microsoft JhengHei 10.45 px (the Detail column) · section 11 · labels 9 · tags 8 · display 19 (brand / title / stats)", "palette": "ENG049 template 15 colours (unchanged)",
               "summary": "00 tab 系統摘要: verification matrix (status · item · detail) + consensus matrix (FactSet 目標價中位數 · FactSet 分析師人數 …)",
               "acceptance": "04 tab 待驗收項目 matrix (status · category · item · detail · count)", "headers": "English line + Chinese line everywhere", "left_panel": "numbered steps 1–6",
               "input_classes": "stock report · non-stock report · news and market notes · page image · unclassified × PDF / Word / TXT / image / other (filename candidates; PDF only is extracted)"},
        "fixes": {"BookSource_v0100": "new family · ⑬a · selftest 14 (rules cross-checked with Workbench v0108)", "OutputStore_v0103": "thin tail over v0102 · selftest v0102 + 2 engines × 5",
                  "Workbench_v0109": "thin tail over v0108 · selftest 12 · CSS SHA-256 pinned", "launcher_v0175": "⑬a between ⑬b and ⑬ · OutputStore v0103 / Workbench v0109 active",
                  "RoundAll_v0131": "package v0175 pin · ⑤ source / store fill / workbench v0109 · selftest 103 · Combined column check ignores the two ⑬a columns", "HandleAll_v0123": "points at RoundAll v0131 / release v0175"},
        "package": {"name": "VRN2_Closeout_v0175.zip", "sha256": want, "release_folder": "vrn2_release_v0175", "changed": True, "launcher": "ActivateVRN-2_v0175.py"},
        "runtime": {"name": "VRN2_Runtime_v0164.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 204, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0130.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0174"}],
        "roundall": {"name": "VRN2_RoundAll_v0131.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0131.md"},
        "handleall": {"name": "VRN2_HandleAll_v0123.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0123_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "BookSource v0100 (new family) · OutputStore v0103 · Workbench v0109 · runtime v0164 · launcher / package / receipt v0175 · RoundAll v0131 · HandleAll v0123 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0175.md"}}
(rel / "VRN2_Release_v0175.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
