"""VRN2_RoundAll_v0131.py = 本線 v0130(倉裡 vrn2_release_v0174)+ 套件 v0175(啟動器 v0175 · runtime v0164)+ ⑤ ⑬a 輸出冊 SOURCE / BROKER_EN · ⑬ OutputStore v0103 補欄 ·
Workbench v0109 補放 / 重渲染。操作員 2026-11-03(BROKER 英文縮寫 · 輸出冊和增量庫實體加 Source 欄 · 細節字型 · 系統摘要矩陣 · 左欄步驟)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v175")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0174/VRN2_RoundAll_v0130.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0130')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0130 — ', '"""VRN2_RoundAll v0131 — ', 1)
at = doc.index("v0130(")
doc = doc[:at] + '''v0131(操作員 2026-11-03:「BROKER 一律用英文縮寫 · 輸出冊和增量庫也實體加 Source 欄 · 字型字級以細節 / Detail 為準 · 資料驗證狀況放入系統摘要 ·
  所有資訊矩陣化、燈號化 · 表頭統一 · 左面板步驟編號 · 說明放底下 · 全形標點」):
  · 套件 v0175(啟動器 v0175 · runtime v0164 = v0163 的 204 個成員一字不改 + BookSource v0100 + OutputStore v0103 + Workbench v0109)。
  · ⑤ 新增 source:輸出冊還沒有 SOURCE / BROKER_EN、或比上次寫欄的收據新、或本輪重算 ⑬b / Combined → 只增不覆寫補放 BookSource v0100 → 寫最後兩欄
    (BROKER 原文不改 · 其他值逐位元組不變)· 收據沒有 ⑬a 步驟(v0174 以前的啟動器)→ 補一列在 ⑬ 前面。排在 store 之前(增量庫收到兩欄)。
  · ⑤ store:補放鏈多 OutputStore v0103(雜湊不算 SOURCE / BROKER_EN · 已在庫裡的列不重複追加 · 舊列就地補欄 · 先備份 · restore-fill);
    增量庫收據沒有 derived_fill(v0103 還沒跑過)→ 也排 store。
  · ⑤ workbench 觸發換成 v0109 標記(id="wb109-tpl");補放 WORKBENCH_CHAIN = v0109 + v0108 + v0107。⑥ Workbench 標記多「細節字型 · 系統摘要矩陣」。
  · ③ 自測清單:Workbench v0108 → v0109 · OutputStore v0102 → v0103 · 多 BookSource v0100。貼回包多 VRN2_BookSource_latest.json。
  · ⑥ 除錯:Combined 最後兩欄是 ⑬a 實體欄 → 欄序照 ConsensusJoin 清單比(沙盒整輪多出「欄序不同」VRN-2 1 項)。
  · 自測 103 項(v0130 的 100 項 + 101 · 101b · 101c;舊項目在 VIA_VRN2_NO_BOOKSOURCE=1 下跑,行為不變)。VIA_VRN2_NO_BOOKSOURCE=1 → 不排 ⑬a / 補欄。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0130.py", "用法:python VRN2_RoundAll_v0131.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


b0 = s.index('VERSION = "v0130"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0174", "v0175").replace("VRN2_Runtime_v0163", "VRN2_Runtime_v0164")
s = pre + post
rep('VERSION = "v0130"', 'VERSION = "v0131"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0130.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0130.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0131.py"', n_dl)
rep('"VRN2_RoundAll_v0130.py" in html_', '"VRN2_RoundAll_v0131.py" in html_')
rep("· v0128 起 98 項 · v0129 起 99 項 · v0130 起 100 項。", "· v0128 起 98 項 · v0129 起 99 項 · v0130 起 100 項 · v0131 起 103 項。")
n = s.count('("VRN2_Workbench_v0108.py", 600)')
rep('("VRN2_Workbench_v0108.py", 600)', '("VRN2_Workbench_v0109.py", 600)', n)
n = s.count('("VRN2_OutputStore_v0102.py", 300)')
rep('("VRN2_OutputStore_v0102.py", 300)', '("VRN2_OutputStore_v0103.py", 300)', n)
rep('SELFTESTS = (("VRN2_Workbench_v0109.py", 600),', 'SELFTESTS = (("VRN2_Workbench_v0109.py", 600), ("VRN2_BookSource_v0100.py", 300),')
rep('STORE_CHAIN = ("VRN2_OutputStore_v0102.py", "VRN2_OutputStore_v0101.py", "VRN2_OutputStore_v0100.py")',
    'STORE_CHAIN = ("VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py", "VRN2_OutputStore_v0101.py", "VRN2_OutputStore_v0100.py")   # v0131 v0103 補欄\n'
    'BOOKSOURCE_CHAIN = ("VRN2_BookSource_v0100.py",)                             # v0131 ⑬a 輸出冊 SOURCE / BROKER_EN\n'
    'BOOKSOURCE_RECEIPT = "VRN2_BookSource_latest.json"\n'
    'SOURCE_BOOKS = ("BasicInfo", "FinancialData", "Summary", "Combined", "Rejected", "FinancialAligned", "Deleted")')
rep('            and STORE_CHAIN[0] == "VRN2_OutputStore_v0102.py")', '            and STORE_CHAIN[0] == "VRN2_OutputStore_v0103.py")')
rep('''('id="wb108-tpl"', "ENG049 視覺模板鎖定 · 時效 / Ticker / Source(Workbench v0108)"))''',
    '''('id="wb108-tpl"', "ENG049 視覺模板鎖定 · 時效 / Ticker / Source(Workbench v0108)"), ('id="wb109-tpl"', "細節字型 · 系統摘要矩陣 · 表頭雙行 · 左欄步驟(Workbench v0109)"))''')
rep('WORKBENCH_CHAIN = ("VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")         # v0130 v0108 薄尾要 v0107 在旁(v0128 起只增不覆寫補放)',
    'WORKBENCH_CHAIN = ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")   # v0131 v0109 → v0108 → v0107(只增不覆寫補放)')
rep("""WB_MARK = 'id="wb108-tpl"'                                                   # v0130 頁面不是 v0108 後處理過的 → 重渲染""",
    """WB_MARK = 'id="wb109-tpl"'                                                   # v0131 頁面不是 v0109 後處理過的 → 重渲染""")
rep('"Workbench 重渲染(換 v0108 · ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / Source)"',
    '"Workbench 重渲染(換 v0109 · 細節字型 · 系統摘要矩陣 · 表頭雙行 · 左欄步驟 · 輸入分類)"')
rep("install_chain(state.get(\"pkg\"), root, WORKBENCH_CHAIN)                 # v0130 Workbench v0108 + v0107 只增不覆寫",
    "install_chain(state.get(\"pkg\"), root, WORKBENCH_CHAIN)                 # v0131 Workbench v0109 + v0108 + v0107 只增不覆寫")
rep('            and HISTORY_CHAIN[0] == "VRN2_HistoryAlign_v0103.py" and WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0108.py")',
    '            and HISTORY_CHAIN[0] == "VRN2_HistoryAlign_v0103.py" and WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0109.py")')
# ── source_due + plan ──
rep('''def history_due_why(v2, planned) -> str:''', '''def source_due(v2, planned) -> str:
    """v0131 ⑬a 要不要寫 SOURCE / BROKER_EN:本輪重算 ⑬b / Combined · 沒有收據 · 輸出冊比收據新 → 原因;不用 → ""。"""
    if os.environ.get("VIA_VRN2_NO_BOOKSOURCE") == "1":
        return ""
    out = Path(v2) / "output"
    books = [out / ("VRN2_%s_latest.json" % b) for b in SOURCE_BOOKS if (out / ("VRN2_%s_latest.json" % b)).is_file()]
    if not books:
        return ""
    if planned & {"history", "combined"}:
        return "本輪重算歷史對齊 / Combined"
    rec = Path(v2) / BOOKSOURCE_RECEIPT
    if not rec.is_file():
        return "輸出冊還沒有 SOURCE / BROKER_EN 欄"
    newer = [p.name[5:-12] for p in books if _mtime(p) > _mtime(rec)]
    return ("輸出冊比上次寫欄新(%s)" % "、".join(newer)) if newer else ""


def history_due_why(v2, planned) -> str:''')
rep('''    planned = {p[0] for p in plan}
    store = jread(v2 / "VRN2_OutputStore_latest.json", {}) or {}''', '''    planned = {p[0] for p in plan}
    s_why = source_due(v2, planned)                                            # v0131 ⑬a 排在 store 之前
    if s_why:
        plan.append(("source", "⑬a 輸出冊 SOURCE / BROKER_EN 欄:%s → BookSource v0100 寫最後兩欄(BROKER 原文不改 · 其他值不變)" % s_why))
    planned = {p[0] for p in plan}
    store = jread(v2 / "VRN2_OutputStore_latest.json", {}) or {}''')
rep('''    if cfg.get("output_dir") and (planned or missing_books or dirty):''', '''    fill_due = cfg.get("output_dir") and store and "derived_fill" not in store and os.environ.get("VIA_VRN2_NO_BOOKSOURCE") != "1"   # v0131 OutputStore v0103 還沒跑過
    if cfg.get("output_dir") and (planned or missing_books or dirty or fill_due):''')
rep('''"本輪有修正" if planned else ("庫裡還沒有 " + "、".join(missing_books) if missing_books else "OutputStore v0102"))))''',
    '''"本輪有修正" if planned else ("庫裡還沒有 " + "、".join(missing_books) if missing_books else ("OutputStore v0103 補 SOURCE / BROKER_EN 欄" if fill_due else "OutputStore v0102")))))''')
# ── step_fix source branch + store detail ──
rep('''        elif key == "combined":
            if state.get("pkg"):''', '''        elif key == "source":                                                  # v0131 ⑬a
            put_s, refused_s = install_chain(state.get("pkg"), root, BOOKSOURCE_CHAIN)
            bs = _latest_in(rt, "VRN2_BookSource_v[0-9][0-9][0-9][0-9].py")
            if bs:
                rc, lines = run_stream([vpy, "-X", "utf8", str(bs), "apply", "--v2", str(v2)], cwd=rt, env=env, timeout=900, prefix="    [⑬a] ")
                lamp, detail = _cli_lamp(lines)
            else:
                lamp, detail = "YELLOW", "私有 runtime 沒有 VRN2_BookSource_v*.py(套件沒放進來)"
            detail = ("%s%s%s" % (("補放 " + "、".join(put_s) + " · ") if put_s else "", ("不覆寫 " + " / ".join(refused_s)[:120] + " · ") if refused_s else "", detail)).strip(" ·")
            steps_r = receipt.setdefault("steps", [])
            if not any(str(x.get("step", "")).startswith("⑬a") for x in steps_r):      # v0174 以前的收據沒有 ⑬a → 補在 ⑬ 前面
                at = next((i for i, x in enumerate(steps_r) if str(x.get("step", "")).startswith("⑬ ")), len(steps_r))
                steps_r.insert(at, {"step": "⑬a 輸出冊 Source / Broker 欄(實體)", "lamp": "GRAY", "detail": ""})
            step_updates["⑬a"] = (lamp if lamp != "RED" else "YELLOW", detail)
        elif key == "combined":
            if state.get("pkg"):''')
rep('''                pg = rec.get("mops_purge") or {}''', '''                fl = rec.get("derived_fill") or {}                         # v0131 OutputStore v0103 補欄
                if fl.get("filled") or fl.get("lamp") in ("YELLOW", "RED"):
                    detail = "補欄 %s · %s" % (fl.get("why", ""), detail)
                pg = rec.get("mops_purge") or {}''')
rep('''PASTE_FILES = ("VRN2_Closeout_v0175.json",''', '''PASTE_FILES = ("VRN2_BookSource_latest.json", "VRN2_Closeout_v0175.json",''')
rep("""        cols = list(comb[0].keys())
        empty = {c: sum(1 for r in comb""", """        cols = list(comb[0].keys())
        tail_bs = cols[-2:] == ["BROKER_EN", "SOURCE"]                       # v0131 ⑬a 實體欄在最後兩欄 → 欄序照 ConsensusJoin 清單比(兩欄另記)
        cols = cols[:-2] if tail_bs else cols
        empty = {c: sum(1 for r in comb""")
rep("""        f("GREEN" if cols == want and gap_owner is None else "YELLOW", "Combined 冊", "%d 列 · 欄序%s · 空格 %s%s" % (len(comb), "正確" if cols == want else "不同(%s)" % [c for c in want if c not in cols][:4], json.dumps(empty, ensure_ascii=False),""",
    """        f("GREEN" if cols == want and gap_owner is None else "YELLOW", "Combined 冊", "%d 列 · 欄序%s%s · 空格 %s%s" % (len(comb), "正確" if cols == want else "不同(%s)" % ([c for c in want if c not in cols][:4] or [c for c in cols if c not in want][:4]),
                                                                                                         " · 最後兩欄 BROKER_EN / SOURCE(⑬a)" if tail_bs else "", json.dumps(empty, ensure_ascii=False),""")
# ── selftest: 舊項目在 NO_BOOKSOURCE 下跑 · 新 101 ──
rep('''    saved_env = {k: os.environ.get(k) for k in ("USERPROFILE", "HOME", "VRN2_DOWNLOADS", "VRN2_ROOT", "VIA_ROOT", "VIA_FETCH_PY", "VRN2_PACKAGE")}''',
    '''    saved_env = {k: os.environ.get(k) for k in ("USERPROFILE", "HOME", "VRN2_DOWNLOADS", "VRN2_ROOT", "VIA_ROOT", "VIA_FETCH_PY", "VRN2_PACKAGE", "VIA_VRN2_NO_BOOKSOURCE")}
    os.environ["VIA_VRN2_NO_BOOKSOURCE"] = "1"                                  # v0131 舊項目照舊(⑬a / 補欄只在 101 驗)''')
i98 = s.index('        with tempfile.TemporaryDirectory() as td98:')
j98 = s.index('        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",')
s = s[:i98] + '''        with tempfile.TemporaryDirectory() as td98:
            v98 = Path(td98) / "VIA_Reports" / "vrn2"
            v98.mkdir(parents=True)
            (v98 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb107-css"></style><style id="wb108-tpl"></style></html>', encoding="utf-8")
            p98a = plan_fixes(Path(td98), {"market": {}, "consensus": {}}, "", A93(), "")
            (v98 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb108-tpl"></style><style id="wb109-tpl"></style></html>', encoding="utf-8")
            p98b = plan_fixes(Path(td98), {"market": {}, "consensus": {}}, "", A93(), "")
        chk("98 v0131:頁是 v0108(沒有 wb109-tpl)→ 只排 workbench(換 v0109 · 細節字型 · 系統摘要矩陣)· 已是 v0109 → 不排 · 補放鏈 v0109 + v0108 + v0107 · 標記含 v0109 · 套件 v0175",
            [k for k, _ in p98a] == ["workbench"] and "v0109" in p98a[0][1] and p98b == [] and WORKBENCH_CHAIN == ("VRN2_Workbench_v0109.py", "VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")
            and any(m == 'id="wb109-tpl"' for m, _ in WORKBENCH_MARKS) and PACKAGE == "VRN2_Closeout_v0175" and RUNTIME_ZIP == "VRN2_Runtime_v0164.zip")
        with tempfile.TemporaryDirectory() as td101:
            os.environ.pop("VIA_VRN2_NO_BOOKSOURCE", None)
            try:
                v101 = Path(td101) / "VIA_Reports" / "vrn2"
                (v101 / "output").mkdir(parents=True)
                fin101 = v101 / "output" / "VRN2_FinancialData_latest.json"
                fin101.write_text(json.dumps([{"FILENAME": "a.pdf", "PERIOD": "2026E"}]), encoding="utf-8")
                (v101 / "VRN2_Output_Config.json").write_text(json.dumps({"output_dir": str(Path(td101) / "out")}), encoding="utf-8")
                (v101 / STORE_PURGE).write_text(json.dumps({"apply": True, "lamp": "GREEN"}), encoding="utf-8")
                (v101 / "VRN2_OutputStore_latest.json").write_text(json.dumps({"lamp": "GREEN", "totals": {}}), encoding="utf-8")
                (v101 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb108-tpl"></style></html>', encoding="utf-8")
                p101a = plan_fixes(Path(td101), {"market": {}, "consensus": {}}, "", A93(), "")
                (v101 / "VRN2_OutputStore_latest.json").write_text(json.dumps({"lamp": "GREEN", "totals": {}, "derived_fill": {"lamp": "GREEN"}}), encoding="utf-8")
                p101b = plan_fixes(Path(td101), {"market": {}, "consensus": {}}, "", A93(), "")
                (v101 / BOOKSOURCE_RECEIPT).write_text(json.dumps({"lamp": "GREEN"}), encoding="utf-8")
                t101 = time.time()
                os.utime(fin101, (t101 - 100, t101 - 100))
                (v101 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb109-tpl"></style></html>', encoding="utf-8")
                p101c = plan_fixes(Path(td101), {"market": {}, "consensus": {}}, "", A93(), "")
                os.utime(fin101, (t101 + 100, t101 + 100))
                p101d = plan_fixes(Path(td101), {"market": {}, "consensus": {}}, "", A93(), "")
            finally:
                os.environ["VIA_VRN2_NO_BOOKSOURCE"] = "1"
            p101e = plan_fixes(Path(td101), {"market": {}, "consensus": {}}, "", A93(), "")
        chk("101 v0131:輸出冊沒有 SOURCE / BROKER_EN → 排 ⑬a 在 ⑬ 之前 · 增量庫收據沒有 derived_fill → 也排 ⑬ · 頁不是 v0109 → 重渲染 · 都齊了 → 計畫空 · 冊比收據新 → 再寫 · VIA_VRN2_NO_BOOKSOURCE=1 → 不排 · 套件 v0175",
            [k for k, _ in p101a] == ["source", "store", "workbench"] and "還沒有 SOURCE" in p101a[0][1] and [k for k, _ in p101b] == ["source", "store", "workbench"]
            and p101c == [] and [k for k, _ in p101d] == ["source", "store", "workbench"] and "FinancialData" in p101d[0][1] and p101e == [])
        with tempfile.TemporaryDirectory() as td101c:
            r101c = Path(td101c) / "VIA"
            (r101c / "VIA_Reports" / "vrn2" / "output").mkdir(parents=True)
            w101c = COMBINED_HEAD + ["%d_DILUTED_EPS_FACTSET" % y for y in (2026, 2027, 2028)] + ["%d_PER_FACTSET" % y for y in (2026, 2027, 2028)] + COMBINED_TAIL
            (r101c / "VIA_Reports" / "vrn2" / "output" / "VRN2_Combined_latest.json").write_text(json.dumps([dict({c: "1" for c in w101c}, BROKER_EN="KGI", SOURCE="報告 + TWSE/TPEX/Yahoo + 共識")]), encoding="utf-8")
            (r101c / "VIA_Reports" / "vrn2" / RECEIPT).write_text(json.dumps({"version": "ActivateVRN-2 v0175", "rc": 0, "elapsed_s": 1, "passes": [1], "steps": []}), encoding="utf-8")
            (r101c / "VIA_Reports" / "vrn2" / "consensus").mkdir()
            (r101c / "VIA_Reports" / "vrn2" / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"year_n": 2026}), encoding="utf-8")
            import io as _io101
            sys.stdout = _io101.StringIO()
            try:
                rep101c = diagnose(r101c)
            finally:
                sys.stdout = sys_stdout
            f101c = {x["area"]: x for x in rep101c["findings"]}.get("Combined 冊", {})
        chk("101c v0131:Combined 最後兩欄 BROKER_EN / SOURCE(⑬a 實體欄)→ 欄序仍算正確(另記一句)· 不再被判「欄序不同」算 VRN-2",
            "欄序正確" in f101c.get("finding", "") and "最後兩欄 BROKER_EN / SOURCE" in f101c.get("finding", "") and "欄序不同" not in f101c.get("finding", ""))
        chk("101b v0131:補放鏈與清單 · BookSource / OutputStore v0103 / Workbench v0109 在自測清單 · 貼回包收 BookSource 收據",
            BOOKSOURCE_CHAIN == ("VRN2_BookSource_v0100.py",) and STORE_CHAIN[0] == "VRN2_OutputStore_v0103.py" and ("VRN2_BookSource_v0100.py", 300) in SELFTESTS
            and ("VRN2_OutputStore_v0103.py", 300) in SELFTESTS and ("VRN2_Workbench_v0109.py", 600) in SELFTESTS and "VRN2_BookSource_latest.json" in PASTE_FILES
            and WB_MARK == 'id="wb109-tpl"' and PACKAGE == "VRN2_Closeout_v0175" and RUNTIME_ZIP == "VRN2_Runtime_v0164.zip")
''' + s[j98:]
(W / "new").mkdir(exist_ok=True)
(W / "new" / "VRN2_RoundAll_v0131.py").write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,30}VRN2_Runtime_v0163.{0,30}|.{0,30}Closeout_v0174.{0,30}", s[s.index('VERSION = "v0131"'):])]
print("RoundAll v0131 lines", s.count("\n"), "· stale refs:", len(left), left[:3])
