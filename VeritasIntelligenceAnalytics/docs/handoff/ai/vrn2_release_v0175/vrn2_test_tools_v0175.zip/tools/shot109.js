const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1600, height: 1000 } });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', e => errs.push(String(e)));
  p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  const out = process.argv[3];
  await p.goto('file://' + process.argv[2]);
  await p.waitForTimeout(300);
  const shot = async (sel, name) => { const e = await p.$(sel); if (e) { await e.scrollIntoViewIfNeeded(); await e.screenshot({ path: out + '/' + name }); } else console.log('missing', sel); };
  await p.screenshot({ path: out + '/b_top.png' });
  await shot('aside', 'b_aside.png');
  await shot('#wb109v', 'b_verify.png');
  const info = await p.evaluate(() => {
    const g = s => { const e = document.querySelector(s); if (!e) return null; const c = getComputedStyle(e); return c.fontFamily.slice(0, 50) + ' | ' + c.fontSize + ' | ' + c.fontWeight; };
    const over = [];
    document.querySelectorAll('.kv .cell, .sm-c, .w9-mx td, .sm-card, .lamps div, aside .action, .w9-kv div').forEach(e => { if (e.offsetParent && e.scrollWidth > e.clientWidth + 2) over.push((e.className || e.tagName) + ':' + e.textContent.trim().slice(0, 40)); });
    return { body: g('body'), td: g('.w9-mx td'), ep: g('.sm-ep'), lb: g('.sm-lb'), action: g('aside .action'), h2: g('main h2'), th: g('.w9-mx th .w9en'), zh: g('.w9-mx th .w9zh'),
      tab0: document.querySelector('.tabs button').textContent, title: (document.querySelector('.sm-title') || {}).textContent,
      steps: [...document.querySelectorAll('.w9-step')].map(x => x.textContent.trim()), asideNotes: document.querySelectorAll('aside .w9-notes li').length,
      wb107: !!document.getElementById('wb107'), overflow: over.slice(0, 12), overflowN: over.length,
      halfParenCJK: [...document.querySelectorAll('main h2, main h3, .sm-sect')].map(x => x.textContent).filter(t => /\([^)]*[㐀-鿿]/.test(t)).slice(0, 8) };
  });
  console.log(JSON.stringify(info, null, 1));
  await p.click('.tabs button[data-tab="overview"]'); await p.waitForTimeout(250);
  await shot('#wb109i', 'b_input.png');
  await p.screenshot({ path: out + '/b_overview.png' });
  await p.click('.tabs button[data-tab="data"]'); await p.waitForTimeout(300);
  for (const ds of ['FinancialData', 'BasicInfo', 'Combined', 'MarketConsensus', 'FinancialAligned']) {
    const btn = await p.$('.subtabs button[data-ds="' + ds + '"]');
    if (!btn) { console.log(ds, 'no subtab'); continue; }
    await btn.click(); await p.waitForTimeout(250);
    const r = await p.evaluate(() => {
      const th = [...document.querySelectorAll('#dsHead th')].map(x => x.textContent.trim().replace(/\s+/g, ' '));
      const codes = [...document.querySelectorAll('#dsHead th')].map(x => x.getAttribute('title'));
      const row = [...document.querySelectorAll('#dsBody tr:first-child td')].map(x => x.textContent.trim());
      const notes = [...document.querySelectorAll('#w9dsNotes li')].map(x => x.textContent);
      return { n: th.length, src: codes.filter(c => c === 'SOURCE').length, brEn: codes.filter(c => c === 'BROKER_EN').length, codes: codes.slice(0, 8).concat(['…', codes[codes.length - 1]]),
        th: th.slice(0, 4).concat(['…', th[th.length - 1]]), row: row.slice(0, 6).concat(['…', row[row.length - 1]]), notes };
    });
    console.log(ds, JSON.stringify(r));
    if (ds === 'FinancialData') await p.screenshot({ path: out + '/b_data.png', clip: { x: 0, y: 0, width: 1600, height: 820 } });
    if (ds === 'Combined') await p.screenshot({ path: out + '/b_combined.png', clip: { x: 0, y: 0, width: 1600, height: 820 } });
  }
  const sub = await p.$('.subtabs button[data-ds="FinancialData"]'); if (sub) { await sub.click(); await p.waitForTimeout(200); }
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-act="csvAll"]')]);
  const f = await dl.path(); const head = fs.readFileSync(f, 'utf8').split('\n')[0];
  console.log('csvAll', dl.suggestedFilename(), 'SOURCE x', head.split(',').filter(x => x.replace(/["\r﻿]/g, '') === 'SOURCE').length, '| tail', head.slice(-40));
  await p.click('.tabs button[data-tab="handover"]'); await p.waitForTimeout(250);
  await shot('#wb109a', 'b_accept.png');
  await p.click('.tabs button[data-tab="summary"]'); await p.waitForTimeout(250);
  await p.setViewportSize({ width: 1100, height: 900 }); await p.waitForTimeout(200);
  await p.screenshot({ path: out + '/b_narrow.png' });
  console.log('errors', JSON.stringify(errs));
  await b.close();
})();
