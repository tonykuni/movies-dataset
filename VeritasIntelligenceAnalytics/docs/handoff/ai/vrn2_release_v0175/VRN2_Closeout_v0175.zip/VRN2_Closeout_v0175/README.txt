VRN2_Closeout_v0175 — VRN-2 closeout package (2026-11-03 · ⑬a book Source / Broker columns · OutputStore v0103 · Workbench v0109)

Entry: python ActivateVRN-2_v0175.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0131.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0123.md (same release folder).
Runtime: VRN2_Runtime_v0164.zip = v0163 (204 members byte-identical) + VRN2_BookSource_v0100 + VRN2_OutputStore_v0103 + VRN2_Workbench_v0109.

v0175 (operator 2026-11-03: broker abbreviations · physical Source column in the books and the store · Detail-column font · 系統摘要 matrices · step panel):
 - ⑬a VRN2_BookSource_v0100 (after ⑬b, before ⑬): BROKER_EN + SOURCE as the last two columns of the seven report books (JSON / CSV / Parquet;
   other values byte-identical; BROKER kept as written in the report; MarketConsensus keeps its own SOURCE). VIA_VRN2_NO_BOOKSOURCE=1 opts out.
 - VRN2_OutputStore_v0103: the row hash ignores SOURCE / BROKER_EN (no re-append); rows already stored get the two columns filled in place
   (DuckDB file backed up first · affected run partitions rewritten · restore-fill --folder <_source_fill_ folder>).
 - VRN2_Workbench_v0109: Detail-column font (Consolas + Microsoft JhengHei 10.45 px) everywhere; 00 tab = 系統摘要 with verification and consensus
   matrices; 04 open acceptance items as a matrix; English + Chinese two-line headers; notes under each card; full-width punctuation beside Chinese;
   numbered left-panel steps; input classification matrix (stock report / non-stock report / news / page image / unclassified x file type).
v0174: Workbench v0108 (ENG049 template lock · Freshness · Ticker / YFinance · broker abbreviations · YYYY dates · Source). v0172: HistoryAlign v0103 ·
ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107. v0163: no MOPS.
Verification: see VRN2_Verification_v0175.md. Hashes: PACKAGE_SHA256.json.
