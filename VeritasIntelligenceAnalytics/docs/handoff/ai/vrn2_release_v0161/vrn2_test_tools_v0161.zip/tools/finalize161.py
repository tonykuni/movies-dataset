"""v0161 收尾:驗證紀錄 · 交接 v0162(從 v0161 抄 · 只增)· 放進倉 vrn2_release_v0161 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v161"); rel = W / "release161"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    return x.replace(str(W / "t161a"), "<sbx>").replace(str(W), "<w>").replace(SCR, "<scratch>").replace(SCR0, "<scratch0>")


R = json.loads((rel / "VRN2_Release_v0161.json").read_text(encoding="utf-8"))
st = [l for l in lines(W / "rall117_selftest.log") if re.search(r"^\[PASS\] 6[5-9] |^\[FAIL\]|--selftest · ", l)]
stv = [l for l in lines(W / "rall117_selftest_venv.log") if "--selftest · " in l]
ps = json.loads((W / "pscheck161.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny161.rc") if l.strip()]
pat = r"boot:|boot SHA|擷取鎖 ·|⑤ 修 · ⑥e|last_error.txt 移到|⑤ 自動修計畫|===== 收尾|\[(VRN-2|人工|VCGC)\] \d"
e2e = {n: [short(l)[:200] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)] for n in ("stale", "live", "full", "tamper")}
vdf = {n: (W / ("vdf_after_%s.txt" % n)).read_text().split() for n in ("stale", "live", "full")}
rep = lines(W / "replay_summary.txt")   # 只留負責方統計 · 不帶桌機資料
R["results"] = {"selftest": st, "selftest_venv": stv, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "vdf_folder_after": vdf, "replay_desktop_report": rep,
                "not_run": "the real 6e re-fetch after the lock is moved: the container has no Python inside the VDF engine's version bounds (pyarrow / yfinance / tzdata missing) and VRN-2 installs nothing (VCGC's job) → plan order (move lock, then re-fetch) is selftest 67; the re-fetch branch itself is the existing step 5 'market' fix (MarketFetchRun)"}
(rel / "VRN2_Release_v0161.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0161 驗證紀錄(2026-10-31 · RoundAll v0117 · Handle-All v0109 · 套件 v0158 不動)

## 1. 起因(桌機 14:33 貼回 · `VRN2_PasteBack_20261031_143304.zip`)

RoundAll v0116 repair → 收尾 **OPEN · VRN-2 2 項**,兩項都是 ⑥e。`market\\vdf\\last_error.txt` 的錯誤是
`RuntimeError: Another writer may be active. Inspect …\\VIA_Reports\\vrn2\\market\\vdf\\RUNNING.lock; remove only after confirming the old process has stopped.`
上午整輪(啟動器 v0158 · 3802 秒)⑥e 跑 5 次全被這個鎖擋住:09-18 ~ 10-04 日線(2 檔 · 就是 3706 / 6669 回補)rc1 致命錯 · 財報 2020~2023 / 2022~2025 / 2023~2025 / latest 都 rc1。
不是網路工具 DENY(上一輪那句 `Existing VIA network bridge denied` 不在)→ RoundAll 認不出來 → 照保守規則算 VRN-2;收尾頁那列又先放了 43 檔代號的 CMD,錯誤被截掉。

根因:VDF 引擎 `VDF_TW_AllInOne_v039` 的 `def_run_lock` 在輸出夾用 O_EXCL 建 `RUNNING.lock`,只在 `finally` 刪 → 引擎被強制結束(逾時殺掉 / 關視窗)就留下,
之後每次 ⑥e 都停。輸出夾是 VRN-2 自己的(`VIA_Reports\\vrn2\\market\\vdf`);引擎與共用 MarketFetch 是借用的(只讀不改)。

## 2. 修法(RoundAll v0117 · SHA-256 `%s`)

| 項目 | 內容 |
|---|---|
| 擷取鎖過期判斷 | PID 已不在 / 號碼現在不是 python(被重用)/ 那個行程比鎖晚起(重用)→ 過期;讀不到 = 當它還在跑 |
| 處理 | 過期 → 移到 `RUNNING.lock.stale_<時間>`(不刪 · 內容照留)· 還在跑 → 不動(收尾頁「人工」)|
| ④ / ⑤ | ④ 跑啟動器前先看一次 · ⑤ 鎖過期就移開 · 上一輪 ⑥e 被鎖擋住就重抓(repair 自己找共用 MarketFetch 最高版號)|
| last_error.txt | ④ 前 / ⑤ 重抓前把上一輪的移到 `last_error.before_<時間>.txt`(MarketFetch 只在失敗時寫 · 不移的話抓成功了舊錯誤還在)|
| 收尾頁 | 「⑥e 擷取錯誤」錯誤在前 · CMD 在後(代號縮成「N 檔」)· 新列「⑥e 擷取鎖擋住」· 三列合一列 · 貼回包帶 `RUNNING.lock` |

Handle-All v0109 = v0108 指向 RoundAll v0117(一行 `%s` · 開機檔 `%s` · 最短一行 %d 字元 · cmd 一行 %d 字元)。套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip` 不動。

## 3. 測試

```text
%s
venv(有 PyMuPDF):%s
%s
e2e 結束碼:%s
```

VCGC 全景骨架卡(`CGC_MDL158 … read`):RoundAll v0117 報 10 項 SWALLOW,跟 v0115 / v0116 一樣多。

## 4. 用桌機貼回包重播(只讀 · 容器 · report 模式 · 放一個 PID 已不在的鎖)

```text
%s
```

(只留負責方統計 · 桌機的明細不進倉。貼回包缺 JSON 冊,所以兩版都多一項「Combined 冊」· 桌機沒有這項。)v0116:⑥e 兩項分開算 VRN-2,「擷取錯誤」那列開頭是 CMD(錯誤被截掉);v0117:⑥e 三列合成一項,錯誤排在前面。

## 5. e2e(桌機 v0153 狀態沙盒 · 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設)

```text
%s
```

- stale(repair):⑤ 把 PID 已不在的鎖移到 `RUNNING.lock.stale_*`;沙盒沒有合 VDF 界線的擷取 Python → ⑥e 這輪沒重抓 → 收尾留 1 項 VRN-2「擷取鎖已不在 · 再跑 repair」(桌機有 `C:\\Python313` 會重抓)。
- live(活的 python · 比鎖早起):鎖不動 · 收尾 BLOCKED · 鎖那項算「人工」。
- full:④ 先移開過期鎖 · 舊 last_error.txt 改名留著 · 收尾 BLOCKED · VRN-2 0(沙盒的 VCGC 項是沙盒環境)。 tamper:開機檔被改 → 不執行。
- 輸出夾事後:%s

**沒跑到的**:鎖移開之後真的重抓 ⑥e(容器沒有合 VDF 界線的 Python · VRN-2 不裝套件)→ 計畫順序由自測 67 把關,重抓沿用既有 ⑤「market」修法(MarketFetchRun)。

## 6. 桌機預期

repair → ⑤ 計畫第一項「⑥e 擷取鎖過期(PID … 已不在)→ 移開」→「⑥e 上一輪被擷取鎖擋住 → 重抓」→ 日線(含 3706 / 6669 回補)重抓 · 財報打 MOPS 預期照舊被 VIA 網路工具 DENY
→ 收尾回到 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 1 ~ 2**。鎖的 PID 還在跑 → 不動 · 收尾頁「人工」。

## 7. 給 VDF(只讀攤開 · 不改)

`VDF_TW_AllInOne_v039.def_run_lock` 只看鎖檔在不在,不檢查鎖裡的 PID 是否還活著 → 引擎被強制結束後,下一次一定被擋(訊息叫人手動刪)。要不要改成「啟動時判 PID 過期」是 VDF 的決定。
""" % (R["roundall"]["sha256"][:12], H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], H["cmd_line_chars"],
       "\n".join(st), " ".join(stv), pparse, " · ".join(rc), "\n".join(rep), "\n".join("[%s] " % n + l for n in e2e for l in e2e[n]),
       " · ".join("%s → %s" % (n, ", ".join(v)) for n, v in vdf.items()))
(rel / "VRN2_Verification_v0161.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0161.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0116 + VRN2_HandleAll_v0108 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0117 + VRN2_HandleAll_v0109 · 2026-10-31(桌機 14:33 貼回:⑥e 全被 VDF 引擎留下的過期 RUNNING.lock 擋住 → "
        "RoundAll v0117 過期就移開(不刪)再重抓 · 還在跑不動;收尾頁錯誤訊息排前面;套件 v0158 不動)")
src = "\n".join(L)
once("> **本輪(v0160)**",
     "> **本輪(v0161)**:桌機 14:33 貼回(RoundAll v0116 repair)= OPEN · VRN-2 2 項 = ⑥e。`last_error.txt`:`RuntimeError: Another writer may be active … market\\\\vdf\\\\RUNNING.lock` —— "
     "VDF 引擎的鎖只在正常結束時刪,上一個擷取被強制結束就留下;上午整輪 ⑥e 5 次全被擋(含 3706 / 6669 日線回補)。**RoundAll v0117**:鎖過期(PID 不在 / 被重用)→ 移到 `RUNNING.lock.stale_*` · "
     "還在跑 → 不動(人工)· ④ 前先看 · ⑤ 移鎖後重抓 ⑥e · 上一輪 last_error.txt 移成 `last_error.before_*` · 收尾頁錯誤在前、三列合一列 · 自測 69。**Handle-All v0109**(最短一行 %d 字元 · cmd 一行 %d 字元)。"
     "桌機也確認了 v0160 的兩條進度列與收尾頁(貼回的是新版面)。\n"
     "> **本輪(v0160)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
once("| **VRN2_HandleAll_v0108.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0108** | `vrn2_release_v0160` |",
     "| **VRN2_HandleAll_v0109.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0109** | `vrn2_release_v0161` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0117)|\n"
     "| **VRN2_RoundAll_v0117.py**(發行夾 · 一支入口 · 不在套件內)| **v0117** | `vrn2_release_v0161` | `%s` | **新**(⑥e 過期擷取鎖移開再重抓 · 錯誤在前 · 自測 69 項)|\n"
     "| **VRN2_HandleAll_v0108.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0108** | `vrn2_release_v0160` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12]))
r160 = json.loads((REPO / "vrn2_release_v0160/VRN2_Release_v0160.json").read_text(encoding="utf-8"))
once("| **VRN2_RoundAll_v0116.py**(發行夾 · 一支入口 · 不在套件內)| **v0116** | `vrn2_release_v0160` | `%s` | **新**(" % r160["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0116.py**(發行夾 · 一支入口 · 不在套件內)| **v0116** | `vrn2_release_v0160` | `%s` | 被 v0117 取代(⑥e 過期擷取鎖沒處理 · 錯誤被 CMD 截掉)· (" % r160["roundall"]["sha256"][:12])
once("| 0 | **(v0160)**",
     "| 0 | **(v0161)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"` 再貼 `vrn2_release_v0161/VRN2_HandleAll_v0109.md` 的 cmd 一行(PowerShell 視窗用最短一行)→ repair:⑤ 移開過期 RUNNING.lock → 重抓 ⑥e → "
     "預期 BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 1 ~ 2 | 貼回 |\n"
     "| 0 | **(v0160)**")
once("**v0160(2026-10-31)**:", "**v0161(2026-10-31)**:⑥e 被 VDF 引擎留下的過期 RUNNING.lock 擋住 → RoundAll v0117 過期就移開(不刪)再重抓 · 還在跑不動 · 收尾頁錯誤在前;Handle-All v0109;套件 v0158 不動。\n\n**v0160(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0161)** **先看 last_error.txt 的錯誤本身,不要只看燈號**:同樣是 ⑥e 黃,05:30 是 MOPS 被網路工具 DENY(VCGC),14:33 是過期 RUNNING.lock(VRN-2 自己的輸出夾 · VRN-2 能修)。"
     "收尾頁的明細要讓錯誤排在指令列前面,不然被字數截掉就看不到原因。\n"
     "- **(v0161)** **別系統工具留在 VRN-2 夾裡的鎖**:只在 PID 已不在 / 被重用時移開,而且是改名留著不刪;PID 還在跑就不動、交人工。別系統的程式(VDF 引擎 · 共用 MarketFetch)照舊只讀不改,問題攤開給它們。\n"
     "- **(v0161)** **只在失敗時寫的檔(last_error.txt)**:重跑前先把舊的移開,不然成功了舊錯誤還在,會被當成這輪的。\n\n")
(REPO / "VRN2_Handover_v0162.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0161"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0117.py", "VRN2_RoundAll_v0117.md", "VRN2_HandleAll_v0109.md", "VRN2_HandleAll_v0109_boot.txt", "VRN2_Release_v0161.json", "VRN2_Verification_v0161.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t161a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0161.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "rall117_selftest.log", W / "rall117_selftest_venv.log", W / "pscheck161.log", W / "tiny161.rc", W / "replay_summary.txt"] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("vdf_after_*.txt")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0161.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall117.py", "build161.py", "finalize161.py", "e2e161.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0162", src.count("\n"))
