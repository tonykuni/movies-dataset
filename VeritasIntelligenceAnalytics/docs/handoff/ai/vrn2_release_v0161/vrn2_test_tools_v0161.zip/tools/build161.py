"""v0161(冪等):RoundAll v0117(套件 v0158 不動)→ Handle-All v0109(= v0108 指向 RoundAll v0117)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單。
vrn2_release_v0160 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v161"); rel = W / "release161"; rel.mkdir(exist_ok=True)
P160 = Path("/home/user/vrn2_work/v160/release160")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r160 = json.loads((REPO / "vrn2_release_v0160/VRN2_Release_v0160.json").read_text(encoding="utf-8"))
want = r160["package"]["sha256"]
assert hashlib.sha256((REPO / "vrn2_release_v0158/VRN2_Closeout_v0158.zip").read_bytes()).hexdigest() == want
ra = (W / "new/VRN2_RoundAll_v0117.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'VERSION = "v0117"' in ra
(rel / "VRN2_RoundAll_v0117.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ha = (P160 / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0160'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0161'")
rep("$F = 'VRN2_RoundAll_v0116.py'", "$F = 'VRN2_RoundAll_v0117.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0108", "Handle-All v0109", 4)
rep("· 重組 Combined · 增量庫 · Workbench;閘關:現有共識不動)→ 除錯報告 → 收尾頁 → 貼回包(幾分鐘)'",
    "· ⑥e 擷取鎖過期 → 移開後重抓 ⑥e · 重組 Combined · 增量庫 · Workbench;閘關:現有共識不動)→ 除錯報告 → 收尾頁 → 貼回包(幾分鐘 · 要重抓 ⑥e 時更久)'")
assert "exit" not in ha.replace("Exception", "")
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (P160 / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0160", "vrn2_release_v0161"), ("VRN2_HandleAll_v0108.md", "VRN2_HandleAll_v0109.md"), ("Handle-All v0108 SHA-256 OK", "Handle-All v0109 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0109_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0161/VRN2_HandleAll_v0109_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0109(2026-10-31 · RoundAll v0117 · 套件 v0158 不動)

v0109 = v0108(VIA 加速器進度模板 · 跑完自動開收尾頁)+ RoundAll **v0117**:桌機 14:33 貼回(收尾 OPEN · VRN-2 2 項都是 ⑥e)的原因是
VDF 引擎在 VRN-2 自己的輸出夾看到 `market\\vdf\\RUNNING.lock` 就停(`Another writer may be active`)—— 上一個擷取被強制結束、鎖沒清,
上午整輪 ⑥e 跑 5 次全被它擋住(09-18 ~ 10-04 那 2 檔日線回補 · 4 次財報)。

| 項目 | 現在 |
|---|---|
| ⑥e 擷取鎖 | 鎖裡的 PID 已不在 / 號碼被別的程式重用 → **移到 `RUNNING.lock.stale_<時間>`(不刪)**;PID 還在跑 → 不動(收尾頁「人工」)|
| ④ 跑啟動器前 | 先看一次擷取鎖(整輪不再被舊鎖擋)|
| ⑤ 自動修(repair)| 鎖過期就移開 · 上一輪 ⑥e 被鎖擋住就重抓 ⑥e(價格 + 財報補缺 · 經 MarketFetchRun · `C:\\Python313`)→ ⑬b → Combined → 增量庫 → Workbench |
| 收尾頁 | 「⑥e 擷取錯誤」錯誤訊息排前面(以前 43 檔代號把字數用完 · 錯誤被截掉)· 同一件事三列合一列 · 貼回包多帶 `RUNNING.lock` |
| 一支 Python | `VRN2_RoundAll_v0117.py`(SHA-256 `%s` · 自測 69 項)· 套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s` · 不動) |

## 先看:你開的是哪一種視窗?

- 提示字元前面有 **PS**(`PS C:\\Users\\tonyk>`)→ **PowerShell** → 用「PowerShell 7 視窗」那段。
- 前面沒有 PS(例如 `[14:33:04.12] C:\\Users\\tonyk` 下一行 `>`)→ **cmd** → 用「cmd 視窗」那段。cmd 不認 `$env:…` / `$r=…`。

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定 · 不想經網路工具抓就不貼)· 第 2 行 = 下面 PowerShell 那一行的編碼版(解碼後一字不差 · 一樣核對 SHA-256 才執行)。
要整輪(約 40 ~ 60 分鐘)才在第 2 行之前多貼 `set "VRN2_MODE=full"`。`'pwsh' is not recognized` → 開始功能表開「PowerShell 7」改用下面那段。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)· 要整輪再貼 `$env:VRN2_MODE = 'full'`。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0109 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0117 `%s`)。

## 這次桌機貼下去會怎樣

- auto = repair:⑤ 自動修計畫第一項 `⑥e 擷取鎖過期(PID … 已不在 …)→ 移開(不刪)`,接著 `⑥e 上一輪被擷取鎖擋住 → 鎖移開後重抓` →
  日線(含 3706 / 6669 那段 09-18 ~ 10-04 回補)重抓;財報打 MOPS 預期照舊被 VIA 網路工具 DENY →
  收尾預期回到 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 1 ~ 2**(3706 / 6669 補到日資料就少一項)。
- 鎖的 PID 還在跑(真的有另一個擷取在跑)→ 不動 · 收尾頁「人工」:等它跑完或確認它停了再貼。
- BLOCKED / REVIEW / DATA_GAP 都不是成功;VCGC 的 closeout_lamp 才是 VCGC 驗收。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (ra_sha[:12], want[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0109.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0117.py(套件 v0158 不動 · ⑥e 過期擷取鎖)

`VRN2_RoundAll_v0117.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0116 +

| 改了什麼 | 說明 |
|---|---|
| ⑥e 擷取鎖 | VDF 引擎在 `VIA_Reports\\vrn2\\market\\vdf\\RUNNING.lock` 留下的鎖:PID 已不在 / 號碼被重用 / 比鎖晚起 → 移到 `RUNNING.lock.stale_<時間>`(不刪)· PID 還在跑 → 不動 |
| ④ 跑啟動器前 | 先看一次擷取鎖 |
| ⑤ 自動修 | 鎖過期 → 移開 · 上一輪 ⑥e 被鎖擋住 → 重抓 ⑥e(repair 沒跑 ② 也自己找共用夾的 MarketFetch 最高版號)|
| last_error.txt | ④ 跑啟動器前 / ⑤ 重抓前把上一輪的移到 `last_error.before_<時間>.txt`(MarketFetch 只在失敗時寫 · 這輪抓成功就不會留著舊錯誤)|
| 除錯報告 / 收尾頁 | 「⑥e 擷取錯誤」錯誤在前 · CMD 在後(代號縮成「N 檔」)· 新列「⑥e 擷取鎖擋住」· 鎖還在跑 = 人工 · 過期 / 已移開 = VRN-2 · 三列合一列 · 貼回包帶 `RUNNING.lock` |

自測 69 項(v0116 的 64 項 + 65 ~ 69)。套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s` · 本檔內已釘死)。**最省事:`VRN2_HandleAll_v0109.md`(cmd / PowerShell 各一段)**。

```bat
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0117.py" --only package,fix,report,closeout,pasteback
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0117.py"
```
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0117.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0117 + VRN2_HandleAll_v0109 (package v0158 unchanged)", "date": "2026-10-31",
        "trigger": "桌機 2026-10-31 14:33 貼回(VRN2_PasteBack_20261031_143304 · RoundAll v0116 repair):收尾 OPEN · VRN-2 2 項 = ⑥e;last_error.txt = RuntimeError: Another writer may be active (market/vdf/RUNNING.lock) · 上午整輪(啟動器 v0158 · 3802 秒)⑥e 5 次全失敗",
        "root_cause": "VDF_TW_AllInOne_v039 def_run_lock: O_CREAT|O_EXCL lock in the output folder, released only in finally → a force-killed engine (timeout kill / closed window) leaves RUNNING.lock; every later 6e run stops on it. The output folder is VRN-2's own (VIA_Reports/vrn2/market/vdf); the engine and the shared MarketFetch are read-only for VRN-2.",
        "package": {"name": "VRN2_Closeout_v0158.zip", "folder": "vrn2_release_v0158", "sha256": want, "changed": False},
        "fixes": {"RoundAll_v0117": "vdf_lock_state (PID gone / PID reused by a non-python program / process started after the lock → stale; unreadable → treated as running) · stale lock moved to RUNNING.lock.stale_<stamp> (kept) before step 4 and as a step 5 fix · step 5 re-fetches 6e through MarketFetchRun when the last 6e hit the lock (repair finds the shared MarketFetch itself) · '6e 擷取錯誤' row shows the error before the shortened CMD · new row '6e 擷取鎖擋住' · close-out: lock still running = 人工, stale / gone = VRN-2, the 3 rows merged · paste-back carries market/vdf/RUNNING.lock · last_error.txt of the previous run moved aside before step 4 and before the step 5 re-fetch (MarketFetch writes it only on failure) · selftest 69",
                  "HandleAll_v0109": "v0108 pointed at RoundAll v0117 (vrn2_release_v0161) · repair description mentions the 6e lock"},
        "vdf_note": "VDF 引擎的 RUNNING.lock 只看檔案在不在(不記錄 / 不檢查 PID 是否還活著)· 被強制結束就留鎖。VRN-2 只讀不改 VDF,攤開給 VDF 自己決定(例:啟動時判 PID 過期)。",
        "roundall_previous": [{"name": "VRN2_RoundAll_v0116.py", "sha256": r160["roundall"]["sha256"], "status": "superseded 2026-10-31 (6e stale RUNNING.lock not handled · error tail cut by the CMD line); file kept in vrn2_release_v0160"}],
        "roundall": {"name": "VRN2_RoundAll_v0117.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0117.md"},
        "handleall": {"name": "VRN2_HandleAll_v0109.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0109_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "not_fixed_here": r160["not_fixed_here"], "results": {"status": "see VRN2_Verification_v0161.md"}}
(rel / "VRN2_Release_v0161.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
