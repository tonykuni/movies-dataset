"""VRN2_RoundAll_v0117.py = v0116(倉裡 vrn2_release_v0160)+ ⑥e 擷取鎖(VDF 引擎留下的 market/vdf/RUNNING.lock):過期就移開(不刪)再重抓 · 還在跑就不動 ·
「⑥e 擷取錯誤」那列錯誤訊息排在 CMD 前面。套件 v0158 不動。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v161")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
s = (REPO / "vrn2_release_v0160/VRN2_RoundAll_v0116.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


# ---- 說明 ----
rep('"""VRN2_RoundAll v0116 — ', '"""VRN2_RoundAll v0117 — ')
rep("v0116(操作員 2026-10-31:「所有 PS / PY 檔案都要導入加速器", '''v0117(桌機 2026-10-31 14:33 貼回 · RoundAll v0116 repair · 收尾 OPEN · VRN-2 2 項都是 ⑥e):
  · 上午整輪(啟動器 v0158 · 3802 秒)⑥e 跑 5 次全失敗,原因不是網路工具 DENY,是 VDF 引擎在 VRN-2 自己的輸出夾看到
    market\\\\vdf\\\\RUNNING.lock 就停(「Another writer may be active」)。引擎正常結束會刪這個鎖,被強制結束(逾時殺掉 / 關視窗)就留下來,
    之後每一次 ⑥e 都被它擋住(09-18 ~ 10-04 那 2 檔日線回補 · 4 次財報)。
  · ⑥e 擷取鎖:過期 = 鎖裡的 PID 已不在 / 那個號碼現在不是 python(被別的程式重用)/ 那個行程比鎖晚起 → 移到 RUNNING.lock.stale_<時間>(不刪)·
    PID 還在跑 → 不動(收尾頁「人工」:等它跑完或確認它停了)。④ 跑啟動器前先看一次;⑤ 自動修:鎖過期就移開,上一輪 ⑥e 被鎖擋住就重抓
    (價格 + 財報補缺 · 經 MarketFetchRun · 合 VDF 版本界線的 Python)。repair 沒跑 ② 也自己找共用夾的 MarketFetch 最高版號。
  · 「⑥e 擷取錯誤」那列:錯誤訊息排前面 · CMD 放最後(代號清單縮成「N 檔」)· 以前 43 檔代號把 600 字用完,錯誤被截掉。
  · 收尾頁:被擷取鎖擋住 → 鎖還在跑 = 人工 · 過期 / 已移開 = VRN-2(跑 repair 會自己修)。貼回包多帶 market/vdf/RUNNING.lock(PID · 時間)。
  · VDF 引擎的鎖只用「檔案在不在」判斷(不看 PID)· VRN-2 只讀不改 VDF,攤開給 VDF 自己決定。自測 69 項(v0116 的 64 項 + 65 ~ 69)。

v0116(操作員 2026-10-31:「所有 PS / PY 檔案都要導入加速器''')
rep("用法:python VRN2_RoundAll_v0116.py", "用法:python VRN2_RoundAll_v0117.py")
rep('VERSION = "v0116"', 'VERSION = "v0117"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0116.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0117.py"', 2)
rep('"VRN2_RoundAll_v0116.py" in html_', '"VRN2_RoundAll_v0117.py" in html_')
rep('"market/vdf/last_error.txt", ', '"market/vdf/last_error.txt", "market/vdf/RUNNING.lock", ')

# ---- 擷取鎖 ----
rep('''def probe_modules(py: str, modules) -> dict:''', '''# ===== v0117 ⑥e 擷取鎖(VDF 引擎寫在 VRN-2 自己的輸出夾 · 正常結束會刪 · 被強制結束就留下)=====
VDF_LOCK = Path("market") / "vdf" / "RUNNING.lock"
VDF_BUSY = "Another writer may be active"


def pid_info(pid) -> dict:
    """v0117 這個 PID 現在是哪支程式、什麼時候起的(Windows:QueryFullProcessImageNameW / GetProcessTimes · 其他:/proc)· 讀不到的欄位就沒有。"""
    info = {}
    try:
        if os.name == "nt":
            import ctypes  # noqa: WPS433
            from ctypes import wintypes  # noqa: WPS433
            k32 = ctypes.windll.kernel32
            handle = k32.OpenProcess(0x1000, False, int(pid))
            if not handle:
                return info
            try:
                buf, size = ctypes.create_unicode_buffer(32768), wintypes.DWORD(32768)
                if k32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                    info["image"] = buf.value
                times = [wintypes.FILETIME() for _ in range(4)]
                if k32.GetProcessTimes(handle, *[ctypes.byref(t) for t in times]):
                    info["started"] = ((times[0].dwHighDateTime << 32) | times[0].dwLowDateTime) / 1e7 - 11644473600
            finally:
                k32.CloseHandle(handle)
        else:
            proc = Path("/proc/%d" % int(pid))
            info["image"] = os.readlink(str(proc / "exe"))
            info["started"] = proc.stat().st_ctime
    except Exception:  # noqa: BLE001
        info.setdefault("error", "讀不到")
    return info


def _iso_epoch(text) -> float:
    try:
        return _dt.datetime.fromisoformat(str(text).replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError):
        return 0.0


def vdf_lock_state(v2) -> dict:
    """v0117 market/vdf/RUNNING.lock 過期嗎?過期 = PID 已不在 / 那個號碼現在不是 python(重用)/ 那個行程比鎖晚起(重用)· 判斷不了 = 當它還在跑(不動)。"""
    path = Path(v2) / VDF_LOCK
    if not path.is_file():
        return {"exists": False, "path": str(path)}
    doc = jread(path, {}) or {}
    at = str(doc.get("at") or "")
    st = {"exists": True, "path": str(path), "pid": doc.get("pid"), "at": at or _dt.datetime.fromtimestamp(_mtime(path)).isoformat(timespec="seconds")}
    try:
        pid = int(doc.get("pid"))
    except (TypeError, ValueError):
        return dict(st, stale=True, why="鎖裡沒有可讀的 PID")
    if not pid_alive(pid):
        return dict(st, stale=True, why="PID %d 已不在(上一個擷取被強制結束 · 鎖沒清)" % pid)
    info = pid_info(pid)
    name = Path(str(info.get("image") or "")).name
    if name and "python" not in name.lower():
        return dict(st, stale=True, why="PID %d 現在是 %s(號碼被別的程式重用)" % (pid, name))
    t_lock = _iso_epoch(at) or _mtime(path)
    if info.get("started") and t_lock and info["started"] > t_lock + 60:
        return dict(st, stale=True, why="PID %d 比鎖晚起(號碼被重用)" % pid)
    return dict(st, stale=False, why="PID %d 還在跑(%s)" % (pid, name or "程式名讀不到"))


def clear_vdf_lock(st: dict) -> str:
    """v0117 過期的擷取鎖移到 RUNNING.lock.stale_<時間>(不刪 · 內容照留 · 貼回包看得到)。回新檔名。"""
    path = Path(st["path"])
    dst = path.with_name("RUNNING.lock.stale_%s" % stamp())
    path.replace(dst)
    return dst.name


def retire_last_error(v2) -> str:
    """v0117 上一輪的 last_error.txt 移到 last_error.before_<時間>.txt(不刪)· MarketFetch 只在失敗時寫它 → 不移開的話,這輪抓成功了舊錯誤還留著被當成這輪的。"""
    err = Path(v2) / "market" / "vdf" / "last_error.txt"
    if not err.is_file():
        return ""
    dst = err.with_name("last_error.before_%s.txt" % stamp())
    err.replace(dst)
    return dst.name


def last_error_digest(text: str) -> str:
    """v0117 last_error.txt → 錯誤訊息在前 · CMD 在後(代號清單縮成「N 檔」)· 以前 CMD 先佔掉 600 字 · 錯誤被截掉。"""
    rows = [l.strip() for l in str(text).splitlines() if l.strip()]
    cmd = next((l for l in rows if l.startswith("CMD:")), "")
    rest = [l for l in rows if not l.startswith("CMD:")][-6:]
    cmd = re.sub(r"--tickers (\\S+)", lambda m: "--tickers (%d 檔)" % (m.group(1).count(",") + 1), cmd)
    return " | ".join(rest + ([cmd[:220]] if cmd else []))[:600]


def probe_modules(py: str, modules) -> dict:''')

# ---- ④ 跑啟動器前先看擷取鎖 ----
rep('''    cmd = [vpy, "-X", "utf8", str(Path(pkg) / LAUNCHER)]
    src = args.source or os.environ.get("VRN2_SOURCE") or ""''', '''    lk = vdf_lock_state(Path(root) / "VIA_Reports" / "vrn2")                  # v0117 ⑥e 擷取鎖過期 → 先移開(不然 ⑥e 每次都被擋)
    if lk.get("exists") and lk.get("stale"):
        try:
            say("GREEN", "④ ⑥e 擷取鎖", "過期 · %s · 鎖時間 %s → 移到 %s(不刪)" % (lk["why"], lk["at"], clear_vdf_lock(lk)))
        except OSError as error:
            say("YELLOW", "④ ⑥e 擷取鎖", "過期但移不開(%s)· %s" % (type(error).__name__, lk["path"]), "關掉佔用它的程式(防毒 / 同步)後再跑")
    elif lk.get("exists"):
        say("YELLOW", "④ ⑥e 擷取鎖", "%s · 鎖時間 %s · 不動 · 這輪 ⑥e 會被它擋" % (lk["why"], lk["at"]), "另一個 VDF 擷取還在跑 → 等它跑完(或確認它停了)再跑")
    if not (lk.get("exists") and not lk.get("stale")):
        try:
            old_err = retire_last_error(Path(root) / "VIA_Reports" / "vrn2")
            if old_err:
                info("④ 上一輪的 ⑥e last_error.txt 移到 %s(這輪 ⑥e 失敗才會再寫)" % old_err)
        except OSError as error:
            info("④ last_error.txt 移不開(%s)· 照跑" % type(error).__name__)
    cmd = [vpy, "-X", "utf8", str(Path(pkg) / LAUNCHER)]
    src = args.source or os.environ.get("VRN2_SOURCE") or ""''')

# ---- ⑤ 自動修:移鎖 + 重抓 ----
rep('''    plan = []
    market = receipt.get("market") or {}
    consensus = receipt.get("consensus") or {}''', '''    plan = []
    market = receipt.get("market") or {}
    consensus = receipt.get("consensus") or {}
    lk = vdf_lock_state(v2)                                                    # v0117 ⑥e 擷取鎖
    err_e = v2 / "market" / "vdf" / "last_error.txt"
    lock_hit = VDF_BUSY in str(market.get("detail", "")) or (err_e.is_file() and VDF_BUSY in err_e.read_text(encoding="utf-8", errors="replace"))
    if lk.get("exists") and lk.get("stale"):
        plan.append(("vdf_lock", "⑥e 擷取鎖過期(%s · %s)→ 移開(不刪)" % (lk["why"], lk["at"])))
    if (lock_hit and market_tool and fetch_py and not (lk.get("exists") and not lk.get("stale")) and market.get("lamp") in ("YELLOW", "RED")
            and os.environ.get("VIA_VRN2_NO_MARKET") != "1"):
        plan.append(("market", "⑥e 上一輪被擷取鎖擋住 → 鎖移開後重抓(價格 + 財報補缺 · 擷取 Python %s)" % fetch_py))''')
rep('''    if market_tool and fetch_py and market.get("lamp") in ("YELLOW", "RED") and "Python 本行程" in str(market.get("detail", "")) and not market.get("runner") and os.environ.get("VIA_VRN2_NO_MARKET") != "1":''',
    '''    if (market_tool and fetch_py and market.get("lamp") in ("YELLOW", "RED") and "Python 本行程" in str(market.get("detail", "")) and not market.get("runner")
            and os.environ.get("VIA_VRN2_NO_MARKET") != "1" and not any(k == "market" for k, _ in plan)):''')
rep('''    fetch_py, fetch_how = bounds_fetch_python(state, receipt)               # v0115 ⑥e / ⑥f 同一個擷取 Python
    plan = plan_fixes(''', '''    fetch_py, fetch_how = bounds_fetch_python(state, receipt)               # v0115 ⑥e / ⑥f 同一個擷取 Python
    if not state.get("market_tool"):                                          # v0117 repair 沒跑 ② → 自己找共用夾的 MarketFetch 最高版號(只讀)
        shared = Path(root) / "functional modules" / "VRN"
        tools = sorted(shared.glob("VRN2_MarketFetch_v[0-9][0-9][0-9][0-9].py"), key=lambda p: int(re.search(r"_v(\\d{4})", p.name).group(1))) if shared.is_dir() else []
        if tools:
            state["market_tool"] = str(tools[-1])
    plan = plan_fixes(''')
rep('''        elif key == "lock":
            try:''', '''        elif key == "vdf_lock":                                                # v0117 再看一次才移(避免剛好有新的擷取起來)
            lk = vdf_lock_state(v2)
            if not lk.get("exists"):
                lamp, detail = "GREEN", "擷取鎖已經不在"
            elif not lk.get("stale"):
                lamp, detail = "YELLOW", "擷取鎖 %s · 不動" % lk["why"]
            else:
                try:
                    lamp, detail = "GREEN", "擷取鎖 %s · 鎖時間 %s → 移到 %s(不刪)" % (lk["why"], lk["at"], clear_vdf_lock(lk))
                except OSError as error:
                    lamp, detail = "YELLOW", "擷取鎖移不開(%s)· %s" % (type(error).__name__, lk["path"])
        elif key == "lock":
            try:''')

rep('''            tool, basic = Path(state["market_tool"]), v2 / "output" / "VRN2_BasicInfo_latest.json"
            lamps = []''', '''            tool, basic = Path(state["market_tool"]), v2 / "output" / "VRN2_BasicInfo_latest.json"
            lamps = []
            try:
                old_err = retire_last_error(v2)                                # v0117 舊錯誤不算這輪的(重抓失敗才會再寫)
                if old_err:
                    info("⑤ 上一輪的 ⑥e last_error.txt 移到 %s(重抓失敗才會再寫)" % old_err)
            except OSError as error:
                info("⑤ last_error.txt 移不開(%s)· 照抓" % type(error).__name__)''')

# ---- 除錯報告:錯誤在前 + 擷取鎖列 ----
rep('''        tail = [l.strip() for l in err.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()][-6:]
        f("YELLOW", "⑥e 擷取錯誤(last_error.txt)", " | ".join(tail)[:600], "VDF 引擎自己的錯誤(VRN-2 只讀不改)· 網路 / 憑證 / 套件 → 照錯誤處理;整段在貼回包 vrn2/market/vdf/last_error.txt")
        whole = err.read_text(encoding="utf-8", errors="replace")''', '''        whole = err.read_text(encoding="utf-8", errors="replace")
        f("YELLOW", "⑥e 擷取錯誤(last_error.txt)", last_error_digest(whole), "VDF 引擎自己的錯誤(VRN-2 只讀不改)· 網路 / 憑證 / 套件 → 照錯誤處理;整段在貼回包 vrn2/market/vdf/last_error.txt")
        if VDF_BUSY in whole:                                                 # v0117
            lk = vdf_lock_state(v2)
            now = ("鎖還在 · " + lk["why"]) if lk.get("exists") else "鎖現在已不在(移開了 / 擷取跑完)"
            f("YELLOW", "⑥e 擷取鎖擋住(RUNNING.lock)", "VDF 引擎看到 market\\\\vdf\\\\RUNNING.lock 就停(上一個擷取被強制結束 · 鎖沒清)· 現在:%s" % now,
              "PID 已不在 → RoundAll ⑤ 自動修會移開鎖並重抓(跑 repair);PID 還在 → 等它跑完或確認它停了")''')

# ---- 收尾頁負責方 ----
rep('''    if step.startswith("①b VIA 加速器"):''', '''    if "擷取鎖" in step or ((ctx.get("vdf_busy") or VDF_BUSY in detail) and re.match(r"⑥ (步驟 ⑥e 市場擷取|⑥e 擷取錯誤)", step)):   # v0117 VDF 引擎被擷取鎖擋住
        lk = ctx.get("vdf_lock") or {}
        if lk.get("exists") and not lk.get("stale"):
            return "人工", "另一個 VDF 擷取還在跑(%s)→ 等它跑完或確認它停了;VRN-2 不動還在用的鎖" % lk.get("why", "")
        if lk.get("exists"):
            return "VRN-2", "上一個擷取被強制結束、鎖沒清 → 跑 repair:⑤ 自動修會移開過期鎖並重抓 ⑥e"
        return "VRN-2", "擷取鎖已不在(移開了)· ⑥e 這輪還沒重抓成 → 再跑 repair(⑤ 重抓 ⑥e)· 還是失敗看 last_error.txt"
    if step.startswith("①b VIA 加速器"):''')
rep('''    ctx = {"receipt": bool(receipt), "mops_deny": "Existing VIA network bridge denied" in text,''',
    '''    ctx = {"receipt": bool(receipt), "mops_deny": "Existing VIA network bridge denied" in text, "vdf_lock": vdf_lock_state(v2), "vdf_busy": VDF_BUSY in text,''')

rep('''    if "⑥f" in step and "Yahoo 代號" not in step:                          # v0110''', '''    if "擷取鎖" in step or (ctx.get("vdf_busy") and re.match(r"⑥ (步驟 ⑥e 市場擷取|⑥e 擷取錯誤)", step)):   # v0117 ⑥e 步驟列 / last_error / 擷取鎖說明 = 同一個擷取鎖
        return "%s|⑥e 擷取鎖" % owner
    if "⑥f" in step and "Yahoo 代號" not in step:                          # v0110''')

# ---- 自測 65 ~ 68 ----
rep('''        src64 = Path(__file__).read_text(encoding="utf-8")''', '''        v65 = td / "v65"
        (v65 / "market" / "vdf").mkdir(parents=True)
        lock65 = v65 / VDF_LOCK
        saved_alive, saved_info = globals()["pid_alive"], globals()["pid_info"]
        now65 = _dt.datetime.now(_dt.timezone.utc)
        try:
            s65a = vdf_lock_state(v65)
            lock65.write_text(json.dumps({"pid": 4242, "at": now65.isoformat(timespec="seconds")}), encoding="utf-8")
            globals()["pid_alive"] = lambda pid: False
            s65b = vdf_lock_state(v65)
            globals()["pid_alive"] = lambda pid: True
            globals()["pid_info"] = lambda pid: {"image": "C:/Python313/python.exe", "started": now65.timestamp() - 120}
            s65c = vdf_lock_state(v65)
            globals()["pid_info"] = lambda pid: {"image": "C:/Windows/explorer.exe", "started": now65.timestamp() - 120}
            s65d = vdf_lock_state(v65)
            globals()["pid_info"] = lambda pid: {"image": "C:/Python313/python.exe", "started": now65.timestamp() + 3600}
            s65e = vdf_lock_state(v65)
            globals()["pid_info"] = lambda pid: {}
            s65f = vdf_lock_state(v65)
            lock65.write_text("not json", encoding="utf-8")
            s65g = vdf_lock_state(v65)
        finally:
            globals()["pid_alive"], globals()["pid_info"] = saved_alive, saved_info
        chk("65 ⑥e 擷取鎖過期判斷:沒有鎖 · PID 已不在 = 過期 · 還在跑的 python 比鎖早起 = 不動 · 號碼現在是別的程式 / 比鎖晚起 = 過期(重用)· 讀不到程式名 = 不動 · 鎖讀不到 PID = 過期",
            s65a["exists"] is False and s65b["stale"] and "已不在" in s65b["why"] and s65c["stale"] is False and s65d["stale"] and "explorer.exe" in s65d["why"]
            and s65e["stale"] and "晚起" in s65e["why"] and s65f["stale"] is False and s65g["stale"] and "PID" in s65g["why"])
        lock65.write_text(json.dumps({"pid": 4242, "at": "2026-10-31T01:02:03+00:00"}), encoding="utf-8")
        moved66 = clear_vdf_lock({"path": str(lock65)})
        kept66 = v65 / "market" / "vdf" / moved66
        chk("66 過期擷取鎖移到 RUNNING.lock.stale_<時間>(不刪 · 內容照留)· 原位置空出來 · 貼回包帶 market/vdf/RUNNING.lock",
            not lock65.exists() and moved66.startswith("RUNNING.lock.stale_") and kept66.is_file() and '"pid": 4242' in kept66.read_text(encoding="utf-8")
            and "market/vdf/RUNNING.lock" in PASTE_FILES)
        v67 = td / "v67"
        (v67 / "VIA_Reports" / "vrn2" / "market" / "vdf").mkdir(parents=True)
        l67 = v67 / "VIA_Reports" / "vrn2" / VDF_LOCK
        l67.write_text(json.dumps({"pid": 4242, "at": now65.isoformat(timespec="seconds")}), encoding="utf-8")
        (v67 / "VIA_Reports" / "vrn2" / "market" / "vdf" / "last_error.txt").write_text("CMD: py e.py --tickers 1303,1319\\n\\n[ERROR] RuntimeError: Another writer may be active. Inspect x", encoding="utf-8")
        rc67 = {"market": {"lamp": "YELLOW", "detail": "擷取 RED:VDF AllInOne_v039 · 失敗 5", "runner": "VRN2_MarketFetchRun_v0100.py"}}
        try:
            globals()["pid_alive"] = lambda pid: False
            p67a = plan_fixes(v67, rc67, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")
            globals()["pid_alive"] = lambda pid: True
            globals()["pid_info"] = lambda pid: {"image": "/py/python", "started": now65.timestamp() - 60}
            p67b = plan_fixes(v67, rc67, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")
            l67.unlink()
            p67c = plan_fixes(v67, rc67, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")
            os.environ["VIA_VRN2_NO_MARKET"] = "1"
            p67d = plan_fixes(v67, rc67, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")
        finally:
            os.environ.pop("VIA_VRN2_NO_MARKET", None)
            globals()["pid_alive"], globals()["pid_info"] = saved_alive, saved_info
        k67a, k67b, k67c, k67d = [[k for k, _ in p] for p in (p67a, p67b, p67c, p67d)]
        chk("67 ⑤ 自動修:上一輪 ⑥e 被擷取鎖擋住 + 鎖過期 → 先移鎖再重抓 ⑥e(順序)· 鎖還在跑 → 都不做 · 鎖已不在 → 只重抓 · VIA_VRN2_NO_MARKET=1 → 不重抓",
            k67a[:2] == ["vdf_lock", "market"] and "vdf_lock" not in k67b and "market" not in k67b and "vdf_lock" not in k67c and "market" in k67c and "market" not in k67d)
        dig68 = last_error_digest("CMD: C:/Python313/python.exe -u e.py --tickers " + ",".join(str(1000 + i) for i in range(43)) + " --output C:/x --datasets financial\\n\\n"
                                  "[ERROR] RuntimeError: Another writer may be active. Inspect C:/x/RUNNING.lock")
        o68a = owner_of({"lamp": "YELLOW", "step": "④ ⑥e 擷取鎖", "detail": "PID 9 還在跑(python.exe)"}, {"vdf_lock": {"exists": True, "stale": False, "why": "PID 9 還在跑"}})
        o68b = owner_of({"lamp": "YELLOW", "step": "⑥ 步驟 ⑥e 市場擷取", "detail": "失敗 5 · RuntimeError: Another writer may be active"}, {"vdf_lock": {"exists": False}})
        o68c = owner_of({"lamp": "YELLOW", "step": "⑥ ⑥e 擷取鎖擋住(RUNNING.lock)", "detail": "鎖現在已不在"}, {"vdf_lock": {"exists": False}})
        chk("68 「⑥e 擷取錯誤」錯誤訊息在前 · CMD 在後(43 檔代號縮成「43 檔」)· 收尾頁:擷取鎖還在跑 = 人工 · 鎖過期 / 已不在 = VRN-2(跑 repair 自己修)· 同一件事三列合一列",
            dig68.startswith("[ERROR] RuntimeError: Another writer may be active") and "--tickers (43 檔)" in dig68 and "1042" not in dig68
            and o68a[0] == "人工" and o68b[0] == "VRN-2" and "repair" in o68b[1] and o68c[0] == "VRN-2"
            and len(merge_same([{"lamp": "YELLOW", "step": st68, "detail": "x", "owner": "VRN-2", "why": "w"} for st68 in ("⑥ 步驟 ⑥e 市場擷取", "⑥ ⑥e 擷取錯誤(last_error.txt)", "⑥ ⑥e 擷取鎖擋住(RUNNING.lock)")],
                               {"vdf_busy": True})) == 1)
        e69 = v65 / "market" / "vdf" / "last_error.txt"
        e69.write_text("CMD: x\\n\\n[ERROR] RuntimeError: Another writer may be active", encoding="utf-8")
        r69a = retire_last_error(v65)
        r69b = retire_last_error(v65)
        kept69 = v65 / "market" / "vdf" / r69a
        src69 = Path(__file__).read_text(encoding="utf-8")
        chk("69 上一輪的 last_error.txt 在 ④ 跑啟動器前 / ⑤ 重抓 ⑥e 前移到 last_error.before_<時間>.txt(不刪)· MarketFetch 只在失敗時寫 → 這輪抓成功就不會留著舊錯誤 · 沒有檔 = 不動",
            r69a.startswith("last_error.before_") and kept69.is_file() and VDF_BUSY in kept69.read_text(encoding="utf-8") and not e69.exists() and r69b == ""
            and src69.count("old_err = " + "retire_last_error(") == 2)
        src64 = Path(__file__).read_text(encoding="utf-8")''')
rep("自測 64 項(v0115 的 59 項 + 60 ~ 64)。", "自測 64 項(v0115 的 59 項 + 60 ~ 64)· v0117 起 69 項。")
out = W / "new" / "VRN2_RoundAll_v0117.py"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0117 lines", s.count("\n"))
