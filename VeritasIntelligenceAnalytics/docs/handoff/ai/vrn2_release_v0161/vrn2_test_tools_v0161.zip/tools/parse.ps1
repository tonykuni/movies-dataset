$r = @()
foreach ($f in $args) { $t = $null; $e = $null; [void][System.Management.Automation.Language.Parser]::ParseFile($f, [ref]$t, [ref]$e); $sig = ($t | Where-Object { $_.Kind -notin 'NewLine', 'Semi', 'EndOfInput', 'LineContinuation', 'Comment' } | ForEach-Object { $_.Text }) -join "`u{1}"; $r += [pscustomobject]@{ f = (Split-Path $f -Leaf); e = $e.Count; h = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sig))) } }
$r | ConvertTo-Json -Compress
