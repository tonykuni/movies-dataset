"""Handle-All:可讀版 → 一行版(同 v0151 起的規則:上一行以 { 結尾或下一行以 } 開頭 → 空白;其他 → '; ' · 去掉 # 註解行)。"""


def join(src: str) -> str:
    lines = [l.strip() for l in src.split("\n")]
    lines = [l for l in lines if l and not l.startswith("#")]
    out = lines[0]
    for prev, cur in zip(lines, lines[1:]):
        out += (" " if prev.endswith("{") or cur.startswith("}") else "; ") + cur
    return out
