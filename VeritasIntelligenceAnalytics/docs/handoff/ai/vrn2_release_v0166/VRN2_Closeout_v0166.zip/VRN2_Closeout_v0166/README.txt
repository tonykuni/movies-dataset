VRN2_Closeout_v0166 — VRN-2 closeout package (2026-11-01 · manager v0258: table repair before the books)

Entry: python ActivateVRN-2_v0166.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0122.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0114.md (same release folder).
Runtime: VRN2_Runtime_v0158.zip = v0157 (196 members byte-identical) + VRN_SystemManager_v0258.

v0166 (operator 2026-11-01 uploaded the originals of the reports listed as 'output books missing annual data'): both print annual tables.
 Manager v0258 repairs two table shapes on a copy of the extraction result before v0257's books run unchanged: (1) item names printed ~3 pt
 below their numbers (CTBC: a value-only row + a label-only row) are merged only when the second reader prints that label and that annual
 number sequence on one line; (2) a year banner above the real period header (Daiwa: 3-5 numbers per cell) is re-gridded on the real header,
 each number placed by the second reader's x position; rows it cannot place go to the Rejected book with the reason. Repaired values pass the
 same column check, third-reader gate, one-row-one-item and the independent verifier. Launcher number v0165 is skipped (no launcher v0165).
v0164: TARGET_PRICE(ADJ) sync · store MOPS rows purged · consensus in the TWSE / TPEX format · v0163: no MOPS (step 6e --no-financial).
Verification: see VRN2_Verification_v0166.md. Hashes: PACKAGE_SHA256.json.
