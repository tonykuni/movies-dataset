#!/bin/bash
# v0166 e2e 變體:沙盒輸入夾改指向沙盒自己的 samples(多放操作員上傳的 Daiwa-6278 · 欣銓 3264 原文 · 只在沙盒)→ 最短一行 auto(整輪 · 啟動器 v0166 · 管理器 v0258)
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v166; W4=/home/user/vrn2_work/v164; T=$W/t166b; P=$S2/venv_vrn2/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
REL=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
cp /home/user/vrn2_work/v165/pdfs/daiwa6278.pdf "$T/samples/Daiwa-6278 20260521.pdf"; cp /home/user/vrn2_work/v165/pdfs/ctbc3264.pdf "$T/samples/欣銓(3264,B_買進)-CTBC260918.pdf"
for f in "$T/VIA/VIA_Reports/vrn2/VRN2_Input_latest.json" "$T/VIA/functional modules/VRN2/SSOT/"*.json; do sed -i "s#$S/v153/t153d/samples#$T/samples#g; s#$S/v151/t151/samples#$T/samples#g" "$f"; done
grep -l "$T/samples" "$T/VIA/VIA_Reports/vrn2/VRN2_Input_latest.json" >/dev/null && echo input repointed
$P -I $W4/seed164.py $T $W4/rt > $W/seed166b.log 2>&1; cat $W/seed166b.log
B=$T.br; D6=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166; mkdir -p $D6
cp $W/release166/VRN2_Closeout_v0166.zip $W/release166/VRN2_Release_v0166.json $W/release166/VRN2_RoundAll_v0122.py $W/release166/VRN2_RoundAll_v0122.md $W/release166/VRN2_HandleAll_v0114.md $W/release166/VRN2_HandleAll_v0114_boot.txt $D6/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release166/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
cd "$T/home" && env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2 timeout 6000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_b_full.log 2>&1; echo "b_full rc $?" > $W/tiny166b.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_b_full.log
cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_b_full.json 2>/dev/null; rm -rf "${W:?}/out_b_full"; cp -a $V2/output $W/out_b_full 2>/dev/null; cp -a $V2/verify_independent $W/verify_b_full 2>/dev/null; cat $W/tiny166b.rc
