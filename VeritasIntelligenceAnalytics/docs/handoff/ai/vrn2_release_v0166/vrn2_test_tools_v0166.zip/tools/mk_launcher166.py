"""ActivateVRN-2_v0166.py = v0164 + 管理器 VRN_SystemManager_v0258(表格修補:科目半行配對 · 兩層期間表頭重排)· runtime v0158 = runtime v0157(196 個成員一字不改)+ v0258。
操作員 2026-11-01 上傳原文(欣銓 3264 · Daiwa-6278)。啟動器版號跳過 v0165(v0165 是只換 RoundAll 的發行夾,沒有 v0165 啟動器)。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v164/pkg164/ActivateVRN-2_v0164.py")
OUT = Path("/home/user/vrn2_work/v166/pkg166/ActivateVRN-2_v0166.py")
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0164: v0163 entry + the operator decisions of 2026-11-01', '''"""VRN-2 v0166: v0164 entry + manager VRN_SystemManager_v0258 (table repair before the books). Operator 2026-11-01 uploaded the originals of the
reports the closeout listed as "output books missing annual data" (human item H-275f449a): both print annual tables, the books dropped them.
 - 欣銓(3264) CTBC page 5: each item name is printed ~3 pt below its numbers → the engine stores a value-only row and a label-only row; the books
   skipped both (not even in the Rejected book). v0258 merges them only when the second reader prints that label and that annual number sequence on
   one line (unique) · label pieces split over cells are joined.
 - Daiwa-6278 page 2: a year banner above the real period header → cells with 3-5 numbers ("一格多值"). v0258 re-grids on the real header row:
   the second reader must find that header line once and each data row once (item + same numbers); each number goes to the nearest header label
   (one-to-one · in order · within 0.4 column gap); a row it cannot place goes to the Rejected book with the reason.
 Every repaired value still passes the second-reader column check, the third-reader gate, one-row-one-item and the independent verifier (step 11).
 Real originals: 3264 → 225 annual values · 6278 → 30 · independent verifier 685 / 685 ALIGNED; v0257 output kept (nothing removed).
 Runtime v0158 = runtime v0157 (196 members byte-identical) + VRN_SystemManager_v0258. Receipt VRN2_Closeout_v0166.json.
 Launcher number v0165 is skipped (release folder v0165 only replaced RoundAll; there is no launcher v0165).

VRN-2 v0164: v0163 entry + the operator decisions of 2026-11-01''')
rep('VERSION = "ActivateVRN-2 v0164"', 'VERSION = "ActivateVRN-2 v0166"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0157.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0158.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0157.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0158.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0164.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0166.json"')
rep('MANAGER = "VRN_SystemManager_v0257.py"   # v0153:', 'MANAGER = "VRN_SystemManager_v0258.py"   # v0166: table repair before the books (half-line labels · two-level period header) over v0257 · v0153 v0257:')
rep('''    assert MANAGER == "VRN_SystemManager_v0257.py"
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            mgr = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN_SystemManager_v\\d{4}\\.py", n))
        assert mgr[-1] == "VRN_SystemManager_v0257.py" and "VRN_SystemManager_v0255.py" in mgr and "VRN_SystemManager_v0243.py" in mgr, mgr[-3:]''',
'''    m258 = selftest_source("VRN_SystemManager_v0258.py").read_text(encoding="utf-8")
    assert 'TAG = "v0258"' in m258 and 'PRIOR_NAME = "VRN_SystemManager_v0257.py"' in m258 and "def _zone_repair(" in m258 and '_out_books = _timed("輸出冊", _out_books_v0258)' in m258
    assert "def _zr_same_line(" in m258 and "def _zr_regrid(" in m258 and "_ZR_REASON" in m258
    assert MANAGER == "VRN_SystemManager_v0258.py"
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            mgr = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN_SystemManager_v\\d{4}\\.py", n))
        assert mgr[-1] == "VRN_SystemManager_v0258.py" and "VRN_SystemManager_v0257.py" in mgr and "VRN_SystemManager_v0255.py" in mgr and "VRN_SystemManager_v0243.py" in mgr, mgr[-3:]''')
rep('''    print("[PASS] v0153: manager v0257 is the active manager''', '''    print("[PASS] v0166: manager v0258 is the active manager (table repair before the books: half-line label pairing · two-level period header re-grid · both confirmed by the second reader · unplaced rows to Rejected) · v0257 kept as PRIOR")
    print("[PASS] v0153: manager v0257 (PRIOR of v0258)''')
rep('return runtime / MANAGER, lamp, detail + " · active manager v0257"', 'return runtime / MANAGER, lamp, detail + " · active manager v0258"')
rep('return lamp, detail + " · launcher v0164"', 'return lamp, detail + " · launcher v0166"')
rep('note="VRN-2 private runtime; exact ship v0157 (launcher v0164 · no MOPS · store MOPS rows purged); manager v0257 (over v0255);',
    'note="VRN-2 private runtime; exact ship v0158 (launcher v0166 · no MOPS · store MOPS rows purged); manager v0258 table repair (over v0257 · v0255);')
rep('print("NEXT: [%s] VRN-2 v0164 · rc %s', 'print("NEXT: [%s] VRN-2 v0166 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0166", len(s.splitlines()), "lines")
