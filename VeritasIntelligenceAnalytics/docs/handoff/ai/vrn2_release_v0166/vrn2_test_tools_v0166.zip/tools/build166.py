"""v0166(冪等):套件 VRN2_Closeout_v0166.zip(啟動器 v0166 · runtime v0158 = v0157 + 管理器 v0258)→ RoundAll v0122(填套件雜湊)→ Handle-All v0114
→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0166)。vrn2_release_v0165 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v166"); pkg, rel = W / "pkg166", W / "release166"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v165/release165")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r164 = json.loads((REPO / "vrn2_release_v0164/VRN2_Release_v0164.json").read_text(encoding="utf-8"))
r165 = json.loads((REPO / "vrn2_release_v0165/VRN2_Release_v0165.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0158.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0158.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0157.zip " + r164["runtime"]["zip_sha256"]
assert rt["retained_members"] == 196 and rt["new_members"] == ["VRN_SystemManager_v0258.py"]
old = {c["path"]: c["sha256"] for c in r164["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0166.py", "VRN2_Runtime_v0158.zip", "VRN2_Runtime_v0158.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0166.py", "VRN2_Runtime_v0158.zip", "VRN2_Runtime_v0158.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0164 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0166 — VRN-2 closeout package (2026-11-01 · manager v0258: table repair before the books)\n\n"
  "Entry: python ActivateVRN-2_v0166.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0122.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0114.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0158.zip = v0157 (196 members byte-identical) + VRN_SystemManager_v0258.\n\n"
  "v0166 (operator 2026-11-01 uploaded the originals of the reports listed as 'output books missing annual data'): both print annual tables.\n"
  " Manager v0258 repairs two table shapes on a copy of the extraction result before v0257's books run unchanged: (1) item names printed ~3 pt\n"
  " below their numbers (CTBC: a value-only row + a label-only row) are merged only when the second reader prints that label and that annual\n"
  " number sequence on one line; (2) a year banner above the real period header (Daiwa: 3-5 numbers per cell) is re-gridded on the real header,\n"
  " each number placed by the second reader's x position; rows it cannot place go to the Rejected book with the reason. Repaired values pass the\n"
  " same column check, third-reader gate, one-row-one-item and the independent verifier. Launcher number v0165 is skipped (no launcher v0165).\n"
  "v0164: TARGET_PRICE(ADJ) sync · store MOPS rows purged · consensus in the TWSE / TPEX format · v0163: no MOPS (step 6e --no-financial).\n"
  "Verification: see VRN2_Verification_v0166.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0166.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0166", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0166.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0166/" + n, date_time=(2026, 11, 1, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0122.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0166"' in ra and 'VERSION = "v0122"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166"' in ra
(rel / "VRN2_RoundAll_v0122.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0165'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166'")
rep("$F = 'VRN2_RoundAll_v0121.py'", "$F = 'VRN2_RoundAll_v0122.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0113", "Handle-All v0114", ha.count("Handle-All v0113"))
rep("$Mode = ($last -ge 153 -and $haveOut) ? 'repair' : 'full'", "$Mode = ($last -ge 166 -and $haveOut) ? 'repair' : 'full'")
rep("(上一輪輸出冊是啟動器 v0153 以前做的 · 管理器 v0257 要重做輸出冊)", "(上一輪輸出冊是啟動器 v0166 以前做的 · 管理器 v0258 要重做輸出冊:補回原文有、以前漏掉的年度表)")
rep("(輸出冊是啟動器 v0153 以後做的 · 這版只改 ⑥f 共識出網 → 不整輪)", "(輸出冊是啟動器 v0166 做的 → 不整輪)")
rep("管理器 v0257", "管理器 v0258(輸出冊前表格修補)", ha.count("管理器 v0257"))
rep("v0164", "v0166", ha.count("v0164"))
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if re.search(r"v0113|v0153|v0257", l) and not l.lstrip().startswith("#")]
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0165", "vrn2_release_v0166"), ("VRN2_HandleAll_v0113.md", "VRN2_HandleAll_v0114.md"), ("Handle-All v0113 SHA-256 OK", "Handle-All v0114 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0114_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166/VRN2_HandleAll_v0114_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0114(2026-11-01 · 管理器 v0258 輸出冊前表格修補 · 套件 v0166 · RoundAll v0122)

操作員 2026-11-01 上傳原文 4 份 → 收尾頁人工項「輸出冊缺項 · 年度數據」裡的 **欣銓(3264)與 Daiwa-6278 原文都有年度表**(擷取後輸出冊漏掉 · 不是原文沒有)。這版:

| 項目 | 現在 |
|---|---|
| 管理器 v0258 | ① 科目印在數字下方 3pt(CTBC)→ 第二讀取器同一印刷列有「科目 + 這串年度數字」才併 ② 年份橫幅蓋在真正的期間表頭上(Daiwa)→ 依真正的表頭重排(第二讀取器的 x 位置)· 放不進去的列進剔除冊(帶理由)|
| 原文實測 | 欣銓 3264 → 225 筆 · Daiwa-6278 → 30 筆 · 獨立驗證 685 / 685 對欄 |
| 回歸 | 沙盒 14 份真報告:原有 4905 筆一筆不少 · 剔除冊 / 基本資料 / 摘要不變 · 晶心科(6533 · 同一種 CTBC 版面)多 32 筆 · 獨立驗證 4937 / 4937 |
| 自動選模式 | 上一輪收據不是啟動器 v0166 做的 → **整輪**(輸出冊要由 v0258 重做 · 桌機約 40 分鐘)|
| 套件 | `vrn2_release_v0166/VRN2_Closeout_v0166.zip`(SHA-256 `%s` · 啟動器 v0166 · runtime v0158)|
| 一支 Python | `VRN2_RoundAll_v0122.py`(SHA-256 `%s` · 自測 88 項)|

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定)· 第 2 行 = 下面 PowerShell 那一行的編碼版(一樣核對 SHA-256 才執行)。這一輪 auto 會自己選整輪(不用另設 `VRN2_MODE`)。

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0122.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0122.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

第 1 行列出待核項與代碼 · 第 2 行記一筆確認(代碼照收尾頁那一項)· 撤銷:`--confirm revoke H-xxxxxxxx`。確認後收尾頁用上一輪的結果重做。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0114 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0122 `%s`)。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0114.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0122.py(套件 v0166 · 管理器 v0258 輸出冊前表格修補)

`VRN2_RoundAll_v0122.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0121 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0166/VRN2_Closeout_v0166.zip`(SHA-256 `%s` · 本檔內已釘)· 啟動器 v0166 · runtime v0158 = v0157 的 196 個成員不動 + 管理器 v0258 |
| ③ 自測 | 改跑管理器 v0258(它再跑 v0257 / v0255 的自測)|
| 收尾頁 | 「輸出冊缺項」的人工提示:先把那幾份原 PDF 上傳給 AI 對(有年度表 = 擷取漏 · 要修);原文真的沒有年度表才算缺 |
| 負責方 | ⑤ 自動修那一列寫「擷取環境缺 requests / yfinance … 交 VCGC」→ VCGC(v0120 起落到 VRN-2)|

`--confirm` 照舊只有操作員親手打才記。自測 88 項(v0121 的 85 項 + 84 · 85 · 86)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0122.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0166 (manager v0258 · runtime v0158) + VRN2_RoundAll_v0122 + VRN2_HandleAll_v0114", "date": "2026-11-01",
        "trigger": "操作員 2026-11-01 上傳原文 4 份(MQ-1560 · 3014TT · Daiwa-6278 · 欣銓 3264)· 收尾頁人工項 H-fd2ea35f(MQ-1560 四點 OCR)與 H-275f449a(輸出冊缺項 3 份 · 年度數據)",
        "finding": {"3264_CTBC": "page 5 prints 資產負債表 / 現金流量表 / 損益表 / 比率分析 (2022 – 2027F); item names ~3 pt below their numbers → value-only + label-only rows, both skipped by the books (not even Rejected)",
                    "6278_Daiwa": "page 2 financial summary: year banner (2024 · 2025 · 2026) above the real header (1Q24 … 1Q26 · 2024 · 2025 · 3M26) → 3-5 numbers per cell, rejected as 一格多值; annual 2024 / 2025 actuals never reached the book (report has no forecasts · Target price n.a.)",
                    "6143_華南": "original not uploaded; desktop Rejected 40 values with reason 轉置表第三讀法對不上 → needs the original to check",
                    "MQ-1560": "image-only; four OCR points match the original wording and numbers; OCR spacing glitches; one word wrong (chi players → chip layers); its OCR'd annual table stays in Rejected (4 of 68 OCR values wrong vs the image)"},
        "base_package": {"name": "VRN2_Closeout_v0164 (launcher v0164 · runtime v0157)", "retained": "runtime v0157's 196 members byte-identical inside runtime v0158; every package member except launcher / runtime byte-identical to v0164"},
        "fixes": {"SystemManager_v0258": "thin tail over v0257: _zone_repair on a copy of the extraction result (P1VIEW untouched) → v0257 books unchanged · half-line pairing confirmed by the second reader (label + annual numbers on one printed line · unique) · two-level period header re-grid confirmed by the second reader (header line once · each row once · nearest label one-to-one within 0.4 column gap) · unplaced rows to Rejected with the reason · repair error → books from the original result",
                  "launcher_v0166": "runtime v0158 · manager v0258 · receipt VRN2_Closeout_v0166.json · selftest block v0166 (launcher number v0165 skipped)",
                  "RoundAll_v0122": "package v0166 · step 3 selftest runs manager v0258 · closeout hint for 輸出冊缺項: upload the originals to the AI first (annual table present = extraction miss) · owner: a step-5 row saying the fetch environment lacks requests / yfinance → VCGC (was VRN-2 since v0120)",
                  "HandleAll_v0114": "v0113 pointed at RoundAll v0122 (vrn2_release_v0166) · auto picks full when the last receipt is older than launcher v0166 (books must be rebuilt by v0258)"},
        "tests": {"originals": "3264 225 · 6278 30 · independent verifier 685 / 685 ALIGNED · v0257 rows kept (0 removed)",
                  "regression_14_real": "FinancialData 4905 → 4937 (0 removed · +32 晶心科 6533 CTBC p5) · Rejected / BasicInfo / Summary unchanged · independent verifier 4937 / 4937"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"changed": True},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0121.py", "sha256": r165["roundall"]["sha256"], "status": "superseded 2026-11-01 (package v0164); file kept in vrn2_release_v0165"}],
        "roundall": {"name": "VRN2_RoundAll_v0122.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0122.md"},
        "handleall": {"name": "VRN2_HandleAll_v0114.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0114_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0166/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0166.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0166.py"]).hexdigest()},
        "results": {"status": "see VRN2_Verification_v0166.md"}}
(rel / "VRN2_Release_v0166.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
