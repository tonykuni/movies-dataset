"""VRN2_RoundAll_v0122.py = v0121(倉裡 vrn2_release_v0165)+ 套件 v0166(啟動器 v0166 · runtime v0158 · 管理器 v0258 表格修補)· 缺項的人工提示改成「先上傳原 PDF 給 AI 對」。
操作員 2026-11-01 上傳原文 4 份(MQ-1560 · 3014TT · Daiwa-6278 · 欣銓 3264)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v166")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0165/VRN2_RoundAll_v0121.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0121')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0121 — ', '"""VRN2_RoundAll v0122 — ', 1)
at = doc.index("v0121(")
doc = doc[:at] + '''v0122(操作員 2026-11-01 上傳原文 4 份 · 收尾頁人工項「輸出冊缺項 · 年度數據」對原文):
  · 欣銓(3264) CTBC 第 5 頁(資產負債表 · 現金流量表 · 損益表 · 比率分析 · 2022 ~ 2027F)與 Daiwa-6278 第 2 頁(financial summary 2024 / 2025)
    原文都有年度表 —— 是擷取後輸出冊漏掉(v0121 以前的提示「原文沒有就是真的沒有」不對)。
  · 套件 v0166(啟動器 v0166 · runtime v0158 = v0157 的 196 個成員不動 + 管理器 VRN_SystemManager_v0258「輸出冊前表格修補」):
      ① 科目印在數字下方 3pt(擷取成「只有數字」+「只有科目」兩列)→ 第二讀取器同一印刷列有「科目 + 這串年度數字」才併(唯一)·
        科目被切成幾格接回(中中不空 · 中英一格空白);
      ② 年份橫幅蓋在真正的期間表頭上(一格 3 ~ 5 個值「一格多值」)→ 依真正的表頭列重排:第二讀取器找得到那一行(唯一)· 每一列
        「科目 + 同一串數字」找得到(唯一)· 每個數字歸最近的表頭字(一對一 · 順序 · 0.4 欄距內)· 放不進去的列進剔除冊(帶理由)。
      修過的值照樣過第二讀取器對欄 · 第三讀法閘 · 一列一科目 · ⑪ 獨立驗證。原文實測:3264 → 225 筆 · 6278 → 30 筆 · 獨立驗證 685 / 685 對欄;
      沙盒 14 份真報告回歸:原有 4905 筆一筆不少 · 剔除冊 / 基本資料 / 摘要不變 · 晶心科(6533 · 同一種 CTBC 版面)多 32 筆 · 獨立驗證 4937 / 4937。
  · 收尾頁「輸出冊缺項」的人工提示:先把那幾份原 PDF 上傳給 AI 對(有年度表 = 擷取漏 · 要修);原文真的沒有年度表才算缺。
  · 收尾頁負責方:⑤ 自動修那一列(例:重組 Combined)內容寫「擷取環境缺 requests / yfinance … 交 VCGC」→ VCGC(v0120 起這列落到 VRN-2 · 沙盒整輪實錄)。
  · ③ 自測改跑管理器 v0258(它再跑 v0257 / v0255 的自測)。給 Handle-All v0114 用(auto:上一輪收據不是啟動器 v0166 做的 → 整輪 · 輸出冊要由 v0258 重做)。
  · 自測 88 項(v0121 的 85 項 + 84 · 85 · 86)。共用 MarketFetch 與 VDF 引擎照舊只讀不改。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0121.py", "用法:python VRN2_RoundAll_v0122.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


b0 = s.index('VERSION = "v0121"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0164", "v0166").replace("VRN2_Runtime_v0157", "VRN2_Runtime_v0158")
s = pre + post
rep('VERSION = "v0121"', 'VERSION = "v0122"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
rep('("VRN_SystemManager_v0257.py", 1800)', '("VRN_SystemManager_v0258.py", 1800)')
rep("· v0120 起 78 項 · v0121 起 83 項。", "· v0120 起 78 項 · v0121 起 83 項 · v0122 起 88 項。")
for a in ('"C:/Users/x/Downloads/VRN2_RoundAll_v0121.py"', '"VRN2_RoundAll_v0121.py" in html_'):
    s = s.replace(a, a.replace("v0121", "v0122"))
rep('''        return "人工", "先看原 PDF:原文真的沒有年度數據 / 欄位就是沒有;有 → 貼回包給 AI"''',
    '''        return "人工", "先把那幾份原 PDF 上傳給 AI 對:原文有年度表 = 擷取漏(要修 · 欣銓 3264 / Daiwa-6278 就是 · 管理器 v0258 已補);原文真的沒有年度表才算缺"''')
rep('''    if "⑥f" in step:
        if "Yahoo 代號" in step:''', '''    if step.startswith("⑤ 修") and re.search(r"擷取環境缺|缺 yfinance|缺 requests", detail):   # v0122 ⑤ 自動修的列寫「擷取環境缺 … 交 VCGC」(重組 Combined 時共識欄留空)
        return "VCGC", "⑤ 自動修照跑 · 共識欄留空是擷取環境缺套件(requests / yfinance)→ VCGC 建 via_tw_fetch(VRN-2 不 pip)"
    if "⑥f" in step:
        if "Yahoo 代號" in step:''')
rep('''"缺年度數據 / 欄位 → 貼回包;原文沒有就是真的沒有")''', '''"缺年度數據 → 把那幾份原 PDF 上傳給 AI 對(有年度表 = 擷取漏 · 要修);原文真的沒有年度表才算缺")''')
rep('''and src82.count("return step_" + "confirm(args)") == 1 and SSOT_CHAIN[0] == "VRN2_SSOT_Proposals_v0101.json" and VERSION == "v0121")''',
    '''and src82.count("return step_" + "confirm(args)") == 1 and SSOT_CHAIN[0] == "VRN2_SSOT_Proposals_v0101.json" and VERSION >= "v0121")''')
rep('''        chk("82 v0121:套件照舊 v0166 ·''', '''        chk("82 v0121:套件照釘(v0122 起 v0166)·''')
rep('''            and output_gaps(td / "nowhere") == [])
''', '''            and output_gaps(td / "nowhere") == [])
        chk("84 v0122:套件 v0166(啟動器 v0166 · runtime v0158 · 收據 VRN2_Closeout_v0166.json)· ③ 自測跑管理器 v0258(它再跑 v0257 / v0255 的自測)· 不再單跑 v0257",
            PACKAGE == "VRN2_Closeout_v0166" and LAUNCHER == "ActivateVRN-2_v0166.py" and RUNTIME_ZIP == "VRN2_Runtime_v0158.zip" and RECEIPT == "VRN2_Closeout_v0166.json"
            and RELEASE_REL.endswith("/vrn2_release_v0166") and ("VRN_SystemManager_v0258.py", 1800) in SELFTESTS and ("VRN_SystemManager_v0257.py", 1800) not in SELFTESTS and VERSION == "v0122")
        o85 = owner_of({"lamp": "YELLOW", "step": "⑥ 完成判定 · 輸出冊(基本資料 / 年度數據 / 一標題四重點)", "detail": "個股 52 份 · 缺項 1 份"}, {})
        h85 = next((x[2] for x in [("YELLOW", "輸出缺項", "缺年度數據 → 把那幾份原 PDF 上傳給 AI 對(有年度表 = 擷取漏 · 要修);原文真的沒有年度表才算缺")]), "")
        src85 = Path(__file__).read_text(encoding="utf-8")
        chk("85 v0122:輸出冊缺項 → 人工 · 提示先把原 PDF 上傳給 AI 對(有年度表 = 擷取漏 · 要修)· 不再寫「原文沒有就是真的沒有」",
            o85[0] == "人工" and "上傳給 AI" in o85[1] and "擷取漏" in o85[1] and "v0258" in o85[1] and h85 in src85
            and ("欄位 → 貼回包;原文沒有就是" + "真的沒有") not in src85 and ("欄位就是沒有;有 → " + "貼回包給 AI") not in src85)
        o86 = owner_of({"lamp": "YELLOW", "step": "⑤ 修 · TARGET_PRICE(ADJ) 同步還原 + 共識照 TWSE / TPEX 格式合併(ConsensusJoin v0105)",
                        "detail": "共識合併 v0105 · join · Combined 14 列(共識欄全空:擷取環境缺 requests(新引擎經 VIA 網路工具 · Yahoo 車道要它 · 交 VCGC 環境工具補)"}, {})
        o86b = owner_of({"lamp": "YELLOW", "step": "⑤ 修 · TARGET_PRICE(ADJ) 同步還原 + 共識照 TWSE / TPEX 格式合併(ConsensusJoin v0105)", "detail": "共識合併 v0105 · join · Combined 14 列"}, {})
        chk("86 v0122:⑤ 自動修那一列寫「擷取環境缺 requests … 交 VCGC」→ VCGC(沙盒整輪實錄被算成 VRN-2 1 項)· 沒寫擷取環境 → 照舊",
            o86[0] == "VCGC" and "via_tw_fetch" in o86[1] and o86b[0] != "VCGC")
''')
rep('''chk("78 套件 v0166(啟動器 v0166 · runtime v0157)''', '''chk("78 套件 v0166(啟動器 v0166 · runtime v0158)''')
(W / "new").mkdir(exist_ok=True)
out = W / "new/VRN2_RoundAll_v0122.py"
out.write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,40}v0164.{0,40}", s[s.index('VERSION = "v0122"'):])]
print("RoundAll v0122 lines", s.count("\n"), "· v0164 left in body:", len(left), left[:3])
