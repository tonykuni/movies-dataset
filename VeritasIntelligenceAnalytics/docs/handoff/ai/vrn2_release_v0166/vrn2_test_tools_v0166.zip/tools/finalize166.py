"""v0166 收尾:驗證紀錄 · 交接 v0167(從 v0166 抄 · 只增)· 放進倉 vrn2_release_v0166 · logs / 工具 zip。原文 PDF / 輸出冊的值不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v166"); rel = W / "release166"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    for a, b in ((str(W / "t166a"), "<sbx>"), (str(W / "t166b"), "<sbx-b>"), (str(W), "<w>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        x = x.replace(a, b)
    return x


R = json.loads((rel / "VRN2_Release_v0166.json").read_text(encoding="utf-8"))
mgr = [l for l in lines(W / "mgr258_selftest.log") if l.startswith(("[PASS]", "[FAIL]"))]
lau = [l for l in lines(W / "launcher166_selftest.log") if l.startswith("[FAIL]") or "v0166" in l and l.startswith("[PASS]")]
ra = [l for l in lines(W / "rall122_selftest_venv.log") if re.search(r"^\[PASS\] 8[45] |^\[FAIL\]|--selftest · ", l)]
ps = json.loads((W / "pscheck166.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny166.rc") if l.strip()] + [l for l in lines(W / "tiny166b.rc") if l.strip()]
pat = r"boot:|boot SHA|④ 自動選模式|① 套件 ·|v0258 表格修補|===== 收尾|\[(VRN-2|人工|VCGC|資料源)\] \d|年度數據 \d+ 筆|ALIGNED"
e2e = {n: [short(l)[:240] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)][:24] for n in ("auto1", "auto2", "tamper", "b_full")}
conf = [short(l)[:200] for l in lines(W / "confirm_list.log")][:20]
states = {}
for n in ("auto1", "auto2", "b_full"):
    p = W / ("closeout_%s.json" % n)
    if p.is_file():
        d = json.loads(p.read_text(encoding="utf-8"))
        states[n] = {"state": d.get("state"), "per_owner": d.get("per_owner"), "items": [(i["owner"], i.get("step", "")[:60], i.get("code")) for i in d.get("items") or []]}
ov = [l for l in lines(W / "originals_verify.log") if re.search(r"年度數據|ALIGNED|FAIL", l)]
rv = [l for l in lines(W / "regression_verify.log") if re.search(r"年度數據|晶心科|FAIL", l)]
R["results"] = {"manager_v0258_selftest": mgr[-1:], "launcher_v0166_selftest": lau, "roundall_v0122_selftest": ra, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e,
                "confirm_list": conf, "closeout_states": states, "originals": [short(l) for l in ov], "regression_14": [short(l) for l in rv],
                "regression_books": "FinancialData 4905 → 4937 (removed 0 · added 32 晶心科 6533 P5) · Rejected 744 = 744 (0 changed) · BasicInfo / Summary identical",
                "not_run": "the desktop itself (next run: auto → full because the last receipt is v0164 · books rebuilt by v0258) · 華南-6143 original (not uploaded) · the operator's own --confirm"}
(rel / "VRN2_Release_v0166.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0166 驗證紀錄(2026-11-01 · 管理器 v0258 輸出冊前表格修補 · 套件 v0166 · RoundAll v0122 · Handle-All v0114)

## 1. 起因

桌機 2026-11-01 06:32(v0165 repair)收尾 **REVIEW**:人工 2 項 —— H-fd2ea35f(MQ-1560 影像頁四點 OCR)· H-275f449a(輸出冊缺項 3 份 · 年度數據:Daiwa-6278 · 欣銓 3264 · 華南投顧-6143)。
操作員上傳原文 4 份(MQ-1560 · 3014TT · Daiwa-6278 · 欣銓 3264 · 只在容器沙盒用 · 不進倉)。

## 2. 原文核對結論

| 檔 | 結論 |
|---|---|
| MQ-1560(影像頁) | 四點都在原文(三點在 Why it matters · 一點在 What's new)· 數字全對(70-80%% · 10%% · 20-30%% · 25-30%%)· OCR 有字距雜訊(GP M · ram ping · m gmt)· **一處字詞錯**:原文 chip layers → 摘錄 chi players。影像頁的年度表 OCR 值照舊全進剔除冊(68 值裡 4 值跟原圖不符 · 剔除是對的)|
| 欣銓 3264(CTBC) | **原文有年度表**(第 5 頁 資產負債表 / 現金流量表 2022-2025 · 損益表 / 比率分析 2023-2027F · 第 1 頁表 2022-2027F)→ 擷取後輸出冊漏掉:科目印在數字下方約 3pt,擷取成「只有數字」+「只有科目」兩列,輸出冊兩列都略過(剔除冊也沒有)|
| Daiwa-6278 | **原文有年度數據**(第 2 頁 financial summary 2024 / 2025 實績 · Target price n.a. · 沒有預估年)→ 年份橫幅蓋在真正的期間表頭上,一格 3 ~ 5 個值,全進剔除冊「一格多值」|
| 3014TT | 年度數據 430 筆照舊(2023/2024 年報告 · 共識要的 2026 EPS 原文本來就沒有)· 四點:第 2 點從句中開始(「CPU(Meteor Lake)…」· 原文那段是字距拉開的排版)· 第 1 / 3 點講同一件事(Type-C PD 10%%)→ 摘要器下一輪再看 |
| 華南投顧-6143 | 沒上傳 · 桌機剔除冊 40 值(轉置表第三讀法對不上)→ 要原文才能判 |

以前寫的「原文沒有就是真的沒有」用的是本機 ~20 KB 的合成替身 —— 對 3264 / 6278 不成立,這裡更正。

## 3. 修正:管理器 VRN_SystemManager_v0258(薄尾 · PRIOR v0257)

輸出冊之前,在擷取結果的**副本**上修兩種表(P1VIEW 不動),然後 v0257 的輸出冊照跑:
- ① 科目半行配對:「只有數字」列旁邊是「只有科目」列 → 第二讀取器(pypdfium2)同一印刷列有「科目 + 這串年度欄數字」(整頁唯一 · ≥ 2 個數)才併 · 科目被切成幾格接回(中中不空 · 中英一格空白)。
- ② 兩層期間表頭:表頭下一列才是真正的期間(全是期間字 · ≥ 2 個年度 · 不重複 · 有格裝了好幾個)→ 依那一列重排:第二讀取器找得到那一行(唯一)· 每一列「科目 + 同一串數字」找得到(唯一)· 每個數字歸最近的表頭字(一對一 · 順序 · 0.4 欄距內)· 放不進去的列移剔除冊(帶理由)。
- 修補出錯 → 輸出冊照 v0257(原始結果)· 印一行原因。

## 4. 測試

| 項目 | 結果 |
|---|---|
| 管理器 v0258 自測 | %s |
| 啟動器 v0166 自測 | %s |
| RoundAll v0122 自測 | %s |
| PowerShell 剖析 | %s |
| 原文(沙盒 · 管理器直跑) | 欣銓 3264 → 225 筆 · Daiwa-6278 → 30 筆 · v0257 的筆數一筆不少 · 獨立驗證 v0114:%s |
| 回歸(沙盒 14 份真報告) | %s · 獨立驗證:%s |
| e2e(最短一行 · 沙盒 14 份) | %s · auto 第一次 → 整輪(收據 v0153)· 第二次 → repair(收據 v0166)· 竄改開機檔 → 不執行 · 收尾 BLOCKED(VRN-2 0 · 等 VCGC 的沙盒環境 · 人工 1 = MQ-1560 四點)|
| e2e 變體(沙盒 + 兩份原文 · 16 份) | 整輪 · 年度數據 5192 筆(欣銓 225 · Daiwa-6278 30 · 晶心科 111)· ⑪ 獨立驗證錯值 0(ALIGNED 4665 · SUBALIGNED 452 · TRANSALIGNED 75)· 兩份新檔的摘要在沙盒失敗 = 容器測試環境 numpy 1.26.4 配 scikit-learn 1.9.1(np.long · 環境問題 · 不是 VRN-2 程式 · 摘要器這輪沒動 · 桌機 06:32 這兩份已有四點)|

e2e 收尾狀態:%s

## 5. 一行指令

cmd 一行 %d 字元 · PowerShell 最短一行 %d 字元 · 開機檔 `vrn2_release_v0166/VRN2_HandleAll_v0114_boot.txt`(SHA-256 `%s`)· Handle-All 一行 `%s` · RoundAll v0122 `%s` · 套件 `%s`。
auto:上一輪收據不是啟動器 v0166 做的 → 整輪(輸出冊由 v0258 重做 · 桌機約 40 分鐘)。

## 6. 沒做 / 待辦

- 人工確認:只有操作員親手打 `--confirm`(AI 不代打)。
- 華南投顧-6143 原文沒上傳(轉置表第三讀法對不上 40 值)。
- 3014TT 四點(第 2 點從句中開始 · 第 1 / 3 點重複)· MQ-1560 OCR 字詞錯(chi players)→ 摘要器 / OCR 下一輪。
""" % (R["results"]["manager_v0258_selftest"][0][:120] if mgr else "—", " · ".join(x[:80] for x in lau) or "—", " · ".join(x[:90] for x in ra[-1:]),
       pparse, " · ".join(ov[:1]), R["results"]["regression_books"], " · ".join(rv[:1]), " · ".join(rc),
       json.dumps({k: {"state": v["state"], "per_owner": v["per_owner"]} for k, v in states.items()}, ensure_ascii=False),
       H["cmd_line_chars"], H["tiny_line_chars"], H["boot_line_sha256"][:12], H["line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12])
(rel / "VRN2_Verification_v0166.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0166.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0164 + VRN2_RoundAll_v0121 + VRN2_HandleAll_v0113 · 2026-11-01(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0166 + VRN2_RoundAll_v0122 + VRN2_HandleAll_v0114 · 2026-11-01(操作員上傳原文 → 欣銓 3264 / Daiwa-6278 年度表是擷取後漏掉 → "
        "管理器 v0258 輸出冊前表格修補 · 套件 v0166)")
src = "\n".join(L)
once("> **本輪(v0165)**",
     "> **本輪(v0166)**:操作員上傳原文 4 份(MQ-1560 · 3014TT · Daiwa-6278 · 欣銓 3264)核對收尾頁兩個人工項 → **欣銓 3264 與 Daiwa-6278 原文都有年度表**(以前「原文沒有」的結論是用本機合成替身下的 · 不成立)。"
     "**管理器 v0258**(薄尾 · PRIOR v0257):輸出冊前在擷取結果副本上修兩種表 —— ① 科目印在數字下方 3pt(CTBC)→ 第二讀取器同一印刷列有「科目 + 這串年度數字」才併;"
     "② 年份橫幅蓋在真正的期間表頭上(Daiwa)→ 依真正的表頭重排(第二讀取器 x 位置 · 放不進去的列進剔除冊)。原文實測 3264 → 225 筆 · 6278 → 30 筆 · 獨立驗證 685 / 685;"
     "沙盒 14 份真報告回歸 0 筆少 · 剔除冊不變 · 晶心科 +32(同一種 CTBC 版面)。**套件 v0166**(啟動器 v0166 · runtime v0158)· **RoundAll v0122** · **Handle-All v0114**"
     "(auto:上一輪收據不是 v0166 → 整輪 · 最短一行 %d 字元 · cmd 一行 %d 字元)。MQ-1560 四點對原圖:數字全對 · 一處字詞 OCR 錯(chi players ← chip layers)。\n"
     "> **本輪(v0165)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
r165 = json.loads((REPO / "vrn2_release_v0165/VRN2_Release_v0165.json").read_text(encoding="utf-8"))
once("| **VRN2_HandleAll_v0113.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0113** | `vrn2_release_v0165` |",
     "| **VRN2_HandleAll_v0114.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0114** | `vrn2_release_v0166` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0122 · auto:收據 < v0166 → 整輪)|\n"
     "| **VRN2_RoundAll_v0122.py**(發行夾 · 一支入口 · 不在套件內)| **v0122** | `vrn2_release_v0166` | `%s` | **新**(套件 v0166 · ③ 自測跑管理器 v0258 · 缺項提示:先上傳原 PDF 給 AI 對 · 自測 87 項)|\n"
     "| **VRN2_Closeout_v0166.zip**(發行夾 · 套件)| **v0166** | `vrn2_release_v0166` | `%s` | **新**(啟動器 v0166 · runtime v0158 · 管理器 v0258)|\n"
     "| **VRN2_HandleAll_v0113.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0113** | `vrn2_release_v0165` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0121.py**(發行夾 · 一支入口 · 不在套件內)| **v0121** | `vrn2_release_v0165` | `%s` | **新**(" % r165["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0121.py**(發行夾 · 一支入口 · 不在套件內)| **v0121** | `vrn2_release_v0165` | `%s` | 被 v0122 取代(套件 v0164 → v0166)· (" % r165["roundall"]["sha256"][:12])
once("| ActivateVRN-2_v0164.py(套件 · 底座 v0136 · runtime v0157)| **v0164** |",
     "| ActivateVRN-2_v0166.py(套件 · 底座 v0136 · runtime v0158 · 版號跳過 v0165)| **v0166** | 見發行清單 | `%s` | **新**(管理器 v0258 · 收據 v0166 · 自測多一段 v0166)|\n"
     "| VRN2_Runtime_v0158.zip(套件 · runtime)| **v0158** | 套件內 | `%s` | **新**(v0157 的 196 個成員不動 + VRN_SystemManager_v0258)|\n"
     "| VRN_SystemManager_v0258.py(runtime · 薄尾 v0257)| **v0258** | runtime v0158 | 見 runtime 清單 | **新**(輸出冊前表格修補:科目半行配對 · 兩層期間表頭重排 · 都要第二讀取器確認 · 放不進去的列進剔除冊)|\n"
     "| ActivateVRN-2_v0164.py(套件 · 底座 v0136 · runtime v0157)| **v0164** |" % (R["launcher"]["sha256"][:12], R["runtime"]["zip_sha256"][:12]))
once("| 0 | **(v0165)**",
     "| 0 | **(v0166)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"` 再貼 `vrn2_release_v0166/VRN2_HandleAll_v0114.md` 的 cmd 一行 → auto 選整輪(輸出冊由 v0258 重做 · 約 40 分鐘)· "
     "收尾頁「輸出冊缺項」應只剩華南 6143(若原文有年度表 → 上傳原文)· MQ-1560 四點看過原圖後操作員自己打 `--confirm H-…`(AI 不代打)· 上傳貼回包 | 貼回 / 人工 |\n"
     "| 0 | **(v0165)**")
once("**v0165(2026-11-01)**:", "**v0166(2026-11-01)**:操作員上傳原文 → 欣銓 3264 / Daiwa-6278 年度表是擷取後漏掉 → 管理器 v0258(輸出冊前表格修補)· 套件 v0166(啟動器 v0166 · runtime v0158)· RoundAll v0122 · Handle-All v0114。\n\n**v0165(2026-11-01)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0166)** **「原文沒有」要看原文才能下**:本機 `local1028/samples52` 是約 20 KB 的合成替身,不能拿來判斷操作員的原文有沒有年度表。缺項先請操作員上傳原 PDF;"
     "有年度表 = 擷取漏(要修)。欣銓 3264 / Daiwa-6278 就是這樣(v0165 以前的結論已更正)。\n"
     "- **(v0166)** **表格修補只在第二讀取器確認時才動**:管理器 v0258 修的是擷取結果的副本(P1VIEW 不動);配不上 / 放不進去的照舊不輸出(重排放不進去的列進剔除冊 · 帶理由)。"
     "新版面要擴規則時,同樣先找第二讀取器的唯一證據,不猜。\n\n")
(REPO / "VRN2_Handover_v0167.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0166"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0166.zip", "VRN2_RoundAll_v0122.py", "VRN2_RoundAll_v0122.md", "VRN2_HandleAll_v0114.md", "VRN2_HandleAll_v0114_boot.txt", "VRN2_Release_v0166.json", "VRN2_Verification_v0166.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t166a"), "<sbx>"), (str(W / "t166b"), "<sbx-b>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0166.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mgr258_selftest.log", "launcher166_selftest.log", "rall122_selftest_venv.log", "pscheck166.log", "tiny166.rc", "tiny166b.rc", "seed166.log",
                              "originals_verify.log", "regression_verify.log", "regression_repair.log", "confirm_list.log")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0166.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("runtime158.py", "mk_launcher166.py", "mk_roundall122.py", "build166.py", "finalize166.py", "e2e166.sh", "e2e166b.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0167", src.count("\n"))
