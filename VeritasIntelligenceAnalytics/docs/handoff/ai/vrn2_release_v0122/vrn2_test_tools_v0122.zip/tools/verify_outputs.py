"""VRN-2 輸出值獨立驗證(不 import 任何 VRN-2 程式 · 讀法 = pypdfium2 字元框 · 與擷取用的 pdfplumber 不同讀取器)。

用法:python verify_outputs.py <output 夾> <PDF 夾> <報告 .json>
  基本資料:每欄值必須在 PDF 原文找得到(或可由原文重算)· 推算值要標推算
  年度數據:每筆 VALUE 必須在該頁 · 同列有 ITEM · 數值落在 PERIOD 表頭那一欄(x 對齊)
"""
import json
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

import pypdfium2 as pdfium


def nfk(t):
    return unicodedata.normalize("NFKC", t or "")


def squash(t):
    return re.sub(r"\s+", "", nfk(t)).lower()


_PAGES = {}


def page_lines(pdf, pno):
    """回 [(y, [(x0, x1, token)])] · 依字元框分列分詞(列 = 字元垂直中心差 < 0.5 字高)。"""
    key = (str(pdf), pno)
    if key in _PAGES:
        return _PAGES[key]
    doc = pdfium.PdfDocument(str(pdf))
    out = []
    if 1 <= pno <= len(doc):
        tp = doc[pno - 1].get_textpage()
        chars = []
        for i in range(tp.count_chars()):
            ch = tp.get_text_range(i, 1)
            l, b, r, t = tp.get_charbox(i, loose=True)
            if ch in ("\r", "\n") or r <= l:
                chars.append(None)
                continue
            chars.append((ch, l, b, r, t))
        rows = []
        for c in chars:
            if c is None:
                continue
            ch, l, b, r, t = c
            yc, h = (b + t) / 2, max(t - b, 1.0)
            row = next((rw for rw in rows if abs(rw[0] - yc) < 0.5 * max(h, rw[1])), None)
            if row is None:
                row = [yc, h, []]
                rows.append(row)
            row[2].append((l, r, ch, h))
        for yc, h, cs in rows:
            cs.sort(key=lambda x: x[0])
            toks, cur = [], None
            for l, r, ch, hh in cs:
                if ch.isspace():
                    cur = None
                    continue
                if cur is not None and l - cur[1] <= 0.25 * hh:
                    cur[1], cur[2] = r, cur[2] + ch
                else:
                    cur = [l, r, ch]
                    toks.append(cur)
            out.append((yc, [(a, b_, nfk(s)) for a, b_, s in toks]))
        out.sort(key=lambda x: -x[0])
    doc.close()
    _PAGES[key] = out
    return out


def page_text(pdf, pno):
    return "\n".join(" ".join(t for _, _, t in toks) for _, toks in page_lines(pdf, pno))


def all_text(pdf, pages=(1, 2, 3, 4, 5, 6, 7, 8)):
    """兩個讀取器聯集(pypdfium2 字元框 + pdfplumber 文字層)· 去掉字母間的字型雜訊 %(To%mmy → Tommy)。"""
    import pdfplumber
    t = [page_text(pdf, p) for p in pages]
    try:
        with pdfplumber.open(str(pdf)) as d:
            t += [(d.pages[p - 1].extract_text() or "") for p in pages if p <= len(d.pages)]
    except Exception:  # noqa: BLE001
        pass
    return re.sub(r"(?<=[A-Za-z\u4e00-\u9fff])%(?=[A-Za-z\u4e00-\u9fff])", "", nfk("\n".join(t)))


def num_in(v, text):
    v = nfk(v).strip()
    if not v:
        return True
    pat = r"(?<![\d.,])" + re.escape(v) + r"(?![\d])"
    if re.search(pat, text):
        return True
    return re.search(pat, re.sub(r"(?<=\d)\s+(?=[\d,.])", "", text)) is not None   # 原文字距拆開的數字


def verify_fin(rows, pdfdir):
    res = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        lines = page_lines(pdf, int(x["PAGE"]))
        item, per, val = nfk(x["ITEM"]).strip(), nfk(x["PERIOD"]).strip(), nfk(x["VALUE"]).strip()
        sv = squash(val)
        # 1) 值在該頁
        ptxt = "\n".join(" ".join(t for _, _, t in tk) for _, tk in lines)
        present = num_in(val, ptxt) or sv in squash(ptxt)
        # 2) 科目那一列(科目前 14 字壓縮比對 · 允許科目折行:取科目起點所在列與下一列)
        key = squash(item)[:14]
        cand = []
        for k, (y, tk) in enumerate(lines):
            lt = squash("".join(t for _, _, t in tk))
            if key and key in lt:
                cand.append(k)
        # 3) 表頭期間欄 x(取在科目列上方、最近的那一個表頭)
        verdict, note = ("PRESENT" if present else "FAIL"), ""
        kind = "NUM" if re.search(r"\d", val) else ("NIL" if re.fullmatch(r"(?i)[-–—]+|n\.?a\.?|nm|n/?m|n/?a|na|nil|neg\.?|ns|--", val) else "TEXT")
        best = None
        for k in cand:
            y = lines[k][0]
            row_toks = [tt for kk in (k, k + 1) if kk < len(lines) and abs(lines[kk][0] - y) < 14 for tt in lines[kk][1]]
            hits = [((a + b) / 2, a, b, t) for a, b, t in row_toks if squash(t) == sv or squash(t) == sv.replace(",", "")]
            if not hits:
                continue
            for yy, tk in lines:                                 # 每個在上方、同期間字樣的表頭都試 · 取 x 最近(並排表各自的表頭)
                if not (y - 1 < yy < y + 520):
                    continue
                for a, b, t in tk:
                    if t != per:
                        continue
                    hx = (a + b) / 2
                    colw = min([abs((aa + bb) / 2 - hx) for aa, bb, tt in tk if tt != per and re.match(r"^(?:FY)?\d{2,4}[AEFP]?$|^\d{1,2}/\d{2}[AEFe]?$|^[A-Z][a-z]{2}-\d{2}[AEF]$", tt)] + [60])
                    for vx, va, vb, vt in hits:
                        dx = abs(vx - hx)
                        if best is None or dx < best[0]:
                            best = (dx, colw, hx, vx, b - a, yy)
        if best:
            dx, colw, hx, vx, hw, hy = best
            if dx <= max(0.55 * colw, hw * 0.9, 12):
                verdict, note = "ALIGNED", "dx %.1f · 欄寬 %.0f" % (dx, colw)
            else:
                verdict, note = "MISALIGNED", "值 x %.0f · 表頭 %s x %.0f · dx %.1f · 欄寬 %.0f" % (vx, per, hx, dx, colw)
        if kind == "TEXT" and not re.fullmatch(r"(?i)net\s*cash|淨現金", val):
            verdict, note = "BADVALUE", "VALUE 不是數字 / 空值記號(科目或底線混進數值欄)· " + note
        elif len([t for t in val.split() if re.search(r"\d", t) or re.fullmatch(r"(?i)[-–—]+|n\.?a\.?|n/a|nm|n\.m\.|nil", t)]) >= 2:
            verdict, note = "BADVALUE", "一格多值 · %s" % note
        si = squash(item)
        rows_sq = [squash("".join(t for _, _, t in tk)) for _, tk in lines]
        wrapped = any(si[:k] in rows_sq[i] and si[k:] in "".join(rows_sq[i + 1:i + 3]) for i in range(len(rows_sq)) for k in range(6, len(si) - 2))   # 科目折行
        if verdict in ("ALIGNED", "PRESENT") and si not in squash(ptxt) and not wrapped:
            verdict, note = "BADITEM", "科目 %r 本頁原文沒有 · %s" % (item, note)
        res.append(dict(x, _V=verdict, _N=note))
    return res


_BROKER = [(r"(?i)^CLST|clsa|cl-sec", "CLSA"), (r"(?i)^Citi|citi\.com", "Citi"), (r"(?i)^Daiwa|daiwa", "Daiwa"), (r"(?i)^GS-|gs\.com", "Goldman Sachs"),
           (r"(?i)^JP-|jpmorgan", "J.P. Morgan"), (r"(?i)^MQ-|macquarie", "Macquarie"), (r"(?i)^MS-|morganstanley", "Morgan Stanley"),
           (r"凱基|KGI", "凱基"), (r"中信|CTBC", "中信"), (r"華南", "華南"), (r"兆豐", "兆豐"), (r"台新", "台新")]


def verify_basic(rows, pdfdir):
    out = []
    for x in rows:
        pdf = Path(pdfdir) / x["FILENAME"]
        t1 = all_text(pdf, (1,))
        ta = all_text(pdf)
        st = x.get("_STATUS") or {}
        chk = {}
        def put(k, ok, why=""):
            chk[k] = ("PASS" if ok else "FAIL") + ((" · " + why) if why else "")
        f = x["FILENAME"]
        tk = x.get("TICKER", "")
        put("TICKER", bool(tk) and (tk in f or tk in t1), "檔名或首頁")
        d = x.get("REPORT_DATE", "")
        if d:
            y, m, dd = d.split("-")
            roc = "%d%s%s" % (int(y) - 1911, m, dd)
            put("REPORT_DATE", (y + m + dd) in f or roc in f or (y[2:] + m + dd) in f or any(s in t1 for s in (d, "%s/%s/%s" % (y, m, dd), "%s年%d月%d日" % (y, int(m), int(dd)))), "檔名 / 首頁")
        for k in ("YFINANCE_TICKER", "ENGLISH_NAME", "TITLE", "RATING"):
            v = nfk(x.get(k, "")).strip()
            if v:
                put(k, squash(v) in squash(t1) or squash(v) in squash(ta), "原文")
        v = x.get("BLOOMBERG_TICKER", "")
        if v:
            put("BLOOMBERG_TICKER", squash(v) in squash(ta) or st.get("BLOOMBERG_TICKER", "").startswith("推算"), "原文或標推算")
        if x.get("NAME"):
            put("NAME", x["NAME"] in f or x["NAME"] in ta, "檔名 / 原文")
        for e in [e for e in (x.get("EMAIL") or "").split("、") if e]:
            put("EMAIL:" + e, e.lower() in re.sub(r"\s+", "", nfk(ta)).lower(), "原文")
        tel = x.get("TEL", "")
        if tel:
            digits = re.sub(r"\D", "", tel)
            put("TEL", len(digits) >= 8 and digits[-8:] in re.sub(r"\D", "", ta), "原文數字")
        for nm in [a for a in (x.get("ANALYST") or "").split("、") if a]:
            put("ANALYST:" + nm, squash(nm) in squash(ta) and not re.search(r"信箱|電話|郵件|傳真|地址|研究員|分析師|聯絡|日期", nm), "原文(姓名照原文印 · 不是欄位標籤)")
        b = x.get("BROKER", "")
        if b:
            exp = next((name for rx, name in _BROKER if re.search(rx, f) or re.search(rx, x.get("EMAIL", ""))), None)
            put("BROKER", exp is None or squash(exp)[:4] in squash(b) or squash(b)[:4] in squash(exp), "檔名 / 網域 → %s" % exp)
        for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
            v = x.get(k, "")
            if v:
                put(k, num_in(v, ta), "原文")
        up = x.get("UPSIDE_PCT", "")
        if up:
            if (st.get("UPSIDE_PCT") or "").startswith("計算"):
                try:
                    calc = (float(x["TARGET_PRICE"].replace(",", "")) / float(x["CURRENT_PRICE_REPORT"].replace(",", "")) - 1) * 100
                    put("UPSIDE_PCT", abs(calc - float(up)) < 0.06, "重算 %.2f" % calc)
                except (ValueError, ZeroDivisionError, KeyError):
                    put("UPSIDE_PCT", False, "無法重算")
            else:
                put("UPSIDE_PCT", num_in(up, ta) or num_in(up.lstrip("+"), ta), "原文")
        out.append({"FILENAME": f, "checks": chk})
    return out


def main(od, pdfdir, rep):
    od = Path(od)
    basic = json.loads((od / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
    fin = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
    vb = verify_basic(basic, pdfdir)
    vf = verify_fin(fin, pdfdir)
    bc = Counter(v.split(" ·")[0] for r in vb for v in r["checks"].values())
    fc = Counter(r["_V"] for r in vf)
    per_file = defaultdict(Counter)
    for r in vf:
        per_file[r["FILENAME"]][r["_V"]] += 1
    Path(rep).write_text(json.dumps({"basic": vb, "fin_counts": dict(fc), "fin_per_file": {k: dict(v) for k, v in per_file.items()},
                                     "fin_bad": [r for r in vf if r["_V"] in ("FAIL", "MISALIGNED", "BADVALUE", "BADITEM")]}, ensure_ascii=False, indent=1), encoding="utf-8")
    print("[驗證] 基本資料 %d 份 · 欄位檢查 %s" % (len(vb), dict(bc)))
    for r in vb:
        bad = {k: v for k, v in r["checks"].items() if v.startswith("FAIL")}
        if bad:
            print("  [FAIL] %s · %s" % (r["FILENAME"][:40], " | ".join("%s %s" % kv for kv in bad.items())[:300]))
    print("[驗證] 年度數據 %d 筆 · %s" % (len(vf), dict(fc)))
    for f, c in sorted(per_file.items()):
        print("  %-46s %s" % (f[:46], dict(c)))
    return 0 if not any(v.startswith("FAIL") for r in vb for v in r["checks"].values()) and not fc.get("FAIL") and not fc.get("MISALIGNED") and not fc.get("BADVALUE") and not fc.get("BADITEM") else 1


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
