#!/bin/bash
# 使用者機器情境(一鍵 v0148):Downloads 沒有套件 · 發行 v0148 放在假 GitHub 分支 · 貼「一行」(-EncodedCommand)→ ③ 下載套件 · 雜湊 + 逐檔核對 · ④ 跑 ActivateVRN-2_v0148 · ⑤ 摘要 · 再貼一次(本機已是 v0148)
S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v148; T=$W/t148oc
OCRPY=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/bin/python
REL=$W/release148
bash /tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v142/mktree142.sh $T $W/pkg148 "$S2/shipF/samples" > $W/scen148_setup.log 2>&1 || { cat $W/scen148_setup.log; exit 1; }
rm -rf $T/pkg   # 情境:本機沒有套件(要從 GitHub 取)
cp "/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules/"SUP_MDL737_SuperAccelModule_v*.py "$T/VIA/supportive modules/"; cd "$T/VIA" && git add -A >/dev/null 2>&1 && git commit -qm superaccel >/dev/null 2>&1; git push -q origin main 2>/dev/null
B=$T.br; rm -rf $B; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0148; mkdir -p $D
cp $REL/VRN2_Closeout_v0148.zip $REL/VRN2_Release_v0148.json $REL/VRN2_OneClick_v0148.md $D/
cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1
B64=$(cut -d' ' -f6 $REL/oneline148.txt)
run() {  # $1 = 名稱
  cd "$T/Downloads" && env HOME="$T/home" USERPROFILE="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VRN2_SOURCE="$T/samples" VIA_ENVS_HOME="$T/envs" VIA_TOOLS_ROOT="$T/VIA" \
    VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 \
    VRN2_ROOT="$T/VIA" VRN2_PACKAGE="$T/Downloads/VRN2_Closeout_v0148" VRN2_PY="$S2/venv_vrn2/bin/python" VRN2_LAUNCHER_ARGS="--no-install" VRN2_NO_UI=1 VRN2_OUTPUT_DIR="$T/OneDrive/VRN2_out" \
    timeout 3500 "$S2/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -EncodedCommand "$B64" > $W/scen148_$1.log 2>&1
  echo "$1 rc $?" >> $W/scen148.rc
  sed -i 's/\x1b\[[0-9;]*m//g' $W/scen148_$1.log
}
: > $W/scen148.rc
run first
cp "$T/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $W/ui148_oc_first.html 2>/dev/null
run again
printf "\n# tampered\n" >> "$T/Downloads/VRN2_Closeout_v0148/ActivateVRN-2_v0148.py"
run tamper
echo done >> $W/scen148.rc
