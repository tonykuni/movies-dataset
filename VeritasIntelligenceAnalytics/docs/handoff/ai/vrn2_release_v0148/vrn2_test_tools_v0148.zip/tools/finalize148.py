"""收尾 v0148:results → VRN2_Release_v0148.json.results · VRN2_Verification_v0148.md(套件 zip 已定,不重算)。"""
import glob, json, re, zipfile
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v148")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def lines(p):
    try: return [l for l in Path(p).read_text(encoding="utf-8", errors="replace").splitlines() if "<Objs" not in l and "</S>" not in l and "<S N=" not in l]
    except OSError: return []
def grep(p, pat, all_=False):
    hits = [l for l in lines(p) if re.search(pat, l)]
    return hits if all_ else (hits[-1] if hits else "")
def esc(x): return str(x).replace("|", "\\|")
v2 = W / "t148/VIA/VIA_Reports/vrn2"
ra1 = W / "ra148_first.log"; ra2 = W / "ra148_fix.log"
top = lambda p: [l for l in lines(p) if re.match(r"^\[(GREEN|YELLOW|RED|GRAY)\] |^NEXT:|^總表", l)]
first_rows, fix_rows = top(ra1), top(ra2)
def count(rows):
    c = {k: sum(1 for l in rows if l.startswith("[%s]" % k)) for k in ("GREEN", "YELLOW", "RED", "GRAY")}
    return c
reds1 = [l[:200] for l in first_rows if l.startswith("[RED]")]
st = j(v2 / "VRN2_OutputStore_latest.json", {}) or {}; hist = j(v2 / "VRN2_HistoryAlign_latest.json", {}) or {}; integ = j(v2 / "VRN2_Integrate_latest.json", {}) or {}
comb = j(v2 / "output/VRN2_Combined_latest.json", []) or []; cl = j(v2 / "VRN2_Closeout_v0148.json", {}) or {}
zips = sorted(glob.glob(str(W / "t148/Downloads/VRN2_PasteBack_*.zip")))
pz = zipfile.ZipFile(zips[-1]).namelist() if zips else []
selft = {n: grep(W / f, r"--selftest · .*不過 0|\[PASS\] v0148") [:200] for n, f in (("VRN2_RoundAll_v0101", "roundall101_selftest.log"), ("VRN2_UIAction_v0110(殼有 VIA_ROOT)", "VRN2_UIAction_v0110_selftest_with_VIA_ROOT.log"), ("VRN2_ConsensusJoin_v0101", "VRN2_ConsensusJoin_v0101_selftest.log"), ("VRN2_HistoryAlign_v0102", "VRN2_HistoryAlign_v0102_selftest.log"), ("ActivateVRN-2_v0148(建置夾)", "ActivateVRN-2_v0148_selftest.log"), ("ActivateVRN-2_v0148(真套件 zip 解到隔離夾 · VRN2_OUTPUT_DIR / VIA_ROOT 已設)", "ActivateVRN-2_v0148_selftest_iso.log"))}
repro = {"UIAction v0109 · 殼有 VIA_ROOT(重現桌機 ③ 紅)": grep(W / "VRN2_UIAction_v0109_selftest_with_VIA_ROOT.log", r"^\[FAIL\] ④")[:200] + " / " + grep(W / "VRN2_UIAction_v0109_selftest_with_VIA_ROOT.log", r"--selftest · ")[:120],
         "UIAction v0110 · 同條件": grep(W / "VRN2_UIAction_v0110_selftest_with_VIA_ROOT.log", r"--selftest · ")[:160],
         "共識引擎原本 vs v0101(上櫃 .TWO)": grep(W / "VRN2_ConsensusJoin_v0101_selftest.log", r"⑨ 引擎原本")[:200],
         "同日快取用錯尾碼 → 重抓": grep(W / "VRN2_ConsensusJoin_v0101_selftest.log", r"⑪ 同日續跑")[:200],
         "歷史對齊 v0101 vs v0102(同一份資料)": " → ".join("%s:%s" % (k, v.get("why", "")) for k, v in (j(W / "cmp_hist148.json", {}) or {}).items())[:400],
         "端到端:退役環境略過": grep(ra1, r"擷取 Python 不用退役")[:200],
         "端到端:殼有 VIA_ROOT 時處理器自測": grep(ra1, r"③ 自測 · VRN2_UIAction_v0110")[:200]}
c1, c2 = count(first_rows), count(fix_rows)
st_rows = [l for l in first_rows if "③ 自測 ·" in l]; st_green = sum(1 for l in st_rows if l.startswith("[GREEN]"))
red_names = sorted({re.sub(r"^\[RED\] ", "", l).split(" · ")[0] for l in reds1})
skipped = [Path(str(s_.get("path", ""))).name for s_ in (integ.get("skipped") or [])]
e2e = {"summary": "RoundAll 全流程 %s(綠 %d · 黃 %d · 紅 %d · 灰 %d)· ③ 自測 %d 支 · 綠 %d · 紅的步驟:%s · Combined %d 列 · 整合 %s(套用 %d · 略過 %s)"
              % (re.sub(r" · 貼回包 .*", "", grep(ra1, r"^NEXT:")), c1["GREEN"], c1["YELLOW"], c1["RED"], c1["GRAY"], len(st_rows), st_green, " / ".join(red_names) or "無", len(comb),
                 integ.get("state"), len(integ.get("applied") or []), "、".join(skipped) or "無"), "reds": reds1, "rows": first_rows}
fix = {"summary": "只修回合 %s(綠 %d · 黃 %d · 紅 %d):⑤ 計畫 %s · 歷史對齊 %s · 長線庫 %s(Combined 值變了的列另存一版,舊版留著)"
              % (re.sub(r" · 貼回包 .*", "", grep(ra2, r"^NEXT:")), c2["GREEN"], c2["YELLOW"], c2["RED"], grep(ra2, r"⑤ 自動修計畫")[len("[計] ⑤ 自動修計畫:"):][:200], str(hist.get("why", ""))[:160], json.dumps(st.get("totals") or {}, ensure_ascii=False)), "rows": fix_rows}
R = {"selftests": selft, "pwsh_hash_chain": [l for l in lines(W / "pscheck148.log") if l.strip()],
     "roundall_e2e": e2e, "roundall_fix_pass": fix,
     "store_after_fix": {k: st.get(k) for k in ("lamp", "store_engine", "appended", "backfilled", "totals")}, "history_after_fix": {k: hist.get(k) for k in ("lamp", "why", "totals")},
     "integrate": {"state": integ.get("state"), "applied": len(integ.get("applied") or []), "skipped": [(Path(str(s.get("path", ""))).name, s.get("why")) for s in integ.get("skipped") or []]},
     "combined_first_row": {k: (comb[0].get(k) if comb else None) for k in ("FILENAME", "TARGET_PRICE", "TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN", "2026_DILUTED_EPS_FACTSET", "2026_PER_FACTSET", "UPSIDE_PCT(ADJ)")},
     "receipt_roundall": cl.get("roundall"), "desktop_reproduction": repro, "pasteback_zip": {"name": Path(zips[-1]).name if zips else None, "members": len(pz), "has": [m for m in pz if m.endswith(("transcript.txt", "VRN2_RoundAll_latest.json", "VRN2_Closeout_v0148.before_roundall.json", "VRN2_FinancialAligned_latest.csv", "VRN2_Deleted_latest.csv"))]},
     "oneclick_scenario_pwsh": {"rc": (W / "scen148.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen148.rc").exists() else "not run",
                                "first": grep(W / "scen148_first.log", r"③ 套件 v0148 就位|③ 本機已是 v0148")[:200], "again": grep(W / "scen148_again.log", r"③ 本機已是 v0148")[:200],
                                "tamper": grep(W / "scen148_tamper.log", r"③ 舊套件夾已改名備份")[:160], "closeout": grep(W / "scen148_first.log", r"⑧b 收尾收據 v0148")[:200], "roundall_hint": grep(W / "scen148_first.log", r"VRN2_RoundAll_v0101")[:160]},
     "not_claimed": ["Windows desktop run of v0148 / RoundAll v0101: not yet (next paste-back)",
                     "3014TT POINT_3 FAIL (the reason for closeout rc 1 on the desktop): the container only has a synthetic copy of the PDF — needs the paste-back zip",
                     "MS-3661 / MS-6669 / MS-8358 / MS-8210 CURRENT_PRICE / UPSIDE FAIL on the desktop: the same MS-3661 PDF passes when extracted fresh in the container (3190 / 4388 / 38); the desktop reused cached extraction 52/52 — needs the paste-back zip",
                     "⑥e VDF_TW_AllInOne_v039 fatal errors on the desktop: VDF's own engine (bootstraps via_tw_fetch with pip); reason only in market/vdf/last_error.txt of the paste-back zip; VRN-2 does not modify VDF files",
                     "⑥f live cnyes / Yahoo: no network here; the .TWO fix is proven on the engine's own ticker function and offline fixtures, not on live Yahoo",
                     "Windows-only paths (os.startfile, winreg vrn2:// lookup, ctypes PID check) are exercised by code review and the posix equivalents only"]}
rel_p = W / "release148/VRN2_Release_v0148.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
md = ["# VRN-2 v0148 + VRN2_RoundAll_v0101 容器實測紀錄(2026-10-29)", "",
      "桌機 2026-10-29 14:40 第一次跑 VRN2_RoundAll_v0100 的貼回(52 份 · 2069 秒 · 紅 4 黃 10)→ 能在容器重現 / 驗證的修成 v0148(見發行清單 `fixes` · `not_fixed_here`)。", "",
      "## 0. 桌機問題在容器重現 / 驗證", "", "| 項目 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有)") for k, v in repro.items()] + ["",
      "## 1. 自測", "", "| 檔 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有 PASS 行)") for k, v in selft.items()] + ["",
      "## 2. PowerShell 雜湊鏈(pwsh 7.4.6)", "", "```", *R["pwsh_hash_chain"], "```", "",
      "## 3. 端到端:RoundAll v0101 在仿桌機沙盒(殼有 VIA_ROOT · envs 有退役環境 · 套件從假 GitHub 分支取 · 共用 MarketFetch 在、沒 yfinance · 輸出夾在 OneDrive · 舊 Google Sheet CSV + 家用記帳 CSV · 19 份真實樣本)", "",
      e2e["summary"], "", "```", *[l[:260] for l in first_rows], "```", "",
      "## 4. 只修回合(`--skip-package --skip-selftest --skip-run`,先放一份合成的市場資料)", "", fix["summary"], "", "```", *[l[:260] for l in fix_rows], "```", "",
      "| 項目 | 值 |", "|---|---|", "| 長線庫(修後)| %s |" % esc(json.dumps(R["store_after_fix"], ensure_ascii=False)), "| 歷史對齊(修後)| %s |" % esc(json.dumps(R["history_after_fix"], ensure_ascii=False)[:600]),
      "| 舊資料庫整合 | %s |" % esc(json.dumps(R["integrate"], ensure_ascii=False)), "| Combined 第一列 | %s |" % esc(json.dumps(R["combined_first_row"], ensure_ascii=False)),
      "| 收尾收據的 roundall 欄 | %s |" % esc(json.dumps(R["receipt_roundall"], ensure_ascii=False)[:500]), "| 貼回包 | %s |" % esc(json.dumps(R["pasteback_zip"], ensure_ascii=False)), "",
      "## 5. 一鍵 v0148 使用者情境(pwsh · 假 GitHub 分支 → 跑 → 再貼 → 竄改)", "", "| 項目 | 值 |", "|---|---|"] + ["| %s | %s |" % (k, esc(v)) for k, v in R["oneclick_scenario_pwsh"].items()] + ["",
      "## 6. 沒做到 / 沒驗到(照實)", ""] + ["- %s" % x for x in R["not_claimed"]]
(W / "release148/VRN2_Verification_v0148.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
print("finalize148 ok ·", e2e["summary"][:120], "·", fix["summary"][:120])
