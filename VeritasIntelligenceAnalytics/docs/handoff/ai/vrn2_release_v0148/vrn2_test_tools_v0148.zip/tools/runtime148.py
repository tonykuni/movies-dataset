import hashlib, json, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); old, new, out = S / "v147/pkg147", S / "v148/new", S / "v148/pkg148"
out.mkdir(parents=True, exist_ok=True)
om = json.loads((old / "VRN2_Runtime_v0147.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
with zipfile.ZipFile(old / "VRN2_Runtime_v0147.zip") as z: members = {n: z.read(n) for n in old_names}
for e in om["files"]: assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"]
new_names = ["VRN2_UIAction_v0110.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_HistoryAlign_v0102.py"]
for n in new_names: assert n not in members, n; members[n] = (new / n).read_bytes()
for n, src in (("VRN2_UIAction_v0109.py", S / "v146/new"), ("VRN2_ConsensusJoin_v0100.py", S / "v146/new"), ("VRN2_HistoryAlign_v0101.py", S / "v147/new"), ("VRN2_HistoryAlign_v0100.py", S / "v146/new"), ("VRN2_UIAction_v0108.py", S / "v146/new")):
    assert members[n] == (src / n).read_bytes(), n   # 前版逐位元相同(薄尾在建置樹測過的就是 runtime 裡的那一支)
names = sorted(members); zp = out / "VRN2_Runtime_v0148.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0148", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0147.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names, "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0148.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(str(old / n), str(out / n))
shutil.copy2(str(new / "ActivateVRN-2_v0148.py"), str(out / "ActivateVRN-2_v0148.py"))
print("runtime v0148", len(names), man["zip_sha256"][:12], "· pkg148", sorted(p.name for p in out.iterdir()))
