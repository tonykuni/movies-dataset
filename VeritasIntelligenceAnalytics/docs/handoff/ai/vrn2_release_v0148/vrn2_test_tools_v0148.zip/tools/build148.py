"""v0148 整包重建(冪等):pkg148 → 套件 zip → VRN2_RoundAll_v0101.py(填套件雜湊)+ 一行啟動 md → 發行清單 → 一鍵 v0148 md → 操作員 v0109 md → 本地實測一輪改指。"""
import base64, hashlib, json, re, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); out, rel, op9, new = S / "v148/pkg148", S / "v148/release148", S / "v148/operator109", S / "v148/new"
rel.mkdir(exist_ok=True); op9.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
rt = json.loads((out / "VRN2_Runtime_v0148.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN2_UIAction_v0110.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_HistoryAlign_v0102.py"]
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0148.py", "VRN2_Runtime_v0148.zip", "VRN2_Runtime_v0148.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0148 — VRN-2 closeout package (2026-10-29)\n\nEntry: python ActivateVRN-2_v0148.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0101.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.\n"
  "Runtime: VRN2_Runtime_v0148.zip = runtime v0147 (178 members byte-identical) + VRN2_UIAction_v0110 + VRN2_ConsensusJoin_v0101 + VRN2_HistoryAlign_v0102,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0148 (first desktop run of VRN2_RoundAll_v0100 · 2026-10-29 14:40 · red 4 · yellow 10):\n"
  " - ⑥c / ⑫b handler UIAction v0110: --selftest clears VIA_ROOT / VRN2_* while testing (v0109's ④ failed on the desktop because the shell has VIA_ROOT).\n"
  " - ⑥f ConsensusJoin v0101: TPEx stocks use .TWO on Yahoo (cnyes answers TWS:#### for TPEx too → the engine asked Yahoo for ####.TW → 404 for 5274 / 5904 / 8358 /\n"
  "   4966 / 7728 / 6147 / 3264 / 6143). Code → ticker map from the market book; the bundled engine is unchanged and runs through a shim; stale same-day payloads re-fetched.\n"
  " - ⑬b HistoryAlign v0102: item mapping ignores other / segment / payable / liabilities / minority / adjusted / core rows; checks take |COGS|, accept ROE on average\n"
  "   equity, use the value that recurs across a report's tables, and mark basis mismatches UNCLEAR instead of FAIL.\n"
  "Verification: see VRN2_Verification_v0148.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0148.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0148", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0148.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0148/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll v0101:填套件雜湊 · 一行啟動 · md =====
ra_src = (new / "VRN2_RoundAll_v0101.py").read_text(encoding="utf-8")
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0101.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
boot0 = (S / "v147/release147/boot_roundall.ps1").read_text(encoding="utf-8")
ra_boot = boot0.replace("vrn2_release_v0147", "vrn2_release_v0148").replace("VRN2_RoundAll_v0100.py", "VRN2_RoundAll_v0101.py")
ra_boot = re.sub(r"\$H  = '[0-9a-f]{64}'", "$H  = '%s'" % ra_sha, ra_boot, count=1)
assert ra_sha in ra_boot and "v0147" not in ra_boot and "v0100" not in ra_boot
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii"); assert len(ra_one) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0101.py(取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯報告 → 貼回包)

`VRN2_RoundAll_v0101.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪;套件 = `VRN2_Closeout_v0148.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。
v0101 = v0100 + 桌機 2026-10-29 14:40 第一次跑 v0100 的貼回修正(紅 4 · 黃 10):

| 桌機看到的 | 根因 | v0148 / v0101 怎麼修 |
|---|---|---|
| ③ `VRN2_UIAction_v0109.py --selftest` ④ FAIL(容器裡過)| 你的殼有 `VIA_ROOT`,處理器的「重渲染」就去讀它 → 自測真的重渲染了桌機的 Workbench,對不上「沒有 VIA 根」的預期 | 處理器 **v0110**:自測先拿掉 VIA_ROOT / VRN2_* 再跑、結束還原;動作照 v0109 |
| ⑥f 8 檔 Yahoo 404「####.TW」(5274 · 5904 · 8358 · 4966 · 7728 · 6147 · 3264 · 6143)· gate FAIL_CLOSED | 鉅亨對上櫃股也回 `TWS:####` → 共識引擎一律組 `.TW`;這 8 檔是上櫃,Yahoo 要 `.TWO` | **ConsensusJoin v0101**:用 ⑥e 市場冊(VDF 身分表 TWSE .TW / TPEX .TWO)的代號對應,換掉引擎組代號那一個函式(引擎檔原樣不動);今天快取裡用錯尾碼抓的代號會重抓 |
| ② 擷取 Python = `envs\\via_core.retired-20260914_111946` | 本檔把 `envs` 下任何裝齊套件的夾都當候選 | **RoundAll v0101**:名字有 retired / backup / bak / old / deprecated / archive 的夾一律略過(照列)|
| ⑬b「檢驗 534(不過 120)」 | 科目對錯列:其他營收當總營收 · 應付所得稅當所得稅 · 負債與權益合計當權益 · 部門成長率當營收成長率 · 成本寫負數直接相減 · 預估調整表同年三個值取到舊估 | **HistoryAlign v0102**:這些列不對應(不覆蓋 · 不刪 · 不檢驗)· 成本取絕對值 · ROE 可用平均權益 · 同年同科目取報告裡重複出現的值 · 差到不像同口徑標「口徑不明」不算不過(容器資料:74 / 218 → 5 / 192,剩的 5 筆是測試故意做錯的)|
| `python "%USERPROFILE%\\Downloads\\…"` 在 PowerShell 找不到檔 | `%USERPROFILE%` 只有 cmd 認得;PowerShell 要 `$env:USERPROFILE` | 本檔跑完最後印「下次」三行,用**完整路徑**(兩種殼都能貼);下面也分開寫 |
| ⑥ 四點 FAIL / ⑥e 紅只有一行 | 證據在貼回包,主控台看不到 | 除錯報告多印:FAIL 那一點的摘錄原文 · `market\\vdf\\last_error.txt` 最後幾行 · Yahoo 404 代號與上櫃 .TWO 數 |

| 步驟 | 做什麼 | 不做什麼 |
|---|---|---|
| ⓪ VIA 根 | `--root` → `VRN2_ROOT` / `VIA_ROOT` → 本檔所在的倉 → 啟動器記的 `Downloads\\VRN2_Closeout_v0*\\VRN2_Runtime_Context.json` → vrn2:// 註冊 → `%USERPROFILE%\\OneDrive\\Documents\\movies-dataset\\VeritasIntelligenceAnalytics` | 找不到不猜:印出查過的地方 |
| ① 套件 | 本機 `Downloads\\VRN2_Closeout_v0148` 的 zip 雜湊對 + 逐檔對 → 直接用;否則 git archive 發行夾(分支 → main)→ 核對 → 解壓;本機夾有檔不對 → 整夾改名備份再解壓 | 不刪舊套件夾 |
| ② 診斷 | VRN-2 Python 的必裝套件 · 擷取 Python(`VIA_FETCH_PY` / `%USERPROFILE%\\envs\\via_tw_fetch` / 其他 envs · 退役 / 備份夾略過)的 yfinance 等 · 共用 MarketFetch / VDF 引擎 · 啟動器鎖 · 輸出夾可寫 · 來源夾 · 磁碟 · CPU · git | 不裝套件(缺的交 VCGC,照印指令)|
| ③ 自測 | runtime zip 解到 TEMP(逐檔核對)→ Workbench v0102 · HistoryAlign v0100 / v0102 · DataIntegrate v0100 / v0101 · UIAction v0110 · SSOTSync v0101 · OutputStore v0101 · ConsensusJoin v0101 · 管理器 v0255 各 `--selftest` + 啟動器 `--selftest` | 不碰真資料 |
| ④ 跑 | `ActivateVRN-2_v0148.py`(預設不上船 `VIA_VRN2_NO_PUSH=1`)· 逐行即時印 · 60 秒沒輸出印心跳 · 另一個啟動器在跑就不跑 | `--ship` 才推 |
| ⑤ 自動修 | 同 v0100(重抓 ⑥e · 重跑 ⑥f · 重跑 ⑬b · Combined 重組 · ⑬ 補寫 · Workbench 重渲染 · 舊資料庫問你 · 清過期鎖)| 收尾收據先備份成 `.before_roundall.json` 再標註;不刪任何資料 |
| ⑥ 除錯 | 每個非綠步驟 + 下一步 · 四點核對不過的點 **+ 摘錄原文** · ⑥e 錯誤最後幾行 · Yahoo 404 / 上櫃 .TWO · 缺項 · 完成判定 · 冪等閘 · 階段耗時 · Combined 欄序 / 空格 · Workbench · 市場 / 歷史 / 庫 / 整合 / SSOT → `VIA_Reports\\vrn2\\VRN2_RoundAll_latest.json` | — |
| ⑦ 貼回包 | `Downloads\\VRN2_PasteBack_<時間>.zip`(多收 `consensus\\VRN2_YFTickerMap_latest.json`)| — |

結束碼 0 綠 · 2 黃 · 1 紅;最後一行 `NEXT: [燈] …`(前面三行「下次」是完整路徑的重跑指令)。

## 在 cmd 或 PowerShell 貼這一行(建議)

它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)取 `VRN2_RoundAll_v0101.py` → **核對 SHA-256**(`@RASHA12@`)→ 存到 `Downloads` → 用你的 python 執行。
VIA 根不在預設位置就先設(cmd:`set VRN2_ROOT=…` · PowerShell:`$env:VRN2_ROOT='…'`);要帶參數就設 `VRN2_ROUNDALL_ARGS`(例:`--integrate yes --source C:\\測試樣本報告`)。

```bat
@ONE@
```

## 已經有這個檔時

在 **cmd**(提示字元 `C:\\Users\\…>`):

```bat
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0101.py"
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0101.py" --skip-run --integrate yes
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0101.py" --only preflight,selftest
```

在 **PowerShell**(提示字元 `PS C:\\Users\\…>`;`%USERPROFILE%` 在這裡不會展開):

```powershell
python "$env:USERPROFILE\\Downloads\\VRN2_RoundAll_v0101.py"
python "$env:USERPROFILE\\Downloads\\VRN2_RoundAll_v0101.py" --skip-run --integrate yes
python "$env:USERPROFILE\\Downloads\\VRN2_RoundAll_v0101.py" --only preflight,selftest
```

兩種殼都能貼的寫法:完整路徑,例 `python "C:\\Users\\<你>\\Downloads\\VRN2_RoundAll_v0101.py"`(本檔跑完最後就印這三行)。

常用參數:`--source <報告夾>` · `--integrate ask|yes|no|skip`(舊資料庫)· `--no-open` · `--ship`(允許上船)· `--offline`(不連 GitHub)· `--python <VRN-2 的 python>` · `--skip-selftest` · `--selftest`(本檔自測)。

## 一行解開來的程式碼(核對用)

```text
@BOOT@
```
"""
ra_md = ra_md.replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
(rel / "VRN2_RoundAll_v0101.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0148 + VRN2_RoundAll_v0101", "date": "2026-10-29",
        "trigger": "桌機 2026-10-29 14:40 第一次跑 VRN2_RoundAll_v0100(52 份 · 2069 秒 · 紅 4 黃 10)→ 能在容器重現 / 驗證的缺陷修成 v0148(見 fixes)",
        "base_package": {"name": "VRN2_Closeout_v0147 (launcher v0147 · runtime v0147)", "retained": "runtime v0147 members byte-identical inside runtime v0148; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0147 for the closeout entry; VRN2_RoundAll v0100 → v0101; VRN-2 one-click v0147 → v0148; operator one-click v0108 → v0109",
        "fixes": {"UIAction_v0110": "hermetic --selftest (VIA_ROOT / VRN2_* cleared and restored) — v0109 ④ failed on the desktop shell with VIA_ROOT; reproduced in the container",
                  "ConsensusJoin_v0101": "TPEx → .TWO from the market book (cnyes TWS:#### for TPEx made the engine ask Yahoo for ####.TW → 404 × 8); engine unchanged, shim swaps its ticker function; stale same-day payloads re-fetched",
                  "HistoryAlign_v0102": "strict item mapping (other / segment / payable / liabilities / minority / adjusted / core / … of …) · |COGS| · ROE average equity · recurring value across tables · UNCLEAR vs FAIL (74/218 → 5/192 failing checks on container data)",
                  "RoundAll_v0101_fetch_python": "retired / backup / bak / old / deprecated / archive env folders are never the fetch Python (desktop picked envs\\via_core.retired-20260914_111946)",
                  "RoundAll_v0101_evidence": "diagnosis prints the FAIL point's excerpt, last_error.txt tail, Yahoo 404 codes and the .TWO count",
                  "RoundAll_v0101_rerun_hint": "prints full-path rerun commands that work in cmd and PowerShell (%USERPROFILE% does not expand in PowerShell)",
                  "operator_v0109_md_history": "operator one-click v0108's md had its history paragraphs rewritten by a blanket replace in build147 (\"v0108 = v0106 + …\"); v0109 rebuilds them from v0107's md (v0108 file left as is)"},
        "not_fixed_here": {"3014TT_POINT_3": "verbatim FAIL → closeout rc 1; needs the real PDF / paste-back zip (container only has a synthetic copy)",
                           "MS_basic_fails": "MS-3661 / MS-6669 / MS-8358 / MS-8210 CURRENT_PRICE / UPSIDE FAIL on the desktop (extraction reused from cache 52/52); the same MS-3661 PDF passes fresh in the container → needs the paste-back zip",
                           "VDF_6e_fatal": "VDF_TW_AllInOne_v039 windows rc1 '致命錯' (VDF's own engine bootstrapped via_tw_fetch with pip first); reason is in market/vdf/last_error.txt of the paste-back zip — VDF files are not modified by VRN-2",
                           "annual_gaps": "Daiwa-6278 · 欣銓 3264 · 振曜 6143 annual data missing (known)"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0148.json inside the package"},
        "roundall": {"name": "VRN2_RoundAll_v0101.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0101.md"},
        "tested_in": "Linux container · python 3.13 venv_vrn2 (pyarrow · no duckdb · no yfinance) · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0148.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0148/<files> (no .ps1 · the one-click md / RoundAll py are the entries)"},
        "launcher": {"name": "ActivateVRN-2_v0148.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0148.py"]).hexdigest()},
        "oneclick": "VRN2_OneClick_v0148.md", "test_tools_zip": "vrn2_test_tools_v0148.zip", "logs_zip": "logs_v0148.zip"}
(rel / "VRN2_Release_v0148.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
# ===== one-click v0148 from v0147 =====
md = (REPO / "vrn2_release_v0147/VRN2_OneClick_v0147.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); old_cs = hashlib.sha256(ps.encode("utf-8")).hexdigest(); assert old_cs in boot
HEAD7 = "  # ===== VRN-2 一鍵 v0147(套件 v0147 = 啟動器 v0147 + runtime v0147 = v0146 + OutputStore v0101 + DataIntegrate v0101;"
BAN7 = "[計] VRN-2 一鍵 v0147 · ActivateVRN-2 v0147(套件 · 私有 runtime v0147 = v0146 + "
lines = ps.split("\n")
outl = []
for line in lines:
    if line.startswith(HEAD7):
        line = ("  # ===== VRN-2 一鍵 v0148(套件 v0148 = 啟動器 v0148 + runtime v0148 = v0147 + UIAction v0110 + ConsensusJoin v0101 + HistoryAlign v0102;v0148 = 桌機 2026-10-29 14:40 第一次跑 VRN2_RoundAll_v0100 的貼回修正:"
                "處理器自測不受殼的 VIA_ROOT 影響 · ⑥f 上櫃股 Yahoo 用 .TWO(對應表來自 ⑥e 市場冊)· ⑬b 科目對應更嚴 + 檢驗分「不過 / 口徑不明」· 另一支 Python 升 VRN2_RoundAll_v0101;"
                "v0147 = 套件 v0147 = 啟動器 v0147 + runtime v0147 = v0146 + OutputStore v0101 + DataIntegrate v0101;" + line[len(HEAD7):])
    elif BAN7 in line:
        i = line.index(BAN7)
        line = line[:i] + "[計] VRN-2 一鍵 v0148 · ActivateVRN-2 v0148(套件 · 私有 runtime v0148 = v0147 + UIAction v0110(自測不受 VIA_ROOT 影響)· ConsensusJoin v0101(上櫃 .TWO)· HistoryAlign v0102(科目對應更嚴 · 檢驗分不過 / 口徑不明);另一支 Python VRN2_RoundAll_v0101.py;v0147 = v0146 + " + line[i + len(BAN7):].replace("另有一支 Python VRN2_RoundAll_v0100.py 跑全流程;", "")
    else:
        line = line.replace("v0147", "v0148").replace("VRN2_RoundAll_v0100", "VRN2_RoundAll_v0101").replace("VRN2_UIAction_v0109\\.py", "VRN2_UIAction_v0110\\.py")
    outl.append(line)
ps = "\n".join(outl)
ps = re.sub(r"\$Want   = '[0-9a-f]{64}'   # VRN2_Closeout_v0148\.zip SHA-256[^\n]*", lambda m: "$Want   = '%s'   # VRN2_Closeout_v0148.zip SHA-256(套件 · 內含啟動器 v0148 + runtime v0148 清單 = v0147 + UIAction v0110 · ConsensusJoin v0101 · HistoryAlign v0102)" % want, ps, count=1)
assert want in ps and old_want not in ps
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0147" in code and "v0147 =" not in code), line[:200]
assert "VRN2_UIAction_v0110\\.py" in ps and "VRN2_RoundAll_v0101.py" in ps
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(old_cs, cs).replace("vrn2_release_v0147", "vrn2_release_v0148").replace("VRN2_OneClick_v0147.md", "VRN2_OneClick_v0148.md").replace("v0147", "v0148") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", md, count=1)
head = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", head, count=1)
head = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", head, count=1)
head = head.replace(old_want, "@WANT@").replace(old_cs, "@CS@").replace(old_cs[:12], "@CS@")


def hrep(a, b):
    global head
    assert head.count(a) == 1, (head.count(a), a[:80]); head = head.replace(a, b)


def hline(prefix, b):
    global head
    ls = head.split("\n"); idx = [i for i, l in enumerate(ls) if l.startswith(prefix)]; assert len(idx) == 1, (prefix, idx); ls[idx[0]] = b; head = "\n".join(ls)


hline("# VRN-2 一鍵 v0147(", "# VRN-2 一鍵 v0148(cmd / PowerShell 都能貼 · 套件 v0148 = 啟動器 v0148 + runtime v0148 = v0147 + UIAction v0110 · ConsensusJoin v0101 · HistoryAlign v0102)")
hrep("v0147 = v0146 入口 + runtime v0147(= runtime v0146 的 175 個成員逐位元保留 + 3 個新檔):",
     "桌機 2026-10-29 14:40 第一次跑 `VRN2_RoundAll_v0100.py`(52 份 · 2069 秒 · 紅 4 · 黃 10)→ 能在容器重現 / 驗證的修成 v0148;另一支 Python 升 **`VRN2_RoundAll_v0101.py`**(同發行夾 · 用法見 `VRN2_RoundAll_v0101.md`)。\n\n"
     "v0148 = v0147 入口 + runtime v0148(= runtime v0147 的 178 個成員逐位元保留 + 3 個新檔):\n\n| 元件 | 版本 | 修了什麼 |\n|---|---|---|\n"
     "| 處理器 ⑥c / ⑫b | VRN2_UIAction v0110(v0109 留著)| `--selftest` 先拿掉 VIA_ROOT / VRN2_* 再跑、結束還原 —— v0109 的 ④ 在殼有 VIA_ROOT 的桌機會真的去重渲染 Workbench、對不上預期而 FAIL(容器重現)· 動作全部照 v0109 |\n"
     "| 共識合併 ⑥f | VRN2_ConsensusJoin v0101(v0100 與共識引擎 v0120 都留著不動)| 上櫃股 Yahoo 用 `.TWO`:鉅亨對上櫃股也回 `TWS:####` → 引擎一律組 `.TW` → 5274 / 5904 / 8358 / 4966 / 7728 / 6147 / 3264 / 6143 在 Yahoo 404;對應表改從 ⑥e 市場冊(VDF 身分表)來,引擎由同一個 Python 經 shim 帶起、只換它組代號那個函式;今天快取裡用錯尾碼抓的代號重抓 · 收據多 `yf_ticker_map` / `yf_404` |\n"
     "| 歷史對齊 ⑬b | VRN2_HistoryAlign v0102(v0101 / v0100 留著)| 科目對應排除「其中一部分 / 別的口徑」的列(Other Revenue · Taxes payable · Total liabs & equity · Minorities · 調整後 / 核心 · 部門 / 事業成長率)· 檢驗:成本取絕對值 · ROE 可用平均權益 · 同年同科目取報告裡重複出現的值(預估調整表同年有舊估 / 新估 / 變動 %)· 差到不像同口徑 → 口徑不明不算不過 —— 容器資料不過 74 / 218 → 5 / 192 |\n"
     "| 啟動器 | ActivateVRN-2 v0148 | 指向上面三個新版 · 收據 `VRN2_Closeout_v0148.json`(⑥f 多 Yahoo 對應 / 404)· 自測多一段 v0148 |\n\n"
     "前一版 v0147 = v0146 入口 + runtime v0147(= runtime v0146 的 175 個成員逐位元保留 + 3 個新檔):")
hrep("| 啟動器 | ActivateVRN-2 v0147 |", "| 啟動器(v0147)| ActivateVRN-2 v0147 |")
hrep("| 步驟 | v0147 做什麼 |", "| 步驟 | v0148 做什麼 |")
hrep("| ① ② ③ ③b | 同 v0146(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|", "| ① ② ③ ③b | 同 v0147(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|")
hline("| ④ | `python ActivateVRN-2_v0147.py", "| ④ | `python ActivateVRN-2_v0148.py [--source …]`:單機閘 → ①~⑤ → ⑤b SSOT-ID 核號同步(含提案冊)→ ⑥ → ⑦(管理器 v0255)→ ⑥e 市場擷取(擷取 Python)→ ⑥f 共識合併(上櫃 .TWO · Combined 冊)→ ⑧~⑫ → ⑫b 補放 → 四點原文核對 → 收據 → ⑬b 歷史對齊(v0102)→ ⑬ 輸出位置 · 長線 Parquet 庫(七冊 · 補缺)→ ⑬c 舊資料庫整合掃描(限深)→ Workbench v0102 渲染 + 開啟 |")
hline("| ⑤ | 摘要多七行", "| ⑤ | 摘要多七行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID · 階段耗時 · ⑥e 市場擷取 · ⑥f 共識合併 · ⑬b 歷史對齊 · ⑬c 舊資料庫整合(都讀 `VRN2_Closeout_v0148.json`)+ 一行指向 `VRN2_RoundAll_v0101.py` |")
hline("| ⑤b ⑤c |", "| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\\\VRN2\\\\VRN2_UIAction_v0110.py`(設定檔 v0148 · `vrn2://integrate` 取最新的 DataIntegrate = v0101)· U/I 有輸入區塊 · 沒開就代開 |")
for a, b in (("VRN2_OneClick_v0147", "VRN2_OneClick_v0148"), ("套件 `VRN2_Closeout_v0147.zip`", "套件 `VRN2_Closeout_v0148.zip`"), ("從 `vrn2_release_v0147` 取", "從 `vrn2_release_v0148` 取"), ("Downloads\\VRN2_Closeout_v0147`", "Downloads\\VRN2_Closeout_v0148`")):
    head = head.replace(a, b)
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and "@" + "WANT@" not in newmd and cs in boot
(rel / "VRN2_OneClick_v0148.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot148.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline148.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0148.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0148", cs[:12])
# ===== operator v0109 from v0108 code + v0107 md history =====
md8 = (REPO / "vrn1_vrn2_oneclick_v0108/VRN1_VRN2_OneClick_v0108.md").read_text(encoding="utf-8")
md7 = (REPO / "vrn1_vrn2_oneclick_v0107/VRN1_VRN2_OneClick_v0107.md").read_text(encoding="utf-8")
p8 = re.search(r"(?s)```powershell\n(.*?)\n```", md8).group(1); boot8 = re.search(r"(?s)```text\n(.*?)\n```", md8).group(1)
p9 = p8


def rep9(a, b):
    global p9
    assert p9.count(a) == 1, (p9.count(a), a[:80]); p9 = p9.replace(a, b)


rep9("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0147'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0148'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0147 程式碼 SHA-256", p9).group(1); assert old_h2 == old_cs
rep9("  $H2 = '%s'   # VRN-2 一鍵 v0147 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0148 程式碼 SHA-256" % cs)
rep9("  # ===== VRN-1 / VRN-2 操作員一鍵 v0108(2026-10-29 · ② 改指 VRN-2 一鍵 v0147:",
     "  # ===== VRN-1 / VRN-2 操作員一鍵 v0109(2026-10-29 · ② 改指 VRN-2 一鍵 v0148:處理器自測不受 VIA_ROOT 影響 · ⑥f 上櫃 .TWO · ⑬b 科目對應更嚴;另一支 Python VRN2_RoundAll_v0101.py;v0108 · ② 改指 VRN-2 一鍵 v0147:")
rep9("操作員一鍵 v0108 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0109 · {0} · VRN-1 {1} · VIA {2}")
outl = []
for line in p9.split("\n"):
    if "操作員一鍵 v0109(2026-10-29 · ② 改指 VRN-2 一鍵 v0148" not in line:
        line = line.replace("VRN2_OneClick_v0147.md", "VRN2_OneClick_v0148.md").replace("VRN-2 一鍵 v0147", "VRN-2 一鍵 v0148").replace("套件 v0147 = 啟動器 v0147 + runtime v0147", "套件 v0148 = 啟動器 v0148 + runtime v0148").replace("ActivateVRN-2_v0147 單機閘", "ActivateVRN-2_v0148 單機閘")
    outl.append(line)
p9 = "\n".join(outl)
for line in p9.splitlines():
    code = line.split("#", 1)[0]
    assert "v0147" not in code, line[:160]
cs9 = hashlib.sha256(p9.encode("utf-8")).hexdigest()
boot9 = boot8.replace(re.search(r"\$H  = '([0-9a-f]{64})'", boot8).group(1), cs9).replace("vrn1_vrn2_oneclick_v0108", "vrn1_vrn2_oneclick_v0109").replace("VRN1_VRN2_OneClick_v0108.md", "VRN1_VRN2_OneClick_v0109.md").replace("操作員一鍵 v0108", "操作員一鍵 v0109") + "\n"
one9 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot9.encode("utf-16-le")).decode("ascii"); assert len(one9) < 8191
i7 = md7.index("\n## ")
hist7 = md7[:i7].split("\n", 1)[1]                                            # v0107 的歷史段落(正確的)
p8_intro = md8.split("\n\n")[1]                                               # v0108 自己的那一段(正確的)
assert p8_intro.startswith("操作員 2026-10-29「generate a py code") and "v0108 = v0107 + ② 改指 **VRN-2 一鍵 v0147**" in p8_intro
tail = md7[i7:]
tail = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", tail, count=1)
tail = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", tail, count=1)
tail = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", tail, count=1)
cs7 = hashlib.sha256(re.search(r"(?s)```powershell\n(.*?)\n```", md7).group(1).encode("utf-8")).hexdigest()
tail = tail.replace(cs7, cs9).replace(cs7[:12], cs9[:12])
assert "v0107" not in tail.replace("@PS@", "").replace("@BOOT@", "").replace("@ONE@", ""), "tail mentions v0107"
text = ("# VRN-1 / VRN-2 操作員一鍵 v0109(cmd / PowerShell 都能貼 · v0108 + ② 改指 VRN-2 一鍵 v0148:處理器自測不受 VIA_ROOT 影響 · ⑥f 上櫃 .TWO · ⑬b 科目對應更嚴)\n\n"
        "桌機 2026-10-29 14:40 第一次跑 `VRN2_RoundAll_v0100.py`(紅 4 · 黃 10)→ VRN-2 v0148 + `VRN2_RoundAll_v0101.py`(`vrn2_release_v0148`)。v0109 = v0108 + ② 改指 **VRN-2 一鍵 v0148**"
        "(套件 v0148 = 啟動器 v0148 + runtime v0148 = v0147 + UIAction v0110 · ConsensusJoin v0101 · HistoryAlign v0102)+ 本檔的歷史段落照 v0107 原文還原(v0108 的 md 建置時把歷史段落的版號也一起換掉了;v0108 檔留著不改);其餘一字不改。\n\n"
        + p8_intro + "\n\n" + hist7.lstrip("\n") + tail)
text = text.replace("@PS@", p9).replace("@BOOT@", boot9.rstrip("\n")).replace("@ONE@", one9)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p9 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot9
(op9 / "VRN1_VRN2_OneClick_v0109.md").write_text(text, encoding="utf-8", newline="\n"); (op9 / "boot_pair109.ps1").write_text(boot9, encoding="utf-8", newline="\n"); (op9 / "oneline_pair109.txt").write_text(one9 + "\n", encoding="utf-8"); (op9 / "Run-VRN1-VRN2-v0109.ps1").write_text(p9 + "\n", encoding="utf-8", newline="\n"); (op9 / "code_sha.txt").write_text(cs9)
(op9 / "VRN1_VRN2_Verification_v0109.md").write_text(
    "# VRN-1 / VRN-2 操作員一鍵 v0109 · 容器驗證(2026-10-29)\n\nv0109 = v0108 的程式碼只改三處:② 發行夾 `vrn2_release_v0147` → `vrn2_release_v0148`、`$H2` → VRN-2 一鍵 v0148 程式碼 SHA-256(`%s`)、橫幅「操作員一鍵 v0108」→「v0109」;歷史子句照舊。"
    "md 的歷史段落照 v0107 原文還原(v0108 的 md 把「v0107 = v0106 …」等段落誤寫成「v0108 = …」,v0108 檔不改)。\n\n"
    "| 檢查 | 結果 |\n|---|---|\n| pwsh 7.4.6 語法剖析(Run-VRN1-VRN2-v0109.ps1 · boot_pair109.ps1)| 見 `vrn2_release_v0148/logs_v0148.zip` 的 `pscheck148.log` |\n| 本段程式碼 SHA-256 = boot 裡的 `$H` | 同上 |\n| 一行(-EncodedCommand)解碼 = boot | 同上 |\n"
    "| `$H2` = `VRN2_OneClick_v0148.md` 程式碼 SHA-256 | 同上 |\n| 橫幅版號 | `操作員一鍵 v0109` |\n| 本地實測一輪 v0100 的 `$H_OP` = 本段程式碼 SHA-256 | 同上 |\n\n沒有 .ps1 進倉:一鍵程式碼只在本夾的 md 裡,`tools_v0109.zip` 是容器測試用副本。\n" % cs[:12], encoding="utf-8", newline="\n")
print("operator v0109", cs9[:12])
# ===== LocalRound re-point =====
lr = REPO / "VRN2_LocalRound_v0100.md"; s = lr.read_text(encoding="utf-8")
if "VRN1_VRN2_OneClick_v0109.md" in s:
    s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0109 程式碼 SHA-256", "$H_OP = '%s'   # 操作員一鍵 v0109 程式碼 SHA-256" % cs9, s, count=1); assert cs9 in s
    lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP refreshed", cs9[:12]); raise SystemExit(0)


def lrep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)


lrep("# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0147(開 Workbench)→ 打包貼回材料)", "# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0148(開 Workbench)→ 打包貼回材料)")
lrep("> **2026-10-29 v0147 改指(", "> **2026-10-29 v0148 改指(桌機 14:40 第一次跑 VRN2_RoundAll_v0100 的貼回):** 本段現在指 操作員一鍵 **v0109** → VRN-2 一鍵 **v0148**(處理器 v0110 自測不受殼的 VIA_ROOT 影響 · ⑥f 上櫃股 Yahoo 用 .TWO · ⑬b 科目對應更嚴 + 檢驗分「不過 / 口徑不明」)。另一支 Python 升 **`vrn2_release_v0148/VRN2_RoundAll_v0101.py`**(擷取 Python 不用退役環境 · 除錯報告帶摘錄 / 錯誤原文 · 最後印兩種殼都能貼的重跑指令);本段 ④ 貼回包多收 `consensus\\VRN2_YFTickerMap_latest.json`。\n> **2026-10-29 v0147 改指(")
lrep("本段現在指 操作員一鍵 **v0108** → VRN-2 一鍵 **v0147**", "本段當時指 操作員一鍵 **v0108** → VRN-2 一鍵 **v0147**")
lrep("從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0108.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0147 套件**(啟動器 v0147 → ", "從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0109.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0148 套件**(啟動器 v0148 → 處理器 v0110 · ⑥f 上櫃 .TWO · ⑬b 科目對應更嚴;v0147 的 ")
lrep("最後 300 行貼包 · `VRN2_Closeout_v0147.json` ·", "最後 300 行貼包 · `VRN2_Closeout_v0148.json` ·")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0108 程式碼 SHA-256\(VRN1_VRN2_OneClick_v0108\.md powershell 區塊 · ② 指 VRN-2 一鍵 v0147\)", "$H_OP = '%s'   # 操作員一鍵 v0109 程式碼 SHA-256(VRN1_VRN2_OneClick_v0109.md powershell 區塊 · ② 指 VRN-2 一鍵 v0148)" % cs9, s, count=1); assert cs9 in s
lrep("  $k3 = '③ 跑 VRN-2 v0147'", "  $k3 = '③ 跑 VRN-2 v0148'")
lrep("  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0108' 'VRN1_VRN2_OneClick_v0108.md' $H_OP", "  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0109' 'VRN1_VRN2_OneClick_v0109.md' $H_OP")
lrep("  foreach ($rel in 'VRN2_Closeout_v0147.json', 'VRN2_RoundAll_latest.json',", "  foreach ($rel in 'VRN2_Closeout_v0148.json', 'VRN2_RoundAll_latest.json', 'consensus\\VRN2_YFTickerMap_latest.json',")
lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP", cs9[:12])
