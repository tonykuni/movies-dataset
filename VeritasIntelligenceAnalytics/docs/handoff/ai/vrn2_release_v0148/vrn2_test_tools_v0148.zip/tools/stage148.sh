#!/bin/bash
# v0148 放進倉:docs/handoff/ai/vrn2_release_v0148/ + vrn1_vrn2_oneclick_v0109/ + functional modules/VRN/ 新工具(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v148
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0148; OP=$REPO/vrn1_vrn2_oneclick_v0109; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v148")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0148"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0109")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("ra148_first.log", "ra148_fix.log", "ra148.rc", "t148_setup.log", "pscheck148.log", "scen148.rc", "scen148_first.log", "scen148_again.log", "scen148_tamper.log", "scen148_setup.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0148_selftest.log", "ActivateVRN-2_v0148_selftest_iso.log", "roundall101_selftest.log", "VRN2_HistoryAlign_v0102_selftest.log", "VRN2_ConsensusJoin_v0101_selftest.log", "VRN2_UIAction_v0109_selftest_with_VIA_ROOT.log", "VRN2_UIAction_v0110_selftest_with_VIA_ROOT.log", "cmp_hist148.log", "cmp_hist148.json", "run_roundall148.sh", "scen148.sh")]
v2 = W / "t148/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0148.json", "VRN2_Closeout_v0148.before_roundall.json", "VRN2_RoundAll_latest.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Output_Config.json", "VRN2_Phase_Timing_latest.json", "VRN2_HistoryAlign_latest.json", "VRN2_Integrate_latest.json", "consensus/VRN2_Consensus_latest.json", "market/VRN2_Market_latest.json", "output/VRN2_Combined_latest.csv", "output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "VRN2_Workbench_latest.html"):
    logs.append(("t148/" + n, v2 / n))
for n in ("VRN2_NUMBER_REQUEST_latest.json", "VRN2_NUMBER_STATE_latest.json"):
    logs.append(("t148/contract/" + n, W / "t148/VIA/functional modules/VRN2/contract" / n))
z(D / "logs_v0148.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))] + [("release/" + q.name, q) for q in (W / "release148" / "boot_roundall.ps1", W / "release148" / "oneline_roundall.txt", W / "release148" / "Run-VRN2-v0148.ps1", W / "release148" / "boot148.ps1")]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py")) if q.name in ("VRN2_UIAction_v0110.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_HistoryAlign_v0102.py", "ActivateVRN-2_v0148.py", "VRN2_RoundAll_v0101.py")]
z(D / "vrn2_test_tools_v0148.zip", tools)
z(OP / "tools_v0109.zip", [("tools/" + q.name, q) for q in (W / "operator109" / "boot_pair109.ps1", W / "operator109" / "oneline_pair109.txt", W / "operator109" / "Run-VRN1-VRN2-v0109.ps1")])
for n in ("VRN1_VRN2_OneClick_v0109.md", "VRN1_VRN2_Verification_v0109.md"): shutil.copy(W / "operator109" / n, OP / n)
for n in ("VRN2_Closeout_v0148.zip", "VRN2_Release_v0148.json", "VRN2_OneClick_v0148.md", "VRN2_Verification_v0148.md", "VRN2_RoundAll_v0101.py", "VRN2_RoundAll_v0101.md"): shutil.copy(W / "release148" / n, D / n)
# 新成員只在私有 runtime zip(functional modules/VRN2)與 vrn2_test_tools_v0148.zip/new;不放共用 VRN 夾;VRN2_RoundAll_v0101.py 放發行夾(一支入口)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
