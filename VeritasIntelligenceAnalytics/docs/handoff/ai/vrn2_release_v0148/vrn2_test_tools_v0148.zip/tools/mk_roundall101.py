"""VRN2_RoundAll_v0101.py = v0100 + 桌機 2026-10-29 14:40 貼回的修正(套件 v0148 · 擷取 Python 不用退役環境 · 除錯報告帶證據 · 重跑指令兩種殼都能貼)。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v147/new/VRN2_RoundAll_v0100.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('''"""VRN2_RoundAll v0100 — 一支 Python 跑完 VRN-2 一輪:取套件 → 環境診斷 → 全部自測 → 跑啟動器 → 自動修 → 除錯報告 → 貼回包。
''', '''"""VRN2_RoundAll v0101 — 一支 Python 跑完 VRN-2 一輪:取套件 → 環境診斷 → 全部自測 → 跑啟動器 → 自動修 → 除錯報告 → 貼回包。

v0101(桌機 2026-10-29 14:40 第一次跑 v0100 的貼回 · 紅 4 黃 10):
  · 套件 v0148(啟動器 v0148 · runtime v0148 = v0147 的 178 個成員不動 + UIAction v0110 · ConsensusJoin v0101 · HistoryAlign v0102)。
  · ② 擷取 Python 不再選退役 / 備份的環境:桌機 envs\\via_core.retired-20260914_111946 被當成 ⑥e / ⑥f 的 Python(名字有 retired / backup / bak / old /
    deprecated / archive 的夾一律略過,略過的照列)。
  · ③ 自測清單:UIAction v0109 → v0110(v0109 的自測在殼有 VIA_ROOT 時會失敗 —— 桌機就是)· ConsensusJoin v0101 · HistoryAlign v0102。
  · ⑥ 除錯報告多帶證據,貼主控台文字也看得到:四點原文核對 FAIL 的那一點的摘錄原文(摘要冊)· ⑥e 不綠時 market\\vdf\\last_error.txt 最後幾行 ·
    ⑥f Yahoo 404 的代號與上櫃 .TWO 對應數。
  · 最後印「下次怎麼跑」:用本檔的完整路徑(cmd / PowerShell 都能貼;%USERPROFILE% 只在 cmd 有效,PowerShell 要 $env:USERPROFILE)。
''')
rep('VERSION = "v0100"', 'VERSION = "v0101"')
rep('PACKAGE = "VRN2_Closeout_v0147"', 'PACKAGE = "VRN2_Closeout_v0148"')
rep('# 建置時填入 VRN2_Closeout_v0147.zip 的 SHA-256', '# 建置時填入 VRN2_Closeout_v0148.zip 的 SHA-256')
rep('RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0147"', 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0148"')
rep('RELEASE_JSON = "VRN2_Release_v0147.json"', 'RELEASE_JSON = "VRN2_Release_v0148.json"')
rep('LAUNCHER = "ActivateVRN-2_v0147.py"', 'LAUNCHER = "ActivateVRN-2_v0148.py"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0147.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0148.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0147.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0148.json"')
rep('RECEIPT = "VRN2_Closeout_v0147.json"', 'RECEIPT = "VRN2_Closeout_v0148.json"')
rep('''SELFTESTS = (("VRN2_Workbench_v0102.py", 600), ("VRN2_HistoryAlign_v0100.py", 300), ("VRN2_HistoryAlign_v0101.py", 300), ("VRN2_DataIntegrate_v0100.py", 300), ("VRN2_DataIntegrate_v0101.py", 300),
             ("VRN2_UIAction_v0109.py", 300), ("VRN2_SSOTSync_v0101.py", 300), ("VRN2_OutputStore_v0101.py", 300), ("VRN2_ConsensusJoin_v0100.py", 900), ("VRN_SystemManager_v0255.py", 1800))''',
    '''SELFTESTS = (("VRN2_Workbench_v0102.py", 600), ("VRN2_HistoryAlign_v0100.py", 300), ("VRN2_HistoryAlign_v0102.py", 300), ("VRN2_DataIntegrate_v0100.py", 300), ("VRN2_DataIntegrate_v0101.py", 300),
             ("VRN2_UIAction_v0110.py", 300), ("VRN2_SSOTSync_v0101.py", 300), ("VRN2_OutputStore_v0101.py", 300), ("VRN2_ConsensusJoin_v0101.py", 900), ("VRN_SystemManager_v0255.py", 1800))
RETIRED_ENV = re.compile(r"retired|backup|\\.bak|_bak|\\bbak\\b|\\.old|_old|-old|deprecated|archive", re.I)   # 退役 / 備份的環境夾不當擷取 Python
SKIPPED_ENVS = []''')
rep('PASTE_FILES = ("VRN2_Closeout_v0147.json", "VRN2_Closeout_v0147.before_roundall.json",', 'PASTE_FILES = ("VRN2_Closeout_v0148.json", "VRN2_Closeout_v0148.before_roundall.json",')
rep('"output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "market/vdf/last_error.txt")',
    '"output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "market/vdf/last_error.txt", "consensus/VRN2_YFTickerMap_latest.json")')
rep('''    envs = home() / "envs"
    for name in ["via_tw_fetch"] + (sorted(p.name for p in envs.iterdir() if p.is_dir() and p.name != "via_tw_fetch") if envs.is_dir() else []):
        for rel in ("Scripts/python.exe", "bin/python"):''', '''    envs = home() / "envs"
    SKIPPED_ENVS.clear()
    for name in ["via_tw_fetch"] + (sorted(p.name for p in envs.iterdir() if p.is_dir() and p.name != "via_tw_fetch") if envs.is_dir() else []):
        if RETIRED_ENV.search(name):
            SKIPPED_ENVS.append(name)
            continue
        for rel in ("Scripts/python.exe", "bin/python"):''')
rep('''    fpy, report = find_fetch_python()
    state["fetch_python"] = fpy''', '''    fpy, report = find_fetch_python()
    state["fetch_python"] = fpy
    if SKIPPED_ENVS:
        info("擷取 Python 不用退役 / 備份的環境:%s" % "、".join(SKIPPED_ENVS))''')
rep('''        eng = list((shared / "_vdf_fetch").glob("VDF_TW_*.py")) if (shared / "_vdf_fetch").is_dir() else []''',
    '''        eng = sorted((shared / "_vdf_fetch").glob("VDF_TW_*.py"), key=lambda p: int((re.search(r"_v(\\d+)", p.name) or re.search(r"(\\d+)", "0")).group(1))) if (shared / "_vdf_fetch").is_dir() else []''')
rep('''("%s · VDF 引擎 %s" % (tools[-1].name, eng[0].name))''', '''("%s · VDF 引擎 %s" % (tools[-1].name, " / ".join(p.name for p in eng)))''')
# 除錯報告:四點 FAIL 的摘錄
rep('''          "FAIL = 第二讀取器在原文找不到完整摘錄 → 貼回包(含原 PDF 檔名)給 AI;OCR_PENDING = 影像頁等 OCR")''',
    '''          "FAIL = 第二讀取器在原文找不到完整摘錄 → 貼回包(含原 PDF 檔名)給 AI;OCR_PENDING = 影像頁等 OCR")
        summ = {str(r.get("FILENAME")): r for r in (jread(v2 / "output" / "VRN2_Summary_latest.json", []) or []) if isinstance(r, dict)}
        for r in [x for x in bad if x.get("state") == "FAIL"][:6]:
            text = str((summ.get(str(r.get("file"))) or {}).get("POINT_%s" % r.get("point")) or "")
            if text:
                f("RED", "四點 FAIL 摘錄", "%s 第 %s 點(第 %s 頁 · %s):%s" % (r.get("file"), r.get("point"), r.get("page") or "?", r.get("reason") or r.get("match") or "", text[:240]),
                  "這段字要在原 PDF 找得到一字不差;找不到的那幾個字就是摘要器拼錯 / 斷行合錯的地方")''')
rep('''    market = jread(v2 / "market" / "VRN2_Market_latest.json", {}) or {}
    if market.get("per_file"):''', '''    step_e = next((s for s in receipt.get("steps") or [] if str(s.get("step", "")).startswith("⑥e")), {})
    err = v2 / "market" / "vdf" / "last_error.txt"
    if step_e.get("lamp") not in (None, "GREEN") and err.is_file():
        tail = [l.strip() for l in err.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()][-6:]
        f("YELLOW", "⑥e 擷取錯誤(last_error.txt)", " | ".join(tail)[:600], "VDF 引擎自己的錯誤(VRN-2 只讀不改)· 網路 / 憑證 / 套件 → 照錯誤處理;整段在貼回包 vrn2/market/vdf/last_error.txt")
    run_c = (receipt.get("consensus") or {}).get("run") or {}
    cons_rec = jread(v2 / "consensus" / "VRN2_Consensus_latest.json", {}) or {}
    if cons_rec.get("yf_404") or cons_rec.get("yf_ticker_map"):
        ym = cons_rec.get("yf_ticker_map") or {}
        f("YELLOW" if cons_rec.get("yf_404") else "GREEN", "⑥f Yahoo 代號", "對應表 %s 筆 · 上櫃 .TWO %d(%s)· Yahoo 404:%s" % (ym.get("codes", 0), len(ym.get("tpex") or []), ",".join((ym.get("tpex") or [])[:12]), ",".join(cons_rec.get("yf_404") or []) or "無"),
          "" if not cons_rec.get("yf_404") else "404 的代號 Yahoo 沒有 → 共識只有 FactSet;若是上櫃卻還是 .TW → 市場冊沒有它的 yfinance_ticker(先讓 ⑥e 綠)")
    elif run_c.get("why"):
        rep.setdefault("consensus_why", run_c.get("why"))
    market = jread(v2 / "market" / "VRN2_Market_latest.json", {}) or {}
    if market.get("per_file"):''')
# 下次怎麼跑
rep('''    print("NEXT: [%s] %s · 紅 %d · 黃 %d · %s" % (overall, NAME, counts["RED"], counts["YELLOW"], ("貼回包 " + str(zpath)) if zpath else "(沒打包)"), flush=True)''',
    '''    for line in rerun_hint(Path(__file__).resolve()):
        print(line)
    print("NEXT: [%s] %s · 紅 %d · 黃 %d · %s" % (overall, NAME, counts["RED"], counts["YELLOW"], ("貼回包 " + str(zpath)) if zpath else "(沒打包)"), flush=True)''')
rep('''# ===== 12. 自測 =====''', '''def rerun_hint(script: Path) -> list:
    """下次怎麼跑:完整路徑加引號(cmd 與 PowerShell 都能直接貼;%USERPROFILE% 只有 cmd 認得)。"""
    exe = "python"
    return ["下次(cmd / PowerShell 都能貼 · 一行一個指令 · 整行複製;第 1 行整輪 · 第 2 行不重跑只修 + 除錯 + 打包 · 第 3 行只診斷 + 自測):",
            '%s "%s"' % (exe, script),
            '%s "%s" --skip-run --integrate yes' % (exe, script),
            '%s "%s" --only preflight,selftest' % (exe, script)]


# ===== 12. 自測 =====''')
# 自測:檔名 / 新項目
rep('''            and "vrn2/" + RECEIPT in names and "vrn2/VRN2_Closeout_v0147.before_roundall.json" in names and "vrn2/VRN2_Workbench_latest.html" in names)''',
    '''            and "vrn2/" + RECEIPT in names and "vrn2/VRN2_Closeout_v0148.before_roundall.json" in names and "vrn2/VRN2_Workbench_latest.html" in names)''')
rep('''            and parse_args(["--launcher-args", "--no-install --x", "--no-open"]).launcher_args == "--no-install --x" and parse_args(["--launcher-args", "--no-install"]).no_open is False)
''', '''            and parse_args(["--launcher-args", "--no-install --x", "--no-open"]).launcher_args == "--no-install --x" and parse_args(["--launcher-args", "--no-install"]).no_open is False)
        # ⑫ 擷取 Python 不用退役 / 備份環境
        envs = Path(os.environ["USERPROFILE"]) / "envs"
        for name in ("via_core.retired-20260914_111946", "via_tw_fetch.bak_1", "old_backup", "work"):
            exe = envs / name / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
            exe.parent.mkdir(parents=True, exist_ok=True)
            exe.write_text("", encoding="utf-8")
        cands = fetch_python_candidates()
        chk("⑫ 擷取 Python 候選:via_core.retired-… / via_tw_fetch.bak_1 / old_backup 略過並記下 · work 照收 · 本行程最後",
            any("work" in c for c in cands) and not any(("retired" in c or ".bak_" in c or "old_backup" in c) for c in cands) and set(SKIPPED_ENVS) == {"via_core.retired-20260914_111946", "via_tw_fetch.bak_1", "old_backup"} and cands[-1] == sys.executable)
        # ⑬ ⑭ 除錯報告的證據
        (v2 / "output" / "VRN2_Summary_latest.json").write_text(json.dumps([{"FILENAME": "3014TT.pdf", "POINT_3": "營收年增 25% 優於預期"}], ensure_ascii=False), encoding="utf-8")
        (v2 / "market" / "vdf").mkdir(parents=True, exist_ok=True)
        (v2 / "market" / "vdf" / "last_error.txt").write_text("Traceback\\nConnectionError: www.twse.com.tw timed out\\n", encoding="utf-8")
        (v2 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"year_n": 2026, "yf_404": ["6933.TW"], "yf_ticker_map": {"codes": 3, "tpex": ["5274"]}}), encoding="utf-8")
        rr = jread(v2 / RECEIPT, {})
        for st in rr.get("steps") or []:
            if str(st.get("step", "")).startswith("⑥e"):
                st["lamp"] = "YELLOW"                                    # ⑦ 把它標成綠了;⑭ 要「⑥e 不綠」
        (v2 / RECEIPT).write_text(json.dumps(rr, ensure_ascii=False), encoding="utf-8")
        sys.stdout = io.StringIO()
        try:
            rep2 = diagnose(root)
        finally:
            sys.stdout = sys_stdout
        a2 = {x["area"]: x for x in rep2["findings"]}
        chk("⑬ 除錯:四點 FAIL 帶摘錄原文(3014TT 第 3 點「營收年增 25% 優於預期」)", "營收年增 25% 優於預期" in a2.get("四點 FAIL 摘錄", {}).get("finding", ""))
        chk("⑭ 除錯:⑥e 不綠 → last_error.txt 最後幾行(timed out)· ⑥f Yahoo 404 代號與上櫃 .TWO 數", "timed out" in a2.get("⑥e 擷取錯誤(last_error.txt)", {}).get("finding", "") and "6933.TW" in a2.get("⑥f Yahoo 代號", {}).get("finding", "") and "上櫃 .TWO 1" in a2.get("⑥f Yahoo 代號", {}).get("finding", ""))
        hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0101.py"))
        chk("⑮ 下次怎麼跑:完整路徑加引號(兩種殼都能貼 · 不用 %USERPROFILE% · 指令行沒有 :: / # 註解尾巴 · 行首就是 python)· 整輪 / --skip-run / --only preflight,selftest",
            len(hint) == 4 and all(h.startswith('python "') for h in hint[1:]) and not any("%USERPROFILE%" in h or "::" in h or "#" in h for h in hint[1:]) and hint[2].endswith("--skip-run --integrate yes") and hint[1].endswith('.py"'))
''')
rep('''    print("[%s] %s %s --selftest · 12 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(bad)), flush=True)''',
    '''    print("[%s] %s %s --selftest · 16 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(bad)), flush=True)''')
rep("用法:python VRN2_RoundAll_v0100.py", "用法:python VRN2_RoundAll_v0101.py")
s = s.replace("本機 Downloads\\\\VRN2_Closeout_v0147 的 zip", "本機 Downloads\\\\VRN2_Closeout_v0148 的 zip").replace("ActivateVRN-2_v0147(預設不上船", "ActivateVRN-2_v0148(預設不上船").replace("都在 VRN-2 套件 v0147 裡", "都在 VRN-2 套件 v0148 裡").replace("九支 --selftest", "十支 --selftest")
out = S / "v148/new/VRN2_RoundAll_v0101.py"
out.write_text(s, encoding="utf-8", newline="\n")
print("wrote", out, s.count("\n"))
