"""VRN2_Handover_v0149.md:從 v0148 只增不減。"""
import json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v148")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0148.md").read_text(encoding="utf-8")
R = json.loads((S / "release148/VRN2_Release_v0148.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg148/VRN2_Runtime_v0148.json").read_text(encoding="utf-8"))["files"]}


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)


lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0147 + VRN2_RoundAll_v0100 · 2026-10-29(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0148 + VRN2_RoundAll_v0101 · 2026-10-29(v0147 + 本輪:桌機 14:40 第一次跑 VRN2_RoundAll_v0100(52 份 · 2069 秒 · 紅 4 黃 10)的貼回 → "
            "處理器 v0110(自測不受殼的 VIA_ROOT 影響)· ConsensusJoin v0101(上櫃股 Yahoo 用 .TWO)· HistoryAlign v0102(科目對應更嚴 · 檢驗分不過 / 口徑不明)· RoundAll v0101(不用退役環境 · 除錯帶證據 · 兩種殼都能貼的重跑指令)· "
            "一鍵 v0148 · 操作員一鍵 v0109(歷史段落還原)· 本地實測一輪改指;runtime v0147 的 178 個成員一個位元組都不動 · +3 個新檔)")
src = "\n".join(lines)
old_round = "> **操作員令(2026-10-29 · v0146 推上之後)**"
assert src.count(old_round) == 1
e2e = res["roundall_e2e"]; fx = res.get("roundall_fix_pass") or {}
new_round = ("> **桌機貼回(2026-10-29 14:40 · 第一次跑 VRN2_RoundAll_v0100 · 52 份 · 2069 秒 · 紅 4 黃 10)**:紅 = ③ UIAction v0109 自測 ④ · ④ 啟動器 rc 1 · ⑥ 收尾收據 rc 1 · ⑥ 四點原文核對 FAIL(3014TT 第 3 點);"
             "黃 = ② 擷取 Python 選到 `envs\\via_core.retired-20260914_111946` · ⑥e VDF 引擎 5 個視窗 rc1「致命錯」(VDF 先自己用 pip 建 via_tw_fetch)· ⑥f 8 檔 Yahoo 404 + gate FAIL_CLOSED · ⑬b 無歷史 44 · 檢驗 534 不過 120 · ⑪ 驗證 FAIL 4(MS 四份現價 / 上漲)· 缺年度 3 份 …;"
             "另 PowerShell 裡打 `python \"%%USERPROFILE%%\\…\"` 找不到檔。\n"
             "> **本輪(v0148 · 套件 = 啟動器 v0148 + runtime v0148 = v0147 的 178 個成員不動 + UIAction v0110 + ConsensusJoin v0101 + HistoryAlign v0102 · 一支 Python `vrn2_release_v0148/VRN2_RoundAll_v0101.py` · 一鍵 v0148 · 操作員一鍵 v0109)**:"
             "① **UIAction v0110**:v0109 的 rerender() 在設定檔沒 root 時讀環境變數 VIA_ROOT,桌機的殼有它 → 自測真的重渲染了 Workbench、印的不是「沒有 VIA 根」→ ④ FAIL;容器設 VIA_ROOT 重現(`VRN2_UIAction_v0109_selftest_with_VIA_ROOT.log`)· v0110 自測時拿掉再還原 · 7 項過。"
             "② **ConsensusJoin v0101**:鉅亨對上櫃股也回 `TWS:####`,引擎 `def_cnyes_symbol_to_yfinance_ticker` 一律 `.TW` → Yahoo 404;對應表改從 ⑥e 市場冊(MarketFetch / VDF 身分表 TWSE .TW · TPEX .TWO)· 引擎檔不動,由本檔 `--engine-shim` 在同一個 Python 帶起並只換那個函式 · 同日 checkpoint 用錯尾碼抓的代號重抓 · 11 項過(含引擎原本 5274 → .TW、patch 後 .TWO)。"
             "③ **HistoryAlign v0102**:檢驗不過多半是科目對錯列(Other Revenue · Taxes payable · Total liabs & equity · Minorities · 調整後 / 核心 · 部門成長率)+ 成本寫負數 + 預估調整表同年三個值取到舊估;v0102 排除這些列、成本取絕對值、ROE 可用平均權益、同年同科目取重複出現的值、差到不像同口徑標 UNCLEAR —— 容器資料 不過 74 / 218 → 5 / 192(剩的 5 筆是合成資料故意改錯的淨利)。"
             "④ **RoundAll v0101**:擷取 Python 候選略過 retired / backup / bak / old / deprecated / archive 夾 · 除錯報告印四點 FAIL 那一點的摘錄原文、`market\\vdf\\last_error.txt` 最後幾行、Yahoo 404 代號與上櫃數 · 最後印完整路徑的重跑指令(cmd / PowerShell 都能貼)· 16 項過。"
             "⑤ **操作員一鍵 v0109**:v0108 的 md 被 build147 的整段取代把歷史段落也改成 v0108 / v0147;v0109 從 v0107 的 md 還原歷史(v0108 檔不改)。"
             "⑥ **端到端(沙盒仿桌機:殼有 VIA_ROOT · envs 有退役環境 · 套件從假 GitHub 分支取 · 輸出夾在 OneDrive)**:%s;只修回合:%s。"
             "**沒修 / 要貼回 zip 才能修**:3014TT 第 3 點 FAIL(rc 1 的原因)· MS-3661 / 6669 / 8358 / 8210 現價 / 上漲 FAIL(桌機這輪擷取沿用快取;同一份 MS-3661 在容器新跑是 PASS)· ⑥e VDF 致命錯的原因(VDF 的檔 VRN-2 不改)· 3 份缺年度數據。\n"
             % (e2e.get("summary", "見驗證紀錄"), fx.get("summary", "見驗證紀錄")))
src = src.replace(old_round, new_round + old_round, 1)
once("> **本輪(v0147 · 套件 = 啟動器 v0147 + runtime v0147", "> **前一輪(v0147 · 套件 = 啟動器 v0147 + runtime v0147")
anchor = "| **VRN2_RoundAll_v0100.py**(發行夾 · 一支入口 · 不在套件內)| **v0100** |"
assert src.count(anchor) == 1
rows = ("| **VRN2_RoundAll_v0101.py**(發行夾 · 一支入口 · 不在套件內)| **v0101** | `vrn2_release_v0148` | `%s` | **新**(套件 v0148 · 擷取 Python 不用退役環境 · 除錯帶摘錄 / 錯誤原文 · 重跑指令兩種殼都能貼 · 自測 16 項)|\n"
        "| ActivateVRN-2_v0148.py(套件 · 底座 v0136)| **v0148** | 見發行清單 | `%s` | **新**(指向 UIAction v0110 / ConsensusJoin v0101 / HistoryAlign v0102 · 收據 v0148 · 自測 6 段)|\n"
        "| **VRN2_UIAction** | **v0110**(薄尾 · v0109 留著)| runtime v0148 | `%s` | **新**(自測不受 VIA_ROOT / VRN2_* 影響 · 7 項)|\n"
        "| **VRN2_ConsensusJoin** | **v0101**(薄尾 · v0100 與共識引擎 v0120 留著)| runtime v0148 | `%s` | **新**(上櫃 .TWO 對應表來自市場冊 · 引擎經 shim 帶起 · 11 項)|\n"
        "| **VRN2_HistoryAlign** | **v0102**(薄尾 · v0101 / v0100 留著)| runtime v0148 | `%s` | **新**(科目對應排除部分 / 別口徑列 · 檢驗 UNCLEAR vs FAIL · 11 項)|\n") % (
    R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], rt["VRN2_UIAction_v0110.py"], rt["VRN2_ConsensusJoin_v0101.py"], rt["VRN2_HistoryAlign_v0102.py"])
src = src.replace(anchor, rows + anchor, 1)
once("## 7. 本輪(v0146 → v0147 + VRN2_RoundAll_v0100 · 操作員「generate a py code to handle all above and fix all test all debug all」)",
     "## 7. 本輪(v0147 → v0148 + VRN2_RoundAll_v0101 · 桌機 2026-10-29 14:40 第一次跑 RoundAll 的貼回)\n\n| # | 桌機看到的 | 根因 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | ③ UIAction v0109 --selftest ④ FAIL(容器過)| rerender() 讀殼的 VIA_ROOT → 自測真的重渲染 Workbench | UIAction v0110:自測先拿掉 VIA_ROOT / VRN2_* 再還原 | 容器設 VIA_ROOT:v0109 FAIL 重現 · v0110 7 項過 · 端到端殼有 VIA_ROOT 照綠 |\n"
     "| b | ⑥f 8 檔 Yahoo 404 `####.TW` · gate FAIL_CLOSED | 鉅亨對上櫃也回 TWS:#### → 引擎一律 .TW | ConsensusJoin v0101:市場冊對應表 + 引擎 shim · 同日快取用錯尾碼的重抓 | 自測 11 項(引擎原本 5274 → .TW · patch → .TWO · 離線 fixture .TWO 拿到 YFinance 中位數)|\n"
     "| c | ② 擷取 Python = `envs\\via_core.retired-…` | RoundAll 把 envs 下任何裝齊套件的夾都當候選 | RoundAll v0101 略過 retired / backup / bak / old / deprecated / archive | 自測 ⑫ · 端到端放一個退役夾 → 略過並列出 |\n"
     "| d | ⑬b 檢驗 534 不過 120 | 科目對錯列(其他營收 · 應付所得稅 · 負債與權益合計 · 少數 · 調整後 · 部門成長率)+ 成本負數 + 預估調整表三個值 | HistoryAlign v0102 | 自測 11 項 · 容器資料不過 74 / 218 → 5 / 192 |\n"
     "| e | PowerShell 裡 `python \"%USERPROFILE%\\…\"` 找不到檔 | %USERPROFILE% 只有 cmd 展開 | RoundAll v0101 最後印完整路徑的重跑指令;md 分 cmd / PowerShell 寫 | 自測 ⑮ |\n"
     "| f | 四點 FAIL / ⑥e 紅在主控台只有一行 | 證據只在貼回包 | RoundAll v0101 除錯報告印摘錄原文 · last_error 最後幾行 · Yahoo 404 / 上櫃數 | 自測 ⑬ ⑭ |\n"
     "| g | (建置)操作員一鍵 v0108 md 的歷史段落被改成 v0108 / v0147 | build147 對整份 md 做 .replace(\"v0107\", \"v0108\") | v0109 從 v0107 的 md 還原歷史段落(v0108 檔不改)| 讀 md 比對 |\n"
     "| — | 3014TT 第 3 點 FAIL → rc 1 · MS 四份現價 / 上漲 FAIL · ⑥e VDF 致命錯 · 缺年度 3 份 | 要原 PDF / 貼回包 | **沒修**(容器只有合成小 PDF;MS-3661 真檔在容器新跑是 PASS → 桌機的值來自擷取快取)| — |\n\n---\n\n"
     "## 7.0k 前一輪(v0146 → v0147 + VRN2_RoundAll_v0100 · 操作員「generate a py code to handle all above and fix all test all debug all」)")
once("| 0 | **(v0147)** 桌機跑一支 Python:", "| 0 | **(v0148)** 桌機貼 `vrn2_release_v0148/VRN2_RoundAll_v0101.md` 的一行(或 cmd:`python \"%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0101.py\"` · PowerShell:`python \"$env:USERPROFILE\\Downloads\\VRN2_RoundAll_v0101.py\"`)· 跑完**上傳 `Downloads\\VRN2_PasteBack_<時間>.zip`**(3014TT 第 3 點 · MS 四份 · VDF 致命錯都要它)| 貼回 zip |\n"
     "| 0a | **(v0148)** ⑥e VDF 引擎第一次會自己用 pip 建 `envs\\via_tw_fetch`(桌機這輪就在下載);建好後下一輪 RoundAll ② 就用它(不再碰退役環境)· 仍致命錯 → 看貼回包 `vrn2/market/vdf/last_error.txt`(VDF 的事,VRN-2 只讀)| 貼回 zip |\n"
     "| 0b | **(v0148)** 擷取快取:桌機「擷取沿用 52 / 52」—— 若 MS 四份的值是舊引擎留下的,要清這幾份的擷取快取再跑(先看貼回 zip 的 BasicInfo 再決定)| 貼回 zip |\n"
     "| 0 | **(v0147)** 桌機跑一支 Python:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0148)** **自測只能在乾淨的環境變數下判**:任何模組的 --selftest 都要先拿掉 VIA_ROOT / VRN2_ROOT / VRN2_OUTPUT_DIR / VRN2_INTEGRATE_* 等會改行為的變數再跑、結束還原;桌機的殼有 VIA_ROOT。\n"
     "- **(v0148)** **Yahoo 代號的上市 / 上櫃只信 VDF 身分表(市場冊 yfinance_ticker)**,不信鉅亨 symbol 的前綴(上櫃也回 TWS)。\n"
     "- **(v0148)** **擷取 Python 不用退役環境**:名字有 retired / backup / bak / old / deprecated / archive 的 envs 夾一律略過;via_tw_fetch 是 VDF 自己建的環境。\n"
     "- **(v0148)** **檢驗不過先看是不是科目對錯列**:其他 / 部門 / 應付 / 負債 / 少數 / 調整後 / 核心 這些列不是那個科目;同年同科目多個值(預估調整表)取報告裡重複出現的;差到不像同口徑標 UNCLEAR 不算不過。\n"
     "- **(v0148)** **建置腳本不要對整份 md 做版號取代**:歷史段落會被一起改掉(v0108 md 就這樣);只換程式碼區塊與指定的行。\n"
     "- **(v0148)** 給使用者的指令要分 cmd / PowerShell(`%USERPROFILE%` vs `$env:USERPROFILE`),或直接給完整路徑。\n\n")
(REPO / "VRN2_Handover_v0149.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0149 lines", src.count("\n"))
