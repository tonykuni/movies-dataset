"""ActivateVRN-2_v0148.py = v0147 + UIAction v0110 · ConsensusJoin v0101 · HistoryAlign v0102(桌機 2026-10-29 14:40 RoundAll 貼回)。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v147/new/ActivateVRN-2_v0147.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0147: v0146 entry + fixes found while building the one-file runner VRN2_RoundAll_v0100.py',
    '"""VRN-2 v0148: v0147 entry + fixes from the first desktop run of VRN2_RoundAll_v0100 (2026-10-29 14:40 · red 4 · yellow 10).\n\n'
    ' - ⑥c / ⑫b handler VRN2_UIAction_v0110: its --selftest clears VIA_ROOT / VRN2_* for the run (v0109\'s ④ failed on the desktop because the shell has VIA_ROOT,\n'
    '   so the selftest re-rendered the real Workbench); every action still goes to v0109.\n'
    ' - ⑥f VRN2_ConsensusJoin_v0101: TPEx stocks use .TWO on Yahoo. cnyes answers "TWS:####:STOCK" for TPEx stocks too, so the fusion engine (bundled unchanged)\n'
    '   asked Yahoo for 5274.TW / 5904.TW / 8358.TW / … → 404. The code → yfinance ticker map now comes from ⑥e\'s market book (VDF identity: TWSE .TW · TPEX .TWO) and the\n'
    '   engine runs through a shim that swaps its ticker function (same Python, same engine file, same arguments); same-day checkpoint payloads fetched with the wrong\n'
    '   suffix are re-fetched.\n'
    ' - ⑬b VRN2_HistoryAlign_v0102: item mapping ignores component / other-basis rows (Other Revenue · Taxes payable · Total liabs & equity · minorities · adjusted /\n'
    '   core · segment / business growth) and the add / multiply checks take |COGS|, accept ROE on average equity, take the value that recurs across a report\'s tables\n'
    '   (estimate-revision tables carry old / new / % change for the same year) and mark basis mismatches UNCLEAR instead of FAIL\n'
    '   (container data: 74 / 218 → 5 / 192 failing checks, the 5 being the deliberately contradicted synthetic history).\n'
    ' Runtime v0148 = runtime v0147 (178 members byte-identical) + VRN2_UIAction_v0110 + VRN2_ConsensusJoin_v0101 + VRN2_HistoryAlign_v0102.\n\n'
    'v0147: v0146 entry + fixes found while building the one-file runner VRN2_RoundAll_v0100.py')
rep('VERSION = "ActivateVRN-2 v0147"', 'VERSION = "ActivateVRN-2 v0148"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0147.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0148.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0147.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0148.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0147.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0148.json"')
rep('UI_HANDLER = "VRN2_UIAction_v0109.py"   # v0105 / v0107 are the desktop line\'s publish handlers in functional modules/VRN; this line went v0108 → v0109 (vrn2://integrate)',
    'UI_HANDLER = "VRN2_UIAction_v0110.py"   # v0105 / v0107 are the desktop line\'s publish handlers in functional modules/VRN; this line went v0108 → v0109 (vrn2://integrate) → v0110 (hermetic selftest)')
rep('HISTORY_ALIGN = "VRN2_HistoryAlign_v0101.py"   # v0147: thin tail over v0100 (Deleted only for same-magnitude contradictions)',
    'HISTORY_ALIGN = "VRN2_HistoryAlign_v0102.py"   # v0148: thin tail over v0101 (strict item mapping · checks UNCLEAR vs FAIL)')
rep('CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0100.py"', 'CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0101.py"   # v0148: thin tail over v0100 (TPEx → .TWO from the market book)')
rep('for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN):',
    'for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0100.py"):')
rep('launcher = root / "package" / "ActivateVRN-2_v0147.py"', 'launcher = root / "package" / "ActivateVRN-2_v0148.py"')
rep('return lamp, detail + " · launcher v0147"', 'return lamp, detail + " · launcher v0148"')
rep('print("NEXT: [%s] VRN-2 v0147 · rc %s', 'print("NEXT: [%s] VRN-2 v0148 · rc %s')
rep('''"run": {k: ran.get(k) for k in ("lamp", "why", "engine", "python", "codes", "codes_got", "codes_missing", "gate", "rc", "receipt") if k in ran}''',
    '''"run": {k: ran.get(k) for k in ("lamp", "why", "engine", "python", "codes", "codes_got", "codes_missing", "gate", "rc", "receipt", "yf_ticker_map", "yf_404") if k in ran}''')
# v0148 selftest block (before the v0147 PASS line)
rep('''    print("[PASS] v0147: OutputStore v0101 / DataIntegrate v0101 / HistoryAlign v0101''', '''    with tempfile.TemporaryDirectory(prefix="vrn2-v0148-check-") as temporary:
        folder = Path(temporary)
        root = folder / "VIA"
        runtime = root / "functional modules" / "VRN2"
        runtime.mkdir(parents=True)
        for name in (CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0100.py", HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", UI_HANDLER, "VRN2_UIAction_v0109.py", "VRN2_UIAction_v0108.py"):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        output = root / "VIA_Reports" / "vrn2"
        (output / "market").mkdir(parents=True)
        (output / "market" / "VRN2_Market_latest.json").write_text(json.dumps({"per_ticker": {"5274": {"yfinance_ticker": "5274.TWO"}}, "per_file": {"a.pdf": {"yfinance_ticker": "2330.TW"}}}), encoding="utf-8")
        cj = _load_runtime_module(runtime, CONSENSUS_JOIN, "vrn2_consensus_join_v0148_check")
        assert cj.VERSION == "v0101" and cj.ticker_map(output) == {"5274": "5274.TWO", "2330": "2330.TW"}
        ha = _load_runtime_module(runtime, HISTORY_ALIGN, "vrn2_history_align_v0148_check")
        assert ha.VERSION == "v0102" and ha.std_of("Other Revenue") == "" and ha.std_of("Total Revenue") == "revenue" and ha.std_of("Taxes payable") == ""
        ui = _load_runtime_module(runtime, UI_HANDLER, "vrn2_uiaction_v0148_check")
        assert ui.VERSION == "v0110" and "VIA_ROOT" in ui.SELFTEST_ENV_CLEAR and hasattr(ui, "patch_ui")
    print("[PASS] v0148: UIAction v0110 (hermetic selftest · patch_ui kept) · ConsensusJoin v0101 (TPEx .TWO from the market book) · HistoryAlign v0102 (strict item mapping)")
    print("[PASS] v0147: OutputStore v0101 / DataIntegrate v0101 / HistoryAlign v0101''')
(S / "v148/new").mkdir(parents=True, exist_ok=True)
(S / "v148/new/ActivateVRN-2_v0148.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0148 lines", s.count("\n"))
