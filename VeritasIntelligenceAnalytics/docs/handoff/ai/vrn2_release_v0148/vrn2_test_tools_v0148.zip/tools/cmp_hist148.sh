#!/bin/bash
# 歷史對齊 v0101 vs v0102 對照:同一份真實樣本年度數據(v0147 沙盒 14 份)+ 合成市場資料(只取 2025 以前 · 第一份淨利故意差 20%)
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; P=$S2/venv_vrn2/bin/python
for v in 0101 0102; do
  R=$S/v148/cmp_$v; rm -rf "${R:?}"; mkdir -p $R/VIA_Reports/vrn2/output $R/VIA_Reports/vrn2/market
  cp $S/v147/t147ra/VIA/VIA_Reports/vrn2/output/VRN2_FinancialData_latest.json $S/v147/t147ra/VIA/VIA_Reports/vrn2/output/VRN2_BasicInfo_latest.json $R/VIA_Reports/vrn2/output/
  $P $S/v148/mk_market148.py $R/VIA_Reports/vrn2
  d=$S/v148/new; [ $v = 0101 ] && d=$S/v147/new
  (cd $d && $P VRN2_HistoryAlign_v$v.py align --root $R)
done
$P - <<'PY'
import json, collections
S = "/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v148"
out = {}
for v in ("0101", "0102"):
    j = json.load(open(f"{S}/cmp_{v}/VIA_Reports/vrn2/VRN2_HistoryAlign_latest.json", encoding="utf-8"))
    c = collections.Counter(x["verdict"] for f in j["files"].values() for x in f.get("checks") or [])
    out[v] = {"totals": j["totals"], "verdicts": dict(c), "why": j["why"]}
    print(v, j["why"])
json.dump(out, open(f"{S}/cmp_hist148.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
PY
