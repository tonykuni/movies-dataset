VRN2_Closeout_v0148 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0148.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0101.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.
Runtime: VRN2_Runtime_v0148.zip = runtime v0147 (178 members byte-identical) + VRN2_UIAction_v0110 + VRN2_ConsensusJoin_v0101 + VRN2_HistoryAlign_v0102,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0148 (first desktop run of VRN2_RoundAll_v0100 · 2026-10-29 14:40 · red 4 · yellow 10):
 - ⑥c / ⑫b handler UIAction v0110: --selftest clears VIA_ROOT / VRN2_* while testing (v0109's ④ failed on the desktop because the shell has VIA_ROOT).
 - ⑥f ConsensusJoin v0101: TPEx stocks use .TWO on Yahoo (cnyes answers TWS:#### for TPEx too → the engine asked Yahoo for ####.TW → 404 for 5274 / 5904 / 8358 /
   4966 / 7728 / 6147 / 3264 / 6143). Code → ticker map from the market book; the bundled engine is unchanged and runs through a shim; stale same-day payloads re-fetched.
 - ⑬b HistoryAlign v0102: item mapping ignores other / segment / payable / liabilities / minority / adjusted / core rows; checks take |COGS|, accept ROE on average
   equity, use the value that recurs across a report's tables, and mark basis mismatches UNCLEAR instead of FAIL.
Verification: see VRN2_Verification_v0148.md. Hashes: PACKAGE_SHA256.json.
