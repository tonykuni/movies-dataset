"""VRN2_Handover_v0136.md = v0135 交接報告(MAIN)+ v0136(整合一支 · 第二回:驗證器 v0105 + ⑫a VRN-1 倉同步)· 逐行錨點替換 · 冪等。
用法:python make_handover_v0136.py <v0135.md> <結果 json> <輸出 md>"""
import json
import re
import sys
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
R = json.loads(res_p.read_text(encoding="utf-8"))
lines = src.read_text(encoding="utf-8").split("\n")


def one(prefix):
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    assert len(hits) == 1, (prefix[:40], len(hits))
    return hits[0]


def sub(prefix, new):
    i = one(prefix)
    lines[i] = new(lines[i]) if callable(new) else new


def before(prefix, extra):
    i = one(prefix)
    lines[i:i] = extra


sub("# VRN-2 交接報告 · ActivateVRN-2 v0135 · 2026-10-21(",
    "# VRN-2 交接報告 · ActivateVRN-2 v0136 · 2026-10-21(整合一支 · 第二回:操作員「integrate INTO ONE CODE TO HANDLE ALL ABOVE」—— 獨立驗證器 v0105(DUPKEY 看位置證據只標不對位那筆 · 目標價 / 現價對調直接說 · EPS 不符印年度數據那一格 · 貼給 AI 的摘要每類錯值都出現)· ⑫a 借工具前自己把 VRN-1 的本機倉 fast-forward 到它的 main · v0102 / v0103 / v0104 留著 · 處理器 / 管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋一個位元組都不動 · 其餘同 v0135)")
before("> **本輪(v0135 · 啟動器 + 獨立驗證器 VRN2_IndependentVerifier_v0104",
       ["> **本輪(v0136 · 啟動器 + 獨立驗證器 VRN2_IndependentVerifier_v0105 · 交接報告 v0136 · 處理器 / 管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋一個位元組都不動)**:操作員在 v0135 合併後再令「integrate INTO ONE CODE TO HANDLE ALL ABOVE」。v0135 之後還留著的四件,全部整進同一支啟動器:"
        "① **DUPKEY 82**:Windows 那份 ⑪ 的 82 筆同鍵不同值,一行都沒進「貼給 AI」—— 摘要 150 行的上限先被基本資料 25 筆 + BADITEM 吃掉。v0105 摘要改成每一類錯值先各印 6 筆再補滿,而且 DUPKEY 看位置證據:同鍵兩個值裡只有一個對位(ALIGNED / SUBALIGNED / TRANSALIGNED)→ 那筆保留判決、另一筆才是錯值(⑫ PIVOT 只收對位的格,所以對的那筆進得了 PIVOT);都對位 / 都不對位 → 分不出,照舊兩筆都 DUPKEY。"
        "② **標籤對調 3 筆**(MS-6669 現價在目標價標籤旁 · GS-2317 目標價旁沒標籤 · 神達上漲空間在目標價標籤旁):v0105 `_swap_hint` 在目標價 / 現價不在自己標籤旁時再看是不是在對方的標籤旁,訊息直接寫「對調」「現價被填成目標價」「可能把目標價當成現價」—— 值仍 FAIL(照實),擷取端下一輪就有明確證據。"
        "③ **MS-6669 EPS**(一標題四重點 2025 年 EPS 251.50 不是年度數據的值):v0105 `_eps_ok` 不符時把年度數據同年度那一格印出來(「年度數據 2025 年 EPS 是 EPS (NT$) 2025E=…」),摘要器下一輪就知道該用哪一格。"
        "④ **⑫ 要操作員手動 `git switch main; git pull`**:v0136 啟動器 ⑫a 在借工具前自己做 —— 找 VRN-1 的本機倉(VIA_VRN1_ROOT · C:\\Users\\tonyk\\VIA-VDF-VRN · 家目錄 · VIA 倉旁邊),已追蹤的檔沒改動才動:fetch origin main → 不在 main 就 switch main(原分支名印在說明 · `git switch -` 切得回)→ `merge --ff-only`;有改動 / 沒網路 / 分岔 → 不動、照實說,⑫ 照舊。只 fast-forward、不改寫歷史、不提交、不推(四系統各自獨立)。`VIA_VRN2_NO_VRN1_SYNC=1` 不同步。"
        "實測:驗證器 v0105 自測 %s · %s · 啟動器 %s · %s · %s · %s。" % (R["selftest_iv"], R["verifier_regress"], R["selftest"], R["e2e"], R["oneclick"], R["ui"])])
sub("> **本輪(v0135 · 啟動器 + 獨立驗證器 VRN2_IndependentVerifier_v0104", lambda l: l.replace("> **本輪(v0135", "> **前一輪(v0135", 1))
sub("> **前一輪(v0134 · 啟動器 + 處理器 VRN2_UIAction_v0104", lambda l: l.replace("> **前一輪(v0134", "> **v0134(", 1))
sub("| **啟動器(MAIN)** |", lambda l: l.replace("v0135", "v0136"))
sub("| **獨立驗證器** |", "| **獨立驗證器** | `<ROOT>\\functional modules\\VRN\\VRN2_IndependentVerifier_v0105.py` | v0136 落地(v0102 / v0103 / v0104 留著 · ⑪ 取最新版)· DUPKEY 看位置證據 `_ALIGNED_V` · 對調診斷 `_swap_hint` · EPS 不符印年度數據那一格 · 摘要每類錯值都出現 · 其餘同 v0104(空值記號看該格 · 字距 · 標籤旁前 4 頁 · 上漲空間推算 · 覆蓋率去標點 · 科目名去 * $)|")
sub("| **交接報告** |", lambda l: l.replace("VRN2_Handover_v0135.md", "VRN2_Handover_v0136.md"))
sub("| 本輪證據 |", lambda l: l.replace("`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0135\\`(v0134:", "`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0136\\`(v0135:`vrn2_release_v0135\\` · v0134:", 1))
sub("### 3.1 現役版本(v0135 內嵌", "### 3.1 現役版本(v0136 內嵌 · 依序自動落地)")
sub("| ActivateVRN-2.py | **v0135** |", lambda l: re.sub(r"\| [^|]*\|$", "| **新**(= v0135 + 內嵌獨立驗證器 v0105 + ⑫a VRN-1 倉同步;其餘元件逐位元組相同)|", l.replace("**v0135**", "**v0136**", 1)))
before("| **VRN2_IndependentVerifier** | **v0104**(v0102 / v0103 留著)|",
       ["| **VRN2_IndependentVerifier** | **v0105**(v0102 / v0103 / v0104 留著)| 94,467 | `%s` | **新**(v0104 + DUPKEY 位置證據 · 對調診斷 · EPS 格 · 摘要每類都出現 · 自測 %s)|" % (R.get("iv_sha12", "見發行清單"), R["selftest_iv"].split("(")[0].strip())])
sub("| **VRN2_IndependentVerifier** | **v0104**(v0102 / v0103 留著)|", lambda l: re.sub(r"\| \*\*新\*\*\([^|]*\|$", "| v0135 內嵌 · 留著 |", l))
before("## 7. 本輪修正(v0134 → v0135 · Codex #561)",
       ["## 7. 本輪修正(v0135 → v0136 · 整合一支 第二回)", "",
        "| # | v0135 之後還留著的 | 做法(都在啟動器 v0136 內嵌的元件裡) | 實測 |", "|---|---|---|---|",
        "| 1 | DUPKEY 82 筆一行都沒進「貼給 AI」(摘要 150 行先被基本資料 25 筆 + BADITEM 吃掉)| 驗證器 v0105 摘要:每一類錯值先各印 6 筆(標題 + 檔分佈)再補滿 150 行;基本資料不過的只印 16 筆 + 一行「另有 n 筆」 | 自測:BADITEM 60 + DUPKEY 60 兩類都在 · ≤ 150 行 |",
        "| 2 | DUPKEY 兩筆都標錯值,分不出哪筆對 | v0105 `dupkey` 看位置證據:同鍵只有一個值對位 → 那筆保留判決(註記)、另一筆 DUPKEY(註記對位的值是多少);都對位 / 都不對位 → 照舊兩筆都 DUPKEY | 自測 3 種組合 · 容器同一本冊判決逐類相同 |",
        "| 3 | 標籤對調 3 筆(MS-6669 · GS-2317 · 神達)只寫「但旁邊是目標價標籤」 | v0105 `_swap_hint`:目標價在股價標籤旁且現價在目標價標籤旁 → 「對調」· 同值在目標價標籤旁 → 「現價被填成目標價」· 單邊 → 「可能把 … 當成 …」;值仍 FAIL | 自測 5 種組合 |",
        "| 4 | MS-6669 一標題四重點 EPS 不是年度數據的值,沒說年度數據是多少 | v0105 `_eps_ok` 不符時印「年度數據 2025 年 EPS 是 EPS (NT$) 2025E=…」 | 自測 |",
        "| 5 | ⑫ 灰:要操作員手動 `cd VIA-VDF-VRN; git switch main; git pull` | 啟動器 v0136 ⑫a:借工具前自己 fetch + fast-forward 到 VRN-1 的 main(已追蹤檔沒改動才動 · 原分支名印出 · 不改寫歷史 · 不提交 · 不推 · `VIA_VRN2_NO_VRN1_SYNC=1` 不同步)| 啟動器自測 git 夾具(feature 落後 1 → main 最新 · 改過 → 黃不動 · 關閉 → 灰)· %s |" % R["selftest"],
        "| 6 | 回歸 | %s | — |" % R["verifier_regress"],
        "| 7 | 端到端 | %s | %s |" % (R["e2e"], R["ui"]),
        "| 8 | 一鍵 | %s | — |" % R["oneclick"],
        "| 9 | 沒動(照實說)| 對調 / DUPKEY 另一筆 / EPS 用錯格 的**根因在擷取 / 摘要器**(ENG397 · ENG062 · 管理器),本輪只把證據寫清楚;修擷取端要等 Windows 用 v0136 跑一次、把帶證據的摘要貼回來 | — |",
        "", "---", ""])
sub("## 7. 本輪修正(v0134 → v0135 · Codex #561)", "## 7.0e v0134 → v0135(Codex #561 / #562)")
i = one("| 0 | **使用者用 v0135 的一行跑**")
old0 = lines[i].replace("| 0 |", "| 0b |", 1).replace("| 待執行 |", "| 被 v0136 取代(v0135 已合併 MAIN · 可跑,但 ⑪ 是驗證器 v0104、⑫ 要手動 pull)|", 1)
lines[i] = "| 0 | **使用者用 v0136 的一行跑**(`vrn2_release_v0136/VRN2_OneClick_v0136.md`)| 待執行 | 預期:U/I 自己跳出 · ⑪ 用驗證器 v0105 → 「貼給 AI」會有 DUPKEY 的例子(每類至少 6 筆)、對調的 3 筆寫明哪種對調、MS-6669 EPS 寫出年度數據那一格 · ⑫a 自己把 VIA-VDF-VRN fast-forward 到 main → ⑫ 應轉綠(借到 PIVOT 工具)。貼回 ⑪ 驗證摘要 + ⑫a / ⑫ 兩行。 |"
lines[i + 1:i + 1] = [old0]
sub("| 0b | **使用者用 v0134 的一行跑**", lambda l: l.replace("| 0b |", "| 0c |", 1))
sub("| 0c | **使用者用 v0133 的一行跑**", lambda l: l.replace("| 0c |", "| 0d |", 1))
sub("一鍵(取得 v0135 →", lambda l: l.replace("取得 v0135", "取得 v0136", 1).replace("執行(啟動器自己跑 ①~⑫ · 開 U/I)", "執行(啟動器自己跑 ①~⑫ · ⑫a 同步 VRN-1 倉 · 開 U/I)", 1))
before("- **驗證器放寬要看該格(Codex #561 / #562)**",
       ["- **錯值要全部看得到**:貼給 AI 的摘要每一類錯值都要出現(先各印幾筆再補滿),不能讓前面的類別把後面的擠掉 —— DUPKEY 82 筆隱形了一整輪。",
        "- **同鍵不同值用位置證據分**:對位的那筆是對的、保留;不對位的才是錯值;分不出就兩筆都標。",
        "- **借別的系統的倉前先同步它的 main(只 fast-forward)**:乾淨才動、不改寫歷史、不提交、不推;動了就把原分支名印出來。"])
out.write_text("\n".join(lines), encoding="utf-8", newline="\n")
print("[計] %s · %d 字" % (out.name, len("\n".join(lines))))
