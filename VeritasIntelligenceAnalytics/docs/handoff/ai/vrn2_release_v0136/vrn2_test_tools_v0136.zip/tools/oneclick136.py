"""一鍵 v0136:從 MAIN 的 VRN2_OneClick_v0135.md 取程式碼與 boot → 換版號 · $Want = 啟動器 v0136 SHA-256 · 驗證器 v0105 → Run-VRN2-v0136.ps1 + VRN2_OneClick_v0136.md + boot136.ps1 + oneline136.txt(冪等)。
用法:python oneclick136.py <MAIN 的 VRN2_OneClick_v0135.md> <ActivateVRN-2 v0136 SHA-256> <輸出夾>"""
import base64, hashlib, re, sys
from pathlib import Path
src, want, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]); assert re.fullmatch(r"[0-9a-f]{64}", want); out.mkdir(parents=True, exist_ok=True)
md = src.read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
assert base64.b64decode(one.split()[-1]).decode("utf-16-le") == boot + "\n"
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); ps = ps.replace(old_want, want)
n = ps.count("v0135"); ps = ps.replace("v0135", "v0136")
n3 = ps.count("驗證器 v0104"); assert n3 == 1, n3; ps = ps.replace("驗證器 v0104", "驗證器 v0105")
def rep(a, b):
    global ps; assert ps.count(a) == 1, (ps.count(a), a[:80]); ps = ps.replace(a, b)
rep("# ===== VRN-2 一鍵 v0136(啟動器 v0136 Codex #561 修正:驗證器 v0105 空值記號看該格 · 字距只接逗點 / 小數點後的空白;",
    "# ===== VRN-2 一鍵 v0136(啟動器 v0136 整合一支 第二回:驗證器 v0105 DUPKEY 位置證據 · 對調診斷 · EPS 格 · 摘要每類都出現 · ⑫a 借工具前 fast-forward VRN-1 的倉;v0135 Codex #561 修正:驗證器 v0104 空值記號看該格 · 字距只接逗點 / 小數點後的空白;")
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1); boot = boot.replace(h_old, cs).replace("v0135", "v0136") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
old_code = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); old_boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); old_one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
md = md.replace(old_code, "@PS@").replace(old_boot, "@BOOT@").replace(old_one, "@ONE@")
md = re.sub(r"[0-9a-f]{64}", want, md, count=1)
md = md.replace("v0135", "v0136").replace("驗證器 v0104", "驗證器 v0105")
a = "# VRN-2 一鍵 v0136(cmd / PowerShell 都能貼 · 啟動器 v0136 = v0134 + Codex #561 修正:驗證器 v0105 · 處理器 v0104 · U/I 自己跳出 · ⑨ 交接不回退)"; assert md.count(a) == 1, md.count(a)
md = md.replace(a, "# VRN-2 一鍵 v0136(cmd / PowerShell 都能貼 · 啟動器 v0136 = v0135 + 整合一支 第二回:驗證器 v0105 · ⑫a 自己同步 VRN-1 的倉 · 處理器 v0104 · U/I 自己跳出 · ⑨ 交接不回退)")
a = "v0136 = v0134 + Codex #561 修正(PR #561 合併後)"; assert md.count(a) == 1
md = md.replace(a, "v0136 = v0135 + 整合一支 第二回(操作員「integrate INTO ONE CODE TO HANDLE ALL ABOVE」):獨立驗證器 v0105 —— DUPKEY 看位置證據只標不對位那筆 · 目標價 / 現價對調直接說 · EPS 不符印年度數據那一格 · 貼給 AI 的摘要每類錯值都出現;啟動器 ⑫a 借工具前自己把 VIA-VDF-VRN fast-forward 到 main(乾淨才動 · 不改寫歷史 · 不提交 · 不推);一鍵流程、處理器 v0104、主體都同 v0135。\nv0135 = v0134 + Codex #561 修正(PR #561 合併後)")
md = md.replace("| 步驟 | v0134 改了什麼(v0136 同 · 只換驗證器)|", "| 步驟 | v0134 改了什麼(v0135 / v0136 同 · 只換驗證器、加 ⑫a)|")
md = re.sub(r"程式碼 SHA-256\(本文 · 一行核對的就是這個\):`[0-9a-f]{12}", "程式碼 SHA-256(本文 · 一行核對的就是這個):`" + cs[:12], md)
md = md.replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n")).replace("@ONE@", one)
assert re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) == ps and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot
assert "vrn2_release_v0136" in boot and "VRN2_OneClick_v0136.md" in boot and "v0135" not in boot
(out / "VRN2_OneClick_v0136.md").write_text(md, encoding="utf-8", newline="\n"); (out / "boot136.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline136.txt").write_text(one + "\n", encoding="utf-8"); (out / "Run-VRN2-v0136.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("launcher %s · code %s · one-liner %d 字 · md %d · 換版號 %d 處" % (want[:12], cs[:12], len(one), len(md), n))
