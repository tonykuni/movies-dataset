#!/bin/bash
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
cd $S/v136 || exit 9
rm -f scen.rc; bash tools/scen136.sh > scen_driver.log 2>&1; echo "scen: $(cat scen.rc)"
sed -e 's/\x1b\[[0-9;]*m//g' scen_oneclick.log | grep -E "③ |⑦ 啟動|⑧ 完成|⑪ 獨立驗證\(|⑫a|⑫ PIVOT 資料庫\(借用 VRN-1\) · |⑫b|註冊核對|⑤b|⑤c|NEXT|SHA-256|IndependentVerifier_v01" | cut -c1-200
cd $S2/tools && node ui_test.js "$S/v136/t136oc/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $S/v136/shots_oc "$S/v136/t136oc/VIA/VIA_Reports/vrn2/output" > $S/v136/ui_test.log 2>&1; echo "ui_test rc=$?"; grep -E "FAIL|\[計\]" $S/v136/ui_test.log | cut -c1-160
node $S/v136/tools/ui_input.js "$S/v136/t136oc/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $S/v136/shots_input_oc "samples" > $S/v136/ui_input_oc.log 2>&1; echo "ui_input rc=$?"; grep -E "FAIL|\[計\]" $S/v136/ui_input_oc.log | cut -c1-160
echo "SCEN UI DONE"
