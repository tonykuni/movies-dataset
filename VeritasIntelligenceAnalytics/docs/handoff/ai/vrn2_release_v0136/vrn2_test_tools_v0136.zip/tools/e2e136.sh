#!/bin/bash
# v0136 e2e:沙盒樹 · 啟動器 v0136 · VRN-1 = 本機倉(⑫ 借得到)· OCR 隔離環境是真的
#   A1:預設來源(環境 VIA_VRN_INPUT = samples 19 份)· 完整跑 → ②b / ⑫b / U/I 輸入區塊 / VRN2_Input_latest.json
#   P1:U/I「選擇檔案夾」(測試掛鉤 · 子集 5 個股 + 1 範圍外 + txt / docx / png)→ 重跑不帶環境變數 → ②b 用 U/I 選的 · 範圍夾只剩 5 份
#   P2:U/I「選擇檔案」(掛鉤 2 PDF + 1 txt → 複製到暫存夾)→ 重跑 → ②b 來源 = 暫存夾
#   R:cat=industry → 拒絕(尚未開放)· audit:重新稽核
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v136; T=$W/t136
OCRPY=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/bin/python
OCRBR=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/VRN2_OCRBridge_v0100.py
P=$S/venv_vrn2/bin/python
: > $W/e2e.rc
cd /tmp && $S/tools/mktree.sh $T $W/ActivateVRN-2_v0136.py > $W/e2e_setup.log 2>&1
V="$T/VIA/functional modules/VRN"
mkdir -p $T/pick_sub
for f in "JP-2330 20250718.pdf" "GS-6415 20260517.pdf" "MS-2308 20251128.pdf" "凱基投顧_2637 慧洋-KY_賴偉中_20260915.pdf" "晶心科(6533,N,中立)-CTBC251208.pdf" "20260916兆豐台灣產業專題-航太產業.pdf"; do cp "$T/samples/$f" "$T/pick_sub/"; done
printf '環球晶 6488\n' > $T/pick_sub/note.txt; printf 'PK' > $T/pick_sub/memo.docx; printf '\x89PNG' > $T/pick_sub/scan.png
go() {   # $1 = 名稱 · $2 = 額外環境(VAR=value · 可空)
  cd "$T/Downloads" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VIA_ENVS_HOME="$T/envs" VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$OCRBR" \
    PYTHONDONTWRITEBYTECODE=1 VIA_VRN1_ROOT=/home/user/via-vdf-vrn $2 timeout 3500 $P ActivateVRN-2.py --no-install > $W/e2e_$1.log 2>&1
  echo "$1 rc $?" >> $W/e2e.rc
  sed -i 's/\x1b\[[0-9;]*m//g' $W/e2e_$1.log
}
ua() {   # $1 = 名稱 · $2 = vrn2:// 網址 · 其餘 = 環境
  local n=$1 u=$2; shift 2
  cd "$V" && env VIA_NO_OPEN=1 PYTHONDONTWRITEBYTECODE=1 "$@" $P -W ignore VRN2_UIAction_v0104.py "$u" > $W/e2e_$n.log 2>&1
  echo "$n rc $?" >> $W/e2e.rc
}
go A1 "VIA_VRN_INPUT=$T/samples"
cp "$T/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $W/ui_A1.html
ua P1pick "vrn2://pick?kind=folder&cat=stock" VRN2_PICK_PATH=$T/pick_sub
cp "$T/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $W/ui_after_pick.html
go P1 ""
cp "$T/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $W/ui_P1.html
ua P2pick "vrn2://pick?kind=files&cat=stock" "VRN2_PICK_FILES=$T/samples/Citi-3231 20250604(20261006-122410).pdf|$T/samples/Daiwa-1319 20231011(20261006-122413).pdf|$T/pick_sub/note.txt"
go P2 ""
cp "$T/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $W/ui_P2.html
ua R "vrn2://pick?kind=folder&cat=industry"
ua R2 "vrn2://pick?kind=files&cat=other"
ua audit "vrn2://audit"
cp "$T/VIA/VIA_Reports/vrn2/VRN2_Input_latest.json" $W/input_final.json 2>/dev/null
cp "$T/VIA/VIA_Reports/vrn2/VRN2_Input_History.jsonl" $W/input_history.jsonl 2>/dev/null
echo done >> $W/e2e.rc
