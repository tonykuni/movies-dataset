"""VRN2_IndependentVerifier_v0105 = v0104 + 操作員 2026-10-21「integrate into one code to handle all above」留下的四件(錨點替換 · 只增):
用法:python make_verifier_v0105.py <v0104.py> <輸出 v0105.py>
  ① DUPKEY 82:同鍵兩個值時看位置證據 —— 只有一個值對位(ALIGNED / SUBALIGNED / TRANSALIGNED)→ 那筆保留判決、另一筆才是 DUPKEY(錯值);都對位 / 都不對位 → 照舊兩筆都 DUPKEY
  ② 標籤對調 3 筆:基本資料目標價 / 現價不在自己標籤旁時,再看它是不是在「對方」的標籤旁 → 訊息直接寫「對調」「現價被填成目標價」
  ③ MS-6669 EPS:一標題四重點的 EPS 不是年度數據同年度的值時,把年度數據那一格印出來(擷取 / 摘要器下一輪就有證據)
  ④ 貼給 AI 的摘要:每個錯值類別都要出現(先每類 6 筆、再補到 150 行)—— Windows 那份 DUPKEY 82 筆一行都沒進摘要"""
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:80])
    s = s.replace(a, b)


rep('"""VRN2_IndependentVerifier_v0104 — VRN-2 輸出值獨立驗證(v0104:',
    '"""VRN2_IndependentVerifier_v0105 — VRN-2 輸出值獨立驗證(v0105:DUPKEY 看位置證據只標不對位那筆 · 目標價 / 現價對調直接說 · EPS 不符印年度數據那一格 · 摘要每類錯值都出現;v0104:')
rep('VERSION = "VRN2_IndependentVerifier_v0104"', 'VERSION = "VRN2_IndependentVerifier_v0105"')

# ① DUPKEY 位置證據
rep('''    out = []
    for r in vf:
        vs = g[k_(r)]
        if len(vs) > 1:
            r = dict(r, _V="DUPKEY", _N="同一列同科目同期間有 %d 個不同的值:%s" % (len(vs), " / ".join(sorted(vs))[:80]))
        elif cnt[k_(r)] > 1:
''', '''    al = defaultdict(set)                                        # v0105 同鍵裡「對位」的值(位置證據)
    for r in vf:
        if r.get("_V") in _ALIGNED_V:
            al[k_(r)].add(squash(r.get("VALUE", "")))
    out = []
    for r in vf:
        vs = g[k_(r)]
        if len(vs) > 1:
            av = al[k_(r)]
            if len(av) == 1 and r.get("_V") in _ALIGNED_V:        # v0105 只有這個值對位 → 保留判決 · 註記同鍵另有不對位的值
                r = dict(r, _N="%s · 同鍵另有 %d 個值不對位(%s)· 這筆對位保留" % (r.get("_N", ""), len(vs) - 1, " / ".join(sorted(vs - av))[:60]))
            elif len(av) == 1:
                r = dict(r, _V="DUPKEY", _N="同鍵對位的值是 %s · 這筆 %s 不對位(%s)→ 錯值" % (" / ".join(sorted(av)), squash(r.get("VALUE", "")), r.get("_V", "")))
            else:
                r = dict(r, _V="DUPKEY", _N="同一列同科目同期間有 %d 個不同的值:%s(對位 %d 個 · 分不出)" % (len(vs), " / ".join(sorted(vs))[:80], len(av)))
        elif cnt[k_(r)] > 1:
''')
rep('''def dupkey(vf):
    """一致性(跟讀法無關):同檔 · 同表 · 同一列(ROW · 沒有就用段落)· 同科目 · 同期間 · 同子欄 只能有一個值 → 兩個以上不同的值 = DUPKEY(兩種讀法一致地讀錯欄也抓得到)。"""''',
    '''_ALIGNED_V = ("ALIGNED", "SUBALIGNED", "TRANSALIGNED")


def dupkey(vf):
    """一致性(跟讀法無關):同檔 · 同表 · 同一列(ROW · 沒有就用段落)· 同科目 · 同期間 · 同子欄 只能有一個值 → 兩個以上不同的值 = DUPKEY(兩種讀法一致地讀錯欄也抓得到)。
    v0105:同鍵裡只有一個值對位(位置證據)→ 那筆保留判決、其餘才是 DUPKEY;都對位 / 都不對位 → 分不出,兩筆都 DUPKEY(照舊)。"""''')

# ② 標籤對調
rep('''        for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
            v = x.get(k, "")
            if v:                                                # v0100 要在自己的標籤旁(目標價 / 股價對調會被抓到)
                okl, why = near_label(pdf, v, k)
                put(k, okl, why)
''', '''        for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
            v = x.get(k, "")
            if v:                                                # v0100 要在自己的標籤旁(目標價 / 股價對調會被抓到)
                okl, why = near_label(pdf, v, k)
                put(k, okl, why)
        tp_, cp_ = x.get("TARGET_PRICE", ""), x.get("CURRENT_PRICE_REPORT", "")
        if tp_ and cp_ and (chk.get("TARGET_PRICE", "").startswith("FAIL") or chk.get("CURRENT_PRICE_REPORT", "").startswith("FAIL")):   # v0105 對調直接說
            hint = _swap_hint(near_label(pdf, tp_, "CURRENT_PRICE_REPORT")[0], near_label(pdf, cp_, "TARGET_PRICE")[0], tp_, cp_)
            if hint:
                for k in ("TARGET_PRICE", "CURRENT_PRICE_REPORT"):
                    if chk.get(k, "").startswith("FAIL"):
                        chk[k] = "FAIL · " + hint + " · " + chk[k][7:]
''')
rep('''def verify_basic(rows, pdfdir):
''', '''def _swap_hint(tp_near_price, cp_near_tp, tp, cp):
    """v0105 目標價 / 現價不在自己標籤旁時的診斷:目標價在股價標籤旁且現價在目標價標籤旁 → 對調;兩個值相同且現價在目標價標籤旁 → 現價被填成目標價;
    只有現價在目標價標籤旁 → 可能把目標價當成現價;只有目標價在股價標籤旁 → 可能把現價當成目標價。回一句(沒有 → "")。"""
    same = _numv(re.sub(r"[^\\d.,]", "", str(tp)).strip(".,")) == _numv(re.sub(r"[^\\d.,]", "", str(cp)).strip(".,"))
    if tp_near_price and cp_near_tp:
        return "目標價 / 現價對調(目標價 %s 在股價標籤旁 · 現價 %s 在目標價標籤旁)" % (tp, cp)
    if cp_near_tp and same:
        return "現價被填成目標價(兩個值都是 %s · 在目標價標籤旁)" % cp
    if cp_near_tp:
        return "現價 %s 在目標價標籤旁(可能把目標價當成現價)" % cp
    if tp_near_price:
        return "目標價 %s 在股價標籤旁(可能把現價當成目標價)" % tp
    return ""


def verify_basic(rows, pdfdir):
''')

# ③ EPS 不符時印年度數據那一格
rep('''    if eps_rows:                                                 # 年度數據有 EPS → 一定要同年度那一格(別年的 EPS 也在原文 EPS 那一列 · 不能用來過)
        return False, ""
''', '''    if eps_rows:                                                 # 年度數據有 EPS → 一定要同年度那一格(別年的 EPS 也在原文 EPS 那一列 · 不能用來過)
        same_y = [r for r in eps_rows if yy in str(r.get("PERIOD", "")) or re.search(r"(?<!\\d)%s(?!\\d)" % yy[2:], str(r.get("PERIOD", "")))]
        return False, "年度數據 %s 年 EPS 是 %s" % (yy, " / ".join("%s %s=%s" % (str(r.get("ITEM", ""))[:18], r.get("PERIOD", ""), r.get("VALUE", "")) for r in same_y[:3]) or "(同年度沒有 EPS 格)")   # v0105
''')
rep('''                ok_e, why_e = _eps_ok(m.group(2), m.group(1), pdf, fin)
                if not ok_e:
                    bad.append("%s 年 EPS %s 不是年度數據 / 原文 EPS 那一列的值" % (m.group(1), m.group(2)))
''', '''                ok_e, why_e = _eps_ok(m.group(2), m.group(1), pdf, fin)
                if not ok_e:
                    bad.append("%s 年 EPS %s 不是年度數據 / 原文 EPS 那一列的值%s" % (m.group(1), m.group(2), (" · " + why_e) if why_e else ""))
''')

# ④ 摘要每類都出現
rep('''    for nm, rs in (("基本資料", vb), ("一標題四重點", vs)):
        bad = [(r["FILENAME"], k, v) for r in rs for k, v in r["checks"].items() if not v.startswith("PASS")]
        for f_, k, v in bad[:25]:
            L.append("  %s %s · %s · %s" % (nm, f_[:44], k, v[:110]))
    for cat in BADV + ("OCR", "PRESENT"):
        xs = [r for r in vf if r["_V"] == cat]
        if not xs:
            continue
        why = _C(re.sub(r"[\\d.,]+", "#", r["_N"])[:40] for r in xs)
        L.append("年度數據 %s %d 筆 · 理由前 3:%s" % (cat, len(xs), " | ".join("%s ×%d" % kv for kv in why.most_common(3))))
        byf = _C(r["FILENAME"] for r in xs)
        L.append("  檔:%s" % " · ".join("%s ×%d" % (f_[:30], n) for f_, n in byf.most_common(6)))
        for r in xs[:12 if cat in BADV else 4]:
            L.append("  %s | %s | %s | %s | %s | %s | %s" % (r["FILENAME"][:30], r.get("TABLE", ""), str(r.get("ITEM", ""))[:22], r.get("PERIOD", ""), r.get("SUBCOL", ""), r.get("VALUE", ""), r["_N"][:90]))
    Path(path).write_text("\\n".join(L[:150]) + "\\n", encoding="utf-8")
    return L[:150]
''', '''    for nm, rs in (("基本資料", vb), ("一標題四重點", vs)):
        bad = [(r["FILENAME"], k, v) for r in rs for k, v in r["checks"].items() if not v.startswith("PASS")]
        for f_, k, v in bad[:16]:                                   # v0105 16 筆(原 25):把行數留給年度數據的每一類
            L.append("  %s %s · %s · %s" % (nm, f_[:44], k, v[:110]))
        if len(bad) > 16:
            L.append("  %s 另有 %d 筆不過(完整在報告 json)" % (nm, len(bad) - 16))
    heads, rows_by = [], {}
    for cat in BADV + ("OCR", "PRESENT"):
        xs = [r for r in vf if r["_V"] == cat]
        if not xs:
            continue
        why = _C(re.sub(r"[\\d.,]+", "#", r["_N"])[:40] for r in xs)
        byf = _C(r["FILENAME"] for r in xs)
        heads.append(("年度數據 %s %d 筆 · 理由前 3:%s" % (cat, len(xs), " | ".join("%s ×%d" % kv for kv in why.most_common(3))), "  檔:%s" % " · ".join("%s ×%d" % (f_[:30], n) for f_, n in byf.most_common(6))))
        rows_by[cat] = ["  %s | %s | %s | %s | %s | %s | %s" % (r["FILENAME"][:30], r.get("TABLE", ""), str(r.get("ITEM", ""))[:22], r.get("PERIOD", ""), r.get("SUBCOL", ""), r.get("VALUE", ""), r["_N"][:90]) for r in xs[:12 if cat in BADV else 4]]
    # v0105 先讓每一類都出現(標題 + 檔 + 前 6 筆)· 行數還有剩再補到每類 12 筆 → 任何一類(DUPKEY 82 那種)都不會被前面的類別擠掉
    cats = [h[0].split(" ")[1] for h in heads]
    for (h1, h2), cat in zip(heads, cats):
        L += [h1, h2] + rows_by[cat][:6]
    for cat in cats:
        for ln_ in rows_by[cat][6:]:
            if len(L) >= 150:
                break
            L.append(ln_)
    Path(path).write_text("\\n".join(L[:150]) + "\\n", encoding="utf-8")
    return L[:150]
''')

# 自測
rep('''    print("[計] %s 自測 %d/%d · %s" % (VERSION, p, p + f, "PASS" if f == 0 else "FAIL"))
    return 0 if f == 0 else 1
''', '''    r0 = {"FILENAME": "d.pdf", "TABLE": "T", "ROW": 5, "ITEM": "Revenue", "PERIOD": "2025E", "SUBCOL": "", "VALUE": "100", "_V": "ALIGNED", "_N": "dx 1"}
    d5 = dupkey([dict(r0), dict(r0, VALUE="101", _V="PRESENT", _N="值在該頁")])
    d6 = dupkey([dict(r0), dict(r0, VALUE="101", _V="ALIGNED", _N="dx 2")])
    d7 = dupkey([dict(r0, _V="PRESENT"), dict(r0, VALUE="101", _V="FAIL")])
    chk("v0105 DUPKEY 看位置證據:一筆對位一筆不對位 → 對位的保留 ALIGNED(註記)· 不對位的 DUPKEY · 兩筆都對位 → 都 DUPKEY · 都不對位 → 都 DUPKEY",
        [r["_V"] for r in d5] == ["ALIGNED", "DUPKEY"] and "保留" in d5[0]["_N"] and "錯值" in d5[1]["_N"] and [r["_V"] for r in d6] == ["DUPKEY", "DUPKEY"] and [r["_V"] for r in d7] == ["DUPKEY", "DUPKEY"])
    chk("v0105 目標價 / 現價對調診斷:兩邊互換 → 對調 · 同值在目標價標籤旁 → 現價被填成目標價 · 只有現價在目標價標籤旁 → 可能 · 都不在 → 沒有",
        "對調" in _swap_hint(True, True, "400", "231") and "填成目標價" in _swap_hint(False, True, "400", "400.00") and "可能把目標價當成現價" in _swap_hint(False, True, "400", "231")
        and "可能把現價當成目標價" in _swap_hint(True, False, "400", "231") and _swap_hint(False, False, "400", "231") == "")
    fin5 = [{"ITEM": "EPS (NT$)", "PERIOD": "2025E", "VALUE": "24.10"}, {"ITEM": "EPS (NT$)", "PERIOD": "2026E", "VALUE": "30.00"}]
    e5 = _eps_ok("251.50", "2025", None, fin5)
    chk("v0105 EPS 不符印年度數據那一格:251.50 ≠ 年度數據 2025E EPS 24.10 → 不過 · 訊息帶「2025E=24.10」", e5[0] is False and "2025E=24.10" in e5[1] and _eps_ok("24.10", "2025", None, fin5)[0] is True)
    import tempfile as _tf5
    vf5 = [dict(r0, _V="BADITEM", _N="科目 x 本頁原文沒有", ITEM="I%d" % i) for i in range(60)] + [dict(r0, _V="DUPKEY", _N="同鍵", ITEM="J%d" % i) for i in range(60)]
    vb5 = [{"FILENAME": "d.pdf", "checks": {"K%d" % i: "FAIL · x" for i in range(40)}}]
    with _tf5.TemporaryDirectory(prefix="vrn2dg-") as td5:
        L5 = write_digest(Path(td5) / "d.txt", vb5, vf5, [], 1)
    chk("v0105 摘要每類都出現:基本資料 40 筆不過只印 16 + 一行「另有」· BADITEM 60 與 DUPKEY 60 兩類標題都在 · 總行數 ≤ 150",
        any(l.startswith("年度數據 BADITEM 60") for l in L5) and any(l.startswith("年度數據 DUPKEY 60") for l in L5) and any("另有 24 筆" in l for l in L5) and len(L5) <= 150
        and sum(1 for l in L5 if "| J" in l) >= 6)
    print("[計] %s 自測 %d/%d · %s" % (VERSION, p, p + f, "PASS" if f == 0 else "FAIL"))
    return 0 if f == 0 else 1
''')
out.write_text(s, encoding="utf-8", newline="\n")
compile(s, out.name, "exec")
print("[計] %s · %d 位元組" % (out.name, len(s.encode("utf-8"))))
