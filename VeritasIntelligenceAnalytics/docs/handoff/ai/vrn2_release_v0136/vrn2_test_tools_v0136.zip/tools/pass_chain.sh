#!/bin/bash
# $1 = pass 名稱;results.json 已填好 → 交接 → 啟動器 → 自測 → 發行 → 一鍵 → chk5b → 情境(背景)→ U/I 測試
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
cd $S/v136 || exit 9
python3 tools/make_handover_v0136.py src/VRN2_Handover_v0135.md results.json new/VRN2_Handover_v0136.md | tail -1 || exit 1
python3 tools/build_v0136.py src/ActivateVRN-2_v0135.py new ActivateVRN-2_v0136.py || exit 2
SHA=$(sha256sum ActivateVRN-2_v0136.py | cut -d' ' -f1); echo "launcher $SHA"
python3 -c "
import json,pathlib;p=pathlib.Path('results.json');r=json.loads(p.read_text(encoding='utf-8'));r['launcher_sha12']='$SHA'[:12];p.write_text(json.dumps(r,ensure_ascii=False,indent=1),encoding='utf-8')"
env HOME=$S/v136/sthome TMPDIR=$S/v136/sttmp VIA_NO_OPEN=1 PYTHONDONTWRITEBYTECODE=1 timeout 1500 $S2/venv_vrn2/bin/python -W ignore ActivateVRN-2_v0136.py --selftest > selftest_v0136.log 2>&1; RC=$?; echo "selftest rc=$RC"; sed -e 's/\x1b\[[0-9;]*m//g' selftest_v0136.log | grep -E "FAIL|\[計\] ActivateVRN" | cut -c1-120
[ $RC -eq 0 ] || exit 3
python3 tools/make_release136.py ActivateVRN-2_v0136.py results.json release136 | tail -1 || exit 4
python3 tools/oneclick136.py src/VRN2_OneClick_v0135.md $SHA release136 || exit 5
python3 tools/test_chk5b.py release136/Run-VRN2-v0136.ps1 $S2/pwsh/pwsh > chk5b_unit.log 2>&1; grep "\[計\]" chk5b_unit.log; grep -q "FAIL" chk5b_unit.log && exit 6
rm -f scen.rc; bash tools/scen136.sh > scen_driver.log 2>&1; echo "scen: $(cat scen.rc)"
sed -e 's/\x1b\[[0-9;]*m//g' scen_oneclick.log | grep -E "③ |⑦ 啟動|⑧ 完成|⑪ 獨立驗證\(|⑫b|註冊核對|⑤b|⑤c|NEXT|SHA-256|IndependentVerifier_v01" | cut -c1-170
cd $S2/tools && node ui_test.js "$S/v136/t136oc/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $S/v136/shots_oc "$S/v136/t136oc/VIA/VIA_Reports/vrn2/output" > $S/v136/ui_test.log 2>&1; echo "ui_test rc=$?"; grep -E "FAIL|\[計\]" $S/v136/ui_test.log | cut -c1-160
node $S/v136/tools/ui_input.js "$S/v136/t136oc/VIA/VIA_Reports/vrn2/VRN2_UI_latest.html" $S/v136/shots_input_oc "samples" > $S/v136/ui_input_oc.log 2>&1; echo "ui_input rc=$?"; grep -E "FAIL|\[計\]" $S/v136/ui_input_oc.log | cut -c1-160
echo "PASS $1 DONE"
