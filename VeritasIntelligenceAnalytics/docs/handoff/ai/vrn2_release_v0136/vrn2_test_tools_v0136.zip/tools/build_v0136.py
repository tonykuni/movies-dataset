"""ActivateVRN-2 v0135(MAIN · PR #562 已合併)→ v0136 組裝(錨點替換 · 每個錨點只准出現一次 · 不改 v0135 原檔)。
用法:python build_v0136.py <v0135 啟動器> <new 夾> <輸出 v0136 啟動器>
  new 夾:VRN2_IndependentVerifier_v0105.py · VRN2_Handover_v0136.md
v0136 = 操作員 2026-10-21「integrate INTO ONE CODE TO HANDLE ALL ABOVE」(v0135 之後還留著的四件):
  ① 內嵌驗證器 v0105(DUPKEY 看位置證據 · 目標價 / 現價對調直接說 · EPS 不符印年度數據那一格 · 摘要每類錯值都出現)· v0102 / v0103 / v0104 留著 · ⑪ 取最新版
  ② ⑫a VRN-1 倉同步:借工具前把 VRN-1 的本機倉 fetch + fast-forward 到它的 main(乾淨才動 · 不改寫歷史 · 不提交 · 不推 · VIA_VRN2_NO_VRN1_SYNC=1 不同步)→ ⑫ 不必再叫操作員手動 git switch / pull
  處理器 / 管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋 一個位元組都不動。"""
import base64
import hashlib
import re
import sys
from pathlib import Path

src_p, new_d, out_p = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src_p.read_text(encoding="utf-8")


def b64(raw: bytes) -> str:
    t = base64.b64encode(raw).decode("ascii")
    return "\n".join(t[i:i + 120] for i in range(0, len(t), 120))


def rep(a: str, b: str) -> None:
    global s
    assert s.count(a) == 1, (s.count(a), a[:90])
    s = s.replace(a, b)


iv = (new_d / "VRN2_IndependentVerifier_v0105.py").read_bytes()
hand = (new_d / "VRN2_Handover_v0136.md").read_bytes()
isha, hsha = hashlib.sha256(iv).hexdigest(), hashlib.sha256(hand).hexdigest()

rep('r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0135 Codex #561 修正:',
    'r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0136 整合一支(操作員 2026-10-21「integrate INTO ONE CODE TO HANDLE ALL ABOVE」):獨立驗證器 v0105 —— DUPKEY 看位置證據只標不對位那筆 · 目標價 / 現價對調直接說 · EPS 不符印年度數據那一格 · 貼給 AI 的摘要每類錯值都出現(Windows 那份 DUPKEY 82 筆一行都沒進摘要);'
    '⑫a 借工具前先把 VRN-1 的本機倉 fetch + fast-forward 到它的 main(乾淨才動 · 不改寫歷史 · 不提交 · 不推 · VIA_VRN2_NO_VRN1_SYNC=1 不同步);v0102 / v0103 / v0104 留著 · ⑪ 取最新版 · 其餘同 v0135;v0135 Codex #561 修正:')
rep('VERSION = "ActivateVRN-2 v0135"', 'VERSION = "ActivateVRN-2 v0136"')
rep('UI_HANDLER_NAME = "VRN2_UIAction_v0104.py"\n',
    'EXTRAS.append(("VRN2_IndependentVerifier_v0105.py", "%s", """\n%s\n"""))   # v0136 獨立驗證器 v0105(DUPKEY 位置證據 · 對調診斷 · EPS 格 · 摘要每類都出現 · ⑪ 取最新版 · v0102 / v0103 / v0104 留著)\n' % (isha, b64(iv))
    + 'UI_HANDLER_NAME = "VRN2_UIAction_v0104.py"\n')
s, n = re.subn(r'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0135\.md", "[0-9a-f]{64}"\n', 'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0136.md", "' + hsha + '"\n', s)
assert n == 1, n
i0 = s.index('HANDOVER_B64 = """\n'); i1 = s.index('\n"""', i0 + 20)
s = s[:i0] + 'HANDOVER_B64 = """\n' + b64(hand) + s[i1:]
rep('    """v0134 交接報告落地(⑨ 之前 · v0135 內嵌的是 VRN2_Handover_v0135.md):', '    """v0134 交接報告落地(⑨ 之前 · v0136 內嵌的是 VRN2_Handover_v0136.md):')
# ⑫a VRN-1 倉同步
rep('def _pivot_borrow(vrn, v2) -> tuple:\n', '''def _vrn1_sync(root) -> tuple:
    """v0136 ⑫a 借工具前把 VRN-1 的本機倉同步到它的 main(四系統各自獨立:只 fast-forward 它自己的 main · 不改寫歷史 · 不提交 · 不推):
    找倉(VIA_VRN1_ROOT · C:\\\\Users\\\\tonyk\\\\VIA-VDF-VRN · 家目錄 · VIA 倉旁邊)→ 工作樹乾淨(已追蹤的檔沒有改動)才動 → git fetch origin main →
    不在 main 就 switch main(原分支名印出來 · git switch - 切得回)→ git merge --ff-only origin/main;有改動 / 不是 git 倉 / 沒網路 / 分岔 → 不動、照實說(⑫ 照舊自己判借不借得到)。
    VIA_VRN2_NO_VRN1_SYNC=1 → 不同步。回 (燈, 說明)。"""
    if os.environ.get("VIA_VRN2_NO_VRN1_SYNC") == "1":
        return "GRAY", "VIA_VRN2_NO_VRN1_SYNC=1 · 這次不同步 VRN-1 的倉"
    cands = [os.environ.get("VIA_VRN1_ROOT"), r"C:\\\\Users\\\\tonyk\\\\VIA-VDF-VRN", str(_cb_Path.home() / "VIA-VDF-VRN")] + [str(up / "VIA-VDF-VRN") for up in list(_cb_Path(root).parents)[:3]]
    repo = next((_cb_Path(c) for c in cands if c and (_cb_Path(c) / ".git").exists()), None)
    if repo is None:
        return "GRAY", "找不到 VRN-1 的 git 倉(試過 %s · 可設 VIA_VRN1_ROOT)· ⑫ 照舊" % " / ".join(c for c in cands if c)[:200]

    def g(*a, t=120):
        return run(["git", "-C", str(repo)] + list(a), t, {"GIT_TERMINAL_PROMPT": "0"}, cwd=str(repo), silent_max=t)
    rc, ln = g("status", "--porcelain", "--untracked-files=no")
    if rc != 0:
        return "YELLOW", "VRN-1 倉 %s:git status 失敗(rc %d)· 不動" % (repo, rc)
    dirty = [l for l in ln if l.strip() and not l.strip().startswith("[")]
    rc, ln = g("rev-parse", "--abbrev-ref", "HEAD")
    br = next((l.strip() for l in ln if l.strip() and not l.strip().startswith("[")), "?") if rc == 0 else "?"
    rc, ln = g("fetch", "-q", "origin", "main", t=300)
    if rc != 0:
        return "YELLOW", "VRN-1 倉 %s:git fetch origin main 失敗(rc %d · 網路?)· 本機照舊(%s)" % (repo, rc, br)
    rc, ln = g("rev-list", "--count", "HEAD..origin/main")
    behind = int(next((l.strip() for l in ln if l.strip().isdigit()), "0")) if rc == 0 else -1
    rc, ln = g("rev-parse", "--short", "origin/main")
    rmain = next((l.strip() for l in ln if l.strip() and not l.strip().startswith("[")), "?")
    if dirty:
        return "YELLOW", "VRN-1 倉 %s 有 %d 個已追蹤的檔改過 · 不動(現在在 %s · 落後 origin/main %d 個提交 · 自己 commit / stash 後再跑)" % (repo, len(dirty), br, behind)
    if br == "main" and behind == 0:
        return "GREEN", "VRN-1 倉 %s 已在 main 最新 %s" % (repo, rmain)
    note = ""
    if br != "main":
        rc, ln = g("switch", "main")
        if rc != 0:
            rc, ln = g("switch", "-c", "main", "--track", "origin/main")
        if rc != 0:
            return "YELLOW", "VRN-1 倉 %s:切不到 main(rc %d · 原在 %s)· 不動" % (repo, rc, br)
        note = " · 原在 %s(git switch - 可切回)" % br
    rc, ln = g("merge", "--ff-only", "origin/main")
    if rc != 0:
        return "YELLOW", "VRN-1 倉 %s:main 與 origin/main 分岔 · fast-forward 不了(rc %d)· 不動%s" % (repo, rc, note)
    return "GREEN", "VRN-1 倉 %s → main %s(fast-forward %d 個提交%s)" % (repo, rmain, behind, note)


def _pivot_borrow(vrn, v2) -> tuple:
''')
rep('            pl_, pd_, ppk_ = _pivot_borrow(vrn, v2)                            # v0131 ⑫ 借 VRN-1 table.pivot_db',
    '            sl_, sd_ = _vrn1_sync(root)                                         # v0136 ⑫a 先把 VRN-1 的本機倉同步到它的 main(乾淨才動 · 只 fast-forward)\n'
    '            step("⑫a VRN-1 倉同步(借工具前 · 只 fast-forward)", sl_, sd_[:300])\n'
    '            pl_, pd_, ppk_ = _pivot_borrow(vrn, v2)                            # v0131 ⑫ 借 VRN-1 table.pivot_db')
# 自測:驗證器改認 v0105 · 多一條 ⑫a
rep('    iv3_ = next((e for e in EXTRAS if e[0] == "VRN2_IndependentVerifier_v0104.py"), None)', '    iv3_ = next((e for e in EXTRAS if e[0] == "VRN2_IndependentVerifier_v0105.py"), None)')
rep('    with tempfile.TemporaryDirectory(prefix="act135iv-") as td_:\n        p_ = _cb_Path(td_) / "VRN2_IndependentVerifier_v0104.py"',
    '    with tempfile.TemporaryDirectory(prefix="act136iv-") as td_:\n        p_ = _cb_Path(td_) / "VRN2_IndependentVerifier_v0105.py"')
rep('    chk("v0135 內嵌獨立驗證器 v0104(v0102 / v0103 留著 · ⑪ 取最新版):Codex #561 / #562 _nil_cell · _val_row · _SPLITNUM ·',
    '    chk("v0136 內嵌獨立驗證器 v0105(v0102 / v0103 / v0104 留著 · ⑪ 取最新版):DUPKEY 位置證據 _ALIGNED_V · _swap_hint · 摘要每類都出現 · Codex #561 / #562 _nil_cell · _val_row · _SPLITNUM ·')
rep('        ivn_ == ["VRN2_IndependentVerifier_v0102.py", "VRN2_IndependentVerifier_v0103.py", "VRN2_IndependentVerifier_v0104.py"] and all(x in iv3src for x in ("def _num_cands(",',
    '        ivn_ == ["VRN2_IndependentVerifier_v0102.py", "VRN2_IndependentVerifier_v0103.py", "VRN2_IndependentVerifier_v0104.py", "VRN2_IndependentVerifier_v0105.py"] and all(x in iv3src for x in ("_ALIGNED_V", "def _swap_hint(", "def _num_cands(",')
rep('    chk("v0134 ⑨ 交接不回退:倉裡同版已在 → 不蓋 · latest = 最高版號(v0199)· 空夾 → 落地內嵌版 + latest", _ok1 and _ok2 and "v0199" in _w1)\n',
    '''    chk("v0134 ⑨ 交接不回退:倉裡同版已在 → 不蓋 · latest = 最高版號(v0199)· 空夾 → 落地內嵌版 + latest", _ok1 and _ok2 and "v0199" in _w1)
    with tempfile.TemporaryDirectory(prefix="act136v1-") as td_:                 # v0136 ⑫a VRN-1 倉同步(git 夾具:origin 有 2 個提交 · clone 退回 1 個 · 不在 main)
        _t = _cb_Path(td_)
        def _gq(*a, cwd=None):
            return subprocess.run(["git"] + list(a), cwd=str(cwd or _t), capture_output=True, text=True)
        _gq("init", "-q", "-b", "main", "src"); _src = _t / "src"
        (_src / "a.txt").write_text("1\\n"); _gq("-c", "user.email=t@t", "-c", "user.name=t", "add", "-A", cwd=_src); _gq("-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qm", "c1", cwd=_src)
        (_src / "a.txt").write_text("2\\n"); _gq("-c", "user.email=t@t", "-c", "user.name=t", "commit", "-qam", "c2", cwd=_src)
        _gq("clone", "-q", str(_src), "cl"); _cl = _t / "cl"
        _gq("switch", "-q", "-c", "feature", "HEAD~1", cwd=_cl)
        _o = dict(os.environ); os.environ["VIA_VRN1_ROOT"] = str(_cl)
        try:
            _l1, _d1 = _vrn1_sync(_t)
            _h1 = _gq("rev-parse", "--abbrev-ref", "HEAD", cwd=_cl).stdout.strip(); _a1 = (_cl / "a.txt").read_text().strip()
            (_cl / "a.txt").write_text("dirty\\n")
            _l2, _d2 = _vrn1_sync(_t)
            os.environ["VIA_VRN2_NO_VRN1_SYNC"] = "1"
            _l3, _d3 = _vrn1_sync(_t)
        finally:
            os.environ.clear(); os.environ.update(_o)
    chk("v0136 ⑫a VRN-1 倉同步:feature 分支落後 1 → 切回 main 並 fast-forward(a.txt = 2 · 原分支名在說明)· 已追蹤檔改過 → 黃不動 · VIA_VRN2_NO_VRN1_SYNC=1 → 灰 · 不提交不推",
        _l1 == "GREEN" and _h1 == "main" and _a1 == "2" and "feature" in _d1 and _l2 == "YELLOW" and "改過" in _d2 and _l3 == "GRAY")
''')
assert "import subprocess" in s
out_p.write_text(s, encoding="utf-8", newline="\n")
compile(s, out_p.name, "exec")
left = [l[:100] for l in s.split("\n") if "IndependentVerifier_v0104" in l and "EXTRAS.append" not in l and "ivn_ ==" not in l]
print("[計] %s · %d 位元組 · 驗證器 %s · 交接 %s · sha256 %s · 其餘 v0104 字樣 %d" % (out_p.name, len(s.encode("utf-8")), isha[:12], hsha[:12], hashlib.sha256(s.encode("utf-8")).hexdigest()[:12], len(left)))
