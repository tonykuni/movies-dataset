param($W)
function Sha([string]$s) { -join ([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($s)) | ForEach-Object { $_.ToString('x2') }) }
function Block($md, $lang) { [regex]::Match($md, "(?s)``````$lang`n(.*?)`n``````").Groups[1].Value }
foreach ($f in "$W/release145/Run-VRN2-v0145.ps1", "$W/release145/boot145.ps1", "$W/operator106/Run-VRN1-VRN2-v0106.ps1", "$W/operator106/boot_pair106.ps1", "$W/cs101.ps1", "$W/../round2/round.ps1") {
  $e = $null; [System.Management.Automation.Language.Parser]::ParseFile($f, [ref]$null, [ref]$e) | Out-Null; "$(Split-Path -Leaf $f) parse errors: $($e.Count)"
}
$md = [IO.File]::ReadAllText("$W/release145/VRN2_OneClick_v0145.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code = Block $md 'powershell'; $boot = Block $md 'text'; $H = [regex]::Match($boot, "\`$H  = '([0-9a-f]{64})'").Groups[1].Value
"vrn2 one-click v0145: code sha = boot H → $((Sha $code) -eq $H) ($((Sha $code).Substring(0,12)))"
$one = Block $md 'bat'; "one-liner decodes to boot → $(([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($one.Split(' ')[-1]))) -eq ($boot + "`n"))"
$want = [regex]::Match($code, "\`$Want   = '([0-9a-f]{64})'").Groups[1].Value
"package zip sha = \$Want → $(((Get-FileHash -LiteralPath "$W/release145/VRN2_Closeout_v0145.zip" -Algorithm SHA256).Hash.ToLower()) -eq $want)"
$md2 = [IO.File]::ReadAllText("$W/operator106/VRN1_VRN2_OneClick_v0106.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code2 = Block $md2 'powershell'; $boot2 = Block $md2 'text'; $H2b = [regex]::Match($boot2, "\`$H  = '([0-9a-f]{64})'").Groups[1].Value
"operator v0106: code sha = boot H → $((Sha $code2) -eq $H2b) ($((Sha $code2).Substring(0,12)))"
$H2 = [regex]::Match($code2, "\`$H2 = '([0-9a-f]{64})'").Groups[1].Value
"operator H2 = vrn2 one-click v0145 code sha → $($H2 -eq (Sha $code))"
"operator banner says v0106 → $($code2.Contains('操作員一鍵 v0106 · {0}'))"
$md3 = [IO.File]::ReadAllText("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/VRN2_LocalRound_v0100.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code3 = Block $md3 'powershell'
$hop = [regex]::Match($code3, "\`$H_OP = '([0-9a-f]{64})'").Groups[1].Value; $hcs = [regex]::Match($code3, "\`$H_CS = '([0-9a-f]{64})'").Groups[1].Value
"localround H_OP = operator v0106 code sha → $($hop -eq (Sha $code2))"
$md4 = [IO.File]::ReadAllText("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/VRN2_ChainShip_v0101.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code4 = Block $md4 'powershell'; "localround H_CS = chainship md v0101 code sha → $($hcs -eq (Sha $code4))"
$want4 = [regex]::Match($code4, '\$WANT = "([0-9a-f]{64})"').Groups[1].Value
"chainship md WANT = tool v0101 sha → $(((Get-FileHash -LiteralPath '/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN/VRN2_ChainShip_v0101.py' -Algorithm SHA256).Hash.ToLower()) -eq $want4)"
