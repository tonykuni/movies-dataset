"""VRN2_Handover_v0146.md:從 v0144 只增不減(v0145 這個號桌機線已用,本線跳到 v0146)。"""
import json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v145")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0144.md").read_text(encoding="utf-8")
R = json.loads((S / "release145/VRN2_Release_v0145.json").read_text(encoding="utf-8")); rr = R["results"]["full_run_v0145_19_real"]; dk = R["results"]["desktop_v0144_2026_10_29_0814"]
it = rr.get("idempotence_timing") or {}
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)
lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0144 · 2026-10-29(")
lines[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0145 · 2026-10-29(v0144 + 本輪:桌機 08:14 實跑 v0144 貼回 → 前後端已連結、2422 秒慢在 ⑦ 冪等閘序跑 → 管理器薄尾 v0255(冪等閘每波 3 份並行 · 30 秒心跳 · 階段計時)· 啟動器 v0145 · 操作員一鍵 v0106 · 本地實測一輪改指;交接號 v0145 桌機線已用 → 本檔 v0146;runtime v0144 的 166 個成員一個位元組都不動)"
src = "\n".join(lines)
old_round = "> **本輪(v0144 · 套件 = 啟動器 v0144 + runtime v0144"
assert src.count(old_round) == 1
new_round = ("> **操作員令(2026-10-29 · 08:14 貼回後)**:「先把這兩天有更新的部分抓下來再 PC 測試 先不要讓 GITHUB 影響 這是獨立系統」→ 貼回 v0144 整輪主控台 →「ENSURE THE SYSTEM HAS SYNCHRONIZED WITH HTML U/I AND USER CAN USE THE SYSTEM ON IT. IT TAKE LOTS OF TIME TO LAUNCH. IS IT THE FIRST TIME TO LAUNCH SYSTEM OR ACCELERATORS DIDN'T WORK.」\n"
             "> **本輪(v0145 · 套件 = 啟動器 v0145 + runtime v0145 = v0144 的 166 個成員不動 + 管理器 v0255 · 操作員一鍵 v0106 · 本地實測一輪 v0100 改指)**:"
             "① **桌機 08:14 判讀**:前後端已連結(%s);紅燈只有 ⑧b 收尾收據 rc 1 ← %s;時間 總 %d 秒 = 啟動器 %d(⑦ %d 其中無輸出 %s · ⑪ %d · ④ %d)+ 一鍵外殼;快取 %s;加速器 %s → **不是第一次啟動、加速器有生效**;慢的根因判讀:%s。"
             "② **管理器 v0255**(釘名前版 v0243;v0244 ~ v0254 是桌機線在 `functional modules\\VRN` 用掉的號,本線跳過):冪等閘契約不變(同主跑子行程路徑 · 不吃擷取快取 · R1 / R2 / 主跑紀錄三方比對 · GREEN / STALE_RECORD / NONDETERMINISTIC),改成每波**一份一個單路子行程並行**(預設 3 路 · `VRN2_IDEM_LANES`)、R1 跑完才 R2(同一份的 OCR 快取不會被兩次同時寫)、每 30 秒心跳、R1 / R2 / 每份秒數進 `IDEMPOTENCE_latest.json.timing`;把原生流程的 `_resolve(\"p1loop\")` / `acceptance` / `_out_books` / `_out_html` / `_funnel` / 冪等閘包上計時 → 即時印 `[計] 階段 · X · 完成 · 耗時` · 收尾一行 `[計] 階段耗時` · `VIA_Reports\\vrn2\\VRN2_Phase_Timing_latest.json`;`completion.manager` = v0255。"
             "③ **啟動器 v0145**:只改指管理器 v0255 與收據名 `VRN2_Closeout_v0145.json`;⑤b / ⑬ / 處理器 v0108 / Workbench v0101 / 單機閘 / 上限 / ⑫b 補放照舊。"
             "④ **一鍵 v0145 / 操作員 v0106 / 本地實測一輪**:⑤ 摘要多印階段耗時;④ 貼回包改收 v0145 收據 + 階段計時,不再把前版收據與(跑完本來就移除的)鎖檔算「缺」;操作員 v0105 歷史子句被連帶改錯的「v0104 → 一鍵 v0144」改回 v0143。"
             "容器實測:啟動器 v0145 自測 PASS · 管理器 v0255 自測 PASS(3 路並行 GREEN · 非冪等 RED · 1 路)· pwsh 雜湊鏈全 True · 沙盒 19 份:⑧ %s · 管理器 %s · 冪等閘 %s(R1 %s 秒 %s 路 · R2 %s 秒)· 階段耗時行 %s · 其餘數字與 v0144 同一組。桌機還沒跑 v0145。\n"
             % (dk["ui_binding"], dk["red"], dk["total_s"], dk["launcher_s"], dk["step7_s"], dk["silent_gap_s"], dk["step11_s"], dk["step4_s"], dk["cache"], dk["accelerators"], dk["diagnosis"],
                rr["completion"]["verdict"], rr["completion"]["manager"], rr["idempotence"], (it.get("R1") or {}).get("elapsed_s"), (it.get("R1") or {}).get("lanes"), (it.get("R2") or {}).get("elapsed_s"), (rr.get("phase_summary_line") or "")[:160]))
src = src.replace(old_round, new_round + "> **前一輪(v0144 · 套件 = 啟動器 v0144 + runtime v0144", 1)
anchor = "| ActivateVRN-2_v0144.py(套件 · 底座 v0136)| **v0144** |"
assert src.count(anchor) == 1
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg145/VRN2_Runtime_v0145.json").read_text(encoding="utf-8"))["files"]}
rows = ("| ActivateVRN-2_v0145.py(套件 · 底座 v0136)| **v0145** | 見發行清單 | `%s` | **新**(改指管理器 v0255 · 收據 v0145;其餘同 v0144)|\n"
        "| **VRN_SystemManager** | **v0255**(薄尾 · 釘名 v0243;v0243 留著 · v0244 ~ v0254 = 桌機線)| 見 runtime 清單 | `%s` | **新**(冪等閘每波一份一子行程並行 · 心跳 · timing · 階段計時 · 自測 PASS)|\n") % (R["launcher"]["sha256"][:12], rt["VRN_SystemManager_v0255.py"])
src = src.replace(anchor, rows + anchor, 1)
once("## 7. 本輪(v0143 → v0144 · 操作員 2026-10-29 政策)",
     "## 7. 本輪(v0144 → v0145 · 桌機 2026-10-29 08:14 貼回)\n\n| # | 貼回 | 追到的根因 | v0145 做法 | 實測 |\n|---|---|---|---|---|\n"
     "| 1 | 「花很多時間 · 是第一次啟動還是加速器沒作用」· 2422 秒 | 都不是:快取 52/52 命中、加速器已載;⑦ 1201 秒裡約 1050 秒無輸出 = v0243 冪等閘 3 份 ×2 單路序跑、不吃快取(主跑本身都是快取)| 管理器 v0255:每波一份一子行程並行 · 心跳 · timing · 階段計時 | 自測 PASS · 沙盒冪等閘 %s · R1 %s 秒 %s 路 |\n"
     "| 2 | 「確認已與 HTML U/I 同步、使用者可用」| 貼回已證明:⑥c · ⑤b · ⑫b · ⑬(duckdb)· Workbench v0101 全綠 · 驗證判決寫回指紋相同 | 不改;寫進交接 | — |\n"
     "| 3 | ⑧b rc 1:四點原文核對 FAIL 1(3014TT POINT_3)· 缺項 3 份年度數據 | 要貼回 zip 的 `VRN2_VerbatimVerify_latest.json` 與原檔 | 本輪不碰(zip 還沒上傳)| — |\n"
     "| 4 | ④ 貼回包黃「缺 2」(v0143 收據 · 鎖檔)| 清單列了前版收據與跑完必移除的鎖 | 本地實測一輪 ④ 改收 v0145 收據 + 階段計時 | 下一次貼回 |\n\n---\n\n## 7.0h 前一輪(v0143 → v0144 · 操作員 2026-10-29 政策)" % (rr["idempotence"], (it.get("R1") or {}).get("elapsed_s"), (it.get("R1") or {}).get("lanes")))
once("| 0 | **(v0144)** 桌機還沒跑 v0144:",
     "| 0 | **(v0145)** 桌機跑 v0145(本地實測一輪的一行 · `VRN_ROUND_NO_SHIP=1` 只測不推):看 ⑦ 的 `[計] 階段 · … · 耗時` 與 `[計] 冪等閘 · R1 完成 · 耗時`,再看收尾 `[計] 階段耗時` 一行 —— 這就是 2422 秒的拆帳;若冪等閘仍 > 300 秒,下一步是把它移到 ⑪ 同一背景 | 貼回 zip |\n"
     "| 0a | **(v0145)** 上傳 `VRN2_PasteBack_20261029_081428.zip`:修 3014TT POINT_3 FAIL 1 與 3 份年度數據缺項(Daiwa-6278 · 欣銓 3264 · 華南 6143)要它裡面的四點核對 json 與 PDF | 上傳 |\n"
     "| 0b | **(v0145)** ⑪ 獨立驛證 691 秒(11513 筆 · 6 路)與 ④ 加速器掃描兩遍 92 秒還沒動;OneDrive 夾 I/O 沒量 | 看階段計時再決定 |\n"
     "| 0 | **(v0144)** 桌機已跑 v0144(08:14):".replace("驛證", "驗證"))
once("## 10. 執行方式(v0144:貼 `docs/handoff/ai/VRN2_LocalRound_v0100.md` 頂端的一行(logo → ChainShip v0101 補船 → 操作員一鍵 v0105 → VRN-2 一鍵 v0144 → 貼回包);",
     "## 10. 執行方式(v0145:貼 `docs/handoff/ai/VRN2_LocalRound_v0100.md` 頂端的一行(logo → ChainShip v0101 補船 → 操作員一鍵 v0106 → VRN-2 一鍵 v0145 → 貼回包);只測不推先 `$env:VRN_ROUND_NO_SHIP = '1'`;冪等閘並行路數 `$env:VRN2_IDEM_LANES`(預設 3);前一版 v0144:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0145)** **慢先拆帳,不猜**:v0255 起 ⑦ 每階段有 `[計] 階段 · X · 耗時` 與收尾 `[計] 階段耗時` 一行(`VRN2_Phase_Timing_latest.json`);貼回來先看這一行,再決定動哪裡。桌機 08:14 的 1050 秒無輸出是推論(v0243 的 R*.log 在 GREEN 時被刪),v0255 的 timing 會證實或推翻。\n"
     "- **(v0145)** **長時間子行程一定要有心跳**:管理器內部任何 > 30 秒的子行程迴圈要印進度(啟動器的沉默看門狗只認輸出)。\n"
     "- **(v0145)** **冪等閘的並行只能跨檔、不能跨波**:同一份的 R1 / R2 不能同時跑(共用 OCR 快取會互寫);波內不同檔並行安全。\n"
     "- **(v0145)** **版號跳過另一條線用掉的號**:管理器 v0244 ~ v0254、處理器 v0105 / v0107、交接 v0145 都是桌機線的;出新版前 `chain <家族>` 看兩線的號,釘名前版、不用 v-1 推。\n"
     "- **(v0145)** 「GitHub 不影響」= GitHub 只當 git 遠端抓檔 + 核對雜湊;CI 紅綠不擋本機實測;`VRN_ROUND_NO_SHIP=1` 連補船都不推。\n\n")
(REPO / "VRN2_Handover_v0146.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0146 lines", src.count("\n"))
