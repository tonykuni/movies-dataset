"""收尾 v0145:results → VRN2_Release_v0145.json.results · VRN2_Verification_v0145.md(套件 zip 已定,不重算)。"""
import json, re
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v145")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def grep(path, pat, last=True, all_=False):
    try: hits = [l for l in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if re.search(pat, l) and "<Objs" not in l and "</S>" not in l and "<S N=" not in l and "</U32>" not in l]
    except OSError: return [] if all_ else ""
    if all_: return hits
    return (hits[-1] if last else hits[0]) if hits else ""
def esc(x): return str(x).replace("|", "\\|")
o = W / "t145/VIA/VIA_Reports/vrn2"
cl = j(o / "VRN2_Closeout_v0145.json", {}); idem = j(o / "IDEMPOTENCE_latest.json", {}); comp = j(o / "VRN2_Completion_latest.json", {}); pt = j(o / "VRN2_Phase_Timing_latest.json", {})
log = W / "full145.log"
line7 = grep(log, r"⑦ 啟動 VRN-2 · \[計\] VRN-2 個股四項"); m7 = re.search(r"個股四項 · (\d+) 份\(全綠 (\d+)\)", line7); m7t = re.search(r"耗時 (\d+) 秒", line7)
line11 = grep(log, r"⑪ 獨立驗證\(背景 · 只讀\) ·"); m11 = re.search(r"基本資料 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 一標題四重點 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 年度數據 (\d+) 筆 · (\{[^}]*\})", line11)
st = cl.get("output_store") or {}; ss = cl.get("ssot_sync") or {}; wb = cl.get("workbench") or {}
non_green = [(s.get("step"), s.get("lamp")) for s in cl.get("steps", []) if s.get("lamp") != "GREEN"]
phase_lines = [l.strip() for l in grep(log, r"\[計\] 階段 · ", all_=True) if "完成" in l]
idem_lines = [l.strip() for l in grep(log, r"\[計\] 冪等閘 · (開始|R1 完成|R2 完成|R[12] · 已)", all_=True)]
gate_line = grep(log, r"\[計\] 冪等閘 · (GREEN|RED|YELLOW|GRAY) ·")
summary_line = grep(log, r"\[計\] 階段耗時")
selft = {"ActivateVRN-2_v0145": grep(W / "ActivateVRN-2_v0145_selftest.log", r"\[PASS\] v0145").strip()[:220], "VRN_SystemManager_v0255": grep(W / "VRN_SystemManager_v0255_selftest.log", r"\[PASS\] v0255").strip()[:260]}
scen_rc = (W / "scen145.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen145.rc").exists() else "not run"
scen_first = grep(W / "scen145_first.log", r"③ 套件 v0145 就位|③ 本機已是 v0145"); scen_again = grep(W / "scen145_again.log", r"③ 本機已是 v0145|③ 套件 v0145 就位")
scen_tamper = (grep(W / "scen145_tamper.log", r"③ 本機套件夾有 \d+ 個檔與已驛證的 zip 不同|③ 本機套件夾有 \d+ 個檔與已驗證的 zip 不同").strip()[:160] + " → " + grep(W / "scen145_tamper.log", r"③ 舊套件夾已改名備份").strip()[:120])
scen_8b = grep(W / "scen145_first.log", r"⑧b 收尾收據 v0145"); scen_pt = grep(W / "scen145_first.log", r"階段耗時"); scen_idem = grep(W / "scen145_first.log", r"\[計\] 冪等閘 · (GREEN|RED)"); scen_reg = grep(W / "scen145_first.log", r"註冊核對 ·")
R = {"selftests": selft, "pwsh_hash_chain": [l for l in (W / "pscheck145.log").read_text(encoding="utf-8").splitlines() if l.strip()],
     "full_run_v0145_19_real": {"closeout_rc": cl.get("rc"), "rc_reason": "③ 環境檢查 RED in the Linux sandbox only (accelerator deps not in venv; --no-install); same as v0142–v0144", "non_green_steps": non_green,
        "lock_removed_after_run": not (o / "VRN2_Launcher.lock").exists(),
        "passes": [(p.get("attempt"), p.get("rc"), p.get("idempotence")) for p in cl.get("passes", [])], "completion": {"verdict": comp.get("verdict"), "red": comp.get("red"), "yellow": comp.get("yellow"), "manager": comp.get("manager")},
        "stock_reports": {"n": int(m7.group(1)) if m7 else None, "all_green": int(m7.group(2)) if m7 else None, "step7_seconds": int(m7t.group(1)) if m7t else None}, "idempotence": idem.get("classification"),
        "idempotence_timing": idem.get("timing"), "idempotence_method": idem.get("method"), "gate_line": gate_line.strip()[:300], "gate_progress_lines": idem_lines[:8],
        "phase_timing": pt, "phase_lines": phase_lines, "phase_summary_line": summary_line.strip()[:300],
        "source_quotes": (cl.get("source_quotes") or {}).get("counts"), "output_gaps": cl.get("output_gaps"),
        "independent_verifier": {"basic": m11.group(2) if m11 else "", "summary": m11.group(4) if m11 else "", "financial_rows": int(m11.group(5)) if m11 else None, "financial_verdicts": m11.group(6) if m11 else ""},
        "registration_line": grep(log, r"註冊核對 ·").strip()[:200],
        "ssot_sync": {"lamp": ss.get("lamp"), "detail": ss.get("detail")}, "output_store": {"lamp": st.get("lamp"), "store_engine": st.get("store_engine"), "new_files": len(st.get("new_files") or []), "appended": st.get("appended")},
        "workbench": {"lamp": wb.get("lamp"), "legacy_linked": wb.get("legacy_linked")}},
     "oneclick_scenario_pwsh": {"rc": scen_rc, "first": scen_first.strip()[:200], "again": scen_again.strip()[:200], "tamper": scen_tamper, "closeout_line": scen_8b.strip()[:200], "phase_line": scen_pt.strip()[:300], "gate_line": scen_idem.strip()[:260], "registration_line": scen_reg.strip()[:200]},
     "desktop_v0144_2026_10_29_0814": {"total_s": 2422, "launcher_s": 2401, "step7_s": 1201, "silent_gap_s": "~1050 (heartbeat 距上次輸出 1068 秒 before the manager's [計] lines)", "step11_s": 691, "step4_s": 92, "cache": "擷取沿用 52/52 · 驗收沿用 51/52", "accelerators": "VeritasCeleritas v1141 loaded · PS accelerator bound · accelfix 0 missing · 6-way parallel segment 55 s vs 177 s serial",
        "ui_binding": "⑥c vrn2:// → VRN2_UIAction_v0108 read back equal · ⑤b 前後端已連結 GREEN · ⑫b input block GREEN · 驗證過的輸出 written back (fingerprint 9888cecc1a7f291f) · Workbench v0101 GREEN opened · ⑬ duckdb GREEN 52 files · ⑤b SSOT-ID GREEN pending 371",
        "red": "⑧b closeout rc 1 ← 四點原文核對 FAIL 1 (3014TT-20231005 POINT_3 · second reader did not reproduce the complete source excerpt) · 輸出缺項 3 份年度數據 (Daiwa-6278 · 欣銓 3264 · 華南 6143)",
        "diagnosis": "not a first launch; accelerators worked; the silent 1050 s is consistent with the v0243 idempotence gate: 3 兆豐 PDFs × 2 waves in ONE single-lane subprocess per wave, no extraction cache, serial — main extraction itself was all cache hits"},
     "not_claimed": ["Windows desktop run of v0145: not yet (next paste-back); the 1050 s attribution to the idempotence gate is an inference from the console (the R*.log evidence is deleted on GREEN by v0243); v0255 records R1/R2 timing so the next paste-back proves or refutes it",
                     "⑪ independent verifier 691 s and ④ accelfix double pass 92 s: not changed this round",
                     "3014TT POINT_3 FAIL and the 3 missing annual-data books: need the paste-back zip (VRN2_PasteBack_20261029_081428.zip) — not in the container samples",
                     "OneDrive-synced repository folder slows file I/O: not measured; the phase timing will show it",
                     "Items carried from v0143 / v0144: PasteBack 013350 transcript, v0248 / v0253 location on the desktop, VCGC side of the SSOT-ID protocol"]}
rel_p = W / "release145/VRN2_Release_v0145.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
rr = R["full_run_v0145_19_real"]; sc = R["oneclick_scenario_pwsh"]; dk = R["desktop_v0144_2026_10_29_0814"]
it = rr["idempotence_timing"] or {}
md = ["# VRN-2 v0145 容器實測紀錄(2026-10-29)", "",
      "起因:桌機 2026-10-29 08:14 用 v0144 跑本地實測一輪(52 份 · %d 秒):前後端已連結、⑬ 走 duckdb 正式路徑、⑤b 綠,但 ⑦ %d 秒裡約 1050 秒管理器沒有輸出;操作員問「IS IT THE FIRST TIME TO LAUNCH SYSTEM OR ACCELERATORS DIDN'T WORK」。" % (dk["total_s"], dk["step7_s"]), "",
      "## 0. 桌機貼回判讀(v0144 · 08:14)", "", "| 項 | 結果 |", "|---|---|",
      "| 前後端同步 | %s |" % esc(dk["ui_binding"]), "| 紅燈 | %s |" % esc(dk["red"]),
      "| 時間 | 總 %d 秒 · 啟動器 %d · ⑦ %d(無輸出 %s)· ⑪ %d · ④ %d |" % (dk["total_s"], dk["launcher_s"], dk["step7_s"], dk["silent_gap_s"], dk["step11_s"], dk["step4_s"]),
      "| 快取 / 加速器 | %s · %s |" % (dk["cache"], esc(dk["accelerators"])), "| 判讀 | %s |" % esc(dk["diagnosis"]), "",
      "## 1. 本輪改了什麼", "", "| 元件 | 版本 | 內容 |", "|---|---|---|",
      "| 管理器 | VRN_SystemManager v0255(薄尾 · 釘名前版 v0243;v0244 ~ v0254 是桌機線的號)| 冪等閘契約不變,每波一份一個單路子行程並行(預設 3 路 · `VRN2_IDEM_LANES`)· R1 跑完才 R2 · 30 秒心跳 · R1 / R2 / 每份秒數進 `IDEMPOTENCE_latest.json.timing` · 階段計時(擷取迴圈 · 驗收 + 摘要 · 輸出冊 · U/I 輸出冊頁 · 調節輪 · 冪等閘)即時印 + `[計] 階段耗時` 一行 + `VRN2_Phase_Timing_latest.json` · completion.manager = v0255 |",
      "| 啟動器 | ActivateVRN-2 v0145 | 改指管理器 v0255 · 收據 `VRN2_Closeout_v0145.json` · runtime v0145 = v0144 的 166 成員 + v0255;v0144 的 ⑤b / ⑬ / 處理器 v0108 / Workbench v0101 與 v0143 的閘 / 上限 / ⑫b 照舊 |",
      "| 一鍵 | VRN-2 一鍵 v0145 · 操作員一鍵 v0106 · 本地實測一輪 v0100 改指 | ⑤ 摘要多印階段耗時 · ⑧b 收據 v0145 · ④ 貼回包改收 v0145 收據 + 階段計時,不再把前版收據與鎖檔算缺 |", "",
      "## 2. 自測與雜湊鏈", "", "| 項 | 結果 |", "|---|---|"] + ["| `%s --selftest` | %s |" % (k, esc(v)) for k, v in R["selftests"].items()] + ["| pwsh 雜湊鏈 | %s |" % esc(l) for l in R["pwsh_hash_chain"]] + ["",
      "## 3. 沙盒全流程(套件 v0145 · 19 份真檔)", "", "| 項 | 結果 |", "|---|---|",
      "| 收尾 rc | %s(%s)|" % (rr["closeout_rc"], rr["rc_reason"]), "| 非綠步驟 | %s |" % esc(rr["non_green_steps"]),
      "| 輪數 / 冪等 | %s · %s · 鎖檔已移除 %s |" % (rr["passes"], rr["idempotence"], rr["lock_removed_after_run"]),
      "| ⑧ 完成判定 | %s · 紅 %s 黃 %s · **%s** |" % (rr["completion"]["verdict"], rr["completion"]["red"], rr["completion"]["yellow"], rr["completion"]["manager"]),
      "| ⑦ 個股四項 | %s 份 · 全綠 %s · ⑦ 耗時 %s 秒 |" % (rr["stock_reports"]["n"], rr["stock_reports"]["all_green"], rr["stock_reports"]["step7_seconds"]),
      "| **冪等閘** | %s |" % esc(rr["gate_line"]), "| 冪等閘 timing | R1 %s 秒(%s 路 · %s)· R2 %s 秒 · 總 %s 秒 |" % ((it.get("R1") or {}).get("elapsed_s"), (it.get("R1") or {}).get("lanes"), esc((it.get("R1") or {}).get("files")), (it.get("R2") or {}).get("elapsed_s"), it.get("total_s"))] + ["| 冪等閘進度行 | %s |" % esc(l[:200]) for l in rr["gate_progress_lines"]] + [
      "| **階段耗時** | %s |" % esc(rr["phase_summary_line"])] + ["| 階段行 | %s |" % esc(l[:160]) for l in rr["phase_lines"]] + [
      "| 四點原文核對 | %s · 缺項 %s |" % (rr["source_quotes"], rr["output_gaps"]),
      "| ⑪ 獨立驗證 | 基本資料 %s · 四點 %s · 年度 %s 筆 %s |" % (rr["independent_verifier"]["basic"], rr["independent_verifier"]["summary"], rr["independent_verifier"]["financial_rows"], rr["independent_verifier"]["financial_verdicts"]),
      "| 註冊核對 | %s |" % esc(rr["registration_line"]), "| ⑤b / ⑬ / Workbench | %s · %s %s 新檔 %s · Workbench %s |" % (rr["ssot_sync"]["lamp"], rr["output_store"]["lamp"], rr["output_store"]["store_engine"], rr["output_store"]["new_files"], rr["workbench"]["lamp"]), "",
      "擷取 / 驗收 / 驗證的數字與 v0142 ~ v0144 同一組(無退步);管理器換成 v0255 只改了冪等閘跑法與計時。", "",
      "## 4. 一鍵 v0145 情境(pwsh · 假 GitHub 分支)", "", "| 項 | 結果 |", "|---|---|",
      "| rc | %s(rc 1 = 沙盒 ③ 環境檢查 RED,與 §3 同)|" % sc["rc"], "| 第一次(Downloads 沒套件 → 從分支取)| %s |" % esc(sc["first"]),
      "| 再貼一次 | %s |" % esc(sc["again"]), "| 竄改啟動器後再貼 | %s |" % esc(sc["tamper"]),
      "| ⑧b | %s |" % esc(sc["closeout_line"]), "| ⑤ 階段耗時行 | %s |" % esc(sc["phase_line"]), "| 冪等閘 | %s |" % esc(sc["gate_line"]), "| 註冊核對 | %s |" % esc(sc["registration_line"]), "",
      "## 5. 沒有宣稱的", ""] + ["- " + x for x in R["not_claimed"]]
(W / "release145/VRN2_Verification_v0145.md").write_text("\n".join(md) + "\n", encoding="utf-8"); print("verification md + release results ok")
