"""v0145 整包重建(冪等):pkg145(runtime 已建)→ release zip/json → 一鍵 v0145 md → 操作員 v0106 md → LocalRound 指回。"""
import base64, hashlib, json, re, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); out, rel, op6 = S / "v145/pkg145", S / "v145/release145", S / "v145/operator106"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
rt = json.loads((out / "VRN2_Runtime_v0145.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN_SystemManager_v0255.py"]
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0145.py", "VRN2_Runtime_v0145.zip", "VRN2_Runtime_v0145.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0145 — VRN-2 closeout package (2026-10-29)\n\nEntry: python ActivateVRN-2_v0145.py [--source <folder>] [--no-install] [--no-open]\n"
  "Runtime: VRN2_Runtime_v0145.zip = runtime v0144 (166 members byte-identical) + VRN_SystemManager_v0255\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0145 (desktop run 2026-10-29 08:14 · 2422 s · U/I bound, ⑦ 1201 s with ~1050 s silence):\n"
  " - manager v0255 (PRIOR pinned v0243; v0244–v0254 are the desktop line's numbers): idempotence gate runs each wave as one\n"
  "   single-lane subprocess PER FILE in parallel (default 3 lanes · VRN2_IDEM_LANES), R1 completes before R2; heartbeat every 30 s;\n"
  "   per-wave / per-file wall time in IDEMPOTENCE_latest.json; phase timing (p1loop · acceptance · books · U/I · funnel · gate)\n"
  "   printed live, one [計] 階段耗時 summary line, VIA_Reports/vrn2/VRN2_Phase_Timing_latest.json.\n"
  " - launcher v0145: MANAGER → v0255, receipt VRN2_Closeout_v0145.json; v0144 steps ⑤b / ⑬ / handler v0108 / Workbench v0101 unchanged.\n"
  "Exit codes: 0 GREEN · 2 YELLOW · 1 RED.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0145.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0145", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0145.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0145/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0145", "date": "2026-10-29",
       "trigger": "桌機 2026-10-29 08:14 實跑 v0144(52 份 · 2422 秒):前後端已連結(⑥c · ⑤b · ⑫b · ⑬ 綠)· ⑦ 1201 秒其中約 1050 秒管理器無輸出(擷取快取 52/52 命中 · 真正在跑的是冪等閘 3 份 ×2 單路序跑)· ⑪ 691 秒 · ④ 92 秒;操作員問「是第一次啟動還是加速器沒作用」→ 都不是,是冪等閘序跑",
       "base_package": {"name": "VRN2_Closeout_v0144 (launcher v0144 · runtime v0144)", "retained": "runtime v0144 members byte-identical inside runtime v0145; ActivateVRN-2_v0136.py base unchanged"},
       "supersedes": "v0144 for the closeout entry; VRN-2 one-click v0144; operator one-click v0105 → v0106",
       "design": {"VRN_SystemManager_v0255": "thin tail over v0243 (number skips the desktop line's v0244–v0254): _idem_check waves run one single-lane shard subprocess per file concurrently (VRN2_IDEM_LANES · default 3) · R1 before R2 · heartbeat 30 s · timing in IDEMPOTENCE_latest.json · phase timers (_resolve p1loop · acceptance · _out_books · _out_html · _funnel · gate) → [計] 階段耗時 line + VRN2_Phase_Timing_latest.json · completion.manager = v0255",
                  "ActivateVRN-2_v0145": "MANAGER v0255 · receipt v0145 · runtime v0145; v0144 ⑤b / ⑬ / handler v0108 / Workbench v0101 / v0143 guard & limits unchanged"},
       "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
       "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0145.json inside the package"},
       "tested_in": "Linux container · python 3.13 venv_vrn2 (pyarrow · no duckdb) · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0145.md"},
       "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0145/<files> (no .ps1 · the one-click md is the entry)"},
       "launcher": {"name": "ActivateVRN-2_v0145.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0145.py"]).hexdigest()}, "manager": {"name": "VRN_SystemManager_v0255.py", "sha256": next(f["sha256"] for f in rt["files"] if f["path"] == "VRN_SystemManager_v0255.py")},
       "oneclick": "VRN2_OneClick_v0145.md", "test_tools_zip": "vrn2_test_tools_v0145.zip", "logs_zip": "logs_v0145.zip"}
(rel / "VRN2_Release_v0145.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8"); print("package", want[:12])
# ===== one-click v0145 from v0144 =====
md = (REPO / "vrn2_release_v0144/VRN2_OneClick_v0144.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); old_cs = hashlib.sha256(ps.encode("utf-8")).hexdigest(); assert old_cs in boot
def rep(a, b):
    global ps
    assert ps.count(a) == 1, (ps.count(a), a[:80]); ps = ps.replace(a, b)
rep("  $Want   = '%s'   # VRN2_Closeout_v0144.zip SHA-256(套件 · 內含啟動器 v0144 + runtime v0144 清單 = v0142 + 處理器 v0108 / OutputStore / SSOTSync / Workbench v0101)" % old_want,
    "  $Want   = '%s'   # VRN2_Closeout_v0145.zip SHA-256(套件 · 內含啟動器 v0145 + runtime v0145 清單 = v0144 + 管理器 v0255)" % want)
rep("[計] VRN-2 一鍵 v0144 · ActivateVRN-2 v0144(套件 · 私有 runtime v0144 = v0142 + 處理器 v0108 · OutputStore v0100 · SSOTSync v0100 · Workbench v0101;管理器 v0243 · 摘要器 v0117 · 驗證器 v0110 · 原文核對 v0104;v0144 = 輸出位置 window I/O · DuckDB 增量 Parquet 庫 · SSOT-ID 協作;v0143 = 單機閘 · 上限 · ⑫b 補放)",
    "[計] VRN-2 一鍵 v0145 · ActivateVRN-2 v0145(套件 · 私有 runtime v0145 = v0144 + 管理器 v0255(冪等閘每波 3 份並行 · 30 秒心跳 · 階段計時);處理器 v0108 · OutputStore v0100 · SSOTSync v0100 · Workbench v0101 · 摘要器 v0117 · 驗證器 v0110 · 原文核對 v0104;v0144 = 輸出位置 window I/O · DuckDB 增量 Parquet 庫 · SSOT-ID 協作;v0143 = 單機閘 · 上限 · ⑫b 補放)")
rep("  # ===== VRN-2 一鍵 v0144(套件 v0144 = 啟動器 v0144 + runtime v0144;v0144 = 操作員 2026-10-29 政策:",
    "  # ===== VRN-2 一鍵 v0145(套件 v0145 = 啟動器 v0145 + runtime v0145 = v0144 + 管理器 v0255;v0145 = 桌機 2026-10-29 08:14 實跑 2422 秒的速度修正:冪等閘每波 3 份並行(VRN2_IDEM_LANES)· 每 30 秒心跳 · R1 / R2 計時進 IDEMPOTENCE 收據 · 階段計時 VRN2_Phase_Timing_latest.json + 一行總表 · ⑤ 摘要多印階段耗時;v0144 = 啟動器 v0144 + runtime v0144 · 操作員 2026-10-29 政策:")
rep('cl = j(v2 / "VRN2_Closeout_v0144.json") or {}', 'cl = j(v2 / "VRN2_Closeout_v0145.json") or {}')
rep('"%s|⑧b 收尾收據 v0144 · rc %s', '"%s|⑧b 收尾收據 v0145 · rc %s')
rep('"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0144.json(啟動器 v0144 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"', '"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0145.json(啟動器 v0145 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"')
rep('''ss_ = cl.get("ssot_sync") or {}
if ss_:
    print("%s|⑤b SSOT-ID 核號同步 · %s" % ({"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(ss_.get("lamp"), "YELLOW"), (ss_.get("detail") or "")[:200]))''',
    '''ss_ = cl.get("ssot_sync") or {}
if ss_:
    print("%s|⑤b SSOT-ID 核號同步 · %s" % ({"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(ss_.get("lamp"), "YELLOW"), (ss_.get("detail") or "")[:200]))
pt_ = j(v2 / "VRN2_Phase_Timing_latest.json") or {}
if pt_:
    print("GRAY|階段耗時(秒 · 管理器 %s)· %s · 其他 %.0f · 總 %.0f" % (pt_.get("manager", ""), " · ".join("%s %.0f" % (p_.get("phase", ""), p_.get("seconds", 0)) for p_ in (pt_.get("phases") or [])) or "無", pt_.get("untimed_s", 0), pt_.get("total_s", 0)))
else:
    print("GRAY|階段耗時 · 沒有 VRN2_Phase_Timing_latest.json(管理器不是 v0255 或 ⑦ 沒跑完)")''')
rep('"③ 本機套件不是 v0144,且讀不到', '"③ 本機套件不是 v0145,且讀不到'); rep('"③ 本機已是 v0144 套件(', '"③ 本機已是 v0145 套件(')
rep("($cf.version -eq 'ActivateVRN-2 v0144')", "($cf.version -eq 'ActivateVRN-2 v0145')")
for a, b in (("VRN2_Closeout_v0144", "VRN2_Closeout_v0145"), ("vrn2_release_v0144", "vrn2_release_v0145"), ("ActivateVRN-2_v0144", "ActivateVRN-2_v0145"), ("VRN-2 一鍵 v0144", "VRN-2 一鍵 v0145"), ("vrn2_v0144_", "vrn2_v0145_"), ("套件 v0144 就位", "套件 v0145 就位"), ("啟動器 v0144", "啟動器 v0145"), ("VRN2_UIAction_Config.json v0144", "VRN2_UIAction_Config.json v0145"), ("# v0144 發行所在", "# v0145 發行所在"), ("VRN2_Handover_v0144", "VRN2_Handover_v0146"), ("VRN2_Release_v0144", "VRN2_Release_v0145")):
    ps = ps.replace(a, b)
assert ps.count("v0144 = 啟動器 v0145 + runtime v0144") == 1; ps = ps.replace("v0144 = 啟動器 v0145 + runtime v0144", "v0144 = 啟動器 v0144 + runtime v0144")
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0144" in code and "v0144 =" not in code and "= v0144 +" not in code), line[:160]
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(old_cs, cs).replace("vrn2_release_v0144", "vrn2_release_v0145").replace("VRN2_OneClick_v0144.md", "VRN2_OneClick_v0145.md").replace("v0144", "v0145") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
# head template from the v0144 md
head = md.replace("```powershell\n" + re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + re.search(r"(?s)```text\n(.*?)\n```", md).group(1) + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + re.search(r"(?s)```bat\n(.*?)\n```", md).group(1) + "\n```", "```bat\n@ONE@\n```")
head = head.replace(old_want, "@WANT@").replace(old_cs, "@CS@").replace(old_cs[:12], "@CS@")
def hrep(a, b):
    global head
    assert head.count(a) == 1, (head.count(a), a[:80]); head = head.replace(a, b)
hrep("# VRN-2 一鍵 v0144(cmd / PowerShell 都能貼 · 套件 v0144 = 啟動器 v0144 + runtime v0144)", "# VRN-2 一鍵 v0145(cmd / PowerShell 都能貼 · 套件 v0145 = 啟動器 v0145 + runtime v0145 = v0144 + 管理器 v0255)")
hrep("v0144 = v0143 入口 + runtime v0144(= runtime v0142 的 162 個成員逐位元保留 + 4 個新檔):",
     "桌機 2026-10-29 08:14 實跑 v0144(52 份 · 2422 秒):前後端已連結、⑬ 走 duckdb 正式路徑、⑤b 綠;但 ⑦ 1201 秒裡約 1050 秒管理器沒有輸出 —— 擷取快取 52/52 命中,真正在跑的是 v0243 的冪等閘(3 份 ×2 單路序跑、不吃快取)。操作員問「是第一次啟動還是加速器沒作用」:都不是。\n\n"
     "v0145 = v0144 入口 + runtime v0145(= runtime v0144 的 166 個成員逐位元保留 + 1 個新檔):\n\n| 元件 | 版本 | 改了什麼 |\n|---|---|---|\n"
     "| 管理器 | VRN_SystemManager v0255(v0243 留著 · 釘名前版 v0243;v0244 ~ v0254 是桌機線 `functional modules\\VRN` 的號,本線跳過)| 冪等閘契約不變(同主跑子行程路徑 · 不吃擷取快取 · R1 / R2 / 主跑紀錄三方比對 · GREEN / STALE_RECORD / NONDETERMINISTIC),只改跑法:每波**一份一個單路子行程並行**(預設 3 路 · `$env:VRN2_IDEM_LANES`)· R1 跑完才跑 R2(OCR 快取不會被同一份的兩次同時寫)· 每 30 秒心跳 · 每波 / 每份秒數進 `IDEMPOTENCE_latest.json` 的 `timing`;階段計時(擷取迴圈 · 驗收 + 摘要 · 輸出冊 · U/I 輸出冊頁 · 調節輪 · 冪等閘)即時印、收尾一行 `[計] 階段耗時` · `VIA_Reports\\vrn2\\VRN2_Phase_Timing_latest.json` |\n"
     "| 啟動器 | ActivateVRN-2 v0145 | 改指管理器 v0255 · 收據 `VRN2_Closeout_v0145.json`;v0144 的 ⑤b / ⑬ / 處理器 v0108 / Workbench v0101 與 v0143 的單機閘 / 上限 / ⑫b 補放照舊 |\n\n"
     "前一版 v0144 = v0143 入口 + runtime v0144(= runtime v0142 的 162 個成員逐位元保留 + 4 個新檔):")
hrep("| 啟動器 | ActivateVRN-2 v0144 | 註冊處理器 v0108 · ⑤b · ⑬ · 收據 `VRN2_Closeout_v0144.json` 多 `ssot_sync` / `output_store`;`$env:VRN2_OUTPUT_DIR` 可預設輸出夾;v0143 的單機閘 / 上限 / ⑫b 補放照舊 |",
     "| 啟動器(v0144)| ActivateVRN-2 v0144 | 註冊處理器 v0108 · ⑤b · ⑬ · 收據多 `ssot_sync` / `output_store`;`$env:VRN2_OUTPUT_DIR` 可預設輸出夾;v0143 的單機閘 / 上限 / ⑫b 補放照舊 |")
hrep("| 步驟 | v0144 做什麼 |", "| 步驟 | v0145 做什麼 |")
hrep("| ① ② ③ ③b | 同 v0143(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|", "| ① ② ③ ③b | 同 v0144(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|")
hrep("| ④ | `python ActivateVRN-2_v0144.py [--source …]`:單機閘 → ①~⑤ → **⑤b SSOT-ID 核號同步** → ⑥~⑫ → ⑫b 補放 → 四點原文核對 → 收據 → **⑬ 輸出位置 · 增量庫** → Workbench v0101 渲染 + 開啟 |",
     "| ④ | `python ActivateVRN-2_v0145.py [--source …]`:單機閘 → ①~⑤ → ⑤b SSOT-ID 核號同步 → ⑥ → **⑦(管理器 v0255:階段計時即時印 · 冪等閘並行 + 心跳)** → ⑧~⑫ → ⑫b 補放 → 四點原文核對 → 收據 → ⑬ 輸出位置 · 增量庫 → Workbench v0101 渲染 + 開啟 |")
hrep("| ⑤ | 摘要多兩行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID |", "| ⑤ | 摘要多三行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID · **階段耗時**(管理器 v0255 的 `VRN2_Phase_Timing_latest.json`)|")
hrep("(設定檔 v0144)", "(設定檔 v0145)")
hrep("VRN-2 主體(管理器鏈 · ENG397 · 摘要器 · 驗證器 · 工具橋 · OCR 橋)與 runtime v0142 的 162 個成員一個位元組都不動;", "VRN-2 主體(ENG397 · 摘要器 · 驗證器 · 工具橋 · OCR 橋)與 runtime v0144 的 166 個成員一個位元組都不動(管理器 v0243 留著,v0255 疊在上面);")
for a, b in (("VRN2_OneClick_v0144", "VRN2_OneClick_v0145"), ("vrn2_release_v0144", "vrn2_release_v0145"), ("VRN2_Closeout_v0144.zip", "VRN2_Closeout_v0145.zip"), ("Downloads\\VRN2_Closeout_v0144", "Downloads\\VRN2_Closeout_v0145")):
    head = head.replace(a, b)
(S / "v145/oneclick145_head.md").write_text(head, encoding="utf-8", newline="\n")
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and "@" + "WANT@" not in newmd
(rel / "VRN2_OneClick_v0145.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot145.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline145.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0145.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0145", cs[:12])
# ===== operator v0106 from v0105 =====
md5 = (REPO / "vrn1_vrn2_oneclick_v0105/VRN1_VRN2_OneClick_v0105.md").read_text(encoding="utf-8")
ps5 = re.search(r"(?s)```powershell\n(.*?)\n```", md5).group(1); boot5 = re.search(r"(?s)```text\n(.*?)\n```", md5).group(1); one5 = re.search(r"(?s)```bat\n(.*?)\n```", md5).group(1)
p6 = ps5
def rep6(a, b):
    global p6
    assert p6.count(a) == 1, (p6.count(a), a[:80]); p6 = p6.replace(a, b)
rep6("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0144'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0145'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0144 程式碼 SHA-256", p6).group(1); assert old_h2 == old_cs
rep6("  $H2 = '%s'   # VRN-2 一鍵 v0144 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0145 程式碼 SHA-256" % cs)
rep6("  # ===== VRN-1 / VRN-2 操作員一鍵 v0105(2026-10-29 · ② 改指 VRN-2 一鍵 v0144:輸出位置 window I/O · DuckDB 增量 Parquet 庫 · SSOT-ID 協作;v0104 · ② 改指 VRN-2 一鍵 v0144:",
     "  # ===== VRN-1 / VRN-2 操作員一鍵 v0106(2026-10-29 · ② 改指 VRN-2 一鍵 v0145:管理器 v0255 冪等閘並行 · 心跳 · 階段計時;v0105 · ② 改指 VRN-2 一鍵 v0144:輸出位置 window I/O · DuckDB 增量 Parquet 庫 · SSOT-ID 協作;v0104 · ② 改指 VRN-2 一鍵 v0143:")
rep6("操作員一鍵 v0105 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0106 · {0} · VRN-1 {1} · VIA {2}")
p6 = p6.replace("VRN2_OneClick_v0144.md", "VRN2_OneClick_v0145.md").replace("VRN-2 一鍵 v0144", "VRN-2 一鍵 v0145").replace("套件 v0144 = 啟動器 v0144 + runtime v0144", "套件 v0145 = 啟動器 v0145 + runtime v0145").replace("ActivateVRN-2_v0144 單機閘", "ActivateVRN-2_v0145 單機閘")
assert p6.count("v0105 · ② 改指 VRN-2 一鍵 v0145:輸出位置") == 1; p6 = p6.replace("v0105 · ② 改指 VRN-2 一鍵 v0145:輸出位置", "v0105 · ② 改指 VRN-2 一鍵 v0144:輸出位置")
for line in p6.splitlines():
    code = line.split("#", 1)[0]; assert "v0144" not in code or "v0144:" in code, line[:160]
cs6 = hashlib.sha256(p6.encode("utf-8")).hexdigest()
boot6 = boot5.replace(re.search(r"\$H  = '([0-9a-f]{64})'", boot5).group(1), cs6).replace("vrn1_vrn2_oneclick_v0105", "vrn1_vrn2_oneclick_v0106").replace("VRN1_VRN2_OneClick_v0105.md", "VRN1_VRN2_OneClick_v0106.md").replace("操作員一鍵 v0105", "操作員一鍵 v0106") + "\n"
one6 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot6.encode("utf-16-le")).decode("ascii")
text = md5.replace("```powershell\n" + ps5 + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + boot5 + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + one5 + "\n```", "```bat\n@ONE@\n```")
old_cs5 = hashlib.sha256(ps5.encode("utf-8")).hexdigest()
text = text.replace(old_cs5, cs6).replace(old_cs5[:12], cs6[:12]).replace(old_h2, cs).replace(old_h2[:12], cs[:12]).replace("v0105", "v0106").replace("VRN-2 一鍵 v0144", "VRN-2 一鍵 v0145").replace("vrn2_release_v0144", "vrn2_release_v0145").replace("VRN2_OneClick_v0144", "VRN2_OneClick_v0145")
head_old = text.split("\n", 1)[0]; text = text.replace(head_old, "# VRN-1 / VRN-2 操作員一鍵 v0106(cmd / PowerShell 都能貼 · v0105 + ② 改指 VRN-2 一鍑 v0145:管理器 v0255 冪等閘並行 · 心跳 · 階段計時)".replace("一鍑", "一鍵"), 1)
intro_old = text.split("\n\n", 2)[1]; text = text.replace(intro_old, "桌機 2026-10-29 08:14 實跑 v0144(52 份 · 2422 秒):前後端已連結,慢在 ⑦ 的冪等閘序跑(約 1050 秒無輸出)。v0106 = v0105 + ② 改指 **VRN-2 一鍵 v0145**(套件 v0145 = 啟動器 v0145 + runtime v0145 = v0144 + 管理器 v0255);其餘一字不改。\n\n" + intro_old, 1)
text = text.replace("@PS@", p6).replace("@BOOT@", boot6.rstrip("\n")).replace("@ONE@", one6)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p6 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot6
(op6 / "VRN1_VRN2_OneClick_v0106.md").write_text(text, encoding="utf-8", newline="\n"); (op6 / "boot_pair106.ps1").write_text(boot6, encoding="utf-8", newline="\n"); (op6 / "oneline_pair106.txt").write_text(one6 + "\n", encoding="utf-8"); (op6 / "Run-VRN1-VRN2-v0106.ps1").write_text(p6 + "\n", encoding="utf-8", newline="\n"); (op6 / "code_sha.txt").write_text(cs6)
print("operator v0106", cs6[:12])
# ===== LocalRound re-point =====
lr = REPO / "VRN2_LocalRound_v0100.md"; s = lr.read_text(encoding="utf-8")
if "VRN1_VRN2_OneClick_v0106.md" in s:   # already re-pointed by an earlier build: only refresh $H_OP
    s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0106 程式碼 SHA-256", "$H_OP = '%s'   # 操作員一鍵 v0106 程式碼 SHA-256" % cs6, s, count=1); assert cs6 in s
    lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP refreshed", cs6[:12]); raise SystemExit(0)
def lrep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
lrep("# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0144(開 Workbench)→ 打包貼回材料)", "# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0145(開 Workbench)→ 打包貼回材料)")
lrep("> **2026-10-29 v0144 改指(操作員:", "> **2026-10-29 v0145 改指(桌機 08:14 實跑 v0144 貼回:前後端已連結 · 2422 秒慢在 ⑦ 冪等閘序跑約 1050 秒無輸出;操作員問「是第一次啟動還是加速器沒作用」→ 都不是):** 本段現在指 操作員一鍵 **v0106** → VRN-2 一鍵 **v0145**(管理器 v0255:冪等閘每波 3 份並行 · 30 秒心跳 · 階段計時 `VRN2_Phase_Timing_latest.json`;其餘同 v0144)。④ 貼回包改收 `VRN2_Closeout_v0145.json` 與 `VRN2_Phase_Timing_latest.json`,不再把前一版收據與(跑完本來就會移除的)鎖檔算成「缺」。\n> **2026-10-29 v0144 改指(操作員:")
lrep("本段現在指 操作員一鍵 **v0105** → VRN-2 一鍵 **v0144**(⑤b SSOT-ID 核號同步", "本段當時指 操作員一鍵 **v0105** → VRN-2 一鍵 **v0144**(⑤b SSOT-ID 核號同步")
lrep("| ③ 跑 | 從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0105.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0144 套件**(啟動器 v0144:⑤b SSOT-ID 核號同步 · ⑬ 輸出位置 / DuckDB 增量庫 · 處理器 v0108(v0105 / v0107 是桌機線的號)· Workbench v0101;v0143 的單機閘 / 上限 / ⑫b 補放照舊;",
     "| ③ 跑 | 從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0106.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0145 套件**(啟動器 v0145 → 管理器 v0255:冪等閘每波 3 份並行 · 30 秒心跳 · 階段計時;v0144 的 ⑤b SSOT-ID 核號同步 · ⑬ 輸出位置 / DuckDB 增量庫 · 處理器 v0108(v0105 / v0107 是桌機線的號)· Workbench v0101 與 v0143 的單機閘 / 上限 / ⑫b 補放照舊;")
lrep("最後 300 行貼包 · `VRN2_Closeout_v0144.json` · `VRN2_OutputStore_latest.json` · `IDEMPOTENCE_latest.json`", "最後 300 行貼包 · `VRN2_Closeout_v0145.json` · `VRN2_Phase_Timing_latest.json` · `VRN2_OutputStore_latest.json` · `IDEMPOTENCE_latest.json`")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0105 程式碼 SHA-256\(VRN1_VRN2_OneClick_v0105\.md powershell 區塊 · ② 指 VRN-2 一鍵 v0144\)", "$H_OP = '%s'   # 操作員一鍵 v0106 程式碼 SHA-256(VRN1_VRN2_OneClick_v0106.md powershell 區塊 · ② 指 VRN-2 一鍵 v0145)" % cs6, s, count=1); assert cs6 in s
lrep("  $k3 = '③ 跑 VRN-2 v0144'", "  $k3 = '③ 跑 VRN-2 v0145'")
lrep("  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0105' 'VRN1_VRN2_OneClick_v0105.md' $H_OP", "  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0106' 'VRN1_VRN2_OneClick_v0106.md' $H_OP")
lrep("  foreach ($rel in 'VRN2_Closeout_v0144.json', 'VRN2_Closeout_v0143.json', 'VRN2_OutputStore_latest.json', 'VRN2_Output_Config.json', 'VRN2_Launcher.lock', 'IDEMPOTENCE_latest.json',", "  foreach ($rel in 'VRN2_Closeout_v0145.json', 'VRN2_Phase_Timing_latest.json', 'VRN2_OutputStore_latest.json', 'VRN2_Output_Config.json', 'IDEMPOTENCE_latest.json',")
lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP", cs6[:12])
