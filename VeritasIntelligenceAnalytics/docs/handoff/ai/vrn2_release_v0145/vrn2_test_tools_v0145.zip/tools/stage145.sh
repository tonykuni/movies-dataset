#!/bin/bash
# v0145 放進倉:docs/handoff/ai/vrn2_release_v0145/ + vrn1_vrn2_oneclick_v0106/ + functional modules/VRN/ 新工具(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v145
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0145; OP=$REPO/vrn1_vrn2_oneclick_v0106; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v145")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0145"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0106")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("full144.log", "full144.rc", "t145_setup.log", "pscheck144.log", "scen144.rc", "scen144_first.log", "scen144_again.log", "scen144_tamper.log", "scen144_setup.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0145_selftest.log", "VRN_SystemManager_v0255_selftest.log")]
v2 = W / "t145/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0145.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_Activate_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Output_Config.json", "VRN2_Phase_Timing_latest.json"):
    logs.append(("t145/" + n, v2 / n))
for n in ("VRN2_NUMBER_REQUEST_latest.json", "VRN2_NUMBER_STATE_latest.json"):
    logs.append(("t145/contract/" + n, W / "t145/VIA/functional modules/VRN2/contract" / n))
z(D / "logs_v0145.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py"))]
z(D / "vrn2_test_tools_v0145.zip", tools)
z(OP / "tools_v0106.zip", [("tools/" + q.name, q) for q in (W / "operator106" / "boot_pair106.ps1", W / "operator106" / "oneline_pair106.txt", W / "operator106" / "Run-VRN1-VRN2-v0106.ps1")])
for n in ("VRN1_VRN2_OneClick_v0106.md", "VRN1_VRN2_Verification_v0106.md"): shutil.copy(W / "operator106" / n, OP / n)
for n in ("VRN2_Closeout_v0145.zip", "VRN2_Release_v0145.json", "VRN2_OneClick_v0145.md", "VRN2_Verification_v0145.md"): shutil.copy(W / "release145" / n, D / n)
# 新成員只在私有 runtime zip(functional modules/VRN2)與 vrn2_test_tools_v0145.zip/new;不放共用 VRN 夾(桌機線 v0105 / v0107 在那裡,免得版本鏈混線)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
