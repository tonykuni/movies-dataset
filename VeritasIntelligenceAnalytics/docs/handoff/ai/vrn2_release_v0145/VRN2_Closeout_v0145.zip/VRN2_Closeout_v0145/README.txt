VRN2_Closeout_v0145 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0145.py [--source <folder>] [--no-install] [--no-open]
Runtime: VRN2_Runtime_v0145.zip = runtime v0144 (166 members byte-identical) + VRN_SystemManager_v0255
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0145 (desktop run 2026-10-29 08:14 · 2422 s · U/I bound, ⑦ 1201 s with ~1050 s silence):
 - manager v0255 (PRIOR pinned v0243; v0244–v0254 are the desktop line's numbers): idempotence gate runs each wave as one
   single-lane subprocess PER FILE in parallel (default 3 lanes · VRN2_IDEM_LANES), R1 completes before R2; heartbeat every 30 s;
   per-wave / per-file wall time in IDEMPOTENCE_latest.json; phase timing (p1loop · acceptance · books · U/I · funnel · gate)
   printed live, one [計] 階段耗時 summary line, VIA_Reports/vrn2/VRN2_Phase_Timing_latest.json.
 - launcher v0145: MANAGER → v0255, receipt VRN2_Closeout_v0145.json; v0144 steps ⑤b / ⑬ / handler v0108 / Workbench v0101 unchanged.
Exit codes: 0 GREEN · 2 YELLOW · 1 RED.
