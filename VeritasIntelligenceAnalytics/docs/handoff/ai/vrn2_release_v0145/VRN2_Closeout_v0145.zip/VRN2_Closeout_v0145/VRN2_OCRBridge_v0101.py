# -*- coding: utf-8 -*-
"""VRN2_OCRBridge v0101 — VRN-2 OCR 隔離橋(放在隔離 venv envs\\vrn2_ocr 裡跑 · 不進主環境 · LL#21–24)。
用法:python VRN2_OCRBridge_v0100.py job.json out.json
job = {"images": [png 路徑 ...]} → out = {"engine": ..., "results": [{"image", "lines": [{"box": [[x,y]x4], "text", "score"}]}]}
OCR 套件用字串動態載入(rapidocr_onnxruntime → rapidocr),主環境 AST 掃描不會把它當成要裝的套件。"""
# [VIA:ACCEL-BRIDGE:v0111] 加速器橋:隔離 venv 內找不到正本就不改行為
import importlib
import json
import sys


def _engine():
    ort = importlib.import_module("onnxruntime")
    ort.disable_telemetry_events()
    for name in ("rapidocr_onnxruntime", "rapidocr"):
        try:
            mod = importlib.import_module(name)
            ver = getattr(mod, "__version__", "")
            return name, ver, mod.RapidOCR()
        except Exception:
            continue
    raise RuntimeError("隔離環境沒有 rapidocr_onnxruntime / rapidocr")


def _space(text, wboxes):
    """字元框間距補空格(rapidocr 英文常黏在一起):間距 > 行高中位數 × 0.35 且兩側都是英數 / 標點才補 · 中文之間不補。"""
    chars = list(text)
    if not wboxes or len(wboxes) != len(chars):
        return text
    xs = [(min(p[0] for p in b), max(p[0] for p in b)) for b in wboxes]
    hs = sorted(max(p[1] for p in b) - min(p[1] for p in b) for b in wboxes)
    if not hs:
        return text
    th = max(2.0, hs[len(hs) // 2] * 0.35)          # 實測(MQ-1560):以行高正規化 · 真空格 ≥0.4 · 字內 ≤0.2 · 0.35 為界
    out = chars[0]
    for i in range(1, len(chars)):
        gap = xs[i][0] - xs[i - 1][1]
        a_, b_ = chars[i - 1], chars[i]
        if gap > th and a_.isascii() and b_.isascii() and a_ != " " and b_ != " ":
            out += " "
        out += b_
    return out


def _respace(text, protect, wn):
    """v0100 字典斷詞補空格(wordninja · 只在隔離 venv):≥9 字母的長串才斷 · 同文件單獨出現的字(專有名詞)先保護 · 連續單一字母併回(mgmt)· 數字 / 字母交界 · 句點逗號後補空格。"""
    import re
    def seg2(w):
        if len(w) < 5 or wn is None:
            return w
        merged, buf = [], ""
        for p in wn.split(w):
            if len(p) == 1 and p.lower() not in ("a", "i"):
                buf += p
                continue
            if buf:
                merged.append(buf)
                buf = ""
            merged.append(p)
        if buf:
            merged.append(buf)
        return " ".join(merged) if "".join(merged) == w else w
    def seg(m):
        w = m.group(0)
        for p in protect:
            if w.lower().startswith(p.lower()) and len(w) > len(p) + 2:
                return w[:len(p)] + " " + seg2(w[len(p):])
        return seg2(w) if len(w) >= 9 else w
    t = re.sub(r"[A-Za-z]{6,}", seg, text)
    t = re.sub(r"(?<=[a-z]{2})(?=\d)", " ", t)
    t = re.sub(r"(?<=\d)(?=[A-Z][a-z]{2})|(?<=\d)(?=[A-Z]{2,}\b)", " ", t)
    t = re.sub(r"(?<=[a-z])\.(?=[A-Z])", ". ", t)
    t = re.sub(r"(?<=[a-z]),(?=[A-Za-z])", ", ", t)
    return re.sub(r" {2,}", " ", t)


def _lines(name, eng, path):
    out = []
    if name == "rapidocr_onnxruntime":
        try:
            res, _ = eng(path, return_word_box=True)
        except TypeError:
            res, _ = eng(path)
        for r in res or []:
            box, text, score = r[0], str(r[1]), float(r[2])
            if len(r) > 3 and isinstance(r[3], list):
                text = _space(text, r[3])
            out.append({"box": [[float(a), float(b)] for a, b in box], "text": text, "score": score})
    else:
        r = eng(path)
        boxes, txts, scores = getattr(r, "boxes", None), getattr(r, "txts", None), getattr(r, "scores", None)
        for box, text, score in zip(boxes if boxes is not None else [], txts or [], scores or []):
            out.append({"box": [[float(a), float(b)] for a, b in box], "text": str(text), "score": float(score)})
    return out


def main(argv):
    job = json.load(open(argv[1], encoding="utf-8"))
    name, ver, eng = _engine()
    res = [{"image": p, "lines": _lines(name, eng, p)} for p in job.get("images", [])]
    try:
        wn = importlib.import_module("wordninja")
    except Exception:  # noqa: BLE001
        wn = None
    import re
    protect = sorted({x["text"] for r in res for x in r["lines"] if re.fullmatch(r"[A-Z][a-z]{3,}", x["text"])}, key=len, reverse=True)
    for r in res:
        for x in r["lines"]:
            x["raw"] = x["text"]
            x["text"] = _respace(x["text"], protect, wn)
    json.dump({"engine": "%s %s" % (name, ver), "results": res}, open(argv[2], "w", encoding="utf-8"), ensure_ascii=False)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
