#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""One accelerated child entry; preserves the target's __file__, argv and exit code."""
from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import runpy
import sys


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True)
    parser.add_argument("--kind", choices=("code", "module", "script"), required=True)
    parser.add_argument("--target", required=True)
    parser.add_argument("arguments", nargs=argparse.REMAINDER)
    options = parser.parse_args(argv)
    path = Path(__file__).resolve().with_name("VIA_ExecutionBridge_v0103.py")
    spec = importlib.util.spec_from_file_location("via_execution_bridge_for_child", path)
    bridge = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = bridge
    spec.loader.exec_module(bridge)
    # [VIA:ACCEL-BRIDGE:v0111] Applied before every target, including Python -c/-m.
    state = bridge.activate(options.root)
    print("[鎖驗證] " + " · ".join(f"{name}={entry['mode']}" for name, entry in state["verification"].items()), flush=True)
    print("[加速] " + Path(state["accelerator"]).name + " · " + options.kind, flush=True)
    arguments = options.arguments[1:] if options.arguments[:1] == ["--"] else options.arguments
    sys.argv = [options.target if options.kind != "code" else "-c", *arguments]
    if options.kind == "code":
        exec(compile(options.target, "<string>", "exec"), {"__name__": "__main__", "__package__": None})
    elif options.kind == "module":
        runpy.run_module(options.target, run_name="__main__", alter_sys=True)
    else:
        target = Path(options.target).resolve()
        if str(target.parent) not in sys.path:
            sys.path.insert(0, str(target.parent))
        runpy.run_path(str(target), run_name="__main__")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
