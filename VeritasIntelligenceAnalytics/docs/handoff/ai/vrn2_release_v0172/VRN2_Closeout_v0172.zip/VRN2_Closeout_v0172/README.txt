VRN2_Closeout_v0172 — VRN-2 closeout package (2026-11-03 · VRN P0 F1 / F2 / F3: typed Parquet · UPSIDE_ADJ ratio column · Basic Info merged view)

Entry: python ActivateVRN-2_v0172.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0128.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0120.md (same release folder).
Runtime: VRN2_Runtime_v0162.zip = v0160 (200 members byte-identical) + VRN2_HistoryAlign_v0103 + VRN2_ConsensusJoin_v0107 + VRN2_Workbench_v0107.

v0172 (operator 2026-11-03: "新增小數欄,舊欄保留並標註,三項一起修"):
 - F1 VRN2_HistoryAlign_v0103 — when the prior cannot write FinancialAligned / Deleted Parquet (ArrowInvalid: None turned into "" in a numeric column),
   rewrite it typed (numbers float64 with null · strings · truly mixed columns as text) and read it back before replacing. JSON / CSV unchanged.
 - F2 VRN2_ConsensusJoin_v0107 — Combined gains UPSIDE_ADJ (pure ratio = TARGET_PRICE(ADJ) / ADJ_CLOSE - 1, 9 decimals) right after the kept
   percent column UPSIDE_PCT(ADJ); output/VRN2_Combined_columns_latest.json annotates unit / definition / old-or-new. Filled cells never overwritten.
 - F3 VRN2_Workbench_v0107 — Basic Info merged view (verbatim book tagged 原 · Combined fills tagged 合 with source · neither book changed) ·
   upside shown from UPSIDE_ADJ x 100 · 3 more verification lamps · column notes · self-contained (skips v0105 / accelfix v0106) · accel marker.
v0170: Workbench v0105 + ConsensusJoin v0106 snapshot backfill. v0168: manager v0259. v0163: no MOPS.
Launcher number v0171 is skipped (release folder v0171 only replaced RoundAll; there is no launcher v0171).
Verification: see VRN2_Verification_v0172.md. Hashes: PACKAGE_SHA256.json.
