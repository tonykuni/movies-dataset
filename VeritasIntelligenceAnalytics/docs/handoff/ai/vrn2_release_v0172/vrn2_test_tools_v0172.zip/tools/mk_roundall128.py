"""VRN2_RoundAll_v0128.py = 本線 v0127(倉裡 vrn2_release_v0171)+ 套件 v0172(啟動器 v0172 · runtime v0162)+ VRN P0 三項的 ⑤ 自動修。
操作員 2026-11-03:「新增小數欄,舊欄保留並標註,三項一起修 · 授權依建議最佳化完成」。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v172")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0171/VRN2_RoundAll_v0127.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0127')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0127 — ', '"""VRN2_RoundAll v0128 — ', 1)
at = doc.index("v0127(")
doc = doc[:at] + '''v0128(操作員 2026-11-03:「新增小數欄,舊欄保留並標註,三項一起修 · 授權依建議最佳化完成」· 另一工作階段的 VRN P0 三項 F1 / F2 / F3 用桌機 15:18 真資料核實屬實):
  · 套件 v0172(啟動器 v0172 · runtime v0162 = v0160 的 200 個成員一字不改 + 三個新尾版):
    F1 VRN2_HistoryAlign_v0103:FinancialAligned 的 Parquet「(沒寫:ArrowInvalid)」(v0100 把 None 換成 "" → 同欄數字與字串混型)→
       前版照寫,只有 Parquet 沒寫成時依欄位型別重寫(數字欄空值 = null · 真混型欄整欄轉字串 · 讀回比對列數 / 欄名才換上)。JSON / CSV 不動。
    F2 VRN2_ConsensusJoin_v0107:Combined 新增 UPSIDE_ADJ(純小數 · TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1 · 9 位)緊接在舊欄 UPSIDE_PCT(ADJ) 後;
       舊欄(百分數)保留不改語意 · output/VRN2_Combined_columns_latest.json 標註兩欄的單位 / 定義 / 新舊。增量庫照 v0102 的 ALTER TABLE 加欄(舊列 NULL)。
    F3 VRN2_Workbench_v0107:Basic Info · 合併檢視(原文冊 × Combined 逐份對起來 · 原文有值標「原」· 原文空才用 Combined 標「合」· 兩冊不改)·
       上漲空間由小數欄 × 100 顯示 % · 資料驗證燈多三列(Basic 合併 · 新舊上漲欄互核 · 歷史對齊 Parquet)· 表頭滑過看欄位標註 ·
       自包含(跳過 v0105 與桌機 accelfix 的 v0106 複本 · 不重複後處理)· 第 3 行帶加速器標記(accelfix 不再複製)。
  · ⑤ 自動修新觸發(不用整輪 · 幾分鐘修完):
    history ← 歷史對齊收據 written[...].parquet 是「(沒寫…」→ 先只增不覆寫補放 HistoryAlign v0103 鏈 → 重跑 ⑬b;
    combined ← Combined 冊第一列沒有 UPSIDE_ADJ → 補放 ConsensusJoin 鏈(v0107)→ 重組;
    workbench ← 頁面沒有 v0107 標記 → 補放 Workbench v0107 → 重渲染;增量庫(⑬)照舊跟著有修正的輪次補寫。
  · ⑥ 除錯:Combined 欄序以 v0107 為準(UPSIDE_ADJ 緊接 UPSIDE_PCT(ADJ));Workbench 標記多「Basic Info 合併檢視」。
  · 自測 98 項(v0127 的 94 項 + 93 ~ 96)。共用 MarketFetch 與 VDF 引擎照舊只讀不改;版號兩邊(本分支 · main)都查過沒人用。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0127.py", "用法:python VRN2_RoundAll_v0128.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


# ── 套件 v0170 → v0172 · runtime v0160 → v0162(本文整批 · 版號之後)──
b0 = s.index('VERSION = "v0127"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0170", "v0172").replace("VRN2_Runtime_v0160", "VRN2_Runtime_v0162")
s = pre + post
rep('VERSION = "v0127"', 'VERSION = "v0128"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0127.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0127.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0128.py"', n_dl)
rep('"VRN2_RoundAll_v0127.py" in html_', '"VRN2_RoundAll_v0128.py" in html_')
rep("· v0126 起 93 項 · v0127 起 94 項。", "· v0126 起 93 項 · v0127 起 94 項 · v0128 起 98 項。")
# ── SELFTESTS:Workbench v0107 · HistoryAlign v0103 · ConsensusJoin v0107(前版照舊由鏈自測)──
rep('SELFTESTS = (("VRN2_Workbench_v0105.py", 600), ("VRN2_HistoryAlign_v0100.py", 300), ("VRN2_HistoryAlign_v0102.py", 300),',
    'SELFTESTS = (("VRN2_Workbench_v0107.py", 600), ("VRN2_HistoryAlign_v0100.py", 300), ("VRN2_HistoryAlign_v0102.py", 300), ("VRN2_HistoryAlign_v0103.py", 300),')
rep('("VRN2_OutputStore_v0102.py", 300), ("VRN2_ConsensusJoin_v0106.py", 900), ("VRN_SystemManager_v0259.py", 1800),',
    '("VRN2_OutputStore_v0102.py", 300), ("VRN2_ConsensusJoin_v0107.py", 900), ("VRN_SystemManager_v0259.py", 1800),')
rep('''and ("VRN2_ConsensusJoin_v0106.py", 900) in SELFTESTS and ("VRN2_ConsensusJoin_v0105.py", 900) not in SELFTESTS and ("VRN2_Workbench_v0105.py", 600) in SELFTESTS''',
    '''and ("VRN2_ConsensusJoin_v0107.py", 900) in SELFTESTS and ("VRN2_ConsensusJoin_v0106.py", 900) not in SELFTESTS and ("VRN2_Workbench_v0107.py", 600) in SELFTESTS''')
# ── Combined 欄序 / Workbench 標記 ──
rep('COMBINED_TAIL = ["CURRENT_PRICE_REPORT", "UPSIDE_PCT(ADJ)", "ADJ_CLOSE", "ADJ_CLOSE_BEFORE_REPORT", "TOPIC & SUMMARY", "STATUS"]',
    'COMBINED_TAIL = ["CURRENT_PRICE_REPORT", "UPSIDE_PCT(ADJ)", "UPSIDE_ADJ", "ADJ_CLOSE", "ADJ_CLOSE_BEFORE_REPORT", "TOPIC & SUMMARY", "STATUS"]   # v0128 UPSIDE_ADJ 小數欄(ConsensusJoin v0107 · 舊欄百分數保留)')
rep('''("function unitOf", "百萬台幣換算"))''', '''("function unitOf", "百萬台幣換算"), ('id="wb107b"', "Basic Info 合併檢視(Workbench v0107)"))''')
# ── ⑤ 計畫:三個新觸發 ──
rep('''def plan_fixes(root: Path, receipt: dict, fetch_py, args, market_tool: str = "") -> list:''',
    '''HISTORY_CHAIN = ("VRN2_HistoryAlign_v0103.py", "VRN2_HistoryAlign_v0102.py", "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py")   # v0128 F1
WORKBENCH_CHAIN = ("VRN2_Workbench_v0107.py",)                                  # v0128 F3(前版用桌機 / runtime 夾裡已有的)
UPSIDE_NEW = "UPSIDE_ADJ"
WB_MARK = 'id="wb107-css"'


def history_parquet_due(v2) -> str:
    """v0128 F1:歷史對齊收據裡沒寫成的 Parquet 冊名(逗號分隔);都寫了 / 沒收據 → ""。"""
    w = (jread(Path(v2) / "VRN2_HistoryAlign_latest.json", {}) or {}).get("written") or {}
    return ",".join(n for n in ("FinancialAligned", "Deleted") if isinstance(w.get(n), dict) and str(w[n].get("parquet", "")).startswith("(沒寫"))


def history_parquet_why(v2) -> str:
    """v0128 收據寫的沒寫原因(照實 · 例 ArrowInvalid = 同欄混型 · ImportError = 這支 Python 的 pyarrow 載不起來)。"""
    w = (jread(Path(v2) / "VRN2_HistoryAlign_latest.json", {}) or {}).get("written") or {}
    why = sorted({str(x.get("parquet", "")).split(")", 1)[0].strip("(").replace("沒寫:", "") for x in w.values() if isinstance(x, dict) and str(x.get("parquet", "")).startswith("(沒寫")})
    return " / ".join(w2 + ("(同欄混型)" if w2 == "ArrowInvalid" else "(這支 Python 的 pyarrow 載不起來)" if w2 == "ImportError" else "") for w2 in why if w2)


def upside_column_due(v2) -> bool:
    """v0128 F2:Combined 冊有列但第一列沒有 UPSIDE_ADJ(ConsensusJoin v0107 之前組的)。"""
    comb = jread(Path(v2) / "output" / "VRN2_Combined_latest.json", None)
    return isinstance(comb, list) and bool(comb) and isinstance(comb[0], dict) and UPSIDE_NEW not in comb[0]


def workbench_due(v2) -> bool:
    """v0128 F3:Workbench 頁不是 v0107 後處理過的(沒有 wb107-css)。"""
    wb = Path(v2) / "VRN2_Workbench_latest.html"
    try:
        return wb.is_file() and WB_MARK not in wb.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False


def install_chain(pkg, root, names) -> tuple:
    """v0128 套件 runtime 的一串成員只增不覆寫地放進 functional modules\\\\VRN2;回 (補放了哪些, 沒放的原因)。沒套件 → ([], [])。"""
    if not pkg or not (Path(pkg) / RUNTIME_ZIP).is_file():
        return [], []
    put, refused = [], []
    for name in names:
        try:
            got, why = install_runtime_member(pkg, root, name)
        except (OSError, KeyError, zipfile.BadZipFile) as error:
            got, why = None, "%s: %s" % (type(error).__name__, str(error)[:80])
        if got is None:
            refused.append(why)
        elif why == "補放":
            put.append(name)
    return put, refused


def plan_fixes(root: Path, receipt: dict, fetch_py, args, market_tool: str = "") -> list:''')
rep('''    if mjson.is_file() and (planned & {"market", "market_fill"} or not hrec.is_file() or _mtime(mjson) > _mtime(hrec) or (receipt.get("history_align") or {}).get("lamp") == "GRAY"):
        plan.append(("history", "市場資料比歷史對齊新 / 歷史對齊沒跑 → 重跑 ⑬b"))''',
    '''    pq_due = history_parquet_due(v2)                                           # v0128 F1
    if mjson.is_file() and (planned & {"market", "market_fill"} or not hrec.is_file() or _mtime(mjson) > _mtime(hrec) or (receipt.get("history_align") or {}).get("lamp") == "GRAY"):
        plan.append(("history", "市場資料比歷史對齊新 / 歷史對齊沒跑 → 重跑 ⑬b" + (" · %s 的 Parquet 沒寫 → HistoryAlign v0103 依欄位型別重寫" % pq_due if pq_due else "")))
    elif pq_due:
        plan.append(("history", "歷史對齊 %s 的 Parquet 沒寫(%s)→ HistoryAlign v0103 依欄位型別重寫(JSON / CSV 照舊)" % (pq_due, history_parquet_why(v2) or "原因沒寫")))''')
rep('''    elif (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and tp_sync_due(v2):                # v0120
        plan.append(("combined", "TARGET_PRICE(ADJ) 同步還原 + 共識照 TWSE / TPEX 格式合併(ConsensusJoin v0105)→ 重組 Combined"))''',
    '''    elif (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and tp_sync_due(v2):                # v0120
        plan.append(("combined", "TARGET_PRICE(ADJ) 同步還原 + 共識照 TWSE / TPEX 格式合併(ConsensusJoin v0105)→ 重組 Combined"))
    elif (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and upside_column_due(v2):          # v0128 F2
        plan.append(("combined", "Combined 還沒有 UPSIDE_ADJ 小數欄 → ConsensusJoin v0107 重組(舊欄 UPSIDE_PCT(ADJ) 百分數保留 · 欄位標註)"))''')
rep('''    if plan or not wb.is_file():
        plan.append(("workbench", "Workbench 重渲染(最新收據)"))''',
    '''    if plan or not wb.is_file() or workbench_due(v2):                           # v0128 F3 頁面不是 v0107 後處理過的也重渲染
        plan.append(("workbench", "Workbench 重渲染(最新收據)" if (plan or not wb.is_file()) else "Workbench 重渲染(換 v0107 · Basic Info 合併檢視 · 上漲空間小數欄 · 欄位標註)"))''')
# ── ⑤ 執行:history / workbench 先只增不覆寫補放新尾版 ──
rep('''        elif key == "history":
            ha = _latest_in(rt, "VRN2_HistoryAlign_v[0-9][0-9][0-9][0-9].py")
            rc, lines = run_stream([vpy, "-X", "utf8", str(ha), "align", "--root", str(root)], cwd=rt, env=env, timeout=900, prefix="    [⑬b] ")
            lamp, detail = _cli_lamp(lines)''',
    '''        elif key == "history":
            put_h, refused_h = install_chain(state.get("pkg"), root, HISTORY_CHAIN)    # v0128 F1 HistoryAlign v0103 鏈只增不覆寫
            ha = _latest_in(rt, "VRN2_HistoryAlign_v[0-9][0-9][0-9][0-9].py")
            rc, lines = run_stream([vpy, "-X", "utf8", str(ha), "align", "--root", str(root)], cwd=rt, env=env, timeout=900, prefix="    [⑬b] ")
            lamp, detail = _cli_lamp(lines)
            pq_left = history_parquet_due(v2)
            detail = ("%s%s%s · %s" % (("補放 " + "、".join(put_h) + " · ") if put_h else "", ("不覆寫 " + " / ".join(refused_h)[:120] + " · ") if refused_h else "",
                                       ("Parquet 仍沒寫:" + pq_left) if pq_left else "Parquet 寫成", detail)).strip(" ·")''')
rep('''        elif key == "workbench":
            wb = _latest_in(rt, "VRN2_Workbench_v[0-9][0-9][0-9][0-9].py")''',
    '''        elif key == "workbench":
            install_chain(state.get("pkg"), root, WORKBENCH_CHAIN)                 # v0128 F3 Workbench v0107 只增不覆寫
            wb = _latest_in(rt, "VRN2_Workbench_v[0-9][0-9][0-9][0-9].py")''')
# ── 自測 93 ~ 96 ──
rep('''        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''',
    '''        n93 = 2026
        want93 = COMBINED_HEAD + ["%d_DILUTED_EPS_FACTSET" % y for y in (n93, n93 + 1, n93 + 2)] + ["%d_PER_FACTSET" % y for y in (n93, n93 + 1, n93 + 2)] + COMBINED_TAIL
        chk("93 v0128:Combined 欄序 = ConsensusJoin v0107(UPSIDE_ADJ 緊接 UPSIDE_PCT(ADJ) · 舊欄保留)· Workbench 標記含 Basic Info 合併檢視",
            want93[want93.index("UPSIDE_PCT(ADJ)") + 1] == "UPSIDE_ADJ" and want93.count("UPSIDE_ADJ") == 1 and want93[-1] == "STATUS"
            and any(m == 'id="wb107b"' for m, _ in WORKBENCH_MARKS))
        A93 = type("A93", (), {"integrate": "skip"})
        with tempfile.TemporaryDirectory() as td94:
            v94 = Path(td94) / "VIA_Reports" / "vrn2"
            (v94 / "output").mkdir(parents=True)
            (v94 / "market").mkdir(parents=True)
            (v94 / "consensus").mkdir(parents=True)
            (v94 / "output" / "VRN2_BasicInfo_latest.json").write_text("[]", encoding="utf-8")
            (v94 / "VRN2_Workbench_latest.html").write_text("<html>" + WB_MARK + "</html>", encoding="utf-8")
            old94 = [{c: "" for c in want93 if c != "UPSIDE_ADJ"}]
            (v94 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps(old94), encoding="utf-8")
            plan94 = plan_fixes(Path(td94), {"market": {}, "consensus": {}}, "", A93(), "")
            d94 = next((d for k, d in plan94 if k == "combined"), "")
            (v94 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps([{c: "" for c in want93}]), encoding="utf-8")
            p94b = [k for k, _ in plan_fixes(Path(td94), {"market": {}, "consensus": {}}, "", A93(), "")]
            (v94 / "VRN2_Workbench_latest.html").write_text("<html>v0105 page</html>", encoding="utf-8")
            p94c = [k for k, _ in plan_fixes(Path(td94), {"market": {}, "consensus": {}}, "", A93(), "")]
        chk("94 v0128:⑤ 計畫 · Combined 沒有 UPSIDE_ADJ → combined(ConsensusJoin v0107 重組)+ Workbench 跟著 · 有新欄且頁是 v0107 → 不排 · 頁不是 v0107 → 只排 workbench",
            "UPSIDE_ADJ" in d94 and [k for k, _ in plan94][-1] == "workbench" and p94b == [] and p94c == ["workbench"])
        with tempfile.TemporaryDirectory() as td95:
            v95 = Path(td95) / "VIA_Reports" / "vrn2"
            (v95 / "market").mkdir(parents=True)
            (v95 / "market" / "VRN2_Market_latest.json").write_text("{}", encoding="utf-8")
            hr95 = {"lamp": "GREEN", "written": {"FinancialAligned": {"json": "a", "csv": "b", "rows": 3, "parquet": "(沒寫:ArrowInvalid)"}, "Deleted": {"parquet": "d.parquet"}}}
            (v95 / "VRN2_HistoryAlign_latest.json").write_text(json.dumps(hr95, ensure_ascii=False), encoding="utf-8")
            os.utime(v95 / "market" / "VRN2_Market_latest.json", (1, 1))
            plan95 = plan_fixes(Path(td95), {"market": {}, "consensus": {}, "history_align": {"lamp": "GREEN"}}, "", A93(), "")
            due95 = history_parquet_due(v95)
            hr95["written"]["FinancialAligned"]["parquet"] = "x.parquet"
            (v95 / "VRN2_HistoryAlign_latest.json").write_text(json.dumps(hr95, ensure_ascii=False), encoding="utf-8")
            p95b = [k for k, _ in plan_fixes(Path(td95), {"market": {}, "consensus": {}, "history_align": {"lamp": "GREEN"}}, "", A93(), "")]
        chk("95 v0128:⑤ 計畫 · 歷史對齊 FinancialAligned Parquet「(沒寫:ArrowInvalid)」→ history(HistoryAlign v0103 依欄位型別重寫 · 說明照收據寫原因)· 寫成了 → 不排",
            due95 == "FinancialAligned" and any(k == "history" and "v0103" in d and "FinancialAligned" in d and "ArrowInvalid(同欄混型)" in d for k, d in plan95) and "history" not in p95b)
        with tempfile.TemporaryDirectory() as td96:
            pk96, rt96 = Path(td96) / "pkg", Path(td96) / "VIA"
            pk96.mkdir()
            body96 = b"VERSION = 'v0103'\\n"
            with zipfile.ZipFile(pk96 / RUNTIME_ZIP, "w") as z96:
                z96.writestr("VRN2_HistoryAlign_v0103.py", body96)
                z96.writestr("VRN2_Workbench_v0107.py", b"x")
            (pk96 / RUNTIME_MANIFEST).write_text(json.dumps({"files": [{"path": "VRN2_HistoryAlign_v0103.py", "sha256": hashlib.sha256(body96).hexdigest()},
                                                                       {"path": "VRN2_Workbench_v0107.py", "sha256": "0" * 64}]}), encoding="utf-8")
            put96, ref96 = install_chain(pk96, rt96, ("VRN2_HistoryAlign_v0103.py", "VRN2_Workbench_v0107.py", "VRN2_Nope_v0100.py"))
            again96 = install_chain(pk96, rt96, ("VRN2_HistoryAlign_v0103.py",))
            (rt96 / "functional modules" / "VRN2" / "VRN2_HistoryAlign_v0103.py").write_bytes(b"other line")
            diff96 = install_chain(pk96, rt96, ("VRN2_HistoryAlign_v0103.py",))
            none96 = install_chain(None, rt96, HISTORY_CHAIN)
        chk("96 v0128:新尾版只增不覆寫補放(雜湊對清單才放 · 已在同內容不重放 · 同名不同內容不覆寫 · 沒套件不動)· 自測清單換 HistoryAlign v0103 / ConsensusJoin v0107 / Workbench v0107",
            put96 == ["VRN2_HistoryAlign_v0103.py"] and len(ref96) == 2 and "雜湊不符" in ref96[0] and again96 == ([], []) and diff96[0] == [] and "不覆寫" in diff96[1][0]
            and none96 == ([], []) and ("VRN2_HistoryAlign_v0103.py", 300) in SELFTESTS and ("VRN2_ConsensusJoin_v0107.py", 900) in SELFTESTS and ("VRN2_Workbench_v0107.py", 600) in SELFTESTS
            and HISTORY_CHAIN[0] == "VRN2_HistoryAlign_v0103.py" and WORKBENCH_CHAIN == ("VRN2_Workbench_v0107.py",))
        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''')
out = W / "new"
out.mkdir(exist_ok=True)
(out / "VRN2_RoundAll_v0128.py").write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,30}VRN2_Runtime_v0160.{0,30}|.{0,30}Closeout_v0170.{0,30}", s[s.index('VERSION = "v0128"'):])]
print("RoundAll v0128 lines", s.count("\n"), "· stale refs:", len(left), left[:3])
