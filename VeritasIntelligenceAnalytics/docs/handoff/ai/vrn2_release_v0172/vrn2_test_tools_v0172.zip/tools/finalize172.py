"""v0172 收尾:驗證紀錄 · 交接 v0173(從 v0172 抄 · 只增)· 放進倉 vrn2_release_v0172 · Graphify v0101 · logs / 工具 zip。桌機值不進倉(只寫結論與筆數)。"""
import csv, json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v172"); rel = W / "release172"
G = Path("/home/user/vrn2_work/graphify101")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def last(p):
    return [l for l in lines(p) if l.strip()][-1]


R = json.loads((rel / "VRN2_Release_v0172.json").read_text(encoding="utf-8"))
H = R["handleall"]
ra = [l for l in lines(W / "rall128_selftest.log") if re.search(r"^\[FAIL\]|--selftest · ", l)]
assert ra and "98 項 · 不過 0" in ra[-1], ra[-1:]
lsum = [l for l in lines(W / "launcher172_selftest.log") if l.startswith("[PASS] v0172")]
assert lsum and not [l for l in lines(W / "launcher172_selftest.log") if l.startswith("[FAIL]")]
mods = {n: last(W / f) for n, f in (("HistoryAlign v0103(pyarrow)", "ha103_selftest.log"), ("ConsensusJoin v0107", "cj107_selftest.log"), ("Workbench v0107", "wb107_selftest.log"),
                                     ("ConsensusJoin v0106 回歸", "cj106_regress.log"), ("Workbench v0105 回歸", "wb105_regress.log"))}
assert all("全過" in v for v in mods.values()), mods
ps = json.loads((W / "pscheck172.log").read_text())
by = {x["f"]: x for x in ps}
pparse = "pwsh 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % (sorted(x["e"] for x in ps), by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"], by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"])
assert all(x["e"] == 0 for x in ps) and by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"] and by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"]
rc = [l for l in lines(W / "tiny172.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
assert "[RED] boot SHA-256 mismatch - not run" in (W / "tiny_tamper.log").read_text(encoding="utf-8")
states = {}
for n in ("auto1", "auto2"):
    d = json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))
    states[n] = {"state": d["state"], "per_owner": d["per_owner"]}
base171 = {n: json.loads(Path("/home/user/vrn2_work/v171/closeout_%s.json" % n).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
assert states["auto1"]["per_owner"].get("VRN-2") == base171["auto1"].get("VRN-2") and states["auto2"]["per_owner"].get("VRN-2") == base171["auto2"].get("VRN-2")
plan2 = next(l for l in lines(W / "tiny_auto2.log") if "⑤ 自動修計畫" in l)
assert "HistoryAlign v0103" in plan2
ha1 = json.loads((W / "ha_auto1.json").read_text(encoding="utf-8"))["written"]
ha2 = json.loads((W / "ha_auto2.json").read_text(encoding="utf-8"))["written"]
assert str(ha1["FinancialAligned"]["parquet"]).startswith("(沒寫") and not str(ha2["FinancialAligned"]["parquet"]).startswith("(沒寫") and ha2["FinancialAligned"].get("parquet_typed")
typed = ha2["FinancialAligned"]["parquet_typed"]
comb = json.loads((W / "out_auto2" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
cols = list(comb[0]); i = cols.index("UPSIDE_PCT(ADJ)")
assert cols[i + 1] == "UPSIDE_ADJ"
n_new = sum(1 for r in comb if str(r.get("UPSIDE_ADJ") or "")); n_old = sum(1 for r in comb if str(r.get("UPSIDE_PCT(ADJ)") or ""))
mism = sum(1 for r in comb if r.get("UPSIDE_ADJ") and r.get("UPSIDE_PCT(ADJ)") and abs(float(r["UPSIDE_ADJ"]) * 100 - float(r["UPSIDE_PCT(ADJ)"])) > 0.051)
assert n_new == n_old and mism == 0
notes = json.loads((W / "colnotes_auto2.json").read_text(encoding="utf-8"))
assert set(notes["columns"]) == {"UPSIDE_PCT(ADJ)", "UPSIDE_ADJ"}
wb = (W / "wb_auto2.html").read_text(encoding="utf-8")
marks = {m: wb.count(m) for m in ('id="wb107-css"', 'id="wb107"', 'id="wb107b"', 'id="wb107-js"', 'id="wb105"')}
assert marks == {'id="wb107-css"': 1, 'id="wb107"': 1, 'id="wb107b"': 1, 'id="wb107-js"': 1, 'id="wb105"': 0}, marks
lamps = {}
for name in ("Basic Info · 合併檢視", "上漲空間 新欄 × 舊欄", "歷史對齊 Parquet"):
    m = re.search(r'<span class="lamp (\w+)"></span><b>%s</b>' % re.escape(name), wb)
    lamps[name] = m.group(1) if m else None
store = "DuckDB book_combined 多 UPSIDE_ADJ 欄(31 列 · 新輪 17 列有值 · 舊列 NULL)"   # 沙盒查詢實錄(見 logs)
R["results"] = {"roundall_v0128_selftest": ra[-1:], "launcher_v0172_selftest": lsum, "module_selftests": mods, "pwsh_parse": pparse, "e2e_rc": rc, "closeout_states": states,
                "closeout_vrn2_items_same_as_v0171_baseline": True,
                "repair_plan": plan2.split("⑤ 自動修計畫:", 1)[-1][:400],
                "F1": "auto1 (sandbox venv: pyarrow cannot load) → receipt honestly '(沒寫:ImportError) · 型別版也沒寫成:ImportError' → auto2 repair with a pyarrow Python: the prior write hit ArrowInvalid (mixed column) → v0103 typed rewrite · FinancialAligned %d rows · num %d · str %d · mixed→str %s" % (typed["rows"], typed["num"], typed["str"], typed["mixed_as_str"]),
                "F2": "Combined UPSIDE_ADJ right after UPSIDE_PCT(ADJ) · filled %d = old %d · cross-check mismatches %d · column notes file written · %s" % (n_new, n_old, mism, store),
                "F3": "Workbench v0107 over v0102 (repo runtime) · marks %s · lamps %s · browser 1920/1366/390: card rows 17, nothing overflows outside the table container; the 390-px page scroll is the prior page header (unchanged when the v0107 blocks are removed)" % (json.dumps(marks), json.dumps(lamps, ensure_ascii=False)),
                "tamper": "tampered boot file → '[RED] boot SHA-256 mismatch - not run'",
                "not_run": "the desktop itself (one line · auto = repair, minutes) · the operator's own --confirm (H-fd2ea35f) · a real ArrowInvalid on the desktop's 11,905-row book (reproduced on sandbox data + unit fixture)"}
(rel / "VRN2_Release_v0172.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0172 驗證紀錄(2026-11-03 · VRN P0 三項:Parquet 型別 · UPSIDE_ADJ 小數欄 · Basic Info 合併檢視 · 套件 v0172 · RoundAll v0128 · Handle-All v0120)

操作員 2026-11-03:「新增小數欄,舊欄保留並標註,三項一起修 · 授權給你依照你建議最佳化完成」+ 睡前授權「自動解決完善三個獨立系統一切問題 · 完成既有範圍不可擴張」。

## 1. 三項修正(只增新版 · 前版一字不改)

| # | 桌機 15:18 真資料 | 本輪 | 沙盒實證 |
|---|---|---|---|
| F1 | FinancialAligned 11,905 列 JSON / CSV 在 · Parquet「(沒寫:ArrowInvalid)」| **HistoryAlign v0103**:前版照寫;只有沒寫成時依欄位型別重寫(數字欄空值 null · 真混型整欄轉字串 · 讀回比對才換上)| %s |
| F2 | `UPSIDE_PCT(ADJ)` 存百分數(46.0)· 增量庫已有舊列 → 不能改語意 | **ConsensusJoin v0107**:新增 `UPSIDE_ADJ`(純小數 9 位)緊接舊欄 · 舊欄保留 · `output/VRN2_Combined_columns_latest.json` 標註 | %s |
| F3 | Basic Info NAME 23/52 · ADJ_CLOSE 0/52(原文冊)vs Combined 51/52 | **Workbench v0107**:Basic Info · 合併檢視(原 / 合標來源 · 兩冊不改)· 上漲空間用小數欄 × 100 · 驗證燈 +3 · 自包含(跳過 v0105 / 桌機 accelfix v0106)· 第 3 行加速器標記 | %s |

## 2. ⑤ 自動修(收據 ≥ v0170 → repair · 幾分鐘 · 不用整輪)

RoundAll v0128 新觸發:歷史對齊 Parquet「(沒寫…」→ ⑬b(先只增不覆寫補放 HistoryAlign v0103 鏈)· Combined 沒有 UPSIDE_ADJ → 重組(ConsensusJoin v0107)·
頁不是 v0107 → 重渲染(補放 Workbench v0107)· 增量庫照舊跟著補寫(OutputStore v0102 的 ALTER TABLE 加欄 · 舊列 NULL)。
沙盒 auto2 的計畫實錄:`%s`

## 3. 測試

| 項目 | 結果 |
|---|---|
| RoundAll v0128 自測 | %s |
| 啟動器 v0172 自測 | 全過 · %s |
| 模組自測 | %s |
| PowerShell 剖析 | %s |
| e2e(最短一行 · 沙盒)| %s · auto1 整輪(啟動器 v0172)→ 模擬桌機 v0170 狀態 → auto2 repair → 竄改開機檔不執行 |
| 收尾狀態 | %s · VRN-2 項與 v0171 基準相同(沙盒限定:沒有真 OCR 環境的驗收紅 · 已記錄在前版驗證)· 綠 32 → 36 |

## 4. 沒做 / 待辦(不擴張)

- 桌機實跑(一行 · auto = repair · 幾分鐘)· 操作員 `--confirm H-fd2ea35f`(只有操作員打才算)· 同意閘不代設。
- 桌機真的 11,905 列 ArrowInvalid 在沙盒以同形狀資料重現(單元 + 沙盒 auto2);桌機那本要等 repair 跑過才看到 `parquet_typed`。
- 下一階段(VRN P1 · 已列在 VIA_Ultimate_Requirements_v0100.md):F4 拖曳 / 刪除勾選接後端 · F5 匯出 Parquet 檔 · 內建預覽 · checkpoint · 壓測。
""" % (R["results"]["F1"], R["results"]["F2"], R["results"]["F3"], R["results"]["repair_plan"][:300], ra[-1][:120], lsum[0][:120],
       " · ".join("%s %s" % (k, v.split("自測", 1)[-1].strip()) for k, v in mods.items()), pparse, " · ".join(rc), json.dumps(states, ensure_ascii=False))
(rel / "VRN2_Verification_v0172.md").write_text(md, encoding="utf-8", newline="\n")

# ── 交接 v0173(從 v0172 抄 · 只增)──
src = (REPO / "VRN2_Handover_v0172.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0170 + VRN2_RoundAll_v0127 + VRN2_HandleAll_v0119 · 2026-11-02(")
L[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0172 + VRN2_RoundAll_v0128 + VRN2_HandleAll_v0120 · 2026-11-03(VRN P0 三項:Parquet 型別 · UPSIDE_ADJ 小數欄(舊欄保留標註)· Basic Info 合併檢視)"
src = "\n".join(L)
once("> **本輪(v0171)**",
     "> **本輪(v0172)**:操作員 11/03「新增小數欄,舊欄保留並標註,三項一起修 · 授權依建議最佳化完成」→ 另一工作階段的 F1 / F2 / F3 先用 15:18 真資料核實屬實,再修:"
     "**HistoryAlign v0103**(Parquet 沒寫成才依欄位型別重寫 · JSON / CSV 不動)· **ConsensusJoin v0107**(`UPSIDE_ADJ` 純小數緊接舊欄 `UPSIDE_PCT(ADJ)` · 舊欄百分數保留 · "
     "`output/VRN2_Combined_columns_latest.json` 標註)· **Workbench v0107**(Basic Info · 合併檢視 · 原 / 合標來源 · 兩冊不改 · 自包含跳過 v0105 / accelfix v0106 · 第 3 行加速器標記)· "
     "**RoundAll v0128**(⑤ 三個新觸發 · 只增不覆寫補放新尾版 · 自測 98)· **Handle-All v0120**(收據 ≥ v0170 照舊 repair · 幾分鐘)· 套件 v0172(啟動器 v0172 · runtime v0162)。"
     "另:PR #586 已併 main(含 v0171)· 本分支 = main + 之後的提交(force-push 不允許 → 用合併 main 的方式,不改寫歷史)· Graphify v0101(根目錄驗證)· "
     "`VIA_Ultimate_Requirements_v0100.md`(操作員最嚴格要求逐條編號 + 現況差距矩陣 · 不擴張範圍)。\n"
     "> **本輪(v0171)**")
rows = ("| **VRN2_HandleAll_v0120.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0120** | `vrn2_release_v0172` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0128 · 收據 ≥ v0170 → repair)|\n"
        "| **VRN2_RoundAll_v0128.py**(發行夾 · 一支入口 · 不在套件內)| **v0128** | `vrn2_release_v0172` | `%s` | **新**(套件 v0172 · ⑤ 新觸發:Parquet 沒寫 / Combined 沒有 UPSIDE_ADJ / 頁不是 v0107 · 自測 98)|\n"
        "| ActivateVRN-2_v0172.py(套件 · 底座 v0136 · runtime v0162 · 版號跳過 v0171)| **v0172** | 見發行清單 | `%s` | **新**(HistoryAlign v0103 · ConsensusJoin v0107 · Workbench v0107)|\n"
        "| VRN2_Runtime_v0162.zip(套件 · runtime)| **v0162** | 套件內 | `%s` | **新**(v0160 的 200 個成員不動 + 3 個新尾版)|\n"
        "| VRN2_HistoryAlign_v0103.py(runtime · 薄尾 v0102)| **v0103** | runtime v0162 | 見 runtime 清單 | **新**(F1 Parquet 依欄位型別重寫 · 讀回比對 · 收據 parquet_typed)|\n"
        "| VRN2_ConsensusJoin_v0107.py(runtime · 薄尾 v0106)| **v0107** | runtime v0162 | 見 runtime 清單 | **新**(F2 UPSIDE_ADJ 小數欄 · 舊欄保留 · 欄位標註檔 · 不覆寫已有值)|\n"
        "| VRN2_Workbench_v0107.py(runtime · 自包含後處理尾 · 跳過 v0105 系)| **v0107** | runtime v0162 | 見 runtime 清單 | **新**(F3 Basic Info 合併檢視 · 驗證燈 +3 · 欄位標註 · 加速器標記)|\n") % (
    H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12],
    next(c["sha256"] for c in R["components"] if c["path"] == "ActivateVRN-2_v0172.py")[:12], R["runtime"]["zip_sha256"][:12])
once("| **VRN2_HandleAll_v0119.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0119** | `vrn2_release_v0171` |",
     rows + "| **VRN2_HandleAll_v0119.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0119** | `vrn2_release_v0171` |")
once("| 0 | **(v0171)**",
     "| 0 | **(v0172)** 貼 `vrn2_release_v0172/VRN2_HandleAll_v0120.md` 的最短一行(auto = repair · 幾分鐘)→ ⑤ 會:⑬b Parquet 型別重寫 · Combined 補 UPSIDE_ADJ · 增量庫加欄 · Workbench v0107 → "
     "收尾應維持 REVIEW(VRN-2 0 · VCGC 0)· Workbench 資料頁最上面看「Basic Info · 合併檢視」· MQ-1560 看過原圖後操作員自己打 "
     "`python \"%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0128.py\" --confirm H-fd2ea35f --note \"…\"` → DATA_GAP = VRN-2 側終點 | 貼回 / 人工 |\n"
     "| 0 | **(v0171)**")
once("**v0171(2026-11-02)**:", "**v0172(2026-11-03)**:VRN P0 三項(HistoryAlign v0103 Parquet 型別 · ConsensusJoin v0107 UPSIDE_ADJ 小數欄 · Workbench v0107 Basic Info 合併檢視)· RoundAll v0128 · Handle-All v0120 · 套件 v0172 · Graphify v0101 · 最嚴格要求規格。\n\n**v0171(2026-11-02)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0172)** **上漲空間兩欄**:`UPSIDE_ADJ` = 純小數(0.46 = 46%% · 資料庫標準 · U/I 才乘 100);`UPSIDE_PCT(ADJ)` = 舊欄百分數(保留 · 不改語意 · 不要拿來算)。"
     "兩欄同列互核(新 × 100 與舊差 ≤ 0.05)在 Workbench 驗證燈;不一致 = 紅。增量庫舊列的 UPSIDE_ADJ 是 NULL(新增欄 · 不回填)。\n"
     "- **(v0172)** **Workbench 前版規則**:v0107 起找前版時**跳過含 `wb105-css` 的檔**(v0105 與桌機 accelfix 的 v0106 複本),v0105 的後處理本版自己做;下一版若要疊在 v0107 上,"
     "照同樣做法跳過含 `wb107-css` 的檔或直接指名前版,不要讓同一段後處理做兩次。新尾版一律第 3 行 `# [VIA:ACCEL-BRIDGE:v0111]`。\n"
     "- **(v0172)** **版號(兩線都查過)**:本線下一版 RoundAll v0129+ · Handle-All v0121+ · Workbench v0108+ · HistoryAlign v0104+ · ConsensusJoin v0108+ · runtime v0163+ · 啟動器 / 套件 / 收據 v0173+。"
     "PR #586 已併 main(含 v0171);本分支 = main + 之後提交(force-push 不允許 → 用合併 main 的方式重新對齊,不改寫歷史)。\n"
     "- **(v0172)** **操作員最嚴格要求**在 `VIA_Ultimate_Requirements_v0100.md`(UP-0 ~ UP-20 · 狀態圖 · KPI)· 未做的只列待辦與負責系統,不在收尾輪擴張範圍。\n\n")
(REPO / "VRN2_Handover_v0173.md").write_text(src, encoding="utf-8", newline="\n")

D = REPO / "vrn2_release_v0172"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0172.zip", "VRN2_RoundAll_v0128.py", "VRN2_RoundAll_v0128.md", "VRN2_HandleAll_v0120.md", "VRN2_HandleAll_v0120_boot.txt", "VRN2_Release_v0172.json", "VRN2_Verification_v0172.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t172a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0172.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall128_selftest.log", "launcher172_selftest.log", "ha103_selftest.log", "cj107_selftest.log", "wb107_selftest.log", "cj106_regress.log", "wb105_regress.log",
                              "pscheck172.log", "tiny172.rc", "seed172.log", "sim170.log", "confirm_list.log")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0172.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall128.py", "mk_launcher172.py", "runtime162.py", "build172.py", "finalize172.py", "e2e172.sh", "shot172.js", "shot172b.js")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())

GD = REPO / "via_graphify_v0101"
GD.mkdir(exist_ok=True)
for n in ("VIA_Graphify_v0101.md", "VIA_Graphify_v0101_boot.txt", "VIA_Graphify_Release_v0101.json"):
    shutil.copy(G / "release" / n, GD / n)
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0173", src.count("\n"), "· graphify", sorted(x.name for x in GD.iterdir()))
