"""ActivateVRN-2_v0172.py = v0170 + HistoryAlign v0103(F1 Parquet 依欄位型別)+ ConsensusJoin v0107(F2 UPSIDE_ADJ 小數欄 · 舊欄保留標註)+ Workbench v0107(F3 Basic Info 合併檢視)。
runtime v0162 = runtime v0160(200 個成員一字不改)+ 這三個新尾版。啟動器版號跳過 v0171(v0171 是只換 RoundAll 的發行夾,沒有 v0171 啟動器)。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v170/pkg170/ActivateVRN-2_v0170.py")
OUT = Path("/home/user/vrn2_work/v172/pkg172/ActivateVRN-2_v0172.py")
OUT.parent.mkdir(parents=True, exist_ok=True)
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0170: v0168 entry + Workbench v0105 + ConsensusJoin v0106', '''"""VRN-2 v0172: v0170 entry + HistoryAlign v0103 + ConsensusJoin v0107 + Workbench v0107 (operator 2026-11-03: "新增小數欄,舊欄保留並標註,三項一起修 · 授權依建議最佳化完成";
 the three VRN P0 findings F1 / F2 / F3 were confirmed on the desktop 15:18 receipts).
 - F1 VRN2_HistoryAlign_v0103 (thin tail over v0102 · v0102 ~ v0100 unchanged): v0100's _write_books turns None into "" so a numeric column also holds strings
   and pyarrow refuses the whole FinancialAligned Parquet (ArrowInvalid · JSON / CSV were fine, 11,905 rows). v0103 lets the prior write first and only when the
   Parquet is "(沒寫…" rewrites it typed: all-number columns → float64 with null for empty (never 0 / ""), all-string → string, truly mixed → whole column as string;
   it reads the file back (row count · column names) before replacing, otherwise it reports not-written honestly. The receipt gains written[...].parquet_typed.
 - F2 VRN2_ConsensusJoin_v0107 (thin tail over v0106): Combined gains UPSIDE_ADJ (pure ratio · TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1 · 9 decimals) right after the
   old UPSIDE_PCT(ADJ) (percent · kept, meaning unchanged, annotated as the old column); output/VRN2_Combined_columns_latest.json documents unit / definition /
   old-or-new for both. Values come from the market book's upside_adj; a filled cell is never overwritten. The store adds the column via ALTER TABLE (old rows NULL).
 - F3 VRN2_Workbench_v0107 (self-contained post-processing tail · skips v0105 and the desktop accelfix copy v0106 so nothing is applied twice · carries the
   accelerator marker on line 3): "Basic Info · 合併檢視" puts the verbatim Basic Info book (NAME 23/52 · ADJ_CLOSE 0/52 on the desktop, by design) next to the
   merged Combined book (51/52) per report — verbatim values tagged 原, Combined fills tagged 合 with the source on hover; neither book is modified. Upside is
   shown from UPSIDE_ADJ × 100; three more verification lamps (Basic merge · new-vs-old upside cross-check · history-align Parquet); column notes on hover.
 Runtime v0162 = runtime v0160 (200 members byte-identical) + VRN2_HistoryAlign_v0103 + VRN2_ConsensusJoin_v0107 + VRN2_Workbench_v0107.
 Receipt VRN2_Closeout_v0172.json. Launcher number v0171 is skipped (release folder v0171 only replaced RoundAll; there is no launcher v0171).

VRN-2 v0170: v0168 entry + Workbench v0105 + ConsensusJoin v0106''')
rep('VERSION = "ActivateVRN-2 v0170"', 'VERSION = "ActivateVRN-2 v0172"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0160.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0162.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0160.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0162.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0170.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0172.json"')
rep('WORKBENCH = "VRN2_Workbench_v0105.py"   # v0170:', 'WORKBENCH = "VRN2_Workbench_v0107.py"   # v0172: self-contained tail (skips v0105 / accelfix v0106) · Basic Info merged view · UPSIDE_ADJ shown as % · v0170:')
rep('HISTORY_ALIGN = "VRN2_HistoryAlign_v0102.py"   # v0148:', 'HISTORY_ALIGN = "VRN2_HistoryAlign_v0103.py"   # v0172: typed Parquet rewrite when the prior could not write it (ArrowInvalid) · v0148:')
rep('CONSENSUS_JOIN_ACTIVE = "VRN2_ConsensusJoin_v0106.py"   # v0170:', 'CONSENSUS_JOIN_ACTIVE = "VRN2_ConsensusJoin_v0107.py"   # v0172: UPSIDE_ADJ ratio column after the kept percent column UPSIDE_PCT(ADJ) · column notes · v0170:')
# 鏈:v0103 載 v0102 · v0107 載 v0106(自測夾要一起放)
rep('HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py"', 'HISTORY_ALIGN, "VRN2_HistoryAlign_v0102.py", "VRN2_HistoryAlign_v0101.py"', 2)
rep('CONSENSUS_JOIN_ACTIVE, "VRN2_ConsensusJoin_v0105.py"', 'CONSENSUS_JOIN_ACTIVE, "VRN2_ConsensusJoin_v0106.py", "VRN2_ConsensusJoin_v0105.py"', 2)
rep('''        assert ha.VERSION == "v0102" and ha.std_of("Other Revenue") == ""''',
    '''        assert ha.VERSION == "v0103" and ha.PRIOR.VERSION == "v0102" and ha.BASE._write_books is ha._write_books and ha.std_of("Other Revenue") == ""''')
rep('''    assert WORKBENCH == "VRN2_Workbench_v0105.py"''',
    '''    wb107 = selftest_source("VRN2_Workbench_v0107.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0107"' in wb107 and wb107.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]" and '_SKIP_MARK = "wb105-css"' in wb107
    assert "def basic_merged(" in wb107 and "def upside_check(" in wb107 and "def parquet_check(" in wb107 and 'id="wb107b"' in wb107 and "Basic Info · 合併檢視" in wb107
    assert WORKBENCH == "VRN2_Workbench_v0107.py"''')
rep('''    assert CONSENSUS_JOIN_ACTIVE == "VRN2_ConsensusJoin_v0106.py"''',
    '''    cj107 = selftest_source("VRN2_ConsensusJoin_v0107.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0107"' in cj107 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0106.py"' in cj107 and 'NEW_COL = "UPSIDE_ADJ"' in cj107 and 'OLD_COL = "UPSIDE_PCT(ADJ)"' in cj107
    assert CONSENSUS_JOIN_ACTIVE == "VRN2_ConsensusJoin_v0107.py"
    ha103 = selftest_source("VRN2_HistoryAlign_v0103.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0103"' in ha103 and 'PRIOR_NAME = "VRN2_HistoryAlign_v0102.py"' in ha103 and "def write_typed_parquet(" in ha103 and "BASE._write_books = _write_books" in ha103
    assert HISTORY_ALIGN == "VRN2_HistoryAlign_v0103.py"''')
rep('''        assert cj.VERSION == "v0106" and cj.PRIOR.VERSION == "v0105" and cj.PRIOR.PRIOR.VERSION == "v0104"
        assert cj.V0100.join is cj.join and cj.PRIOR.join is cj.join and cj.V0100.run is cj.run and cj.PRIOR.run is cj.run   # v0170: v0106 rewires run (snapshot backfill) and join (ASOF note)''',
    '''        assert cj.VERSION == "v0107" and cj.PRIOR.VERSION == "v0106" and cj.PRIOR.PRIOR.VERSION == "v0105" and cj.PRIOR.PRIOR.PRIOR.VERSION == "v0104"
        assert cj.V0100.join is cj.join and cj.PRIOR.join is cj.join and cj.V0100.run is cj.run and cj.PRIOR.run is cj.run   # v0170: v0106 rewires run (snapshot backfill) and join (ASOF note)
        assert cj.V0100._write is cj._write and cj.V0100.columns is cj.columns                                                # v0172: v0107 rewires the Combined writer / column list
        cols172 = cj.columns(2026)
        assert cols172[cols172.index("UPSIDE_PCT(ADJ)") + 1] == "UPSIDE_ADJ" and cols172.count("UPSIDE_ADJ") == 1 and cj.ratio_text(0.4) == "0.400000000" and cj.ratio_text(None) == ""''')
rep('''    print("[PASS] v0170: Workbench v0105''', '''    print("[PASS] v0172: HistoryAlign v0103 (typed Parquet rewrite · JSON / CSV unchanged) · ConsensusJoin v0107 (UPSIDE_ADJ ratio column after the kept percent column · column notes) · Workbench v0107 (Basic Info merged view · self-contained · accelerator marker) are active")
    print("[PASS] v0170: Workbench v0105''')
rep('return lamp, detail + " · launcher v0170"', 'return lamp, detail + " · launcher v0172"')
rep('note="VRN-2 private runtime; exact ship v0160 (launcher v0170 · Workbench v0105 · ConsensusJoin v0106 snapshot backfill · no MOPS);',
    'note="VRN-2 private runtime; exact ship v0162 (launcher v0172 · HistoryAlign v0103 typed Parquet · ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107 Basic merged view · no MOPS);')
rep('print("NEXT: [%s] VRN-2 v0170 · rc %s', 'print("NEXT: [%s] VRN-2 v0172 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0172", len(s.splitlines()), "lines")
