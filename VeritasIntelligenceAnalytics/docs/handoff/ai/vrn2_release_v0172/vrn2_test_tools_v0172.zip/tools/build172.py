"""v0172(冪等):套件 VRN2_Closeout_v0172.zip(啟動器 v0172 · runtime v0162 = v0160 + HistoryAlign v0103 + ConsensusJoin v0107 + Workbench v0107)→ RoundAll v0128(填套件雜湊)
→ Handle-All v0120(指到 v0128 · 收據 ≥ v0170 照舊 repair:三項修正幾分鐘補上)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0172)。vrn2_release_v0171 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v172"); pkg, rel = W / "pkg172", W / "release172"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v171/release171")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0170/VRN2_Release_v0170.json").read_text(encoding="utf-8"))
r171 = json.loads((REPO / "vrn2_release_v0171/VRN2_Release_v0171.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0162.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0162.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0160.zip " + r170["runtime"]["zip_sha256"]
assert rt["retained_members"] == 200 and rt["new_members"] == ["VRN2_HistoryAlign_v0103.py", "VRN2_ConsensusJoin_v0107.py", "VRN2_Workbench_v0107.py"]
old = {c["path"]: c["sha256"] for c in r170["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0172.py", "VRN2_Runtime_v0162.zip", "VRN2_Runtime_v0162.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0172.py", "VRN2_Runtime_v0162.zip", "VRN2_Runtime_v0162.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0170 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0172 — VRN-2 closeout package (2026-11-03 · VRN P0 F1 / F2 / F3: typed Parquet · UPSIDE_ADJ ratio column · Basic Info merged view)\n\n"
  "Entry: python ActivateVRN-2_v0172.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0128.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0120.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0162.zip = v0160 (200 members byte-identical) + VRN2_HistoryAlign_v0103 + VRN2_ConsensusJoin_v0107 + VRN2_Workbench_v0107.\n\n"
  "v0172 (operator 2026-11-03: \"新增小數欄,舊欄保留並標註,三項一起修\"):\n"
  " - F1 VRN2_HistoryAlign_v0103 — when the prior cannot write FinancialAligned / Deleted Parquet (ArrowInvalid: None turned into \"\" in a numeric column),\n"
  "   rewrite it typed (numbers float64 with null · strings · truly mixed columns as text) and read it back before replacing. JSON / CSV unchanged.\n"
  " - F2 VRN2_ConsensusJoin_v0107 — Combined gains UPSIDE_ADJ (pure ratio = TARGET_PRICE(ADJ) / ADJ_CLOSE - 1, 9 decimals) right after the kept\n"
  "   percent column UPSIDE_PCT(ADJ); output/VRN2_Combined_columns_latest.json annotates unit / definition / old-or-new. Filled cells never overwritten.\n"
  " - F3 VRN2_Workbench_v0107 — Basic Info merged view (verbatim book tagged 原 · Combined fills tagged 合 with source · neither book changed) ·\n"
  "   upside shown from UPSIDE_ADJ x 100 · 3 more verification lamps · column notes · self-contained (skips v0105 / accelfix v0106) · accel marker.\n"
  "v0170: Workbench v0105 + ConsensusJoin v0106 snapshot backfill. v0168: manager v0259. v0163: no MOPS.\n"
  "Launcher number v0171 is skipped (release folder v0171 only replaced RoundAll; there is no launcher v0171).\n"
  "Verification: see VRN2_Verification_v0172.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0172.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0172", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0172.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0172/" + n, date_time=(2026, 11, 3, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0128.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0172"' in ra and 'VERSION = "v0128"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172"' in ra
(rel / "VRN2_RoundAll_v0128.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0171'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172'")
rep("$F = 'VRN2_RoundAll_v0127.py'", "$F = 'VRN2_RoundAll_v0128.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0119", "Handle-All v0120", ha.count("Handle-All v0119"))
rep("套件 v0170 裝在新夾 VRN2_Closeout_v0170", "套件 v0172 裝在新夾 VRN2_Closeout_v0172")
rep("(上一輪輸出冊是啟動器 v0170 以前做的 → 整輪:Workbench v0105 U/I + 共識欄快照補位要在新啟動器輪跑)", "(上一輪輸出冊是啟動器 v0170 以前做的 → 整輪:新啟動器 v0172 重做)")
rep("(輸出冊是啟動器 v0170 做的 → 不整輪)", "(輸出冊是啟動器 v0170 以後做的 → 不整輪:VRN P0 三項由 ⑤ 自動修幾分鐘補上)")
rep("取套件 v0170 → 診斷 → 全部自測 → 跑啟動器 v0170(", "取套件 v0172 → 診斷 → 全部自測 → 跑啟動器 v0172(")
rep("Workbench v0105(緊湊 / 白字 / 欄寬自動 / 資料驗證燈 / 共識面板) · ⑥f ConsensusJoin v0106(閘未開 DENY → 碟上快照補位 ASOF 標示 · v0105 同步還原 · TWSE / TPEX 格式合併)",
    "Workbench v0107(v0105 全部 + Basic Info 合併檢視 · 上漲空間小數欄 · 欄位標註) · ⑬b HistoryAlign v0103(Parquet 依欄位型別寫) · ⑥f ConsensusJoin v0107(UPSIDE_ADJ 小數欄 · 舊欄 UPSIDE_PCT(ADJ) 保留標註 · v0106 閘未開快照補位 · v0105 同步還原 · TWSE / TPEX 格式合併)")
rep("repair = '取套件 v0170 → ⑤ 自動修(", "repair = '取套件 v0172 → ⑤ 自動修(VRN P0 三項:⑬b HistoryAlign v0103 重寫沒寫成的 Parquet · Combined 加 UPSIDE_ADJ 小數欄(ConsensusJoin v0107 · 舊欄保留)· Workbench v0107 Basic Info 合併檢視;")
rep("只重跑 ⑪ 獨立驗證(套件 v0170 的", "只重跑 ⑪ 獨立驗證(套件 v0172 的")
left = [l for l in ha.split("\n") if re.search(r"Handle-All v0119|v0127\.py|release_v0171|套件 v0170|Closeout_v0170", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha                  # 收據 ≥ v0170 照舊 repair(三項不用整輪)
assert re.search(r"\$col = @\{[^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0171", "vrn2_release_v0172"), ("VRN2_HandleAll_v0119.md", "VRN2_HandleAll_v0120.md"), ("Handle-All v0119 SHA-256 OK", "Handle-All v0120 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0120_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172/VRN2_HandleAll_v0120_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0120(2026-11-03 · VRN P0 三項:Parquet 型別 · UPSIDE_ADJ 小數欄 · Basic Info 合併檢視 · 套件 v0172 · RoundAll v0128)

操作員 2026-11-03:「新增小數欄,舊欄保留並標註,三項一起修 · 授權依建議最佳化完成」。另一工作階段的 F1 / F2 / F3 先用桌機 15:18 真資料核實屬實,再修:

| # | 問題(桌機 15:18 真資料) | 修法(只增新版 · 前版一字不改) |
|---|---|---|
| F1 | FinancialAligned 11,905 列 · JSON / CSV 都在,**Parquet「(沒寫:ArrowInvalid)」**(同欄數字與空字串混型) | **HistoryAlign v0103**:前版照寫;Parquet 沒寫成才依欄位型別重寫(數字欄空值 = null · 真混型欄轉字串 · 讀回比對才換上)|
| F2 | Combined `UPSIDE_PCT(ADJ)` 存百分數(46.0),不是小數(0.46);增量庫已累積舊列 → 不能直接改語意 | **ConsensusJoin v0107**:新增 `UPSIDE_ADJ`(純小數 9 位)緊接舊欄;**舊欄保留不改**並在 `output/VRN2_Combined_columns_latest.json` 標註單位 / 定義 / 新舊;增量庫加欄(舊列 NULL)|
| F3 | Basic Info `NAME` 23/52、`ADJ_CLOSE` 0/52(原文冊照抄 · 原文本來沒寫),Combined 51/52 | **Workbench v0107**:「Basic Info · 合併檢視」逐份把兩冊對起來 · 原文值標「原」· Combined 補上的標「合」(滑過看來源)· **兩冊內容不改** · 上漲空間用小數欄 × 100 顯示 |

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0172/VRN2_Closeout_v0172.zip`(SHA-256 `%s` · 啟動器 v0172 · runtime v0162 = v0160 + 3 個新尾版 · 跳過 v0171 啟動器號)|
| 一支 Python | `VRN2_RoundAll_v0128.py`(SHA-256 `%s` · 自測 98 項 · ⑤ 新觸發:Parquet 沒寫 → ⑬b · Combined 沒有 UPSIDE_ADJ → 重組 · 頁不是 v0107 → 重渲染)|
| 自動選模式 | 收據已是 v0170 → **repair(幾分鐘)**:三項都在 ⑤ 自動修補上,不用整輪 |

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0120 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0128 `%s`)。

要最新共識才需要先貼(同意閘 · 操作員決定 · VRN-2 不代設;不貼也照修三項):`$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'`

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0128.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0128.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0120.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0128.py(套件 v0172 · VRN P0 三項)

`VRN2_RoundAll_v0128.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0127 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0172/VRN2_Closeout_v0172.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0172 · runtime v0162 = v0160 + HistoryAlign v0103 + ConsensusJoin v0107 + Workbench v0107 |
| ⑤ 自動修 | history ← 歷史對齊收據的 Parquet「(沒寫…」(先只增不覆寫補放 HistoryAlign v0103 鏈)· combined ← Combined 沒有 UPSIDE_ADJ(補放 ConsensusJoin v0107)· workbench ← 頁不是 v0107(補放 Workbench v0107)· 增量庫照舊跟著補寫 |
| ⑥ 除錯 | Combined 欄序以 v0107 為準(UPSIDE_ADJ 緊接 UPSIDE_PCT(ADJ))· Workbench 標記多「Basic Info 合併檢視」|
| ③ 自測清單 | HistoryAlign v0103 · ConsensusJoin v0107 · Workbench v0107(前版照舊由鏈自測)|
| 自測 | 98 項(v0127 的 94 項 + 93 欄序 · 94 小數欄計畫 · 95 Parquet 計畫 · 96 只增不覆寫補放)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0128.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0172 (launcher v0172 · runtime v0162) + VRN2_RoundAll_v0128 + VRN2_HandleAll_v0120", "date": "2026-11-03",
        "trigger": "操作員 2026-11-03:「新增小數欄,舊欄保留並標註,三項一起修 · 授權給你依照你建議最佳化完成」+ 睡前授權「自動解決完善三個獨立系統一切問題 · 完成既有範圍不可擴張」",
        "findings": {"F1": "HistoryAlign FinancialAligned Parquet not written (ArrowInvalid: v0100 _write_books turns None into \"\" → mixed column) · desktop 15:18: 11,905 rows in JSON / CSV",
                     "F2": "Combined UPSIDE_PCT(ADJ) holds percent (46.0) not ratio (0.46) · the store already holds old rows → meaning cannot change in place",
                     "F3": "Basic Info NAME 23/52 · ADJ_CLOSE 0/52 (verbatim book) vs Combined 51/52 (merged book)"},
        "consent_gate": "unchanged and operator-only: nothing in this release sets VIA_NET_CONSENT / VIA_SCRAPE_CONSENT",
        "fixes": {"HistoryAlign_v0103": "prior writes first; only a not-written Parquet is rewritten typed (float64 with null / string / mixed as string) with a read-back check · receipt written[...].parquet_typed",
                  "ConsensusJoin_v0107": "UPSIDE_ADJ ratio column (9 decimals) inserted right after the kept percent column UPSIDE_PCT(ADJ) · filled from market per_file.upside_adj · never overwrites · output/VRN2_Combined_columns_latest.json column notes",
                  "Workbench_v0107": "self-contained post-processing tail (prior = highest version below it without wb105-css → skips v0105 and the desktop accelfix v0106 copy) · all v0105 features · Basic Info merged view (原 / 合 tags, source on hover, books unchanged) · upside from UPSIDE_ADJ × 100 · 3 more lamps · column notes · accelerator marker on line 3",
                  "RoundAll_v0128": "package v0172 pin · plan triggers (Parquet not written → history · Combined without UPSIDE_ADJ → combined · page not v0107 → workbench) with add-only installs of the new tails · Combined column order per v0107 · selftest 98",
                  "HandleAll_v0120": "points at RoundAll v0128 / release v0172 · receipts ≥ v0170 still pick repair (the three fixes land in minutes, no full round)"},
        "package": {"name": "VRN2_Closeout_v0172.zip", "sha256": want, "release_folder": "vrn2_release_v0172", "changed": True,
                    "launcher": "ActivateVRN-2_v0172.py", "launcher_numbering": "v0171 skipped (release v0171 was RoundAll-only)"},
        "runtime": {"name": "VRN2_Runtime_v0162.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 200, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0127.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0171"}],
        "roundall": {"name": "VRN2_RoundAll_v0128.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0128.md"},
        "handleall": {"name": "VRN2_HandleAll_v0120.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0120_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "every new number checked free on BOTH this branch and origin/main before minting (RoundAll v0128 · HandleAll v0120 · Workbench v0107 · HistoryAlign v0103 · ConsensusJoin v0107 · runtime v0162 · launcher / package / receipt v0172)",
        "results": {"status": "see VRN2_Verification_v0172.md"}}
(rel / "VRN2_Release_v0172.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
