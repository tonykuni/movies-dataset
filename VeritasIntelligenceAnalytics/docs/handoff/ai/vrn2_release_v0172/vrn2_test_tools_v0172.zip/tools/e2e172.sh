#!/bin/bash
# v0172 e2e(RoundAll v0128 · Handle-All v0120 · 套件 v0172:HistoryAlign v0103 + ConsensusJoin v0107 + Workbench v0107):沙盒(桌機 v0153 狀態 + 髒增量庫)+ 三份原文(只在沙盒)
# + 合成共識快照 → auto1(收據 v0153 < v0170 → 整輪 · 啟動器 v0172 · venv 的 pyarrow 壞(numpy 1.26)→ Parquet 照實報沒寫)
# → 模擬桌機 v0170 狀態(Combined 拿掉 UPSIDE_ADJ · 沒有欄位標註 · 頁換回舊版)→ --confirm list → auto2(收據 ≥ v0170 → repair · 用有 pyarrow 的 Python)
# → ⑤ 自動修:⑬b Parquet 型別重寫 · Combined 補 UPSIDE_ADJ · 增量庫加欄 · Workbench v0107 → 竄改不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v172; W4=/home/user/vrn2_work/v164; T=$W/t172a; P=$S2/venv_vrn2/bin/python; PA=$S/pa_venv/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
REL=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
cp /home/user/vrn2_work/v165/pdfs/daiwa6278.pdf "$T/samples/Daiwa-6278 20260521.pdf"; cp /home/user/vrn2_work/v165/pdfs/ctbc3264.pdf "$T/samples/欣銓(3264,B_買進)-CTBC260918.pdf"; cp /home/user/vrn2_work/v168/pdfs/hn6143.pdf "$T/samples/華南投顧-6143-振曜-1141128.pdf"; for f in "$T/VIA/VIA_Reports/vrn2/VRN2_Input_latest.json" "$T/VIA/functional modules/VRN2/SSOT/"*.json; do sed -i "s|$S/v153/t153d/samples|$T/samples|g; s|$S/v151/t151/samples|$T/samples|g" "$f"; done
$P -I $W4/seed164.py $T $W4/rt > $W/seed172.log 2>&1; tail -2 $W/seed172.log
$P - "$T" <<'PYEOF' >> $W/seed172.log 2>&1
# 合成共識快照:沙盒 BasicInfo 前 6 檔代號 · 形狀同引擎矩陣 · 數字合成(不是任何原文 / 桌機值)· ASOF = 台北 2026-11-01
import csv, json, re, sys
from pathlib import Path
v2 = Path(sys.argv[1]) / "VIA" / "VIA_Reports" / "vrn2"
basic = json.loads((v2 / "output" / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
codes = []
for r in basic if isinstance(basic, list) else []:
    c = str(r.get("TICKER") or r.get("ticker") or "").strip()
    if re.fullmatch(r"[1-9]\d{3}", c) and c not in codes:
        codes.append(c)
codes = codes[:6]
head = ["code", "symbol", "company_name", "fetched_at_utc", "current_price", "target_median", "target_mean", "target_analyst_count", "target_rate_date",
        "yf_target_median", "yf_target_mean", "yf_target_analyst_count", "yf_current_price", "eps_2026_median", "eps_2026_forward_pe", "source_agreement_gate", "source_page", "source_yfinance"]
out = v2 / "consensus"
out.mkdir(parents=True, exist_ok=True)
with (out / "factset_yfinance_consensus_matrix.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(head)
    for i, c in enumerate(codes):
        base = 100.0 + 10 * i
        w.writerow([c, "TWS:%s:STOCK" % c, "合成快照%d" % i, "2026-11-01T01:19:00+00:00", base, round(base * 1.2, 2), round(base * 1.21, 2), 5 + i,
                    "2026-10-30", round(base * 1.1, 2), round(base * 1.12, 2), 7 + i, base, round(9.5 + i, 2), round(14.0 + i, 2), "PASS", "https://example.invalid/%s" % c, "yfinance"])
print("seed snapshot codes", codes)
PYEOF
B=$T.br; D1=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172; mkdir -p $D1
cp $W/release172/VRN2_Closeout_v0172.zip $W/release172/VRN2_RoundAll_v0128.py $W/release172/VRN2_RoundAll_v0128.md $W/release172/VRN2_HandleAll_v0120.md $W/release172/VRN2_HandleAll_v0120_boot.txt $W/release172/VRN2_Release_v0172.json $D1/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release172/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2)
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 6000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny172.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; cp -a $V2/output $W/out_$N 2>/dev/null; cp $V2/VRN2_Workbench_latest.html $W/wb_$N.html 2>/dev/null; cp $V2/consensus/VRN2_Consensus_latest.json $W/cons_$N.json 2>/dev/null; }
rm -rf "${W:?}/out_auto1" "${W:?}/out_auto2" "${W:?}/out_tamper"; rm -f $W/tiny172.rc
run auto1
RA=$T/home/Downloads/VRN2_RoundAll_v0128.py
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm list > $W/confirm_list.log 2>&1; echo "confirm list rc $?" >> $W/tiny172.rc
cp $V2/VRN2_HistoryAlign_latest.json $W/ha_auto1.json 2>/dev/null
$P - "$V2" <<'PYEOF' > $W/sim170.log 2>&1
# 模擬桌機 v0170 輪的狀態(ConsensusJoin v0106 組的 Combined 沒有 UPSIDE_ADJ · 沒有欄位標註 · Workbench 頁是舊版)· 只動沙盒
import csv, json, sys
from pathlib import Path
v2 = Path(sys.argv[1]); out = v2 / "output"
rows = json.loads((out / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
had = sum(1 for r in rows if "UPSIDE_ADJ" in r)
rows = [{k: v for k, v in r.items() if k != "UPSIDE_ADJ"} for r in rows]
(out / "VRN2_Combined_latest.json").write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
with (out / "VRN2_Combined_latest.csv").open("w", encoding="utf-8-sig", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
(out / "VRN2_Combined_columns_latest.json").unlink(missing_ok=True)
wb = v2 / "VRN2_Workbench_latest.html"
page = wb.read_text(encoding="utf-8")
wb.write_text(page.replace('id="wb107-css"', 'id="old-css"').replace('id="wb107b"', 'id="oldb"'), encoding="utf-8")
ha = json.loads((v2 / "VRN2_HistoryAlign_latest.json").read_text(encoding="utf-8"))
print("sim v0170: Combined rows", len(rows), "had UPSIDE_ADJ", had, "· history parquet", {k: str(v.get("parquet"))[:60] for k, v in (ha.get("written") or {}).items()})
PYEOF
cat $W/sim170.log
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$PA" VRN2_ROUNDALL_ARGS="--python $PA" VIA_ACCEL_LIGHT_SEC=2)
run auto2
cp $V2/VRN2_HistoryAlign_latest.json $W/ha_auto2.json 2>/dev/null; cp $V2/output/VRN2_Combined_columns_latest.json $W/colnotes_auto2.json 2>/dev/null; cp $V2/VRN2_OutputStore_latest.json $W/store_auto2.json 2>/dev/null
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172/VRN2_HandleAll_v0120_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny172.rc
echo E2E172_DONE
