const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  for (const [w, h, tag] of [[1920, 1080, 'wide'], [1366, 768, 'mid'], [390, 844, 'phone']]) {
    const p = await b.newPage({ viewport: { width: w, height: h } });
    await p.goto('file:///home/user/vrn2_work/v172/run1/wb_auto2.html');
    const r = await p.evaluate(() => {
      const card = document.getElementById('wb107b'), blk = document.getElementById('wb107');
      const tabs = [...document.querySelectorAll('[data-tab]')].filter(x => x.tagName !== 'SECTION').map(x => x.textContent.trim()).slice(0, 8);
      const over = el => el ? [...el.querySelectorAll('*')].filter(x => x.getBoundingClientRect().right > el.getBoundingClientRect().right + 2 && !x.closest('.matrix')).length : -1;
      return { card: !!card, blk: !!blk, cardRows: card ? card.querySelectorAll('tbody tr').length : 0, overflowOutsideMatrix: over(card), blkOverflow: over(blk),
               docScrollX: document.documentElement.scrollWidth > window.innerWidth + 2, tabs };
    });
    console.log(tag, JSON.stringify(r));
    await p.evaluate(() => { const t = document.querySelector('button[data-tab="data"], [data-tab="data"]:not(section)'); if (t) t.click(); });
    await p.waitForTimeout(300);
    const el = await p.$('#wb107b');
    if (el) await el.screenshot({ path: `/home/user/vrn2_work/v172/wb107b_${tag}.png` });
    const el2 = await p.$('#wb107');
    if (el2 && tag === 'wide') await el2.screenshot({ path: `/home/user/vrn2_work/v172/wb107_${tag}.png` });
    await p.close();
  }
  await b.close();
})();
