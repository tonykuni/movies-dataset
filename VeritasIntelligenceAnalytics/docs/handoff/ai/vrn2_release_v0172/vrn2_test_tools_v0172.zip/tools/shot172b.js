const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 390, height: 844 } });
  await p.goto('file:///home/user/vrn2_work/v172/run1/wb_auto2.html');
  const r = await p.evaluate(() => {
    const sw = () => document.documentElement.scrollWidth;
    const before = sw();
    const wide = [...document.querySelectorAll('body *')].filter(x => x.getBoundingClientRect().right > window.innerWidth + 2 && !x.closest('.matrix') && !x.closest('pre')).slice(0, 6).map(x => x.tagName + '#' + x.id + '.' + x.className + ' ' + Math.round(x.getBoundingClientRect().right) + ' in ' + (x.closest('[id]') || {}).id);
    ['wb107', 'wb107b'].forEach(i => { const e = document.getElementById(i); if (e) e.remove(); });
    return { before, after: sw(), vw: window.innerWidth, wide };
  });
  console.log(JSON.stringify(r, null, 1));
  await b.close();
})();
