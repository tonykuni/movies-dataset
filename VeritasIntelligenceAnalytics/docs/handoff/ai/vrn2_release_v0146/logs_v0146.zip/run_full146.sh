#!/bin/bash
# 整輪:套件 v0146 跑沙盒 19 份 · 共識引擎走離線 fixture(每個代號一份)· 輸出夾放一份舊 CSV 讓 ⑬c 偵測 · 市場擷取會因缺 yfinance 黃燈(容器沒網路)
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v146; T=$W/t146; L=ActivateVRN-2_v0146.py; N=full146
OCRPY=$S/v131/ocrenv/vrn2_ocr/bin/python; P=$S2/venv_vrn2/bin/python
rm -rf $T $T.setup.log; bash $S/v142/mktree142.sh $T $W/pkg146 "$S2/shipF/samples" > $W/t146_setup.log 2>&1 || { cat $W/t146_setup.log; exit 1; }
# 共識 fixture:代號取自 v0145 沙盒的基本資料冊(同 19 份樣本)
FX=$($P - <<'PY'
import json, importlib.util, sys, pathlib
S = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
sp = importlib.util.spec_from_file_location("cj", S / "v146/new/VRN2_ConsensusJoin_v0100.py"); m = importlib.util.module_from_spec(sp); sys.modules["cj"] = m; sp.loader.exec_module(m)
codes = m.codes_from_basic(S / "v145/t145/VIA/VIA_Reports/vrn2")
out = []
for i, c in enumerate(codes):
    p = m._fixture(S / "v146/fx" / ("fx%s.json" % c), c, "公司" + c, 100.0 + i, 120.0 + i, 118.0 + i, {2026: 5.0 + i, 2027: 6.0 + i, 2028: 7.0 + i})
    out.append(str(p))
print(";".join(out))
PY
)
echo "fixtures: $(echo "$FX" | tr ';' '\n' | wc -l)" >> $W/t146_setup.log
mkdir -p "$T/OneDrive/VRN2_out"; printf '\xef\xbb\xbfTicker,Date,Broker,Target Price,Rating\n2330,2025-10-01,CLSA,1200,BUY\n3008,2025-10-05,KGI,2500,HOLD\n' > "$T/OneDrive/VRN2_out/舊基本資料 - Sheet1.csv"
cd "$T/pkg" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VRN2_ROOT="$T/VIA" VIA_TOOLS_ROOT="$T/VIA" VIA_ENVS_HOME="$T/envs" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$T/pkg/VRN2_OCRBridge_v0101.py" PYTHONUTF8=1 PYTHONIOENCODING=utf-8 PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 \
  VIA_VRN2_NO_PUSH=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_OUTPUT_DIR="$T/OneDrive/VRN2_out" VRN2_CONSENSUS_FIXTURES="$FX" VRN2_CONSENSUS_YEAR=2026 VRN2_INTEGRATE_TEMP="$T/tmp" \
  timeout 7000 $P -X utf8 "$T/pkg/$L" --no-install --no-open --source "$T/samples" > "$W/$N.log" 2>&1
echo "$N rc $?" > "$W/$N.rc"
sed -i 's/\x1b\[[0-9;]*m//g' "$W/$N.log"
