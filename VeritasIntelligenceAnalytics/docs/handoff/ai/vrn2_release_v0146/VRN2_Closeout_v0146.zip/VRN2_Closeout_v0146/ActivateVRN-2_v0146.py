#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VRN-2 v0146: v0145 entry + market data (⑥e) · FactSet / YFinance consensus Combined book (⑥f) · history alignment (⑬b) · legacy-database integration scan (⑬c) · Workbench v0102 · handler v0109 · SSOT proposals.

Operator 2026-10-29 (10:25 paste-back of v0145 · 2546 s · CPU 87.5% busy by another process so the launcher ran 1 lane; ⑬ duckdb incremental GREEN) asked:
 - U/I: headers with spaces (now bilingual per the operator list), everything top-aligned, amounts shown in NT$ millions with thousands separators (per-share / multiples / % keep their value),
   tiles auto-fit instead of overflowing, an output-folder slot (long-term Parquet store) above the other-system Gates, the first right-panel block = input dedup matrix + engine status, logo 180% with 1.5% margin.
 - "Why can't it fetch TWSE / TPEX / YFinance any more?": the desktop line's own manager (v0249+) carries a ⑥e MarketFetch step; this package line (manager v0243 → v0255) never had one.
   v0146 adds ⑥e here: after the run it borrows the shared folder's latest VRN2_MarketFetch_v*.py (desktop-line tool · read-only · wraps VDF_TW_AllInOne) with --fetch then --fill → VIA_Reports/vrn2/market/VRN2_Market_latest.json.
 - ⑥f: the uploaded VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120 (bundled unchanged in runtime v0146) fetches FactSet (cnyes) + YFinance consensus; VRN2_ConsensusJoin builds output/VRN2_Combined_latest
   (per report: … TARGET_PRICE · TARGET_PRICE(ADJ) · FACTSET / YFINANCE target medians · <year>_DILUTED_EPS_FACTSET ×3 · <year>_PER_FACTSET ×3 with real years n..n+2 · CURRENT_PRICE_REPORT · UPSIDE_PCT(ADJ) · ADJ_CLOSE · … · TOPIC & SUMMARY · STATUS).
 - ⑬b VRN2_HistoryAlign: at least one period of each report must reconcile with MOPS / TWSE history (0.97–1.03 · unit scale auto) before history overrides estimates; add/sub and mul/div checks; contradicted report values go to the Deleted zone.
 - ⑬c VRN2_DataIntegrate scan: legacy CSV / XLSX / Google-Sheet exports near the output folder are detected and the Workbench asks the user; apply (vrn2://integrate · handler v0109) never deletes originals (copies to TEMP after a verified new Parquet).
 Non-critical steps: ⑥e / ⑥f / ⑬b / ⑬c never turn the closeout RED (GRAY when opted out or a tool is absent · YELLOW on env / partial). Opt-outs: VIA_VRN2_NO_MARKET=1 · VIA_VRN2_NO_CONSENSUS=1 · VIA_VRN2_NO_HISTORY=1 · VIA_VRN2_NO_INTEGRATE=1.
 Runtime v0146 = runtime v0145 (167 members byte-identical) + Workbench v0102 · UIAction v0109 · SSOTSync v0101 · HistoryAlign v0100 · DataIntegrate v0100 · ConsensusJoin v0100 · SSOT proposals v0100 · the consensus engine v0120.

v0145: v0144 entry + manager v0255 (parallel idempotence gate · heartbeat · phase timing).

Desktop run 2026-10-29 08:14 (v0144 · 52 reports · 2422 s): everything registered and the U/I was bound (⑥c · ⑤b · ⑫b · ⑬ GREEN),
but step ⑦ took 1201 s with ~1050 s of silence although extraction served 52/52 from cache: the v0243 idempotence gate
re-extracts 3 reports twice in one single-lane subprocess per wave. v0145 only points the private runtime at manager v0255
(same gate contract; each wave runs one subprocess per file in parallel, prints a heartbeat every 30 s, records per-wave timing,
and times the native phases into VRN2_Phase_Timing_latest.json + one [計] 階段耗時 line). Runtime v0145 = runtime v0144 + v0255.

v0144: v0143 entry + output location / DuckDB incremental Parquet store + SSOT-ID coordination (VRN-2 side) + Workbench v0101 + handler v0108.

Operator 2026-10-29: the three systems (VRN-2 / VDF / VCGC) stay independent; SSOT / Regex / synonym / policy entries are proposed
bottom-up with a blank SSOT ID, VCGC detects cross-system conflicts, the user and AI fix them, VCGC assigns the number and the
subsystem fills it in automatically. VRN-2 is to close out quickly through the HTML U/I: output location chosen with Windows I/O
(dialog / drag) or a cloud-synced folder, Parquet output with incremental extraction managed by DuckDB.
v0144 lands runtime v0144 = runtime v0142 + VRN2_UIAction_v0108 (vrn2://pick?kind=outdir · outdir?reset=1 · --set-outdir) +
VRN2_OutputStore_v0100 (mirror + DuckDB incremental store, pyarrow fallback) + VRN2_SSOTSync_v0100 (request / apply / sync)
+ VRN2_Workbench_v0101 (output-location and store panel · SSOT-ID status). New steps: ⑤b SSOT-ID sync after the register;
⑬ output store after the closeout receipt (GRAY until an output folder is chosen; VRN2_OUTPUT_DIR seeds the config).

v0143: v0142 entry + single-instance guard + wider child limits + in-process ⑫b fallback. Runtime v0142 untouched.

Operator desktop run 2026-10-29 01:33 (paste-back): two launcher instances overlapped (01:35 and 01:58) on the same VIA root,
free RAM fell to 0.16 GB, and every child subprocess then hit its ceiling: ⑦ killed after 1500 s without output, ⑪ verifier
stopped at 1800 s, ⑫b --refresh-ui killed at 120 s, so the U/I had no input block and the one-click ⑤b went RED although
⑧ completed. v0143 adds: (1) VIA_Reports/vrn2/VRN2_Launcher.lock — a second launcher on the same root refuses to start while
the first PID is alive (VRN2_FORCE_PARALLEL=1 overrides); (2) child limits from the environment with safer defaults
(VRN2_UI_REFRESH_WAIT 600 s · VRN2_SILENT_MAX 3600 s for the ⑦ run · VRN2_MANIFEST_WAIT 900 s · VIA_VRN2_VERIFY_WAIT 3600 s);
(3) when the ⑫b handler subprocess fails or times out, this entry writes the input block itself (same patch_ui code, in
process) so the front end stays linked. Everything else is v0142.

v0142: v0141 entry + Workbench U/I (template-locked front end bound to the run's receipts) + summarizer v0117.

Operator 2026-10-28: the pasted run (v0136 line · summarizer v0114) showed truncated / header-polluted four points, and
the operator uploaded the "VIA VRN-2 Workbench" template to lock as the front end, integrated with the backend as one
system, with a transparent seal logo replacing the template logo. v0142 lands runtime v0142 = runtime v0141 +
VRN_ENG062_SummarizerV1_v0117 (leading banner / title / section-heading lines trimmed from an excerpt; spans stay
exact) + VRN2_Workbench_v0100 (renders VIA_Reports/vrn2/VRN2_Workbench_latest.html from the receipts and output books;
vrn2:// actions wired; VRN2_Logo.png auto-transparent) + its font assets. After the closeout receipt is written this
entry renders the Workbench, links it from the legacy U/I page and opens it. Everything else is v0141.
"""
from __future__ import annotations

# ===== 1. Parameters =====
VERSION = "ActivateVRN-2 v0146"
BASE_NAME = "ActivateVRN-2_v0136.py"
RUNTIME_ZIP = "VRN2_Runtime_v0146.zip"
RUNTIME_MANIFEST = "VRN2_Runtime_v0146.json"
PRIVATE_FOLDER = "VRN2"
OCR_BRIDGE = "VRN2_OCRBridge_v0101.py"
CONTEXT_NAME = "VRN2_Runtime_Context.json"
STATE_PATTERNS = (("SSOT", "VRN2_SSOT_v*.json"), ("SSOT", "VRN_Config_v1*.json"), ("registry", "VRN2_*.json"), ("registry", "VRN2_*.jsonl"))
MANAGER = "VRN_SystemManager_v0255.py"   # v0244–v0254 belong to the desktop line in functional modules/VRN; this runtime line continues at v0255 (PRIOR pinned v0243)
VERBATIM = "VRN2_VerbatimVerifier_v0104.py"
MAX_PASSES = 2
WORKBENCH = "VRN2_Workbench_v0102.py"
UI_HANDLER = "VRN2_UIAction_v0109.py"   # v0105 / v0107 are the desktop line's publish handlers in functional modules/VRN; this line went v0108 → v0109 (vrn2://integrate)
OUTPUT_STORE = "VRN2_OutputStore_v0100.py"
SSOT_SYNC = "VRN2_SSOTSync_v0101.py"
HISTORY_ALIGN = "VRN2_HistoryAlign_v0100.py"
DATA_INTEGRATE = "VRN2_DataIntegrate_v0100.py"
CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0100.py"
MARKET_FETCH_GLOB = "VRN2_MarketFetch_v[0-9][0-9][0-9][0-9].py"   # borrowed from the shared desktop-line folder functional modules/VRN (read-only · latest number)
LOCK_NAME = "VRN2_Launcher.lock"
RECEIPT_NAME = "VRN2_Closeout_v0146.json"
LIMIT_DEFAULTS = {"VRN2_UI_REFRESH_WAIT": 600, "VRN2_SILENT_MAX": 3600, "VRN2_MANIFEST_WAIT": 900, "VIA_VRN2_VERIFY_WAIT": 3600, "VRN2_MARKET_WAIT": 1800, "VRN2_CONSENSUS_WAIT": 900}
CRITICAL_STEPS = ("② 定位 VRN-2 · VRN-2 SystemManager", "② 擷取引擎", "② 摘要器", "②b", "⑤", "⑥ 啟動前", "⑦", "⑧", "⑪")

import hashlib
import html
import importlib.util
import json
import os
import queue
import re
import subprocess
import threading
from pathlib import Path
import shutil
import sys
import tempfile
import time
import zipfile
import datetime

# [VIA:ACCEL-BRIDGE:v0111] The unchanged released launcher loads the existing accelerator bridge.


# ===== 2. Versioned runtime restoration =====
def load_base():
    path = Path(__file__).resolve().with_name(BASE_NAME)
    specification = importlib.util.spec_from_file_location("vrn2_release_v0136", path)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def restore_private_runtime(root: Path, package_dir: Path | None = None) -> Path:
    package_dir = package_dir or Path(__file__).resolve().parent
    manifest = json.loads((package_dir / RUNTIME_MANIFEST).read_text(encoding="utf-8"))
    archive_path = package_dir / RUNTIME_ZIP
    if hashlib.sha256(archive_path.read_bytes()).hexdigest() != manifest["zip_sha256"]:
        raise ValueError("VRN-2 runtime archive checksum mismatch")
    runtime = root / "functional modules" / PRIVATE_FOLDER
    staged = []
    with zipfile.ZipFile(archive_path) as archive:
        for entry in manifest["files"]:
            relative = Path(entry["path"])
            if relative.is_absolute() or ".." in relative.parts or len(relative.parts) != 1:
                raise ValueError("Invalid runtime member")
            data = archive.read(entry["path"])
            if hashlib.sha256(data).hexdigest() != entry["sha256"]:
                raise ValueError("Runtime member checksum mismatch: " + entry["path"])
            target = runtime / relative
            if target.exists() and target.read_bytes() != data:
                raise ValueError("Existing VRN-2 runtime differs; retained without overwrite: " + str(target))
            staged.append((target, data))
    for target, data in staged:
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    shared = root / "functional modules" / "VRN"
    for folder, pattern in STATE_PATTERNS:
        for source in (shared / folder).glob(pattern):
            target = runtime / folder / source.name
            if source.is_file() and not target.exists():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
    return runtime


# ===== 2b. v0143: single-instance guard · child limits · ⑫b fallback =====
def pid_alive(pid: int) -> bool:
    if not pid or pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            handle = ctypes.windll.kernel32.OpenProcess(0x1000, False, int(pid))  # PROCESS_QUERY_LIMITED_INFORMATION
            if not handle:
                return False
            code = ctypes.c_ulong()
            still = ctypes.windll.kernel32.GetExitCodeProcess(handle, ctypes.byref(code))
            ctypes.windll.kernel32.CloseHandle(handle)
            return bool(still) and code.value == 259  # STILL_ACTIVE
        except Exception:  # noqa: BLE001
            return False
    try:
        os.kill(int(pid), 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def acquire_lock(output: Path) -> tuple:
    """One launcher per VIA root. Returns (ok, info). A live PID in the lock refuses this start unless VRN2_FORCE_PARALLEL=1; a stale lock is taken over."""
    output.mkdir(parents=True, exist_ok=True)
    path = output / LOCK_NAME
    old = {}
    if path.is_file():
        try:
            old = json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            old = {"pid": 0, "raw": "unreadable"}
        alive = pid_alive(int(old.get("pid") or 0))
        if alive and os.environ.get("VRN2_FORCE_PARALLEL") != "1":
            return False, {"lock": str(path), "holder": old, "alive": True, "why": "另一個 VRN-2 啟動器還在跑(PID %s · %s · 自 %s)· 本次不跑;等它結束再貼,或 VRN2_FORCE_PARALLEL=1 強制(會搶 RAM · 2026-10-29 實跑就是這樣全逾時)" % (old.get("pid"), old.get("version"), old.get("started"))}
        if alive:
            note = "VRN2_FORCE_PARALLEL=1 · 與 PID %s 並行" % old.get("pid")
        else:
            note = "接手過期鎖(PID %s 已不在)" % old.get("pid")
    else:
        note = "新鎖"
    mine = {"pid": os.getpid(), "version": VERSION, "started": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "root": str(output.parent.parent), "python": sys.executable}
    path.write_text(json.dumps(mine, ensure_ascii=False, indent=1), encoding="utf-8")
    return True, {"lock": str(path), "holder": mine, "alive": False, "why": note}


def release_lock(output: Path) -> None:
    path = output / LOCK_NAME
    try:
        if path.is_file() and int(json.loads(path.read_text(encoding="utf-8")).get("pid") or 0) == os.getpid():
            path.unlink()
    except Exception:  # noqa: BLE001
        pass


def limits() -> dict:
    out = {}
    for key, default in LIMIT_DEFAULTS.items():
        try:
            out[key] = max(int(os.environ.get(key) or default), 60)
        except ValueError:
            out[key] = default
    return out


def run_limits(arguments: list, timeout, kwargs: dict, lim: dict) -> tuple:
    """Map a child command to its (timeout, kwargs): --refresh-ui → VRN2_UI_REFRESH_WAIT; vrn2 --run → silent_max VRN2_SILENT_MAX; manifest → VRN2_MANIFEST_WAIT."""
    tokens = [str(a) for a in arguments]
    kwargs = dict(kwargs)
    if "--refresh-ui" in tokens:
        timeout = max(int(timeout or 0), lim["VRN2_UI_REFRESH_WAIT"])
        kwargs["silent_max"] = max(int(kwargs.get("silent_max") or 0), lim["VRN2_UI_REFRESH_WAIT"])
    elif "vrn2" in tokens and "--run" in tokens:
        kwargs["silent_max"] = max(int(kwargs.get("silent_max") or 0), lim["VRN2_SILENT_MAX"])
    elif tokens and tokens[-2:-1] == ["manifest"] or "manifest" in tokens[2:4]:
        timeout = max(int(timeout or 0), lim["VRN2_MANIFEST_WAIT"])
    return timeout, kwargs


def ensure_input_block(runtime: Path, output: Path, steps: list) -> dict:
    """⑫b fallback: if the handler subprocess did not leave the input block in the legacy U/I, write it here (same patch_ui, in process)."""
    ui = Path(output) / "VRN2_UI_latest.html"
    entries = [entry for entry in steps if str(entry.get("step", "")).startswith("⑫b")]
    present = ui.is_file() and "<!--vrn2-input-->" in ui.read_text(encoding="utf-8", errors="replace")
    if present and entries and entries[-1].get("lamp") == "GREEN":
        return {"lamp": "GREEN", "how": "子行程", "detail": entries[-1].get("detail", "")}
    if not ui.is_file():
        return {"lamp": "GRAY", "how": "none", "detail": "沒有 U/I 頁(⑦ 沒寫出)· 不補放"}
    handler = Path(runtime) / UI_HANDLER
    try:
        specification = importlib.util.spec_from_file_location("vrn2_ui_handler_fallback", handler)
        module = importlib.util.module_from_spec(specification)
        sys.modules[specification.name] = module
        specification.loader.exec_module(module)
        ok, message = module.patch_ui(output)
    except Exception as error:  # noqa: BLE001
        ok, message = False, "%s: %s" % (type(error).__name__, str(error)[:120])
    lamp = "GREEN" if ok else "YELLOW"
    detail = "v0143 本支補放(處理器子行程 %s)· %s" % ((entries[-1].get("detail", "")[:80] if entries else "沒跑"), message)
    if entries:
        entries[-1].update(lamp=lamp, detail=detail)
    else:
        steps.append({"step": "⑫b U/I 輸入區塊(window I/O)", "lamp": lamp, "detail": detail})
    return {"lamp": lamp, "how": "in-process", "detail": detail}


# ===== 2c. v0144: SSOT-ID sync · output store =====
def _load_runtime_module(runtime: Path, name: str, alias: str):
    specification = importlib.util.spec_from_file_location(alias, Path(runtime) / name)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def ssot_sync(runtime: Path, steps: list) -> dict:
    """⑤b: VRN-2 side of the three-system SSOT-ID protocol — apply VCGC grants / conflicts to the component register, rewrite the request."""
    try:
        module = _load_runtime_module(runtime, SSOT_SYNC, "vrn2_ssot_sync_entry")
        result = module.sync(Path(runtime))
    except Exception as error:  # noqa: BLE001
        result = {"lamp": "YELLOW", "apply": {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}, "request": {}}
    a, q = result.get("apply") or {}, result.get("request") or {}
    if a.get("lamp") == "GRAY":
        detail = a.get("why", "沒有登記冊")
    else:
        counts = q.get("counts") or {}
        detail = "核發 %s · 衝突 %s · 待核號 %s(SSOT 類 %s · 程式類 %s)· 自撞 %s · 登記冊 %s · 核發冊 %s" % (
            a.get("granted", 0), a.get("conflicts", 0), a.get("pending", 0), counts.get("ssot_like", "—"), counts.get("program", "—"), counts.get("self_conflicts", 0),
            a.get("register", "—"), " · ".join(a.get("grant_sources") or []) or "尚無(VCGC 還沒核發)")
    lamp = {"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(result.get("lamp"), "YELLOW")
    steps.append({"step": "⑤b SSOT-ID 核號同步(VRN-2 側)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑤b SSOT-ID 核號同步 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "apply": {k: a.get(k) for k in ("granted", "conflicts", "pending", "register", "grant_sources") if k in a}, "request": q}


def output_store(runtime: Path, output: Path, run_id: str, steps: list) -> dict:
    """⑬: mirror this run's books + incremental Parquet store (DuckDB) into the chosen output folder; GRAY when none is chosen."""
    try:
        module = _load_runtime_module(runtime, OUTPUT_STORE, "vrn2_output_store_entry")
        if os.environ.get("VRN2_OUTPUT_DIR") and not module.read_config(output).get("output_dir"):
            module.write_config(output, os.environ["VRN2_OUTPUT_DIR"], "環境變數 VRN2_OUTPUT_DIR")
        result = module.sync(Path(output), None, run_id)
    except Exception as error:  # noqa: BLE001
        result = {"lamp": "RED", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "RED")
    if lamp == "GRAY":
        detail = result.get("why", "未設定輸出位置")
    elif "store_engine" in result:
        appended = result.get("appended") or {}
        detail = "%s(%s)· 鏡像 %d · 引擎 %s · 新檔 %d / 已知 %d · 追加 %s · parquet %d%s" % (
            result.get("output_dir"), result.get("cloud_hint", ""), len(result.get("mirrored") or []), result.get("store_engine"), len(result.get("new_files") or []), len(result.get("known_files") or []),
            " / ".join("%s %s" % (k, v) for k, v in appended.items()), len(result.get("parquet_files") or []), (" · " + result["why"]) if result.get("why") else "")
    else:
        detail = result.get("why", "")
    steps.append({"step": "⑬ 輸出位置 · 增量庫(DuckDB)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬ 輸出位置 · 增量庫 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {k: result.get(k) for k in ("lamp", "why", "output_dir", "cloud_hint", "store_engine", "store", "run_id", "new_files", "known_files", "appended", "totals", "catalog_files", "parquet_files", "mirrored") if k in result}


# ===== 3. Completion gate =====
# ===== v0146: ⑥e market data · ⑥f consensus Combined · ⑬b history alignment · ⑬c legacy-database integration scan =====
def shared_market_tool(root: Path) -> Path | None:
    """⑥e borrows the shared folder's VRN2_MarketFetch (desktop line · read-only · latest number); None when absent."""
    folder = Path(root) / "functional modules" / "VRN"
    hits = sorted(folder.glob(MARKET_FETCH_GLOB), key=lambda p: int(re.search(r"_v(\d{4})", p.name).group(1))) if folder.is_dir() else []
    return hits[-1] if hits else None


def stream_child(command: list, cwd: Path, wait: int, prefix: str) -> tuple:
    """Run a child, echo its lines live with a prefix, kill it after `wait` seconds of total time; returns (rc, lines)."""
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    proc = subprocess.Popen([str(c) for c in command], cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", env=env)
    bucket: queue.Queue = queue.Queue()

    def pump():
        for line in proc.stdout:
            bucket.put(line)
        bucket.put(None)
    threading.Thread(target=pump, daemon=True).start()
    lines, started = [], time.time()
    while True:
        try:
            line = bucket.get(timeout=5)
        except queue.Empty:
            if time.time() - started > wait:
                proc.kill()
                lines.append("[RED] 逾時 %d 秒 · 已停止" % wait)
                print(prefix + lines[-1], flush=True)
                break
            continue
        if line is None:
            break
        lines.append(line.rstrip("\n"))
        print(prefix + lines[-1][:300], flush=True)
    try:
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill()
    return (proc.returncode if proc.returncode is not None else -9), lines


def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:
    """⑥e: TWSE / TPEX / Yahoo market data through the shared folder's VRN2_MarketFetch (borrowed · read-only): --fetch then --fill; never RED (GRAY opted out / absent · YELLOW env or partial)."""
    basic = Path(output) / "output" / "VRN2_BasicInfo_latest.json"
    market = Path(output) / "market"
    tool = shared_market_tool(root)
    extra = {}
    if os.environ.get("VIA_VRN2_NO_MARKET") == "1":
        lamp, detail = "GRAY", "VIA_VRN2_NO_MARKET=1 · 本輪不抓市場資料"
    elif not tool:
        lamp, detail = "GRAY", "共用夾 functional modules\\VRN 沒有 VRN2_MarketFetch_v*.py(桌機線工具)· 不抓 · ⑬b 歷史對齊與 Combined 的還原價會缺"
    elif not basic.is_file():
        lamp, detail = "GRAY", "沒有基本資料冊(⑦ 沒出冊)· 不抓"
    else:
        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        results = {}
        for verb in ("--fetch", "--fill"):
            command = [sys.executable, "-X", "utf8", str(tool), verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)]
            rc, lines = stream_child(command, tool.parent, wait + 120, "    [⑥e] ")
            last = next((line for line in reversed(lines) if line.startswith("[計] 市場")), "")
            match = re.search(r"\[計\] 市場(擷取|填值) · (GREEN|YELLOW|RED|GRAY) · (.*)", last)
            results[verb] = {"rc": rc, "lamp": match.group(2) if match else ("RED" if rc else "YELLOW"), "msg": (match.group(3) if match else (lines[-1] if lines else "沒有輸出"))[:240], "lines": len(lines)}
            if verb == "--fetch" and results[verb]["lamp"] in ("GRAY", "RED"):
                break
        fetched, filled = results.get("--fetch", {}), results.get("--fill", {})
        if fetched.get("lamp") == "GRAY":
            lamp = "GRAY"
        elif fetched.get("lamp") == "RED" or filled.get("lamp") == "RED":
            lamp = "YELLOW"
        elif filled.get("lamp") == "GREEN" and fetched.get("lamp") == "GREEN":
            lamp = "GREEN"
        else:
            lamp = "YELLOW"
        detail = "%s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, fetched.get("lamp", "—"), fetched.get("msg", ""), filled.get("lamp", "—"), filled.get("msg", "沒跑"))
        extra = {"tool": str(tool), "results": results, "market_json": str(market / "VRN2_Market_latest.json") if (market / "VRN2_Market_latest.json").is_file() else ""}
    steps.append({"step": "⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 MarketFetch)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑥e 市場擷取 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **extra}


def consensus_join(runtime: Path, root: Path, output: Path, steps: list, lim: dict) -> dict:
    """⑥f: FactSet / YFinance consensus through the bundled fusion engine, then the Combined book (target price → adjusted · medians · real-year EPS / PER); never RED."""
    try:
        module = _load_runtime_module(runtime, CONSENSUS_JOIN, "vrn2_consensus_join_entry")
        fixtures = [f for f in (os.environ.get("VRN2_CONSENSUS_FIXTURES") or "").split(";") if f.strip()]
        ran = module.run(Path(output), Path(root), fixtures or None, int(lim.get("VRN2_CONSENSUS_WAIT", 900)))
        joined = module.join(Path(output))
    except Exception as error:  # noqa: BLE001
        ran, joined = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}, {"lamp": "GRAY", "why": "沒組 Combined"}
    pair = (ran.get("lamp", "YELLOW"), joined.get("lamp", "YELLOW"))
    if "YELLOW" in pair or "RED" in pair:
        lamp = "YELLOW"                      # env missing / partial / engine trouble → YELLOW, never RED (non-critical step)
    elif pair == ("GREEN", "GREEN"):
        lamp = "GREEN"
    else:
        lamp = "GRAY"                        # opted out / no tool / no book
    detail = "共識 %s:%s · Combined %s:%s" % (ran.get("lamp", "—"), ran.get("why", ""), joined.get("lamp", "—"), joined.get("why", ""))
    steps.append({"step": "⑥f 共識合併(FactSet / YFinance → Combined 冊)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑥f 共識合併 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "run": {k: ran.get(k) for k in ("lamp", "why", "engine", "python", "codes", "codes_got", "codes_missing", "gate", "rc", "receipt") if k in ran}, "join": {k: joined.get(k) for k in ("lamp", "why", "rows", "target_adj", "factset_median", "yf_median", "eps_cells", "year_n", "files") if k in joined}}


def history_align(runtime: Path, root: Path, output: Path, steps: list) -> dict:
    """⑬b: history (MOPS / TWSE via ⑥e) reconciles ≥ 1 period per report → history overrides estimates · checks · Deleted zone; never RED."""
    if os.environ.get("VIA_VRN2_NO_HISTORY") == "1":
        result = {"lamp": "GRAY", "why": "VIA_VRN2_NO_HISTORY=1 · 本輪不做歷史對齊"}
    else:
        try:
            module = _load_runtime_module(runtime, HISTORY_ALIGN, "vrn2_history_align_entry")
            result = module.align(Path(root))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = str(result.get("why", ""))
    steps.append({"step": "⑬b 歷史對齊(歷史覆蓋預估 · 加減乘除檢驗 · 刪除區)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬b 歷史對齊 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **{k: result.get(k) for k in ("totals", "written", "receipt") if k in result}}


def integrate_scan(runtime: Path, output: Path, steps: list) -> dict:
    """⑬c: detect legacy CSV / XLSX / Google-Sheet exports and leave the question to the user in the Workbench (apply only via vrn2://integrate); never RED."""
    if os.environ.get("VIA_VRN2_NO_INTEGRATE") == "1":
        result = {"lamp": "GRAY", "state": "NONE", "why": "VIA_VRN2_NO_INTEGRATE=1 · 本輪不掃舊資料庫"}
    else:
        try:
            module = _load_runtime_module(runtime, DATA_INTEGRATE, "vrn2_data_integrate_entry")
            result = module.scan(Path(output))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "state": "NONE", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = "%s · %s" % (result.get("state", "NONE"), result.get("why", ""))
    steps.append({"step": "⑬c 舊資料庫整合掃描(CSV / XLSX / Google Sheet · 問使用者)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬c 舊資料庫整合掃描 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "state": result.get("state"), "candidates": len(result.get("candidates") or []), "receipt": result.get("receipt")}


def strict_exit_code(steps: list, original_rc: int) -> int:
    if original_rc != 0:
        return original_rc if original_rc in (1, 2, 130) else 1
    if any(entry.get("lamp") == "RED" for entry in steps):
        return 1
    for prefix in CRITICAL_STEPS:
        found = [entry for entry in steps if str(entry.get("step", "")).startswith(prefix)]
        if not found:
            return 1
        if any(entry.get("lamp") != "GREEN" for entry in found):
            return 2
    if any(entry.get("lamp") in ("YELLOW", "GRAY") and str(entry.get("step", "")).startswith("⑥c") for entry in steps):
        return 2
    return 0


def output_gaps(directory: Path) -> list:
    """Required report headings and four summary points must actually be populated."""
    gaps = []
    for stem, required in (("VRN2_BasicInfo_latest", ("FILENAME", "REPORT_DATE", "TICKER", "TITLE")), ("VRN2_Summary_latest", ("TITLE", "POINT_1", "POINT_2", "POINT_3", "POINT_4"))):
        path = directory / (stem + ".json")
        if not path.is_file():
            gaps.append({"book": stem, "reason": "missing output"})
            continue
        rows = json.loads(path.read_text(encoding="utf-8"))
        if not rows:
            gaps.append({"book": stem, "reason": "empty output"})
        for row in rows:
            missing = [key for key in required if not str(row.get(key) or "").strip()]
            if missing:
                gaps.append({"book": stem, "file": row.get("FILENAME"), "missing": missing})
    return gaps


def current_completion(base, comp, steps, comp_mtime, started):
    if comp_mtime < started - 1:
        # The native caller also prints comp.items after checking freshness.
        # Do not attribute an older run's failed items to this run.
        comp.clear()
        comp.update(verdict="本輪未寫出完成判定", red=1, yellow=0, items=[], exceptions=[])
    return base(comp, steps, comp_mtime, started)


def fresh_output_books(directory, started):
    names = ("VRN2_BasicInfo_latest.json", "VRN2_FinancialData_latest.json", "VRN2_Summary_latest.json", "VRN2_SummarySource_latest.json")
    return all((directory / name).is_file() and (directory / name).stat().st_mtime >= started - 1 for name in names)


def update_closeout_ui(path: Path, code: int, gaps: list) -> bool:
    if not path.is_file():
        return False
    label = {0: "GREEN", 1: "RED", 2: "YELLOW"}.get(code, "RED")
    message = "正式收尾通過" if code == 0 else "正式收尾尚未完成，保留待核對項目"
    reasons = "；".join(str(row.get("file", row.get("book", ""))) + ": " + ", ".join(row.get("missing", [row.get("reason", "")])) for row in gaps)
    notice = '<!--VRN2-CLOSEOUT-137-START--><div role="status" id="vrn2-closeout-137" style="padding:10px;margin-bottom:8px;border:2px solid #a66c11;background:#fff6d8;color:#523900"><strong>' + html.escape(label + " · " + message) + '</strong><div>' + html.escape(reasons) + '</div></div><!--VRN2-CLOSEOUT-137-END-->'
    page = path.read_text(encoding="utf-8")
    page = re.sub(r"<!--VRN2-CLOSEOUT-137-START-->.*?<!--VRN2-CLOSEOUT-137-END-->", "", page, flags=re.S)
    page, count = re.subn(r"(<body\b[^>]*>)", lambda match: match.group(1) + notice, page, count=1, flags=re.I)
    if count == 0:
        charset = re.match(r"\s*<meta\b[^>]*charset[^>]*>", page, flags=re.I)
        if charset:
            page = page[:charset.end()] + notice + page[charset.end():]
        else:
            page = '<meta charset="utf-8">\n' + notice + page
    temporary = path.with_suffix(".closeout.tmp")
    temporary.write_text(page, encoding="utf-8")
    temporary.replace(path)
    return True


def repass_wanted(output: Path, attempt: int) -> tuple:
    """A second pass is taken only when the idempotence gate found a stale main record (cache cleared) on the first pass."""
    if attempt >= MAX_PASSES or os.environ.get("VRN2_NO_REPASS") == "1":
        return False, "no re-pass (limit or VRN2_NO_REPASS)"
    path = output / "IDEMPOTENCE_latest.json"
    if not path.is_file():
        return False, "no idempotence receipt"
    try:
        receipt = json.loads(path.read_text(encoding="utf-8"))
    except Exception as error:
        return False, "unreadable idempotence receipt: " + type(error).__name__
    if receipt.get("classification") == "STALE_RECORD":
        return True, "STALE_RECORD · %s · cache cleared %d" % ("、".join(receipt.get("stale_files") or []), len(receipt.get("cache_cleared") or []))
    return False, "idempotence " + str(receipt.get("classification"))


def configure_ui_launcher(runtime, root, launcher=None):
    launcher = Path(launcher or __file__).resolve()
    path = Path(runtime) / "VRN2_UIAction_Config.json"
    config = json.loads(path.read_text(encoding="utf-8"))
    config.update(launcher=str(launcher), root=str(root), version=VERSION)
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    (launcher.parent / CONTEXT_NAME).write_text(json.dumps({"root": str(root)}, ensure_ascii=False, indent=2), encoding="utf-8")


def link_workbench(legacy: Path, workbench: Path) -> bool:
    """Legacy U/I page (written by the manager · reopened by the vrn2:// handler) gets one link bar to the Workbench; rerun replaces the same bar."""
    if not legacy.is_file():
        return False
    try:
        rel = os.path.relpath(workbench, legacy.parent).replace(os.sep, "/")
    except ValueError:
        rel = workbench.as_uri()
    bar = ('<!--VRN2-WORKBENCH-START--><div id="vrn2-workbench-link" style="padding:8px 12px;margin-bottom:8px;border:1px solid #dbd9d3;border-left:4px solid #b5291a;background:#fff;font:600 13px system-ui,sans-serif">'
           '<a href="%s" target="_blank" style="color:#b5291a;text-decoration:none">→ 開啟 VRN-2 Workbench(新 U/I · 範本視覺 · 本輪收據與輸出冊)</a>'
           '<span style="color:#6b6a66;font-weight:400"> · 這一頁是舊版 U/I(每檔細節 · 驗證過的輸出)</span></div><!--VRN2-WORKBENCH-END-->') % html.escape(rel)
    page = legacy.read_text(encoding="utf-8")
    page = re.sub(r"<!--VRN2-WORKBENCH-START-->.*?<!--VRN2-WORKBENCH-END-->", "", page, flags=re.S)
    page, count = re.subn(r"(<body\b[^>]*>)", lambda match: match.group(1) + bar, page, count=1, flags=re.I)
    if count == 0:
        page = bar + page
    temporary = legacy.with_suffix(".workbench.tmp")
    temporary.write_text(page, encoding="utf-8")
    temporary.replace(legacy)
    return True


def render_workbench(runtime: Path, root: Path, output: Path) -> dict:
    """Render the Workbench from the receipts just written; never fails the run (YELLOW on error)."""
    module_path = Path(runtime) / WORKBENCH
    try:
        specification = importlib.util.spec_from_file_location("vrn2_workbench_entry", module_path)
        module = importlib.util.module_from_spec(specification)
        sys.modules[specification.name] = module
        specification.loader.exec_module(module)
        path = module.render(root)
        linked = link_workbench(output / "VRN2_UI_latest.html", path)
        return {"lamp": "GREEN", "path": str(path), "version": getattr(module, "VERSION", "?"), "legacy_linked": linked, "detail": "%s · %s · 舊版 U/I 連結 %s" % (getattr(module, "VERSION", "?"), path, "已加" if linked else "沒有舊版頁")}
    except Exception as error:  # noqa: BLE001
        return {"lamp": "YELLOW", "path": "", "detail": "Workbench 沒渲染:%s: %s" % (type(error).__name__, str(error)[:160])}


def open_page(workbench: Path | None, base, output: Path) -> str:
    """Open the Workbench (Windows default browser); without it fall back to the legacy U/I; non-Windows prints the path."""
    if workbench and workbench.is_file():
        if hasattr(os, "startfile"):
            try:
                os.startfile(str(workbench))  # type: ignore[attr-defined]
                return "已送出瀏覽器開啟要求:%s" % workbench
            except OSError as error:
                return "開不了 %s(%s)· 請手動開" % (workbench, error.__class__.__name__)
        return "非 Windows · Workbench 在 %s" % workbench
    return base._ui_open(output, False)


def selftest() -> int:
    complete = [{"step": prefix, "lamp": "GREEN"} for prefix in CRITICAL_STEPS]
    assert strict_exit_code(complete, 0) == 0
    assert strict_exit_code(complete + [{"step": "⑧", "lamp": "RED"}], 0) == 1
    assert strict_exit_code(complete[:-1], 0) == 1
    assert strict_exit_code(complete[:-1] + [{"step": "⑪", "lamp": "YELLOW"}], 0) == 2
    assert strict_exit_code([], 1) == 1
    with tempfile.TemporaryDirectory(prefix="vrn2-private-check-") as temporary:
        root = Path(temporary)
        shared = root / "functional modules" / "VRN"
        shared.mkdir(parents=True)
        protected = shared / "VRN_SystemManager_v0153.py"
        protected.write_text("protected original", encoding="utf-8")
        runtime = restore_private_runtime(root)
        assert protected.read_text(encoding="utf-8") == "protected original"
        assert "def _vdf_home" in (runtime / "VRN_SystemManager_v0153.py").read_text(encoding="utf-8")
        assert (runtime / "rule_catalog_runtime.json").is_file()
        hashes = {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in runtime.iterdir()}
        restore_private_runtime(root)
        assert hashes == {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in runtime.iterdir()}
        (runtime / "VRN_SystemManager_v0153.py").write_text("different local content", encoding="utf-8")
        try:
            restore_private_runtime(root)
        except ValueError:
            pass
        else:
            raise AssertionError("Different local runtime must not be overwritten")
        cfg = runtime / "VRN2_UIAction_Config.json"
        cfg.write_text(json.dumps({"launcher": "old.py", "python": "python", "v2": "output"}), encoding="utf-8")
        launcher = root / "package" / "ActivateVRN-2_v0146.py"
        launcher.parent.mkdir()
        configure_ui_launcher(runtime, root, launcher)
        assert json.loads(cfg.read_text())["launcher"] == str(launcher)
        assert json.loads((launcher.parent / CONTEXT_NAME).read_text())["root"] == str(root)
        reports = root / "VIA_Reports" / "vrn2"
        reports.mkdir(parents=True)
        assert repass_wanted(reports, 1) == (False, "no idempotence receipt")
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "STALE_RECORD", "stale_files": ["a.pdf"], "cache_cleared": ["k.json"]}), encoding="utf-8")
        assert repass_wanted(reports, 1)[0] and not repass_wanted(reports, 2)[0]
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "NONDETERMINISTIC"}), encoding="utf-8")
        assert not repass_wanted(reports, 1)[0]
        os.environ["VRN2_NO_REPASS"] = "1"
        (reports / "IDEMPOTENCE_latest.json").write_text(json.dumps({"classification": "STALE_RECORD"}), encoding="utf-8")
        assert not repass_wanted(reports, 1)[0]
        os.environ.pop("VRN2_NO_REPASS", None)
    with tempfile.TemporaryDirectory(prefix="vrn2-workbench-check-") as temporary:
        folder = Path(temporary)
        legacy = folder / "VRN2_UI_latest.html"
        legacy.write_text("<html><body><p>ui</p></body></html>", encoding="utf-8")
        wb = folder / "VRN2_Workbench_latest.html"
        wb.write_text("<html></html>", encoding="utf-8")
        assert link_workbench(legacy, wb) and link_workbench(legacy, wb)
        page = legacy.read_text(encoding="utf-8")
        assert page.count('id="vrn2-workbench-link"') == 1 and 'href="VRN2_Workbench_latest.html"' in page and page.index("vrn2-workbench-link") < page.index("<p>ui")
        assert not link_workbench(folder / "missing.html", wb)
        broken = render_workbench(folder, folder, folder)
        assert broken["lamp"] == "YELLOW" and not broken["path"]
        assert open_page(None, type("B", (), {"_ui_open": staticmethod(lambda o, n: "legacy")})(), folder) == "legacy"
    with tempfile.TemporaryDirectory(prefix="vrn2-guard-check-") as temporary:
        folder = Path(temporary)
        out = folder / "VIA_Reports" / "vrn2"
        assert pid_alive(os.getpid()) and not pid_alive(0) and not pid_alive(2 ** 22 + 12345)
        ok1, g1 = acquire_lock(out)
        assert ok1 and g1["why"] == "新鎖" and (out / LOCK_NAME).is_file()
        ok2, g2 = acquire_lock(out)
        assert not ok2 and g2["alive"] and "另一個 VRN-2 啟動器還在跑" in g2["why"] and json.loads((out / LOCK_NAME).read_text(encoding="utf-8"))["pid"] == os.getpid()
        os.environ["VRN2_FORCE_PARALLEL"] = "1"
        ok3, g3 = acquire_lock(out)
        os.environ.pop("VRN2_FORCE_PARALLEL", None)
        assert ok3 and "並行" in g3["why"]
        (out / LOCK_NAME).write_text(json.dumps({"pid": 2 ** 22 + 12345, "version": "old"}), encoding="utf-8")
        ok4, g4 = acquire_lock(out)
        assert ok4 and "過期鎖" in g4["why"]
        release_lock(out)
        assert not (out / LOCK_NAME).is_file()
        (out / LOCK_NAME).write_text(json.dumps({"pid": 1}), encoding="utf-8")
        release_lock(out)
        assert (out / LOCK_NAME).is_file()  # someone else's lock is never removed
        os.environ["VRN2_UI_REFRESH_WAIT"] = "700"
        os.environ["VRN2_SILENT_MAX"] = "10"  # below floor → 60
        lim = limits()
        os.environ.pop("VRN2_UI_REFRESH_WAIT", None)
        os.environ.pop("VRN2_SILENT_MAX", None)
        assert lim["VRN2_UI_REFRESH_WAIT"] == 700 and lim["VRN2_SILENT_MAX"] == 60 and lim["VIA_VRN2_VERIFY_WAIT"] == 3600
        lim = limits()
        assert run_limits(["python", "h.py", "--refresh-ui", "--v2", "x"], 120, {}, lim) == (600, {"silent_max": 600})
        assert run_limits(["python", "m.py", "vrn2", "--run", "--no-open"], 7200, {}, lim) == (7200, {"silent_max": 3600})
        assert run_limits(["python", "b.py", "manifest", "root"], 300, {}, lim)[0] == 900
        assert run_limits(["git", "status"], 120, {}, lim) == (120, {})
        runtime = folder / "rt"
        runtime.mkdir()
        (runtime / UI_HANDLER).write_text("from pathlib import Path\ndef patch_ui(v2):\n    p = Path(v2) / 'VRN2_UI_latest.html'\n    p.write_text(p.read_text(encoding='utf-8').replace('</body>', '<!--vrn2-input-->blk<!--/vrn2-input--></body>'), encoding='utf-8')\n    return True, 'fixture block'\n", encoding="utf-8")
        steps = [{"step": "⑫b U/I 輸入區塊(window I/O)", "lamp": "YELLOW", "detail": "[RED] 逾時 120 秒"}]
        assert ensure_input_block(runtime, out, steps)["how"] == "none"
        (out / "VRN2_UI_latest.html").write_text("<html><body>ui</body></html>", encoding="utf-8")
        got = ensure_input_block(runtime, out, steps)
        assert got["how"] == "in-process" and got["lamp"] == "GREEN" and steps[-1]["lamp"] == "GREEN" and "<!--vrn2-input-->" in (out / "VRN2_UI_latest.html").read_text(encoding="utf-8")
        assert ensure_input_block(runtime, out, steps)["how"] == "子行程"
        (runtime / UI_HANDLER).write_text("def patch_ui(v2):\n    raise RuntimeError('boom')\n", encoding="utf-8")
        (out / "VRN2_UI_latest.html").write_text("<html><body>ui</body></html>", encoding="utf-8")
        steps2 = []
        got2 = ensure_input_block(runtime, out, steps2)
        assert got2["lamp"] == "YELLOW" and steps2 and "RuntimeError" in steps2[-1]["detail"]
    with tempfile.TemporaryDirectory(prefix="vrn2-v0145-check-") as temporary:   # v0145 checks kept verbatim
        folder = Path(temporary)
        runtime = folder / "rt"
        runtime.mkdir()
        for name in (SSOT_SYNC, "VRN2_SSOTSync_v0100.py", OUTPUT_STORE):   # v0146: SSOTSync v0101 is a thin tail over v0100
            source = Path(__file__).with_name(name)
            if not source.is_file():
                source = Path(__file__).resolve().parent.parent / "new" / name
            shutil.copy2(str(source), str(runtime / name))
        output = folder / "VIA_Reports" / "vrn2"
        (output / "output").mkdir(parents=True)
        (output / "scope_in").mkdir()
        steps = []
        got = ssot_sync(runtime, steps)
        assert got["lamp"] == "GRAY" and steps[-1]["step"].startswith("⑤b") and "登記冊" in steps[-1]["detail"]
        (runtime / "registry").mkdir()
        (runtime / "registry" / "VRN2_Component_Register_v0100.json").write_text(json.dumps({"entries": {"SSOT|A": {"no": "VRN2-SSOT-0001", "kind": "SSOT", "key": "A", "status": "暫編 · 待 VCGC 核號", "fp": "x"}}}), encoding="utf-8")
        got = ssot_sync(runtime, steps)
        assert got["lamp"] == "GREEN" and got["apply"]["pending"] == 1 and (runtime / "contract" / "VRN2_NUMBER_REQUEST_latest.json").is_file()
        got = output_store(runtime, output, "t1", steps)
        assert got["lamp"] == "GRAY" and steps[-1]["step"].startswith("⑬") and "未設定" in steps[-1]["detail"]
        (output / "scope_in" / "a.pdf").write_bytes(b"A")
        (output / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TICKER": "2330"}]), encoding="utf-8")
        for book in ("FinancialData", "Summary", "Rejected"):
            (output / "output" / ("VRN2_%s_latest.json" % book)).write_text("[]", encoding="utf-8")
        os.environ["VRN2_OUTPUT_DIR"] = str(folder / "OneDrive" / "out")
        got = output_store(runtime, output, "t2", steps)
        os.environ.pop("VRN2_OUTPUT_DIR", None)
        assert got["lamp"] in ("GREEN", "YELLOW") and (folder / "OneDrive" / "out" / "VRN2" / "latest" / "VRN2_BasicInfo_latest.json").is_file()
        if got.get("store_engine") != "none":
            assert got["new_files"] == ["a.pdf"] and got["appended"]["BasicInfo"] == 1
        assert json.loads((output / "VRN2_Output_Config.json").read_text(encoding="utf-8"))["how"].startswith("環境變數")
        got2 = output_store(runtime, output, "t3", steps)
        assert got2["new_files"] == [] and sum(got2["appended"].values()) == 0  # engine none → both empty as well
    with tempfile.TemporaryDirectory(prefix="vrn2-v0146-check-") as temporary:
        folder = Path(temporary)
        root = folder / "VIA"
        runtime = root / "functional modules" / "VRN2"
        runtime.mkdir(parents=True)
        for name in (HISTORY_ALIGN, DATA_INTEGRATE, CONSENSUS_JOIN):
            source = Path(__file__).with_name(name)
            if not source.is_file():
                source = Path(__file__).resolve().parent.parent / "new" / name
            shutil.copy2(str(source), str(runtime / name))
        output = root / "VIA_Reports" / "vrn2"
        (output / "output").mkdir(parents=True)
        lim = limits()
        steps = []
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "GRAY" and "沒有 VRN2_MarketFetch" in steps[-1]["detail"] and steps[-1]["step"].startswith("⑥e")
        shared = root / "functional modules" / "VRN"
        shared.mkdir(parents=True)
        (shared / "VRN2_MarketFetch_v0112.py").write_text("import sys\nv = sys.argv[1]\nprint('[計] 心跳')\nprint('[計] 市場擷取 · GREEN · 擷取 2 代號' if v == '--fetch' else '[計] 市場填值 · YELLOW · 完整 1 · 部分 1')\n", encoding="utf-8")
        (shared / "VRN2_MarketFetch_v0101.py").write_text("print('old')\n", encoding="utf-8")
        assert shared_market_tool(root).name == "VRN2_MarketFetch_v0112.py"
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "GRAY" and "沒有基本資料冊" in got["detail"]
        (output / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TICKER": "2330", "REPORT_DATE": "2026-01-01", "TARGET_PRICE": "100", "BROKER": "A"}]), encoding="utf-8")
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "YELLOW" and got["results"]["--fetch"]["lamp"] == "GREEN" and got["results"]["--fill"]["lamp"] == "YELLOW" and "擷取 GREEN:擷取 2 代號" in got["detail"]
        os.environ["VIA_VRN2_NO_MARKET"] = "1"
        assert market_fetch(root, output, steps, lim)["lamp"] == "GRAY"
        os.environ.pop("VIA_VRN2_NO_MARKET", None)
        os.environ["VIA_VRN2_NO_CONSENSUS"] = "1"
        got = consensus_join(runtime, root, output, steps, lim)
        os.environ.pop("VIA_VRN2_NO_CONSENSUS", None)
        assert got["lamp"] in ("GRAY", "YELLOW") and got["run"]["lamp"] == "GRAY" and got["join"]["rows"] == 1 and steps[-1]["step"].startswith("⑥f") and (output / "output" / "VRN2_Combined_latest.json").is_file()
        combined = json.loads((output / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
        assert list(combined[0].keys())[9:13] == ["TARGET_PRICE", "TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN"] and combined[0]["TARGET_PRICE"] == "100"
        got = history_align(runtime, root, output, steps)
        assert got["lamp"] == "GRAY" and "沒有年度數據冊" in got["detail"] and steps[-1]["step"].startswith("⑬b")
        (output / "output" / "VRN2_FinancialData_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "ITEM": "Revenue", "PERIOD": "2025A", "VALUE": "1,000"}]), encoding="utf-8")
        got = history_align(runtime, root, output, steps)
        assert got["lamp"] == "GRAY" and "沒有市場資料" in got["detail"] and (output / "VRN2_HistoryAlign_latest.json").is_file()
        os.environ["VIA_VRN2_NO_HISTORY"] = "1"
        assert history_align(runtime, root, output, steps)["lamp"] == "GRAY"
        os.environ.pop("VIA_VRN2_NO_HISTORY", None)
        os.environ["VRN2_INTEGRATE_TEMP"] = str(folder / "temp")
        got = integrate_scan(runtime, output, steps)
        assert got["lamp"] == "GRAY" and got["state"] == "NONE" and steps[-1]["step"].startswith("⑬c")
        (output / "legacy_in").mkdir()
        (output / "legacy_in" / "old - Sheet1.csv").write_text("Ticker,Date,Broker,Target Price\n2330,2025-10-01,CLSA,1200\n", encoding="utf-8-sig")
        got = integrate_scan(runtime, output, steps)
        assert got["lamp"] == "YELLOW" and got["state"] == "PENDING_USER" and got["candidates"] == 1 and (output / "VRN2_Integrate_latest.json").is_file()
        os.environ.pop("VRN2_INTEGRATE_TEMP", None)
        complete = [{"step": prefix, "lamp": "GREEN"} for prefix in CRITICAL_STEPS]
        assert strict_exit_code(complete + [{"step": "⑥e 市場擷取", "lamp": "YELLOW"}, {"step": "⑬b 歷史對齊", "lamp": "GRAY"}], 0) == 0   # non-critical steps never change the code
    print("[PASS] v0146: ⑥e market fetch (absent → GRAY · no book → GRAY · fetch GREEN + fill YELLOW → YELLOW · opt-out) · ⑥f consensus Combined (opt-out run → Combined still built · column order) · ⑬b history align (no book / no market → GRAY · opt-out) · ⑬c integrate scan (none → GRAY · legacy csv → PENDING_USER) · non-critical lamps never change rc")
    print("[PASS] v0145: manager v0255 is the active manager (parallel idempotence gate · phase timing) · receipt v0145")
    print("[PASS] v0144: ⑤b SSOT-ID sync (no register → GRAY · pending → GREEN + request) · ⑬ output store (unset → GRAY · VRN2_OUTPUT_DIR seeds config · incremental append · idempotent re-run)")
    print("[PASS] v0143: v0142 checks + single-instance lock (live / stale / forced / foreign), child limits (env · floor · mapping), ⑫b in-process fallback (missing page · patched · already present · handler error)")
    return 0


# ===== 4. Delegate to the existing VRN-2 entry =====
def main(argv: list | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments == ["--selftest"]:
        return selftest()
    base = load_base()
    if os.environ.get("VRN2_ROOT"):
        root = Path(os.environ["VRN2_ROOT"]).resolve()
    elif Path(__file__).with_name(CONTEXT_NAME).is_file():
        root = Path(json.loads(Path(__file__).with_name(CONTEXT_NAME).read_text(encoding="utf-8"))["root"]).resolve()
    else:
        root, _ = base.locate()
    for key in ("VIA_VRN2_NO_PUSH", "VIA_VRN2_NO_BORROW", "VIA_VRN2_NO_VRN1_SYNC"):
        os.environ[key] = "1"
    bridge_path = Path(__file__).with_name("VIA_ExecutionBridge_v0103.py")
    spec = importlib.util.spec_from_file_location("vrn2_execution_bridge", bridge_path)
    execution_bridge = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = execution_bridge
    spec.loader.exec_module(execution_bridge)
    tool_state = execution_bridge.activate(root)
    print("[加速] VRN-2 active lock:", tool_state["accelerator"])
    runtime = restore_private_runtime(root)
    lim = limits()
    os.environ["VIA_VRN2_VERIFY_WAIT"] = str(lim["VIA_VRN2_VERIFY_WAIT"])
    original_run = base.run
    def accelerated_run(arguments, *args, **kwargs):
        if args:
            timeout, kwargs = run_limits(arguments, args[0], kwargs, lim)
            args = (timeout,) + tuple(args[1:])
        if arguments and Path(str(arguments[0])).name.lower().startswith("python"):
            arguments = execution_bridge.command(arguments, root, Path(__file__).parent)
        return original_run(arguments, *args, **kwargs)
    base.run = accelerated_run
    original_manager_setup = base.land_manager
    def manager_setup(*args, **kwargs):
        _prior_manager, lamp, detail = original_manager_setup(*args, **kwargs)
        return runtime / MANAGER, lamp, detail + " · active manager v0255"
    base.land_manager = manager_setup
    original_register = base.register_ui_protocol
    def register_current_launcher(vrn, v2):
        lamp, detail = original_register(vrn, v2)
        configure_ui_launcher(vrn, root)
        return lamp, detail + " · launcher v0146"
    base.register_ui_protocol = register_current_launcher
    base.UI_HANDLER_NAME = UI_HANDLER                                      # v0144: ⑥c registers / ⑫b refreshes with handler v0108 (outdir)
    base._ui_wait = lambda: None

    def locate_private():
        base.LOCATE.update(note="VRN-2 private runtime; exact ship v0153; manager v0255; shared VRN retained", fix=False)
        return root, runtime

    def own_runtime_ready(_runtime, _root):
        return "GREEN", "Exact VRN-2 runtime verified in functional modules/VRN2; shared VRN untouched"

    def skip_ship(*_arguments):
        return "GRAY", "Closeout validation only; no Git commit or push"

    def skip_archive(*_arguments):
        return "GRAY", "Versioned runtime retained; no files moved or deleted"

    original_ocr_environment = base.ocr_env

    def ocr_environment(environment=None):
        lamp, detail = original_ocr_environment(environment)
        target = os.environ if environment is None else environment
        if lamp == "GREEN":
            target["VIA_VRN2_OCR_BRIDGE"] = str(Path(__file__).resolve().with_name(OCR_BRIDGE))
        return lamp, detail + " · official ONNX telemetry opt-out bridge v0101"

    base.VERSION = VERSION
    base.locate = locate_private
    base.restore_bundle = own_runtime_ready
    base.git_ship = skip_ship
    base.consolidate = skip_archive
    base.ocr_env = ocr_environment
    base.PACK.clear()
    base.STEPS.clear()
    base.LOG.clear()
    original_done = base._done_ok
    base._done_ok = lambda comp, steps, stamp, start: current_completion(original_done, comp, steps, stamp, start)
    started = time.time()
    output = root / "VIA_Reports" / "vrn2"
    output.mkdir(parents=True, exist_ok=True)
    locked, guard = acquire_lock(output)
    if not locked:
        print("[RED] 單機閘 · " + guard["why"], flush=True)
        print("NEXT: [RED] VRN-2 v0143 · rc 1 · 另一個啟動器還在跑 · 鎖 %s" % guard["lock"], flush=True)
        return 1
    print("[計] 單機閘 · %s · 鎖 %s · 子行程上限 ⑫b %d 秒 · ⑦ 無輸出 %d 秒 · 工具冊 %d 秒 · ⑪ 等驗證 %d 秒" % (guard["why"], guard["lock"], lim["VRN2_UI_REFRESH_WAIT"], lim["VRN2_SILENT_MAX"], lim["VRN2_MANIFEST_WAIT"], lim["VIA_VRN2_VERIFY_WAIT"]), flush=True)
    try:
        return _main_locked(arguments, base, root, runtime, tool_state, output, started, lim, guard)
    finally:
        release_lock(output)


def _main_locked(arguments, base, root, runtime, tool_state, output, started, lim, guard) -> int:
    passes = []
    ui_block = {}
    ssot = {}
    for attempt in range(1, MAX_PASSES + 1):
        if attempt > 1:
            base.PACK.clear()
            base.STEPS.clear()
            base.LOG.clear()
        # The outer entry opens pages only after all gates are written.
        original_rc = base.main(arguments + (["--no-open"] if "--no-open" not in arguments else []))
        ui_block = ensure_input_block(runtime, output, base.STEPS)
        ssot = ssot_sync(runtime, base.STEPS)
        if ui_block.get("how") == "in-process":
            print("[計] ⑫b %s · %s" % (ui_block["lamp"], ui_block["detail"]), flush=True)
        again, why = repass_wanted(output, attempt)
        passes.append({"attempt": attempt, "rc": original_rc, "lamps": {entry.get("step"): entry.get("lamp") for entry in base.STEPS}, "idempotence": why, "repass": again})
        if not again:
            break
        print("[計] ⑧ 冪等閘 · " + why + " → 自動再跑一輪(第 %d 輪 · 該檔重新擷取 · 其餘沿用快取)" % (attempt + 1), flush=True)
    market = market_fetch(root, output, base.STEPS, lim)
    consensus = consensus_join(runtime, root, output, base.STEPS, lim)
    code = strict_exit_code(base.STEPS, original_rc)
    gaps = output_gaps(output / "output")
    if gaps and code == 0:
        code = 2
    fresh_outputs = fresh_output_books(output / "output", started)
    proof_report = {"verdict": "NOT_RUN", "rc": 1, "reason": "本輪輸出未齊，不驗舊冊"}
    try:
        if not fresh_outputs:
            raise RuntimeError(proof_report["reason"])
        proof_path = Path(__file__).with_name(VERBATIM)
        proof_spec = importlib.util.spec_from_file_location("vrn2_original_quote_gate", proof_path)
        proof_module = importlib.util.module_from_spec(proof_spec)
        sys.modules[proof_spec.name] = proof_module
        proof_spec.loader.exec_module(proof_module)
        source = output / "scope_in"
        proof_report = proof_module.verify(output / "output", source)
    except Exception as error:
        proof_report.update(verdict="FAIL" if fresh_outputs else "NOT_RUN", error=f"{type(error).__name__}: {error}")
    (output / "VRN2_VerbatimVerify_latest.json").write_text(json.dumps(proof_report, ensure_ascii=False, indent=2), encoding="utf-8")
    if proof_report["rc"] == 1:
        code = 1
    elif proof_report["rc"] == 2 and code == 0:
        code = 2
    if proof_report["rc"]:
        gaps.append({"book": "四點原文核對", "reason": proof_report["verdict"] + " · " + str(proof_report.get("counts", proof_report.get("error", "")))})
    update_closeout_ui(output / "VRN2_UI_latest.html", code, gaps)
    receipt = {"system": "VRN-2", "version": VERSION, "rc": code, "elapsed_s": round(time.time() - started, 2), "runtime": str(runtime), "passes": passes, "steps": base.STEPS, "fresh_outputs": fresh_outputs, "output_gaps": gaps, "source_quotes": proof_report, "tools": tool_state, "shared_runtime_modified": False,
               "guard": guard, "limits": lim, "ui_block": ui_block, "ssot_sync": ssot, "market": market, "consensus": consensus}
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    store = output_store(runtime, output, datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), base.STEPS)
    receipt["output_store"] = store
    receipt["steps"] = base.STEPS
    if store.get("lamp") == "RED" and code == 0:
        code = 2
        receipt["rc"] = code
    receipt["history_align"] = history_align(runtime, root, output, base.STEPS)
    receipt["integrate"] = integrate_scan(runtime, output, base.STEPS)
    receipt["steps"] = base.STEPS
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    workbench = render_workbench(runtime, root, output)
    receipt["workbench"] = workbench
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[%s] Workbench U/I · %s" % (workbench["lamp"], workbench["detail"]))
    print("NEXT: [%s] VRN-2 v0146 · rc %s · 跑了 %d 輪 · %s" % ({0: "GREEN", 1: "RED", 2: "YELLOW"}.get(code, "RED"), code, len(passes), output / RECEIPT_NAME))
    if "--no-open" not in arguments and os.environ.get("VRN2_NO_UI") != "1":
        print("[U/I]", open_page(Path(workbench["path"]) if workbench.get("path") else None, base, output))
    return code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print("[RED] VRN-2 v0142:", type(error).__name__, str(error), file=sys.stderr)
        raise SystemExit(1)
