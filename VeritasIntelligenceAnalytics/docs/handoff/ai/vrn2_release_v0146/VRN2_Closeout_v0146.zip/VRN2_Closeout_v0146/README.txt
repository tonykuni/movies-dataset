VRN2_Closeout_v0146 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0146.py [--source <folder>] [--no-install] [--no-open]
Runtime: VRN2_Runtime_v0146.zip = runtime v0145 (167 members byte-identical) + 8 new members:
  VRN2_Workbench_v0102 · VRN2_UIAction_v0109 · VRN2_SSOTSync_v0101 · VRN2_HistoryAlign_v0100 · VRN2_DataIntegrate_v0100 · VRN2_ConsensusJoin_v0100 ·
  VRN2_SSOT_Proposals_v0100.json · VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py (operator upload · bundled unchanged)
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0146 (desktop run 2026-10-29 10:25 · v0145 · 2546 s · operator U/I + data requests):
 - Workbench v0102: bilingual headers (Report Date / 報告日期 …), top-aligned cells, amounts in NT$ millions with thousands separators (per-share / multiples / % keep value),
   tiles auto-fit, output-folder slot (long-term Parquet store) above the other-system Gates, first right-panel block = input dedup matrix + engine status, logo 1.5% margin · 180%.
 - ⑥e market fetch: borrows the shared folder's VRN2_MarketFetch_v* (--fetch / --fill → VIA_Reports/vrn2/market/VRN2_Market_latest.json); GRAY when absent / opted out (VIA_VRN2_NO_MARKET=1).
 - ⑥f consensus Combined: the bundled fusion engine (FactSet via cnyes + YFinance) → VRN2_Consensus_latest.json → output/VRN2_Combined_latest (TARGET_PRICE → TARGET_PRICE(ADJ) → FactSet / YFinance medians →
   <year>_DILUTED_EPS_FACTSET ×3 → <year>_PER_FACTSET ×3 (real years n..n+2) → … → TOPIC & SUMMARY → STATUS). VIA_VRN2_NO_CONSENSUS=1 opts out.
 - ⑬b history alignment: ≥ 1 period per report must reconcile with MOPS / TWSE history (0.97–1.03 · unit scale auto) → history overrides estimates → FinancialAligned / Deleted books + checks.
 - ⑬c legacy-database integration scan (CSV / XLSX / Google-Sheet export) → the Workbench asks; apply via vrn2://integrate never deletes originals (copies to TEMP after a verified new Parquet).
 - SSOT proposals (ticker regex ×3 · ETF suffix classes · Taipei / HK phone · rating codes 0–5 · target-price synonyms · analyst titles · U/I number format) with blank ssot_id → VRN2_NUMBER_REQUEST.
 - Handler v0109 (vrn2://integrate?scan|apply|dismiss) · receipt VRN2_Closeout_v0146.json (market · consensus · history_align · integrate).
Verification: see VRN2_Verification_v0146.md. Hashes: PACKAGE_SHA256.json.
