"""ActivateVRN-2_v0146.py = v0145 + ⑥e 市場擷取(借共用 MarketFetch)· ⑥f 共識合併(借上傳引擎)· ⑬b 歷史對齊 · ⑬c 舊資料庫整合掃描 · Workbench v0102 · 處理器 v0109 · SSOTSync v0101。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v145/new/ActivateVRN-2_v0145.py").read_text(encoding="utf-8")
s = src
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90]); s = s.replace(a, b)
rep('"""VRN-2 v0145: v0144 entry + manager v0255 (parallel idempotence gate · heartbeat · phase timing).\n',
    '"""VRN-2 v0146: v0145 entry + market data (⑥e) · FactSet / YFinance consensus Combined book (⑥f) · history alignment (⑬b) · legacy-database integration scan (⑬c) · Workbench v0102 · handler v0109 · SSOT proposals.\n\n'
    'Operator 2026-10-29 (10:25 paste-back of v0145 · 2546 s · CPU 87.5% busy by another process so the launcher ran 1 lane; ⑬ duckdb incremental GREEN) asked:\n'
    ' - U/I: headers with spaces (now bilingual per the operator list), everything top-aligned, amounts shown in NT$ millions with thousands separators (per-share / multiples / % keep their value),\n'
    '   tiles auto-fit instead of overflowing, an output-folder slot (long-term Parquet store) above the other-system Gates, the first right-panel block = input dedup matrix + engine status, logo 180% with 1.5% margin.\n'
    ' - "Why can\'t it fetch TWSE / TPEX / YFinance any more?": the desktop line\'s own manager (v0249+) carries a ⑥e MarketFetch step; this package line (manager v0243 → v0255) never had one.\n'
    '   v0146 adds ⑥e here: after the run it borrows the shared folder\'s latest VRN2_MarketFetch_v*.py (desktop-line tool · read-only · wraps VDF_TW_AllInOne) with --fetch then --fill → VIA_Reports/vrn2/market/VRN2_Market_latest.json.\n'
    ' - ⑥f: the uploaded VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120 (bundled unchanged in runtime v0146) fetches FactSet (cnyes) + YFinance consensus; VRN2_ConsensusJoin builds output/VRN2_Combined_latest\n'
    '   (per report: … TARGET_PRICE · TARGET_PRICE(ADJ) · FACTSET / YFINANCE target medians · <year>_DILUTED_EPS_FACTSET ×3 · <year>_PER_FACTSET ×3 with real years n..n+2 · CURRENT_PRICE_REPORT · UPSIDE_PCT(ADJ) · ADJ_CLOSE · … · TOPIC & SUMMARY · STATUS).\n'
    ' - ⑬b VRN2_HistoryAlign: at least one period of each report must reconcile with MOPS / TWSE history (0.97–1.03 · unit scale auto) before history overrides estimates; add/sub and mul/div checks; contradicted report values go to the Deleted zone.\n'
    ' - ⑬c VRN2_DataIntegrate scan: legacy CSV / XLSX / Google-Sheet exports near the output folder are detected and the Workbench asks the user; apply (vrn2://integrate · handler v0109) never deletes originals (copies to TEMP after a verified new Parquet).\n'
    ' Non-critical steps: ⑥e / ⑥f / ⑬b / ⑬c never turn the closeout RED (GRAY when opted out or a tool is absent · YELLOW on env / partial). Opt-outs: VIA_VRN2_NO_MARKET=1 · VIA_VRN2_NO_CONSENSUS=1 · VIA_VRN2_NO_HISTORY=1 · VIA_VRN2_NO_INTEGRATE=1.\n'
    ' Runtime v0146 = runtime v0145 (167 members byte-identical) + Workbench v0102 · UIAction v0109 · SSOTSync v0101 · HistoryAlign v0100 · DataIntegrate v0100 · ConsensusJoin v0100 · SSOT proposals v0100 · the consensus engine v0120.\n\n'
    'v0145: v0144 entry + manager v0255 (parallel idempotence gate · heartbeat · phase timing).\n')
rep('VERSION = "ActivateVRN-2 v0145"', 'VERSION = "ActivateVRN-2 v0146"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0145.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0146.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0145.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0146.json"')
rep('WORKBENCH = "VRN2_Workbench_v0101.py"', 'WORKBENCH = "VRN2_Workbench_v0102.py"')
rep('UI_HANDLER = "VRN2_UIAction_v0108.py"   # v0105 / v0107 are the desktop line\'s publish handlers in functional modules/VRN; this line skips to v0108',
    'UI_HANDLER = "VRN2_UIAction_v0109.py"   # v0105 / v0107 are the desktop line\'s publish handlers in functional modules/VRN; this line went v0108 → v0109 (vrn2://integrate)')
rep('SSOT_SYNC = "VRN2_SSOTSync_v0100.py"', 'SSOT_SYNC = "VRN2_SSOTSync_v0101.py"\nHISTORY_ALIGN = "VRN2_HistoryAlign_v0100.py"\nDATA_INTEGRATE = "VRN2_DataIntegrate_v0100.py"\nCONSENSUS_JOIN = "VRN2_ConsensusJoin_v0100.py"\nMARKET_FETCH_GLOB = "VRN2_MarketFetch_v[0-9][0-9][0-9][0-9].py"   # borrowed from the shared desktop-line folder functional modules/VRN (read-only · latest number)')
rep('RECEIPT_NAME = "VRN2_Closeout_v0145.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0146.json"')
rep('LIMIT_DEFAULTS = {"VRN2_UI_REFRESH_WAIT": 600, "VRN2_SILENT_MAX": 3600, "VRN2_MANIFEST_WAIT": 900, "VIA_VRN2_VERIFY_WAIT": 3600}',
    'LIMIT_DEFAULTS = {"VRN2_UI_REFRESH_WAIT": 600, "VRN2_SILENT_MAX": 3600, "VRN2_MANIFEST_WAIT": 900, "VIA_VRN2_VERIFY_WAIT": 3600, "VRN2_MARKET_WAIT": 1800, "VRN2_CONSENSUS_WAIT": 900}')
rep('import importlib.util\nimport json\nimport os\nimport re\n', 'import importlib.util\nimport json\nimport os\nimport queue\nimport re\nimport subprocess\nimport threading\n')
NEW = r'''
# ===== v0146: ⑥e market data · ⑥f consensus Combined · ⑬b history alignment · ⑬c legacy-database integration scan =====
def shared_market_tool(root: Path) -> Path | None:
    """⑥e borrows the shared folder's VRN2_MarketFetch (desktop line · read-only · latest number); None when absent."""
    folder = Path(root) / "functional modules" / "VRN"
    hits = sorted(folder.glob(MARKET_FETCH_GLOB), key=lambda p: int(re.search(r"_v(\d{4})", p.name).group(1))) if folder.is_dir() else []
    return hits[-1] if hits else None


def stream_child(command: list, cwd: Path, wait: int, prefix: str) -> tuple:
    """Run a child, echo its lines live with a prefix, kill it after `wait` seconds of total time; returns (rc, lines)."""
    env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
    proc = subprocess.Popen([str(c) for c in command], cwd=str(cwd), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", env=env)
    bucket: queue.Queue = queue.Queue()

    def pump():
        for line in proc.stdout:
            bucket.put(line)
        bucket.put(None)
    threading.Thread(target=pump, daemon=True).start()
    lines, started = [], time.time()
    while True:
        try:
            line = bucket.get(timeout=5)
        except queue.Empty:
            if time.time() - started > wait:
                proc.kill()
                lines.append("[RED] 逾時 %d 秒 · 已停止" % wait)
                print(prefix + lines[-1], flush=True)
                break
            continue
        if line is None:
            break
        lines.append(line.rstrip("\n"))
        print(prefix + lines[-1][:300], flush=True)
    try:
        proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        proc.kill()
    return (proc.returncode if proc.returncode is not None else -9), lines


def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:
    """⑥e: TWSE / TPEX / Yahoo market data through the shared folder's VRN2_MarketFetch (borrowed · read-only): --fetch then --fill; never RED (GRAY opted out / absent · YELLOW env or partial)."""
    basic = Path(output) / "output" / "VRN2_BasicInfo_latest.json"
    market = Path(output) / "market"
    tool = shared_market_tool(root)
    extra = {}
    if os.environ.get("VIA_VRN2_NO_MARKET") == "1":
        lamp, detail = "GRAY", "VIA_VRN2_NO_MARKET=1 · 本輪不抓市場資料"
    elif not tool:
        lamp, detail = "GRAY", "共用夾 functional modules\\VRN 沒有 VRN2_MarketFetch_v*.py(桌機線工具)· 不抓 · ⑬b 歷史對齊與 Combined 的還原價會缺"
    elif not basic.is_file():
        lamp, detail = "GRAY", "沒有基本資料冊(⑦ 沒出冊)· 不抓"
    else:
        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        results = {}
        for verb in ("--fetch", "--fill"):
            command = [sys.executable, "-X", "utf8", str(tool), verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)]
            rc, lines = stream_child(command, tool.parent, wait + 120, "    [⑥e] ")
            last = next((line for line in reversed(lines) if line.startswith("[計] 市場")), "")
            match = re.search(r"\[計\] 市場(擷取|填值) · (GREEN|YELLOW|RED|GRAY) · (.*)", last)
            results[verb] = {"rc": rc, "lamp": match.group(2) if match else ("RED" if rc else "YELLOW"), "msg": (match.group(3) if match else (lines[-1] if lines else "沒有輸出"))[:240], "lines": len(lines)}
            if verb == "--fetch" and results[verb]["lamp"] in ("GRAY", "RED"):
                break
        fetched, filled = results.get("--fetch", {}), results.get("--fill", {})
        if fetched.get("lamp") == "GRAY":
            lamp = "GRAY"
        elif fetched.get("lamp") == "RED" or filled.get("lamp") == "RED":
            lamp = "YELLOW"
        elif filled.get("lamp") == "GREEN" and fetched.get("lamp") == "GREEN":
            lamp = "GREEN"
        else:
            lamp = "YELLOW"
        detail = "%s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, fetched.get("lamp", "—"), fetched.get("msg", ""), filled.get("lamp", "—"), filled.get("msg", "沒跑"))
        extra = {"tool": str(tool), "results": results, "market_json": str(market / "VRN2_Market_latest.json") if (market / "VRN2_Market_latest.json").is_file() else ""}
    steps.append({"step": "⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 MarketFetch)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑥e 市場擷取 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **extra}


def consensus_join(runtime: Path, root: Path, output: Path, steps: list, lim: dict) -> dict:
    """⑥f: FactSet / YFinance consensus through the bundled fusion engine, then the Combined book (target price → adjusted · medians · real-year EPS / PER); never RED."""
    try:
        module = _load_runtime_module(runtime, CONSENSUS_JOIN, "vrn2_consensus_join_entry")
        fixtures = [f for f in (os.environ.get("VRN2_CONSENSUS_FIXTURES") or "").split(";") if f.strip()]
        ran = module.run(Path(output), Path(root), fixtures or None, int(lim.get("VRN2_CONSENSUS_WAIT", 900)))
        joined = module.join(Path(output))
    except Exception as error:  # noqa: BLE001
        ran, joined = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}, {"lamp": "GRAY", "why": "沒組 Combined"}
    pair = (ran.get("lamp", "YELLOW"), joined.get("lamp", "YELLOW"))
    if "YELLOW" in pair or "RED" in pair:
        lamp = "YELLOW"                      # env missing / partial / engine trouble → YELLOW, never RED (non-critical step)
    elif pair == ("GREEN", "GREEN"):
        lamp = "GREEN"
    else:
        lamp = "GRAY"                        # opted out / no tool / no book
    detail = "共識 %s:%s · Combined %s:%s" % (ran.get("lamp", "—"), ran.get("why", ""), joined.get("lamp", "—"), joined.get("why", ""))
    steps.append({"step": "⑥f 共識合併(FactSet / YFinance → Combined 冊)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑥f 共識合併 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "run": {k: ran.get(k) for k in ("lamp", "why", "engine", "python", "codes", "codes_got", "codes_missing", "gate", "rc", "receipt") if k in ran}, "join": {k: joined.get(k) for k in ("lamp", "why", "rows", "target_adj", "factset_median", "yf_median", "eps_cells", "year_n", "files") if k in joined}}


def history_align(runtime: Path, root: Path, output: Path, steps: list) -> dict:
    """⑬b: history (MOPS / TWSE via ⑥e) reconciles ≥ 1 period per report → history overrides estimates · checks · Deleted zone; never RED."""
    if os.environ.get("VIA_VRN2_NO_HISTORY") == "1":
        result = {"lamp": "GRAY", "why": "VIA_VRN2_NO_HISTORY=1 · 本輪不做歷史對齊"}
    else:
        try:
            module = _load_runtime_module(runtime, HISTORY_ALIGN, "vrn2_history_align_entry")
            result = module.align(Path(root))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = str(result.get("why", ""))
    steps.append({"step": "⑬b 歷史對齊(歷史覆蓋預估 · 加減乘除檢驗 · 刪除區)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬b 歷史對齊 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, **{k: result.get(k) for k in ("totals", "written", "receipt") if k in result}}


def integrate_scan(runtime: Path, output: Path, steps: list) -> dict:
    """⑬c: detect legacy CSV / XLSX / Google-Sheet exports and leave the question to the user in the Workbench (apply only via vrn2://integrate); never RED."""
    if os.environ.get("VIA_VRN2_NO_INTEGRATE") == "1":
        result = {"lamp": "GRAY", "state": "NONE", "why": "VIA_VRN2_NO_INTEGRATE=1 · 本輪不掃舊資料庫"}
    else:
        try:
            module = _load_runtime_module(runtime, DATA_INTEGRATE, "vrn2_data_integrate_entry")
            result = module.scan(Path(output))
        except Exception as error:  # noqa: BLE001
            result = {"lamp": "YELLOW", "state": "NONE", "why": "%s: %s" % (type(error).__name__, str(error)[:160])}
    lamp = result.get("lamp", "YELLOW")
    if lamp == "RED":
        lamp = "YELLOW"
    detail = "%s · %s" % (result.get("state", "NONE"), result.get("why", ""))
    steps.append({"step": "⑬c 舊資料庫整合掃描(CSV / XLSX / Google Sheet · 問使用者)", "lamp": lamp, "detail": detail[:300]})
    print("[計] ⑬c 舊資料庫整合掃描 · %s · %s" % (lamp, detail[:260]), flush=True)
    return {"lamp": lamp, "detail": detail, "state": result.get("state"), "candidates": len(result.get("candidates") or []), "receipt": result.get("receipt")}


def strict_exit_code(steps: list, original_rc: int) -> int:'''
rep('\ndef strict_exit_code(steps: list, original_rc: int) -> int:', NEW)
# _main_locked: ⑥e / ⑥f after the pass loop; ⑬b / ⑬c after ⑬
rep('''    code = strict_exit_code(base.STEPS, original_rc)
    gaps = output_gaps(output / "output")''', '''    market = market_fetch(root, output, base.STEPS, lim)
    consensus = consensus_join(runtime, root, output, base.STEPS, lim)
    code = strict_exit_code(base.STEPS, original_rc)
    gaps = output_gaps(output / "output")''')
rep('''               "guard": guard, "limits": lim, "ui_block": ui_block, "ssot_sync": ssot}''', '''               "guard": guard, "limits": lim, "ui_block": ui_block, "ssot_sync": ssot, "market": market, "consensus": consensus}''')
rep('''    if store.get("lamp") == "RED" and code == 0:
        code = 2
        receipt["rc"] = code
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    workbench = render_workbench(runtime, root, output)''', '''    if store.get("lamp") == "RED" and code == 0:
        code = 2
        receipt["rc"] = code
    receipt["history_align"] = history_align(runtime, root, output, base.STEPS)
    receipt["integrate"] = integrate_scan(runtime, output, base.STEPS)
    receipt["steps"] = base.STEPS
    (output / RECEIPT_NAME).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
    workbench = render_workbench(runtime, root, output)''')
rep('print("NEXT: [%s] VRN-2 v0145 · rc %s', 'print("NEXT: [%s] VRN-2 v0146 · rc %s')
rep('return lamp, detail + " · launcher v0145"', 'return lamp, detail + " · launcher v0146"')
rep('launcher = root / "package" / "ActivateVRN-2_v0145.py"', 'launcher = root / "package" / "ActivateVRN-2_v0146.py"')
rep('with tempfile.TemporaryDirectory(prefix="vrn2-v0145-check-") as temporary:', 'with tempfile.TemporaryDirectory(prefix="vrn2-v0145-check-") as temporary:   # v0145 checks kept verbatim')
rep('        for name in (SSOT_SYNC, OUTPUT_STORE):\n', '        for name in (SSOT_SYNC, "VRN2_SSOTSync_v0100.py", OUTPUT_STORE):   # v0146: SSOTSync v0101 is a thin tail over v0100\n')
# v0146 selftest block before the final prints
rep('''    print("[PASS] v0145: manager v0255 is the active manager (parallel idempotence gate · phase timing) · receipt v0145")''',
'''    with tempfile.TemporaryDirectory(prefix="vrn2-v0146-check-") as temporary:
        folder = Path(temporary)
        root = folder / "VIA"
        runtime = root / "functional modules" / "VRN2"
        runtime.mkdir(parents=True)
        for name in (HISTORY_ALIGN, DATA_INTEGRATE, CONSENSUS_JOIN):
            source = Path(__file__).with_name(name)
            if not source.is_file():
                source = Path(__file__).resolve().parent.parent / "new" / name
            shutil.copy2(str(source), str(runtime / name))
        output = root / "VIA_Reports" / "vrn2"
        (output / "output").mkdir(parents=True)
        lim = limits()
        steps = []
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "GRAY" and "沒有 VRN2_MarketFetch" in steps[-1]["detail"] and steps[-1]["step"].startswith("⑥e")
        shared = root / "functional modules" / "VRN"
        shared.mkdir(parents=True)
        (shared / "VRN2_MarketFetch_v0112.py").write_text("import sys\\nv = sys.argv[1]\\nprint('[計] 心跳')\\nprint('[計] 市場擷取 · GREEN · 擷取 2 代號' if v == '--fetch' else '[計] 市場填值 · YELLOW · 完整 1 · 部分 1')\\n", encoding="utf-8")
        (shared / "VRN2_MarketFetch_v0101.py").write_text("print('old')\\n", encoding="utf-8")
        assert shared_market_tool(root).name == "VRN2_MarketFetch_v0112.py"
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "GRAY" and "沒有基本資料冊" in got["detail"]
        (output / "output" / "VRN2_BasicInfo_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TICKER": "2330", "REPORT_DATE": "2026-01-01", "TARGET_PRICE": "100", "BROKER": "A"}]), encoding="utf-8")
        got = market_fetch(root, output, steps, lim)
        assert got["lamp"] == "YELLOW" and got["results"]["--fetch"]["lamp"] == "GREEN" and got["results"]["--fill"]["lamp"] == "YELLOW" and "擷取 GREEN:擷取 2 代號" in got["detail"]
        os.environ["VIA_VRN2_NO_MARKET"] = "1"
        assert market_fetch(root, output, steps, lim)["lamp"] == "GRAY"
        os.environ.pop("VIA_VRN2_NO_MARKET", None)
        os.environ["VIA_VRN2_NO_CONSENSUS"] = "1"
        got = consensus_join(runtime, root, output, steps, lim)
        os.environ.pop("VIA_VRN2_NO_CONSENSUS", None)
        assert got["lamp"] in ("GRAY", "YELLOW") and got["run"]["lamp"] == "GRAY" and got["join"]["rows"] == 1 and steps[-1]["step"].startswith("⑥f") and (output / "output" / "VRN2_Combined_latest.json").is_file()
        combined = json.loads((output / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
        assert list(combined[0].keys())[9:13] == ["TARGET_PRICE", "TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN"] and combined[0]["TARGET_PRICE"] == "100"
        got = history_align(runtime, root, output, steps)
        assert got["lamp"] == "GRAY" and "沒有年度數據冊" in got["detail"] and steps[-1]["step"].startswith("⑬b")
        (output / "output" / "VRN2_FinancialData_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "ITEM": "Revenue", "PERIOD": "2025A", "VALUE": "1,000"}]), encoding="utf-8")
        got = history_align(runtime, root, output, steps)
        assert got["lamp"] == "GRAY" and "沒有市場資料" in got["detail"] and (output / "VRN2_HistoryAlign_latest.json").is_file()
        os.environ["VIA_VRN2_NO_HISTORY"] = "1"
        assert history_align(runtime, root, output, steps)["lamp"] == "GRAY"
        os.environ.pop("VIA_VRN2_NO_HISTORY", None)
        os.environ["VRN2_INTEGRATE_TEMP"] = str(folder / "temp")
        got = integrate_scan(runtime, output, steps)
        assert got["lamp"] == "GRAY" and got["state"] == "NONE" and steps[-1]["step"].startswith("⑬c")
        (output / "legacy_in").mkdir()
        (output / "legacy_in" / "old - Sheet1.csv").write_text("Ticker,Date,Broker,Target Price\\n2330,2025-10-01,CLSA,1200\\n", encoding="utf-8-sig")
        got = integrate_scan(runtime, output, steps)
        assert got["lamp"] == "YELLOW" and got["state"] == "PENDING_USER" and got["candidates"] == 1 and (output / "VRN2_Integrate_latest.json").is_file()
        os.environ.pop("VRN2_INTEGRATE_TEMP", None)
        complete = [{"step": prefix, "lamp": "GREEN"} for prefix in CRITICAL_STEPS]
        assert strict_exit_code(complete + [{"step": "⑥e 市場擷取", "lamp": "YELLOW"}, {"step": "⑬b 歷史對齊", "lamp": "GRAY"}], 0) == 0   # non-critical steps never change the code
    print("[PASS] v0146: ⑥e market fetch (absent → GRAY · no book → GRAY · fetch GREEN + fill YELLOW → YELLOW · opt-out) · ⑥f consensus Combined (opt-out run → Combined still built · column order) · ⑬b history align (no book / no market → GRAY · opt-out) · ⑬c integrate scan (none → GRAY · legacy csv → PENDING_USER) · non-critical lamps never change rc")
    print("[PASS] v0145: manager v0255 is the active manager (parallel idempotence gate · phase timing) · receipt v0145")''')
for bad in ('ActivateVRN-2 v0145"', "VRN2_Closeout_v0145", "VRN2_Runtime_v0145.zip", "VRN2_Runtime_v0145.json", "VRN2_Workbench_v0101.py\"", "VRN2_UIAction_v0108.py\"", "VRN-2 v0145 · rc", "launcher v0145\"", "ActivateVRN-2_v0145.py\""):
    assert bad not in s, bad
(S / "v146/new/ActivateVRN-2_v0146.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0146 written", len(s.splitlines()), "lines")
