#!/bin/bash
# v0146 放進倉:docs/handoff/ai/vrn2_release_v0146/ + vrn1_vrn2_oneclick_v0107/ + functional modules/VRN/ 新工具(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v146
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0146; OP=$REPO/vrn1_vrn2_oneclick_v0107; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v146")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0146"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0107")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("full146.log", "full146.rc", "t146_setup.log", "pscheck146.log", "scen146.rc", "scen146_first.log", "scen146_again.log", "scen146_tamper.log", "scen146_setup.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0146_selftest.log", "VRN2_Workbench_v0102_selftest.log", "VRN2_HistoryAlign_v0100_selftest.log", "VRN2_DataIntegrate_v0100_selftest.log", "VRN2_UIAction_v0109_selftest.log", "VRN2_SSOTSync_v0101_selftest.log", "VRN2_ConsensusJoin_v0100_selftest.log", "run_full146.sh", "uitest/ui146.json")]
v2 = W / "t146/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0146.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_Activate_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Output_Config.json", "VRN2_Phase_Timing_latest.json", "VRN2_HistoryAlign_latest.json", "VRN2_Integrate_latest.json", "consensus/VRN2_Consensus_latest.json", "output/VRN2_Combined_latest.csv", "VRN2_Workbench_latest.html"):
    logs.append(("t146/" + n, v2 / n))
for n in ("VRN2_NUMBER_REQUEST_latest.json", "VRN2_NUMBER_STATE_latest.json"):
    logs.append(("t146/contract/" + n, W / "t146/VIA/functional modules/VRN2/contract" / n))
z(D / "logs_v0146.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1")) + sorted((W / "uitest").glob("*.js"))]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py")) + sorted((W / "new").glob("*.json")) if not q.name.startswith(("VRN2_Workbench_v0101", "VRN2_UIAction_v0108", "VRN2_SSOTSync_v0100", "VIA_CNYES"))]
z(D / "vrn2_test_tools_v0146.zip", tools)
z(OP / "tools_v0107.zip", [("tools/" + q.name, q) for q in (W / "operator107" / "boot_pair107.ps1", W / "operator107" / "oneline_pair107.txt", W / "operator107" / "Run-VRN1-VRN2-v0107.ps1")])
for n in ("VRN1_VRN2_OneClick_v0107.md", "VRN1_VRN2_Verification_v0107.md"): shutil.copy(W / "operator107" / n, OP / n)
for n in ("VRN2_Closeout_v0146.zip", "VRN2_Release_v0146.json", "VRN2_OneClick_v0146.md", "VRN2_Verification_v0146.md"): shutil.copy(W / "release146" / n, D / n)
# 新成員只在私有 runtime zip(functional modules/VRN2)與 vrn2_test_tools_v0146.zip/new;不放共用 VRN 夾(桌機線的號在那裡,免得版本鏈混線);上傳的共識引擎 v0120 只在 runtime zip(原樣)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
