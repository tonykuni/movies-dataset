"""VRN2_Handover_v0147.md:從 v0146 只增不減(v0146 是本線上一輪的號;桌機線用到 v0145)。"""
import json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v146")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0146.md").read_text(encoding="utf-8")
R = json.loads((S / "release146/VRN2_Release_v0146.json").read_text(encoding="utf-8")); rr = R["results"]["full_run_v0146_19_real"]; dk = R["results"]["desktop_v0145_2026_10_29_1025"]; sc = R["results"]["oneclick_scenario_pwsh"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg146/VRN2_Runtime_v0146.json").read_text(encoding="utf-8"))["files"]}
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)
lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0145 · 2026-10-29(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0146 · 2026-10-29(v0145 + 本輪:桌機 10:25 實跑 v0145 貼回(2546 秒 · CPU 被佔 87.5% → 1 路 · 冪等閘並行有效 151 秒 · ⑬ duckdb 綠)+ 操作員 U/I 與資料需求 + 上傳共識引擎 v0120 → "
            "Workbench v0102(雙語表頭 · 靠上 · 百萬台幣千分位 · 自動縮放 · 左欄輸出夾 · 右欄去重矩陣 + 引擎狀態 · logo 180%)· ⑥e 市場擷取(借共用 MarketFetch)· ⑥f 共識 Combined(FactSet / YFinance 中位數 · 真實年度 EPS / PER)· ⑬b 歷史對齊(至少一期對上才覆蓋 · 刪除區)· ⑬c 舊資料庫整合(問使用者 · 原檔不刪)· 處理器 v0109 · SSOTSync v0101 + 提案冊 · 啟動器 v0146 · 操作員一鍵 v0107 · 本地實測一輪改指;runtime v0145 的 167 個成員一個位元組都不動)")
src = "\n".join(lines)
old_round = "> **操作員令(2026-10-29 · 08:14 貼回後)**"
assert src.count(old_round) == 1
cj = rr["consensus_6f"]
new_round = ("> **操作員令(2026-10-29 · 10:25 貼回後)**:Gemini 對話(台股代號三形式 · ETF 尾碼 · 台北 / 香港電話 · 評等代碼 0 ~ 5 · 目標價同義字 · 分析師職稱)+「HEADER 用空格取代底線 內容全部靠上對齊 數值呈現在 U/I 上都是以百萬台幣為單位 除每股倍數 要有千分位號」+ v0145 整輪主控台(2546 秒)+ 兩張 Workbench 截圖 +"
             "「為何字體常爆出格子不會自動調整自動優化嗎 · 左邊 VRN-1 GATE 要有一格輸出檔案夾來存長線資料庫 增量維護一律用 PARQUET · 若使用者已有舊的資料庫(CSV / GOOGLE SHEET)主動提醒要不要進行資料整合 · 整合成功前千萬不要刪掉原有資料 · 自適應式對齊欄位核對後問使用者 · OK 則整合創立並把舊資料放到 TEMP · 一定要擷取歷史資料去做數字對齊 至少有一期要對 然後歷史覆蓋預估 加減法 乘除法檢驗 被歷史數據刪掉的部分放刪除區 · 右面板第一區要有輸入去重矩陣 目前引擎狀態 · 昨天不是可以擷取 TWSE/TPEX/YFINANCE 資料嗎 現在為何不行」"
             "→ 再傳 `VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py` +「LOGO 理字邊緣留空更少一點點但不可砍到字 然後高畫質放大到 180%% 依舊去背透明無框無特效無色」+ 欄名雙語清單(REPORT_DATE:Report Date / 報告日期 …)+「Report Target Price(Adj) / FactSet Target Price Median / YFinance Target Price Median / 2026 ~ 2028 Diluted EPS (FactSet) / 2026 ~ 2028 PER (FactSet) 在 Combined 目標價後面加上 · n 是今年 2026 · 還原真實年分」。\n"
             "> **本輪(v0146 · 套件 = 啟動器 v0146 + runtime v0146 = v0145 的 167 個成員不動 + 8 個新成員 · 操作員一鍵 v0107 · 本地實測一輪 v0100 改指)**:"
             "① **桌機 10:25 判讀**:%s;⑦ %s;⑪ %s 秒;④ %s;%s;%s;紅燈 %s。判讀:%s "
             "② **Workbench v0102**(v0101 薄尾):表頭雙語(清單外底線 → 空格 · 原欄名在 title)· th / td 靠上 · 金額欄依列 ITEM / TABLE 判單位 → 百萬台幣 + 千分位(每股 / 倍數 / %% 原值 · 滑鼠停留看原值)· 統計磚 clamp + 逐 px 縮(最小 12px 仍不夠就換行)· 左欄「輸出檔案夾 · 長線資料庫(Parquet 增量)」在其他系統 Gate 之上 · 右欄第一區 = 輸入去重矩陣 + 目前引擎狀態(含 ⑥e / ⑥f / ⑬ / ⑬b / ⑬c)· 舊資料庫整合提問 · 歷史對齊表 · 資料冊多 Combined / FinancialAligned / Deleted · logo 以 alpha 內容框重裁(留白 1.5%% · 雜訊 alpha 歸零)+ LANCZOS 180%%(44 → 79 px · 頁首 100 px)。"
             "③ **⑥e 市場擷取**:啟動器跑完 ⑦ 後借共用夾 `functional modules\\VRN\\VRN2_MarketFetch_v*.py`(桌機線工具 · 只讀 · 最新號)`--fetch` 再 `--fill` → `market\\VRN2_Market_latest.json`;共用夾沒有 → 灰;缺 yfinance → 黃交 VCGC;`VIA_VRN2_NO_MARKET=1` 不抓 —— 回答「為何不行」:桌機線自己的管理器 v0249 有 ⑥e,本套件線(v0243 → v0255)從來沒有。"
             "④ **⑥f 共識合併**:上傳的引擎 v0120 原樣內附 runtime;VRN2_ConsensusJoin v0100 以基本資料冊 TICKER 跑它(`--skip-unit-tests --allow-missing-duckdb` · 離線 `--fixture` 供測試)→ `consensus\\VRN2_Consensus_latest.json` → **Combined 冊**(每份報告一列 · 欄序照操作員雙語清單 · 目標價後接 TARGET_PRICE(ADJ) · FACTSET / YFINANCE 中位數 · %d / %d / %d 真實年度 EPS 與 PER · 最後 TOPIC & SUMMARY · STATUS 寫各欄來源 / 缺的原因)。"
             "⑤ **⑬b 歷史對齊**(VRN2_HistoryAlign v0100):科目同義字 → 年度期間 → 倍率自動對 → 至少一期對上才覆蓋 → VALUE_FINAL / VALUE_SOURCE / RECON_* · 差 > 3%% 進刪除區 · 加減 / 乘除檢驗只報不改 → FinancialAligned / Deleted 兩冊;原三冊不改。"
             "⑥ **⑬c 舊資料庫整合**(VRN2_DataIntegrate v0100 + 處理器 v0109 `vrn2://integrate`):掃輸出夾及其上一層 / legacy_in / `VRN2_INTEGRATE_DIRS` 的 CSV / TSV / XLSX(純 zip + xml 讀)/ Parquet / JSON / Google Sheet 匯出 → 同義字 + 內容型態對齊欄位(對不到保留 X_)→ Workbench 問 → apply:VRN-2 冊 ∪ 舊檔去重(同鍵同值去 · 不同值兩邊留標 CONFLICT)→ 新整合檔 json / csv / parquet → 重讀核對 → **原檔絕不刪**,核對過才複製到 TEMP;同內容整合過 / 選過不要的不再問。"
             "⑦ **SSOT 提案冊** v0100(9 條 · ssot_id 空白 · VRN2-PROP-xxxx)經 SSOTSync v0101 併進 ⑤b 請求冊。"
             "⑧ **啟動器 v0146**:⑥e / ⑥f 在 ⑦ 後、⑬b / ⑬c 在 ⑬ 後;四步都不轉紅(灰 / 黃);收據 `VRN2_Closeout_v0146.json` 多 market / consensus / history_align / integrate;處理器 v0109 · Workbench v0102 · SSOTSync v0101。"
             "容器實測:七支自測全 PASS · pwsh 雜湊鏈全 True · 沙盒 19 份:⑧ %s · 冪等閘 %s · ⑥f %s(%s / %s 代號 · gate %s · Combined %s 列)· ⑬ %s · ⑬c %s · Workbench v0102 %s(無頭 Chromium 無錯 · 雙語表頭 · 千分位)· 情境 %s。桌機還沒跑 v0146。\n"
             % (dk["cpu"], dk["step7_s"], dk["step11_s"], dk["step4_s"], dk["store"], dk["ui"], dk["red"], dk["diagnosis"], 2026, 2027, 2028,
                rr["completion"]["verdict"], rr["idempotence"], cj["lamp"], cj["codes_got"], cj["codes"], cj["gate"], cj["combined_rows"], rr["output_store"]["lamp"], rr["integrate_13c"]["state"], rr["workbench"]["lamp"], sc["rc"]))
src = src.replace(old_round, new_round + old_round, 1)
once("> **本輪(v0145 · 套件 = 啟動器 v0145 + runtime v0145", "> **前一輪(v0145 · 套件 = 啟動器 v0145 + runtime v0145")
anchor = "| ActivateVRN-2_v0145.py(套件 · 底座 v0136)| **v0145** |"
assert src.count(anchor) == 1
rows = ("| ActivateVRN-2_v0146.py(套件 · 底座 v0136)| **v0146** | 見發行清單 | `%s` | **新**(⑥e 市場擷取 · ⑥f 共識 Combined · ⑬b 歷史對齊 · ⑬c 整合掃描 · Workbench v0102 · 處理器 v0109 · SSOTSync v0101 · 收據 v0146)|\n"
        "| **VRN2_Workbench** | **v0102**(薄尾 · v0101 留著)| runtime v0146 | `%s` | **新**(雙語表頭 · 靠上 · 百萬台幣千分位 · 自動縮放 · 輸出夾格 · 去重矩陣 + 引擎狀態 · 歷史對齊表 · logo 180%% · 自測 13 項)|\n"
        "| **VRN2_UIAction** | **v0109**(薄尾 · v0108 留著)| runtime v0146 | `%s` | **新**(vrn2://integrate?scan / apply / dismiss · --integrate-scan · 自測 6 項)|\n"
        "| **VRN2_SSOTSync** | **v0101**(薄尾 · v0100 留著)| runtime v0146 | `%s` | **新**(提案冊併入請求冊 · 自測 6 項)|\n"
        "| **VRN2_HistoryAlign** | **v0100** | runtime v0146 | `%s` | **新**(至少一期對上 · 倍率自動 · 歷史覆蓋預估 · 刪除區 · 加減乘除檢驗 · 自測 14 項)|\n"
        "| **VRN2_DataIntegrate** | **v0100** | runtime v0146 | `%s` | **新**(CSV / XLSX / Google Sheet 匯出偵測 · 自適應欄位對齊 · 原檔不刪 · TEMP 副本 · 自測 15 項)|\n"
        "| **VRN2_ConsensusJoin** | **v0100** | runtime v0146 | `%s` | **新**(跑共識引擎 · Combined 冊欄序 · 真實年份 · 自測 7 項含引擎離線實跑)|\n"
        "| **VRN2_SSOT_Proposals** | **v0100.json** | runtime v0146 | `%s` | **新**(Gemini 對話 9 條提案 · ssot_id 空白)|\n"
        "| **VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine** | **v0120**(操作員上傳 · 原樣 · 不改一字)| runtime v0146 | `%s` | **借用**(FactSet 鉅亨 + YFinance 共識 · 自帶單元測試 · 需 yfinance;duckdb 可缺)|\n") % (
    R["launcher"]["sha256"][:12], rt["VRN2_Workbench_v0102.py"], rt["VRN2_UIAction_v0109.py"], rt["VRN2_SSOTSync_v0101.py"], rt["VRN2_HistoryAlign_v0100.py"], rt["VRN2_DataIntegrate_v0100.py"], rt["VRN2_ConsensusJoin_v0100.py"], rt["VRN2_SSOT_Proposals_v0100.json"], rt["VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py"])
src = src.replace(anchor, rows + anchor, 1)
once("## 7. 本輪(v0144 → v0145 · 桌機 2026-10-29 08:14 貼回)",
     "## 7. 本輪(v0145 → v0146 · 桌機 2026-10-29 10:25 貼回 + 操作員 U/I 與資料需求)\n\n| # | 操作員 | 追到的根因 / 判讀 | v0146 做法 | 實測 |\n|---|---|---|---|---|\n"
     "| 1 | 字體爆出格子不會自動調整? | 統計磚 `.stat b` 固定 24px、格子 nowrap | clamp + 逐 px 縮(最小 12px)· 不夠就換行;td 靠上 + overflow-wrap | Chromium:鎖定版本磚縮到 12px / 換行 · 0 溢出 |\n"
     "| 2 | 表頭空格 · 靠上 · 百萬台幣千分位(每股 / 倍數例外) | v0101 原欄名 + 原值 | 雙語表頭表 HDR · cell() 依 ITEM / TABLE 判單位(bn ×1000 · thousand ÷1000 · 沒標視為百萬)· 每股 / 倍數 / %% 原值 · title 看原值 | Chromium:`Revenue (NT$ bn) 2,894.3 → 2,894,300` · EPS 45.25 · ROE 28.9%% · P/E 18.2x |\n"
     "| 3 | 左邊 Gate 要一格輸出檔案夾(Parquet 長線庫) | 輸出位置只在 03 匯出頁 | 左欄「輸出檔案夾 · 長線資料庫」:目前夾 · 增量庫引擎 / 累計 · 開啟 / 換 / 取消 · 整合提示 | 沙盒:OneDrive 夾 · pyarrow 累計 BasicInfo 14 / FinancialData 4905 |\n"
     "| 4 | 舊資料庫(CSV / Google Sheet)主動提醒整合 · 整合前不刪 · 自適應欄位 · 舊資料放 TEMP | 沒有 | DataIntegrate v0100 + 處理器 v0109 + ⑬c | 自測 15 項(cp950 雜訊列 · Google Sheet 匯出 · xlsx · 去重 / CONFLICT · 原檔 sha 不變 · TEMP 副本)· 沙盒 ⑬c PENDING_USER 1 份 |\n"
     "| 5 | 歷史資料對齊 · 至少一期要對 · 歷史覆蓋預估 · 加減乘除檢驗 · 刪除區 | 沒有 | HistoryAlign v0100 + ⑬b | 自測 14 項;沙盒灰(⑥e 沒抓到市場資料) |\n"
     "| 6 | 右面板第一區 = 輸入去重矩陣 + 目前引擎狀態 | 第一區是統計磚 | 新 `#first` 區塊在統計磚之前 | Chromium:PDF 唯一 13 · 多餘副本 1 · 引擎狀態含 ⑥e / ⑥f / ⑬ / ⑬b / ⑬c |\n"
     "| 7 | 昨天不是可以擷取 TWSE/TPEX/YFINANCE 嗎 現在為何不行 | 昨天跑的是桌機線自己的啟動器(管理器 v0249 有 ⑥e);本套件線沒有 | ⑥e 借共用 MarketFetch(--fetch / --fill) | 自測(假工具 · 燈號);沙盒灰(樹裡沒共用工具) |\n"
     "| 8 | 共識引擎 v0120 → Combined 目標價後接 FactSet / YFinance 中位數 · 2026 ~ 2028 EPS / PER(真實年份)| Combined 冊本線沒有 | ConsensusJoin v0100 + ⑥f(引擎原樣內附) | 引擎離線 fixture 實跑 gate PASS_WITH_WARNINGS · 沙盒 Combined %s 列 · Chromium 25 欄雙語表頭 |\n"
     "| 9 | LOGO 留白更少但不砍字 · 高畫質 180%% · 仍透明無框 | v0101 留白 4%% · 44px | alpha 內容框重裁 1.5%% · LANCZOS ×1.8 · 頁首 100px | 自測 ⑬(角落透明 · 中心紅 · 留白 ≤ 3%%) |\n"
     "| 10 | 2546 秒 | CPU 被佔 87.5%% → 1 路;輸出冊 969 秒 = 第二讀取器回查 10,908 值 | 本輪不動(列待辦) | — |\n\n---\n\n## 7.0i 前一輪(v0144 → v0145 · 桌機 2026-10-29 08:14 貼回)" % cj["combined_rows"])
once("| 0 | **(v0145)** 桌機跑 v0145(本地實測一輪的一行 · `VRN_ROUND_NO_SHIP=1` 只測不推):",
     "| 0 | **(v0146)** 桌機跑 v0146(本地實測一輪的一行 · `VRN_ROUND_NO_SHIP=1` 只測不推):看 ⑥e(共用夾有 MarketFetch v0112 · via_tw_fetch 環境有 yfinance 才綠)· ⑥f(引擎要 yfinance + 網路;`--preflight-only` 可先驗)· ⑬b(⑥e 綠才有歷史)· ⑬c(輸出夾旁有舊 CSV 才問)· Workbench 左欄輸出夾格 / 第一區 / 雙語表頭 / 千分位;貼回 zip 多收 HistoryAlign / Integrate / market / consensus / Combined | 貼回 zip |\n"
     "| 0a | **(v0146)** 金額欄「沒標單位視為百萬」是前端顯示假設(FinancialData 沒有單位欄):真要對,⑬b 對上歷史後 FinancialAligned 的 VALUE_FINAL 才是確定單位;下一輪可把 UNIT_FINAL 併回主冊顯示 | 下一輪 |\n"
     "| 0b | **(v0146)** 輸出冊 969 秒(第二讀取器回查)與 ⑪ 833 秒還沒動;CPU 被別的程序佔時啟動器只能降路數 | 看下一次貼回的階段耗時 |\n"
     "| 0c | **(v0146)** ⑥f 共識引擎的 DuckDB 歷史長表(consensus_history.duckdb)在 `VIA_Reports\\vrn2\\consensus`;⑬ 增量庫還沒把 Combined / FinancialAligned / Deleted 三冊鏡像進 OutputStore(它只收四本冊)| 下一輪 OutputStore v0101 |\n"
     "| 0 | **(v0145)** 桌機跑 v0145(本地實測一輪的一行 · `VRN_ROUND_NO_SHIP=1` 只測不推):")
once("## 10. 執行方式(v0145:貼 `docs/handoff/ai/VRN2_LocalRound_v0100.md` 頂端的一行(logo → ChainShip v0101 補船 → 操作員一鍵 v0106 → VRN-2 一鍵 v0145 → 貼回包);",
     "## 10. 執行方式(v0146:貼 `docs/handoff/ai/VRN2_LocalRound_v0100.md` 頂端的一行(logo → ChainShip v0101 補船 → 操作員一鍵 v0107 → VRN-2 一鍵 v0146 → 貼回包);各關一步 `VIA_VRN2_NO_MARKET / NO_CONSENSUS / NO_HISTORY / NO_INTEGRATE = 1`;擷取 Python `VIA_FETCH_PY`;前一版 v0145:貼 … 操作員一鍵 v0106 → VRN-2 一鍵 v0145 → 貼回包);")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0146)** **顯示換算不改冊**:百萬台幣 / 千分位 / 雙語表頭都在瀏覽器端做(`cell()` / `hdr()`),輸出冊的值與欄名一字不動;匯出 CSV / JSON 仍是原欄名原值。單位判不出就寫「視為百萬」並讓使用者看得到原值。\n"
     "- **(v0146)** **歷史覆蓋要先對上一期**:HistoryAlign 一期都沒對上就不覆蓋(黃),不拿單位猜;被否定的報告值進刪除區帶理由,主冊不改,對齊冊另出。\n"
     "- **(v0146)** **整合絕不刪原檔**:DataIntegrate 只寫新檔;原檔先 sha → 新檔重讀核對 → 才複製到 TEMP;`--move` 也是核對過才搬。掃描後檔案被改(sha 不同)→ 不整合、要重掃。問過使用者「不要」的同內容不再問。\n"
     "- **(v0146)** **借用的工具不進自己的夾改**:共用夾的 MarketFetch 只讀最新號;上傳的共識引擎原樣內附(sha 可核)、包裝在 VRN2_ConsensusJoin;引擎 `--fixture` 離線模式是測試用,正式要 yfinance + 網路。\n"
     "- **(v0146)** **非關鍵步驟不轉紅**:⑥e / ⑥f / ⑬b / ⑬c 只灰 / 黃並寫原因;rc 仍由 ①~⑫ 關鍵步驟決定。\n"
     "- **(v0146)** **薄尾包裝先存本尊**:`_native_x = PRIOR.x` 再 `PRIOR.x = wrapper`(Workbench v0102 的 logo_data_uri 第一版遞迴 992 層就是沒存本尊)。\n"
     "- **(v0146)** 版號:Workbench v0102 · 處理器 v0109 · SSOTSync v0101 · 啟動器 v0146 · 操作員 v0107 · 交接 v0147;桌機線的號(處理器 v0105 / v0107 · 管理器 v0244 ~ v0254 · 交接 v0145)照舊跳過。\n\n")
(REPO / "VRN2_Handover_v0147.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0147 lines", src.count("\n"))
