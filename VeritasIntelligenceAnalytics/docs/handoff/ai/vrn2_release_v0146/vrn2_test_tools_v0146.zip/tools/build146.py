"""v0146 整包重建(冪等):pkg146(runtime 已建)→ release zip/json → 一鍵 v0146 md → 操作員 v0107 md → LocalRound 改指。"""
import base64, hashlib, json, re, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); out, rel, op7 = S / "v146/pkg146", S / "v146/release146", S / "v146/operator107"
rel.mkdir(exist_ok=True); op7.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
NEW8 = ["VRN2_Workbench_v0102.py", "VRN2_UIAction_v0109.py", "VRN2_SSOTSync_v0101.py", "VRN2_HistoryAlign_v0100.py", "VRN2_DataIntegrate_v0100.py", "VRN2_ConsensusJoin_v0100.py", "VRN2_SSOT_Proposals_v0100.json", "VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py"]
rt = json.loads((out / "VRN2_Runtime_v0146.json").read_text(encoding="utf-8")); assert rt["new_members"] == NEW8
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0146.py", "VRN2_Runtime_v0146.zip", "VRN2_Runtime_v0146.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0146 — VRN-2 closeout package (2026-10-29)\n\nEntry: python ActivateVRN-2_v0146.py [--source <folder>] [--no-install] [--no-open]\n"
  "Runtime: VRN2_Runtime_v0146.zip = runtime v0145 (167 members byte-identical) + 8 new members:\n"
  "  VRN2_Workbench_v0102 · VRN2_UIAction_v0109 · VRN2_SSOTSync_v0101 · VRN2_HistoryAlign_v0100 · VRN2_DataIntegrate_v0100 · VRN2_ConsensusJoin_v0100 ·\n"
  "  VRN2_SSOT_Proposals_v0100.json · VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0120.py (operator upload · bundled unchanged)\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0146 (desktop run 2026-10-29 10:25 · v0145 · 2546 s · operator U/I + data requests):\n"
  " - Workbench v0102: bilingual headers (Report Date / 報告日期 …), top-aligned cells, amounts in NT$ millions with thousands separators (per-share / multiples / % keep value),\n"
  "   tiles auto-fit, output-folder slot (long-term Parquet store) above the other-system Gates, first right-panel block = input dedup matrix + engine status, logo 1.5% margin · 180%.\n"
  " - ⑥e market fetch: borrows the shared folder's VRN2_MarketFetch_v* (--fetch / --fill → VIA_Reports/vrn2/market/VRN2_Market_latest.json); GRAY when absent / opted out (VIA_VRN2_NO_MARKET=1).\n"
  " - ⑥f consensus Combined: the bundled fusion engine (FactSet via cnyes + YFinance) → VRN2_Consensus_latest.json → output/VRN2_Combined_latest (TARGET_PRICE → TARGET_PRICE(ADJ) → FactSet / YFinance medians →\n"
  "   <year>_DILUTED_EPS_FACTSET ×3 → <year>_PER_FACTSET ×3 (real years n..n+2) → … → TOPIC & SUMMARY → STATUS). VIA_VRN2_NO_CONSENSUS=1 opts out.\n"
  " - ⑬b history alignment: ≥ 1 period per report must reconcile with MOPS / TWSE history (0.97–1.03 · unit scale auto) → history overrides estimates → FinancialAligned / Deleted books + checks.\n"
  " - ⑬c legacy-database integration scan (CSV / XLSX / Google-Sheet export) → the Workbench asks; apply via vrn2://integrate never deletes originals (copies to TEMP after a verified new Parquet).\n"
  " - SSOT proposals (ticker regex ×3 · ETF suffix classes · Taipei / HK phone · rating codes 0–5 · target-price synonyms · analyst titles · U/I number format) with blank ssot_id → VRN2_NUMBER_REQUEST.\n"
  " - Handler v0109 (vrn2://integrate?scan|apply|dismiss) · receipt VRN2_Closeout_v0146.json (market · consensus · history_align · integrate).\n"
  "Verification: see VRN2_Verification_v0146.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0146.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0146", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0146.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0146/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0146", "date": "2026-10-29",
       "trigger": "桌機 2026-10-29 10:25 實跑 v0145(52 份 · 2546 秒 · CPU 被別的程序佔 87.5% → 1 路;⑬ duckdb 增量綠 · 冪等閘 151 秒並行有效)+ 操作員 U/I 與資料需求:表頭空格(雙語)· 靠上 · 百萬台幣千分位 · 字體自動縮放 · 左欄輸出夾(Parquet 長線庫)· 右欄第一區去重矩陣 + 引擎狀態 · 舊資料庫整合提示 · 歷史對齊覆蓋預估 · 「昨天不是可以擷取 TWSE/TPEX/YFINANCE 資料嗎 現在為何不行」→ 本線沒有 ⑥e(桌機線管理器 v0249 才有)→ v0146 補上;上傳 Consensus 引擎 v0120 → Combined 目標價後接 FactSet / YFinance 中位數與真實年度 EPS / PER;logo 留白 1.5% · 180%",
       "base_package": {"name": "VRN2_Closeout_v0145 (launcher v0145 · runtime v0145)", "retained": "runtime v0145 members byte-identical inside runtime v0146; ActivateVRN-2_v0136.py base unchanged"},
       "supersedes": "v0145 for the closeout entry; VRN-2 one-click v0145; operator one-click v0106 → v0107",
       "design": {"VRN2_Workbench_v0102": "thin tail over v0101: bilingual header map · top-aligned · money cells → NT$ mn + thousands (unit from ITEM / TABLE) · tile auto-fit · output-folder slot · dedup matrix + engine status first · history block · FinancialAligned / Deleted / Combined datasets · logo recrop 1.5% + LANCZOS 180%",
                  "VRN2_UIAction_v0109": "thin tail over v0108: vrn2://integrate?scan|apply|dismiss · --integrate-scan", "VRN2_SSOTSync_v0101": "thin tail over v0100: proposals book → request", "VRN2_HistoryAlign_v0100": "≥1 period reconciliation · scale auto · history overrides · add/sub · mul/div checks · Deleted zone",
                  "VRN2_DataIntegrate_v0100": "scan CSV / XLSX / Google-Sheet export · adaptive column alignment · apply never deletes originals (copy to TEMP after verified write) · dismiss", "VRN2_ConsensusJoin_v0100": "runs the bundled consensus engine (offline fixtures for tests) · Combined book column order per operator list · real years",
                  "ActivateVRN-2_v0146": "⑥e market fetch (borrowed shared MarketFetch) · ⑥f consensus Combined · ⑬b · ⑬c · Workbench v0102 · handler v0109 · SSOTSync v0101 · receipt v0146 · non-critical steps never RED"},
       "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
       "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0146.json inside the package"},
       "tested_in": "Linux container · python 3.13 venv_vrn2 (pyarrow · no duckdb · no yfinance → ⑥e YELLOW · ⑥f via offline fixtures) · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0146.md"},
       "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0146/<files> (no .ps1 · the one-click md is the entry)"},
       "launcher": {"name": "ActivateVRN-2_v0146.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0146.py"]).hexdigest()}, "manager": {"name": "VRN_SystemManager_v0255.py", "sha256": next(f["sha256"] for f in rt["files"] if f["path"] == "VRN_SystemManager_v0255.py")},
       "oneclick": "VRN2_OneClick_v0146.md", "test_tools_zip": "vrn2_test_tools_v0146.zip", "logs_zip": "logs_v0146.zip"}
(rel / "VRN2_Release_v0146.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8"); print("package", want[:12])
# ===== one-click v0146 from v0145 =====
md = (REPO / "vrn2_release_v0145/VRN2_OneClick_v0145.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); old_cs = hashlib.sha256(ps.encode("utf-8")).hexdigest(); assert old_cs in boot
def rep(a, b):
    global ps
    assert ps.count(a) == 1, (ps.count(a), a[:80]); ps = ps.replace(a, b)
def rrep(pat, b):
    global ps
    assert len(re.findall(pat, ps)) == 1, (len(re.findall(pat, ps)), pat[:80]); ps = re.sub(pat, b, ps)
rep("  $Want   = '%s'   # VRN2_Closeout_v0145.zip SHA-256(套件 · 內含啟動器 v0145 + runtime v0145 清單 = v0144 + 管理器 v0255)" % old_want,
    "  $Want   = '%s'   # VRN2_Closeout_v0146.zip SHA-256(套件 · 內含啟動器 v0146 + runtime v0146 清單 = v0145 + Workbench v0102 · 處理器 v0109 · SSOTSync v0101 · HistoryAlign · DataIntegrate · ConsensusJoin · 提案冊 · 共識引擎 v0120)" % want)
rrep(r"\[計\] VRN-2 一鍵 v0145 · ActivateVRN-2 v0145\(套件 · 私有 runtime v0145 = v0144 \+ 管理器 v0255\([^)]*\);處理器 v0108 · OutputStore v0100 · SSOTSync v0100 · Workbench v0101 · ",
     "[計] VRN-2 一鍵 v0146 · ActivateVRN-2 v0146(套件 · 私有 runtime v0146 = v0145 + Workbench v0102(雙語表頭 · 靠上 · 百萬台幣千分位 · 自動縮放 · 輸出夾格 · 去重矩陣 + 引擎狀態)· 處理器 v0109(vrn2://integrate)· SSOTSync v0101(提案冊)· HistoryAlign v0100 · DataIntegrate v0100 · ConsensusJoin v0100 · 共識引擎 v0120;⑥e 市場擷取(借共用 MarketFetch)· ⑥f 共識 Combined · ⑬b 歷史對齊 · ⑬c 舊資料庫整合掃描;管理器 v0255 · OutputStore v0100 · ")
rrep(r"  # ===== VRN-2 一鍵 v0145\(套件 v0145 = 啟動器 v0145 \+ runtime v0145 = v0144 \+ 管理器 v0255;v0145 = 桌機 2026-10-29 08:14 實跑 2422 秒的速度修正:",
     "  # ===== VRN-2 一鍵 v0146(套件 v0146 = 啟動器 v0146 + runtime v0146 = v0145 + 8 個新成員;v0146 = 桌機 2026-10-29 10:25 貼回 2546 秒(CPU 被佔 87.5% → 1 路)+ 操作員 U/I 與資料需求:Workbench v0102 雙語表頭 / 靠上 / 百萬台幣千分位 / 自動縮放 / 左欄輸出夾 / 右欄去重矩陣 + 引擎狀態 / logo 180% · ⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 MarketFetch)· ⑥f 共識 Combined(FactSet / YFinance 中位數 · 真實年度 EPS / PER)· ⑬b 歷史對齊(至少一期對上才覆蓋 · 刪除區)· ⑬c 舊資料庫整合(問使用者 · 原檔不刪)· 非關鍵步驟不轉紅;v0145 = 套件 v0145 = 啟動器 v0145 + runtime v0145 = v0144 + 管理器 v0255 · 桌機 2026-10-29 08:14 實跑 2422 秒的速度修正:")
rep('cl = j(v2 / "VRN2_Closeout_v0145.json") or {}', 'cl = j(v2 / "VRN2_Closeout_v0146.json") or {}')
rep('"%s|⑧b 收尾收據 v0145 · rc %s', '"%s|⑧b 收尾收據 v0146 · rc %s')
rep('"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0145.json(啟動器 v0145 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"', '"YELLOW|⑧b 沒有收尾收據 VRN2_Closeout_v0146.json(啟動器 v0146 沒跑完 · 或單機閘拒跑:看上面 [RED] 單機閘 那行)"')
rep('print("%s|Workbench U/I v0101 · %s"', 'print("%s|Workbench U/I v0102 · %s"')
rep('''ss_ = cl.get("ssot_sync") or {}
if ss_:
    print("%s|⑤b SSOT-ID 核號同步 · %s" % ({"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(ss_.get("lamp"), "YELLOW"), (ss_.get("detail") or "")[:200]))''',
    '''ss_ = cl.get("ssot_sync") or {}
if ss_:
    print("%s|⑤b SSOT-ID 核號同步 · %s" % ({"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(ss_.get("lamp"), "YELLOW"), (ss_.get("detail") or "")[:200]))
for k_, lb_ in (("market", "⑥e 市場擷取(TWSE / TPEX / Yahoo)"), ("consensus", "⑥f 共識合併(FactSet / YFinance → Combined)"), ("history_align", "⑬b 歷史對齊(歷史覆蓋預估 · 刪除區)"), ("integrate", "⑬c 舊資料庫整合掃描")):
    x_ = cl.get(k_) or {}
    if x_:
        print("%s|%s · %s" % ({"GREEN": "GREEN", "YELLOW": "YELLOW", "GRAY": "GRAY"}.get(x_.get("lamp"), "YELLOW"), lb_, (x_.get("detail") or "")[:220]))
    else:
        print("GRAY|%s · 收據沒有這一欄(啟動器不是 v0146)" % lb_)''')
rep('"③ 本機套件不是 v0145,且讀不到', '"③ 本機套件不是 v0146,且讀不到'); rep('"③ 本機已是 v0145 套件(', '"③ 本機已是 v0146 套件(')
rep("($cf.version -eq 'ActivateVRN-2 v0145')", "($cf.version -eq 'ActivateVRN-2 v0146')")
rep(r"($regH -match '[\\/]VRN2_UIAction_v0108\.py$')", r"($regH -match '[\\/]VRN2_UIAction_v0109\.py$')")
for a, b in (("VRN2_Closeout_v0145", "VRN2_Closeout_v0146"), ("vrn2_release_v0145", "vrn2_release_v0146"), ("ActivateVRN-2_v0145", "ActivateVRN-2_v0146"), ("VRN-2 一鍵 v0145", "VRN-2 一鍵 v0146"), ("vrn2_v0145_", "vrn2_v0146_"), ("套件 v0145 就位", "套件 v0146 就位"), ("啟動器 v0145", "啟動器 v0146"), ("VRN2_UIAction_Config.json v0145", "VRN2_UIAction_Config.json v0146"), ("# v0145 發行所在", "# v0146 發行所在"), ("VRN2_Handover_v0146", "VRN2_Handover_v0147"), ("VRN2_Release_v0145", "VRN2_Release_v0146")):
    ps = ps.replace(a, b)
assert ps.count("v0145 = 套件 v0145 = 啟動器 v0146 + runtime v0145") == 1; ps = ps.replace("v0145 = 套件 v0145 = 啟動器 v0146 + runtime v0145", "v0145 = 套件 v0145 = 啟動器 v0145 + runtime v0145")
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0145" in code and "v0145 =" not in code and "= v0145 +" not in code and "runtime v0145" not in code), line[:160]
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(old_cs, cs).replace("vrn2_release_v0145", "vrn2_release_v0146").replace("VRN2_OneClick_v0145.md", "VRN2_OneClick_v0146.md").replace("v0145", "v0146") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = md.replace("```powershell\n" + re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + re.search(r"(?s)```text\n(.*?)\n```", md).group(1) + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + re.search(r"(?s)```bat\n(.*?)\n```", md).group(1) + "\n```", "```bat\n@ONE@\n```")
head = head.replace(old_want, "@WANT@").replace(old_cs, "@CS@").replace(old_cs[:12], "@CS@")
def hrep(a, b):
    global head
    assert head.count(a) == 1, (head.count(a), a[:80]); head = head.replace(a, b)
def hrrep(pat, b):
    global head
    assert len(re.findall(pat, head, flags=re.M)) == 1, (len(re.findall(pat, head, flags=re.M)), pat[:80]); head = re.sub(pat, b, head, flags=re.M)
hrep("# VRN-2 一鍵 v0145(cmd / PowerShell 都能貼 · 套件 v0145 = 啟動器 v0145 + runtime v0145 = v0144 + 管理器 v0255)", "# VRN-2 一鍵 v0146(cmd / PowerShell 都能貼 · 套件 v0146 = 啟動器 v0146 + runtime v0146 = v0145 + Workbench v0102 · 處理器 v0109 · SSOTSync v0101 · HistoryAlign · DataIntegrate · ConsensusJoin · 共識引擎 v0120)")
hrep("v0145 = v0144 入口 + runtime v0145(= runtime v0144 的 166 個成員逐位元保留 + 1 個新檔):",
     "桌機 2026-10-29 10:25 實跑 v0145(52 份 · 2546 秒):CPU 被別的程序佔 87.5% → 啟動器自動降 1 路、優先權不變;冪等閘並行有效(151 秒 · R1 73 / R2 78)、⑬ duckdb 增量綠(新檔 0 / 已知 52);慢在輸出冊 969 秒(第二讀取器回查 10,908 值 · 單路 + OneDrive I/O)。紅燈同前(3014TT POINT_3 · 3 份年度數據缺項 → 要貼回 zip)。操作員問「昨天不是可以擷取 TWSE/TPEX/YFINANCE 資料嗎 現在為何不行」:昨天跑的是桌機線自己的啟動器(管理器 v0249 有 ⑥e MarketFetch);本套件線(管理器 v0243 → v0255)從來沒有這一步 —— v0146 補上。\n\n"
     "v0146 = v0145 入口 + runtime v0146(= runtime v0145 的 167 個成員逐位元保留 + 8 個新檔):\n\n| 元件 | 版本 | 改了什麼 |\n|---|---|---|\n"
     "| Workbench | v0102(v0101 留著)| 表頭雙語(Report Date / 報告日期 · … · Adjusted Target Price / 調整後目標價;不在清單的欄底線 → 空格 · 原欄名在 title)· 內容全部靠上 · 金額欄顯示為**百萬台幣 + 千分位**(依列 ITEM / TABLE 判原單位:bn → ×1000 · thousand → ÷1000 · 沒標視為百萬;每股 / 倍數 / % 原值 · 滑鼠停留看原值)· 統計磚 clamp + 逐 px 自動縮到放得進(不再爆格)· 左欄「輸出檔案夾 · 長線資料庫(Parquet 增量)」在其他系統 Gate 之上 · 右欄第一區 = 輸入去重矩陣 + 目前引擎狀態(含 ⑥e / ⑥f / ⑬ / ⑬b / ⑬c)· 舊資料庫整合提問(整合 / 不要)· 歷史對齊表 · 資料冊多 Combined / FinancialAligned / Deleted · logo 留白 1.5% · LANCZOS 放大 180%(仍透明無框無特效)|\n"
     "| 市場擷取 ⑥e | 借共用夾 `functional modules\\VRN\\VRN2_MarketFetch_v*.py`(桌機線工具 · 只讀 · 最新號)| 跑完 ⑦ 後 `--fetch`(TWSE / TPEX / Yahoo 還原價 · 年度財報)再 `--fill` → `VIA_Reports\\vrn2\\market\\VRN2_Market_latest.json`;共用夾沒有 → 灰;缺 yfinance 等套件 → 黃交 VCGC;`$env:VIA_VRN2_NO_MARKET='1'` 不抓;上限 `$env:VRN2_MARKET_WAIT`(預設 1800 秒)|\n"
     "| 共識合併 ⑥f | VRN2_ConsensusJoin v0100 + 操作員上傳的 VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine v0120(原樣內附)| 代號 = 基本資料冊 TICKER → 引擎抓 FactSet(鉅亨)/ YFinance 共識 → `consensus\\VRN2_Consensus_latest.json` → **Combined 冊** `output\\VRN2_Combined_latest.{json,csv,parquet}`:每份報告一列,欄序 REPORT_DATE · FILENAME · TICKER · YFINANCE_TICKER · BLOOMBERG_TICKER · NAME · BROKER · ANALYST · RATING · TARGET_PRICE · **TARGET_PRICE(ADJ)** · **FACTSET_TARGET_PRICE_MEDIAN** · **YFINANCE_TARGET_PRICE_MEDIAN** · **2026 / 2027 / 2028_DILUTED_EPS_FACTSET** · **2026 / 2027 / 2028_PER_FACTSET**(真實年份 · n = 今年)· CURRENT_PRICE_REPORT · UPSIDE_PCT(ADJ) · ADJ_CLOSE · ADJ_CLOSE_BEFORE_REPORT · TOPIC & SUMMARY · STATUS;缺 yfinance → 黃、欄留空;`$env:VIA_VRN2_NO_CONSENSUS='1'` 不抓 |\n"
     "| 歷史對齊 ⑬b | VRN2_HistoryAlign v0100 | 每份報告:科目同義字 → 年度期間 → 單位倍率自動對(1 / 1000 / 0.001 …)→ **至少一期**(金額 0.97 ~ 1.03 或每股)對上才覆蓋 → 歷史覆蓋預估(VALUE_FINAL / VALUE_SOURCE / RECON_RATIO · 報告值留 VALUE_REPORT)→ 差 > 3% 的報告值進**刪除區** `VRN2_Deleted_latest` → 加減法(毛利 = 營收 − 成本 · 稅後 = 稅前 − 稅)/ 乘除法(毛利率 · 營益率 · 淨利率 · ROE · 營收成長率)檢驗只報不改 → `VRN2_FinancialAligned_latest.{json,csv,parquet}` + 收據 `VRN2_HistoryAlign_latest.json`;沒市場資料 → 灰;一期都沒對上 → 黃不覆蓋 |\n"
     "| 舊資料庫整合 ⑬c | VRN2_DataIntegrate v0100 + 處理器 v0109 | 掃輸出夾及其上一層 / `VIA_Reports\\vrn2\\legacy_in` / `$env:VRN2_INTEGRATE_DIRS` 的 CSV / TSV / XLSX / Parquet / JSON / Google Sheet 匯出 CSV(.gsheet 捷徑只列)→ 自適應欄位對齊(同義字 + 內容型態 · 對不到的欄保留 X_)→ Workbench 問「要不要整合?」→ `vrn2://integrate?apply=1`:新整合檔 `<輸出夾>\\VRN2\\integrated\\VRN2_Integrated_<冊>_<時間>.{json,csv,parquet}`(VRN-2 冊 ∪ 舊檔 · 同鍵同值去重 · 同鍵不同值兩邊都留標 CONFLICT)→ 重讀核對 → **原檔絕不刪**,核對過才複製到 `%TEMP%\\VRN2_Integrate_<時間>\\originals\\` 提醒自行處理;不要 → `dismiss=1`(同內容下次不再問)|\n"
     "| SSOT 提案 | VRN2_SSOT_Proposals v0100 + SSOTSync v0101 | Gemini 對話的 9 條提案(台股代號 TWSE / Yahoo / Bloomberg 三形式 · ETF 尾碼分類 · 台北 / 香港電話 · 評等代碼 0 ~ 5 中英同義字 · 目標價同義字 · 分析師職稱 · U/I 數值格式)`ssot_id` 空白 · `VRN2-PROP-xxxx` → 併進 ⑤b 的核號請求冊,等 VCGC 核發 |\n"
     "| 啟動器 | ActivateVRN-2 v0146 | ⑥e / ⑥f 在 ⑦ 之後、⑬b / ⑬c 在 ⑬ 之後;收據 `VRN2_Closeout_v0146.json` 多 `market` / `consensus` / `history_align` / `integrate`;非關鍵步驟只灰 / 黃、不轉紅;Workbench v0102 · 處理器 v0109 · SSOTSync v0101;v0145 的管理器 v0255 與 v0144 的 ⑤b / ⑬ 照舊 |\n\n"
     "前一版 v0145 = v0144 入口 + runtime v0145(= runtime v0144 的 166 個成員逐位元保留 + 1 個新檔):")
hrep("| 啟動器 | ActivateVRN-2 v0145 | 改指管理器 v0255 · 收據 `VRN2_Closeout_v0145.json`;v0144 的 ⑤b / ⑬ / 處理器 v0108 / Workbench v0101 與 v0143 的單機閘 / 上限 / ⑫b 補放照舊 |",
     "| 啟動器(v0145)| ActivateVRN-2 v0145 | 改指管理器 v0255 · 收據 `VRN2_Closeout_v0145.json`;v0144 的 ⑤b / ⑬ / 處理器 v0108 / Workbench v0101 與 v0143 的單機閘 / 上限 / ⑫b 補放照舊 |")
hrep("| 步驟 | v0145 做什麼 |", "| 步驟 | v0146 做什麼 |")
hrep("| ① ② ③ ③b | 同 v0144(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|", "| ① ② ③ ③b | 同 v0145(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|")
hrrep(r"^\| ④ \| `python ActivateVRN-2_v0145\.py \[--source …\]`:.*$", "| ④ | `python ActivateVRN-2_v0146.py [--source …]`:單機閘 → ①~⑤ → ⑤b SSOT-ID 核號同步(含提案冊)→ ⑥ → ⑦(管理器 v0255)→ **⑥e 市場擷取 → ⑥f 共識合併(Combined 冊)** → ⑧~⑫ → ⑫b 補放 → 四點原文核對 → 收據 → ⑬ 輸出位置 · 增量庫 → **⑬b 歷史對齊 → ⑬c 舊資料庫整合掃描** → Workbench v0102 渲染 + 開啟 |")
hrrep(r"^\| ⑤ \| 摘要多三行:.*$", "| ⑤ | 摘要多七行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID · 階段耗時 · **⑥e 市場擷取 · ⑥f 共識合併 · ⑬b 歷史對齊 · ⑬c 舊資料庫整合**(都讀 `VRN2_Closeout_v0146.json`)|")
_ls = head.split("\n"); _i = [i for i, l in enumerate(_ls) if l.startswith("| ⑤b ⑤c |")]; assert len(_i) == 1, _i; _ls[_i[0]] = "| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\\\VRN2\\\\VRN2_UIAction_v0109.py`(設定檔 v0146 · 多 `vrn2://integrate`)· U/I 有輸入區塊 · 沒開就代開 |"; head = "\n".join(_ls)
hrep("開關:`$env:VRN2_SOURCE` 來源夾", "開關:`$env:VIA_VRN2_NO_MARKET` / `VIA_VRN2_NO_CONSENSUS` / `VIA_VRN2_NO_HISTORY` / `VIA_VRN2_NO_INTEGRATE` 各關一步 · `$env:VRN2_MARKET_WAIT` / `VRN2_CONSENSUS_WAIT` 上限 · `$env:VIA_FETCH_PY` 擷取用的 Python(預設 `%USERPROFILE%\\envs\\via_tw_fetch`)· `$env:VRN2_INTEGRATE_DIRS` 多掃的夾 · `$env:VRN2_SOURCE` 來源夾")
hrep("VRN-2 主體(ENG397 · 摘要器 · 驗證器 · 工具橋 · OCR 橋)與 runtime v0144 的 166 個成員一個位元組都不動(管理器 v0243 留著,v0255 疊在上面);", "VRN-2 主體(ENG397 · 摘要器 · 驗證器 · 工具橋 · OCR 橋 · 管理器 v0255)與 runtime v0145 的 167 個成員一個位元組都不動(v0101 / v0108 / v0100 留著,薄尾疊在上面;基本資料 / 年度數據 / 摘要三冊不改,Combined / FinancialAligned / Deleted 是新冊);共用夾的 MarketFetch 與上傳的共識引擎只借用不改;")
for a, b in (("VRN2_OneClick_v0145", "VRN2_OneClick_v0146"), ("vrn2_release_v0145", "vrn2_release_v0146"), ("VRN2_Closeout_v0145.zip", "VRN2_Closeout_v0146.zip"), ("Downloads\\VRN2_Closeout_v0145", "Downloads\\VRN2_Closeout_v0146")):
    head = head.replace(a, b)
(S / "v146/oneclick146_head.md").write_text(head, encoding="utf-8", newline="\n")
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and "@" + "WANT@" not in newmd
(rel / "VRN2_OneClick_v0146.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot146.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline146.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0146.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0146", cs[:12])
# ===== operator v0107 from v0106 =====
md6 = (REPO / "vrn1_vrn2_oneclick_v0106/VRN1_VRN2_OneClick_v0106.md").read_text(encoding="utf-8")
ps6 = re.search(r"(?s)```powershell\n(.*?)\n```", md6).group(1); boot6 = re.search(r"(?s)```text\n(.*?)\n```", md6).group(1); one6 = re.search(r"(?s)```bat\n(.*?)\n```", md6).group(1)
p7 = ps6
def rep7(a, b):
    global p7
    assert p7.count(a) == 1, (p7.count(a), a[:80]); p7 = p7.replace(a, b)
rep7("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0145'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0146'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0145 程式碼 SHA-256", p7).group(1); assert old_h2 == old_cs
rep7("  $H2 = '%s'   # VRN-2 一鍵 v0145 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0146 程式碼 SHA-256" % cs)
rep7("  # ===== VRN-1 / VRN-2 操作員一鍵 v0106(2026-10-29 · ② 改指 VRN-2 一鍵 v0145:管理器 v0255 冪等閘並行 · 心跳 · 階段計時;v0105 · ② 改指 VRN-2 一鍵 v0144:",
     "  # ===== VRN-1 / VRN-2 操作員一鍵 v0107(2026-10-29 · ② 改指 VRN-2 一鍵 v0146:Workbench v0102 · ⑥e 市場擷取 · ⑥f 共識 Combined · ⑬b 歷史對齊 · ⑬c 舊資料庫整合;v0106 · ② 改指 VRN-2 一鍵 v0145:管理器 v0255 冪等閘並行 · 心跳 · 階段計時;v0105 · ② 改指 VRN-2 一鍵 v0144:")
rep7("操作員一鍵 v0106 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0107 · {0} · VRN-1 {1} · VIA {2}")
p7 = p7.replace("VRN2_OneClick_v0145.md", "VRN2_OneClick_v0146.md").replace("VRN-2 一鍵 v0145", "VRN-2 一鍵 v0146").replace("套件 v0145 = 啟動器 v0145 + runtime v0145", "套件 v0146 = 啟動器 v0146 + runtime v0146").replace("ActivateVRN-2_v0145 單機閘", "ActivateVRN-2_v0146 單機閘")
assert p7.count("v0106 · ② 改指 VRN-2 一鍵 v0146:管理器 v0255") == 1; p7 = p7.replace("v0106 · ② 改指 VRN-2 一鍵 v0146:管理器 v0255", "v0106 · ② 改指 VRN-2 一鍵 v0145:管理器 v0255")
for line in p7.splitlines():
    code = line.split("#", 1)[0]; assert "v0145" not in code or "v0145:" in code, line[:160]
cs7 = hashlib.sha256(p7.encode("utf-8")).hexdigest()
boot7 = boot6.replace(re.search(r"\$H  = '([0-9a-f]{64})'", boot6).group(1), cs7).replace("vrn1_vrn2_oneclick_v0106", "vrn1_vrn2_oneclick_v0107").replace("VRN1_VRN2_OneClick_v0106.md", "VRN1_VRN2_OneClick_v0107.md").replace("操作員一鍵 v0106", "操作員一鍵 v0107") + "\n"
one7 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot7.encode("utf-16-le")).decode("ascii")
text = md6.replace("```powershell\n" + ps6 + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + boot6 + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + one6 + "\n```", "```bat\n@ONE@\n```")
old_cs6 = hashlib.sha256(ps6.encode("utf-8")).hexdigest()
text = text.replace(old_cs6, cs7).replace(old_cs6[:12], cs7[:12]).replace(old_h2, cs).replace(old_h2[:12], cs[:12]).replace("v0106", "v0107").replace("VRN-2 一鍵 v0145", "VRN-2 一鍵 v0146").replace("vrn2_release_v0145", "vrn2_release_v0146").replace("VRN2_OneClick_v0145", "VRN2_OneClick_v0146")
head_old = text.split("\n", 1)[0]; text = text.replace(head_old, "# VRN-1 / VRN-2 操作員一鍵 v0107(cmd / PowerShell 都能貼 · v0106 + ② 改指 VRN-2 一鍵 v0146:Workbench v0102 · ⑥e 市場擷取 · ⑥f 共識 Combined · ⑬b 歷史對齊 · ⑬c 舊資料庫整合)", 1)
intro_old = text.split("\n\n", 2)[1]; text = text.replace(intro_old, "桌機 2026-10-29 10:25 實跑 v0145(52 份 · 2546 秒 · CPU 被佔 87.5% → 1 路;冪等閘並行有效 · ⑬ duckdb 綠)+ 操作員 U/I 與資料需求。v0107 = v0106 + ② 改指 **VRN-2 一鍵 v0146**(套件 v0146 = 啟動器 v0146 + runtime v0146 = v0145 + Workbench v0102 · 處理器 v0109 · SSOTSync v0101 · HistoryAlign · DataIntegrate · ConsensusJoin · 共識引擎 v0120);其餘一字不改。\n\n" + intro_old, 1)
text = text.replace("@PS@", p7).replace("@BOOT@", boot7.rstrip("\n")).replace("@ONE@", one7)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p7 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot7
(op7 / "VRN1_VRN2_OneClick_v0107.md").write_text(text, encoding="utf-8", newline="\n"); (op7 / "boot_pair107.ps1").write_text(boot7, encoding="utf-8", newline="\n"); (op7 / "oneline_pair107.txt").write_text(one7 + "\n", encoding="utf-8"); (op7 / "Run-VRN1-VRN2-v0107.ps1").write_text(p7 + "\n", encoding="utf-8", newline="\n"); (op7 / "code_sha.txt").write_text(cs7)
print("operator v0107", cs7[:12])
# ===== LocalRound re-point =====
lr = REPO / "VRN2_LocalRound_v0100.md"; s = lr.read_text(encoding="utf-8")
if "VRN1_VRN2_OneClick_v0107.md" in s:
    s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0107 程式碼 SHA-256", "$H_OP = '%s'   # 操作員一鍵 v0107 程式碼 SHA-256" % cs7, s, count=1); assert cs7 in s
    lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP refreshed", cs7[:12]); raise SystemExit(0)
def lrep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)
lrep("# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0145(開 Workbench)→ 打包貼回材料)", "# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0146(開 Workbench)→ 打包貼回材料)")
lrep("> **2026-10-29 v0145 改指(桌機 08:14 實跑 v0144 貼回:", "> **2026-10-29 v0146 改指(桌機 10:25 實跑 v0145 貼回:2546 秒 · CPU 被佔 87.5% → 1 路 · 冪等閘並行有效 · ⑬ duckdb 綠;操作員 U/I 與資料需求 + 上傳共識引擎 v0120):** 本段現在指 操作員一鍵 **v0107** → VRN-2 一鍵 **v0146**(Workbench v0102:雙語表頭 · 靠上 · 百萬台幣千分位 · 自動縮放 · 左欄輸出夾 · 右欄去重矩陣 + 引擎狀態 · logo 180%;⑥e 市場擷取(借共用 MarketFetch)· ⑥f 共識 Combined(FactSet / YFinance 中位數 · 真實年度 EPS / PER)· ⑬b 歷史對齊 · ⑬c 舊資料庫整合;其餘同 v0145)。④ 貼回包多收 `VRN2_HistoryAlign_latest.json` · `VRN2_Integrate_latest.json` · `market\\VRN2_Market_latest.json` · `consensus\\VRN2_Consensus_latest.json` · `output\\VRN2_Combined_latest.csv`。\n> **2026-10-29 v0145 改指(桌機 08:14 實跑 v0144 貼回:")
lrep("本段現在指 操作員一鍵 **v0106** → VRN-2 一鍵 **v0145**(管理器 v0255:", "本段當時指 操作員一鍵 **v0106** → VRN-2 一鍵 **v0145**(管理器 v0255:")
lrep("| ③ 跑 | 從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0106.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0145 套件**(啟動器 v0145 → 管理器 v0255:冪等閘每波 3 份並行 · 30 秒心跳 · 階段計時;",
     "| ③ 跑 | 從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0107.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0146 套件**(啟動器 v0146 → Workbench v0102 · ⑥e 市場擷取 · ⑥f 共識 Combined · ⑬b 歷史對齊 · ⑬c 舊資料庫整合;v0145 的管理器 v0255:冪等閘每波 3 份並行 · 30 秒心跳 · 階段計時;")
lrep("最後 300 行貼包 · `VRN2_Closeout_v0145.json` · `VRN2_Phase_Timing_latest.json` · `VRN2_OutputStore_latest.json` · `IDEMPOTENCE_latest.json`", "最後 300 行貼包 · `VRN2_Closeout_v0146.json` · `VRN2_HistoryAlign_latest.json` · `VRN2_Integrate_latest.json` · `market\\VRN2_Market_latest.json` · `consensus\\VRN2_Consensus_latest.json` · `VRN2_Phase_Timing_latest.json` · `VRN2_OutputStore_latest.json` · `IDEMPOTENCE_latest.json`")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0106 程式碼 SHA-256\(VRN1_VRN2_OneClick_v0106\.md powershell 區塊 · ② 指 VRN-2 一鍵 v0145\)", "$H_OP = '%s'   # 操作員一鍵 v0107 程式碼 SHA-256(VRN1_VRN2_OneClick_v0107.md powershell 區塊 · ② 指 VRN-2 一鍵 v0146)" % cs7, s, count=1); assert cs7 in s
lrep("  $k3 = '③ 跑 VRN-2 v0145'", "  $k3 = '③ 跑 VRN-2 v0146'")
lrep("  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0106' 'VRN1_VRN2_OneClick_v0106.md' $H_OP", "  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0107' 'VRN1_VRN2_OneClick_v0107.md' $H_OP")
lrep("  foreach ($rel in 'VRN2_Closeout_v0145.json', 'VRN2_Phase_Timing_latest.json',", "  foreach ($rel in 'VRN2_Closeout_v0146.json', 'VRN2_HistoryAlign_latest.json', 'VRN2_Integrate_latest.json', 'market\\VRN2_Market_latest.json', 'consensus\\VRN2_Consensus_latest.json', 'output\\VRN2_Combined_latest.csv', 'VRN2_Phase_Timing_latest.json',")
lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP", cs7[:12])
