const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const pg = await b.newPage({viewport:{width:1200,height:800}});
  const errs = []; pg.on('pageerror', e => errs.push(String(e))); pg.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
  await pg.goto('file://' + process.argv[2]); await pg.waitForTimeout(500);
  const first = await pg.$eval('#first h2', e => e.textContent);
  await pg.click('[data-tab="data"]'); await pg.click('[data-ds="FinancialData"]'); await pg.waitForTimeout(200);
  const ths = await pg.$$eval('#dsHead th', l => l.map(e => e.textContent));
  const rows = await pg.$$eval('#dsBody tr', l => l.slice(0,5).map(tr => Array.from(tr.querySelectorAll('td')).map(td => td.textContent + '|' + (td.getAttribute('title')||''))));
  const va = await pg.$$eval('#dsBody td', l => [...new Set(l.map(e => getComputedStyle(e).verticalAlign))]);
  const stat = await pg.$$eval('.stat b', l => l.map(e => [e.textContent, e.style.fontSize, e.scrollWidth <= e.clientWidth + 1]));
  console.log(JSON.stringify({errs, first, ths, rows, va, stat}, null, 1));
  await pg.screenshot({path: process.argv[3], fullPage: false});
  await b.close();
})();
