"""收尾 v0146:results → VRN2_Release_v0146.json.results · VRN2_Verification_v0146.md(套件 zip 已定,不重算)。"""
import json, re
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v146")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def grep(path, pat, last=True, all_=False):
    try: hits = [l for l in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if re.search(pat, l) and "<Objs" not in l and "</S>" not in l and "<S N=" not in l and "</U32>" not in l]
    except OSError: return [] if all_ else ""
    if all_: return hits
    return (hits[-1] if last else hits[0]) if hits else ""
def esc(x): return str(x).replace("|", "\\|")
o = W / "t146/VIA/VIA_Reports/vrn2"
cl = j(o / "VRN2_Closeout_v0146.json", {}); idem = j(o / "IDEMPOTENCE_latest.json", {}); comp = j(o / "VRN2_Completion_latest.json", {}); pt = j(o / "VRN2_Phase_Timing_latest.json", {})
cons = j(o / "consensus/VRN2_Consensus_latest.json", {}); integ = j(o / "VRN2_Integrate_latest.json", {}); hist = j(o / "VRN2_HistoryAlign_latest.json", {})
combined = j(o / "output/VRN2_Combined_latest.json", [])
log = W / "full146.log"
line7 = grep(log, r"⑦ 啟動 VRN-2 · \[計\] VRN-2 個股四項"); m7 = re.search(r"個股四項 · (\d+) 份\(全綠 (\d+)\)", line7); m7t = re.search(r"耗時 (\d+) 秒", line7)
line11 = grep(log, r"⑪ 獨立驗證\(背景 · 只讀\) ·"); m11 = re.search(r"基本資料 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 一標題四重點 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 年度數據 (\d+) 筆 · (\{[^}]*\})", line11)
st = cl.get("output_store") or {}; ss = cl.get("ssot_sync") or {}; wb = cl.get("workbench") or {}; mk = cl.get("market") or {}; cj = cl.get("consensus") or {}; ha = cl.get("history_align") or {}; ig = cl.get("integrate") or {}
non_green = [(s.get("step"), s.get("lamp")) for s in cl.get("steps", []) if s.get("lamp") != "GREEN"]
ui = j(W / "uitest/ui146.json", {})
selft = {n: grep(W / (n + "_selftest.log"), r"\[PASS\] .*--selftest · \d+ 項 · 不過 0").strip()[:160] for n in ("VRN2_Workbench_v0102", "VRN2_HistoryAlign_v0100", "VRN2_DataIntegrate_v0100", "VRN2_UIAction_v0109", "VRN2_SSOTSync_v0101", "VRN2_ConsensusJoin_v0100")}
selft["ActivateVRN-2_v0146"] = grep(W / "ActivateVRN-2_v0146_selftest.log", r"\[PASS\] v0146").strip()[:300]
scen_rc = (W / "scen146.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen146.rc").exists() else "not run"
scen_first = grep(W / "scen146_first.log", r"③ 套件 v0146 就位|③ 本機已是 v0146"); scen_again = grep(W / "scen146_again.log", r"③ 本機已是 v0146|③ 套件 v0146 就位")
scen_tamper = (grep(W / "scen146_tamper.log", r"③ 本機套件夾有 \d+ 個檔與已驗證的 zip 不同").strip()[:160] + " → " + grep(W / "scen146_tamper.log", r"③ 舊套件夾已改名備份").strip()[:120])
scen_lines = {k: grep(W / "scen146_first.log", p).strip()[:260] for k, p in (("closeout", r"⑧b 收尾收據 v0146"), ("market", r"⑥e 市場擷取"), ("consensus", r"⑥f 共識合併"), ("history", r"⑬b 歷史對齊"), ("integrate", r"⑬c 舊資料庫整合"), ("workbench", r"Workbench U/I v0102"), ("registration", r"註冊核對 ·"))}
R = {"selftests": selft, "pwsh_hash_chain": [l for l in (W / "pscheck146.log").read_text(encoding="utf-8").splitlines() if l.strip()],
     "full_run_v0146_19_real": {"closeout_rc": cl.get("rc"), "rc_reason": "③ 環境檢查 RED in the Linux sandbox only (accelerator deps not in venv; --no-install); same as v0142–v0145", "non_green_steps": non_green, "elapsed_s": cl.get("elapsed_s"),
        "passes": [(p.get("attempt"), p.get("rc"), p.get("idempotence")) for p in cl.get("passes", [])], "completion": {"verdict": comp.get("verdict"), "red": comp.get("red"), "yellow": comp.get("yellow"), "manager": comp.get("manager")},
        "stock_reports": {"n": int(m7.group(1)) if m7 else None, "all_green": int(m7.group(2)) if m7 else None, "step7_seconds": int(m7t.group(1)) if m7t else None}, "idempotence": idem.get("classification"), "idempotence_timing": idem.get("timing"),
        "phase_timing": pt, "phase_summary_line": grep(log, r"\[計\] 階段耗時").strip()[:300],
        "source_quotes": (cl.get("source_quotes") or {}).get("counts"), "output_gaps": cl.get("output_gaps"),
        "independent_verifier": {"basic": m11.group(2) if m11 else "", "summary": m11.group(4) if m11 else "", "financial_rows": int(m11.group(5)) if m11 else None, "financial_verdicts": m11.group(6) if m11 else ""},
        "registration_line": grep(log, r"註冊核對 ·").strip()[:200],
        "ssot_sync": {"lamp": ss.get("lamp"), "detail": ss.get("detail")}, "output_store": {"lamp": st.get("lamp"), "store_engine": st.get("store_engine"), "new_files": len(st.get("new_files") or []), "appended": st.get("appended")},
        "market_6e": {"lamp": mk.get("lamp"), "detail": mk.get("detail")},
        "consensus_6f": {"lamp": cj.get("lamp"), "detail": cj.get("detail"), "codes": len(cons.get("codes") or []), "codes_got": len(cons.get("codes_got") or []), "gate": cons.get("gate"), "engine": Path(str(cons.get("engine") or "")).name, "combined_rows": len(combined), "combined_columns": list(combined[0].keys()) if combined else [], "sample_row": {k: combined[0].get(k) for k in list(combined[0].keys())[:19]} if combined else {}},
        "history_13b": {"lamp": ha.get("lamp"), "detail": ha.get("detail")},
        "integrate_13c": {"lamp": ig.get("lamp"), "state": ig.get("state"), "candidates": [{"path": Path(str(c.get("path"))).name, "kind": c.get("kind"), "target_book": c.get("target_book"), "mapping": c.get("mapping")} for c in (integ.get("candidates") or [])]},
        "workbench": {"lamp": wb.get("lamp"), "version": wb.get("version"), "legacy_linked": wb.get("legacy_linked")},
        "workbench_chromium": {k: ui.get(k) for k in ("errs", "ths", "fths", "ds", "stat", "logo", "first_head", "outf_head") if k in ui}},
     "oneclick_scenario_pwsh": {"rc": scen_rc, "first": scen_first.strip()[:200], "again": scen_again.strip()[:200], "tamper": scen_tamper, **scen_lines},
     "desktop_v0145_2026_10_29_1025": {"total_s": 2546, "launcher_s": 2525, "cpu": "87.5% busy by another process at launch → launcher chose 平行 1 路 · 優先權 不變", "step7_s": "≈1180 (擷取 13 · 驗收+摘要 9 · 輸出冊 969 · 冪等閘 151 (R1 73 / R2 78 · parallel works))",
        "step11_s": 833, "step4_s": "93 + 107 (④ / ④b)", "store": "⑬ duckdb GREEN · 新檔 0 / 已知 52 (incremental proven)", "ui": "⑥c · ⑤b · ⑫b · Workbench v0101 GREEN · 驗證判決寫回",
        "red": "same as 08:14: ⑧b rc 1 ← 四點原文核對 FAIL 1 (3014TT-20231005 POINT_3) · 輸出缺項 3 份年度數據 (Daiwa-6278 · 欣銓 3264 · 華南 6143) → needs VRN2_PasteBack_20261029_102505.zip",
        "diagnosis": "the 969 s 輸出冊 is the native second-reader value verification (10,908 values across 52 PDFs) under CPU starvation (1 lane) + OneDrive I/O; not the idempotence gate any more (151 s). 'Why no TWSE/TPEX/YFinance?': the desktop line's own launcher (manager v0249) has ⑥e; this package line never had it → v0146 adds ⑥e / ⑥f."},
     "not_claimed": ["Windows desktop run of v0146: not yet (next paste-back)", "the launcher's ④ accelerator step writes a bridge copy VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0121.py (= the uploaded v0120 + the [VIA:ACCEL-BRIDGE] header, same as every unbridged runtime member) into the private runtime at run time; ConsensusJoin then takes the highest number, so ⑥f ran the v0121 bridge copy — the shipped v0120 is byte-identical to the upload (sha b50b3ba6f06c8b14…)", "⑥e in the container: GRAY (the sandbox VIA tree has no shared VRN2_MarketFetch; on the desktop the shared folder has v0112) and the container has no yfinance / network → ⑥e YELLOW there is the honest expectation until the via_tw_fetch env exists",
                     "⑥f live mode (cnyes + Yahoo) not exercised: the container run used offline engine fixtures for the 13 tickers (consensus values are synthetic); the engine's own live path is the operator's v0120 as uploaded", "⑬b history alignment ran GRAY in the sandbox (no market json); its 14 selftest cases cover scale / override / Deleted / checks",
                     "⑬c apply (vrn2://integrate) was exercised by the handler selftest, not from a browser click", "3014TT POINT_3 FAIL and the 3 missing annual-data books: still need the paste-back zip", "the 969 s 輸出冊 verification phase is not changed this round (would need the manager's second reader to parallelise)"]}
rel_p = W / "release146/VRN2_Release_v0146.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
rr = R["full_run_v0146_19_real"]; sc = R["oneclick_scenario_pwsh"]; dk = R["desktop_v0145_2026_10_29_1025"]
md = ["# VRN-2 v0146 容器實測紀錄(2026-10-29)", "",
      "桌機 10:25 貼回(v0145 · 2546 秒):%s;⑦ %s;⑪ %s 秒;④ %s;%s;%s。紅燈:%s。判讀:%s" % (dk["cpu"], dk["step7_s"], dk["step11_s"], dk["step4_s"], dk["store"], dk["ui"], dk["red"], dk["diagnosis"]), "",
      "## 1. 自測", "", "| 檔 | 結果 |", "|---|---|"] + ["| %s | %s |" % (k, esc(v) or "(沒有 PASS 行)") for k, v in selft.items()] + ["",
      "## 2. PowerShell 雜湊鏈(pwsh 7.4.6)", "", "```", *R["pwsh_hash_chain"], "```", "",
      "## 3. 沙盒整輪(套件 v0146 · 19 份真實樣本 · Linux · 無網路 · 共識引擎走離線 fixture)", "",
      "| 項目 | 值 |", "|---|---|",
      "| 收尾 rc | %s(%s)|" % (rr["closeout_rc"], esc(rr["rc_reason"])), "| 非綠步驟 | %s |" % esc(rr["non_green_steps"]), "| 耗時 | %s 秒 |" % rr["elapsed_s"],
      "| 完成判定 | %s |" % esc(rr["completion"]), "| 個股四項 | %s |" % esc(rr["stock_reports"]), "| 冪等閘 | %s · %s |" % (rr["idempotence"], esc(rr["idempotence_timing"])), "| 階段耗時 | %s |" % esc(rr["phase_summary_line"]),
      "| 四點原文核對 | %s |" % esc(rr["source_quotes"]), "| 獨立驗證 | %s |" % esc(rr["independent_verifier"]), "| 註冊核對 | %s |" % esc(rr["registration_line"]),
      "| ⑤b SSOT-ID | %s |" % esc(rr["ssot_sync"]), "| ⑥e 市場擷取 | %s |" % esc(rr["market_6e"]), "| ⑥f 共識合併 | %s · 代號 %s / %s · gate %s · 引擎 %s · Combined %s 列 |" % (rr["consensus_6f"]["lamp"], rr["consensus_6f"]["codes_got"], rr["consensus_6f"]["codes"], rr["consensus_6f"]["gate"], rr["consensus_6f"]["engine"], rr["consensus_6f"]["combined_rows"]),
      "| Combined 欄序 | %s |" % esc(" · ".join(rr["consensus_6f"]["combined_columns"])), "| Combined 第一列(前 19 欄)| %s |" % esc(json.dumps(rr["consensus_6f"]["sample_row"], ensure_ascii=False)),
      "| ⑬ 輸出位置 / 增量庫 | %s |" % esc(rr["output_store"]), "| ⑬b 歷史對齊 | %s |" % esc(rr["history_13b"]), "| ⑬c 舊資料庫整合 | %s |" % esc(rr["integrate_13c"]), "| Workbench | %s |" % esc(rr["workbench"]),
      "| Workbench(無頭 Chromium)| %s |" % esc(json.dumps(rr["workbench_chromium"], ensure_ascii=False)[:1500]), "",
      "## 4. 使用者情境(pwsh · 一鍵 v0146 從假 GitHub 分支取套件 → 跑 → 再貼 → 竄改)", "", "| 項目 | 值 |", "|---|---|"] + ["| %s | %s |" % (k, esc(v)) for k, v in sc.items()] + ["",
      "## 5. 沒做到 / 沒驗到(照實)", ""] + ["- %s" % x for x in R["not_claimed"]]
(W / "release146/VRN2_Verification_v0146.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
print("finalize146 ok · rc", rr["closeout_rc"], "· ⑥f", rr["consensus_6f"]["lamp"], "· scen", scen_rc)
