#!/bin/bash
# v0159 最短一行 e2e(小沙盒):沙盒 GitHub 分支(v0158 套件 + v0159 發行檔)· pwsh 7.4.6 · report / repair / tamper · 同意閘不設
W=/home/user/vrn2_work/v159; T=$W/sbx; S2=<scratch>
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai; PY=$(command -v python3)
rm -rf "${T:?}"; mkdir -p $T/home/OneDrive/Documents $T/home/Downloads $T/tmp $T/VIA/VIA_Reports/vrn2 "$T/VIA/functional modules/VRN2"
git init -q -b work $T/VIA && git init -q --bare $T/remote.git && git -C $T/VIA remote add origin $T/remote.git
ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset
B=$T/br; mkdir -p $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158 $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0159
cp $REPO/vrn2_release_v0158/VRN2_Closeout_v0158.zip $REPO/vrn2_release_v0158/VRN2_Release_v0158.json $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158/
cp $W/release159/VRN2_RoundAll_v0115.py $W/release159/VRN2_RoundAll_v0115.md $W/release159/VRN2_HandleAll_v0107.md $W/release159/VRN2_HandleAll_v0107_boot.txt $W/release159/VRN2_Release_v0159.json $B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0159/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release159/tiny_line.txt)
run() { N=$1; shift; cd "$T/home" && env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 \
  VRN2_ROOT="$T/VIA" VRN2_PY="$PY" VRN2_ROUNDALL_ARGS="--python $PY --no-open" "$@" timeout 900 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny159.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; }
rm -f $W/tiny159.rc; run report VRN2_MODE=report; run repair VRN2_MODE=repair
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0159/VRN2_HandleAll_v0107_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny159.rc
