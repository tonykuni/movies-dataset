"""v0159(小輪 · 冪等):RoundAll v0115(套件 v0158 不動)→ Handle-All v0107 → 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單。vrn2_release_v0158 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v159"); rel = W / "release159"; rel.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402
r158 = json.loads((REPO / "vrn2_release_v0158/VRN2_Release_v0158.json").read_text(encoding="utf-8"))
want = r158["package"]["sha256"]
assert hashlib.sha256((REPO / "vrn2_release_v0158/VRN2_Closeout_v0158.zip").read_bytes()).hexdigest() == want
ra = (W / "new/VRN2_RoundAll_v0115.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra
(rel / "VRN2_RoundAll_v0115.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ha = (W / "ps7/handleall_v0106_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)
for a, b in (("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0159'"),
             ("$F = 'VRN2_RoundAll_v0114.py'", "$F = 'VRN2_RoundAll_v0115.py'"), ("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha),
             ("Handle-All v0106 · PowerShell", "Handle-All v0107 · PowerShell")):
    assert ha.count(a) == 1, a
    ha = ha.replace(a, b)
assert "exit" not in ha.replace("Exception", "")
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (W / "ps7/boot_v0106_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0158", "vrn2_release_v0159"), ("VRN2_HandleAll_v0106.md", "VRN2_HandleAll_v0107.md"), ("Handle-All v0106 SHA-256 OK", "Handle-All v0107 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0107_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(bt_line.encode("utf-16-le")).decode("ascii"); assert len(cmd_line) < 8191
(rel / "boot_cmd.txt").write_text(cmd_line + "\n", encoding="utf-8")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0159/VRN2_HandleAll_v0107_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
md = """# VRN-2 · PowerShell 7 一行處理全部 · VRN2_HandleAll_v0107(2026-10-31 · 套件 v0158 不動 · RoundAll v0115)

v0107 = v0106 + RoundAll **v0115**:⑥e / ⑥f 用同一個擷取 Python。桌機 05:30 那輪(經 VIA 網路工具真抓共識成功)⑥e 用 `C:\\Python313`(合 VDF 版本界線),
⑥f 卻用 `envs\\via_core_312`(只看套件匯得進來 · 舊 pandas)→ 引擎 `Raw Parquet: WARN_PARQUET_ENGINE_UNAVAILABLE`。v0115 起給啟動器與 ⑤ 重跑 ⑥f 的 `VIA_FETCH_PY`
都先用合 VDF 版本界線的那支;repair 沒跑 ② → 用上一輪 ⑥e 收據記的(還在 · 套件齊);都沒有 → 照舊。套件仍是 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s`)。

## PowerShell 7 貼這一行(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0107 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0115 `%s`)。

## 同意閘(操作員決定 · VRN-2 只讀 · 不代設)

新開的視窗要再設一次:`$env:VIA_SCRAPE_CONSENT = 'YES'`(`VIA_NET_CONSENT` 桌機已是 YES)。不設 → ⑥f 不經網路工具重抓(現有共識不動)。

## 這次桌機貼下去會怎樣

- 跟 05:30 一樣 repair(auto):⑥f 已經是今天經網路工具抓的 → 不重抓 → 收尾 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2**(閘照開)。
- 整輪(`$env:VRN2_MODE = 'full'` · 約 40 分鐘):④ 印 `擷取 Python(⑥e / ⑥f)C:\\Python313\\python.exe · 合 VDF 版本界線` · 收據換成啟動器 v0158 · ③ 只檢查 · ③b 照用 OCR 隔離環境 ·
  ⑥e 重抓(3706 / 6669 部分視窗有機會補到)· ⑥f 沿用今天經網路工具抓的。

## 開機行(%s 字元)

```powershell
%s
```

## cmd 視窗

```bat
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, cmd_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == bt_line
(rel / "VRN2_HandleAll_v0107.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0115.py(套件 v0158 不動 · ⑥e / ⑥f 同一個擷取 Python)

`VRN2_RoundAll_v0115.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0114 + 擷取 Python 選法:給啟動器與 ⑤ 重跑 ⑥f 的 `VIA_FETCH_PY` 先用合 VDF 版本界線的那支
(② 經 MarketFetchRun 挑的 · 同 ⑥e)→ 沒跑 ② 用上一輪 ⑥e 收據記的(還在 · 匯入檢查齊)→ 都沒有才用只看匯入的第一支。④ / ⑤ 會印用了哪支、為什麼。
自測 59 項(v0114 的 58 項 + 59)。套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s` · 本檔內已釘死)。**最省事:`VRN2_HandleAll_v0107.md` 最上面那一行**。

```bat
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0115.py" --only package,fix,report,closeout,pasteback
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0115.py"
```
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0115.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0115 + VRN2_HandleAll_v0107 (package v0158 unchanged)", "date": "2026-10-31",
        "trigger": "操作員 2026-10-31:「繼續下一步,依照你的建議進行」· 桌機 05:30 Handle-All v0106 repair 經 VIA 網路工具真抓共識成功(⑥f GREEN)· ⑥f 擷取 Python 是 envs/via_core_312(Raw Parquet WARN)而 ⑥e 是 C:/Python313",
        "package": {"name": "VRN2_Closeout_v0158.zip", "folder": "vrn2_release_v0158", "sha256": want, "changed": False},
        "fixes": {"RoundAll_v0115_fetch_python": "VIA_FETCH_PY for the launcher and for step 5 re-runs of 6f: the Python that passes the VDF engine's own version bounds (step 2 · MarketFetchRun · same as 6e) first; repair without step 2 → the Python the last launcher's 6e receipt recorded (still there · FETCH_REQUIRED import OK); else the first import-only pick as before; steps 4 / 5 print which and why; selftest 59",
                  "HandleAll_v0107": "v0106 pointed at RoundAll v0115 (vrn2_release_v0159); sources recovered from the v0106 md readable blocks (re-joined byte-identical to the published line)"},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0114.py", "sha256": r158["roundall"]["sha256"], "status": "superseded 2026-10-31 (6f fetch Python import-only pick); file kept in vrn2_release_v0158"}],
        "roundall": {"name": "VRN2_RoundAll_v0115.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0115.md"},
        "handleall": {"name": "VRN2_HandleAll_v0107.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0107_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "not_fixed_here": r158["not_fixed_here"], "results": {"status": "see VRN2_Verification_v0159.md"}}
(rel / "VRN2_Release_v0159.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
