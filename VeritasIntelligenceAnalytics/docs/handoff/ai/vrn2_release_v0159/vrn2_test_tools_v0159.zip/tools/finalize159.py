"""v0159 收尾:驗證紀錄 · 交接 v0160(從 v0159 抄 · 只增)· 放進倉 vrn2_release_v0159 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v159"); rel = W / "release159"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
def lines(p): return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()
def short(x): return re.sub(r"<sbx>", "<sbx>", x)
R = json.loads((rel / "VRN2_Release_v0159.json").read_text(encoding="utf-8"))
st = [l for l in lines(W / "rall115_selftest.log") if re.search(r"^\[PASS\] 59 |^\[FAIL\]|--selftest · ", l)]
ps = json.loads((W / "pscheck159.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = lines(W / "tiny159.rc")
e2e = {n: [short(l)[:200] for l in lines(W / ("tiny_%s.log" % n)) if re.search(r"boot|VRN-2\] Handle-All|⑤ VRN2_RoundAll|══════|\[RED\] ⓪|模式 report 要|Handle-All 結束", l)] for n in ("report", "repair", "tamper")}
R["results"] = {"selftest": st, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e,
                "not_run": "repair through a desktop-like VIA root: the container's desktop-state sandbox lived in the session scratchpad that is no longer available, and the 05:41 paste-back carries CSV books only (no JSON books / scope_in) → the 6f fetch-Python pick is covered by selftest 59 (3 cases), the hash chain by the small sandbox"}
(rel / "VRN2_Release_v0159.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
md = """# VRN-2 v0159 驗證紀錄(2026-10-31 · RoundAll v0115 · Handle-All v0107 · 套件 v0158 不動)

## 1. 起因

桌機 05:30(Handle-All v0106 repair · 同意閘兩道都開)第一次經 VIA 網路工具真抓共識成功(⑥f GREEN · 收尾 BLOCKED · VRN-2 0 · 人工 2)。
同一輪 ⑥e 用 `C:\\Python313`(合 VDF 版本界線 · MarketFetchRun 挑的),⑥f 卻用 `envs\\via_core_312`(RoundAll ② 只看套件匯得進來就選 · 舊 pandas)→
引擎 `Raw Parquet: WARN_PARQUET_ENGINE_UNAVAILABLE`。操作員:「繼續下一步,依照你的建議進行」→ ⑥e / ⑥f 用同一個擷取 Python。

## 2. 修法(RoundAll v0115 · SHA-256 `%s`)

`bounds_fetch_python()`:給啟動器(④)與 ⑤ 重跑 ⑥f 的 `VIA_FETCH_PY` →
① ② 挑到合 VDF 版本界線的(同 ⑥e)· ② 沒跑(repair)→ 上一輪啟動器 ⑥e 收據記的(還在 · 匯入檢查齊)· ③ 都沒有 → 照舊只看匯入的第一支。④ / ⑤ 印用了哪支、為什麼。
套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip` 不動(雜湊照釘 `%s`)。Handle-All v0107 指向 RoundAll v0115(原始碼從 v0106 md 的可讀版還原 · 重接後跟發行的那一行逐字相同)。

## 3. 測試

```text
%s
%s
e2e 結束碼:%s
```

## 4. 最短一行 e2e(小沙盒 · 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設)

```text
%s
```

沙盒不是 VIA 根(只驗雜湊鏈):最短一行 → 開機行 SHA-256 → Handle-All v0107 → RoundAll v0115 SHA-256 都相符 · 開機檔被改 → 不執行。
**沒跑到的**:桌機狀態的 repair(容器裡原本的桌機狀態沙盒在已失效的 scratchpad · 貼回包只有 CSV 冊)→ 擷取 Python 的選法由自測 59 的三種情況把關。

## 5. 桌機預期

貼 `VRN2_HandleAll_v0107.md` 最上面那行(新視窗先設 `$env:VIA_SCRAPE_CONSENT = 'YES'`):repair → ⑤ 印 `擷取 Python(⑥e / ⑥f)C:\\Python313\\python.exe · 上一輪 ⑥e 用的(合 VDF 版本界線)`
→ ⑥f 已是今天經網路工具抓的 → 不重抓 → **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2**。整輪(`$env:VRN2_MODE = 'full'`)④ 印 `… · 合 VDF 版本界線(② · 同 ⑥e)`,⑥f 引擎不再 WARN Raw Parquet。
""" % (R["roundall"]["sha256"][:12], R["package"]["sha256"][:12], "\n".join(st), pparse, " · ".join(rc), "\n".join("[%s] " % n + l for n in ("report", "repair", "tamper") for l in e2e[n]))
(rel / "VRN2_Verification_v0159.md").write_text(md, encoding="utf-8", newline="\n")
src = (REPO / "VRN2_Handover_v0159.md").read_text(encoding="utf-8")
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80]); src = src.replace(a, b)
L = src.split("\n"); assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0114 + VRN2_HandleAll_v0106 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0115 + VRN2_HandleAll_v0107 · 2026-10-31(桌機 05:30 經 VIA 網路工具真抓共識成功 · ⑥f GREEN · 收尾 BLOCKED · VRN-2 0 · 人工 2;"
        "RoundAll v0115:⑥e / ⑥f 同一個擷取 Python(合 VDF 版本界線的優先);套件 v0158 不動)")
src = "\n".join(L)
H = R["handleall"]
once("> **本輪(v0158)**",
     "> **桌機 2026-10-31 05:30(Handle-All v0106 repair · 操作員設了 `VIA_SCRAPE_CONSENT`)**:⑥f 第一次經 VIA 網路工具真抓(`SUP_MDL740_NetUnified_v0119 · 閘 開 · 加速器 VIA_SuperAccel_Module · VeritasCeleritas_v1141`)· "
     "43 檔 · 3706 一時抓不到 → 重試補到 · 404 × 3 不納入閘 · gate PASS_WITH_WARNINGS → **GREEN** · 收尾 BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2(`vrn2_release_v0158/VRN2_DesktopRun_20261031.md`)。"
     "③ 23 套件全在 · ③b `envs\\\\vrn2_ocr` 就緒。⑥f 擷取 Python 是 `envs\\\\via_core_312`(⑥e 是 `C:\\\\Python313`)→ Raw Parquet WARN。\n"
     "> **本輪(v0159 · 小輪)**:**RoundAll v0115**:`VIA_FETCH_PY` 先用合 VDF 版本界線的那支(同 ⑥e)· repair 用上一輪 ⑥e 收據記的 · 都沒有才照舊 · 自測 59 項;**Handle-All v0107**(最短一行 %d 字元 · "
     "`vrn2_release_v0159/VRN2_HandleAll_v0107_boot.txt`);套件 v0158 不動。原 scratchpad 失效 → 建置改在 `/home/user/vrn2_work`,原始碼從倉裡已發行的檔還原(Handle-All 重接逐字相同)。\n"
     "> **本輪(v0158)**" % H["tiny_line_chars"])
once("| **VRN2_HandleAll_v0106.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0106** |",
     "| **VRN2_HandleAll_v0107.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0107** | `vrn2_release_v0159` | 一行版 `%s` · 開機檔 `%s` | **新**(RoundAll v0115 · 最短一行 %d 字元)|\n"
     "| **VRN2_RoundAll_v0115.py**(發行夾 · 一支入口 · 不在套件內)| **v0115** | `vrn2_release_v0159` | `%s` | **新**(⑥e / ⑥f 同一個擷取 Python · 套件 v0158 · 自測 59 項)|\n"
     "| **VRN2_HandleAll_v0106.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0106** |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], R["roundall"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0114.py**(發行夾 · 一支入口 · 不在套件內)| **v0114** | `vrn2_release_v0158` | `425397f5d724` | **新**(",
     "| **VRN2_RoundAll_v0114.py**(發行夾 · 一支入口 · 不在套件內)| **v0114** | `vrn2_release_v0158` | `425397f5d724` | 被 v0115 取代(⑥f 擷取 Python 只看匯入)· (")
once("| 0 | **(v0158)**",
     "| 0 | **(v0159)** 桌機 PowerShell 7(新視窗先設 `$env:VIA_SCRAPE_CONSENT='YES'`)貼 `vrn2_release_v0159/VRN2_HandleAll_v0107.md` **最上面那行(%d 字元)**→ repair 預期 BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2 · ⑤ 印擷取 Python = C:\\\\Python313;"
     "整輪(`$env:VRN2_MODE='full'`)收據換啟動器 v0158 · ③ 只檢查 / ③b 照用 / ⑥e 重抓 | 貼回 |\n"
     "| 0 | **(v0158)**" % H["tiny_line_chars"])
once("**v0158(2026-10-31)**:", "**v0159(2026-10-31)**:桌機 05:30 經 VIA 網路工具真抓共識成功;RoundAll v0115 讓 ⑥e / ⑥f 用同一個擷取 Python;Handle-All v0107;套件 v0158 不動。\n\n**v0158(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0159)** **同一輪的步驟用同一個環境**:⑥e 用合 VDF 版本界線挑的 Python,⑥f / 啟動器的 `VIA_FETCH_PY` 也要用它;只看匯入的寬鬆挑法只當最後的退路。\n"
     "- **(v0159)** **scratchpad 會失效**:建置腳本與沙盒放 scratchpad 會整批不見;要留的東西(建置工具 · 原始碼)跟著發行夾的 `vrn2_test_tools_*.zip` 進倉,下一輪才還原得回來。\n\n")
(REPO / "VRN2_Handover_v0160.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0159"; D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0115.py", "VRN2_RoundAll_v0115.md", "VRN2_HandleAll_v0107.md", "VRN2_HandleAll_v0107_boot.txt", "VRN2_Release_v0159.json", "VRN2_Verification_v0159.md"):
    shutil.copy(rel / n, D / n)
def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
    z.writestr(zi, data.replace(b"<sbx>", b"<sbx>").replace(b"<scratch>", b"<scratch>"))
with zipfile.ZipFile(D / "logs_v0159.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "rall115_selftest.log", W / "pscheck159.log", W / "tiny159.rc"] + sorted(W.glob("tiny_*.log")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0159.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall115.py", "build159.py", "finalize159.py", "e2e159.sh", "ps7/join_ps.py", "ps7/parse.ps1", "ps7/handleall_v0106_src.ps1", "ps7/boot_v0106_src.ps1")] + [rel / "tiny_line.txt", rel / "boot_line.txt", rel / "boot_cmd.txt", rel / "handleall_src.ps1", rel / "boot_src.ps1"]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0160", src.count("\n"))
