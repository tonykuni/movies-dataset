"""VRN2_RoundAll_v0115.py = v0114 + ⑥e / ⑥f 用同一個擷取 Python(合 VDF 版本界線的優先)· 套件 v0158 不動(雜湊照釘)。"""
import re
from pathlib import Path
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
W = Path("/home/user/vrn2_work/v159")
s = (REPO / "vrn2_release_v0158/VRN2_RoundAll_v0114.py").read_text(encoding="utf-8")
d0 = s.index('"""VRN2_RoundAll v0114'); d1 = s.index('"""', d0 + 3) + 3


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


doc = s[d0:d1]
doc2 = doc.replace('"""VRN2_RoundAll v0114 — ', '"""VRN2_RoundAll v0115 — ', 1)
at = doc2.index("v0114(操作員 2026-10-31:「依照你的建議進行」)")
doc2 = doc2[:at] + r'''v0115(操作員 2026-10-31:「繼續下一步,依照你的建議進行」· 桌機 05:30 經 VIA 網路工具真抓共識成功之後):
  · ⑥e / ⑥f 用同一個擷取 Python:VIA_FETCH_PY(給啟動器與 ⑤ 重跑 ⑥f)改成合 VDF 版本界線的那支優先(② 用 MarketFetchRun 挑的 · 同 ⑥e);
    沒跑 ②(repair)→ 上一輪啟動器 ⑥e 收據記的 Python(還在 · 匯入檢查齊);都沒有 → 照舊用只看匯入的第一支。
    桌機 05:30:⑥e 用 C:\\Python313(合界線)· ⑥f 卻用 envs\\via_core_312(只看匯入 · 舊 pandas)→ 引擎 Raw Parquet WARN_PARQUET_ENGINE_UNAVAILABLE。
  · 套件仍是 vrn2_release_v0158/VRN2_Closeout_v0158.zip(不動 · 雜湊照釘)。

''' + doc2[at:]
doc2 = doc2.replace("用法:python VRN2_RoundAll_v0114.py", "用法:python VRN2_RoundAll_v0115.py")
assert not re.search(r"(?<!\\)\\(?![\\])", doc2[: doc2.index("v0114(操作員")].replace("\\\\", "")), "single backslash in new docstring part"
s = s[:d0] + doc2 + s[d1:]
rep('VERSION = "v0114"', 'VERSION = "v0115"')
rep('''def runner_from_package(pkg):''', '''def bounds_fetch_python(state: dict, receipt: dict | None = None) -> tuple:
    """v0115 ⑥e / ⑥f 用同一個擷取 Python:② 挑到合 VDF 版本界線的 > 上一輪啟動器 ⑥e 收據記的(還在 · 匯入檢查齊)> 只看匯入的第一支。回 (python, 來源)。"""
    bp = state.get("bounds_python")
    if bp and Path(bp).is_file():
        return bp, "合 VDF 版本界線(② · 同 ⑥e)"
    fp = ((receipt or {}).get("market") or {}).get("fetch_python")
    fp = fp.get("python") if isinstance(fp, dict) else None
    if fp and Path(fp).is_file():
        got = probe_modules(fp, FETCH_REQUIRED)
        if all(got.get(m) for m in FETCH_REQUIRED):
            return fp, "上一輪 ⑥e 用的(合 VDF 版本界線)"
    if "fetch_python" in state:
        return state.get("fetch_python"), "只看匯入(②)"
    py, _ = find_fetch_python()
    return py, "只看匯入"


def runner_from_package(pkg):''')
rep('''    if state.get("fetch_python") and not env.get("VIA_FETCH_PY"):
        env["VIA_FETCH_PY"] = state["fetch_python"]''', '''    run_py, run_how = bounds_fetch_python(state, None)                      # v0115 ⑥e / ⑥f 同一個擷取 Python
    if run_py and not env.get("VIA_FETCH_PY"):
        env["VIA_FETCH_PY"] = run_py
        info("④ 擷取 Python(⑥e / ⑥f)%s · %s" % (run_py, run_how))''')
rep('''    fetch_py = state.get("fetch_python")
    if fetch_py is None and "fetch_python" not in state:
        fetch_py, _ = find_fetch_python()
    plan = plan_fixes(root, receipt, fetch_py, args, state.get("market_tool") or "")''', '''    fetch_py, fetch_how = bounds_fetch_python(state, receipt)               # v0115 ⑥e / ⑥f 同一個擷取 Python
    plan = plan_fixes(root, receipt, fetch_py, args, state.get("market_tool") or "")''')
rep('''    info("⑤ 自動修計畫:" + " · ".join(d for _, d in plan))''', '''    info("⑤ 自動修計畫:" + " · ".join(d for _, d in plan))
    if fetch_py:
        info("⑤ 擷取 Python(⑥e / ⑥f)%s · %s" % (fetch_py, fetch_how))''')
# 自測 59
anchor = '''        chk("58 收尾頁:③b OCR 隔離環境沒就緒(啟動器 v0158 不建不 pip)→ VCGC(以前落到預設 VRN-2)", o58[0] == "VCGC")
'''
rep(anchor, anchor + '''        saved_probe = globals()["probe_modules"]
        fake_ok = str(Path(sys.executable).resolve())
        globals()["probe_modules"] = lambda py, need: {m: True for m in need}
        try:
            p59a = bounds_fetch_python({"bounds_python": fake_ok, "fetch_python": "/no/via_core_312/python"}, None)
            p59b = bounds_fetch_python({}, {"market": {"fetch_python": {"python": fake_ok, "ok": True}}})
            globals()["probe_modules"] = lambda py, need: {m: m != "pyarrow" for m in need}
            p59c = bounds_fetch_python({"fetch_python": "/import/only/python"}, {"market": {"fetch_python": {"python": fake_ok}}})
            p59d = bounds_fetch_python({"bounds_python": "/gone/python", "fetch_python": "/import/only/python"}, None)
        finally:
            globals()["probe_modules"] = saved_probe
        chk("59 ⑥e / ⑥f 同一個擷取 Python:合 VDF 版本界線的優先(桌機 ⑥f 用 via_core_312 · Raw Parquet WARN)· repair 沒跑 ② → 上一輪 ⑥e 收據的(匯入齊)· 不齊 / 不在 → 只看匯入的",
            p59a == (fake_ok, "合 VDF 版本界線(② · 同 ⑥e)") and p59b == (fake_ok, "上一輪 ⑥e 用的(合 VDF 版本界線)") and p59c == ("/import/only/python", "只看匯入(②)")
            and p59d == ("/import/only/python", "只看匯入(②)"))
''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0114.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0115.py"').replace('"VRN2_RoundAll_v0114.py" in html_', '"VRN2_RoundAll_v0115.py" in html_')
assert 'PACKAGE = "VRN2_Closeout_v0158"' in s and re.search(r'PACKAGE_SHA256 = "dfca4f6b13fb[0-9a-f]{52}"', s) and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0158"' in s
(W / "new/VRN2_RoundAll_v0115.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0115 lines", s.count("\n"), "· RoundAll_v0114 refs after doc:", len(re.findall("RoundAll_v0114", s[s.index('VERSION = "v0115"'):])))
