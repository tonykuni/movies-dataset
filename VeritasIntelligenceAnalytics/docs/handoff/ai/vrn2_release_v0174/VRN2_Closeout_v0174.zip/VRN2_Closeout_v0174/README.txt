VRN2_Closeout_v0174 — VRN-2 closeout package (2026-11-03 · Workbench v0108: ENG049 template lock · Freshness · Ticker / YFinance + Name · broker abbreviations · YYYY dates · Source)

Entry: python ActivateVRN-2_v0174.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0130.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0122.md (same release folder).
Runtime: VRN2_Runtime_v0163.zip = v0162 (203 members byte-identical) + VRN2_Workbench_v0108.

v0174 (operator 2026-11-03 U/I):
 - VRN2_Workbench_v0108 (thin tail over v0107): the VRN_ENG049_ContentReconcile v0102 reconcile page is the locked visual template (15 colours,
   font sizes 19 / 11 / 9.5 / 9 / 8 px, Microsoft JhengHei / Cormorant Garamond / Consolas, CSS SHA-256 pinned) over the whole Workbench; data tab:
   Freshness column left of Report Date (before the latest statutory filing deadline or more than 30 trading days old -> 過期; trading days = Mon-Fri
   minus VDF's TW holiday list read with ast), Ticker / YFinance with Name right after it, broker English abbreviations (candidates pending VCGC),
   periods and dates as YYYY / YYYY-MM / YYYY-MM-DD, Source as the last column. window.VRN2_DATA unchanged; exports keep book values + SOURCE.
v0172: HistoryAlign v0103 · ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107. v0170: Workbench v0105 + ConsensusJoin v0106. v0163: no MOPS.
Launcher number v0173 is skipped (release folder v0173 only replaced RoundAll; there is no launcher v0173).
Verification: see VRN2_Verification_v0174.md. Hashes: PACKAGE_SHA256.json.
