// v0174 瀏覽器實測:資料頁欄序 · 第一列 · 整冊 CSV 最後一欄 · 計算後字型 / 顏色 · JS 錯誤 → JSON(只記欄名與結構,不記資料值)
const { chromium } = require('playwright');
const fs = require('fs');
(async () => {
  const b = await chromium.launch();
  const ctx = await b.newContext({ acceptDownloads: true, viewport: { width: 1600, height: 1000 } });
  const p = await ctx.newPage(); const errs = [];
  p.on('pageerror', e => errs.push(String(e))); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto('file://' + process.argv[2]);
  await p.click('.tabs button[data-tab="data"]');
  const books = {};
  for (const ds of ['BasicInfo', 'FinancialData', 'Summary', 'Combined', 'Rejected', 'FinancialAligned']) {
    const btn = await p.$('.subtabs button[data-ds="' + ds + '"]'); if (!btn) continue;
    await btn.click(); await p.waitForTimeout(150);
    books[ds] = await p.evaluate(() => { const th = [...document.querySelectorAll('#dsHead th')].map(x => x.textContent.trim());
      const iT = th.indexOf('Ticker / YFinance'); return { first: th[0], second: th[1], ticker_then: iT >= 0 ? th[iT + 1] : null, last: th[th.length - 1], n: th.length,
        fresh_vals: [...new Set([...document.querySelectorAll('#dsBody td:first-child')].map(x => x.textContent.trim()))].slice(0, 3) }; });
  }
  await p.click('.subtabs button[data-ds="FinancialData"]');
  const [dl] = await Promise.all([p.waitForEvent('download'), p.click('[data-act="csvAll"]')]);
  const hdr = fs.readFileSync(await dl.path(), 'utf8').split('\n')[0].replace(/^﻿/, '').split(',');
  const style = await p.evaluate(() => { const c = s => { const e = document.querySelector(s); if (!e) return null; const g = getComputedStyle(e); return [g.fontFamily.split(',')[0].replace(/"/g, ''), g.fontSize, g.color]; };
    return { body: c('body'), h1: c('header.vh h1'), th: c('#dsHead th'), bg: getComputedStyle(document.body).backgroundColor }; });
  fs.writeFileSync(process.argv[3], JSON.stringify({ books, csv_first: hdr[0], csv_last: hdr[hdr.length - 1], style, errors: errs }, null, 1));
  await b.close();
})();
