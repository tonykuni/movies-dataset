"""VRN2_RoundAll_v0130.py = 本線 v0129(倉裡 vrn2_release_v0173)+ 套件 v0174(啟動器 v0174 · runtime v0163 = v0162 + Workbench v0108)+ ⑤ Workbench v0108 補放 / 重渲染。
操作員 2026-11-03 U/I 要求(ENG049 模板鎖定 · Ticker / YFinance + Name · 券商縮寫 · 時效 · YYYY 日期 · Source)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v174")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0173/VRN2_RoundAll_v0129.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0129')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0129 — ', '"""VRN2_RoundAll v0130 — ', 1)
at = doc.index("v0129(")
doc = doc[:at] + '''v0130(操作員 2026-11-03 U/I:「Ticker / YFinance 同步顯示 · 代號下一欄接 Name · Broker 英文縮寫 · 報告日左邊加時效欄(法定財報日之前或超過 30 個交易日 → 過期)·
  ENG049 對帳頁當靜態視覺模板 · 字體大小與顏色一致且鎖定 · 期間 YYYY / YYYY-MM / YYYY-MM-DD · 所有資料最後加 Source」):
  · 套件 v0174(啟動器 v0174 · runtime v0163 = v0162 的 203 個成員一字不改 + VRN2_Workbench_v0108)。
    Workbench v0108 = v0107 薄尾:ENG049 對帳頁(VRN_ENG049_ContentReconcile v0102)抽出的字型 / 字級 / 顏色鎖成一段 CSS(SHA-256 釘在模組)蓋整頁;
    資料頁顯示層(VRN2_DATA 一字不改)加時效欄 · Ticker / YFinance + Name · 券商縮寫 · 期間 / 日期 YYYY 格式 · 最後一欄 Source;匯出原值 + 最後一欄 SOURCE。
  · ⑤ workbench 觸發換成 v0108 標記(id="wb108-tpl");補放 WORKBENCH_CHAIN = v0108 + v0107(只增不覆寫 · 雜湊對 runtime 清單)。
  · ⑥ Workbench 標記多「ENG049 視覺模板鎖定」。③ 自測清單 Workbench v0107 → v0108。
  · 自測 100 項(v0129 的 99 項 + 98)。共用 MarketFetch 與 VDF 引擎照舊只讀不改(v0108 只用 ast 讀 VDF 的休市表)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0129.py", "用法:python VRN2_RoundAll_v0130.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


b0 = s.index('VERSION = "v0129"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0172", "v0174").replace("VRN2_Runtime_v0162", "VRN2_Runtime_v0163")
s = pre + post
rep('VERSION = "v0129"', 'VERSION = "v0130"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0129.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0129.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0130.py"', n_dl)
rep('"VRN2_RoundAll_v0129.py" in html_', '"VRN2_RoundAll_v0130.py" in html_')
rep("· v0128 起 98 項 · v0129 起 99 項。", "· v0128 起 98 項 · v0129 起 99 項 · v0130 起 100 項。")
rep('SELFTESTS = (("VRN2_Workbench_v0107.py", 600),', 'SELFTESTS = (("VRN2_Workbench_v0108.py", 600),')
rep('and ("VRN2_ConsensusJoin_v0106.py", 900) not in SELFTESTS and ("VRN2_Workbench_v0107.py", 600) in SELFTESTS',
    'and ("VRN2_ConsensusJoin_v0106.py", 900) not in SELFTESTS and ("VRN2_Workbench_v0108.py", 600) in SELFTESTS')
rep('''('id="wb107b"', "Basic Info 合併檢視(Workbench v0107)"))''', '''('id="wb107b"', "Basic Info 合併檢視(Workbench v0107)"), ('id="wb108-tpl"', "ENG049 視覺模板鎖定 · 時效 / Ticker / Source(Workbench v0108)"))''')
rep('WORKBENCH_CHAIN = ("VRN2_Workbench_v0107.py",)                                  # v0128 F3(前版用桌機 / runtime 夾裡已有的)',
    'WORKBENCH_CHAIN = ("VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")         # v0130 v0108 薄尾要 v0107 在旁(v0128 起只增不覆寫補放)')
rep("""WB_MARK = 'id="wb107-css"'""", """WB_MARK = 'id="wb108-tpl"'                                                   # v0130 頁面不是 v0108 後處理過的 → 重渲染""")
rep('"Workbench 重渲染(換 v0107 · Basic Info 合併檢視 · 上漲空間小數欄 · 欄位標註)"', '"Workbench 重渲染(換 v0108 · ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / Source)"')
rep("install_chain(state.get(\"pkg\"), root, WORKBENCH_CHAIN)                 # v0128 F3 Workbench v0107 只增不覆寫",
    "install_chain(state.get(\"pkg\"), root, WORKBENCH_CHAIN)                 # v0130 Workbench v0108 + v0107 只增不覆寫")
rep('''and ("VRN2_Workbench_v0107.py", 600) in SELFTESTS
            and HISTORY_CHAIN[0] == "VRN2_HistoryAlign_v0103.py" and WORKBENCH_CHAIN == ("VRN2_Workbench_v0107.py",))''',
    '''and ("VRN2_Workbench_v0108.py", 600) in SELFTESTS
            and HISTORY_CHAIN[0] == "VRN2_HistoryAlign_v0103.py" and WORKBENCH_CHAIN[0] == "VRN2_Workbench_v0108.py")''')
rep('''        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''',
    '''        with tempfile.TemporaryDirectory() as td98:
            v98 = Path(td98) / "VIA_Reports" / "vrn2"
            v98.mkdir(parents=True)
            (v98 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb107-css"></style></html>', encoding="utf-8")
            p98a = plan_fixes(Path(td98), {"market": {}, "consensus": {}}, "", A93(), "")
            (v98 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb107-css"></style><style id="wb108-tpl"></style></html>', encoding="utf-8")
            p98b = plan_fixes(Path(td98), {"market": {}, "consensus": {}}, "", A93(), "")
        chk("98 v0130:頁是 v0107(沒有 wb108-tpl)→ 只排 workbench(換 v0108 · 模板鎖定)· 已是 v0108 → 不排 · 補放鏈 v0108 + v0107 · 標記含模板鎖定 · 套件 v0174",
            [k for k, _ in p98a] == ["workbench"] and "v0108" in p98a[0][1] and p98b == [] and WORKBENCH_CHAIN == ("VRN2_Workbench_v0108.py", "VRN2_Workbench_v0107.py")
            and any(m == 'id="wb108-tpl"' for m, _ in WORKBENCH_MARKS) and PACKAGE == "VRN2_Closeout_v0174" and RUNTIME_ZIP == "VRN2_Runtime_v0163.zip")
        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''')
(W / "new").mkdir(exist_ok=True)
(W / "new" / "VRN2_RoundAll_v0130.py").write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,30}VRN2_Runtime_v0162.{0,30}|.{0,30}Closeout_v0172.{0,30}", s[s.index('VERSION = "v0130"'):])]
print("RoundAll v0130 lines", s.count("\n"), "· stale refs:", len(left), left[:3])
