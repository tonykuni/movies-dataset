"""從 build172.py 生 build174.py(套件 v0174 · RoundAll v0130 · Handle-All v0122)。"""
import re
from pathlib import Path

s = Path("/home/user/vrn2_work/v172/build172.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep(s.split('"""', 2)[1], "v0174(冪等):套件 VRN2_Closeout_v0174.zip(啟動器 v0174 · runtime v0163 = v0162 + Workbench v0108)→ RoundAll v0130(填套件雜湊)\n"
    "→ Handle-All v0122(指到 v0130 · 收據 ≥ v0170 照舊 repair)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0174)。vrn2_release_v0173 及更早不動。")
rep('W = Path("/home/user/vrn2_work/v172"); pkg, rel = W / "pkg172", W / "release172"', 'W = Path("/home/user/vrn2_work/v174"); pkg, rel = W / "pkg174", W / "release174"')
rep('PREV = Path("/home/user/vrn2_work/v171/release171")', 'PREV = Path("/home/user/vrn2_work/v173/release173")')
rep('(REPO / "vrn2_release_v0170/VRN2_Release_v0170.json")', '(REPO / "vrn2_release_v0172/VRN2_Release_v0172.json")')
rep('(REPO / "vrn2_release_v0171/VRN2_Release_v0171.json")', '(REPO / "vrn2_release_v0173/VRN2_Release_v0173.json")')
rep('(pkg / "VRN2_Runtime_v0162.json")', '(pkg / "VRN2_Runtime_v0163.json")')
rep('(pkg / "VRN2_Runtime_v0162.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0160.zip "', '(pkg / "VRN2_Runtime_v0163.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0162.zip "')
rep('rt["retained_members"] == 200 and rt["new_members"] == ["VRN2_HistoryAlign_v0103.py", "VRN2_ConsensusJoin_v0107.py", "VRN2_Workbench_v0107.py"]',
    'rt["retained_members"] == 203 and rt["new_members"] == ["VRN2_Workbench_v0108.py"]')
rep('"ActivateVRN-2_v0172.py", "VRN2_Runtime_v0162.zip", "VRN2_Runtime_v0162.json"', '"ActivateVRN-2_v0174.py", "VRN2_Runtime_v0163.zip", "VRN2_Runtime_v0163.json"', 2)
rep("# 其他成員跟 v0170 逐位元組相同", "# 其他成員跟 v0172 逐位元組相同")
i0 = s.index('files["README.txt"] = ('); i1 = s.index('files["VALIDATION_RESULT.json"]')
s = s[:i0] + '''files["README.txt"] = ("VRN2_Closeout_v0174 — VRN-2 closeout package (2026-11-03 · Workbench v0108: ENG049 template lock · Freshness · Ticker / YFinance + Name · broker abbreviations · YYYY dates · Source)\\n\\n"
  "Entry: python ActivateVRN-2_v0174.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0130.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0122.md (same release folder).\\n"
  "Runtime: VRN2_Runtime_v0163.zip = v0162 (203 members byte-identical) + VRN2_Workbench_v0108.\\n\\n"
  "v0174 (operator 2026-11-03 U/I):\\n"
  " - VRN2_Workbench_v0108 (thin tail over v0107): the VRN_ENG049_ContentReconcile v0102 reconcile page is the locked visual template (15 colours,\\n"
  "   font sizes 19 / 11 / 9.5 / 9 / 8 px, Microsoft JhengHei / Cormorant Garamond / Consolas, CSS SHA-256 pinned) over the whole Workbench; data tab:\\n"
  "   Freshness column left of Report Date (before the latest statutory filing deadline or more than 30 trading days old -> 過期; trading days = Mon-Fri\\n"
  "   minus VDF's TW holiday list read with ast), Ticker / YFinance with Name right after it, broker English abbreviations (candidates pending VCGC),\\n"
  "   periods and dates as YYYY / YYYY-MM / YYYY-MM-DD, Source as the last column. window.VRN2_DATA unchanged; exports keep book values + SOURCE.\\n"
  "v0172: HistoryAlign v0103 · ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107. v0170: Workbench v0105 + ConsensusJoin v0106. v0163: no MOPS.\\n"
  "Launcher number v0173 is skipped (release folder v0173 only replaced RoundAll; there is no launcher v0173).\\n"
  "Verification: see VRN2_Verification_v0174.md. Hashes: PACKAGE_SHA256.json.\\n").encode("utf-8")
''' + s[i1:]
s = s.replace("VRN2_Verification_v0172.md", "VRN2_Verification_v0174.md")
rep('manifest = {"system": "VRN-2", "version": "v0172",', 'manifest = {"system": "VRN-2", "version": "v0174",')
rep('zpr = rel / "VRN2_Closeout_v0172.zip"', 'zpr = rel / "VRN2_Closeout_v0174.zip"')
rep('zipfile.ZipInfo("VRN2_Closeout_v0172/" + n, date_time=(2026, 11, 3, 0, 0, 0))', 'zipfile.ZipInfo("VRN2_Closeout_v0174/" + n, date_time=(2026, 11, 3, 1, 0, 0))')
rep('(W / "new/VRN2_RoundAll_v0128.py")', '(W / "new/VRN2_RoundAll_v0130.py")')
rep("'PACKAGE = \"VRN2_Closeout_v0172\"' in ra and 'VERSION = \"v0128\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172\"' in ra",
    "'PACKAGE = \"VRN2_Closeout_v0174\"' in ra and 'VERSION = \"v0130\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174\"' in ra")
rep('(rel / "VRN2_RoundAll_v0128.py").write_text(ra', '(rel / "VRN2_RoundAll_v0130.py").write_text(ra')
m0 = re.search(r'^rep\("\$P = ', s, re.M).start()
m1 = s.index("ha_line = join(ha)")
s = s[:m0] + '''rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0173'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174'")
rep("$F = 'VRN2_RoundAll_v0129.py'", "$F = 'VRN2_RoundAll_v0130.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0121", "Handle-All v0122", ha.count("Handle-All v0121"))
rep("套件 v0172 裝在新夾 VRN2_Closeout_v0172", "套件 v0174 裝在新夾 VRN2_Closeout_v0174")
rep("取套件 v0172 → 診斷 → 全部自測 → 跑啟動器 v0172(", "取套件 v0174 → 診斷 → 全部自測 → 跑啟動器 v0174(")
rep("Workbench v0107(v0105 全部 + Basic Info 合併檢視 · 上漲空間小數欄 · 欄位標註)", "Workbench v0108(ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / YYYY 日期 / Source · 含 v0107)")
rep("repair = '取套件 v0172 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;VRN P0 三項:", "repair = '取套件 v0174 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;Workbench v0108 模板鎖定 + 時效 / Ticker / Source;VRN P0 三項:")
rep("只重跑 ⑪ 獨立驗證(套件 v0172 的", "只重跑 ⑪ 獨立驗證(套件 v0174 的")
left = [l for l in ha.split("\\n") if re.search(r"Handle-All v0121|v0129[.]py|release_v0173|套件 v0172|Closeout_v0172", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
''' + s[m1:]
rep('("vrn2_release_v0171", "vrn2_release_v0172"), ("VRN2_HandleAll_v0119.md", "VRN2_HandleAll_v0120.md"), ("Handle-All v0119 SHA-256 OK", "Handle-All v0120 SHA-256 OK")',
    '("vrn2_release_v0173", "vrn2_release_v0174"), ("VRN2_HandleAll_v0121.md", "VRN2_HandleAll_v0122.md"), ("Handle-All v0121 SHA-256 OK", "Handle-All v0122 SHA-256 OK")')
rep('(rel / "VRN2_HandleAll_v0120_boot.txt")', '(rel / "VRN2_HandleAll_v0122_boot.txt")')
rep("vrn2_release_v0172/VRN2_HandleAll_v0120_boot.txt", "vrn2_release_v0174/VRN2_HandleAll_v0122_boot.txt")
i0 = s.index('md = """'); i1 = s.index('print("package"')
s = s[:i0] + Path("/home/user/vrn2_work/v174/build174_tail.py").read_text(encoding="utf-8") + s[i1:]
Path("/home/user/vrn2_work/v174/build174.py").write_text(s, encoding="utf-8")
print("ok")
