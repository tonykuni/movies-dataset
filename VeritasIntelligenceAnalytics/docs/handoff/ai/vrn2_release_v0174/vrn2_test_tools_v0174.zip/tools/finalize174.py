"""v0174 收尾:驗證紀錄 · 交接 v0175(從 v0174 抄 · 只增)· 放進倉 vrn2_release_v0174 · logs / 工具 zip。桌機 / 上傳資料不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v174"); rel = W / "release174"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def last(p):
    return [l for l in lines(p) if l.strip()][-1]


R = json.loads((rel / "VRN2_Release_v0174.json").read_text(encoding="utf-8"))
R.setdefault("template", {})["css_sha256"] = re.search(r'CSS_SHA256 = "([0-9a-f]{64})"', (W / "new" / "VRN2_Workbench_v0108.py").read_text(encoding="utf-8")).group(1)
H = R["handleall"]
ra = [l for l in lines(W / "rall130_selftest.log") if re.search(r"^\[FAIL\]|--selftest · ", l)]
assert ra and "100 項 · 不過 0" in ra[-1], ra[-1:]
lsum = [l for l in lines(W / "launcher174_selftest.log") if l.startswith("[PASS] v0174")]
assert lsum and not [l for l in lines(W / "launcher174_selftest.log") if l.startswith("[FAIL]")]
mods = {"Workbench v0108": last(W / "wb108_selftest.log"), "Workbench v0107 回歸": last(W / "wb107_regress.log")}
assert all("全過" in v for v in mods.values()), mods
ps = json.loads((W / "pscheck174.log").read_text())
by = {x["f"]: x for x in ps}
assert all(x["e"] == 0 for x in ps) and by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"] and by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"]
pparse = "pwsh 剖析錯 %s · Handle-All 一行 = 可讀版 True · 開機行 = 可讀版 True" % sorted(x["e"] for x in ps)
rc = [l for l in lines(W / "tiny174.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
assert "[RED] boot SHA-256 mismatch - not run" in (W / "tiny_tamper.log").read_text(encoding="utf-8")
states = {n: json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
base = {n: json.loads(Path("/home/user/vrn2_work/v171/closeout_%s.json" % n).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
assert states["auto1"].get("VRN-2") == base["auto1"].get("VRN-2") and states["auto2"].get("VRN-2") == base["auto2"].get("VRN-2"), (states, base)
wb1 = (W / "wb_auto1_full.html").read_text(encoding="utf-8")
wb2 = (W / "wb_auto2.html").read_text(encoding="utf-8")
assert wb1.count('id="wb108-tpl"') == 1 and wb2.count('id="wb108-tpl"') == 1 and "function w8cell(" in wb2 and "window.VRN2_WB108" in wb2
plan2 = next(l for l in lines(W / "tiny_auto2.log") if "⑤ 自動修計畫" in l)
wbfix = next(l for l in lines(W / "tiny_auto2.log") if "⑤ 修 · Workbench" in l)
assert "VRN2_Workbench v0108(前版 v0107)" in wbfix and "[GREEN]" in wbfix
browser = json.loads((W / "browser174.json").read_text(encoding="utf-8"))
assert browser["errors"] == [] and browser["csv_last"] == "SOURCE"
R["results"] = {"roundall_v0130_selftest": ra[-1:], "launcher_v0174_selftest": lsum, "module_selftests": mods, "pwsh_parse": pparse, "e2e_rc": rc, "closeout_per_owner": states,
                "closeout_vrn2_items_same_as_v0171_baseline": True, "repair_plan": plan2.split("⑤ 自動修計畫:", 1)[-1][:300], "repair_workbench": wbfix.strip().replace(str(W / "t174a"), "<sbx>")[:200],
                "browser": browser,
                "desktop_shape_check": "the desktop's FinancialData export (11,905 rows, uploaded by the operator, used only in the sandbox): every PERIOD normalised (est 6,489 · act 5,416 · unparsed 0) · all 13 brokers mapped to an abbreviation · rendered over the other line's v0104 → v0107 → v0108 with no JS errors",
                "not_run": "the desktop itself (one line · auto = repair · Workbench re-render) · the operator's own --confirm (H-fd2ea35f)"}
(rel / "VRN2_Release_v0174.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0174 驗證紀錄(2026-11-03 · Workbench v0108:ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance + Name / 券商縮寫 / YYYY 日期 / Source · 套件 v0174 · RoundAll v0130 · Handle-All v0122)

## 1. 操作員要求 → 做法

| 要求 | Workbench v0108(v0107 薄尾 · `window.VRN2_DATA` 一字不改)|
|---|---|
| Ticker Symbol / 股票代號 → Ticker / YFinance · 同步顯示 · 代號下一欄接 Name | 資料頁每一冊:「Ticker / YFinance」一欄(2330 / 2330.TW)· 下一欄一定是 Name(沒有 NAME 的冊用 Combined 合併名稱補)|
| Broker 英文縮寫 | KGI · GS · MS · JPM · CTBC · MQ · Cathay · Mega · HNS …(候選表 · 等 VCGC 核發 · 對不到照原文並標記)|
| 報告日左邊加時效欄 | 早於最近已過的法定公布期限(3/31 · 5/15 · 8/14 · 11/14)或距今 > 30 個交易日 → **過期**;交易日 = 週一到五 − VDF 台股休市表(VDF_MDL001 · ast 唯讀)|
| ENG049 對帳頁當靜態視覺模板 · 字體與顏色一致且鎖定 · 左右面板等加上去 | VRN_ENG049_ContentReconcile v0102 對帳頁抽出 15 色 / 字級 19 · 11 · 9.5 · 9 · 8 px / 三種字型 → 一段 CSS 蓋整頁 · SHA-256 `%s` 釘在模組(自測核對 · 改就紅)|
| 時間 YYYY / YYYY-MM / YYYY-MM-DD | 期間:2026E → 2026 · Dec-26F → 2026-12 · 12/25 → 2025-12 · FY26E → 2026;日期:2026/5/2 → 2026-05-02;滑過看原文 |
| 所有資料最後加 Source | 每一冊最後一欄 Source(歷史 TWSE/TPEX · 報告預估 · 報告實際 · 報告 …)· CSV / JSON / MD 匯出值照輸出冊 + 最後一欄 SOURCE |

說明:Workbench v0105 的「有底色的字白色」改成模板的淡底深字標籤(新要求「顏色跟模板一致」優先)。

## 2. 測試

| 項目 | 結果 |
|---|---|
| Workbench v0108 自測 | %s |
| Workbench v0107 回歸 | %s |
| 啟動器 v0174 自測 | 全過 · %s |
| RoundAll v0130 自測 | %s |
| PowerShell 剖析 | %s |
| 桌機形狀資料(操作員上傳的 FinancialData 匯出 · 只在沙盒用)| 11,905 列期間全部轉成 YYYY 格式(預估 6,489 · 實際 5,416 · 讀不出 0)· 13 家券商全有縮寫 · 疊在另一線 v0104 → v0107 → v0108 上 JS 0 錯 |
| 瀏覽器(Chromium)| 資料頁欄序:時效 → 報告日 → … → Ticker / YFinance → Name → … → Source(最後)· 整冊 CSV 最後一欄 SOURCE · 內文 JhengHei 11px `#33403f` · 標題 Cormorant 19px · 表頭 Consolas 9px · 底 `#f2f1ec` · JS 錯 0 |
| e2e(最短一行 · 沙盒)| %s · auto1 整輪(啟動器 v0174 → Workbench v0108)→ 模擬桌機頁是 v0107 → auto2 repair 只排 workbench(補放 v0108 + v0107 → 重渲染)→ 竄改開機檔不執行 |
| 收尾負責方 | VRN-2 項與 v0171 基準相同(沙盒限定 · 沒有真 OCR 環境)|

## 3. 桌機下一步

1. 貼 `vrn2_release_v0174/VRN2_HandleAll_v0122.md` 的最短一行(收據 ≥ v0170 → repair · 一分鐘上下 · 只重渲染 Workbench)→ 打開工作台看資料頁。
2. MQ-1560 看過原圖:`python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0130.py" --confirm H-fd2ea35f --note "…"`(只有操作員打才算)。
3. 券商縮寫表要成為正式同義字 → 交 VCGC 核(VRN 只顯示用 · 不寫進輸出冊)。
""" % (R.get("template", {}).get("css_sha256", "")[:12] or "見模組 CSS_SHA256", mods["Workbench v0108"][:80], mods["Workbench v0107 回歸"][:80], lsum[0][:100], ra[-1][:100], pparse, " · ".join(rc))
(rel / "VRN2_Verification_v0174.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0174.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0172 + VRN2_RoundAll_v0129 + VRN2_HandleAll_v0121 · 2026-11-03(")
L[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0174 + VRN2_RoundAll_v0130 + VRN2_HandleAll_v0122 · 2026-11-03(Workbench v0108:ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance + Name / 券商縮寫 / YYYY 日期 / Source)"
src = "\n".join(L)
once("> **本輪(v0173)**",
     "> **本輪(v0174)**:操作員 11/03 U/I 要求 → **Workbench v0108**(v0107 薄尾 · `window.VRN2_DATA` 一字不改):VRN_ENG049_ContentReconcile v0102 對帳頁當靜態視覺模板"
     "(15 色 · 字級 19 / 11 / 9.5 / 9 / 8 px · JhengHei / Cormorant / Consolas · CSS SHA-256 釘在模組)蓋整頁;資料頁顯示層:報告日左邊「時效」(法定財報日之前或 > 30 交易日 → 過期 · "
     "交易日扣 VDF 休市表)· 「Ticker / YFinance」+ Name 緊接 · 券商英文縮寫(候選 · 等 VCGC)· 期間 / 日期 YYYY / YYYY-MM / YYYY-MM-DD · 最後一欄 Source;匯出原值 + 最後一欄 SOURCE。"
     "**RoundAll v0130**(頁不是 v0108 → 補放 v0108 + v0107 → 重渲染 · 自測 100)· **Handle-All v0122** · 套件 v0174(啟動器 v0174 · runtime v0163)。\n"
     "> **本輪(v0173)**")
rows = ("| **VRN2_HandleAll_v0122.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0122** | `vrn2_release_v0174` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0130)|\n"
        "| **VRN2_RoundAll_v0130.py**(發行夾 · 一支入口 · 不在套件內)| **v0130** | `vrn2_release_v0174` | `%s` | **新**(套件 v0174 · Workbench v0108 補放 / 重渲染 · 自測 100)|\n"
        "| ActivateVRN-2_v0174.py(套件 · 底座 v0136 · runtime v0163 · 版號跳過 v0173)| **v0174** | 見發行清單 | `%s` | **新**(Workbench v0108)|\n"
        "| VRN2_Runtime_v0163.zip(套件 · runtime)| **v0163** | 套件內 | `%s` | **新**(v0162 的 203 個成員不動 + Workbench v0108)|\n"
        "| VRN2_Workbench_v0108.py(runtime · v0107 薄尾)| **v0108** | runtime v0163 | 見 runtime 清單 | **新**(ENG049 模板鎖定 · 時效 · Ticker / YFinance + Name · 券商縮寫 · YYYY 日期 · Source · 匯出帶 SOURCE)|\n") % (
    H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12],
    next(c["sha256"] for c in R["components"] if c["path"] == "ActivateVRN-2_v0174.py")[:12], R["runtime"]["zip_sha256"][:12])
once("| **VRN2_HandleAll_v0121.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0121** | `vrn2_release_v0173` |",
     rows + "| **VRN2_HandleAll_v0121.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0121** | `vrn2_release_v0173` |")
once("| 0 | **(v0173)**",
     "| 0 | **(v0174)** 貼 `vrn2_release_v0174/VRN2_HandleAll_v0122.md` 的最短一行(repair · 只重渲染 Workbench)→ 看資料頁:時效 · Ticker / YFinance · Name · 券商縮寫 · Source · 模板顏色字級 · "
     "MQ-1560 `--confirm H-fd2ea35f`(操作員)· 券商縮寫表交 VCGC 核 | 貼回 / 人工 / VCGC |\n"
     "| 0 | **(v0173)**")
once("**v0173(2026-11-03)**:", "**v0174(2026-11-03)**:Workbench v0108(ENG049 模板鎖定 · 時效 · Ticker / YFinance + Name · 券商縮寫 · YYYY 日期 · Source)· RoundAll v0130 · Handle-All v0122 · 套件 v0174。\n\n**v0173(2026-11-03)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0174)** **U/I 視覺模板鎖定**:Workbench 的字型 / 字級 / 顏色以 VRN_ENG049_ContentReconcile v0102 對帳頁為準(Workbench v0108 的 `_CSS` · SHA-256 釘在 `CSS_SHA256`)。"
     "改任何顏色 / 字級都要出新版號並重算;只能用模板 15 色、字級 19 / 11 / 9.5 / 9 / 8 px。v0105 的「實底白字」已被模板淡底深字取代。\n"
     "- **(v0174)** **資料頁只改顯示、不改資料**:`window.VRN2_DATA` 要跟輸出冊逐字相同(另一線 v0104 規則);時效 / Ticker / Name / 券商縮寫 / 日期格式 / Source 都在頁面 JS 算;"
     "匯出值照輸出冊 + 最後一欄 SOURCE。券商縮寫表是候選(VCGC 才能核成正式同義字)。\n"
     "- **(v0174)** **版號**:本線下一版 Workbench v0109+ · RoundAll v0131+ · Handle-All v0123+ · runtime v0164+ · 啟動器 / 套件 / 收據 v0175+;出號前照舊查本分支與 main。\n\n")
(REPO / "VRN2_Handover_v0175.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0174"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0174.zip", "VRN2_RoundAll_v0130.py", "VRN2_RoundAll_v0130.md", "VRN2_HandleAll_v0122.md", "VRN2_HandleAll_v0122_boot.txt", "VRN2_Release_v0174.json", "VRN2_Verification_v0174.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 1, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t174a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0174.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall130_selftest.log", "launcher174_selftest.log", "wb108_selftest.log", "wb107_regress.log", "pscheck174.log", "tiny174.rc", "seed174.log", "sim173.log",
                              "confirm_list.log", "browser174.json")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0174.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall130.py", "mk_launcher174.py", "runtime163.py", "gen_build174.py", "build174.py", "build174_tail.py", "finalize174.py", "e2e174.sh", "browser174.js")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0175", src.count("\n"))
