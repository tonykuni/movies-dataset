"""v0174(冪等):套件 VRN2_Closeout_v0174.zip(啟動器 v0174 · runtime v0163 = v0162 + Workbench v0108)→ RoundAll v0130(填套件雜湊)
→ Handle-All v0122(指到 v0130 · 收據 ≥ v0170 照舊 repair)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0174)。vrn2_release_v0173 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v174"); pkg, rel = W / "pkg174", W / "release174"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v173/release173")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0172/VRN2_Release_v0172.json").read_text(encoding="utf-8"))
r171 = json.loads((REPO / "vrn2_release_v0173/VRN2_Release_v0173.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0163.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0163.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0162.zip " + r170["runtime"]["zip_sha256"]
assert rt["retained_members"] == 203 and rt["new_members"] == ["VRN2_Workbench_v0108.py"]
old = {c["path"]: c["sha256"] for c in r170["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0174.py", "VRN2_Runtime_v0163.zip", "VRN2_Runtime_v0163.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0174.py", "VRN2_Runtime_v0163.zip", "VRN2_Runtime_v0163.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0172 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0174 — VRN-2 closeout package (2026-11-03 · Workbench v0108: ENG049 template lock · Freshness · Ticker / YFinance + Name · broker abbreviations · YYYY dates · Source)\n\n"
  "Entry: python ActivateVRN-2_v0174.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0130.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0122.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0163.zip = v0162 (203 members byte-identical) + VRN2_Workbench_v0108.\n\n"
  "v0174 (operator 2026-11-03 U/I):\n"
  " - VRN2_Workbench_v0108 (thin tail over v0107): the VRN_ENG049_ContentReconcile v0102 reconcile page is the locked visual template (15 colours,\n"
  "   font sizes 19 / 11 / 9.5 / 9 / 8 px, Microsoft JhengHei / Cormorant Garamond / Consolas, CSS SHA-256 pinned) over the whole Workbench; data tab:\n"
  "   Freshness column left of Report Date (before the latest statutory filing deadline or more than 30 trading days old -> 過期; trading days = Mon-Fri\n"
  "   minus VDF's TW holiday list read with ast), Ticker / YFinance with Name right after it, broker English abbreviations (candidates pending VCGC),\n"
  "   periods and dates as YYYY / YYYY-MM / YYYY-MM-DD, Source as the last column. window.VRN2_DATA unchanged; exports keep book values + SOURCE.\n"
  "v0172: HistoryAlign v0103 · ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107. v0170: Workbench v0105 + ConsensusJoin v0106. v0163: no MOPS.\n"
  "Launcher number v0173 is skipped (release folder v0173 only replaced RoundAll; there is no launcher v0173).\n"
  "Verification: see VRN2_Verification_v0174.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0174.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0174", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0174.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0174/" + n, date_time=(2026, 11, 3, 1, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0130.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0174"' in ra and 'VERSION = "v0130"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174"' in ra
(rel / "VRN2_RoundAll_v0130.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0173'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174'")
rep("$F = 'VRN2_RoundAll_v0129.py'", "$F = 'VRN2_RoundAll_v0130.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0121", "Handle-All v0122", ha.count("Handle-All v0121"))
rep("套件 v0172 裝在新夾 VRN2_Closeout_v0172", "套件 v0174 裝在新夾 VRN2_Closeout_v0174")
rep("取套件 v0172 → 診斷 → 全部自測 → 跑啟動器 v0172(", "取套件 v0174 → 診斷 → 全部自測 → 跑啟動器 v0174(")
rep("Workbench v0107(v0105 全部 + Basic Info 合併檢視 · 上漲空間小數欄 · 欄位標註)", "Workbench v0108(ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / YYYY 日期 / Source · 含 v0107)")
rep("repair = '取套件 v0172 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;VRN P0 三項:", "repair = '取套件 v0174 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;Workbench v0108 模板鎖定 + 時效 / Ticker / Source;VRN P0 三項:")
rep("只重跑 ⑪ 獨立驗證(套件 v0172 的", "只重跑 ⑪ 獨立驗證(套件 v0174 的")
left = [l for l in ha.split("\n") if re.search(r"Handle-All v0121|v0129[.]py|release_v0173|套件 v0172|Closeout_v0172", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0173", "vrn2_release_v0174"), ("VRN2_HandleAll_v0121.md", "VRN2_HandleAll_v0122.md"), ("Handle-All v0121 SHA-256 OK", "Handle-All v0122 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0122_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0174/VRN2_HandleAll_v0122_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0122(2026-11-03 · Workbench v0108:ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / YYYY 日期 / Source · 套件 v0174 · RoundAll v0130)

操作員 2026-11-03 U/I 要求 → 做法(資料冊一個字都不改 · 只改畫面 · 匯出最後多一欄 SOURCE):

| 要求 | Workbench v0108 |
|---|---|
| Ticker Symbol / 股票代號 → Ticker / YFinance · 兩個同步顯示 · 代號下一欄接 Name | 資料頁每一冊:TICKER 欄顯示「2330 / 2330.TW」(冊裡沒有 Yahoo 代號就用 Combined / 基本資料 / 市場冊對)· 下一欄一定是 Name(沒有 NAME 的冊用 Combined 合併後的名稱補)|
| Broker 一律英文縮寫 | KGI · GS · MS · JPM · CTBC · MQ · Cathay · Mega · HNS …(滑過看原文 · 縮寫表是候選 · 等 VCGC 核發)|
| 報告日左邊加一欄:法定財報日之前或超過 30 個交易日 → 過期 | 「Freshness / 時效」:早於最近一個已過的法定公布期限(3/31 · 5/15 · 8/14 · 11/14)或距今 > 30 個交易日 → **過期**;交易日 = 週一到五 − VDF 台股休市表(唯讀借用)|
| ENG049 對帳頁當靜態視覺模板 · 字體大小與顏色一致且鎖定 · 左右面板與其他部分加上去 | 底 `#f2f1ec` · 字 `#33403f` · 標題 Cormorant Garamond 19px · 內文 Microsoft JhengHei 9.5–11px · 表頭 / 標籤 Consolas 9px 大寫 · 綠 / 琥珀 / 紅淡底標籤;整頁(左欄 · 頁首 · 分頁 · 卡片 · 矩陣 · 00 系統現況)一起套 · CSS SHA-256 釘在模組 |
| 擷取下來的時間一律 YYYY · YYYY-MM · YYYY-MM-DD | 2026E → 2026 · Dec-26F → 2026-12 · 12/25 → 2025-12 · FY26E → 2026 · 2026/5/2 → 2026-05-02(滑過看原文)|
| 所有資料最後加一欄 Source(歷史 vs 報告預估)| 每一冊最後一欄:歷史 TWSE/TPEX · 報告預估 · 報告實際 · 報告 …;CSV / JSON 匯出也帶(值照輸出冊原樣)|

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0174/VRN2_Closeout_v0174.zip`(SHA-256 `%s` · 啟動器 v0174 · runtime v0163 = v0162 + Workbench v0108 · 跳過 v0173 啟動器號)|
| 一支 Python | `VRN2_RoundAll_v0130.py`(SHA-256 `%s` · 自測 100 項 · 頁不是 v0108 → ⑤ 補放 v0108 + v0107 → 重渲染)|
| 自動選模式 | 收據 ≥ v0170 → **repair(一分鐘上下)**:只重渲染 Workbench |

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0122 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0130 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0130.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0130.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0122.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0130.py(套件 v0174 · Workbench v0108)

`VRN2_RoundAll_v0130.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0129 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0174/VRN2_Closeout_v0174.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0174 · runtime v0163 = v0162 + Workbench v0108 |
| ⑤ workbench | 頁面沒有 v0108 標記(`id="wb108-tpl"`)→ 只增不覆寫補放 Workbench v0108 + v0107 → 重渲染 |
| ⑥ 除錯 | Workbench 標記多「ENG049 視覺模板鎖定 · 時效 / Ticker / Source」|
| ③ 自測清單 | Workbench v0107 → v0108 |
| 自測 | 100 項(v0129 的 99 項 + 98)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0130.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0174 (launcher v0174 · runtime v0163) + VRN2_RoundAll_v0130 + VRN2_HandleAll_v0122", "date": "2026-11-03",
        "trigger": "操作員 2026-11-03:Ticker / YFinance 同步顯示 · 代號下一欄接 Name · Broker 英文縮寫 · 報告日左邊加時效欄(法定財報日之前或超過 30 個交易日 → 過期)· ENG049 對帳頁當靜態視覺模板(字體大小與顏色一致且鎖定 · 左右面板加上去)· 擷取時間 YYYY / YYYY-MM / YYYY-MM-DD · 所有資料最後加 Source(歷史 vs 報告預估)",
        "template": {"source": "VRN_ENG049_ContentReconcile_v0102.py (functional modules/VRN) · reconcile page 'VRN-RECONCILE · READ-ONLY · 零落庫 · OCR EXTRACTION × SSOT v2 · CONTENT RECONCILE MATRIX'",
                     "palette": ["#f2f1ec", "#ffffff", "#33403f", "#1b1a17", "#6b6860", "#dcdad3", "#dbd9d3", "#ebe9e3", "#3d7a52", "#e6efec", "#2c4f4a", "#f2ecdd", "#6f5c31", "#f3e7e6", "#9e2b25"],
                     "font_sizes_px": [19, 11, 9.5, 9, 8], "fonts": ["Microsoft JhengHei / Segoe UI", "Cormorant Garamond / Georgia", "Consolas"],
                     "note": "the earlier 'white text on solid badges' rule (Workbench v0105) is superseded by the template's pastel tags with dark text"},
        "data_rule": "window.VRN2_DATA stays byte-identical to the output books (the other line's v0104 rule); all changes are display-time; every export keeps the book values and appends SOURCE as the last column",
        "freshness": "過期 when the report date is before the latest statutory filing deadline already passed (3/31 · 5/15 · 8/14 · 11/14) or more than 30 trading days before the as-of date; trading days = Mon-Fri minus VDF's TW_KNOWN_HOLIDAYS (VDF_MDL001, read with ast, VDF untouched)",
        "broker_abbreviations": "candidate table in Workbench v0108 (display only · not written to books) · pending VCGC as the governed synonym list",
        "fixes": {"Workbench_v0108": "template lock CSS + data-tab display layer (Freshness · Ticker / YFinance + Name · broker abbreviations · YYYY dates · Source) + exports append SOURCE + Basic Info merged card re-laid out · selftest 12",
                  "RoundAll_v0130": "package v0174 pin · workbench trigger on the wb108-tpl page marker · install chain v0108 + v0107 · selftest 100",
                  "HandleAll_v0122": "points at RoundAll v0130 / release v0174 · receipts ≥ v0170 still pick repair"},
        "package": {"name": "VRN2_Closeout_v0174.zip", "sha256": want, "release_folder": "vrn2_release_v0174", "changed": True,
                    "launcher": "ActivateVRN-2_v0174.py", "launcher_numbering": "v0173 skipped (release v0173 was RoundAll-only)"},
        "runtime": {"name": "VRN2_Runtime_v0163.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 203, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0129.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0173"}],
        "roundall": {"name": "VRN2_RoundAll_v0130.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0130.md"},
        "handleall": {"name": "VRN2_HandleAll_v0122.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0122_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "Workbench v0108 · runtime v0163 · launcher / package / receipt v0174 · RoundAll v0130 · HandleAll v0122 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0174.md"}}
(rel / "VRN2_Release_v0174.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
