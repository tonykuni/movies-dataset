md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0122(2026-11-03 · Workbench v0108:ENG049 視覺模板鎖定 · 時效 / Ticker / YFinance / 券商縮寫 / YYYY 日期 / Source · 套件 v0174 · RoundAll v0130)

操作員 2026-11-03 U/I 要求 → 做法(資料冊一個字都不改 · 只改畫面 · 匯出最後多一欄 SOURCE):

| 要求 | Workbench v0108 |
|---|---|
| Ticker Symbol / 股票代號 → Ticker / YFinance · 兩個同步顯示 · 代號下一欄接 Name | 資料頁每一冊:TICKER 欄顯示「2330 / 2330.TW」(冊裡沒有 Yahoo 代號就用 Combined / 基本資料 / 市場冊對)· 下一欄一定是 Name(沒有 NAME 的冊用 Combined 合併後的名稱補)|
| Broker 一律英文縮寫 | KGI · GS · MS · JPM · CTBC · MQ · Cathay · Mega · HNS …(滑過看原文 · 縮寫表是候選 · 等 VCGC 核發)|
| 報告日左邊加一欄:法定財報日之前或超過 30 個交易日 → 過期 | 「Freshness / 時效」:早於最近一個已過的法定公布期限(3/31 · 5/15 · 8/14 · 11/14)或距今 > 30 個交易日 → **過期**;交易日 = 週一到五 − VDF 台股休市表(唯讀借用)|
| ENG049 對帳頁當靜態視覺模板 · 字體大小與顏色一致且鎖定 · 左右面板與其他部分加上去 | 底 `#f2f1ec` · 字 `#33403f` · 標題 Cormorant Garamond 19px · 內文 Microsoft JhengHei 9.5–11px · 表頭 / 標籤 Consolas 9px 大寫 · 綠 / 琥珀 / 紅淡底標籤;整頁(左欄 · 頁首 · 分頁 · 卡片 · 矩陣 · 00 系統現況)一起套 · CSS SHA-256 釘在模組 |
| 擷取下來的時間一律 YYYY · YYYY-MM · YYYY-MM-DD | 2026E → 2026 · Dec-26F → 2026-12 · 12/25 → 2025-12 · FY26E → 2026 · 2026/5/2 → 2026-05-02(滑過看原文)|
| 所有資料最後加一欄 Source(歷史 vs 報告預估)| 每一冊最後一欄:歷史 TWSE/TPEX · 報告預估 · 報告實際 · 報告 …;CSV / JSON 匯出也帶(值照輸出冊原樣)|

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0174/VRN2_Closeout_v0174.zip`(SHA-256 `%s` · 啟動器 v0174 · runtime v0163 = v0162 + Workbench v0108 · 跳過 v0173 啟動器號)|
| 一支 Python | `VRN2_RoundAll_v0130.py`(SHA-256 `%s` · 自測 100 項 · 頁不是 v0108 → ⑤ 補放 v0108 + v0107 → 重渲染)|
| 自動選模式 | 收據 ≥ v0170 → **repair(一分鐘上下)**:只重渲染 Workbench |

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0122 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0130 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0130.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0130.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0122.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0130.py(套件 v0174 · Workbench v0108)

`VRN2_RoundAll_v0130.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0129 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0174/VRN2_Closeout_v0174.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0174 · runtime v0163 = v0162 + Workbench v0108 |
| ⑤ workbench | 頁面沒有 v0108 標記(`id="wb108-tpl"`)→ 只增不覆寫補放 Workbench v0108 + v0107 → 重渲染 |
| ⑥ 除錯 | Workbench 標記多「ENG049 視覺模板鎖定 · 時效 / Ticker / Source」|
| ③ 自測清單 | Workbench v0107 → v0108 |
| 自測 | 100 項(v0129 的 99 項 + 98)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0130.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0174 (launcher v0174 · runtime v0163) + VRN2_RoundAll_v0130 + VRN2_HandleAll_v0122", "date": "2026-11-03",
        "trigger": "操作員 2026-11-03:Ticker / YFinance 同步顯示 · 代號下一欄接 Name · Broker 英文縮寫 · 報告日左邊加時效欄(法定財報日之前或超過 30 個交易日 → 過期)· ENG049 對帳頁當靜態視覺模板(字體大小與顏色一致且鎖定 · 左右面板加上去)· 擷取時間 YYYY / YYYY-MM / YYYY-MM-DD · 所有資料最後加 Source(歷史 vs 報告預估)",
        "template": {"source": "VRN_ENG049_ContentReconcile_v0102.py (functional modules/VRN) · reconcile page 'VRN-RECONCILE · READ-ONLY · 零落庫 · OCR EXTRACTION × SSOT v2 · CONTENT RECONCILE MATRIX'",
                     "palette": ["#f2f1ec", "#ffffff", "#33403f", "#1b1a17", "#6b6860", "#dcdad3", "#dbd9d3", "#ebe9e3", "#3d7a52", "#e6efec", "#2c4f4a", "#f2ecdd", "#6f5c31", "#f3e7e6", "#9e2b25"],
                     "font_sizes_px": [19, 11, 9.5, 9, 8], "fonts": ["Microsoft JhengHei / Segoe UI", "Cormorant Garamond / Georgia", "Consolas"],
                     "note": "the earlier 'white text on solid badges' rule (Workbench v0105) is superseded by the template's pastel tags with dark text"},
        "data_rule": "window.VRN2_DATA stays byte-identical to the output books (the other line's v0104 rule); all changes are display-time; every export keeps the book values and appends SOURCE as the last column",
        "freshness": "過期 when the report date is before the latest statutory filing deadline already passed (3/31 · 5/15 · 8/14 · 11/14) or more than 30 trading days before the as-of date; trading days = Mon-Fri minus VDF's TW_KNOWN_HOLIDAYS (VDF_MDL001, read with ast, VDF untouched)",
        "broker_abbreviations": "candidate table in Workbench v0108 (display only · not written to books) · pending VCGC as the governed synonym list",
        "fixes": {"Workbench_v0108": "template lock CSS + data-tab display layer (Freshness · Ticker / YFinance + Name · broker abbreviations · YYYY dates · Source) + exports append SOURCE + Basic Info merged card re-laid out · selftest 12",
                  "RoundAll_v0130": "package v0174 pin · workbench trigger on the wb108-tpl page marker · install chain v0108 + v0107 · selftest 100",
                  "HandleAll_v0122": "points at RoundAll v0130 / release v0174 · receipts ≥ v0170 still pick repair"},
        "package": {"name": "VRN2_Closeout_v0174.zip", "sha256": want, "release_folder": "vrn2_release_v0174", "changed": True,
                    "launcher": "ActivateVRN-2_v0174.py", "launcher_numbering": "v0173 skipped (release v0173 was RoundAll-only)"},
        "runtime": {"name": "VRN2_Runtime_v0163.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 203, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0129.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0173"}],
        "roundall": {"name": "VRN2_RoundAll_v0130.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0130.md"},
        "handleall": {"name": "VRN2_HandleAll_v0122.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0122_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "Workbench v0108 · runtime v0163 · launcher / package / receipt v0174 · RoundAll v0130 · HandleAll v0122 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0174.md"}}
(rel / "VRN2_Release_v0174.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
