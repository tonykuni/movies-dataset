"""ActivateVRN-2_v0174.py = v0172 + Workbench v0108(ENG049 對帳頁視覺模板鎖定 · 資料頁顯示規則 · 全冊最後一欄 Source)。
runtime v0163 = runtime v0162(203 個成員一字不改)+ VRN2_Workbench_v0108。啟動器版號跳過 v0173(v0173 是只換 RoundAll 的發行夾,沒有 v0173 啟動器)。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v172/pkg172/ActivateVRN-2_v0172.py")
OUT = Path("/home/user/vrn2_work/v174/pkg174/ActivateVRN-2_v0174.py")
OUT.parent.mkdir(parents=True, exist_ok=True)
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0172: v0170 entry + HistoryAlign v0103 + ConsensusJoin v0107 + Workbench v0107', '''"""VRN-2 v0174: v0172 entry + Workbench v0108 (operator 2026-11-03: "Ticker / YFinance 同步顯示 · 代號下一欄接 Name · Broker 英文縮寫 · 報告日左邊加時效欄
 (法定財報日之前或超過 30 個交易日 → 過期)· ENG049 對帳頁當靜態視覺模板 · 字體大小與顏色一致且鎖定 · 期間 YYYY / YYYY-MM / YYYY-MM-DD · 所有資料最後加 Source").
 - VRN2_Workbench_v0108 (thin tail over v0107 · v0107 and its dynamic prior unchanged): one locked CSS block taken from the VRN_ENG049_ContentReconcile v0102
   reconcile page (15 colours · font sizes 19 / 11 / 9.5 / 9 / 8 px · Microsoft JhengHei / Cormorant Garamond / Consolas · SHA-256 pinned in the module) laid over
   the whole Workbench (left panel · header · tabs · cards · matrices · 00 summary · the v0107 blocks); a display layer injected into the page script for the
   data tab: Freshness / 時效 column left of Report Date (before the latest statutory filing deadline 3/31 · 5/15 · 8/14 · 11/14, or more than 30 trading days old
   → 過期; trading days = Mon–Fri minus VDF's TW holiday list, read with ast · VDF untouched), TICKER shown as "Ticker / YFinance" with Name right after it,
   broker English abbreviations (candidate table pending VCGC), periods and dates as YYYY / YYYY-MM / YYYY-MM-DD, and a final Source column (歷史 TWSE/TPEX ·
   報告預估 · 報告實際 · 報告 …). window.VRN2_DATA stays byte-identical to the output books; every export keeps the book values and appends SOURCE as the last column.
 Runtime v0163 = runtime v0162 (203 members byte-identical) + VRN2_Workbench_v0108.
 Receipt VRN2_Closeout_v0174.json. Launcher number v0173 is skipped (release folder v0173 only replaced RoundAll; there is no launcher v0173).

VRN-2 v0172: v0170 entry + HistoryAlign v0103 + ConsensusJoin v0107 + Workbench v0107''')
rep('VERSION = "ActivateVRN-2 v0172"', 'VERSION = "ActivateVRN-2 v0174"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0162.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0163.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0162.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0163.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0172.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0174.json"')
rep('WORKBENCH = "VRN2_Workbench_v0107.py"   # v0172:', 'WORKBENCH = "VRN2_Workbench_v0108.py"   # v0174: ENG049 template lock · data-tab display rules · Source column · v0172:')
rep('''    assert WORKBENCH == "VRN2_Workbench_v0107.py"''',
    '''    wb108 = selftest_source("VRN2_Workbench_v0108.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0108"' in wb108 and 'PRIOR_NAME = "VRN2_Workbench_v0107.py"' in wb108 and wb108.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    assert 'id="wb108-tpl"' in wb108 and "def freshness(" in wb108 and "def norm_period(" in wb108 and "def source_of(" in wb108 and "BROKER_ABBR = {" in wb108 and "@CSS_SHA256@" not in wb108
    assert WORKBENCH == "VRN2_Workbench_v0108.py"''')
rep('''    print("[PASS] v0172: HistoryAlign v0103''', '''    print("[PASS] v0174: Workbench v0108 (ENG049 template lock · Freshness · Ticker / YFinance + Name · broker abbreviations · YYYY / YYYY-MM / YYYY-MM-DD · Source last · exports append SOURCE) is the active Workbench")
    print("[PASS] v0172: HistoryAlign v0103''')
rep('return lamp, detail + " · launcher v0172"', 'return lamp, detail + " · launcher v0174"')
rep('note="VRN-2 private runtime; exact ship v0162 (launcher v0172 · HistoryAlign v0103 typed Parquet · ConsensusJoin v0107 UPSIDE_ADJ · Workbench v0107 Basic merged view · no MOPS);',
    'note="VRN-2 private runtime; exact ship v0163 (launcher v0174 · Workbench v0108 template lock + Source · HistoryAlign v0103 · ConsensusJoin v0107 UPSIDE_ADJ · no MOPS);')
rep('print("NEXT: [%s] VRN-2 v0172 · rc %s', 'print("NEXT: [%s] VRN-2 v0174 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0174", len(s.splitlines()), "lines")
