const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch();
  const f = 'file://' + process.argv[2];
  for (const [name, w, h, scheme] of [['desk', 1366, 900, 'light'], ['dark', 1366, 900, 'dark'], ['phone', 390, 844, 'light']]) {
    const p = await b.newPage({ viewport: { width: w, height: h }, colorScheme: scheme });
    const errs = []; p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
    await p.goto(f); await p.screenshot({ path: name + '.png', fullPage: name !== 'dark' });
    const sw = await p.evaluate(() => document.documentElement.scrollWidth);
    await p.click('button[data-owner="VCGC"]'); const vis = await p.evaluate(() => [...document.querySelectorAll('#items tbody tr')].filter(r => r.style.display !== 'none').length);
    await p.fill('#q', 'MS-8358'); const vis2 = await p.evaluate(() => [...document.querySelectorAll('#items tbody tr')].filter(r => r.style.display !== 'none').length);
    console.log(name, 'scrollWidth', sw, 'VCGC rows', vis, 'VCGC+MS-8358', vis2, 'errors', JSON.stringify(errs));
    await p.close();
  }
  await b.close();
})();
