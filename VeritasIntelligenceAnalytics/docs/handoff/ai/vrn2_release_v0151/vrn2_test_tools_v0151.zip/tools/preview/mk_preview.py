import importlib.util, json, re, sys
from pathlib import Path
S = Path(sys.argv[1]); console = Path(sys.argv[2]); out = S / "v151/preview"
spec = importlib.util.spec_from_file_location("ra104", S / "v151/new/VRN2_RoundAll_v0104.py"); ra = importlib.util.module_from_spec(spec); spec.loader.exec_module(ra)
lines = console.read_text(encoding="utf-8").splitlines()[:356]
rows = []
for i, l in enumerate(lines):
    m = re.match(r"^\[(GREEN|YELLOW|RED|GRAY)\] (.*)$", l)
    if not m:
        if rows and l.startswith("       → "):
            rows[-1]["hint"] = l[9:]
        continue
    parts = m.group(2).split(" · ")
    k = 2 if parts[0] in ("⑤ 修", "⑥ 完成判定") and len(parts) > 2 else 1
    step, detail = " · ".join(parts[:k]), " · ".join(parts[k:])
    rows.append({"lamp": m.group(1), "step": step, "detail": detail, "hint": ""})
root = out / "VIA"; v2 = root / "VIA_Reports" / "vrn2"
(v2 / "market" / "vdf").mkdir(parents=True, exist_ok=True); (v2 / "consensus").mkdir(exist_ok=True)
(v2 / "market" / "vdf" / "last_error.txt").write_text("[ERROR] PermissionError: Existing VIA network bridge denied this request\n", encoding="utf-8")
(v2 / ra.RECEIPT).write_text(json.dumps({"rc": 2, "market": {"fetch_python": {"python": "C:\\Python313\\python.exe"}}}), encoding="utf-8")
(v2 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"no_coverage": {"6933": "404", "4171": "404"}}), encoding="utf-8")
(v2 / "VRN2_Workbench_latest.html").write_text("<p>wb</p>", encoding="utf-8")
ra.RESULTS[:] = rows
doc = ra.build_closeout(root, rows, {"at": "2026-10-29T20:35:43", "elapsed_s": 5957, "package": "C:\\Users\\tonyk\\Downloads\\VRN2_Closeout_v0151"}, Path("C:/Users/tonyk/Downloads/VRN2_PasteBack_20261029_203543.zip"), "C:/Users/tonyk/Downloads/VRN2_RoundAll_v0104.py")
print("rows", len(rows), "state", doc["state"], doc["state_text"], doc["per_owner"])
for it in doc["items"]:
    print("  %-6s %-6s %s | %s" % (it["owner"], it["lamp"], it["step"][:46], (it["why"] or "")[:70]))
print(doc["html"])
