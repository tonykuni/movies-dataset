"""VRN2_RoundAll_v0107.py = v0106 + 略過取套件時找讀得到的套件夾(含 <套件>_<時間> 新夾)· 不跑啟動器 / 自測就不需要套件 · 原套件夾讀不到時沿用既有的新夾。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v151/new/VRN2_RoundAll_v0106.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN2_RoundAll v0106 — ', '"""VRN2_RoundAll v0107 — ')
rep("v0106(桌機 2026-10-30 14:41 跑 v0105", r'''v0107(同日 · 給桌機 v0106 之前先補的兩個洞):
  · 略過取套件(--only report,closeout / --skip-package)時:v0106 只看 Downloads\\VRN2_Closeout_v0151 —— 桌機那個夾讀不到 → ① 黃 → 收尾頁又算「VRN-2 要修」。
    v0107 依序找 --package / VRN2_PACKAGE / Downloads\\<套件> / Downloads\\<套件>_<時間>(新的先)裡第一個讀得到啟動器的;這輪不跑啟動器也不自測 → 不需要套件(灰)。
  · 原套件夾讀不到時:v0106 每輪都再建一個 <套件>_<時間>(每個約 8 MB);v0107 先沿用既有的新夾(逐檔相符就直接用),都不行才建新的。

v0106(桌機 2026-10-30 14:41 跑 v0105''')
rep("用法:python VRN2_RoundAll_v0106.py", "用法:python VRN2_RoundAll_v0107.py")
rep('VERSION = "v0106"', 'VERSION = "v0107"')
# 1) 原夾用不了 → 先沿用既有的新夾
rep('''    try:
        r = install_package(z, PACKAGE_SHA256, pkg, rj)
    except OSError as error:
        alt = Path(pkg).with_name(Path(pkg).name + "_" + stamp())''', '''    try:
        r = install_package(z, PACKAGE_SHA256, pkg, rj)
    except OSError as error:
        for old in _alt_folders(pkg):                                         # v0107 先沿用既有的 <套件>_<時間>(逐檔相符就直接用)
            try:
                r = install_package(z, PACKAGE_SHA256, old, rj)
            except OSError:
                continue
            if r["lamp"] == "GREEN":
                r["detail"] += " · 原套件夾 %s 用不了(%s)→ 沿用 %s" % (pkg, type(error).__name__, old.name)
                say(r["lamp"], "① 套件", r["detail"] + ((" · 來源 " + how) if how else ""))
                return Path(r["pkg"])
        alt = Path(pkg).with_name(Path(pkg).name + "_" + stamp())''')
rep('''def _install_with_fallback(z: Path, rj, pkg: Path, how: str):''', '''def _alt_folders(pkg: Path) -> list:
    """v0107:<套件>_<時間> 新夾(新的先 · 不含 .bak_ 備份)。"""
    try:
        return sorted((p for p in Path(pkg).parent.glob(Path(pkg).name + "_*") if p.is_dir() and re.fullmatch(r"\\d{8}_\\d{6}", p.name[len(Path(pkg).name) + 1:])), key=_mtime, reverse=True)
    except OSError:
        return []


def find_package(args) -> Path | None:
    """v0107 略過取套件時用哪個套件夾:--package / VRN2_PACKAGE / Downloads\\\\<套件> / Downloads\\\\<套件>_<時間>(新的先)裡第一個讀得到啟動器的。"""
    first = [Path(x) for x in (args.package, os.environ.get("VRN2_PACKAGE")) if x]
    base = downloads() / PACKAGE
    for cand in first + [base] + _alt_folders(base):
        try:
            with (cand / LAUNCHER).open("rb") as fh:
                fh.read(1)
            return cand
        except OSError:
            continue
    return None


def _install_with_fallback(z: Path, rj, pkg: Path, how: str):''')
# 2) main:略過取套件
rep('''    else:
        cand = Path(args.package or os.environ.get("VRN2_PACKAGE") or (downloads() / PACKAGE))
        pkg = cand if (cand / LAUNCHER).is_file() else None
        say("GRAY" if pkg else "YELLOW", "① 套件", "略過取套件 · 用 %s" % (pkg or "(沒有套件夾)"))''', '''    else:
        pkg = find_package(args)                                                # v0107 找讀得到的套件夾 · 不跑啟動器 / 自測就不需要
        if pkg:
            say("GRAY", "① 套件", "略過取套件 · 用 %s" % pkg)
        elif want["run"] or want["selftest"]:
            say("YELLOW", "① 套件", "略過取套件 · 找不到讀得到啟動器的套件夾(--package / VRN2_PACKAGE / Downloads\\\\%s / %s_<時間>)" % (PACKAGE, PACKAGE), "拿掉 --skip-package / --only 讓它取套件")
        else:
            say("GRAY", "① 套件", "略過取套件 · 這輪不跑啟動器也不自測(只做 %s)· 不需要套件" % ",".join(s_ for s_ in STEPS if want[s_]))''')
# 3) 自測 ㊳ ㊴
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''', r'''        # ㊳ ㊴ v0107
        dl = Path(os.environ["VRN2_DOWNLOADS"])
        base = dl / PACKAGE
        base.mkdir(parents=True, exist_ok=True)
        (base / LAUNCHER).unlink(missing_ok=True)                            # 原夾讀不到啟動器(桌機:權限)
        older, newer = dl / (PACKAGE + "_20261030_100000"), dl / (PACKAGE + "_20261030_120000")
        for d_, ts_ in ((older, 1000), (newer, 2000)):
            d_.mkdir(exist_ok=True)
            (d_ / LAUNCHER).write_text("x", encoding="utf-8")
            os.utime(d_, (ts_, ts_))
        (dl / (PACKAGE + ".bak_20261030_130000")).mkdir(exist_ok=True)
        os.environ.pop("VRN2_PACKAGE", None)
        fp = find_package(type("Q", (), {"package": None})())
        alts = _alt_folders(base)
        chk("㊳ 略過取套件:原夾讀不到 → 用最新的 <套件>_<時間>(不碰 .bak_ 備份)· --package 優先", fp == newer and alts == [newer, older] and find_package(type("Q", (), {"package": str(older)})()) == older)
        shutil.rmtree(str(older)); shutil.rmtree(str(newer))
        real_install = g["install_package"]
        good = dl / (PACKAGE + "_20261030_140000")

        def install_alt(z_, want_, pkg_, rj_=None):
            if Path(pkg_) == base:
                raise PermissionError(13, "Permission denied", str(pkg_))
            return {"lamp": "GREEN", "detail": "本機已是 %s" % PACKAGE, "pkg": str(pkg_)}
        good.mkdir(exist_ok=True)
        before = sorted(p.name for p in dl.iterdir())
        RESULTS.clear()
        sys.stdout = io.StringIO()
        try:
            g["install_package"] = install_alt
            got_alt = _install_with_fallback(zp, None, base, "GitHub x")
        finally:
            g["install_package"] = real_install
            sys.stdout = sys_stdout
        chk("㊴ 原套件夾用不了 → 先沿用既有的 <套件>_<時間>(不再每輪多建一個 8 MB 的新夾)", got_alt == good and sorted(p.name for p in dl.iterdir()) == before and "沿用" in RESULTS[-1]["detail"])
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0106.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0107.py"').replace('"VRN2_RoundAll_v0106.py" in html_', '"VRN2_RoundAll_v0107.py" in html_')
d0 = s.index('"""VRN2_RoundAll v0107'); d1 = s.index('"""', d0 + 3)
assert not re.search(r"(?<!\\)\\(?![\\])", s[d0:d1].replace("\\\\", "")), "single backslash in docstring"
(S / "v151/new/VRN2_RoundAll_v0107.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0107 lines", s.count("\n"))
