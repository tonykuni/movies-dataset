"""ActivateVRN-2_v0151.py = v0150 + ⑪ IndependentVerifier v0113(runtime 最新 · BADITEM 第二種讀法)· 收尾輪(操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」)。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v150/new/ActivateVRN-2_v0150.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0150: v0149 entry + fixes from the desktop run of VRN2_RoundAll_v0102 (2026-10-29 19:00 · red 0 · yellow 20 · 5957 s).',
    '"""VRN-2 v0151: v0150 entry + the close-out round (operator 2026-10-29: "solve the remaining system issues · HTML U/I · CLOSE OUT").\n\n'
    ' - step 11 VRN2_IndependentVerifier_v0113 (latest in the runtime): the desktop\'s annual-data BADITEM 19 (MS-3665 / MS-8358 / MS-8210 /\n'
    '   Daiwa aspeed · "ModelWare net inc (NT $ mn)" · "Prior EPS (NT$)**" · "DPS", every value on the page) came from the character-box reader\n'
    '   only; an item is now read a second way (PDFium whole-page text + pdfplumber lines) before it is called "not on this page". Fabricated /\n'
    '   renamed items stay BADITEM with the closest source line in the note; a value not on the page stays FAIL with the item\'s source line.\n'
    ' - VRN2_RoundAll_v0104 writes the close-out page VIA_Reports/vrn2/VRN2_CloseoutUI_latest.html (every open item with its owner:\n'
    '   VRN-2 / VCGC / human check / data source / reminder) — this launcher\'s receipt is one of its inputs; nothing here changes how steps run.\n'
    ' Runtime v0151 = runtime v0150 (186 members byte-identical) + VRN2_IndependentVerifier_v0113.\n\n'
    'v0150: v0149 entry + fixes from the desktop run of VRN2_RoundAll_v0102 (2026-10-29 19:00 · red 0 · yellow 20 · 5957 s).')
rep('VERSION = "ActivateVRN-2 v0150"', 'VERSION = "ActivateVRN-2 v0151"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0150.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0151.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0150.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0151.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0150.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0151.json"')
rep('launcher = root / "package" / "ActivateVRN-2_v0150.py"', 'launcher = root / "package" / "ActivateVRN-2_v0151.py"')
rep('return lamp, detail + " · launcher v0150"', 'return lamp, detail + " · launcher v0151"')
rep('print("NEXT: [%s] VRN-2 v0150 · rc %s', 'print("NEXT: [%s] VRN-2 v0151 · rc %s')
rep('''    print("[PASS] v0150: ConsensusJoin v0102''', r'''    verifier = selftest_source("VRN2_IndependentVerifier_v0113.py").read_text(encoding="utf-8")
    assert 'VERSION = "VRN2_IndependentVerifier_v0113"' in verifier and "def item_on_page(" in verifier and "PRIOR.verify_fin = verify_fin" in verifier
    assert 'PRIOR = load("independent_v0113_financial_core", "VRN2_IndependentVerifier_v0105.py")' in verifier and 'if sys.argv[1:2] == ["--shard"]:' in verifier
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            ivs = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN2_IndependentVerifier_v\d{4}\.py", n))
        assert ivs[-1] == "VRN2_IndependentVerifier_v0113.py" and "VRN2_IndependentVerifier_v0112.py" in ivs, ivs[-3:]
    print("[PASS] v0151: runtime's newest IndependentVerifier = v0113 (BADITEM read a second way before 'item not on this page' · structural copy, its own --shard) · v0112 kept")
    print("[PASS] v0150: ConsensusJoin v0102''')
(S / "v151/new").mkdir(parents=True, exist_ok=True)
(S / "v151/new/ActivateVRN-2_v0151.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0151 lines", s.count("\n"))
