"""VRN2_RoundAll_v0104.py = v0103 + 收尾輪(操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」):⑧ 收尾頁 · Combined 空格照原因分 · 套件 v0151。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v150/new/VRN2_RoundAll_v0103.py").read_text(encoding="utf-8")
start = src.index('"""VRN2_RoundAll v0103')
end = src.index('"""', start + 3) + 3
head, doc, body = src[:start], src[start:end], src[end:]
at = doc.index("v0103(桌機 2026-10-29 19:00")
gen = doc.index("操作員令(2026-10-29)")
new_head = doc[:at].replace('"""VRN2_RoundAll v0103 — 一支 Python 跑完 VRN-2 一輪:取套件 → 環境診斷 → 全部自測 → 跑啟動器 → 自動修 → 除錯報告 → 貼回包。',
                            '"""VRN2_RoundAll v0104 — 一支 Python 跑完 VRN-2 一輪:取套件 → 環境診斷 → 全部自測 → 跑啟動器 → 自動修 → 除錯報告 → 收尾頁(HTML U/I)→ 貼回包。', 1)
assert new_head != doc[:at]
v0104_part = r'''v0104(操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」· 桌機 RoundAll v0102 貼回 紅 0 黃 20):
  · 套件 v0151(啟動器 v0151 · runtime v0151 = v0150 的 186 個成員不動 + IndependentVerifier v0113)。
  · 驗證器 v0113(⑪):年度數據 BADITEM 19(MS-3665 / MS-8358 / MS-8210 / Daiwa aspeed ·「ModelWare net inc (NT $ mn)」「Prior EPS (NT$)**」「DPS」,
    值都在該頁)只有字元框讀法說「科目本頁原文沒有」—— 跟 v0112 修的側欄同一個讀法;現在先用第二種讀法(PDFium 整頁文字 + pdfplumber 文字行)找科目
    (整個科目 · 折行 · 兩個字以上的科目字依序在三列內)才判 BADITEM;造假 / 改名的科目兩種讀法都找不到 → 照樣 BADITEM,註記帶原文最像的那一列。
  · ⑧ 收尾頁(新):VIA_Reports\\vrn2\\VRN2_CloseoutUI_latest.html(+ .json)—— 每一列非綠結果判負責方:VRN-2 要修 / 交 VCGC / 人工核對 /
    資料源沒有 / 提醒(不擋)/ 彙總;結案狀態 OPEN(VRN-2 還有要修)> BLOCKED(等 VCGC)> REVIEW(等人工)> DATA_GAP(外部來源沒有 · 已附證據)> PASS。
    BLOCKED / REVIEW / DATA_GAP 都不是成功;認不出來的一律算 VRN-2(寧可未結案)。頁面:燈號數 · 結案判定 · 待辦表(依負責方篩 · 搜尋)· 這輪數據 ·
    檔案連結(Workbench / U/I / 貼回包 / 收據 / 驗證摘要 / 證據 / 品質矩陣)· 下次指令(一鍵複製)· 不連外 · 淺 / 深色。跑完在 Windows 自動開(--no-open / VRN2_NO_UI=1 不開)。
  · ⑥ Combined 冊空格照原因分:原文沒有目標價(不是缺)· 沒有市場資料 · 報告日前沒有日資料 · 鉅亨沒有這檔 FactSet 頁(404)· 共識有這檔但來源沒有這欄;
    只剩「原文沒有目標價」= 綠(v0103 把報告本來就沒有目標價的 15 列也算成缺)。
  · ⑥ ⑪ 驗證器版本:v0113 以前 → 黃(BADITEM 只用字元框讀法)。

'''
general = doc[gen:]
general = general.replace("這些都在 VRN-2 套件 v0150 裡", "這些都在 VRN-2 套件 v0151 裡").replace("Downloads\\\\VRN2_Closeout_v0150", "Downloads\\\\VRN2_Closeout_v0151")
general = general.replace("ActivateVRN-2_v0150(", "ActivateVRN-2_v0151(").replace("用法:python VRN2_RoundAll_v0103.py", "用法:python VRN2_RoundAll_v0104.py")
general = general.replace("[--only package,preflight,selftest,run,fix,report,pasteback]", "[--only package,preflight,selftest,run,fix,report,closeout,pasteback]")
i7 = general.index("  ⑦ 貼回包:")
e7 = general.index("\n", i7) + 1
general = general[:e7] + "  ⑧ 收尾頁:VIA_Reports\\\\vrn2\\\\VRN2_CloseoutUI_latest.html(待辦依負責方 · 結案狀態 · 檔案連結 · 下次指令)· 貼回包也帶它(v0104)。\n" + general[e7:]
assert "v0150" not in general, re.findall(r".{20}v0150.{20}", general)
doc = new_head + v0104_part + doc[at:gen] + general
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
body = body.replace("v0150", "v0151")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0103"', 'VERSION = "v0104"')
rep('''               "VRN2_FailEvidence_latest.json", "consensus/factset_yfinance_consensus_quality_matrix.csv")''',
    '''               "VRN2_FailEvidence_latest.json", "consensus/factset_yfinance_consensus_quality_matrix.csv", "VRN2_CloseoutUI_latest.html", "VRN2_CloseoutUI_latest.json")''')
rep('''        new_enough = bool(num) and int(num.group(1)) >= 111''', '''        new_enough = bool(num) and int(num.group(1)) >= 113                # v0104:v0113 起 BADITEM 先用第二種讀法找科目''')
rep('''          "" if new_enough else "還是舊驗證器(行尾連字號會誤判)→ 套件 v0151 的 runtime 沒還原進 functional modules\\\\VRN2?看 ④ 的 runtime 那行")''',
    '''          "" if new_enough else "還是舊驗證器(v0113 以前:BADITEM 只用字元框讀法)→ 套件 v0151 的 runtime 沒還原進 functional modules\\\\VRN2?看 ④ 的 runtime 那行")''')
# Combined: empties by reason
rep('''        empty = {c: sum(1 for r in comb if not str(r.get(c) or "").strip()) for c in ("TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN", "%d_DILUTED_EPS_FACTSET" % n)}
        f("GREEN" if cols == want and not any(empty.values()) else "YELLOW", "Combined 冊", "%d 列 · 欄序%s · 空格 %s" % (len(comb), "正確" if cols == want else "不同(%s)" % [c for c in want if c not in cols][:4], json.dumps(empty, ensure_ascii=False)),
          "" if not any(empty.values()) else "調整後目標價空 = ⑥e 市場資料缺;FactSet / YFinance / EPS 空 = ⑥f 共識缺(看 STATUS 欄)")''',
    '''        empty = {c: sum(1 for r in comb if not str(r.get(c) or "").strip()) for c in ("TARGET_PRICE(ADJ)", "FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN", "%d_DILUTED_EPS_FACTSET" % n)}
        cctx = closeout_context(root)                                     # v0104 空格照原因分(原文沒有目標價不是缺)
        gaps, gap_owner = cctx["combined_gaps"], cctx["combined_owner"]
        f("GREEN" if cols == want and gap_owner is None else "YELLOW", "Combined 冊", "%d 列 · 欄序%s · 空格 %s%s" % (len(comb), "正確" if cols == want else "不同(%s)" % [c for c in want if c not in cols][:4], json.dumps(empty, ensure_ascii=False),
          (" · 原因 " + json.dumps(gaps, ensure_ascii=False)) if gaps else ""),
          "" if gap_owner is None else "原文沒有目標價 = 不是缺;沒有市場資料 = ⑥e;鉅亨 404 / 來源沒有這欄 = 資料源本來沒有;其他看 STATUS 欄")''')
# closeout block before the paste-back section
block = (S / "v151/closeout_block.py").read_text(encoding="utf-8")
rep("# ===== 10. ⑦ 貼回包 =====\n", block + "# ===== 10. ⑦ 貼回包 =====\n")
rep('''def step_pasteback(root, transcript: Path) -> Path | None:
    dest = downloads()
    try:
        dest.mkdir(parents=True, exist_ok=True)
    except OSError:
        dest = Path(tempfile.gettempdir())
    zpath = dest / ("VRN2_PasteBack_%s.zip" % stamp())''', '''def pasteback_path() -> Path:
    """v0104 貼回包路徑先定好(收尾頁要連到它):Downloads 建不了 → TEMP。"""
    dest = downloads()
    try:
        dest.mkdir(parents=True, exist_ok=True)
    except OSError:
        dest = Path(tempfile.gettempdir())
    return dest / ("VRN2_PasteBack_%s.zip" % stamp())


def step_pasteback(root, transcript: Path, zpath=None) -> Path | None:
    zpath = Path(zpath) if zpath else pasteback_path()''')
rep('STEPS = ("package", "preflight", "selftest", "run", "fix", "report", "pasteback")', 'STEPS = ("package", "preflight", "selftest", "run", "fix", "report", "closeout", "pasteback")')
rep('''    for s in ("package", "preflight", "selftest", "run", "fix", "pasteback"):''', '''    for s in ("package", "preflight", "selftest", "run", "fix", "closeout", "pasteback"):''')
rep('''    zpath = step_pasteback(root, transcript) if want["pasteback"] else None''', '''    zplan = pasteback_path() if want["pasteback"] else None
    page = step_closeout(root, summary, zplan) if (want["closeout"] and root) else None     # v0104 ⑧ 收尾頁(貼回包也帶它)
    zpath = step_pasteback(root, transcript, zplan) if want["pasteback"] else None''')
rep('''    if root and want["fix"] and not args.no_open and os.name == "nt":
        wb = Path(root) / "VIA_Reports" / "vrn2" / "VRN2_Workbench_latest.html"
        if wb.is_file() and any(r["step"].startswith("⑤ 修") for r in RESULTS):
            try:
                os.startfile(str(wb))  # type: ignore[attr-defined]
            except OSError:
                pass''', '''    if page:
        print("收尾頁 · %s · %s · %s → %s" % (page["state"], page["state_label"], page["state_text"], page["html"]))
    if root and not args.no_open and os.environ.get("VRN2_NO_UI") != "1" and os.name == "nt":    # v0104 開收尾頁(它連 Workbench);沒有收尾頁 → 照 v0103 開 Workbench
        target = Path(page["html"]) if page else Path(root) / "VIA_Reports" / "vrn2" / "VRN2_Workbench_latest.html"
        if target.is_file() and (page or (want["fix"] and any(r["step"].startswith("⑤ 修") for r in RESULTS))):
            try:
                os.startfile(str(target))  # type: ignore[attr-defined]
            except OSError:
                pass''')
rep('''    print("NEXT: [%s] %s · 紅 %d · 黃 %d · %s" % (overall, NAME, counts["RED"], counts["YELLOW"], ("貼回包 " + str(zpath)) if zpath else "(沒打包)"), flush=True)''',
    '''    print("NEXT: [%s] %s · 紅 %d · 黃 %d · %s%s" % (overall, NAME, counts["RED"], counts["YELLOW"], ("貼回包 " + str(zpath)) if zpath else "(沒打包)", (" · 收尾 %s" % page["state"]) if page else ""), flush=True)''')
# selftest: count checks + v0104 checks
rep('''    def chk(label, cond):
        print(("[PASS] " if cond else "[FAIL] ") + label, flush=True)
        if not cond:
            bad.append(label)

    class A:''', '''    ran = []

    def chk(label, cond):
        ran.append(label)
        print(("[PASS] " if cond else "[FAIL] ") + label, flush=True)
        if not cond:
            bad.append(label)

    class A:''')
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · 23 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(bad)), flush=True)''', r'''        # ㉓ ~ ㉗ v0104 收尾頁
        ctx0 = {"receipt": True, "mops_deny": True, "fetch_env_ok": True, "no_cov": {"6933", "4171"}, "gate_other": set(), "combined_gaps": {"TARGET_PRICE(ADJ)": {"原文沒有目標價": 15}}, "combined_owner": None}
        rows = [("YELLOW", "⑥ 收尾收據", "ActivateVRN-2 v0151 · rc 2 · 3654 秒", "彙總"), ("YELLOW", "⑥ ⑥e MOPS 財報被拒(VIA 網路工具 DENY)", "VDF 引擎打 MOPS", "VCGC"),
                ("YELLOW", "⑥ 步驟 ⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 Market", "擷取 RED:失敗 4 · rc2", "VCGC"), ("YELLOW", "⑥ 四點原文核對", "REVIEW_OCR · {\"PASS\": 204, \"OCR_PENDING\": 4}", "人工"),
                ("RED", "⑥ 四點原文核對", "FAIL · 3014TT 第 3 點", "VRN-2"), ("YELLOW", "⑥ ⑥f 共識閘 FAIL 列", "2 列 · 代號 4171,6933 · 404", "資料源"), ("YELLOW", "⑥ 完成判定 · ① 結果計算驗證", "黃 1(提醒 · 不擋完成)", "提醒"),
                ("YELLOW", "⑥ ⑪ 基本資料 FAIL 證據", "MS-8358 20260916.pdf · CURRENT_PRICE_REPORT FAIL", "人工"), ("RED", "⑥ 步驟 ⑪ 獨立驗證(背景 · 只讀)", "逾時 3600 秒", "VRN-2"),
                ("YELLOW", "⑥ Combined 冊", "52 列 · 欄序正確", "資料源"), ("RED", "③ 自測 · VRN2_Workbench_v0102.py", "rc 1", "VRN-2"), ("YELLOW", "⑥ 冪等閘", "NONDETERMINISTIC", "VRN-2"),
                ("YELLOW", "② 擷取 Python · VDF 版本界線(⑥e)", "沒有合 pandas>=2.2 的 Python", "VCGC"), ("GREEN", "⑥ Workbench U/I", "都在", None)]
        got = [(owner_of({"lamp": l, "step": st, "detail": d}, ctx0) or (None,))[0] for l, st, d, _ in rows]
        chk("㉓ 收尾頁負責方:收據 rc = 彙總 · MOPS DENY / 擷取環境 = VCGC · OCR / ⑪ 證據 = 人工 · 四點 FAIL / 驗證器逾時 / 自測紅 / 冪等 = VRN-2 · 404 = 資料源 · 不擋 = 提醒 · 綠 = 不列",
            got == [o for *_, o in rows])
        chk("㉓b 認不出來的一律 VRN-2(不把別人的事說成結案)· 沒有收據時「收尾收據」不算彙總", owner_of({"lamp": "YELLOW", "step": "⑥ 新的檢查", "detail": "?"}, ctx0)[0] == "VRN-2"
            and owner_of({"lamp": "RED", "step": "⑥ 收尾收據", "detail": "沒有 x"}, dict(ctx0, receipt=False))[0] == "VRN-2")
        st = [closeout_state([{"owner": o} for o in owners])[0] for owners in (["VRN-2", "VCGC"], ["VCGC", "人工", "資料源"], ["人工", "資料源"], ["資料源"], [])]
        chk("㉔ 結案狀態:VRN-2 有 → OPEN > VCGC → BLOCKED > 人工 → REVIEW > 資料源 → DATA_GAP > PASS(BLOCKED / REVIEW / DATA_GAP 不是成功)", st == ["OPEN", "BLOCKED", "REVIEW", "DATA_GAP", "PASS"])
        gaps, gown = combined_gaps([{"TICKER": "2330", "TARGET_PRICE": "", "TARGET_PRICE(ADJ)": "", "FACTSET_TARGET_PRICE_MEDIAN": "1450", "YFINANCE_TARGET_PRICE_MEDIAN": "1500", "2026_DILUTED_EPS_FACTSET": "60", "STATUS": ""},
                                    {"TICKER": "6933", "TARGET_PRICE": "100", "TARGET_PRICE(ADJ)": "", "FACTSET_TARGET_PRICE_MEDIAN": "", "YFINANCE_TARGET_PRICE_MEDIAN": "90", "2026_DILUTED_EPS_FACTSET": "",
                                     "STATUS": "TARGET_PRICE(ADJ): 缺:MISSING(報告日前沒有日資料) | CONSENSUS: 缺:沒有共識資料(⑥f) · 鉅亨沒有 FactSet 頁(404)"}], {"6933"}, True)
        only_src, own_src = combined_gaps([{"TICKER": "2330", "TARGET_PRICE": "", "TARGET_PRICE(ADJ)": "", "STATUS": ""}], set(), True)
        odd, own_odd = combined_gaps([{"TICKER": "2330", "TARGET_PRICE": "100", "TARGET_PRICE(ADJ)": "", "STATUS": "TARGET_PRICE(ADJ): 缺:除以零"}], set(), True)
        chk("㉕ Combined 空格照原因分:原文沒有目標價不是缺(只剩它 → 綠)· 報告日前沒有日資料 / 鉅亨 404 = 資料源 · 說不出原因 = VRN-2",
            gaps["TARGET_PRICE(ADJ)"] == {"原文沒有目標價": 1, "MISSING(報告日前沒有日資料)": 1} and gaps["FACTSET_TARGET_PRICE_MEDIAN"] == {"鉅亨沒有這檔的 FactSet 頁(404)": 1} and gown == "資料源"
            and own_src is None and only_src == {"TARGET_PRICE(ADJ)": {"原文沒有目標價": 1}} and own_odd == "VRN-2")
        RESULTS.clear()
        for l, st_, d, _ in rows:
            RESULTS.append({"lamp": l, "step": st_, "detail": d, "hint": ""})
        RESULTS.append({"lamp": "YELLOW", "step": "⑥ 輸出缺項", "detail": "<script>alert(1)</script> & \"q\"", "hint": ""})
        (v2 / "market" / "vdf").mkdir(parents=True, exist_ok=True)
        sys.stdout = io.StringIO()
        try:
            page = step_closeout(root, {"at": "2026-10-29T21:00:00", "elapsed_s": 12.5, "package": str(td / "pkg"), "transcript": str(td / "t.log")}, td / "home" / "Downloads" / "VRN2_PasteBack_x.zip", "C:/Users/x/Downloads/VRN2_RoundAll_v0104.py")
        finally:
            sys.stdout = sys_stdout
        html_ = (v2 / CLOSEOUT_HTML).read_text(encoding="utf-8")
        cj = jread(v2 / CLOSEOUT_JSON, {})
        chk("㉖ 收尾頁寫出 html + json:狀態 OPEN(有 VRN-2 項)· 負責方各類都在 · 待辦表 / 檔案 / 下次指令 / 複製鈕 · 不連外(沒有 http)· 內容跳脫(<script> 不會原樣出現)· 貼回包連結用先定好的路徑(之後才打包)",
            page is not None and page["state"] == "OPEN" and cj.get("state") == "OPEN" and not cj.get("vrn2_closed") and 'class="state s-OPEN"' in html_ and "VRN-2 要修" in html_ and "交 VCGC" in html_ and "人工核對" in html_
            and "資料源沒有" in html_ and 'id="items"' in html_ and "下次怎麼跑" in html_ and "VRN2_RoundAll_v0104.py" in html_ and "複製" in html_ and "http://" not in html_ and "https://" not in html_
            and "<script>alert(1)" not in html_ and "&lt;script&gt;alert(1)&lt;/script&gt;" in html_ and html_.count("<script>") == 1 and RESULTS[-1]["step"] == "⑧ 收尾頁(HTML U/I)" and RESULTS[-1]["lamp"] == "RED"
            and next(l for l in cj["links"] if l["label"].startswith("貼回包"))["exists"] and 'class="miss"><b>貼回包' not in html_)
        RESULTS.clear()
        RESULTS.append({"lamp": "YELLOW", "step": "⑥ ⑥e MOPS 財報被拒(VIA 網路工具 DENY)", "detail": "VDF 引擎打 MOPS", "hint": ""})
        RESULTS.append({"lamp": "YELLOW", "step": "⑥ 四點原文核對", "detail": "REVIEW_OCR", "hint": ""})
        sys.stdout = io.StringIO()
        try:
            page2 = step_closeout(root, {"at": "x"}, None)
            zp2 = step_pasteback(root, tr, td / "home" / "Downloads" / "VRN2_PasteBack_plan.zip")
        finally:
            sys.stdout = sys_stdout
        with zipfile.ZipFile(zp2) as z:
            names2 = set(z.namelist())
        chk("㉗ 只剩 VCGC + 人工 → BLOCKED(VRN-2 側可結案 · 不是成功)· 貼回包用先定好的路徑 · 帶收尾頁 html / json · --only 認 closeout",
            page2["state"] == "BLOCKED" and page2["vrn2_closed"] and zp2.name == "VRN2_PasteBack_plan.zip" and "vrn2/" + CLOSEOUT_HTML in names2 and "vrn2/" + CLOSEOUT_JSON in names2
            and "closeout" in STEPS and parse_args(["--only", "report,closeout"]).only == "report,closeout" and parse_args(["--skip-closeout"]).skip_closeout)
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''')
rep('hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0103.py"))', 'hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0104.py"))')
rep('''(vi / "VRN2_IndependentVerify_20261029_000000.json").write_text(json.dumps({"version": "VRN2_IndependentVerifier_v0111",''', '''(vi / "VRN2_IndependentVerify_20261029_000000.json").write_text(json.dumps({"version": "VRN2_IndependentVerifier_v0113",''')
rep("⑪ 驗證器版本 v0111 = 綠", "⑪ 驗證器版本 v0113 = 綠(v0104 起 v0113 以前算舊)")
(S / "v151/new/VRN2_RoundAll_v0104.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0104 lines", s.count("\n"))
