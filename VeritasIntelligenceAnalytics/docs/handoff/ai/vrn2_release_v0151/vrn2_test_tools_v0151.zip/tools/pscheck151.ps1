param($W)
function Sha([string]$s) { -join ([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($s)) | ForEach-Object { $_.ToString('x2') }) }
function Block($md, $lang) { [regex]::Match($md, "(?s)``````$lang`n(.*?)`n``````").Groups[1].Value }
foreach ($f in "$W/release151/Run-VRN2-v0151.ps1", "$W/release151/boot151.ps1", "$W/operator112/Run-VRN1-VRN2-v0112.ps1", "$W/operator112/boot_pair112.ps1", "$W/../round2/round.ps1") {
  $e = $null; [System.Management.Automation.Language.Parser]::ParseFile($f, [ref]$null, [ref]$e) | Out-Null; "$(Split-Path -Leaf $f) parse errors: $($e.Count)"
}
$md = [IO.File]::ReadAllText("$W/release151/VRN2_OneClick_v0151.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code = Block $md 'powershell'; $boot = Block $md 'text'; $H = [regex]::Match($boot, "\`$H  = '([0-9a-f]{64})'").Groups[1].Value
"vrn2 one-click v0151: code sha = boot H → $((Sha $code) -eq $H) ($((Sha $code).Substring(0,12)))"
$one = Block $md 'bat'; "one-liner decodes to boot → $(([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($one.Split(' ')[-1]))) -eq ($boot + "`n"))"
$want = [regex]::Match($code, "\`$Want   = '([0-9a-f]{64})'").Groups[1].Value
"package zip sha = \$Want → $(((Get-FileHash -LiteralPath "$W/release151/VRN2_Closeout_v0151.zip" -Algorithm SHA256).Hash.ToLower()) -eq $want)"
$md2 = [IO.File]::ReadAllText("$W/operator112/VRN1_VRN2_OneClick_v0112.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code2 = Block $md2 'powershell'; $boot2 = Block $md2 'text'; $H2b = [regex]::Match($boot2, "\`$H  = '([0-9a-f]{64})'").Groups[1].Value
"operator v0112: code sha = boot H → $((Sha $code2) -eq $H2b) ($((Sha $code2).Substring(0,12)))"
$H2 = [regex]::Match($code2, "\`$H2 = '([0-9a-f]{64})'").Groups[1].Value
"operator H2 = vrn2 one-click v0151 code sha → $($H2 -eq (Sha $code))"
"operator banner says v0112 → $($code2.Contains('操作員一鍵 v0112 · {0}'))"
$md3 = [IO.File]::ReadAllText("$W/release151/VRN2_LocalRound_v0101.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code3 = Block $md3 'powershell'
$hop = [regex]::Match($code3, "\`$H_OP = '([0-9a-f]{64})'").Groups[1].Value; $hcs = [regex]::Match($code3, "\`$H_CS = '([0-9a-f]{64})'").Groups[1].Value
"localround v0101 H_OP = operator v0112 code sha → $($hop -eq (Sha $code2))"
$md4 = [IO.File]::ReadAllText("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/VRN2_ChainShip_v0101.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code4 = Block $md4 'powershell'; "localround H_CS = chainship md v0101 code sha → $($hcs -eq (Sha $code4))"
$want4 = [regex]::Match($code4, '\$WANT = "([0-9a-f]{64})"').Groups[1].Value
"chainship md WANT = tool v0101 sha → $(((Get-FileHash -LiteralPath '/home/user/movies-dataset/VeritasIntelligenceAnalytics/functional modules/VRN/VRN2_ChainShip_v0101.py' -Algorithm SHA256).Hash.ToLower()) -eq $want4)"
$e = $null; [System.Management.Automation.Language.Parser]::ParseFile("$W/release151/boot_roundall.ps1", [ref]$null, [ref]$e) | Out-Null; "boot_roundall.ps1 parse errors: $($e.Count)"
$rb = [IO.File]::ReadAllText("$W/release151/boot_roundall.ps1", [Text.Encoding]::UTF8)
$rmd = [IO.File]::ReadAllText("$W/release151/VRN2_RoundAll_v0104.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$rlines = [regex]::Matches($rmd, "(?s)``````bat`n((pwsh|powershell) -NoProfile[^`n]*)`n``````") | ForEach-Object { $_.Groups[1].Value }
"roundall md has pwsh + powershell one-liners → $((@($rlines | Where-Object { $_.StartsWith('pwsh ') }).Count -eq 1) -and (@($rlines | Where-Object { $_.StartsWith('powershell ') }).Count -eq 1))"
foreach ($rone in $rlines) { "roundall one-liner ($($rone.Split(' ')[0])) decodes to boot_roundall → $(([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($rone.Split(' ')[-1]))) -eq $rb)" }
"oneline_roundall_pwsh.txt = md pwsh line → $(([IO.File]::ReadAllText("$W/release151/oneline_roundall_pwsh.txt").TrimEnd()) -eq @($rlines | Where-Object { $_.StartsWith('pwsh ') })[0])"
$rH = [regex]::Match($rb, "\`$H  = '([0-9a-f]{64})'").Groups[1].Value
$pyb = (New-Object Text.UTF8Encoding($false)).GetBytes(([IO.File]::ReadAllText("$W/release151/VRN2_RoundAll_v0104.py", [Text.Encoding]::UTF8) -replace "`r`n", "`n"))
$pysha = -join ([Security.Cryptography.SHA256]::Create().ComputeHash($pyb) | ForEach-Object { $_.ToString('x2') })
"roundall py sha (LF-normalised) = boot `$H → $($pysha -eq $rH) ($($pysha.Substring(0,12)))"
$pin = [regex]::Match([Text.Encoding]::UTF8.GetString($pyb), 'PACKAGE_SHA256 = "([0-9a-f]{64})"').Groups[1].Value
"roundall pinned package sha = zip sha → $($pin -eq ((Get-FileHash -LiteralPath "$W/release151/VRN2_Closeout_v0151.zip" -Algorithm SHA256).Hash.ToLower()))"
$crlf = [Text.Encoding]::UTF8.GetString($pyb) -replace "`n", "`r`n"; $crlfn = (New-Object Text.UTF8Encoding($false)).GetBytes(($crlf -replace "`r`n", "`n"))
"roundall CRLF checkout (git autocrlf) still verifies → $((-join ([Security.Cryptography.SHA256]::Create().ComputeHash($crlfn) | ForEach-Object { $_.ToString('x2') })) -eq $rH)"
