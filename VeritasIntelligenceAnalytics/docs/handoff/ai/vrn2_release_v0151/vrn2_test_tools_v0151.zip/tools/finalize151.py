"""收尾 v0151:results → VRN2_Release_v0151.json.results · VRN2_Verification_v0151.md(套件 zip 已定,不重算)。"""
import glob, json, re, zipfile
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v151")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def lines(p):
    try: return [l for l in Path(p).read_text(encoding="utf-8", errors="replace").splitlines() if "<Objs" not in l and "</S>" not in l and "<S N=" not in l]
    except OSError: return []
def grep(p, pat, all_=False):
    hits = [l for l in lines(p) if re.search(pat, l)]
    return hits if all_ else (hits[-1] if hits else "")
def esc(x): return str(x).replace("|", "\\|")
v2 = W / "t151/VIA/VIA_Reports/vrn2"
ra1 = W / "ra151_first.log"; ra2 = W / "ra151_fix.log"
top = lambda p: [l for l in lines(p) if re.match(r"^\[(GREEN|YELLOW|RED|GRAY)\] |^NEXT:|^總表|^收尾頁 ·", l)]
first_rows, fix_rows = top(ra1), top(ra2)
def count(rows):
    return {k: sum(1 for l in rows if l.startswith("[%s]" % k)) for k in ("GREEN", "YELLOW", "RED", "GRAY")}
reds1 = [l[:200] for l in first_rows if l.startswith("[RED]")]
st = j(v2 / "VRN2_OutputStore_latest.json", {}) or {}; hist = j(v2 / "VRN2_HistoryAlign_latest.json", {}) or {}
comb = j(v2 / "output/VRN2_Combined_latest.json", []) or []; cl = j(v2 / "VRN2_Closeout_v0151.json", {}) or {}
page = j(v2 / "VRN2_CloseoutUI_latest.json", {}) or {}
zips = sorted(glob.glob(str(W / "t151/home/Downloads/VRN2_PasteBack_*.zip")))
pz = zipfile.ZipFile(zips[-1]).namelist() if zips else []
selft = {n: grep(W / f, pat)[:220] for n, f, pat in (("VRN2_RoundAll_v0106(2026-10-30 14:41 貼回:收尾分類 · ⑪ 年度 FAIL 證據 · 安裝權限)", "roundall106_selftest.log", r"--selftest · .*不過 0"), ("VRN2_RoundAll_v0105(2026-10-30 · 檔被鎖不當掉)", "roundall105_selftest.log", r"--selftest · .*不過 0"), ("VRN2_RoundAll_v0104", "roundall104_selftest.log", r"--selftest · .*不過 0"),
                                                     ("VRN2_IndependentVerifier_v0113(VIA 樹內 · 含 v0105 30/30 · v0110 ~ v0112)", "iv113_selftest.log", r"\[PASS\] v0113"),
                                                     ("ActivateVRN-2_v0151(建置夾)", "ActivateVRN-2_v0151_selftest.log", r"\[PASS\] v0151"),
                                                     ("ActivateVRN-2_v0151(套件夾複本 · 不靠 ../new)", "ActivateVRN-2_v0151_selftest_iso.log", r"\[PASS\] v0151"))}
repro = {"⑪ BADITEM · 沙盒 4,378 筆原樣(v0105 核心 vs v0113)": grep(W / "regress113.log", r"^0\)")[:220],
         "⑪ BADITEM · 變造科目名 60 筆": grep(W / "regress113.log", r"^A\)")[:220],
         "⑪ BADITEM · 模擬桌機字元框把科目列讀壞 60 筆": grep(W / "regress113.log", r"^B\)")[:260],
         "⑪ 整支跑(平行子行程)v0112 vs v0113": " / ".join(lines(W / "regress113_full.log"))[:420],
         "收尾頁 · 用桌機 19:00 那輪 39 列結果試算": (lines(W / "closeout_preview_desktop0102.log") or [""])[0][:200],
         "收尾頁 · chromium(桌面 1366 / 深色 / 手機 390 · 篩選 · 搜尋)": " / ".join(lines(W / "closeout_ui_browser.log"))[:300],
         "收尾頁 · 端到端產生的那一頁(chromium)": " / ".join(lines(W / "closeout_ui_e2e.log"))[:300],
         "端到端:pwsh 一行指令取 RoundAll v0104": grep(ra1, r"\[VRN-2\] PowerShell")[:120] + " · " + re.sub(r" → .*", "", grep(ra1, r"SHA-256 .* 相符"))[:140],
         "端到端:⑧ 收尾頁": grep(ra1, r"⑧ 收尾頁")[:300],
         "PowerShell 7 原生一行(貼在 pwsh 視窗 · 沙盒實跑)": " / ".join(x[:150] for x in grep(W / "ps7/run_ok.log", r"\[GREEN\] VRN2_RoundAll_v0106|^收尾頁|RoundAll 結束碼|STILL-HERE", True)),
         "PowerShell 7 原生一行 · 雜湊不對": " / ".join(x[:150] for x in grep(W / "ps7/run_badsha.log", r"SHA-256 不對|STILL-HERE", True)),
         "桌機 2026-10-30 13:15 / 13:21:v0104 ① 讀本機套件 zip PermissionError [Errno 13] → Traceback(兩次 · 隔 6 分鐘)": "v0105 修(見下兩列 + 自測 ㉘ ~ ㉜)",
         "桌機 2026-10-30 14:41(RoundAll v0105):紅 0 · 黃 16 · ⑪ 基本資料 FAIL 0 · 年度 BADITEM 19 → 0(PRESENT 82 → 101)· 收尾 OPEN「VRN-2 2 項」= ② CPU 忙碌 + ⑥ Combined 1 格代號不是 4 碼 · icacls 舊 zip Access is denied": "v0106 修(自測 ㉝ ~ ㊲)",
         "v0106 · 用桌機 14:41 那 10 項重算收尾分類": (lines(W / "ps7/reclass106.log") or [""])[0][:300],
         "v0105 · 模擬本機 zip 讀不到(同一行程讓讀檔丟 PermissionError)": " / ".join(x[:170] for x in grep(W / "ps7/lock105.log", r"^\[(GRAY|GREEN)\] ①|⑦ 貼回包|^收尾頁", True)),
         "v0106 · PowerShell 7 原生一行(沙盒)": " / ".join(x[:150] for x in grep(W / "ps7/run106_ok.log", r"\[GREEN\] VRN2_RoundAll_v0106|^收尾頁|結束碼|STILL-HERE", True))}
c1, c2 = count(first_rows), count(fix_rows)
st_rows = [l for l in first_rows if "③ 自測 ·" in l]; st_green = sum(1 for l in st_rows if l.startswith("[GREEN]"))
red_names = sorted({re.sub(r"^\[RED\] ", "", l).split(" · ")[0] for l in reds1})
e2e = {"summary": "RoundAll 全流程 %s(綠 %d · 黃 %d · 紅 %d · 灰 %d)· ③ 自測 %d 支 · 綠 %d · 紅的步驟:%s · Combined %d 列 · 收尾頁 %s(%s)"
              % (re.sub(r" · 貼回包 .*", "", grep(ra1, r"^NEXT:")), c1["GREEN"], c1["YELLOW"], c1["RED"], c1["GRAY"], len(st_rows), st_green, " / ".join(red_names) or "無", len(comb),
                 grep(ra1, r"^收尾頁 ·")[len("收尾頁 · "):].split(" → ")[0][:120], "見 ⑧ 列"), "reds": reds1, "rows": first_rows}
fix = {"summary": "只修回合 %s(綠 %d · 黃 %d · 紅 %d):⑤ 計畫 %s · 收尾頁 %s"
              % (re.sub(r" · 貼回包 .*", "", grep(ra2, r"^NEXT:")), c2["GREEN"], c2["YELLOW"], c2["RED"], grep(ra2, r"⑤ 自動修計畫")[len("[計] ⑤ 自動修計畫:"):][:200], grep(ra2, r"^收尾頁 ·")[len("收尾頁 · "):].split(" → ")[0][:160]), "rows": fix_rows}
if not grep(ra1, r"^NEXT:"):
    e2e = {"summary": "端到端(pwsh 一行指令取 RoundAll v0104 跑全流程)推送時還在跑 · 跑完後下一個 commit 補進本紀錄", "reds": [], "rows": []}
if not grep(ra2, r"^NEXT:"):
    fix = {"summary": "只修回合推送時還沒跑 · 跑完後補", "rows": []}
R = {"selftests": selft, "pwsh_hash_chain": [l for l in lines(W / "pscheck151.log") if l.strip()],
     "roundall_e2e": e2e, "roundall_fix_pass": fix,
     "closeout_page_after_fix": {k: page.get(k) for k in ("state", "state_label", "state_text", "vrn2_closed", "per_owner", "counts")} | {"items": [(i.get("owner"), i.get("lamp"), i.get("step")) for i in page.get("items") or []]},
     "store_after_fix": {k: st.get(k) for k in ("lamp", "store_engine", "totals")}, "history_after_fix": {k: hist.get(k) for k in ("lamp", "why")},
     "receipt_roundall": cl.get("roundall"), "desktop_reproduction": repro, "pasteback_zip": {"name": Path(zips[-1]).name if zips else None, "members": len(pz), "has": [m for m in pz if m.endswith(("transcript.txt", "VRN2_RoundAll_latest.json", "VRN2_CloseoutUI_latest.html", "VRN2_CloseoutUI_latest.json", "VRN2_Closeout_v0151.before_roundall.json"))]},
     "oneclick_scenario_pwsh": {"rc": (W / "scen151.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen151.rc").exists() else "not run",
                                "first": grep(W / "scen151_first.log", r"③ 套件 v0151 就位|③ 本機已是 v0151")[:200], "again": grep(W / "scen151_again.log", r"③ 本機已是 v0151")[:200],
                                "tamper": grep(W / "scen151_tamper.log", r"③ 舊套件夾已改名備份")[:160], "closeout": grep(W / "scen151_first.log", r"⑧b 收尾收據 v0151")[:200], "roundall_hint": grep(W / "scen151_first.log", r"VRN2_RoundAll_v0106")[:160]},
     "not_claimed": ["Windows desktop run of v0151 / RoundAll v0104: not yet (next paste-back)",
                     "BADITEM 19 on the desktop: the real MS-3665 / MS-8358 / MS-8210 / Daiwa aspeed PDFs are only on the desktop (the container's same-named files are synthetic samples); v0113 is proven on the 14 real sandbox PDFs by garbling the item's row in the character-box cache only (59 / 59 back to PRESENT) and by fabricated items (60 / 60 stay BADITEM)",
                     "close-out owner rules are proven on the desktop 19:00 console rows and on the sandbox run; a step name the rules do not know is counted as VRN-2 (never as closed)",
                     "MOPS DENY: VIA locked network tool compliance; not changed (VCGC decision)",
                     "OCR_PENDING 4 (MQ-1560 image page) / annual gaps 3: human check, not automatable without the source",
                     "Windows-only paths (os.startfile opening the close-out page, winreg vrn2:// lookup) are exercised by code review and the posix equivalents only",
                     "known nit (next version): the receipt's 6f row keeps the launcher-time 'Combined YELLOW'; after step 5 rebuilt Combined with only 'no target price in the report' gaps, the close-out page still files that stale row under data source — it never changes OPEN / BLOCKED / REVIEW, but alone it would show DATA_GAP instead of PASS"]}
rel_p = W / "release151/VRN2_Release_v0151.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
md = ["# VRN-2 v0151 + VRN2_RoundAll_v0106 容器實測紀錄(2026-10-29 · 收尾輪)", "",
      "操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」(貼回的是桌機 19:00 跑 VRN2_RoundAll_v0102 的主控台 · v0150 已處理的不重做)→ v0151(見發行清單 `fixes` · `not_fixed_here`)。", "",
      "## 0. 桌機剩下的問題在容器重現 / 驗證", "", "| 項目 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有)") for k, v in repro.items()] + ["",
      "## 1. 自測", "", "| 檔 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有 PASS 行)") for k, v in selft.items()] + ["",
      "## 2. PowerShell 雜湊鏈(pwsh 7.4.6)", "", "```", *R["pwsh_hash_chain"], "```", "",
      "## 3. 端到端:一個指令(pwsh -EncodedCommand)在仿桌機沙盒取 RoundAll v0104 跑全流程(殼有 VIA_ROOT · envs 有退役環境 + 沒裝套件的 via_tw_fetch · 套件從假 GitHub 分支取 · 19 份真實樣本)", "",
      e2e["summary"], "", "```", *[l[:260] for l in first_rows], "```", "",
      "## 4. 只修回合(`--skip-package --skip-selftest --skip-run`,先放一份合成的市場資料)", "", fix["summary"], "", "```", *[l[:260] for l in fix_rows], "```", "",
      "| 項目 | 值 |", "|---|---|", "| 收尾頁(修後)| %s |" % esc(json.dumps(R["closeout_page_after_fix"], ensure_ascii=False)[:900]),
      "| 長線庫(修後)| %s |" % esc(json.dumps(R["store_after_fix"], ensure_ascii=False)), "| 收尾收據的 roundall 欄 | %s |" % esc(json.dumps(R["receipt_roundall"], ensure_ascii=False)[:500]),
      "| 貼回包 | %s |" % esc(json.dumps(R["pasteback_zip"], ensure_ascii=False)), "",
      "## 5. 一鍵 v0151 使用者情境(pwsh · 假 GitHub 分支 → 跑 → 再貼 → 竄改)", "", "| 項目 | 值 |", "|---|---|"] + ["| %s | %s |" % (k, esc(v)) for k, v in R["oneclick_scenario_pwsh"].items()] + ["",
      "## 6. 沒做到 / 沒驗到(照實)", ""] + ["- %s" % x for x in R["not_claimed"]]
(W / "release151/VRN2_Verification_v0151.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
print("finalize151 ok ·", e2e["summary"][:160], "·", fix["summary"][:160])
