# ===== 9b. ⑧ 收尾頁(v0104 · HTML U/I · CLOSE OUT)=====
CLOSEOUT_HTML = "VRN2_CloseoutUI_latest.html"
CLOSEOUT_JSON = "VRN2_CloseoutUI_latest.json"
OWNERS = (("VRN-2", "VRN-2 要修", "VRN-2 自己的程式 / 輸出還有問題 → 貼回包給 AI 修(出新版號 · 舊版不動)"),
          ("VCGC", "交 VCGC", "環境安裝 / 鎖版網路工具放行 / 核號是 VCGC 的決定 · VRN-2 只檢查、照規則不繞道"),
          ("人工", "人工核對", "影像頁 OCR 摘錄 · 驗證器標的待核對值 · 缺年度數據 → 先看原 PDF 再判(擷取錯 / 驗證器誤判 / 原文真的沒有)"),
          ("資料源", "資料源沒有", "外部來源本來就沒有(鉅亨沒有這檔的 FactSet 頁 404 · Yahoo / TWSE 沒有這天)· 已附證據 · 不是 VRN-2 的錯"),
          ("提醒", "提醒(不擋)", "管理器自己標「提醒 · 不擋完成」/ 剔除列帶理由在 Rejected 冊"),
          ("彙總", "彙總", "啟動器的 rc 由各步驟燈號而來 → 看分項"))
OWNER_RANK = {"VRN-2": 3, "VCGC": 2, "資料源": 1}
STATES = {"OPEN": ("未結案", "VRN-2 還有 %d 項要修"), "BLOCKED": ("等 VCGC", "VRN-2 側沒有待修 · %d 項等 VCGC 決定 / 安裝"),
          "REVIEW": ("等人工核對", "VRN-2 側沒有待修 · %d 項要人看原文"), "DATA_GAP": ("資料源缺口", "VRN-2 側結案 · %d 項是外部來源沒有(已附證據)"),
          "PASS": ("結案", "全綠(或只剩提醒)")}
_NO_PAGE = re.compile(r"statusCode=404|頁面或商品不存在|鉅亨沒有 FactSet 頁")


def combined_gaps(comb, no_cov=(), fetch_env_ok=None) -> tuple:
    """v0104 Combined 空格照原因分 → ({欄: {原因: 筆數}}, 負責方 | None):原文沒有目標價 = 不是缺(None)· 沒有市場資料 → 擷取環境不合就 VCGC、否則資料源 ·
    報告日前沒有日資料 / 沒有還原因子 → 資料源 · 共識沒有這檔(鉅亨 404)→ 資料源 · 共識缺 yfinance / via_tw_fetch → VCGC · 共識有這檔但來源沒有這欄 → 資料源 · 其他 → VRN-2。"""
    gaps, owner = {}, None
    eps = sorted(c for c in ((comb or [{}])[0] or {}) if re.fullmatch(r"\d{4}_DILUTED_EPS_FACTSET", str(c)))[:1]

    def add(col, why, who):
        nonlocal owner
        gaps.setdefault(col, {})
        gaps[col][why] = gaps[col].get(why, 0) + 1
        if who and (owner is None or OWNER_RANK[who] > OWNER_RANK[owner]):
            owner = who
    for r in comb or []:
        if not isinstance(r, dict):
            continue
        st = str(r.get("STATUS") or "")
        m0 = re.match(r"\s*(\d{4,6})", str(r.get("TICKER") or ""))
        code = m0.group(1) if m0 else ""
        if not str(r.get("TARGET_PRICE(ADJ)") or "").strip():
            if not str(r.get("TARGET_PRICE") or "").strip():
                add("TARGET_PRICE(ADJ)", "原文沒有目標價", None)
            else:
                m = re.search(r"TARGET_PRICE\(ADJ\): 缺:([^|]*)", st)
                why = m.group(1).strip() if m else "沒有說明"
                if "沒有市場資料" in why:
                    add("TARGET_PRICE(ADJ)", "沒有市場資料(⑥e)", "VCGC" if fetch_env_ok is False else "資料源")
                elif re.search(r"報告日前沒有日資料|MISSING|沒有目標價或還原因子", why):
                    add("TARGET_PRICE(ADJ)", why[:40], "資料源")
                else:
                    add("TARGET_PRICE(ADJ)", why[:40], "VRN-2")
        for col in ["FACTSET_TARGET_PRICE_MEDIAN", "YFINANCE_TARGET_PRICE_MEDIAN"] + eps:
            if col in r and not str(r.get(col) or "").strip():
                m = re.search(r"CONSENSUS: 缺:([^|]*)", st)
                if (code and code in no_cov) or _NO_PAGE.search(st):
                    add(col, "鉅亨沒有這檔的 FactSet 頁(404)", "資料源")
                elif m:
                    why = m.group(1).strip()
                    add(col, "共識缺:" + why[:40], "VCGC" if re.search(r"yfinance|via_tw_fetch|擷取環境", why) else "VRN-2")
                else:
                    add(col, "共識有這檔 · 來源沒有這欄", "資料源")
    return gaps, owner


def closeout_context(root) -> dict:
    """收尾頁判負責方要的事實(只讀):MOPS 被 VIA 網路工具 DENY · 擷取環境合不合 VDF 界線 · 鉅亨沒有 FactSet 頁的代號 · 共識閘別的不過 · Combined 空格原因。"""
    v2 = Path(root) / "VIA_Reports" / "vrn2" if root else Path(".")
    err = v2 / "market" / "vdf" / "last_error.txt"
    text = err.read_text(encoding="utf-8", errors="replace") if err.is_file() else ""
    receipt = jread(v2 / RECEIPT, {}) or {}
    fpick = (receipt.get("market") or {}).get("fetch_python")
    cons = jread(v2 / "consensus" / "VRN2_Consensus_latest.json", {}) or {}
    no_cov = {str(c) for c in (cons.get("no_coverage") or {})}
    other = set()
    for r in quality_fails(v2) if v2.is_dir() else []:
        (no_cov if _NO_PAGE.search(str(r.get("actual") or "") + " " + str(r.get("note") or "")) else other).add(str(r.get("code") or "").strip())
    ctx = {"receipt": bool(receipt), "mops_deny": "Existing VIA network bridge denied" in text, "fetch_env_ok": (bool(fpick.get("python")) if isinstance(fpick, dict) else None),
           "no_cov": no_cov - other, "gate_other": other}
    comb = jread(v2 / "output" / "VRN2_Combined_latest.json", None)
    ctx["combined_gaps"], ctx["combined_owner"] = combined_gaps(comb if isinstance(comb, list) else [], ctx["no_cov"], ctx["fetch_env_ok"])
    return ctx


def owner_of(row: dict, ctx: dict):
    """一列結果的負責方(綠 / 灰 → None)· 認不出來的一律 VRN-2(寧可把 VRN-2 留在未結案,也不把別人的事說成結案)。回 (負責方, 理由)。"""
    lamp, step, detail = row.get("lamp"), str(row.get("step", "")), str(row.get("detail", ""))
    if lamp in ("GREEN", "GRAY", None):
        return None
    text = step + " " + detail
    if ctx.get("receipt") and (step == "⑥ 收尾收據" and " rc " in detail or step.startswith("④ 跑啟動器") and re.search(r"rc [12] ", detail)):
        return "彙總", "啟動器 rc 由各步驟燈號合成 · 分項在下面各列"
    if "不擋完成" in detail or step.startswith("⑥ 完成判定 · 輸出值驗證"):
        return "提醒", "管理器標「提醒 · 不擋完成」/ 剔除列帶理由(output\\VRN2_Rejected_latest)"
    if re.search(r"③ 環境檢查|② VRN-2 套件|② 擷取 Python|⑥e 擷取 Python", step):
        return "VCGC", "缺套件 / 擷取環境不合 VDF 界線 → VCGC 安裝(VRN-2 只檢查 · 不 pip)"
    if re.search(r"輸出", step) and re.search(r"未選|未設定|沒有選", detail):
        return "人工", "在 Workbench 左欄「選擇輸出夾…」選一個(操作員決定)"
    if re.search(r"增量庫|Parquet 庫", step) and "pyarrow" in detail:
        return "VCGC", "沒有 duckdb → pyarrow 備援(資料照寫)· 裝 duckdb 交 VCGC"
    if re.search(r"MOPS|network bridge denied|網路工具 DENY", text):
        return "VCGC", "VIA 鎖版網路工具 DENY MOPS(公開資訊觀測站)→ 放不放行是 VCGC 的決定 · VDF / VRN-2 不繞道"
    if "⑥e" in step or step.startswith("⑥ 市場資料"):
        if ctx.get("fetch_env_ok") is False or re.search(r"沒有合 VDF|匯入失敗|缺 yfinance", detail):
            return "VCGC", "擷取環境不合 VDF 界線 → VCGC 建 via_tw_fetch(帶界線)"
        if step.startswith("⑥ 市場資料"):                          # 價格 / 還原價不經 MOPS:缺的檔是來源沒有
            return "資料源", "TWSE / TPEX / Yahoo 沒有這檔 / 這天的價格(MISSING 的檔看 market\\VRN2_Market_latest.json)"
        if ctx.get("mops_deny"):
            return "VCGC", "VDF 引擎打 MOPS 財報被 VIA 網路工具 DENY(價格照抓)→ VCGC 決定"
        return "VRN-2", ""
    if ("⑬b" in step or step.startswith("⑥ 歷史對齊")) and ctx.get("mops_deny"):
        return "VCGC", "沒有歷史財報 = MOPS 被 DENY 的結果"
    if step.startswith("⑥ Combined 冊"):
        if re.search(r"欄序不同|沒有 output", detail):
            return "VRN-2", "Combined 冊欄序不對 / 沒組出來"
        own = ctx.get("combined_owner")
        return (own or "資料源"), "空格原因:%s" % json.dumps(ctx.get("combined_gaps") or {}, ensure_ascii=False)[:200]
    if "⑥f" in step:
        if "Yahoo 代號" in step:
            return "資料源", "Yahoo 沒有這些代號"
        if "共識閘 FAIL 列" in step or re.search(r"共識 (YELLOW|RED)", detail):
            if re.search(r"缺 yfinance|擷取環境缺", detail) or ctx.get("fetch_env_ok") is False and "共識 GREEN" not in detail:
                return "VCGC", "共識要 yfinance(擷取環境)→ VCGC 建 via_tw_fetch"
            if ctx.get("no_cov") and not ctx.get("gate_other"):
                return "資料源", "鉅亨沒有 %s 的 FactSet 頁(404)· 其他代號閘照評" % ",".join(sorted(ctx["no_cov"]))
            return "VRN-2", ""
        if re.search(r"Combined (YELLOW|RED)", detail):
            return (ctx.get("combined_owner") or "資料源"), "Combined 空格原因:%s" % json.dumps(ctx.get("combined_gaps") or {}, ensure_ascii=False)[:200]
        return "VRN-2", ""
    if "四點" in step:
        if lamp == "RED" or "FAIL 摘錄" in step:
            return "VRN-2", "摘要器的摘錄跟原文不一樣(一字不差才算)"
        return "人工", "影像頁(OCR)摘錄要對原圖"
    if step.startswith("⑥ 輸出缺項") or step.startswith("⑥ 完成判定 · 輸出冊"):
        return "人工", "先看原 PDF:原文真的沒有年度數據 / 欄位就是沒有;有 → 貼回包給 AI"
    if "⑪" in step:
        if lamp == "RED" or re.search(r"逾時|Traceback", detail):
            return "VRN-2", "驗證器沒跑完(逾時 / 例外)"
        if "驗證器版本" in step:
            return "VRN-2", "還在用舊驗證器 → runtime 沒還原"
        return "人工", "驗證器標的待核對值:冊值 vs 原文那行(貼回包 VRN2_FailEvidence_latest.json · 獨立驗證摘要)"
    if "SSOT-ID" in step:
        return "VCGC", "等 VCGC 核號"
    return "VRN-2", ""


def closeout_state(items: list) -> tuple:
    """v0104 結案狀態:VRN-2 有項目 → OPEN · 否則有 VCGC → BLOCKED · 有人工 → REVIEW · 有資料源 → DATA_GAP · 都沒有 → PASS(提醒 / 彙總不算)。
    BLOCKED / REVIEW / DATA_GAP 都不是成功;VRN-2 側結案 = 不是 OPEN。"""
    n = {}
    for it in items:
        n[it["owner"]] = n.get(it["owner"], 0) + 1
    for state, owner in (("OPEN", "VRN-2"), ("BLOCKED", "VCGC"), ("REVIEW", "人工"), ("DATA_GAP", "資料源")):
        if n.get(owner):
            return state, STATES[state][1] % n[owner], n
    return "PASS", STATES["PASS"][1], n


def _h(t) -> str:
    import html as _html
    return _html.escape(str(t if t is not None else ""), quote=True)


def _uri(p) -> str:
    try:
        return Path(p).resolve().as_uri()
    except (ValueError, OSError):
        return ""


CLOSEOUT_CSS = """
:root{--bg:#f6f7f9;--card:#fff;--ink:#1b2430;--mute:#5d6b7c;--line:#dfe4ea;--accent:#2457c5;--green:#1f8a4c;--yellow:#a76a00;--red:#c0362c;--gray:#7b8794;
--chip-vrn2:#c0362c;--chip-vcgc:#6b4fbb;--chip-human:#a76a00;--chip-src:#2b7a9b;--chip-note:#7b8794;--chip-sum:#7b8794;--code:#eef1f5}
@media (prefers-color-scheme:dark){:root{--bg:#11161d;--card:#18202a;--ink:#e6ebf1;--mute:#9aa7b6;--line:#2a3542;--accent:#7aa2ff;--green:#4cc27f;--yellow:#e0a93a;--red:#ff7a6e;--gray:#8a96a3;
--chip-vrn2:#ff7a6e;--chip-vcgc:#a98bff;--chip-human:#e0a93a;--chip-src:#5fb8d9;--chip-note:#8a96a3;--chip-sum:#8a96a3;--code:#0f141a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 "Segoe UI","Microsoft JhengHei","PingFang TC","Noto Sans TC",system-ui,sans-serif}
header{display:flex;flex-wrap:wrap;gap:16px;align-items:center;justify-content:space-between;padding:18px 24px;background:var(--card);border-bottom:1px solid var(--line)}
h1{font-size:20px;margin:0}h2{font-size:16px;margin:0 0 10px}.sub{color:var(--mute);font-size:12px}
.brand{display:flex;gap:12px;align-items:center}.logo{white-space:nowrap;font-weight:700;letter-spacing:.5px;color:#fff;background:var(--accent);border-radius:8px;padding:6px 10px}
.state{border-radius:12px;padding:10px 16px;min-width:260px;border:2px solid currentColor}.state b{font-size:18px;display:block}.state span{font-size:12px}
.s-OPEN{color:var(--red)}.s-BLOCKED{color:var(--chip-vcgc)}.s-REVIEW{color:var(--yellow)}.s-DATA_GAP{color:var(--chip-src)}.s-PASS{color:var(--green)}
main{max-width:1280px;margin:0 auto;padding:18px 16px 40px;display:grid;grid-template-columns:minmax(0,1fr);gap:16px}
.panel{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px;min-width:0}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px}.kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:12px 14px}
.kpi .k{color:var(--mute);font-size:12px}.kpi .v{font-size:24px;font-weight:700;font-variant-numeric:tabular-nums}
.v.green{color:var(--green)}.v.yellow{color:var(--yellow)}.v.red{color:var(--red)}.v.gray{color:var(--gray)}
.owners{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin-top:10px}
.owner{border:1px solid var(--line);border-left:4px solid var(--c);border-radius:10px;padding:10px 12px}.owner b{font-size:15px}.owner .n{float:right;font-weight:700;font-size:18px;color:var(--c)}
.owner p{margin:6px 0 0;color:var(--mute);font-size:12px}
.chip{display:inline-block;border-radius:999px;padding:1px 9px;font-size:12px;font-weight:600;color:#fff;background:var(--c);white-space:nowrap}
.c-VRN-2{--c:var(--chip-vrn2)}.c-VCGC{--c:var(--chip-vcgc)}.c-人工{--c:var(--chip-human)}.c-資料源{--c:var(--chip-src)}.c-提醒{--c:var(--chip-note)}.c-彙總{--c:var(--chip-sum)}
.lamp{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:6px;vertical-align:middle}.l-GREEN{background:var(--green)}.l-YELLOW{background:var(--yellow)}.l-RED{background:var(--red)}.l-GRAY{background:var(--gray)}
.filters{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:10px}.filters button{border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:999px;padding:4px 12px;cursor:pointer;font:inherit}
.filters button.on{border-color:var(--accent);color:var(--accent);font-weight:600}.filters input{flex:1;min-width:180px;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:8px;padding:5px 10px;font:inherit}
.tablewrap{overflow-x:auto}table{border-collapse:collapse;width:100%}th,td{text-align:left;vertical-align:top;padding:7px 8px;border-bottom:1px solid var(--line)}th{font-size:12px;color:var(--mute);font-weight:600;white-space:nowrap}
td.lampcell{white-space:nowrap}td.detail{max-width:560px;word-break:break-word}td.next{max-width:360px;color:var(--mute);word-break:break-word}
dl.facts{display:grid;grid-template-columns:minmax(140px,220px) 1fr;gap:6px 14px;margin:0}dl.facts dt{color:var(--mute)}dl.facts dd{margin:0;word-break:break-word}
.links{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:8px}.links a,.links span{display:block;border:1px solid var(--line);border-radius:8px;padding:8px 10px;text-decoration:none;color:var(--ink)}
.links a:hover{border-color:var(--accent)}.links .miss{color:var(--mute);border-style:dashed}.links small{display:block;color:var(--mute);font-size:11px;word-break:break-all}
.cmd{display:flex;gap:8px;align-items:flex-start;margin:6px 0}.cmd code{flex:1;background:var(--code);border:1px solid var(--line);border-radius:8px;padding:8px 10px;font:12px/1.5 Consolas,"Cascadia Mono",monospace;word-break:break-all}
.cmd button{border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:8px;padding:6px 10px;cursor:pointer;font:inherit}
.note{color:var(--mute);font-size:12px;margin:10px 0 0}.big{font-size:15px;margin:0}.primary{display:inline-block;margin-top:10px;background:var(--accent);color:#fff;border-radius:8px;padding:6px 14px;text-decoration:none}
details summary{cursor:pointer;font-weight:600}footer{color:var(--mute);font-size:12px;text-align:center;padding:0 16px 24px}
@media (max-width:640px){header{padding:14px 16px}.state{min-width:0;width:100%}dl.facts{grid-template-columns:1fr}.kpis{grid-template-columns:repeat(3,minmax(0,1fr))}.kpi .v{font-size:20px}#items thead{display:none}#items,#items tbody,#items tr,#items td{display:block;width:100%}#items tr{border:1px solid var(--line);border-radius:10px;padding:8px 10px;margin-bottom:8px}#items td{border:none;padding:2px 0;max-width:none}#items td.lampcell{display:inline-block;width:auto;margin-left:8px}#items td:first-child{display:inline-block;width:auto}}
"""
CLOSEOUT_JS = """
(function(){var own='全部',q='';function apply(){document.querySelectorAll('#items tbody tr').forEach(function(tr){var ok=(own==='全部'||tr.dataset.owner===own)&&(!q||tr.textContent.toLowerCase().indexOf(q)>=0);tr.style.display=ok?'':'none';});}
document.querySelectorAll('.filters button').forEach(function(b){b.addEventListener('click',function(){own=b.dataset.owner;document.querySelectorAll('.filters button').forEach(function(x){x.classList.toggle('on',x===b);});apply();});});
var s=document.getElementById('q');if(s){s.addEventListener('input',function(){q=s.value.toLowerCase();apply();});}
document.querySelectorAll('.cmd button').forEach(function(b){b.addEventListener('click',function(){var t=b.parentNode.querySelector('code').textContent;function done(){b.textContent='已複製';setTimeout(function(){b.textContent='複製';},1500);}
if(navigator.clipboard){navigator.clipboard.writeText(t).then(done,function(){});}else{var a=document.createElement('textarea');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand('copy');done();}catch(e){}document.body.removeChild(a);}});});})();
"""


def build_closeout(root, results: list, summary: dict, zpath=None, script=None) -> dict:
    """v0104 收尾頁:RESULTS 每一列(非綠灰)判負責方 → 結案狀態 → VIA_Reports\\vrn2\\VRN2_CloseoutUI_latest.html + .json(只讀別系統的檔 · 只寫這兩個)。"""
    v2 = Path(root) / "VIA_Reports" / "vrn2"
    ctx = closeout_context(root)
    items = []
    for r in results:
        got = owner_of(r, ctx)
        if got:
            items.append(dict(r, owner=got[0], why=got[1]))
    real = [i for i in items if i["owner"] not in ("提醒", "彙總")]
    state, state_text, per_owner = closeout_state(real)
    counts = {k: sum(1 for r in results if r.get("lamp") == k) for k in ("GREEN", "YELLOW", "RED", "GRAY")}
    reps = sorted((v2 / "verify_independent").glob("VRN2_IndependentVerify_*.json"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    digests = sorted((v2 / "verify_independent").glob("*.digest.txt"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    links = [("Workbench(四本冊 · 去重矩陣 · 引擎狀態)", v2 / "VRN2_Workbench_latest.html"), ("VRN-2 U/I", v2 / "VRN2_UI_latest.html"),
             ("貼回包(上傳給 AI)", zpath), ("RoundAll 結果 json", v2 / "VRN2_RoundAll_latest.json"), ("啟動器收尾收據", v2 / RECEIPT),
             ("獨立驗證摘要", digests[-1] if digests else None), ("獨立驗證報告", reps[-1] if reps else None), ("⑪ FAIL 證據", v2 / "VRN2_FailEvidence_latest.json"),
             ("Combined 冊 csv", v2 / "output" / "VRN2_Combined_latest.csv"), ("剔除冊(帶理由)", v2 / "output" / "VRN2_Rejected_latest.csv"),
             ("共識品質矩陣", v2 / "consensus" / "factset_yfinance_consensus_quality_matrix.csv"), ("⑥e 擷取錯誤", v2 / "market" / "vdf" / "last_error.txt"),
             ("本輪逐字稿", summary.get("transcript"))]
    link_rows = [{"label": label, "path": str(p or ""), "exists": bool(p) and (Path(str(p)).is_file() or (zpath is not None and p is zpath))} for label, p in links]   # 貼回包在收尾頁之後才打包(路徑先定好)
    fact_steps = ("⑥ 完成判定 · 輸出冊", "⑥ ⑪ 驗證器版本", "⑥ 步驟 ⑪", "⑥ 四點原文核對", "⑥ 市場資料", "⑥ 步驟 ⑥f", "⑥ Combined 冊", "⑥ 歷史對齊", "⑥ 長線 Parquet 庫", "⑥ 階段耗時", "④ 跑啟動器")
    facts = [(r["step"], r["detail"]) for r in results if any(str(r.get("step", "")).startswith(s) for s in fact_steps)][:14]
    if ctx.get("combined_gaps"):
        facts.append(("Combined 空格原因", json.dumps(ctx["combined_gaps"], ensure_ascii=False)))
    cmds = rerun_hint(Path(script or __file__).resolve())[1:]
    doc = {"tool": "%s %s" % (NAME, VERSION), "at": summary.get("at") or _dt.datetime.now().isoformat(timespec="seconds"), "state": state, "state_label": STATES[state][0], "state_text": state_text,
           "vrn2_closed": state != "OPEN", "per_owner": per_owner, "counts": counts, "elapsed_s": summary.get("elapsed_s"), "package": summary.get("package"), "launcher": LAUNCHER,
           "items": [{k: i.get(k) for k in ("owner", "lamp", "step", "detail", "hint", "why")} for i in items], "links": link_rows, "facts": facts, "next": cmds, "context": {k: (sorted(v) if isinstance(v, set) else v) for k, v in ctx.items()},
           "rule": "BLOCKED / REVIEW / DATA_GAP 都不是成功;VRN-2 側結案 = 不是 OPEN。VCGC 的 closeout_lamp 才是 VCGC 驗收(四系統對等 · 只讀互看)。"}
    out_json, out_html = v2 / CLOSEOUT_JSON, v2 / CLOSEOUT_HTML
    v2.mkdir(parents=True, exist_ok=True)
    out_json.write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
    out_html.write_text(render_closeout(doc), encoding="utf-8")
    doc["html"], doc["json"] = str(out_html), str(out_json)
    return doc


def render_closeout(doc: dict) -> str:
    """收尾頁 HTML(單檔 · 不連外 · 淺 / 深色 · 手機寬度可讀)。"""
    c = doc["counts"]
    order = [o for o, _, _ in OWNERS]
    items = sorted(doc["items"], key=lambda i: (order.index(i["owner"]) if i["owner"] in order else 9, {"RED": 0, "YELLOW": 1}.get(i["lamp"], 2)))
    open_n = sum(1 for i in items if i["owner"] not in ("提醒", "彙總"))
    kpi = "".join('<div class="kpi"><div class="k">%s</div><div class="v %s">%s</div></div>' % (_h(k), cls, _h(v)) for k, v, cls in (
        ("綠", c.get("GREEN", 0), "green"), ("黃", c.get("YELLOW", 0), "yellow"), ("紅", c.get("RED", 0), "red"), ("灰", c.get("GRAY", 0), "gray"),
        ("待辦(不含提醒)", open_n, "red" if doc["state"] == "OPEN" else ("yellow" if open_n else "green")), ("耗時(秒)", "%.0f" % float(doc.get("elapsed_s") or 0), "")))
    owner_cards = "".join('<div class="owner c-%s"><span class="n">%d</span><b>%s</b><p>%s</p></div>' % (_h(o), doc["per_owner"].get(o, 0) if o not in ("提醒", "彙總") else sum(1 for i in items if i["owner"] == o), _h(label), _h(what))
                          for o, label, what in OWNERS if o != "彙總")
    buttons = '<button class="on" data-owner="全部">全部 %d</button>' % len(items) + "".join('<button data-owner="%s">%s %d</button>' % (_h(o), _h(label), sum(1 for i in items if i["owner"] == o)) for o, label, _ in OWNERS if any(i["owner"] == o for i in items))
    label_of = {o: label for o, label, _ in OWNERS}
    lamp_zh = {"RED": "紅", "YELLOW": "黃", "GREEN": "綠", "GRAY": "灰"}
    rows = "".join('<tr data-owner="%s"><td><span class="chip c-%s">%s</span></td><td class="lampcell"><span class="lamp l-%s"></span>%s</td><td>%s</td><td class="detail">%s</td><td class="next">%s</td></tr>' % (
        _h(i["owner"]), _h(i["owner"]), _h(label_of.get(i["owner"], i["owner"])), _h(i["lamp"]), _h(lamp_zh.get(i["lamp"], i["lamp"])), _h(i["step"]), _h(i["detail"][:700]), _h(" · ".join(x for x in (i.get("why"), i.get("hint")) if x)[:500]))
        for i in items) or '<tr><td colspan="5">沒有待辦</td></tr>'
    facts = "".join("<dt>%s</dt><dd>%s</dd>" % (_h(k), _h(str(v)[:600])) for k, v in doc["facts"])
    links = "".join(('<a href="%s"><b>%s</b><small>%s</small></a>' % (_h(_uri(l["path"])), _h(l["label"]), _h(l["path"]))) if l["exists"] else
                    '<span class="miss"><b>%s</b><small>%s</small></span>' % (_h(l["label"]), _h(l["path"] or "(這輪沒有)")) for l in doc["links"])
    wb = next((l for l in doc["links"] if l["label"].startswith("Workbench") and l["exists"]), None)
    cmds = "".join('<div class="cmd"><code>%s</code><button type="button">複製</button></div>' % _h(x) for x in doc["next"])
    return ("<!doctype html><html lang=\"zh-Hant\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
            "<title>VRN-2 收尾</title><style>%s</style></head><body>" % CLOSEOUT_CSS
            + '<header><div class="brand"><span class="logo">VRN-2</span><div><h1>收尾 · Close-out</h1><div class="sub">%s · %s · 套件 %s · 啟動器 %s</div></div></div>' % (_h(doc["at"]), _h(doc["tool"]), _h(Path(str(doc.get("package") or "")).name or "—"), _h(doc["launcher"]))
            + '<div class="state s-%s"><b>%s · %s</b><span>%s</span></div></header><main>' % (_h(doc["state"]), _h(doc["state"]), _h(doc["state_label"]), _h(doc["state_text"]))
            + '<section class="kpis">%s</section>' % kpi
            + '<section class="panel"><h2>結案判定</h2><p class="big">%s</p><div class="owners">%s</div><p class="note">%s</p>%s</section>' % (
                _h(("VRN-2 側可結案(不是 OPEN)· " if doc["vrn2_closed"] else "VRN-2 側未結案 · ") + doc["state_text"]), owner_cards, _h(doc["rule"]),
                ('<a class="primary" href="%s">開 Workbench</a>' % _h(_uri(wb["path"]))) if wb else "")
            + '<section class="panel"><h2>待辦(依負責方)</h2><div class="filters">%s<input id="q" type="search" placeholder="搜尋步驟 / 檔名 / 代號"></div>' % buttons
            + '<div class="tablewrap"><table id="items"><thead><tr><th>負責</th><th>燈</th><th>步驟</th><th>內容</th><th>為什麼是它 · 下一步</th></tr></thead><tbody>%s</tbody></table></div></section>' % rows
            + '<section class="panel"><h2>這輪的數據</h2><dl class="facts">%s</dl></section>' % (facts or "<dt>—</dt><dd>沒有(只跑了部分步驟)</dd>")
            + '<section class="panel"><h2>檔案</h2><div class="links">%s</div></section>' % links
            + '<section class="panel"><h2>下次怎麼跑</h2>%s<p class="note">第 1 行整輪 · 第 2 行不重跑只修 + 除錯 + 打包 · 第 3 行只診斷 + 自測 · 跑完把貼回包 zip 上傳給 AI</p></section>' % cmds
            + "</main><footer>VRN-2 自己的收尾頁 · 只讀其他系統的檔 · %s</footer><script>%s</script></body></html>" % (_h(doc["tool"]), CLOSEOUT_JS))


def step_closeout(root, summary: dict, zpath=None, script=None):
    try:
        doc = build_closeout(root, list(RESULTS), summary, zpath, script)
    except Exception as error:  # noqa: BLE001
        say("YELLOW", "⑧ 收尾頁", "沒寫成(%s: %s)" % (type(error).__name__, str(error)[:200]), "其他結果不受影響 · 看 VRN2_RoundAll_latest.json")
        return None
    po = doc["per_owner"]
    say("GREEN" if doc["state"] in ("PASS", "DATA_GAP") else ("RED" if doc["state"] == "OPEN" and any(i["lamp"] == "RED" and i["owner"] == "VRN-2" for i in doc["items"]) else "YELLOW"),
        "⑧ 收尾頁(HTML U/I)", "%s · %s · %s · VRN-2 %d · VCGC %d · 人工 %d · 資料源 %d → %s" % (doc["state"], doc["state_label"], doc["state_text"], po.get("VRN-2", 0), po.get("VCGC", 0), po.get("人工", 0), po.get("資料源", 0), doc["html"]),
        "BLOCKED / REVIEW / DATA_GAP 都不是成功 · 待辦依負責方分好 · VCGC 的 closeout_lamp 才是 VCGC 驗收")
    return doc


