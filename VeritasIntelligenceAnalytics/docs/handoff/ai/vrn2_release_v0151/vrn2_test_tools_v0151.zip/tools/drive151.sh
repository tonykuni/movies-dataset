#!/bin/bash
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=$S/v151; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
: > $W/ra151.rc
bash $W/run_roundall151.sh first
$S2/venv_vrn2/bin/python $S/v148/mk_market148.py "$W/t151/VIA/VIA_Reports/vrn2" > $W/mk_market151.log 2>&1
bash $W/run_roundall151.sh fix --skip-package --skip-selftest --skip-run --integrate yes
echo done-all >> $W/ra151.rc
