"""VRN2_RoundAll_v0106.py = v0105 + 桌機 2026-10-30 14:41 跑 v0105 的結果(紅 0 · 黃 16 · 收尾 OPEN「VRN-2 2 項」· icacls 對舊套件 zip:Access is denied)。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v151/new/VRN2_RoundAll_v0105.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN2_RoundAll v0105 — ', '"""VRN2_RoundAll v0106 — ')
rep("v0105(桌機 2026-10-30 13:15", r'''v0106(桌機 2026-10-30 14:41 跑 v0105:紅 0 · 黃 16 · 3977 秒 · ⑪ 基本資料 FAIL 0 · 年度 BADITEM 0 · 收尾 OPEN「VRN-2 2 項」):
  · 收尾頁的「VRN-2 2 項」都不是 VRN-2 的錯,是分類規則不夠細:「② CPU 忙碌 93%」= 別的程式佔 CPU(啟動器自動降路數 · 只會慢)→ 提醒;
    「⑥ Combined 冊」只因 1 格「基本資料冊代號不是 4 碼」規則認不出來 → 冊裡 TICKER 空白 = 人工核對(原文有沒有印代號)· 有值但不是台股 4 碼 = 資料源。
    Combined 每種空格原因列出是哪幾份檔(_files)。
  · ⑪ 年度數據 FAIL 證據(新):對每筆 FAIL 讀原 PDF 那一頁(PDFium + pdfplumber)找表頭(含該期間)與科目列,依欄位順序對齊 →
    原文該期間的值 = 冊值 → 驗證器讀法問題;≠ 冊值 → 擷取對錯欄(兩種都是 VRN-2 要修);對不齊 → 人工核對 → VRN2_FinFailEvidence_latest.json(進貼回包)。
  · ① 套件安裝不再把 Python 暫存夾整個搬進 Downloads:Python 3.13 在 Windows 建的暫存夾只給擁有者權限,搬過去權限會跟著走 —— 某次用系統管理員
    身分跑過,擁有者就變 Administrators,平常身分讀不到(桌機 icacls 對舊 zip:Access is denied)。改成在目的地正常建資料夾(繼承上一層權限)、逐檔複製。
    證據多一句:icacls 讀不到權限 → 權限不給目前使用者 · 怎麼清(以系統管理員身分 icacls /reset)。

v0105(桌機 2026-10-30 13:15''')
rep("用法:python VRN2_RoundAll_v0105.py", "用法:python VRN2_RoundAll_v0106.py")
rep('VERSION = "v0105"', 'VERSION = "v0106"')
rep('''               "VRN2_FailEvidence_latest.json", "consensus/factset_yfinance_consensus_quality_matrix.csv", "VRN2_CloseoutUI_latest.html", "VRN2_CloseoutUI_latest.json")''',
    '''               "VRN2_FailEvidence_latest.json", "consensus/factset_yfinance_consensus_quality_matrix.csv", "VRN2_CloseoutUI_latest.html", "VRN2_CloseoutUI_latest.json",
               "VRN2_FinFailEvidence_latest.json")''')
# 1) 安裝:不搬暫存夾(權限)
rep('''    pkg.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(stage), str(pkg))''', '''    pkg.parent.mkdir(parents=True, exist_ok=True)
    _place(stage, pkg)''')
rep('''def _copy_extras(pkg: Path, zip_path, release_json) -> str:''', '''def _place(stage: Path, pkg: Path) -> None:
    """v0106:不把暫存夾整個搬過去 —— Python 3.13 在 Windows 建的暫存夾(tempfile.mkdtemp)只給擁有者權限,搬過去權限跟著走;某次用系統管理員
    身分跑過,擁有者就是 Administrators,平常身分讀不到(桌機 icacls:Access is denied)。在目的地正常建資料夾(繼承上一層權限)· 逐檔複製內容 · 刪暫存。"""
    Path(pkg).mkdir(parents=True, exist_ok=False)
    for src in sorted(Path(stage).rglob("*")):
        dst = Path(pkg) / src.relative_to(stage)
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
        else:
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(str(src), str(dst))                            # 只複製內容(權限照目的地繼承)
    shutil.rmtree(str(stage), ignore_errors=True)


def _copy_extras(pkg: Path, zip_path, release_json) -> str:''')
rep('''                shutil.copy2(str(extra), str(Path(pkg) / Path(extra).name))
            except OSError as error:''', '''                shutil.copyfile(str(extra), str(Path(pkg) / Path(extra).name))      # v0106 只複製內容(權限照套件夾繼承)
            except OSError as error:''')
# 2) 證據:icacls 讀不到權限的說明
rep('''                bits.append("%s:%s" % (cmd[0], " ".join(l.strip() for l in out.splitlines() if l.strip())[:300]))''',
    '''                bits.append("%s:%s%s" % (cmd[0], " ".join(l.strip() for l in out.splitlines() if l.strip())[:300], acl_hint(out, path) if cmd[0] == "icacls" else ""))''')
rep('''def guarded(label: str, fn, *a, default=None, **kw):''', '''def acl_hint(text: str, path) -> str:
    """v0106:icacls 連權限都讀不到 → 權限不給目前的使用者(多半某次用系統管理員身分跑過 + 暫存夾權限被搬進來)· 怎麼清。"""
    if re.search(r"Access is denied|存取被拒|拒絕存取", str(text or "")):
        return (" →(權限不給目前的使用者:多半某次用系統管理員身分跑過,檔的擁有者變 Administrators。要清:以系統管理員身分開 PowerShell 跑 "
                "icacls \\"%s\\" /reset /T /C;不清也沒關係,本輪改從 GitHub 取)" % Path(path).parent)
    return ""


def guarded(label: str, fn, *a, default=None, **kw):''')
# 3) 收尾頁分類:② CPU → 提醒 · Combined 代號不是 4 碼 → 人工 / 資料源 · 列檔名
rep('''OWNER_RANK = {"VRN-2": 3, "VCGC": 2, "資料源": 1}''', '''OWNER_RANK = {"VRN-2": 3, "VCGC": 2, "人工": 1.5, "資料源": 1}''')
rep('''    gaps, owner = {}, None
    eps = sorted(''', '''    gaps, owner, files = {}, None, {}
    eps = sorted(''')
rep('''    def add(col, why, who):
        nonlocal owner
        gaps.setdefault(col, {})
        gaps[col][why] = gaps[col].get(why, 0) + 1''', '''    def add(col, why, who, fname=""):
        nonlocal owner
        gaps.setdefault(col, {})
        gaps[col][why] = gaps[col].get(why, 0) + 1
        if who and fname and len(files.setdefault(why, [])) < 6 and fname not in files[why]:   # v0106 哪幾份檔(原文沒有目標價不列)
            files[why].append(fname)''')
rep('''                if "沒有市場資料" in why:
                    add("TARGET_PRICE(ADJ)", "沒有市場資料(⑥e)", "VCGC" if fetch_env_ok is False else "資料源")
                elif re.search(r"報告日前沒有日資料|MISSING|沒有目標價或還原因子", why):
                    add("TARGET_PRICE(ADJ)", why[:40], "資料源")
                else:
                    add("TARGET_PRICE(ADJ)", why[:40], "VRN-2")''', '''                fname = str(r.get("FILENAME") or "")
                if "沒有市場資料" in why:
                    add("TARGET_PRICE(ADJ)", "沒有市場資料(⑥e)", "VCGC" if fetch_env_ok is False else "資料源", fname)
                elif "代號不是 4 碼" in why:                                  # v0106:冊裡 TICKER 空白 → 人工(原文有沒有印代號)· 有值但不是台股 4 碼 → 資料源
                    tk = str(r.get("TICKER") or "").strip()
                    add("TARGET_PRICE(ADJ)", "基本資料冊代號不是台股 4 碼(TICKER %s)" % (repr(tk) if tk else "空白"), "資料源" if tk else "人工", fname)
                elif re.search(r"報告日前沒有日資料|MISSING|沒有目標價或還原因子", why):
                    add("TARGET_PRICE(ADJ)", why[:40], "資料源", fname)
                else:
                    add("TARGET_PRICE(ADJ)", why[:40], "VRN-2", fname)''')
rep('''                if (code and code in no_cov) or _NO_PAGE.search(st):
                    add(col, "鉅亨沒有這檔的 FactSet 頁(404)", "資料源")
                elif m:
                    why = m.group(1).strip()
                    add(col, "共識缺:" + why[:40], "VCGC" if re.search(r"yfinance|via_tw_fetch|擷取環境", why) else "VRN-2")
                else:
                    add(col, "共識有這檔 · 來源沒有這欄", "資料源")
    return gaps, owner''', '''                fname = str(r.get("FILENAME") or "")
                if (code and code in no_cov) or _NO_PAGE.search(st):
                    add(col, "鉅亨沒有這檔的 FactSet 頁(404)", "資料源", fname)
                elif m:
                    why = m.group(1).strip()
                    add(col, "共識缺:" + why[:40], "VCGC" if re.search(r"yfinance|via_tw_fetch|擷取環境", why) else "VRN-2", fname)
                else:
                    add(col, "共識有這檔 · 來源沒有這欄", "資料源", fname)
    if files:
        gaps["_files"] = files
    return gaps, owner''')
rep('''    if lamp in ("GREEN", "GRAY", None):
        return None
    text = step + " " + detail''', '''    if lamp in ("GREEN", "GRAY", None):
        return None
    text = step + " " + detail
    if step.startswith("② CPU"):                                             # v0106
        return "提醒", "CPU 被別的程式佔用 · 啟動器自動降平行路數(只會慢 · 不影響結果)"''')
rep('''    if "⑪" in step:
        if lamp == "RED" or re.search(r"逾時|Traceback", detail):''', '''    if "⑪" in step:
        if "年度數據 FAIL 證據" in step and re.search(r"擷取對錯欄|驗證器讀法", step):   # v0106:原文對齊得出結論 → VRN-2 要修(擷取或驗證器)
            return "VRN-2", "原文表頭 + 科目列依欄位對齊得出結論(見內容)· 擷取對錯欄 → 改擷取;冊值 = 原文 → 改驗證器"
        if lamp == "RED" or re.search(r"逾時|Traceback", detail):''')
# 4) ⑪ 年度數據 FAIL 證據
rep('''EVIDENCE_FIELDS = (''', r'''FIN_EVIDENCE_PY = r"""
import json, re, sys
pdf, page, item, period, value = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4], sys.argv[5]
words = [w for w in re.findall(r"[a-z]+|\d+|[\u3400-\u9fff]+", item.lower()) if len(w) >= 2][:3]
PER = re.compile(r"^(?:fy)?(?:(?:19|20)\d{2}[aefp]?|\d{2}[aefp])$", re.I)
VAL = re.compile(r"^(?:\(?-?[\d,]*\.?\d+\)?%?|n\.?a\.?|n/a|nm|n\.m\.|-+|–|—)$", re.I)
def key(t):
    d = re.sub(r"\D", "", t); l = re.sub(r"[^aefp]", "", t.lower())
    return (d[-2:], l)
want = key(period)
def norm(v):
    return re.sub(r"[\s,]", "", v.lower()).rstrip(".")
out = []
def scan(lines, how):
    heads, items = [], []
    for line in lines:
        toks = line.split()
        pers = [t for t in toks if PER.match(t)]
        if len(pers) >= 2 and any(key(t) == want or (key(t)[0] == want[0] and not want[1]) for t in pers):
            heads.append((line, pers))
        low = line.lower()
        if words and all(w in low for w in words):
            items.append((line, toks))
    for line, pers in heads[-2:]:
        out.append({"how": how, "kind": "header", "line": line.strip()[:220]})
    for line, toks in items[:3]:
        out.append({"how": how, "kind": "item", "line": line.strip()[:220]})
    if heads and items:
        line, pers = heads[-1]
        idx = next((i for i, t in enumerate(pers) if key(t) == want), None)
        if idx is None:
            idx = next((i for i, t in enumerate(pers) if key(t)[0] == want[0]), None)
        for iline, toks in items[:1]:
            vals = [t for t in toks if VAL.match(t)]
            if idx is not None and len(vals) == len(pers):
                at = vals[idx]
                out.append({"how": how, "kind": "aligned", "periods": pers, "values": vals, "at": at, "match": norm(at) == norm(value)})
            else:
                out.append({"how": how, "kind": "unaligned", "periods": pers, "values": vals})
for how, get in (("pdfium", "pdfium"), ("pdfplumber", "pdfplumber")):
    try:
        if get == "pdfium":
            import pypdfium2 as pdfium
            doc = pdfium.PdfDocument(pdf)
            lines = doc[page - 1].get_textpage().get_text_range().replace("\r", "\n").split("\n") if 1 <= page <= len(doc) else []
        else:
            import pdfplumber
            with pdfplumber.open(pdf) as d:
                lines = (d.pages[page - 1].extract_text() or "").split("\n") if 1 <= page <= len(d.pages) else []
        scan(lines, how)
    except Exception as error:
        out.append({"how": how, "error": "%s: %s" % (type(error).__name__, str(error)[:120])})
print(json.dumps(out[:24], ensure_ascii=False))
"""


def fin_fail_evidence(root: Path, vpy=None) -> list:
    """v0106:⑪ 年度數據 FAIL(值不在該頁)的證據 —— 讀原 PDF 那一頁找表頭(含該期間)與科目列,依欄位順序對齊 → 原文該期間的值 vs 冊值 →
    VRN2_FinFailEvidence_latest.json(進貼回包)。只讀。"""
    v2 = Path(root) / "VIA_Reports" / "vrn2"
    reps = sorted((v2 / "verify_independent").glob("VRN2_IndependentVerify_*.json"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    report = jread(reps[-1], {}) if reps else {}
    src_dir = (jread(v2 / "VRN2_Input_latest.json", {}) or {}).get("source_dir") or ""
    out = []
    for r in [x for x in (report or {}).get("fin_bad") or [] if x.get("_V") == "FAIL"][:8]:
        name = str(r.get("FILENAME"))
        pdf = next((p for p in (v2 / "scope_in" / name, Path(src_dir) / name if src_dir else None) if p and p.is_file()), None)
        lines = []
        if pdf and vpy:
            try:
                done = subprocess.run([vpy, "-X", "utf8", "-c", FIN_EVIDENCE_PY, str(pdf), str(r.get("PAGE") or 1), str(r.get("ITEM") or ""), str(r.get("PERIOD") or ""), str(r.get("VALUE") or "")],
                                      capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180)
                lines = json.loads((done.stdout.strip().splitlines() or ["[]"])[-1])
            except Exception as error:  # noqa: BLE001
                lines = [{"error": "%s: %s" % (type(error).__name__, str(error)[:160])}]
        out.append({"file": name, "page": r.get("PAGE"), "item": r.get("ITEM"), "period": r.get("PERIOD"), "value": r.get("VALUE"), "note": r.get("_N"), "pdf": str(pdf or ""),
                    "lines": lines if pdf else [{"error": "找不到原檔(scope_in / 來源夾)"}]})
    if out:
        try:
            (v2 / "VRN2_FinFailEvidence_latest.json").write_text(json.dumps({"at": _dt.datetime.now().isoformat(timespec="seconds"), "verifier": (report or {}).get("version"), "rows": out}, ensure_ascii=False, indent=1), encoding="utf-8")
        except OSError:
            pass
    return out


EVIDENCE_FIELDS = (''')
rep('''    digests = sorted((v2 / "verify_independent").glob("*.digest.txt"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    if digests:
        head = digests[-1].read_text''', '''    for ev in fin_fail_evidence(root, vpy):                               # v0106 ⑪ 年度數據 FAIL:原文表頭 + 科目列對齊
        al = next((x for x in ev["lines"] if x.get("kind") == "aligned"), None)
        heads = [x["line"] for x in ev["lines"] if x.get("kind") == "header"][:1]
        items = [x["line"] for x in ev["lines"] if x.get("kind") == "item"][:1]
        err = next((x["error"] for x in ev["lines"] if x.get("error")), "")
        tag = "" if not al else ("(驗證器讀法 · 原文相符)" if al["match"] else "(擷取對錯欄)")
        verdict = ("原文 %s 這一欄是 %r(冊值 %r)→ %s" % (ev["period"], al["at"], ev["value"], "冊值 = 原文,是驗證器讀法沒找到" if al["match"] else "冊值 ≠ 原文,擷取對錯欄")) if al else "原文表頭與科目列對不齊(欄數不同或找不到)· 要人看"
        f("YELLOW", "⑪ 年度數據 FAIL 證據" + tag, "%s 第 %s 頁 · %s %s = %r · %s · 表頭「%s」· 科目列「%s」%s" % (ev["file"], ev["page"], ev["item"], ev["period"], ev["value"], verdict,
          heads[0] if heads else "沒找到", items[0] if items else "沒找到", (" · " + err) if err and not al else ""),
          "整份在 VRN2_FinFailEvidence_latest.json(貼回包裡)· 擷取對錯欄 → 改擷取;冊值 = 原文 → 改驗證器;對不齊 → 看原 PDF 那一頁")
    digests = sorted((v2 / "verify_independent").glob("*.digest.txt"), key=_mtime) if (v2 / "verify_independent").is_dir() else []
    if digests:
        head = digests[-1].read_text''')
# 5) 自測 ㉝ ~ ㊲
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''', r'''        # ㉝ ~ ㊲ v0106
        stage = Path(tempfile.mkdtemp(prefix="vrn2_place_check_"))
        (stage / "sub").mkdir()
        (stage / "a.txt").write_text("a", encoding="utf-8")
        (stage / "sub" / "b.txt").write_text("b", encoding="utf-8")
        dest = td / "placed" / PACKAGE
        dest.parent.mkdir()
        _place(stage, dest)
        src_code = Path(__file__).read_text(encoding="utf-8")
        mode_ok = os.name == "nt" or (dest.stat().st_mode & 0o777) != 0o700
        chk("㉝ 套件安裝不搬暫存夾(Python 3.13 暫存夾只給擁有者權限):目的地正常建夾 · 逐檔複製 · 暫存刪掉 · 權限不是 0o700",
            (dest / "a.txt").read_text(encoding="utf-8") == "a" and (dest / "sub" / "b.txt").read_text(encoding="utf-8") == "b" and not stage.exists() and mode_ok
            and ("shutil.move(str(" + "stage), str(pkg))") not in src_code and ("_place(" + "stage, pkg)") in src_code)
        cpu = owner_of({"lamp": "YELLOW", "step": "② CPU", "detail": "忙碌 93%"}, ctx0)
        chk("㉞ 收尾頁:② CPU 忙碌 → 提醒(不是 VRN-2 要修)", cpu[0] == "提醒")
        g1, o1 = combined_gaps([{"FILENAME": "x.pdf", "TICKER": "", "TARGET_PRICE": "100", "TARGET_PRICE(ADJ)": "", "STATUS": "TARGET_PRICE(ADJ): 缺:基本資料冊代號不是 4 碼"}], set(), True)
        g2, o2 = combined_gaps([{"FILENAME": "y.pdf", "TICKER": "AAPL US", "TARGET_PRICE": "300", "TARGET_PRICE(ADJ)": "", "STATUS": "TARGET_PRICE(ADJ): 缺:基本資料冊代號不是 4 碼"},
                                {"FILENAME": "z.pdf", "TICKER": "2330", "TARGET_PRICE": "1500", "TARGET_PRICE(ADJ)": "", "STATUS": "TARGET_PRICE(ADJ): 缺:MISSING(報告日前沒有日資料 · 需 --start 回補)"}], set(), True)
        chk("㉟ Combined「代號不是 4 碼」:冊裡 TICKER 空白 → 人工(原文有沒有印代號)· 有值但不是台股 4 碼 → 資料源 · 每種原因列檔名(_files)",
            o1 == "人工" and "x.pdf" in g1["_files"]["基本資料冊代號不是台股 4 碼(TICKER 空白)"] and o2 == "資料源" and g2["_files"]["MISSING(報告日前沒有日資料 · 需 --start 回補)"] == ["z.pdf"])
        al_ok = False
        try:
            try:
                import pymupdf as fitz  # noqa: WPS433
            except ImportError:
                import fitz  # noqa: WPS433
            import pypdfium2  # noqa: F401,WPS433
            doc = fitz.open()
            page = doc.new_page()
            for i, line in enumerate(("Daiwa Capital Markets", "Year to 31 Dec 2024A 2025E 2026E 2027E", "EPS (TWD) 85.1 102.3 120.4 141.0", "PBR (x) n.a. 29.2 25.1 20.3", "Tel +886 2 2345 6789")):
                page.insert_text((60, 80 + 18 * i), line, fontsize=10)
            pdf = td / "fin_ev.pdf"
            doc.save(str(pdf))
            res = {}
            for per, val in (("26E", "n.a."), ("24A", "n.a."), ("25E", "29.2")):
                done = subprocess.run([sys.executable, "-X", "utf8", "-c", FIN_EVIDENCE_PY, str(pdf), "1", "PBR (x)", per, val], capture_output=True, text=True, encoding="utf-8", timeout=120)
                got = json.loads(done.stdout.strip().splitlines()[-1])
                res[per] = next((x for x in got if x.get("kind") == "aligned"), {})
            al_ok = (res["26E"].get("at") == "25.1" and res["26E"].get("match") is False and res["24A"].get("at") == "n.a." and res["24A"].get("match") is True
                     and res["25E"].get("match") is True and res["26E"].get("periods") == ["2024A", "2025E", "2026E", "2027E"])
            chk("㊱ ⑪ 年度數據 FAIL 證據:原文表頭(2024A 2025E 2026E 2027E)+ 科目列(PBR (x) n.a. 29.2 25.1 20.3)依欄位對齊 → 26E 是 25.1 ≠ 冊值 n.a.(擷取對錯欄)· 24A 是 n.a. = 冊值(驗證器讀法)", al_ok)
        except Exception as error:  # noqa: BLE001
            print("[SKIP] ㊱ 沒有 PyMuPDF / pypdfium2(%s)· 不產生 PDF" % type(error).__name__)
        hint = acl_hint("C:\\Users\\x\\Downloads\\VRN2_Closeout_v0151\\VRN2_Closeout_v0151.zip: Access is denied.", Path("C:/Users/x/Downloads/VRN2_Closeout_v0151/VRN2_Closeout_v0151.zip"))
        chk("㊲ 證據:icacls「Access is denied」→ 說明權限不給目前使用者 + 以系統管理員身分 icacls /reset 的指令 · 讀得到權限時不多話", "系統管理員" in hint and "/reset /T /C" in hint and acl_hint("ok (F)", Path("x")) == "")
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0105.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0106.py"').replace('"VRN2_RoundAll_v0105.py" in html_', '"VRN2_RoundAll_v0106.py" in html_')
d0 = s.index('"""VRN2_RoundAll v0106'); d1 = s.index('"""', d0 + 3)
assert not re.search(r"(?<!\\)\\(?![\\])", s[d0:d1].replace("\\\\", "")), "single backslash in docstring"
(S / "v151/new/VRN2_RoundAll_v0106.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0106 lines", s.count("\n"))
