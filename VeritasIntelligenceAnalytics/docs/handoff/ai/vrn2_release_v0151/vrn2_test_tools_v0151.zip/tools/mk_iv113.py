"""VRN2_IndependentVerifier_v0113.py = structural copy of v0112 (the --shard children run this file) + a second reading for BADITEM."""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v150/new/VRN2_IndependentVerifier_v0112.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('''"""Independent verifier v0112: v0111 + a second reading for the basic-info price labels (v0111 kept byte-identical).
''', '''"""Independent verifier v0113: v0112 + a second reading for BADITEM (v0112 kept byte-identical).

v0113: desktop 2026-10-29 19:13 (RoundAll v0102 · verifier v0111): annual data BADITEM 19 = MS-3665 ×7 / MS-8358 ×6 / MS-8210 ×4 / Daiwa aspeed ×2
("ModelWare net inc (NT $ mn)" ×8 · "Prior EPS (NT$)**" ×4 · "DPS" ×2), every one "value on the page" — the same character-box reader
(page_lines) that misread the MS key-data sidebars in v0112 is the only reader BADITEM asks. When it says "item not on this page", v0113 reads
the page a second way (PDFium whole-page text + pdfplumber text lines, text_lines) and keeps the earlier verdict only when the item is there:
the whole item (spaces / * † $ , . quotes / brackets ignored, as v0103) or, for items of two words or more, every word in order within three
consecutive lines (a label wrapped or split by the reader). A fabricated / renamed item is found by neither reading and stays BADITEM; its note
then carries the closest source line of the second reading, so the paste-back shows what the page really says. A value that is not on the page
(FAIL) also gets the item's source line of the second reading in its note (verdict unchanged).
''')
rep('BRIDGE = load("independent_v0112_execution", "VIA_ExecutionBridge_v0103.py")', 'BRIDGE = load("independent_v0113_execution", "VIA_ExecutionBridge_v0103.py")')
rep('PRIOR = load("independent_v0112_financial_core", "VRN2_IndependentVerifier_v0105.py")', 'PRIOR = load("independent_v0113_financial_core", "VRN2_IndependentVerifier_v0105.py")')
rep('QUOTES = load("independent_v0112_source_reader", "VRN2_VerbatimVerifier_v0105.py")', 'QUOTES = load("independent_v0113_source_reader", "VRN2_VerbatimVerifier_v0105.py")')
rep('VERSION = "VRN2_IndependentVerifier_v0112"', 'VERSION = "VRN2_IndependentVerifier_v0113"')
rep('''PRIOR.near_label = near_label            # verify_basic / _swap_hint look near_label up in the v0105 core's globals
''', r'''PRIOR.near_label = near_label            # verify_basic / _swap_hint look near_label up in the v0105 core's globals
_native_verify_fin = PRIOR.verify_fin
_WORD = re.compile(r"[a-z]+|\d+|[㐀-鿿]+")


def _words(t):
    return _WORD.findall(nfk(t).lower())


def _in_order(words, text):
    at = 0
    for w in words:
        at = text.find(w, at)
        if at < 0:
            return False
        at += len(w)
    return True


def item_on_page(pdf, pno, item):
    """v0113 second reading for BADITEM: (True, source line) when the item is on the page — whole item (squash + v0103 _inm) or, for two words or
    more, every word in order within three consecutive lines; else (False, closest source line or "")."""
    lines = text_lines(pdf, pno)
    si = squash(item)
    if not si or not lines:
        return False, ""
    sq = [squash(line) for line in lines]
    for width in (1, 2, 3):                                      # one line first, then a label wrapped over two / three lines
        for i in range(len(lines) - width + 1):
            joined = "".join(sq[i:i + width])
            if si in joined or (_inm(si) and _inm(si) in _inm(joined)):
                return True, " / ".join(lines[i:i + width])[:120]
    words = _words(item)
    if len(words) >= 2 and sum(len(w) for w in words) >= 6:
        low = [nfk(line).lower() for line in lines]
        for width in (1, 2, 3):
            for i in range(len(lines) - width + 1):
                if _in_order(words, " ".join(low[i:i + width])):
                    return True, " / ".join(lines[i:i + width])[:120]
    best, score = "", 0
    for line in lines:
        got = sum(len(w) for w in set(words) if len(w) >= 2 and w in nfk(line).lower())
        if got > score:
            best, score = line, got
    return False, best[:120]


def verify_fin(rows, pdfdir, allrows=None):
    """v0113: v0105's verify_fin, then every BADITEM is read a second way (item_on_page); FAIL notes get the item's source line (verdict kept)."""
    res = _native_verify_fin(rows, pdfdir, allrows)
    for r in res:
        if r.get("_V") not in ("BADITEM", "FAIL"):
            continue
        pdf, pno = Path(pdfdir) / r["FILENAME"], int(r["PAGE"])
        found, line = item_on_page(pdf, pno, r.get("ITEM", ""))
        if r["_V"] == "FAIL":
            if found:
                r["_N"] = "%s · 第二種讀法的科目列「%s」" % (r["_N"], line)
            continue
        prefix = "科目 %r 本頁原文沒有 · " % (nfk(r["ITEM"]).strip(),)
        rest = r["_N"][len(prefix):] if r["_N"].startswith(prefix) else r["_N"]
        if found:
            r["_V"] = "PRESENT" if rest.startswith("值在該頁 · 驗證器對不到期間欄") else "ALIGNED"
            r["_N"] = "科目字在本頁(第二種讀法 · 「%s」)· %s" % (line, rest)
        else:
            r["_N"] = "%s · 第二種讀法也沒有這個科目%s" % (r["_N"], (" · 最像的列「%s」" % line) if line else "(本頁沒有相近的列)")
    return res


PRIOR.verify_fin = verify_fin            # run_files (rebound here) and the v0105 core both look verify_fin up by name
''')
rep('''    print("[PASS] v0112: price labels read a second way when the character-box reader says no — same-line label only (MS-6669 3510 / MS-3661 3190 sidebars PASS · swapped target / price stays FAIL · '18% upside' and 'NT$730 price target' prose)")
    return result
''', '''    print("[PASS] v0112: price labels read a second way when the character-box reader says no — same-line label only (MS-6669 3510 / MS-3661 3190 sidebars PASS · swapped target / price stays FAIL · '18% upside' and 'NT$730 price target' prose)")
    page = ["Financial summary (NT$ mn)  12/24  12/25e  12/26e", "ModelWare net inc (NT$ mn)  4,396  9,045  10,120", "Prior EPS (NT$)**  1.10  2.30", "EPS (NT$)**  1.20  2.40",
            "Dividend", "DPS (NT$)  0.50  0.80", "Gross margin", "(%)  31.2  32.0", "Operating income 2,100 2,400"]
    key = str(Path("t") / "ms.pdf")
    native = globals()["_native_verify_fin"]
    saved_lines = dict(_TEXT_LINES)
    try:
        _TEXT_LINES[(key, 1)] = [nfk(line) for line in page]
        def fake(rows, pdfdir, allrows=None):        # the desktop's character-box miss: every row came back BADITEM
            out = []
            for x in rows:
                note = "值在該頁 · 驗證器對不到期間欄" if x.get("_KEEP") == "PRESENT" else "dx 1.0 · 欄寬 40 · 科目列"
                out.append(dict(x, _V="BADITEM", _N="科目 %r 本頁原文沒有 · %s" % (nfk(x["ITEM"]).strip(), note)))
            return out
        globals()["_native_verify_fin"] = fake
        rows = [{"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "ModelWare net inc (NT $ mn)", "PERIOD": "12/24", "VALUE": "4,396", "_KEEP": "PRESENT"},
                {"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "Prior EPS (NT$)**", "PERIOD": "12/25e", "VALUE": "2.30"},
                {"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "DPS", "PERIOD": "12/25e", "VALUE": "0.80"},
                {"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "Gross margin (%)", "PERIOD": "12/24", "VALUE": "31.2"},
                {"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "Fabricated reserve ratio", "PERIOD": "12/24", "VALUE": "4,396"},
                {"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "ModelWare capex (NT $ mn)", "PERIOD": "12/24", "VALUE": "4,396"},
                {"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "Net debt", "PERIOD": "12/24", "VALUE": "9,045"}]
        got = verify_fin(rows, "t")
        verdicts = [r["_V"] for r in got]
        assert verdicts == ["PRESENT", "ALIGNED", "ALIGNED", "ALIGNED", "BADITEM", "BADITEM", "BADITEM"], verdicts
        assert "第二種讀法" in got[0]["_N"] and got[0]["_N"].endswith("值在該頁 · 驗證器對不到期間欄"), got[0]["_N"]
        assert "Gross margin / (%)" in got[3]["_N"], got[3]["_N"]                                    # wrapped label (three-line window)
        assert "最像的列「ModelWare net inc (NT$ mn)" in got[5]["_N"] and "第二種讀法也沒有" in got[4]["_N"], (got[4]["_N"], got[5]["_N"])
        globals()["_native_verify_fin"] = lambda rows, pdfdir, allrows=None: [dict(x, _V="FAIL", _N="值不在該頁(驗證器讀法)") for x in rows]
        fail = verify_fin([{"FILENAME": "ms.pdf", "PAGE": 1, "ITEM": "DPS", "PERIOD": "12/26e", "VALUE": "n.a."}], "t")[0]
        assert fail["_V"] == "FAIL" and "第二種讀法的科目列「DPS (NT$)" in fail["_N"], fail
    finally:
        _TEXT_LINES.clear(); _TEXT_LINES.update(saved_lines)
        globals()["_native_verify_fin"] = native
    assert PRIOR.verify_fin is verify_fin and globals()["verify_fin"] is verify_fin
    print("[PASS] v0113: BADITEM read a second way — item on the page (whole · wrapped · words in order) keeps PRESENT / ALIGNED; fabricated / renamed item stays BADITEM with the closest source line; FAIL keeps FAIL with the item's source line")
    return result
''')
assert "v0112_" not in s.replace("independent_v0112", "")
out = S / "v151/new/VRN2_IndependentVerifier_v0113.py"
out.write_text(s, encoding="utf-8", newline="\n")
print("IndependentVerifier v0113 lines", s.count("\n"))
