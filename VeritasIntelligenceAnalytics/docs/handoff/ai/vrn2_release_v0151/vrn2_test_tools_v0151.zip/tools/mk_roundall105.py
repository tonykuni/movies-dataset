"""VRN2_RoundAll_v0105.py = v0104 + 桌機 2026-10-30 13:15 PowerShell 7.6.9 原生一行的結果:① 讀 Downloads\\VRN2_Closeout_v0151\\VRN2_Closeout_v0151.zip
PermissionError(Errno 13)→ 整支 Traceback 當掉(沒有收尾頁 / 貼回包)。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v151/new/VRN2_RoundAll_v0104.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN2_RoundAll v0104 — ', '"""VRN2_RoundAll v0105 — ')
rep("v0104(操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」", r'''v0105(桌機 2026-10-30 13:15 · PowerShell 7.6.9 原生一行 · RoundAll v0104 在 ① 就 Traceback 當掉):
  · ① 讀本機套件 zip(Downloads\\VRN2_Closeout_v0151\\VRN2_Closeout_v0151.zip)PermissionError [Errno 13] → v0104 整支當掉,收尾頁 / 貼回包都沒有。
    v0105:讀不到先重試(0.5 / 1 / 2 / 4 秒 —— 防毒掃描這類短暫鎖)· 還是讀不到 → 印證據(啟動器鎖 PID 還在不在 · icacls 權限 · attrib)
    → 改從 GitHub 取套件 · 原套件夾換不了(檔被鎖 / 權限)→ 裝到新夾 VRN2_Closeout_v0151_<時間>(原夾不動)· zip 副本寫不進去不算失敗。
  · 每一步都包起來:任何一步出例外 → 那一步記紅(例外類別 + 訊息 + 最後幾行)· 其他步驟照跑 · 收尾頁 / 貼回包照產生(貼回包讀不到的檔略過並記下)。
  · 收尾頁:⑥f 收據裡啟動器當時的「Combined YELLOW」在 ⑤ 重組後已過時 → 算「提醒」不算「資料源」(v0104 已知小瑕疵)· ① 讀不到 zip 的證據列進「這輪的數據」。

v0104(操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」''')
rep("用法:python VRN2_RoundAll_v0104.py", "用法:python VRN2_RoundAll_v0105.py")
rep('VERSION = "v0104"', 'VERSION = "v0105"')
# 1) 讀雜湊重試 + 鎖檔證據 + 每步保護
rep('''def jread(path: Path, default=None):''', '''SHA_TRIES, SHA_WAIT = 5, 0.5                                          # v0105 讀不到(被鎖)重試:0.5 / 1 / 2 / 4 秒


def read_sha(path: Path) -> tuple:
    """v0105:(SHA-256, "") · 讀不到(PermissionError 等)重試 SHA_TRIES 次 → (None, 錯誤)。"""
    err = ""
    for i in range(SHA_TRIES):
        try:
            return sha256_file(path), ""
        except OSError as error:
            err = "%s: %s" % (type(error).__name__, error)
            if i < SHA_TRIES - 1:
                time.sleep(min(SHA_WAIT * 2 ** i, 4))
    return None, err


def lock_evidence(path: Path, root=None) -> str:
    """v0105 讀不到檔時的證據(只讀):啟動器鎖 PID 還在不在 · Windows 上 icacls / attrib 的輸出。"""
    bits = []
    lock = Path(root) / "VIA_Reports" / "vrn2" / "VRN2_Launcher.lock" if root else None
    if lock and lock.is_file():
        pid = (jread(lock, {}) or {}).get("pid")
        try:
            alive = pid_alive(int(pid or 0))
        except (TypeError, ValueError):
            alive = False
        bits.append("啟動器鎖 PID %s %s" % (pid, "還在跑(另一個 VRN-2 視窗沒關?)" if alive else "已不在"))
    if os.name == "nt":
        for cmd in (["icacls", str(path)], ["attrib", str(path)]):
            try:
                out = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=15).stdout
                bits.append("%s:%s" % (cmd[0], " ".join(l.strip() for l in out.splitlines() if l.strip())[:300]))
            except (OSError, subprocess.SubprocessError) as error:
                bits.append("%s 失敗 %s" % (cmd[0], type(error).__name__))
    return " · ".join(bits) or "沒有其他線索"


def guarded(label: str, fn, *a, default=None, **kw):
    """v0105:一步出例外 → 記紅(類別 + 訊息 + 最後幾行)· 回 default · 後面的步驟(收尾頁 / 貼回包)照跑。"""
    try:
        return fn(*a, **kw)
    except Exception as error:  # noqa: BLE001
        import traceback
        tail = [l.strip() for l in traceback.format_exc().strip().splitlines()][-4:]
        say("RED", label, "例外 %s: %s · %s" % (type(error).__name__, str(error)[:240], " | ".join(tail)[:400]),
            "RoundAll 這一步當掉了 · 其他步驟照跑 · 收尾頁 / 貼回包照產生 → 把貼回包給 AI" + ("(檔案被鎖 / 權限:先關掉佔用它的程式或等防毒掃完再跑)" if isinstance(error, PermissionError) else ""))
        return default


def jread(path: Path, default=None):''')
# 2) install_package:雜湊用 read_sha · zip / 發行清單副本寫不進去不算失敗
rep('''    got = sha256_file(zip_path)
    if want and got != want:''', '''    got, err = read_sha(zip_path)
    if got is None:
        raise PermissionError("讀不到 %s(%s)" % (zip_path, err))
    if want and got != want:''')
rep('''            for extra in (zip_path, release_json):
                if extra and Path(extra).is_file() and Path(extra).resolve() != (pkg / Path(extra).name).resolve():
                    shutil.copy2(str(extra), str(pkg / Path(extra).name))
            return {"lamp": "GREEN", "detail": "本機已是 %s(%d 檔逐檔相符)· %s" % (PACKAGE, len(manifest["files"]), pkg), "pkg": str(pkg)}''',
    '''            note = _copy_extras(pkg, zip_path, release_json)
            return {"lamp": "GREEN", "detail": "本機已是 %s(%d 檔逐檔相符)· %s%s" % (PACKAGE, len(manifest["files"]), pkg, note), "pkg": str(pkg)}''')
rep('''    for extra in (zip_path, release_json):
        if extra and Path(extra).is_file():
            shutil.copy2(str(extra), str(pkg / Path(extra).name))
    return {"lamp": "GREEN", "detail": "套件就位 %s(SHA-256 %s · %d 檔逐檔相符)%s" % (pkg, got[:12], len(manifest["files"]), (" · 舊套件夾改名備份 → " + backup) if backup else ""), "pkg": str(pkg)}''',
    '''    note = _copy_extras(pkg, zip_path, release_json)
    return {"lamp": "GREEN", "detail": "套件就位 %s(SHA-256 %s · %d 檔逐檔相符)%s%s" % (pkg, got[:12], len(manifest["files"]), (" · 舊套件夾改名備份 → " + backup) if backup else "", note), "pkg": str(pkg)}


def _copy_extras(pkg: Path, zip_path, release_json) -> str:
    """v0105:zip / 發行清單副本放進套件夾(方便下次本機核對)· 寫不進去(被鎖)只記一句,不算失敗。"""
    skipped = []
    for extra in (zip_path, release_json):
        if extra and Path(extra).is_file() and Path(extra).resolve() != (Path(pkg) / Path(extra).name).resolve():
            try:
                shutil.copy2(str(extra), str(Path(pkg) / Path(extra).name))
            except OSError as error:
                skipped.append("%s(%s)" % (Path(extra).name, type(error).__name__))
    return (" · 副本沒放進套件夾:" + "、".join(skipped)) if skipped else ""''')
# 3) step_package:本機 zip 讀不到 → 證據 → GitHub · 原夾用不了 → 新夾
rep('''    local_zip = pkg / (PACKAGE + ".zip")
    if local_zip.is_file() and sha256_file(local_zip) == PACKAGE_SHA256:
        manifest = {}
        with zipfile.ZipFile(local_zip) as z:
            name = next((n for n in z.namelist() if n.endswith("PACKAGE_SHA256.json")), None)
            if name:
                manifest = json.loads(z.read(name).decode("utf-8"))
        bad = _manifest_check(pkg, manifest) if manifest else ["PACKAGE_SHA256.json"]
        if not bad:''', '''    local_zip = pkg / (PACKAGE + ".zip")
    got, err = read_sha(local_zip) if local_zip.is_file() else (None, "")
    if err:                                                                # v0105:讀不到(被鎖 / 權限)→ 證據 → 改從 GitHub 取
        ev = lock_evidence(local_zip, root)
        say("GRAY", "① 套件 zip 讀不到(改從 GitHub 取)", "%s · %s · 證據:%s" % (local_zip, err, ev),
            "有別的程式佔著這個檔(防毒掃描 / 另一個 VRN-2 視窗 / 檔案總管預覽)或權限不對;不影響這輪(改從 GitHub 取)")
    manifest, bad = {}, ["(沒讀)"]
    if got == PACKAGE_SHA256:
        try:
            with zipfile.ZipFile(local_zip) as z:
                name = next((n for n in z.namelist() if n.endswith("PACKAGE_SHA256.json")), None)
                if name:
                    manifest = json.loads(z.read(name).decode("utf-8"))
            bad = _manifest_check(pkg, manifest) if manifest else ["PACKAGE_SHA256.json"]
        except OSError as error:
            got, bad = None, ["%s: %s" % (type(error).__name__, error)]
            say("GRAY", "① 套件 zip 讀不到(改從 GitHub 取)", "%s · %s · 證據:%s" % (local_zip, bad[0], lock_evidence(local_zip, root)))
    if got == PACKAGE_SHA256:
        if not bad:''')
rep('''        copy = Path(tempfile.mkdtemp(prefix="vrn2_roundall_zip_")) / local_zip.name
        shutil.copy2(str(local_zip), str(copy))
        r = install_package(copy, PACKAGE_SHA256, pkg, pkg / RELEASE_JSON if (pkg / RELEASE_JSON).is_file() else None)
        say(r["lamp"], "① 套件", r["detail"])
        return pkg if r["lamp"] == "GREEN" else None''', '''        copy = Path(tempfile.mkdtemp(prefix="vrn2_roundall_zip_")) / local_zip.name
        shutil.copy2(str(local_zip), str(copy))
        return _install_with_fallback(copy, pkg / RELEASE_JSON if (pkg / RELEASE_JSON).is_file() else None, pkg, "")''')
rep('''    r = install_package(z, PACKAGE_SHA256, pkg, rj)
    say(r["lamp"], "① 套件", r["detail"] + " · 來源 " + how)
    return pkg if r["lamp"] == "GREEN" else None''', '''    return _install_with_fallback(z, rj, pkg, how)


def _install_with_fallback(z: Path, rj, pkg: Path, how: str):
    """v0105:裝進原套件夾;原夾用不了(檔被鎖 / 權限 · 改名失敗)→ 裝到新夾 <套件>_<時間>(原夾不動)。"""
    try:
        r = install_package(z, PACKAGE_SHA256, pkg, rj)
    except OSError as error:
        alt = Path(pkg).with_name(Path(pkg).name + "_" + stamp())
        info("① 套件夾 %s 用不了(%s: %s)→ 改裝到新夾 %s(原夾不動)" % (pkg, type(error).__name__, str(error)[:160], alt))
        r = install_package(z, PACKAGE_SHA256, alt, rj)
        r["detail"] += " · 原套件夾 %s 用不了(%s)→ 用新夾" % (pkg, type(error).__name__)
    say(r["lamp"], "① 套件", r["detail"] + ((" · 來源 " + how) if how else ""))
    return Path(r["pkg"]) if r["lamp"] == "GREEN" and r.get("pkg") else None''')
# 4) 貼回包:讀不到的檔略過並記下
rep('''            for rel in PASTE_FILES:
                p = v2 / rel
                if p.is_file() and p.stat().st_size <= 20 * 1024 * 1024:
                    z.write(str(p), "vrn2/" + rel)''', '''            skipped = []
            for rel in PASTE_FILES:
                p = v2 / rel
                if p.is_file() and p.stat().st_size <= 20 * 1024 * 1024:
                    try:
                        z.write(str(p), "vrn2/" + rel)
                    except OSError as error:                               # v0105 被鎖的檔略過(其他照包)
                        skipped.append("%s(%s)" % (rel, type(error).__name__))
            if skipped:
                z.writestr("skipped_files.txt", "\\n".join(skipped) + "\\n")''')
# 5) main:每步保護
rep('''    if want["package"]:
        pkg = step_package(root, args)''', '''    if want["package"]:
        pkg = guarded("① 套件", step_package, root, args)''')
rep('''    vpy, vpy_how = vrn2_python(root, args.python)
    state = {}
    if want["preflight"]:
        state = step_preflight(root, pkg, vpy, vpy_how, args)
    if want["selftest"] and pkg:
        step_selftest(pkg, vpy)
    if want["run"] and pkg and root:
        step_run(pkg, root, vpy, state, args)
    elif want["run"]:
        say("RED", "④ 跑啟動器", "沒有套件或 VIA 根 · 不跑")
    if want["fix"] and root:
        step_fix(root, vpy, state, args)
    report = {}
    if want["report"] and root:
        report = diagnose(root, vpy)''', '''    vpy, vpy_how = guarded("② VRN-2 Python", vrn2_python, root, args.python, default=(sys.executable, "本行程(找 Python 時出例外)"))
    state = {}
    if want["preflight"]:
        state = guarded("② 診斷", step_preflight, root, pkg, vpy, vpy_how, args, default={}) or {}
    if want["selftest"] and pkg:
        guarded("③ 自測", step_selftest, pkg, vpy)
    if want["run"] and pkg and root:
        guarded("④ 跑啟動器", step_run, pkg, root, vpy, state, args)
    elif want["run"]:
        say("RED", "④ 跑啟動器", "沒有套件或 VIA 根 · 不跑", "看 ① 套件那一行(讀不到 / 雜湊不對 / GitHub 取不到)")
    if want["fix"] and root:
        guarded("⑤ 自動修", step_fix, root, vpy, state, args)
    report = {}
    if want["report"] and root:
        report = guarded("⑥ 除錯報告", diagnose, root, vpy, default={}) or {}''')
rep('''    zpath = step_pasteback(root, transcript, zplan) if want["pasteback"] else None''', '''    zpath = guarded("⑦ 貼回包", step_pasteback, root, transcript, zplan) if want["pasteback"] else None''')
# 6) 收尾頁:⑥f 過時的 Combined 黃 → 提醒 · ① 證據進「這輪的數據」
rep('''        if re.search(r"Combined (YELLOW|RED)", detail):
            return (ctx.get("combined_owner") or "資料源"), "Combined 空格原因:%s" % json.dumps(ctx.get("combined_gaps") or {}, ensure_ascii=False)[:200]''',
    '''        if re.search(r"Combined (YELLOW|RED)", detail):
            if ctx.get("combined_owner") is None and ctx.get("combined_now"):     # v0105:啟動器當時的 Combined 黃 · ⑤ 重組後只剩原文沒有目標價
                return "提醒", "⑥f 那時的 Combined 黃已被 ⑤ 重組蓋過 · 現在的 Combined 只剩原文沒有目標價的空格(不是缺)"
            return (ctx.get("combined_owner") or "資料源"), "Combined 空格原因:%s" % json.dumps(ctx.get("combined_gaps") or {}, ensure_ascii=False)[:200]''')
rep('''    ctx["combined_gaps"], ctx["combined_owner"] = combined_gaps(comb if isinstance(comb, list) else [], ctx["no_cov"], ctx["fetch_env_ok"])''',
    '''    ctx["combined_gaps"], ctx["combined_owner"] = combined_gaps(comb if isinstance(comb, list) else [], ctx["no_cov"], ctx["fetch_env_ok"])
    ctx["combined_now"] = isinstance(comb, list) and bool(comb)''')
rep('''    fact_steps = ("⑥ 完成判定 · 輸出冊",''', '''    fact_steps = ("① 套件", "⑥ 完成判定 · 輸出冊",''')
# 7) 自測 ㉘ ~ ㉜
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''', r'''        # ㉘ ~ ㉜ v0105:檔被鎖 / 例外不當掉
        g = globals()
        real_sha, real_install, real_fetch, real_pkgsha, real_tries = g["sha256_file"], g["install_package"], g["git_fetch_release"], g["PACKAGE_SHA256"], (g["SHA_TRIES"], g["SHA_WAIT"])
        lockpkg = td / "lockdl" / PACKAGE
        lockpkg.mkdir(parents=True)
        (lockpkg / (PACKAGE + ".zip")).write_bytes(zp.read_bytes())
        calls = {"n": 0}

        def flaky(path):
            if Path(path).name == PACKAGE + ".zip" and Path(path).parent == lockpkg:
                calls["n"] += 1
                if calls["n"] <= 2:
                    raise PermissionError(13, "Permission denied", str(path))
            return real_sha(path)
        sys.stdout = io.StringIO()
        try:
            g["sha256_file"], g["SHA_TRIES"], g["SHA_WAIT"] = flaky, 5, 0.01
            got_r = read_sha(lockpkg / (PACKAGE + ".zip"))
            calls["n"] = -100
            got_x = read_sha(lockpkg / (PACKAGE + ".zip"))
        finally:
            sys.stdout = sys_stdout
            g["sha256_file"], (g["SHA_TRIES"], g["SHA_WAIT"]) = real_sha, real_tries
        chk("㉘ 讀雜湊:被鎖兩次(PermissionError)→ 重試後讀到 · 一直被鎖 → (None, PermissionError …) 不丟例外", got_r[0] == want and got_x[0] is None and "PermissionError" in got_x[1])

        def locked(path):
            if Path(path).parent == lockpkg:
                raise PermissionError(13, "Permission denied", str(path))
            return real_sha(path)

        def install_locked(z_, want_, pkg_, rj_=None):
            if Path(pkg_) == lockpkg:
                raise PermissionError(13, "Permission denied", str(pkg_))
            return real_install(z_, want_, pkg_, rj_)
        RESULTS.clear()
        sys.stdout = io.StringIO()
        try:
            g["sha256_file"], g["SHA_TRIES"], g["SHA_WAIT"], g["PACKAGE_SHA256"] = locked, 2, 0.01, want
            g["install_package"], g["git_fetch_release"] = install_locked, (lambda root_, branch_, work_: (zp, None, "GitHub " + BRANCH))
            got_pkg = step_package(root, type("P", (), {"package": str(lockpkg), "offline": False, "branch": BRANCH})())
        finally:
            sys.stdout = sys_stdout
            g["sha256_file"], (g["SHA_TRIES"], g["SHA_WAIT"]), g["PACKAGE_SHA256"] = real_sha, real_tries, real_pkgsha
            g["install_package"], g["git_fetch_release"] = real_install, real_fetch
        rows = {r["step"]: r for r in RESULTS}
        chk("㉙ ① 本機 zip 被鎖:記證據(GRAY · 不擋)→ 改從 GitHub 取 → 原套件夾用不了 → 裝到新夾 <套件>_<時間>(原夾不動 · 逐檔相符)",
            got_pkg is not None and got_pkg != lockpkg and got_pkg.name.startswith(PACKAGE + "_") and (got_pkg / LAUNCHER).read_bytes() == files[LAUNCHER]
            and rows.get("① 套件 zip 讀不到(改從 GitHub 取)", {}).get("lamp") == "GRAY" and "PermissionError" in rows["① 套件 zip 讀不到(改從 GitHub 取)"]["detail"]
            and rows.get("① 套件", {}).get("lamp") == "GREEN" and "用新夾" in rows["① 套件"]["detail"] and (lockpkg / (PACKAGE + ".zip")).is_file())
        RESULTS.clear()
        sys.stdout = io.StringIO()
        try:
            out_g = guarded("⑥ 除錯報告", lambda: (_ for _ in ()).throw(PermissionError(13, "Permission denied", "x.zip")), default={"d": 1})
        finally:
            sys.stdout = sys_stdout
        src = Path(__file__).read_text(encoding="utf-8")
        chk("㉚ 一步出例外 → 那一步記紅(例外類別 + 訊息)· 回預設值 · main 每一步都包起來(① ② ③ ④ ⑤ ⑥ ⑦)",
            out_g == {"d": 1} and RESULTS[-1]["lamp"] == "RED" and "例外 PermissionError" in RESULTS[-1]["detail"] and "防毒" in RESULTS[-1]["hint"]
            and all(('guarded("%s"' % k) in src for k in ("① 套件", "② VRN-2 Python", "② 診斷", "③ 自測", "④ 跑啟動器", "⑤ 自動修", "⑥ 除錯報告", "⑦ 貼回包")))
        ctx1 = dict(ctx0, combined_owner=None, combined_now=True)
        stale = owner_of({"lamp": "YELLOW", "step": "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)", "detail": "共識 GREEN:… · Combined YELLOW:Combined 14 列 · 調整後目標價 0"}, ctx1)
        real_gap = owner_of({"lamp": "YELLOW", "step": "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)", "detail": "共識 GREEN:… · Combined YELLOW:…"}, dict(ctx0, combined_owner="資料源", combined_now=True))
        chk("㉛ 收尾頁:⑥f 當時的 Combined 黃在 ⑤ 重組後過時 → 提醒(不再算資料源)· 現在還有缺 → 照缺的負責方", stale[0] == "提醒" and real_gap[0] == "資料源")
        real_write = zipfile.ZipFile.write

        def write_locked(self, filename, arcname=None, *a, **k):
            if str(arcname or "").endswith("VRN2_Workbench_latest.html"):
                raise PermissionError(13, "Permission denied", str(filename))
            return real_write(self, filename, arcname, *a, **k)
        sys.stdout = io.StringIO()
        try:
            zipfile.ZipFile.write = write_locked
            zp3 = step_pasteback(root, tr, td / "home" / "Downloads" / "VRN2_PasteBack_locked.zip")
        finally:
            zipfile.ZipFile.write = real_write
            sys.stdout = sys_stdout
        with zipfile.ZipFile(zp3) as z:
            names3 = set(z.namelist())
            skipped3 = z.read("skipped_files.txt").decode("utf-8") if "skipped_files.txt" in names3 else ""
        chk("㉜ 貼回包:被鎖的檔略過並記在 skipped_files.txt · 其他照包", "vrn2/" + RECEIPT in names3 and "vrn2/VRN2_Workbench_latest.html" not in names3 and "VRN2_Workbench_latest.html(PermissionError)" in skipped3)
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''')
s = s.replace('hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0104.py"))', 'hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0105.py"))')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0104.py")', '"C:/Users/x/Downloads/VRN2_RoundAll_v0105.py")')
s = s.replace('"VRN2_RoundAll_v0104.py" in html_', '"VRN2_RoundAll_v0105.py" in html_')
d0 = s.index('"""VRN2_RoundAll v0105'); d1 = s.index('"""', d0 + 3)
assert not re.search(r"(?<!\\)\\(?![\\])", s[d0:d1].replace("\\\\", "")), "single backslash in docstring"
(S / "v151/new/VRN2_RoundAll_v0105.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0105 lines", s.count("\n"))
