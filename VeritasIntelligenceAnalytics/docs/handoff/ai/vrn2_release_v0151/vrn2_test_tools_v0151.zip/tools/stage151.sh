#!/bin/bash
# v0151 放進倉:docs/handoff/ai/vrn2_release_v0151/ + vrn1_vrn2_oneclick_v0112/ + VRN2_LocalRound_v0101.md(固定時間戳 · 冪等)· 新成員只在私有 runtime zip 與 test tools zip
# 不放:桌機貼回內容(收尾頁試算只留一行摘要在驗證紀錄)· .ps1(只在 zip 裡)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v151
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0151; OP=$REPO/vrn1_vrn2_oneclick_v0112; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v151")
REPO = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
D = REPO / "vrn2_release_v0151"; OP = REPO / "vrn1_vrn2_oneclick_v0112"
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("ra151_first.log", "ra151_fix.log", "ra151.rc", "t151_setup.log", "mk_market151.log", "pscheck151.log", "scen151.rc", "scen151_first.log", "scen151_again.log", "scen151_tamper.log", "scen151_setup.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0151_selftest.log", "ActivateVRN-2_v0151_selftest_iso.log", "roundall104_selftest.log", "roundall105_selftest.log", "roundall106_selftest.log", "iv113_selftest.log",
                                 "regress113.log", "regress113_full.log", "closeout_ui_browser.log", "closeout_ui_e2e.log", "run_roundall151.sh", "scen151.sh", "drive151.sh")]
logs += [("regress/run_0112.log", W / "regress/run_0112.log"), ("regress/run_0113.log", W / "regress/run_0113.log")]
logs += [("ps7/" + n, W / "ps7" / n) for n in ("line_ps7.txt", "run_ok.log", "run_badsha.log", "line_ps7_tpl.txt", "run105_ok.log", "lock105.log", "run106_ok.log", "reclass106.log")]
logs += [("release/oneline_roundall_pwsh.txt", W / "release151" / "oneline_roundall_pwsh.txt"), ("release/oneline_roundall.txt", W / "release151" / "oneline_roundall.txt"), ("release/boot_roundall.ps1", W / "release151" / "boot_roundall.ps1")]
logs += [("closeout_ui/" + p.name, p) for p in sorted((W / "e2eshot").glob("*.png"))] if (W / "e2eshot").is_dir() else []
v2 = W / "t151/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0151.json", "VRN2_Closeout_v0151.before_roundall.json", "VRN2_RoundAll_latest.json", "VRN2_CloseoutUI_latest.html", "VRN2_CloseoutUI_latest.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Phase_Timing_latest.json", "VRN2_HistoryAlign_latest.json", "consensus/VRN2_Consensus_latest.json", "market/VRN2_Market_latest.json", "output/VRN2_Combined_latest.csv", "VRN2_FailEvidence_latest.json"):
    logs.append(("t151/" + n, v2 / n))
z(D / "logs_v0151.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))] + [("tools/preview/" + q.name, q) for q in (W / "preview" / "mk_preview.py", W / "preview" / "shot.js", W / "preview" / "over.js")]
tools += [("release/" + q.name, q) for q in (W / "release151" / "boot_roundall.ps1", W / "release151" / "oneline_roundall.txt", W / "release151" / "oneline_roundall_pwsh.txt", W / "release151" / "Run-VRN2-v0151.ps1", W / "release151" / "boot151.ps1")]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py")) if q.name in ("VRN2_IndependentVerifier_v0113.py", "ActivateVRN-2_v0151.py", "VRN2_RoundAll_v0104.py", "VRN2_RoundAll_v0105.py", "VRN2_RoundAll_v0106.py")]
z(D / "vrn2_test_tools_v0151.zip", tools)
z(OP / "tools_v0112.zip", [("tools/" + q.name, q) for q in (W / "operator112" / "boot_pair112.ps1", W / "operator112" / "oneline_pair112.txt", W / "operator112" / "Run-VRN1-VRN2-v0112.ps1")])
for n in ("VRN1_VRN2_OneClick_v0112.md", "VRN1_VRN2_Verification_v0112.md"): shutil.copy(W / "operator112" / n, OP / n)
for n in ("VRN2_Closeout_v0151.zip", "VRN2_Release_v0151.json", "VRN2_OneClick_v0151.md", "VRN2_Verification_v0151.md", "VRN2_RoundAll_v0106.py", "VRN2_RoundAll_v0106.md"): shutil.copy(W / "release151" / n, D / n)
shutil.copy(W / "release151" / "VRN2_LocalRound_v0101.md", REPO / "VRN2_LocalRound_v0101.md")
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
