"""v0113 regression + mutation on the sandbox's real PDFs (in process · run inside the VIA-like tree).

  0) unchanged rows: v0105 core verify_fin vs v0113 verify_fin → verdicts identical
  A) fabricated items (60 ALIGNED rows renamed) → BADITEM in both · v0113 note says the second reading has no such item
  B) the desktop's character-box miss (label letters of the item's row garbled in the char-box cache only) → core BADITEM · v0113 back to PRESENT / ALIGNED
"""
import importlib.util
import json
import random
import sys
from collections import Counter
from pathlib import Path

tree, od, pdfdir = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
spec = importlib.util.spec_from_file_location("iv113_regress", tree / "VRN2_IndependentVerifier_v0113.py")
m = importlib.util.module_from_spec(spec)
sys.modules["iv113_regress"] = m
spec.loader.exec_module(m)
C = m.PRIOR
book = json.loads((od / "VRN2_FinancialData_latest.json").read_text(encoding="utf-8"))
rows = [dict(r, _I=i) for i, r in enumerate(book) if not r.get("SUBCOL") and "轉置" not in str(r.get("VERIFY", ""))]
native, mine = m._native_verify_fin(rows, pdfdir), m.verify_fin(rows, pdfdir)
diff = [(a["_I"], a["_V"], b["_V"]) for a, b in zip(native, mine) if a["_V"] != b["_V"]]
print("0) 原樣 %d 筆 · core %s · v0113 %s · 判決不同 %d" % (len(rows), dict(Counter(r["_V"] for r in native)), dict(Counter(r["_V"] for r in mine)), len(diff)))
assert not diff, diff[:5]
random.seed(151)
aligned = [r for r in native if r["_V"] == "ALIGNED"]
pick = random.sample(aligned, min(60, len(aligned)))
ids = {r["_I"] for r in pick}
mut = [dict(r, ITEM="Zyqx fabricated %d reserve" % r["_I"]) if r["_I"] in ids else r for r in rows]
a_native = [r for r in m._native_verify_fin(mut, pdfdir) if r["_I"] in ids]
a_mine = [r for r in m.verify_fin(mut, pdfdir) if r["_I"] in ids]
print("A) 變造科目名 %d 筆 · core %s · v0113 %s · v0113 註記「第二種讀法也沒有」%d" % (len(ids), dict(Counter(r["_V"] for r in a_native)), dict(Counter(r["_V"] for r in a_mine)), sum("第二種讀法也沒有" in r["_N"] for r in a_mine)))
assert [r["_V"] for r in a_native] == [r["_V"] for r in a_mine] and all(r["_V"] == "BADITEM" for r in a_mine if r["_V"] in ("BADITEM", "PRESENT", "ALIGNED"))
# B) garble the item's row in the character-box cache only (text_lines = the second reading is untouched)
seen, pickb = set(), []
for r in random.sample(aligned, len(aligned)):
    key = (r["FILENAME"], int(r["PAGE"]), C.squash(r["ITEM"])[:14])
    if r["_I"] in ids or key in seen or len(C.squash(r["ITEM"])) < 4:
        continue
    seen.add(key)
    pickb.append(r)
    if len(pickb) >= 60:
        break
pages = {}
for r in pickb:
    pages.setdefault((str(pdfdir / r["FILENAME"]), int(r["PAGE"])), set()).add(C.squash(r["ITEM"])[:14])
saved = dict(C._PAGES)
for (pdf, pno), keys in pages.items():
    lines = C.page_lines(Path(pdf), pno)
    out = []
    for y, tk in lines:
        lt = C.squash("".join(t for _, _, t in tk))
        if any(k in lt for k in keys):
            tk = [(a, b, ("§".join(t) if not any(ch.isdigit() for ch in t) else t)) for a, b, t in tk]
        out.append((y, tk))
    C._PAGES[(pdf, pno)] = out
idb = {r["_I"] for r in pickb}
b_native = {r["_I"]: r for r in m._native_verify_fin(rows, pdfdir) if r["_I"] in idb}
b_mine = {r["_I"]: r for r in m.verify_fin(rows, pdfdir) if r["_I"] in idb}
C._PAGES.clear()
C._PAGES.update(saved)
nb = [i for i, r in b_native.items() if r["_V"] == "BADITEM"]
back = [i for i in nb if b_mine[i]["_V"] in ("PRESENT", "ALIGNED")]
print("B) 字元框讀法把科目列讀壞 %d 筆(桌機的樣子)· core %s · v0113 %s · core BADITEM %d → v0113 回到 PRESENT / ALIGNED %d" % (len(idb), dict(Counter(r["_V"] for r in b_native.values())), dict(Counter(r["_V"] for r in b_mine.values())), len(nb), len(back)))
for i in nb[:3]:
    print("   例:%s p%s %r → %s · %s" % (b_mine[i]["FILENAME"][:34], b_mine[i]["PAGE"], b_mine[i]["ITEM"], b_mine[i]["_V"], b_mine[i]["_N"][:150]))
assert nb and len(back) == len(nb), (len(nb), len(back))
print("[PASS] v0113 回歸 + 變造")
