"""v0151 整包重建(冪等):pkg151 → 套件 zip → VRN2_RoundAll_v0104.py(填套件雜湊)+ 一行啟動(pwsh / powershell / cmd)md → 發行清單 → 一鍵 v0151 md → 操作員 v0112 md → 本地實測一輪 v0101(新版 · v0100 在 main 不動)。"""
import base64, hashlib, json, re, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); out, rel, op12, new = S / "v151/pkg151", S / "v151/release151", S / "v151/operator112", S / "v151/new"
rel.mkdir(exist_ok=True); op12.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
rt = json.loads((out / "VRN2_Runtime_v0151.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN2_IndependentVerifier_v0113.py"]
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0151.py", "VRN2_Runtime_v0151.zip", "VRN2_Runtime_v0151.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0151 — VRN-2 closeout package (2026-10-29 · close-out round)\n\nEntry: python ActivateVRN-2_v0151.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0104.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → close-out page (HTML U/I) → paste-back zip.\n"
  "Runtime: VRN2_Runtime_v0151.zip = runtime v0150 (186 members byte-identical) + VRN2_IndependentVerifier_v0113,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0151 (operator 2026-10-29: solve the remaining system issues · HTML U/I · CLOSE OUT):\n"
  " - step 11 IndependentVerifier v0113: annual-data BADITEM (MS-3665 / MS-8358 / MS-8210 / Daiwa aspeed, every value on the page) came from the\n"
  "   character-box reader only; an item is read a second way (PDFium whole-page text + pdfplumber lines) before it is called 'not on this page'.\n"
  "   Fabricated / renamed items stay BADITEM (with the closest source line); values not on the page stay FAIL (with the item's source line).\n"
  " - RoundAll v0104 writes VIA_Reports/vrn2/VRN2_CloseoutUI_latest.html: every open item with its owner (VRN-2 / VCGC / human check /\n"
  "   data source / reminder) and a close-out state OPEN > BLOCKED > REVIEW > DATA_GAP > PASS (only PASS is success).\n"
  "Verification: see VRN2_Verification_v0151.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0151.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0151", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0151.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0151/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll v0104 =====
ra_src = (new / "VRN2_RoundAll_v0104.py").read_text(encoding="utf-8")
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0104.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
boot0 = (S / "v150/release150/boot_roundall.ps1").read_text(encoding="utf-8")
ra_boot = boot0.replace("vrn2_release_v0150", "vrn2_release_v0151").replace("VRN2_RoundAll_v0103.py", "VRN2_RoundAll_v0104.py")
ra_boot = re.sub(r"\$H  = '[0-9a-f]{64}'", "$H  = '%s'" % ra_sha, ra_boot, count=1)
assert ra_sha in ra_boot and "v0150" not in ra_boot and "v0103" not in ra_boot and "$ProgressPreference" in ra_boot
enc = base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii")
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_one) < 8191
ra_pwsh = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_pwsh) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8"); (rel / "oneline_roundall_pwsh.txt").write_text(ra_pwsh + "\n", encoding="utf-8")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0104.py(一個指令:取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯報告 → 收尾頁 HTML U/I → 貼回包)

`VRN2_RoundAll_v0104.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪;套件 = `VRN2_Closeout_v0151.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。
v0104 = v0103 + 收尾輪(操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」):

| 剩下的問題 | 根因 | v0151 / v0104 怎麼處理 |
|---|---|---|
| ⑪ 年度數據 BADITEM 19(MS-3665 ×7 · MS-8358 ×6 · MS-8210 ×4 · Daiwa aspeed ×2:「ModelWare net inc (NT $ mn)」「Prior EPS (NT$)\\*\\*」「DPS」· 值都在該頁) | 「科目本頁原文沒有」只問字元框讀法 —— 跟 v0112 修的 MS 側欄同一個讀法,在桌機的函式庫版本把科目列讀壞(容器的同名 PDF 是合成樣本,真檔只在桌機) | **IndependentVerifier v0113**:判 BADITEM 前先用第二種讀法(PDFium 整頁文字 + pdfplumber 文字行)找科目(整個科目 · 折行 · 兩個字以上依序在三列內);找到 → 回到原判決(PRESENT / ALIGNED);造假 / 改名的科目兩種讀法都沒有 → 照樣 BADITEM,註記帶原文最像的那一列。容器:原樣 4,378 筆判決 0 差異 · 變造科目名 60 / 60 照樣 BADITEM · 模擬桌機讀壞科目列 59 / 59 回到 PRESENT |
| 跑完不知道「到底結案沒有、剩下的是誰的事」 | 總表只有燈號數;黃燈混了 VRN-2 要修的、VCGC 的決定、要人看原文的、外部來源本來就沒有的 | **⑧ 收尾頁(HTML U/I)** `VIA_Reports\\\\vrn2\\\\VRN2_CloseoutUI_latest.html`:每一列非綠結果判負責方(VRN-2 要修 · 交 VCGC · 人工核對 · 資料源沒有 · 提醒 · 彙總),結案狀態 OPEN > BLOCKED > REVIEW > DATA_GAP > PASS;待辦表可依負責方篩、搜尋;檔案連結;下次指令一鍵複製;跑完自動開 |
| ⑥ Combined 冊「調整後目標價空 15」 | 15 列多半是報告本來就沒有目標價(產業 / 中立 / 未評等),v0103 也算成缺 | 空格照原因分:原文沒有目標價(不是缺)· 沒有市場資料 · 報告日前沒有日資料 · 鉅亨沒有這檔 FactSet 頁(404)· 共識有這檔但來源沒有這欄 |

**收尾狀態怎麼讀**:OPEN = VRN-2 還有要修的(貼回包給 AI)· BLOCKED = VRN-2 側沒有待修、剩 VCGC 的決定 / 安裝 · REVIEW = 剩要人看原文的 · DATA_GAP = 剩外部來源本來沒有的(已附證據)· PASS = 全綠。
**BLOCKED / REVIEW / DATA_GAP 都不是成功**;VCGC 的 `closeout_lamp` 才是 VCGC 驗收(四系統對等 · 只讀互看)。用桌機 19:00 那輪的 39 列結果試算:**BLOCKED**(VRN-2 0 · VCGC 3 · 人工 8 · 資料源 4 · 提醒 3)。

## 一個指令(PowerShell 7.6.9 / cmd 都能貼 · 建議)

```bat
@PWSH@
```

沒有 PowerShell 7(`pwsh`)時用這一行(Windows PowerShell 5.1 · 內容一樣):

```bat
@ONE@
```

## 在 PowerShell 7 視窗裡直接貼(7.0 以上 · 例 7.6.9 · 不用 Base64 · 看得懂每一步)

```powershell
@PS7@
```

同一套步驟改寫成 PowerShell 7 語法(`??` · `[Convert]::ToHexString` · `SHA256.HashData`):包在 `& { … }` 裡、錯了用 `return` 不用 `exit` —— **貼在 PowerShell 視窗裡跑完視窗不會關**。不是 7 以上會印 RED 停下。
環境變數照用:`$env:VRN2_ROOT`(VIA 根)· `$env:VRN2_PY`(指定 python)· `$env:VRN2_ROUNDALL_ARGS`(多帶給 RoundAll 的參數,例 `'--skip-run --integrate yes'`)。

它從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)取 `VRN2_RoundAll_v0104.py` → **核對 SHA-256**(`@RASHA12@`)→ 存到 `Downloads` → 用你的 python 執行 → 跑完印總表、收尾狀態、`NEXT:` 與貼回包位置,並開收尾頁。
VIA 根不在 `C:\\Users\\tonyk\\OneDrive\\Documents\\movies-dataset\\VeritasIntelligenceAnalytics` 就先設(cmd:`set VRN2_ROOT=…` · PowerShell:`$env:VRN2_ROOT='…'`)。

## 已經有這個檔時

```bat
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0104.py"
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0104.py" --skip-run --integrate yes
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0104.py" --only report,closeout
```

第 3 行 = 不跑不修,只重做除錯報告 + 收尾頁(幾秒)。PowerShell 把 `%USERPROFILE%` 換成 `$env:USERPROFILE`。常用參數:`--source <報告夾>` · `--integrate ask|yes|no|skip` · `--no-open` · `--ship` · `--offline` · `--python <VRN-2 的 python>` · `--skip-selftest` · `--skip-closeout` · `--selftest`。

## 程式碼決定不了的(收尾頁會分好)

- **交 VCGC**:⑥e MOPS 財報 —— VIA 鎖版網路工具的合規層拒絕(`Existing VIA network bridge denied this request`),VRN-2 / VDF 不繞;在那之前 ⑬b 會是「無歷史」(灰),價格與還原價照常。
- **人工核對**:MQ-1560 影像頁 4 點 OCR 摘錄要對原圖;⑪ 還標著的基本資料值(看 `⑪ 基本資料 FAIL 證據` 逐值原文 · MS-8358 現價 510.00 / MS-8210 上漲空間 18 先看 v0112 第二種讀法有沒有解掉);年度數據缺項 3 份(原文真的沒有年度表就是沒有)。
- **資料源沒有**:鉅亨沒有 6933 / 4171 的 FactSet 頁(404)· Yahoo / TWSE 沒有的檔或日子。

## 一行解開來的程式碼(核對用 · 兩行解開都是這段)

```text
@BOOT@
```
"""
ps7 = (S / "v151/ps7/line_ps7.txt").read_text(encoding="utf-8").strip("\n")
assert ("$H = '%s'" % ra_sha) in ps7 and "vrn2_release_v0151" in ps7 and "VRN2_RoundAll_v0104.py" in ps7 and "exit" not in ps7
ra_md = ra_md.replace("@PS7@", ps7)
ra_md = ra_md.replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PWSH@", ra_pwsh).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
for kind, b64 in re.findall(r"(?s)```bat\n(pwsh|powershell) -NoProfile -ExecutionPolicy Bypass -EncodedCommand (\S+)\n```", ra_md):
    assert base64.b64decode(b64).decode("utf-16-le") == ra_boot
assert len(re.findall(r"EncodedCommand", ra_md)) == 2
(rel / "VRN2_RoundAll_v0104.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0151 + VRN2_RoundAll_v0104", "date": "2026-10-29",
        "trigger": "操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」(貼回的是桌機 19:00 跑 VRN2_RoundAll_v0102 的主控台 · 紅 0 黃 20 · v0150 已處理的不重做)",
        "base_package": {"name": "VRN2_Closeout_v0150 (launcher v0150 · runtime v0150)", "retained": "runtime v0150 members byte-identical inside runtime v0151; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0150 for the closeout entry; VRN2_RoundAll v0103 → v0104; VRN-2 one-click v0150 → v0151; operator one-click v0111 → v0112; local round v0100 → v0101 (v0100 is in main and stays as is)",
        "fixes": {"IndependentVerifier_v0113": "annual-data BADITEM 19 on the desktop (MS-3665 / MS-8358 / MS-8210 / Daiwa aspeed; values on the page) came from the character-box reader only → the item is read a second way (PDFium whole-page text + pdfplumber lines; whole item · wrapped · words in order within three lines) before BADITEM; container: 4,378 unchanged rows 0 verdict changes · 60 / 60 fabricated items still BADITEM · 59 / 59 simulated desktop char-box misses back to PRESENT; full run v0112 vs v0113 identical (4,905 annual rows)",
                  "RoundAll_v0104_closeout_ui": "VIA_Reports/vrn2/VRN2_CloseoutUI_latest.html + .json: every non-green result with its owner (VRN-2 / VCGC / human check / data source / reminder / aggregate), close-out state OPEN > BLOCKED > REVIEW > DATA_GAP > PASS (only PASS is success; unknown → VRN-2), filters / search / file links / next commands with copy, offline, light / dark, phone width; opened at the end on Windows (--no-open / VRN2_NO_UI=1 skip); in the paste-back zip",
                  "RoundAll_v0104_combined_gaps": "Combined empties split by reason: no target price in the report (not a gap) · no market data · no daily data before the report date · cnyes has no FactSet page (404) · source has no such field",
                  "launcher_v0151": "receipt VRN2_Closeout_v0151.json · selftest checks the runtime's newest IndependentVerifier is v0113"},
        "not_fixed_here": {"MOPS_DENY": "VDF financial fetch through the VIA network bridge is denied by its compliance layer (never bypassed by VDF / VRN-2) → VCGC decision; close-out page lists it under VCGC",
                           "OCR_PENDING_4": "MQ-1560 20260520.pdf image page: OCR excerpts need a human look at the image (close-out page: human check)",
                           "annual_gaps_3": "Daiwa-6278 / 3264 / 6143 annual data missing: check whether the source has an annual table (close-out page: human check)",
                           "MS_8358_8210": "basic-info values the verifier still flags (if any after v0112's second reading) are listed per value with source lines (human check)",
                           "6e_duration": "VDF engine re-fetches every price window each round by operator rule (~30 min on the desktop); not changed"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0151.json inside the package"},
        "roundall": {"name": "VRN2_RoundAll_v0104.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0104.md"},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · 19 real sample files · chromium (close-out page)", "results": {"status": "see VRN2_Verification_v0151.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0151/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0151.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0151.py"]).hexdigest()},
        "oneclick": "VRN2_OneClick_v0151.md", "test_tools_zip": "vrn2_test_tools_v0151.zip", "logs_zip": "logs_v0151.zip"}
(rel / "VRN2_Release_v0151.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
# ===== one-click v0151 from v0150 =====
md = (REPO / "vrn2_release_v0150/VRN2_OneClick_v0150.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); old_cs = hashlib.sha256(ps.encode("utf-8")).hexdigest(); assert old_cs in boot
HEAD0 = "  # ===== VRN-2 一鍵 v0150(套件 v0150 = 啟動器 v0150 + runtime v0150 = v0149 + IndependentVerifier v0112 + ConsensusJoin v0102;"
BAN0 = "[計] VRN-2 一鍵 v0150 · ActivateVRN-2 v0150(套件 · 私有 runtime v0150 = v0149 + "
outl, nh, nb = [], 0, 0
for line in ps.split("\n"):
    if line.startswith(HEAD0):
        nh += 1
        line = ("  # ===== VRN-2 一鍵 v0151(套件 v0151 = 啟動器 v0151 + runtime v0151 = v0150 + IndependentVerifier v0113;v0151 = 收尾輪(操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」):"
                "⑪ BADITEM 先用第二種讀法找科目 · 另一支 Python 升 VRN2_RoundAll_v0104(⑧ 收尾頁 HTML U/I);"
                "v0150 = 套件 v0150 = 啟動器 v0150 + runtime v0150 = v0149 + IndependentVerifier v0112 + ConsensusJoin v0102;" + line[len(HEAD0):])
    elif BAN0 in line:
        nb += 1
        i = line.index(BAN0)
        line = line[:i] + "[計] VRN-2 一鍵 v0151 · ActivateVRN-2 v0151(套件 · 私有 runtime v0151 = v0150 + IndependentVerifier v0113(BADITEM 第二種讀法);另一支 Python VRN2_RoundAll_v0104.py(收尾頁);v0150 = v0149 + " + line[i + len(BAN0):].replace("另一支 Python VRN2_RoundAll_v0103.py;", "")
    else:
        line = line.replace("VRN2_Handover_v0151.md", "VRN2_Handover_v0152.md").replace("v0150", "v0151").replace("VRN2_RoundAll_v0103", "VRN2_RoundAll_v0104")
    outl.append(line)
assert nh == 1 and nb == 1, (nh, nb)
ps = "\n".join(outl)
ps = re.sub(r"\$Want   = '[0-9a-f]{64}'   # VRN2_Closeout_v0151\.zip SHA-256[^\n]*", lambda m: "$Want   = '%s'   # VRN2_Closeout_v0151.zip SHA-256(套件 · 內含啟動器 v0151 + runtime v0151 清單 = v0150 + IndependentVerifier v0113)" % want, ps, count=1)
assert want in ps and old_want not in ps
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0150" in code and "v0150 =" not in code), line[:200]
assert "VRN2_UIAction_v0110\\.py" in ps and "VRN2_RoundAll_v0104.py" in ps
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(old_cs, cs).replace("vrn2_release_v0150", "vrn2_release_v0151").replace("VRN2_OneClick_v0150.md", "VRN2_OneClick_v0151.md").replace("v0150", "v0151") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", md, count=1)
head = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", head, count=1)
head = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", head, count=1)
head = head.replace(old_want, "@WANT@").replace(old_cs, "@CS@").replace(old_cs[:12], "@CS@")


def hrep(a, b):
    global head
    assert head.count(a) == 1, (head.count(a), a[:80]); head = head.replace(a, b)


def hline(prefix, b):
    global head
    ls = head.split("\n"); idx = [i for i, l in enumerate(ls) if l.startswith(prefix)]; assert len(idx) == 1, (prefix, idx); ls[idx[0]] = b; head = "\n".join(ls)


hline("# VRN-2 一鍵 v0150(", "# VRN-2 一鍵 v0151(cmd / PowerShell 都能貼 · 套件 v0151 = 啟動器 v0151 + runtime v0151 = v0150 + IndependentVerifier v0113 · 收尾輪)")
hrep("v0150 = v0149 入口 + runtime v0150(= runtime v0149 的 184 個成員逐位元保留 + 2 個新檔):",
     "操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」→ 收尾輪 v0151;另一支 Python 升 **`VRN2_RoundAll_v0104.py`**(同發行夾 · 一個指令:`VRN2_RoundAll_v0104.md` 的 pwsh 那一行 · 跑完開 **收尾頁** `VIA_Reports\\vrn2\\VRN2_CloseoutUI_latest.html`:待辦依負責方 VRN-2 / VCGC / 人工核對 / 資料源 分好,結案狀態 OPEN > BLOCKED > REVIEW > DATA_GAP > PASS)。\n\n"
     "v0151 = v0150 入口 + runtime v0151(= runtime v0150 的 186 個成員逐位元保留 + 1 個新檔):\n\n| 元件 | 版本 | 修了什麼 |\n|---|---|---|\n"
     "| ⑪ 獨立驗證 | VRN2_IndependentVerifier v0113(v0112 留著)| 年度數據 BADITEM:「科目本頁原文沒有」以前只問字元框讀法(桌機 MS-3665 / MS-8358 / MS-8210 / Daiwa aspeed 19 筆 · 值都在該頁)→ 先用第二種讀法找科目(整個 · 折行 · 依序在三列內)才判;造假 / 改名的科目照樣 BADITEM、註記帶原文最像的列 |\n"
     "| 啟動器 | ActivateVRN-2 v0151 | 收據 `VRN2_Closeout_v0151.json` · 自測多一段 v0151(runtime 最新驗證器 = v0113)· 步驟不變 |\n\n"
     "前一版 v0150 = v0149 入口 + runtime v0150(= runtime v0149 的 184 個成員逐位元保留 + 2 個新檔):")
hrep("| 啟動器 | ActivateVRN-2 v0150 |", "| 啟動器(v0150)| ActivateVRN-2 v0150 |")
hrep("| 步驟 | v0150 做什麼 |", "| 步驟 | v0151 做什麼 |")
hrep("| ① ② ③ ③b | 同 v0149(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|", "| ① ② ③ ③b | 同 v0150(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|")
hline("| ④ | `python ActivateVRN-2_v0150.py", "| ④ | `python ActivateVRN-2_v0151.py [--source …]`:單機閘 → ①~⑤ → ⑤b SSOT-ID 核號同步 → ⑥ → ⑦(管理器 v0255)→ ⑥e 市場擷取(MarketFetchRun:合 VDF 界線的 Python)→ ⑥f 共識合併(上櫃 .TWO · 404 無覆蓋不納閘 · Combined 冊)→ ⑧~⑫(⑪ 驗證器 v0113)→ ⑫b 補放 → 四點原文核對(v0105)→ 收據 → ⑬b 歷史對齊 → ⑬ 長線 Parquet 庫 → ⑬c 舊資料庫整合掃描 → Workbench v0102 |")
hline("| ⑤ | 摘要多七行", "| ⑤ | 摘要多七行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID · 階段耗時 · ⑥e 市場擷取 · ⑥f 共識合併 · ⑬b 歷史對齊 · ⑬c 舊資料庫整合(都讀 `VRN2_Closeout_v0151.json`)+ 一行指向 `VRN2_RoundAll_v0104.py`(收尾頁)|")
hline("| ⑤b ⑤c |", "| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\\\VRN2\\\\VRN2_UIAction_v0110.py`(設定檔 v0151 · `vrn2://integrate` 取最新的 DataIntegrate = v0101)· U/I 有輸入區塊 · 沒開就代開 |")
for a, b in (("VRN2_OneClick_v0150", "VRN2_OneClick_v0151"), ("套件 `VRN2_Closeout_v0150.zip`", "套件 `VRN2_Closeout_v0151.zip`"), ("從 `vrn2_release_v0150` 取", "從 `vrn2_release_v0151` 取"), ("Downloads\\VRN2_Closeout_v0150`", "Downloads\\VRN2_Closeout_v0151`")):
    head = head.replace(a, b)
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and "@" + "WANT@" not in newmd and cs in boot
(rel / "VRN2_OneClick_v0151.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot151.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline151.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0151.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0151", cs[:12])
# ===== operator v0112 from v0111 =====
md11 = (REPO / "vrn1_vrn2_oneclick_v0111/VRN1_VRN2_OneClick_v0111.md").read_text(encoding="utf-8")
p11 = re.search(r"(?s)```powershell\n(.*?)\n```", md11).group(1); boot11o = re.search(r"(?s)```text\n(.*?)\n```", md11).group(1)
cs11_old = hashlib.sha256(p11.encode("utf-8")).hexdigest(); assert cs11_old in boot11o
p12 = p11


def rep12(a, b):
    global p12
    assert p12.count(a) == 1, (p12.count(a), a[:80]); p12 = p12.replace(a, b)


rep12("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0150'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0151'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0150 程式碼 SHA-256", p12).group(1); assert old_h2 == old_cs
rep12("  $H2 = '%s'   # VRN-2 一鍵 v0150 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0151 程式碼 SHA-256" % cs)
rep12("  # ===== VRN-1 / VRN-2 操作員一鍵 v0111(2026-10-29 · ② 改指 VRN-2 一鍵 v0150:",
      "  # ===== VRN-1 / VRN-2 操作員一鍵 v0112(2026-10-29 · ② 改指 VRN-2 一鍵 v0151:收尾輪 · ⑪ BADITEM 第二種讀法;另一支 Python VRN2_RoundAll_v0104.py(收尾頁 HTML U/I);v0111 · ② 改指 VRN-2 一鍵 v0150:")
rep12("操作員一鍵 v0111 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0112 · {0} · VRN-1 {1} · VIA {2}")
outl = []
for line in p12.split("\n"):
    if "操作員一鍵 v0112(2026-10-29 · ② 改指 VRN-2 一鍵 v0151" not in line:
        line = line.replace("VRN2_OneClick_v0150.md", "VRN2_OneClick_v0151.md").replace("VRN-2 一鍵 v0150", "VRN-2 一鍵 v0151").replace("套件 v0150 = 啟動器 v0150 + runtime v0150", "套件 v0151 = 啟動器 v0151 + runtime v0151").replace("ActivateVRN-2_v0150 單機閘", "ActivateVRN-2_v0151 單機閘")
    outl.append(line)
p12 = "\n".join(outl)
for line in p12.splitlines():
    code = line.split("#", 1)[0]
    assert "v0150" not in code, line[:160]
cs12 = hashlib.sha256(p12.encode("utf-8")).hexdigest()
boot12 = boot11o.replace(cs11_old, cs12).replace("vrn1_vrn2_oneclick_v0111", "vrn1_vrn2_oneclick_v0112").replace("VRN1_VRN2_OneClick_v0111.md", "VRN1_VRN2_OneClick_v0112.md").replace("操作員一鍵 v0111", "操作員一鍵 v0112") + "\n"
assert "v0111" not in boot12
one12 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot12.encode("utf-16-le")).decode("ascii"); assert len(one12) < 8191
title11, rest11 = md11.split("\n\n", 1)
assert title11.startswith("# VRN-1 / VRN-2 操作員一鍵 v0111(")
rest = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", rest11, count=1)
rest = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", rest, count=1)
rest = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", rest, count=1)
rest = rest.replace(cs11_old, cs12).replace(cs11_old[:12], cs12[:12])
text = ("# VRN-1 / VRN-2 操作員一鍵 v0112(cmd / PowerShell 都能貼 · v0111 + ② 改指 VRN-2 一鍵 v0151:收尾輪 · ⑪ BADITEM 第二種讀法)\n\n"
        "操作員 2026-10-29「解決剩餘系統問題 HTML U/I CLOSE OUT」→ VRN-2 v0151 + `VRN2_RoundAll_v0104.py`(`vrn2_release_v0151` · 一個指令見 `VRN2_RoundAll_v0104.md` 的 pwsh 那行 · 跑完開收尾頁)。v0112 = v0111 + ② 改指 **VRN-2 一鍵 v0151**"
        "(套件 v0151 = 啟動器 v0151 + runtime v0151 = v0150 + IndependentVerifier v0113);其餘一字不改。\n\n" + rest)
text = text.replace("@PS@", p12).replace("@BOOT@", boot12.rstrip("\n")).replace("@ONE@", one12)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p12 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot12
(op12 / "VRN1_VRN2_OneClick_v0112.md").write_text(text, encoding="utf-8", newline="\n"); (op12 / "boot_pair112.ps1").write_text(boot12, encoding="utf-8", newline="\n"); (op12 / "oneline_pair112.txt").write_text(one12 + "\n", encoding="utf-8"); (op12 / "Run-VRN1-VRN2-v0112.ps1").write_text(p12 + "\n", encoding="utf-8", newline="\n"); (op12 / "code_sha.txt").write_text(cs12)
(op12 / "VRN1_VRN2_Verification_v0112.md").write_text(
    "# VRN-1 / VRN-2 操作員一鍵 v0112 · 容器驗證(2026-10-29)\n\nv0112 = v0111 的程式碼只改四處:② 發行夾 `vrn2_release_v0150` → `vrn2_release_v0151`、`$H2` → VRN-2 一鍵 v0151 程式碼 SHA-256(`%s`)、橫幅「操作員一鍵 v0111」→「v0112」、② 的步驟名 / 檔名 v0150 → v0151;歷史子句與 md 歷史段落照舊。\n\n"
    "| 檢查 | 結果 |\n|---|---|\n| pwsh 7.4.6 語法剖析(Run-VRN1-VRN2-v0112.ps1 · boot_pair112.ps1)| 見 `vrn2_release_v0151/logs_v0151.zip` 的 `pscheck151.log` |\n| 本段程式碼 SHA-256 = boot 裡的 `$H` | 同上 |\n| 一行(-EncodedCommand)解碼 = boot | 同上 |\n"
    "| `$H2` = `VRN2_OneClick_v0151.md` 程式碼 SHA-256 | 同上 |\n| 橫幅版號 | `操作員一鍵 v0112` |\n| 本地實測一輪 v0101 的 `$H_OP` = 本段程式碼 SHA-256 | 同上 |\n\n沒有 .ps1 進倉:一鍵程式碼只在本夾的 md 裡,`tools_v0112.zip` 是容器測試用副本。\n" % cs[:12], encoding="utf-8", newline="\n")
print("operator v0112", cs12[:12])
# ===== LocalRound v0101(新版 · v0100 已在 main · 不改)=====
src = (REPO / "VRN2_LocalRound_v0100.md").read_text(encoding="utf-8")
s = src


def lrep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)


lrep("# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0150(開 Workbench)→ 打包貼回材料)", "# VRN-2 本地實測一輪 v0101(一段 PowerShell 貼上:logo → 補船 → 跑 v0151(開 Workbench)→ 打包貼回材料)")
lrep("> **2026-10-29 v0150 改指(", "> **2026-10-29 v0101(收尾輪 · 操作員「解決剩餘系統問題 HTML U/I CLOSE OUT」):** v0100 已合進 main、照規則不改 → 新版 v0101 指 操作員一鍵 **v0112** → VRN-2 一鍵 **v0151**(⑪ BADITEM 第二種讀法)。另一支 Python 升 **`vrn2_release_v0151/VRN2_RoundAll_v0104.py`**(跑完開收尾頁 `VRN2_CloseoutUI_latest.html`:待辦依負責方分好)。\n> **2026-10-29 v0150 改指(")
lrep("本段現在指 操作員一鍵 **v0111** → VRN-2 一鍵 **v0150**", "本段當時指 操作員一鍵 **v0111** → VRN-2 一鍵 **v0150**")
lrep("從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0111.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0150 套件**(啟動器 v0150 → ⑪ 驗證器 v0112 · ⑥f ConsensusJoin v0102;v0149 的 ", "從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0112.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0151 套件**(啟動器 v0151 → ⑪ 驗證器 v0113;v0150 的 ⑥f ConsensusJoin v0102;v0149 的 ")
lrep("最後 300 行貼包 · `VRN2_Closeout_v0150.json` ·", "最後 300 行貼包 · `VRN2_Closeout_v0151.json` · `VRN2_CloseoutUI_latest.html` ·")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0111 程式碼 SHA-256\(VRN1_VRN2_OneClick_v0111\.md powershell 區塊 · ② 指 VRN-2 一鍵 v0150\)", "$H_OP = '%s'   # 操作員一鍵 v0112 程式碼 SHA-256(VRN1_VRN2_OneClick_v0112.md powershell 區塊 · ② 指 VRN-2 一鍵 v0151)" % cs12, s, count=1); assert cs12 in s
lrep("  $k3 = '③ 跑 VRN-2 v0150'", "  $k3 = '③ 跑 VRN-2 v0151'")
lrep("  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0111' 'VRN1_VRN2_OneClick_v0111.md' $H_OP", "  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0112' 'VRN1_VRN2_OneClick_v0112.md' $H_OP")
lrep("  foreach ($rel in 'VRN2_Closeout_v0150.json', 'VRN2_RoundAll_latest.json',", "  foreach ($rel in 'VRN2_Closeout_v0151.json', 'VRN2_CloseoutUI_latest.html', 'VRN2_CloseoutUI_latest.json', 'VRN2_RoundAll_latest.json',")
(rel / "VRN2_LocalRound_v0101.md").write_text(s, encoding="utf-8", newline="\n"); print("localround v0101 H_OP", cs12[:12])
