"""VRN2_Handover_v0152.md:從 v0151 只增不減(v0151 在 main · 不改)。"""
import json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v151")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0151.md").read_text(encoding="utf-8")
R = json.loads((S / "release151/VRN2_Release_v0151.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg151/VRN2_Runtime_v0151.json").read_text(encoding="utf-8"))["files"]}


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)


lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0150 + VRN2_RoundAll_v0103 · 2026-10-29(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0151 + VRN2_RoundAll_v0104 · 2026-10-29(v0150 + 收尾輪:操作員「解決剩餘系統問題 HTML U/I CLOSE OUT」→ "
            "IndependentVerifier v0113(BADITEM 先用第二種讀法找科目)· RoundAll v0104(⑧ 收尾頁 HTML U/I:待辦依負責方 · 結案狀態 · Combined 空格照原因分)· "
            "一鍵 v0151 · 操作員一鍵 v0112 · 本地實測一輪 v0101;runtime v0150 的 186 個成員一個位元組都不動 · +1 個新檔)")
src = "\n".join(lines)
e2e = res["roundall_e2e"]; fx = res.get("roundall_fix_pass") or {}; pg = res.get("closeout_page_after_fix") or {}
anchor = "> **桌機貼回(2026-10-29 19:00 · 跑 VRN2_RoundAll_v0102"
new_round = ("> **桌機 2026-10-30 14:41(RoundAll v0105 · 3977 秒)**:紅 0 · 黃 16 · ⑪ 基本資料 FAIL 0(MS-6669 / 3661 / 8358 / 8210 都好了)· 年度 BADITEM 19 → 0(PRESENT 82 → 101 · v0113 生效)· 年度 FAIL 1(Daiwa aspeed PBR 26E n.a.)· "
             "收尾 OPEN「VRN-2 2 項」= ② CPU 忙碌 93%% + ⑥ Combined 1 格「基本資料冊代號不是 4 碼」(分類規則不夠細)· `icacls` 對舊套件 zip:Access is denied(`/reset` 非系統管理員也被拒)。"
             "**RoundAll v0106**:② CPU → 提醒 · 代號不是 4 碼 → 冊裡 TICKER 空白 = 人工 / 有值 = 資料源 · 空格原因列檔名 · 新「⑪ 年度數據 FAIL 證據」(讀原 PDF 那頁的表頭 + 科目列依欄位對齊 → 原文該期間的值 vs 冊值)· "
             "套件安裝改成正常建夾 + 逐檔複製(v0104 / v0105 把 Python 3.13 只給擁有者權限的暫存夾整個搬進 Downloads → 某次系統管理員身分跑過就讀不到)。用 14:41 那 10 項重算 → BLOCKED(VRN-2 0 · VCGC 3)。\n"
             "> **桌機 2026-10-30 13:15 / 13:21(PowerShell 7.6.9 原生一行跑 RoundAll v0104)**:兩次都在 ① 讀 `Downloads\\VRN2_Closeout_v0151\\VRN2_Closeout_v0151.zip` 時 `PermissionError [Errno 13]` → Traceback(沒有收尾頁 / 貼回包;隔 6 分鐘一樣 → 不是防毒短暫鎖)。"
             "**RoundAll v0105**:讀不到重試 → 印證據(啟動器鎖 PID · icacls · attrib)→ 改從 GitHub 取 → 原套件夾用不了換新夾 `VRN2_Closeout_v0151_<時間>` · 每一步出例外只記紅不中斷 · 收尾頁 / 貼回包照產生(讀不到的檔略過並記下)· ⑥f 過時的 Combined 黃 → 提醒。自測 34 項 · 沙盒模擬讀不到 → 改 GitHub → 照跑完。套件 / 一鍵 / 操作員 / 本地實測一輪逐位元不變。\n"
             "> **收尾輪(2026-10-29 · 操作員「解決剩餘系統問題 HTML U/I CLOSE OUT」· 貼回的是 19:00 那輪的主控台 · v0150 已處理的不重做 · 分支 #573 已合進 main → 快轉後接著做)**:\n"
             "> **本輪(v0151 · 套件 = 啟動器 v0151 + runtime v0151 = v0150 的 186 個成員不動 + IndependentVerifier v0113 · 一支 Python `vrn2_release_v0151/VRN2_RoundAll_v0104.py` · 一鍵 v0151 · 操作員一鍵 v0112 · 本地實測一輪 v0101)**:"
             "① **IndependentVerifier v0113**(結構複本 · v0112 留著):桌機年度數據 BADITEM 19(MS-3665 ×7 · MS-8358 ×6 · MS-8210 ×4 · Daiwa aspeed ×2 ·「ModelWare net inc (NT $ mn)」「Prior EPS (NT$)**」「DPS」· 值都在該頁)"
             "只有字元框讀法說「科目本頁原文沒有」(跟 v0112 修的側欄同一個讀法)→ 判 BADITEM 前先用第二種讀法(PDFium 整頁文字 + pdfplumber 文字行)找科目(整個 · 折行 · 兩字以上依序在三列內);"
             "造假 / 改名的科目照樣 BADITEM、註記帶原文最像的那一列;值不在該頁的 FAIL 註記帶科目那一列。容器:原樣 4,378 筆 0 差異 · 變造科目名 60 / 60 照樣 BADITEM · 模擬桌機讀壞科目列 59 / 59 回到 PRESENT · 整支跑 v0112 vs v0113 年度 4,905 筆逐筆同判。"
             "② **RoundAll v0104 · ⑧ 收尾頁** `VIA_Reports\\vrn2\\VRN2_CloseoutUI_latest.html`(+ .json · 進貼回包 · Windows 跑完自動開):每列非綠結果判負責方(VRN-2 要修 / 交 VCGC / 人工核對 / 資料源沒有 / 提醒 / 彙總 · 認不出 = VRN-2),"
             "結案狀態 OPEN > BLOCKED > REVIEW > DATA_GAP > PASS(只有 PASS 是成功);用 19:00 那輪 39 列試算 = **BLOCKED**(VRN-2 0 · VCGC 3 · 人工 8 · 資料源 4)。Combined 空格照原因分(原文沒有目標價不是缺)。"
             "③ **端到端(沙盒仿桌機 · pwsh 一行指令從假 GitHub 分支取 RoundAll v0104)**:%s;只修回合:%s;修後收尾頁:%s。\n"
             % (e2e.get("summary", "見驗證紀錄"), fx.get("summary", "見驗證紀錄"), "%s · %s · %s" % (pg.get("state"), pg.get("state_text"), json.dumps(pg.get("per_owner") or {}, ensure_ascii=False))))
assert src.count(anchor) == 1
src = src.replace(anchor, new_round + anchor, 1)
once("> **本輪(v0150 · 套件 = 啟動器 v0150 + runtime v0150", "> **前一輪(v0150 · 套件 = 啟動器 v0150 + runtime v0150")
anchor = "| **VRN2_RoundAll_v0103.py**(發行夾 · 一支入口 · 不在套件內)| **v0103** |"
v106 = ("| **VRN2_RoundAll_v0106.py**(發行夾 · 一支入口 · 不在套件內)| **v0106** | `vrn2_release_v0151` | `%s` | **新**(2026-10-30 14:41 桌機貼回:收尾分類 ② CPU → 提醒 · Combined 代號不是 4 碼 → 人工 / 資料源 + 列檔名 · ⑪ 年度 FAIL 證據(原文表頭 + 科目列依欄位對齊)· 套件安裝不搬暫存夾(Python 3.13 暫存夾權限)· 自測 39 項)|\n" % R["roundall"]["sha256"][:12])
v105 = ("| **VRN2_RoundAll_v0105.py**(發行夾 · 一支入口 · 不在套件內)| **v0105** | `vrn2_release_v0151` | `9edb8912770f` | 被 v0106 取代(2026-10-30 桌機:v0104 ① 讀本機套件 zip PermissionError → Traceback;讀不到重試 → 證據 → 改從 GitHub 取 → 原夾用不了換新夾 · 每步出例外不中斷 · 收尾頁 / 貼回包照產生 · 自測 34 項)|\n")
assert src.count(anchor) == 1
rows = ("| **VRN2_RoundAll_v0104.py**(發行夾 · 一支入口 · 不在套件內)| **v0104** | `vrn2_release_v0151` | `8333c1719127`%s | **新**(套件 v0151 · ⑧ 收尾頁 HTML U/I · Combined 空格照原因分 · 自測 29 項)|\n"
        "| ActivateVRN-2_v0151.py(套件 · 底座 v0136)| **v0151** | 見發行清單 | `%s` | **新**(收據 v0151 · 自測多一段 v0151 · 步驟不變)|\n"
        "| **VRN2_IndependentVerifier** | **v0113**(結構複本 · v0112 留著)| runtime v0151 | `%s` | **新**(BADITEM 第二種讀法 · 造假科目照 BADITEM · FAIL 帶科目列)|\n"
        "| VRN2_LocalRound_v0101.md(docs/handoff/ai · v0100 在 main 不動)| **v0101** | `docs/handoff/ai` | 見 md | **新**(指 操作員一鍵 v0112 → VRN-2 一鍵 v0151 · 貼回包帶收尾頁)|\n") % (
    "", R["launcher"]["sha256"][:12], rt["VRN2_IndependentVerifier_v0113.py"])
src = src.replace(anchor, v106 + v105 + rows.replace("| **新**(套件 v0151 · ⑧ 收尾頁", "| 被 v0105 取代(①  讀不到本機 zip 會當掉)· 套件 v0151 · ⑧ 收尾頁", 1) + anchor, 1)
once("## 7. 本輪(v0149 → v0150 + VRN2_RoundAll_v0103 · 桌機 2026-10-29 19:00 跑 RoundAll v0102 的貼回)",
     "## 7. 本輪(v0150 → v0151 + VRN2_RoundAll_v0104 · 收尾輪 · 操作員「解決剩餘系統問題 HTML U/I CLOSE OUT」)\n\n| # | 剩下的 | 根因 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | ⑪ 年度 BADITEM 19(MS-3665 / MS-8358 / MS-8210 / Daiwa aspeed · 值都在該頁)| 「科目本頁原文沒有」只問字元框讀法(桌機的函式庫版本讀壞科目列 · 同 v0112 的側欄)| IndependentVerifier v0113:先用第二種讀法找科目 | 原樣 0 差異 · 造假 60 / 60 BADITEM · 模擬讀壞 59 / 59 回 PRESENT · 整支跑同判 |\n"
     "| b | 跑完不知道結案沒有、剩下的是誰的 | 總表只有燈號數 | RoundAll v0104 ⑧ 收尾頁(負責方 · 結案狀態 · 待辦表 · 檔案 · 下次指令)| 自測 ㉓ ~ ㉗ · 桌機 19:00 那輪試算 BLOCKED · chromium 桌面 / 深色 / 手機 390 無水平捲動 · 無 JS 錯誤 |\n"
     "| c | Combined「調整後目標價空 15」| 報告本來沒有目標價的列也算缺 | 空格照原因分 | 自測 ㉕ |\n"
     "| — | MOPS DENY · MQ-1560 OCR 4 點 · 年度缺項 3 份 · ⑥e 30 分鐘 | VCGC 決定 / 要人看原文 / 操作員規則 | **沒修**(收尾頁分給負責方)| — |\n\n---\n\n"
     "## 7.0n 前一輪(v0149 → v0150 + VRN2_RoundAll_v0103 · 桌機 2026-10-29 19:00 跑 RoundAll v0102 的貼回)")
once("| 0 | **(v0150)** 桌機(cmd 或 PowerShell 7.6.9)貼 `vrn2_release_v0150/VRN2_RoundAll_v0103.md` 的 **pwsh 那一行**",
     "| 0 | **(v0151 · 2026-10-30 14:41 後)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0151/VRN2_RoundAll_v0106.md` 的 **PowerShell 7 原生一行** · 看收尾頁 ⑪ 年度數據 FAIL 證據(Daiwa aspeed PBR 26E)對齊的結論 · 舊套件夾要清就以系統管理員身分 icacls /reset | 貼回 |\n"
     "| 0 | **(v0151 · 2026-10-30)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0151/VRN2_RoundAll_v0105.md` 的 **PowerShell 7 原生一行**(v0104 在 ① 讀本機套件 zip PermissionError 當掉 · 兩次)· 看 ① 那列 GRAY 證據(icacls / 啟動器鎖 PID)找出誰佔著那個檔 | 貼回 |\n"
     "| 0 | **(v0151)** 桌機(cmd 或 PowerShell 7.6.9)貼 `vrn2_release_v0151/VRN2_RoundAll_v0104.md` 的 **pwsh 那一行** · 跑完看自動開的收尾頁:狀態若是 BLOCKED / REVIEW 就照負責方處理;OPEN 才是 VRN-2 要修 → 貼回包 | 貼回 |\n"
     "| 0b | **(v0151)** 收尾頁「人工核對」:MQ-1560 影像頁 4 點對原圖 · ⑪ 還標著的值看逐值原文 · 年度缺項 3 份確認原文有沒有年度表 | 操作員 |\n"
     "| 0 | **(v0150)** 桌機(cmd 或 PowerShell 7.6.9)貼 `vrn2_release_v0150/VRN2_RoundAll_v0103.md` 的 **pwsh 那一行**")
once("## 10. 執行方式(", "## 9b. 結案判定(CLOSE OUT · v0151)\n\n"
     "VRN-2 自己的收尾頁:`VIA_Reports\\vrn2\\VRN2_CloseoutUI_latest.html`(RoundAll v0104 寫 · 只讀其他系統的檔)。VCGC 的 `closeout_lamp` 才是 VCGC 驗收(四系統對等 · 只讀互看)。\n\n"
     "| 狀態 | 意思 | 算不算成功 |\n|---|---|---|\n| OPEN | VRN-2 還有要修的(貼回包給 AI)| 否 |\n| BLOCKED | VRN-2 側沒有待修 · 剩 VCGC 的決定 / 安裝(例:MOPS 被 VIA 網路工具 DENY)| 否 |\n"
     "| REVIEW | 剩要人看原文的(OCR 影像頁 · ⑪ 待核對值 · 缺年度數據)| 否 |\n| DATA_GAP | 剩外部來源本來沒有的(鉅亨 404 · Yahoo / TWSE 沒有)· 已附證據 | 否(VRN-2 側結案)|\n| PASS | 全綠(或只剩提醒)| 是 |\n\n"
     "目前(桌機 19:00 那輪試算 · v0151 還沒在桌機跑):**BLOCKED** —— VRN-2 0 · VCGC 3(MOPS DENY)· 人工 8 · 資料源 4。下一輪桌機跑 v0151 後以收尾頁為準。\n\n---\n\n## 10. 執行方式(")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0151 · 2026-10-30)** **不要把 tempfile.mkdtemp 建的夾整個搬到使用者看得到的地方**:Python 3.13 在 Windows 給它只限擁有者的權限,搬過去跟著走;要在目的地正常建夾、逐檔複製。\n"
     "- **(v0151 · 2026-10-30)** **收尾分類規則認不出來 = VRN-2 是對的預設,但每次桌機出現新的「VRN-2 要修」都要回頭看是不是規則不夠細**(CPU 忙 · 代號不是 4 碼),補規則時寫清楚理由。\n"
     "- **(v0151 · 2026-10-30)** **一支入口不准整支當掉**:每一步都包起來(例外只記那一步紅),收尾頁 / 貼回包一定要產生;讀不到的檔先重試、再印證據、再繞路(GitHub / 新夾),原檔不動。\n"
     "- **(v0151)** **已發行的同名檔不換內容**:改 RoundAll 時套件 zip 的 README 也提到它 → 套件雜湊會變;已發行的套件 / 一鍵 / 操作員 / 本地實測要逐位元比對不變,只出新版號的那支。\n"
     "- **(v0151)** **「結案」看收尾頁的負責方,不看燈號數**:BLOCKED / REVIEW / DATA_GAP 都不是成功;認不出來的列一律算 VRN-2(寧可未結案)。新增步驟名時,收尾頁的 `owner_of` 規則要一起看。\n"
     "- **(v0151)** **一個讀法說「沒有」之前,換另一個讀法找**(v0112 價格標籤 · v0113 科目);放寬一定配造假變造(改名科目 / 對調價格)確認還抓得到。\n"
     "- **(v0151)** **分支的 PR 被合進 main 後**:先快轉到 main 再做;main 裡的檔(例 `VRN2_LocalRound_v0100.md`)不再改,出新版(v0101)。\n\n")
(REPO / "VRN2_Handover_v0152.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0152 lines", src.count("\n"))
