VRN2_Closeout_v0151 — VRN-2 closeout package (2026-10-29 · close-out round)

Entry: python ActivateVRN-2_v0151.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0104.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → close-out page (HTML U/I) → paste-back zip.
Runtime: VRN2_Runtime_v0151.zip = runtime v0150 (186 members byte-identical) + VRN2_IndependentVerifier_v0113,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0151 (operator 2026-10-29: solve the remaining system issues · HTML U/I · CLOSE OUT):
 - step 11 IndependentVerifier v0113: annual-data BADITEM (MS-3665 / MS-8358 / MS-8210 / Daiwa aspeed, every value on the page) came from the
   character-box reader only; an item is read a second way (PDFium whole-page text + pdfplumber lines) before it is called 'not on this page'.
   Fabricated / renamed items stay BADITEM (with the closest source line); values not on the page stay FAIL (with the item's source line).
 - RoundAll v0104 writes VIA_Reports/vrn2/VRN2_CloseoutUI_latest.html: every open item with its owner (VRN-2 / VCGC / human check /
   data source / reminder) and a close-out state OPEN > BLOCKED > REVIEW > DATA_GAP > PASS (only PASS is success).
Verification: see VRN2_Verification_v0151.md. Hashes: PACKAGE_SHA256.json.
