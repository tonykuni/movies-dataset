import json,sys,collections
V2=sys.argv[1]
c=json.load(open(V2+'/VRN2_Completion_latest.json',encoding='utf-8'))
print([it['detail'][-220:] for it in c['items'] if it['name'].startswith('輸出值')])
f=json.load(open(V2+'/output/VRN2_FinancialData_latest.json',encoding='utf-8'))
sv=[x for x in f if x.get('SUBCOL')]
print('年度數據', len(f), '子欄拆分', len(sv), collections.Counter((x['FILENAME'][:12],x['TABLE']) for x in sv))
for x in sv[:4]+sv[-3:]: print('  ',x['FILENAME'][:12],x['TABLE'],x['ITEM'][:18],x['PERIOD'],x['SUBCOL'],x['VALUE'])
r=json.load(open(V2+'/output/VRN2_Rejected_latest.json',encoding='utf-8'))
print('剔除剩',len(r),collections.Counter((x['FILENAME'][:12],x['TABLE'],x['REASON'][:6]) for x in r if x['BOOK']=='FinancialData'))
b=json.load(open(V2+'/output/VRN2_BasicInfo_latest.json',encoding='utf-8'))
for x in b:
    if x['FILENAME'].startswith(('凱基投顧_2637','華南')): print('  ',x['FILENAME'][:12],'TEL',x['TEL'],'|',x['_STATUS']['TEL'],'| TP',x['TARGET_PRICE'],'UP',x['UPSIDE_PCT'],x['_STATUS']['UPSIDE_PCT'])
