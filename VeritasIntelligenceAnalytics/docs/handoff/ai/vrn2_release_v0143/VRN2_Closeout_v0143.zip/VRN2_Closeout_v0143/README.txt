VRN2_Closeout_v0143 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0143.py [--source <folder>] [--no-install] [--no-open]
Runtime: VRN2_Runtime_v0142.zip (unchanged: 162 members · manager v0243 · ENG062 v0117 · verifier v0110 · verbatim v0104 · Workbench v0100)
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0143 (desktop paste-back 2026-10-29: two launchers overlapped → RAM 0.16 GB → ⑦ / ⑪ / ⑫b all timed out → ⑤b RED):
 - single-instance guard: VIA_Reports/vrn2/VRN2_Launcher.lock; a second launcher on the same root refuses to start while the first PID is alive (VRN2_FORCE_PARALLEL=1 overrides)
 - child limits from the environment with safer defaults: VRN2_UI_REFRESH_WAIT 600 · VRN2_SILENT_MAX 3600 (⑦ no-output ceiling) · VRN2_MANIFEST_WAIT 900 · VIA_VRN2_VERIFY_WAIT 3600
 - ⑫b fallback: when the handler subprocess fails or times out, the entry writes the U/I input block itself (same patch_ui, in process)
 - receipt VRN2_Closeout_v0143.json gains guard / limits / ui_block
Logo: <VIA>/functional modules/VRN/SSOT/VRN2_Logo.png (already-transparent PNG used as is).
Exit codes: 0 GREEN · 2 YELLOW · 1 RED (also when another launcher is running).
