#!/bin/bash
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
bash $S/v142/mktree142.sh $S/v143/t143 $S/v143/pkg143 "$S2/shipF/samples" > $S/v143/t143_setup.log 2>&1 || { echo "tree fail"; exit 1; }
bash $S/v143/run_full143.sh $S/v143/t143 ActivateVRN-2_v0143.py full143
tail -3 $S/v143/full143.log
