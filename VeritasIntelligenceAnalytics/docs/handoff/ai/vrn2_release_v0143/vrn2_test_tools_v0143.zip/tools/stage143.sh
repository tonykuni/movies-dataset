#!/bin/bash
# v0143 放進倉:docs/handoff/ai/vrn2_release_v0143/ + vrn1_vrn2_oneclick_v0104/(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v143
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0143; OP=$REPO/vrn1_vrn2_oneclick_v0104; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v143")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0143"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0104")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("full143.log", "full143.rc", "t143_setup.log", "chainship101_selftest.log", "launcher143_selftest.log", "chainship101_recover_container.log", "pscheck143.log", "scen143.rc", "scen143_first.log", "scen143_again.log", "scen143_tamper.log", "scen143_setup.log")]
v2 = W / "t143/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0143.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_Activate_latest.json"):
    logs.append(("t143/" + n, v2 / n))
z(D / "logs_v0143.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py"))]
z(D / "vrn2_test_tools_v0143.zip", tools)
z(OP / "tools_v0104.zip", [("tools/" + q.name, q) for q in (W / "operator104" / "boot_pair104.ps1", W / "operator104" / "oneline_pair104.txt", W / "operator104" / "Run-VRN1-VRN2-v0104.ps1")])
for n in ("VRN1_VRN2_OneClick_v0104.md", "VRN1_VRN2_Verification_v0104.md"): shutil.copy(W / "operator104" / n, OP / n)
for n in ("VRN2_Closeout_v0143.zip", "VRN2_Release_v0143.json", "VRN2_OneClick_v0143.md", "VRN2_Verification_v0143.md"): shutil.copy(W / "release143" / n, D / n)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
