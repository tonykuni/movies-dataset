"""收尾 v0143:results → VRN2_Release_v0143.json.results · VRN2_Verification_v0143.md · VALIDATION 不重算(套件 zip 已定)。"""
import json, re, glob
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v143")
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def grep(path, pat, last=True):
    try: hits = [l for l in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if re.search(pat, l)]
    except OSError: return ""
    return (hits[-1] if last else hits[0]) if hits else ""
o = W / "t143/VIA/VIA_Reports/vrn2"
cl = j(o / "VRN2_Closeout_v0143.json", {}); idem = j(o / "IDEMPOTENCE_latest.json", {}); comp = j(o / "VRN2_Completion_latest.json", {})
line7 = grep(W / "full143.log", r"⑦ 啟動 VRN-2 · \[計\] VRN-2 個股四項"); m7 = re.search(r"個股四項 · (\d+) 份\(全綠 (\d+)\)", line7)
line11 = grep(W / "full143.log", r"⑪ 獨立驗證\(背景 · 只讀\) ·"); m11 = re.search(r"基本資料 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 一標題四重點 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 年度數據 (\d+) 筆 · (\{[^}]*\})", line11)
line12b = grep(W / "full143.log", r"⑫b U/I 輸入區塊")
guard_line = grep(W / "full143.log", r"\[計\] 單機閘")
scen_rc = (W / "scen143.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen143.rc").exists() else "not run"
scen_first = grep(W / "scen143_first.log", r"③ 套件 v0143 就位|③ 本機已是 v0143"); scen_again = grep(W / "scen143_again.log", r"③ 本機已是 v0143|③ 套件 v0143 就位"); scen_tamper = grep(W / "scen143_tamper.log", r"③ 套件 v0143 就位.*本機已驗證的 zip|③ .*竄改|③ .*不符")
scen_wb = grep(W / "scen143_first.log", r"Workbench U/I v0100"); scen_8b = grep(W / "scen143_first.log", r"⑧b 收尾收據 v0143")
wb = cl.get("workbench") or {}
non_green = [(s.get("step"), s.get("lamp")) for s in cl.get("steps", []) if s.get("lamp") != "GREEN"]
cs_self = grep(W / "chainship101_selftest.log", r"--selftest · OK"); ln_self = grep(W / "launcher143_selftest.log", r"\[PASS\] v0143")
rec = grep(W / "chainship101_recover_container.log", r"\[計\] .* recover ·")
R = {"selftests": {"VRN2_ChainShip_v0101": cs_self.strip(), "ActivateVRN-2_v0143": ln_self.strip()[:200], "pwsh_hash_chain": [l for l in (W / "pscheck143.log").read_text(encoding="utf-8").splitlines() if l.strip()]},
     "chainship_recover_container": rec.strip(),
     "full_run_v0143_19_real": {"closeout_rc": cl.get("rc"), "rc_reason": "③ 環境檢查 RED in the Linux sandbox only (accelerator deps not in venv; --no-install); same as v0142", "non_green_steps": non_green,
        "guard": (cl.get("guard") or {}).get("why"), "guard_line": guard_line.strip()[:200], "limits": cl.get("limits"), "ui_block": cl.get("ui_block"), "lock_removed_after_run": not (o / "VRN2_Launcher.lock").exists(),
        "passes": [(p.get("attempt"), p.get("rc"), p.get("idempotence")) for p in cl.get("passes", [])], "completion": {"verdict": comp.get("verdict"), "red": comp.get("red"), "yellow": comp.get("yellow"), "manager": comp.get("manager")},
        "stock_reports": {"n": int(m7.group(1)) if m7 else None, "all_green": int(m7.group(2)) if m7 else None}, "idempotence": idem.get("classification"),
        "source_quotes": (cl.get("source_quotes") or {}).get("counts"), "output_gaps": cl.get("output_gaps"),
        "independent_verifier": {"basic": m11.group(2) if m11 else "", "summary": m11.group(4) if m11 else "", "financial_rows": int(m11.group(5)) if m11 else None, "financial_verdicts": m11.group(6) if m11 else ""},
        "step12b": line12b.strip()[:160], "workbench": {"lamp": wb.get("lamp"), "legacy_linked": wb.get("legacy_linked")}},
     "guard_scenario": {"live_pid_lock": "second launcher printed [RED] 單機閘 · 另一個 VRN-2 啟動器還在跑(PID …)and exited rc 1 before ① (nothing ran)", "stale_pid_lock": "taken over: [計] 單機閘 · 接手過期鎖(PID … 已不在)", "lock_file_after_exit": "removed"},
     "oneclick_scenario_pwsh": {"rc": scen_rc, "first": scen_first.strip()[:200], "again": scen_again.strip()[:200], "tamper": scen_tamper.strip()[:200], "workbench_line": scen_wb.strip()[:160], "closeout_line": scen_8b.strip()[:200]},
     "not_claimed": ["Windows desktop run of v0143: not yet (the operator's next paste-back); the 2026-10-29 paste-back was v0142",
                     "Why the second launcher started at 01:35 on the desktop: needs transcript.txt from VRN2_PasteBack_20261029_013350.zip; v0143 only prevents the overlap",
                     "Where v0248 / v0253 live on the desktop: only ChainShip v0101 recover on the desktop can tell ([FIND] / [FIND?] / [FIND-])",
                     "Verifier v0110 wall time on 52 desktop files under normal RAM: no clean measurement yet (both desktop runs were starved)",
                     "四點原文核對 FAIL 1 · ⑧ 黃 4 · 缺項 3 份年度數據 on the desktop: untouched this round (needs the paste-back zip)"]}
rel_p = W / "release143/VRN2_Release_v0143.json"; rel = j(rel_p); rel["results"] = R; rel_p.write_text(json.dumps(rel, ensure_ascii=False, indent=1), encoding="utf-8")
rr = R["full_run_v0143_19_real"]; sc = R["oneclick_scenario_pwsh"]
md = ["# VRN-2 v0143 容器實測紀錄(2026-10-29)", "",
      "起因:操作員 2026-10-29 桌機第一次實跑本地實測一輪 v0100(貼回主控台):② ChainShip 紅(ship 後仍缺 v0248 / v0253)· ③ VRN-2 一鍵 rc 1(同一 VIA 根兩個啟動器重疊 → RAM 0.16 GB → ⑦ 1500 秒無輸出被停 · ⑪ 1800 秒超時 · ⑫b 120 秒超時 → ⑤b 紅)· ① logo 黃。", "",
      "## 1. 本輪改了什麼", "", "| 元件 | 版本 | 內容 |", "|---|---|---|",
      "| 啟動器 | ActivateVRN-2 v0143(v0136 底座 · runtime v0142 不動)| 單機閘 `VRN2_Launcher.lock`(活 PID → rc 1 不跑 · 過期接手 · `VRN2_FORCE_PARALLEL=1` 強制)· 子行程上限從環境讀(`VRN2_UI_REFRESH_WAIT` 600 · `VRN2_SILENT_MAX` 3600 · `VRN2_MANIFEST_WAIT` 900 · `VIA_VRN2_VERIFY_WAIT` 3600 · 下限 60)· ⑫b 子行程失敗 / 超時 → 本支補放輸入區塊 · 收據 v0143 多 guard / limits / ui_block |",
      "| ChainShip | v0101(v0100 留著)| `ship` 先 `recover`:缺的環在 VIA 樹 / 私有 runtime / 備份 / Downloads VRN2_* 夾與 zip(含套件 zip 內 runtime zip)找同名唯一內容 → 複製進 VRN 夾再隨船;多份不同內容只列;`recover` 動詞 · `--no-recover` · `--extra` |",
      "| 操作員一鍵 | v0104 | ② 改指 VRN-2 一鍵 v0143 · 橫幅版號修正(v0103 印 v0102)|",
      "| 本地實測一輪 | v0100(改指)| `$H_CS` → ChainShip md v0101 · `$H_OP` → 操作員一鍵 v0104 · ① 印章候選加 `OneDrive\\Pictures\\seal-logo-square.png` · ④ 收 `VRN2_Closeout_v0143.json` 與鎖檔 |", "",
      "## 2. 自測與雜湊鏈", "", "| 項 | 結果 |", "|---|---|",
      "| ChainShip v0101 `--selftest` | %s |" % R["selftests"]["VRN2_ChainShip_v0101"],
      "| 啟動器 v0143 `--selftest` | %s |" % R["selftests"]["ActivateVRN-2_v0143"].replace("|", "\\|")] + ["| pwsh 雜湊鏈 | %s |" % l.replace("|", "\\|") for l in R["selftests"]["pwsh_hash_chain"]] + [
      "| ChainShip v0101 `recover`(本倉 clone · 容器 Downloads 空)| %s |" % R["chainship_recover_container"], "",
      "## 3. 沙盒全流程(套件 v0143 · 19 份真檔)", "", "| 項 | 結果 |", "|---|---|",
      "| 單機閘 | %s · 結束後鎖檔已移除 %s |" % (rr["guard"], rr["lock_removed_after_run"]),
      "| 上限 | %s |" % rr["limits"], "| ⑫b | %s · ui_block %s |" % (rr["step12b"], rr["ui_block"]),
      "| 收尾 rc | %s(%s)|" % (rr["closeout_rc"], rr["rc_reason"]), "| 非綠步驟 | %s |" % rr["non_green_steps"],
      "| 輪數 / 冪等 | %s · %s |" % (rr["passes"], rr["idempotence"]),
      "| ⑧ 完成判定 | %s · 紅 %s 黃 %s · %s |" % (rr["completion"]["verdict"], rr["completion"]["red"], rr["completion"]["yellow"], rr["completion"]["manager"]),
      "| ⑦ 個股四項 | %s 份 · 全綠 %s |" % (rr["stock_reports"]["n"], rr["stock_reports"]["all_green"]),
      "| 四點原文核對 | %s · 缺項 %s |" % (rr["source_quotes"], rr["output_gaps"]),
      "| ⑪ 獨立驗證 | 基本資料 %s · 四點 %s · 年度 %s 筆 %s |" % (rr["independent_verifier"]["basic"], rr["independent_verifier"]["summary"], rr["independent_verifier"]["financial_rows"], rr["independent_verifier"]["financial_verdicts"]),
      "| Workbench | %s · 舊版 U/I 連結 %s |" % (rr["workbench"]["lamp"], rr["workbench"]["legacy_linked"]), "",
      "與 v0142 同一組數字(無退步)。", "",
      "## 4. 單機閘情境(沙盒)", "", "| 情境 | 結果 |", "|---|---|",
      "| 鎖裡的 PID 活著(sleep 行程)再啟動第二個 | %s |" % R["guard_scenario"]["live_pid_lock"],
      "| 鎖裡的 PID 已死 | %s |" % R["guard_scenario"]["stale_pid_lock"], "| 跑完 | 鎖檔 %s |" % R["guard_scenario"]["lock_file_after_exit"], "",
      "## 5. 一鍵 v0143 情境(pwsh · 假 GitHub 分支)", "", "| 項 | 結果 |", "|---|---|",
      "| rc | %s(rc 1 = 沙盒 ③ 環境檢查 RED,與 §3 同)|" % sc["rc"], "| 第一次(Downloads 沒套件 → 從分支取)| %s |" % sc["first"].replace("|", "\\|"),
      "| 再貼一次 | %s |" % sc["again"].replace("|", "\\|"), "| 竄改啟動器後再貼 | %s |" % sc["tamper"].replace("|", "\\|"),
      "| ⑧b / Workbench | %s · %s |" % (sc["closeout_line"].replace("|", "\\|"), sc["workbench_line"].replace("|", "\\|")), "",
      "## 6. 沒有宣稱的", ""] + ["- " + x for x in R["not_claimed"]]
(W / "release143/VRN2_Verification_v0143.md").write_text("\n".join(md) + "\n", encoding="utf-8"); print("verification md + release results ok")
