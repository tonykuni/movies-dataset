& {
  $REPO = "C:\Users\tonyk\OneDrive\Documents\movies-dataset"
  $REL  = "VeritasIntelligenceAnalytics/functional modules/VRN/VRN2_ChainShip_v0101.py"
  $WANT = "81b47d7f9b838cf1f0539792b5bab7cf4e526206e37c1903c03cc9f3e86bacc0"
  if (-not (Test-Path -LiteralPath (Join-Path $REPO ".git"))) { Write-Host "[RED] 不是 git 倉:$REPO" -ForegroundColor Red; return }
  $T = Join-Path $REPO ($REL -replace '/', '\')
  $py = Get-Command python, py, python3 -ErrorAction SilentlyContinue | Where-Object { $_.Source -notmatch 'WindowsApps' } | Select-Object -First 1
  if (-not $py) { Write-Host "[RED] 找不到 python" -ForegroundColor Red; return }
  $env:PYTHONUTF8 = "1"
  if (-not (Test-Path -LiteralPath $T)) {
    git -C $REPO fetch -q origin main claude/optimistic-goodall-yhalc5 2>$null
    foreach ($ref in @('origin/main', 'origin/claude/optimistic-goodall-yhalc5')) {
      & $py.Source -I -c "import subprocess,sys;r=subprocess.run(['git','-C',sys.argv[1],'show',sys.argv[2]+':'+sys.argv[3]],capture_output=True);sys.exit(1) if (r.returncode or not r.stdout) else open(sys.argv[4],'wb').write(r.stdout)" $REPO $ref $REL $T
      if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $T)) { Write-Host "[工具] 從 $ref 取得 VRN2_ChainShip_v0101.py"; break }
    }
  }
  if (-not (Test-Path -LiteralPath $T)) { Write-Host "[RED] 取不到 VRN2_ChainShip_v0101.py(fetch 不到 main / 分支)" -ForegroundColor Red; return }
  $sha = (Get-FileHash -LiteralPath $T -Algorithm SHA256).Hash.ToLower()
  $lf = ([IO.File]::ReadAllText($T) -replace "`r`n", "`n")
  $shaLF = ([BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($lf))) -replace '-', '').ToLower()
  if ($sha -ne $WANT -and $shaLF -ne $WANT) { Write-Host "[RED] 工具雜湊不符:$($sha.Substring(0,12))(要 $($WANT.Substring(0,12)))" -ForegroundColor Red; return }
  Write-Host "[工具] VRN2_ChainShip_v0101.py 雜湊相符 $($WANT.Substring(0,12))"
  & $py.Source $T check;                $rc1 = $LASTEXITCODE
  & $py.Source $T ship --commit --push; $rc2 = $LASTEXITCODE
  & $py.Source $T check;                $rc3 = $LASTEXITCODE
  $lamp = if ($rc3 -eq 1 -or $rc2 -eq 1) { "RED" } elseif ($rc3 -eq 0 -and $rc2 -eq 0) { "GREEN" } else { "YELLOW" }
  Write-Host ("[結果] {0} · 補船前 check rc {1} · ship rc {2} · 補船後 check rc {3}(0 綠 · 2 黃 · 1 紅)· 收據 {4}" -f $lamp, $rc1, $rc2, $rc3, (Join-Path $REPO "VeritasIntelligenceAnalytics\VIA_Reports\vrn2\VRN2_ChainShip_latest.json"))
}