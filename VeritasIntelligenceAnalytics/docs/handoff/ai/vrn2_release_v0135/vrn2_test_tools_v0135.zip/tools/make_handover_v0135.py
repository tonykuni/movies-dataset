"""VRN2_Handover_v0135.md = v0134 交接報告(MAIN)+ v0135(Codex #561:獨立驗證器 v0104)· 逐行錨點替換 · 冪等。
用法:python make_handover_v0135.py <v0134.md> <結果 json> <輸出 md>"""
import json
import re
import sys
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
R = json.loads(res_p.read_text(encoding="utf-8"))
lines = src.read_text(encoding="utf-8").split("\n")


def one(prefix):
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    assert len(hits) == 1, (prefix[:40], len(hits))
    return hits[0]


def sub(prefix, new):
    i = one(prefix)
    lines[i] = new(lines[i]) if callable(new) else new


def before(prefix, extra):
    i = one(prefix)
    lines[i:i] = extra


IV = "獨立驗證器 v0104(Codex #561:空值記號只在原文該格確實是空白 / 別的記號才 NILVAL,該格是數字仍 FAIL · 字距拆開的數字只接千分位逗點 / 小數點後的空白)"
sub("# VRN-2 交接報告 · ActivateVRN-2 v0134 · 2026-10-21(",
    "# VRN-2 交接報告 · ActivateVRN-2 v0135 · 2026-10-21(PR #561 合併後 Codex 兩項修正 · " + IV + " · v0102 / v0103 留著 · ⑪ 取最新版 · 處理器 / 管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋一個位元組都不動 · 其餘同 v0134 整合一支)")
before("> **本輪(v0134 · 啟動器 + 處理器 VRN2_UIAction_v0104",
       ["> **本輪(v0135 · 啟動器 + 獨立驗證器 VRN2_IndependentVerifier_v0104 · 交接報告 v0135 · 處理器 / 管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋一個位元組都不動)**:PR #561(v0134)操作員已合併 MAIN,Codex 在合併前後指出驗證器 v0103 兩點:"
        "① P1 空值記號(n.a. / NM / -)原文找不到就一律 NILVAL、沒看該格 —— 擷取出 `Revenue = n.a.` 而原文該列該欄印 `12.3` 會從錯值裡消失 → v0104 `_nil_cell`:先定科目列,用同一套表頭對欄(`_align` · 同一個 dx 門檻)看該格印了什麼:數字 → 仍 FAIL(註記「原文該格是數字」)· 空白 / 別的空值記號 → NILVAL · 定不出科目列或這頁沒有這個期間表頭 → 仍 FAIL;"
        "② P2 `_num_cands` 把整列空白全去掉再找,「Price target 3 190」會黏成 3190 → 只接「千分位逗點後的空白」「小數點後的空白」(`3, 190.00` · `1, 234. 5`),`3 190` · `12 345` · `Dec 3, 2025` 不黏。"
        "兩項都只讓驗證器更嚴。已合併 MAIN 的 v0134 一個檔都不改:出 v0135(啟動器 · 發行夾 `vrn2_release_v0135` · 一鍵 · 本交接)。實測:驗證器 v0104 自測 %s · %s · 啟動器 %s · %s · %s · %s。" % (R["selftest_iv"], R["verifier_regress"], R["selftest"], R["e2e"], R["oneclick"], R["ui"])])
sub("> **本輪(v0134 · 啟動器 + 處理器 VRN2_UIAction_v0104", lambda l: l.replace("> **本輪(v0134", "> **前一輪(v0134", 1))
sub("> **前一輪(v0133 · 啟動器 + U/I 處理器 VRN2_UIAction_v0103", lambda l: l.replace("> **前一輪(v0133", "> **v0133(", 1))
sub("| **啟動器(MAIN)** |", lambda l: l.replace("v0134", "v0135"))
sub("| **獨立驗證器** |", "| **獨立驗證器** | `<ROOT>\\functional modules\\VRN\\VRN2_IndependentVerifier_v0104.py` | v0135 落地(v0102 / v0103 留著 · ⑪ 取最新版)· Codex #561:空值記號看該格 `_nil_cell` · 字距只接逗點 / 小數點後的空白 `_SPLITNUM` · 其餘同 v0103(標籤旁前 4 頁 · 上漲空間推算 · 覆蓋率去標點 · 科目名去 * $)|")
sub("| **交接報告** |", lambda l: l.replace("VRN2_Handover_v0134.md", "VRN2_Handover_v0135.md"))
sub("| 本輪證據 |", lambda l: l.replace("`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0134\\`(v0133:", "`<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0135\\`(v0134:`vrn2_release_v0134\\` · v0133:", 1))
sub("### 3.1 現役版本(v0134 內嵌", "### 3.1 現役版本(v0135 內嵌 · 依序自動落地)")
sub("| ActivateVRN-2.py | **v0134** |", lambda l: re.sub(r"\| [^|]*\|$", "| **新**(= v0134 + 內嵌獨立驗證器 v0104 · Codex #561;其餘元件逐位元組相同)|", l.replace("**v0134**", "**v0135**", 1)))
before("| **VRN2_IndependentVerifier** | **v0103**(v0102 留著)|",
       ["| **VRN2_IndependentVerifier** | **v0104**(v0102 / v0103 留著)| 85,081 | `%s` | **新**(v0103 + Codex #561:空值記號看該格 `_nil_cell` · 字距只接逗點 / 小數點後的空白 `_SPLITNUM` · 自測 %s)|" % (R.get("iv_sha12", "見發行清單"), R["selftest_iv"].split("(")[0].strip())])
sub("| **VRN2_IndependentVerifier** | **v0103**(v0102 留著)|", lambda l: re.sub(r"\| \*\*新\*\*\([^|]*\|$", "| v0134 內嵌 · 留著(Codex #561 指出的兩點在 v0104 修)|", l))
before("## 7. 本輪修正(v0133 → v0134 · 整合一支)",
       ["## 7. 本輪修正(v0134 → v0135 · Codex #561)", "",
        "| # | Codex 指出(驗證器 v0103) | 做法(驗證器 v0104 · 內嵌啟動器 v0135) | 實測 |", "|---|---|---|---|",
        "| 1 | **P1** 空值記號(n.a. / NM / -)找不到就一律 NILVAL,沒看原文該格:擷取出 `n.a.` 而原文該格印 `12.3` 會從錯值裡消失 | `_nil_cell(lines, labs, per)`:定科目列 → 該列科目右邊的值用 `_align` 對 `per` 表頭(同一個 dx 門檻)→ 該格是數字 → 仍 FAIL(註記「原文該格是數字 …」)· 別的空值記號 / 空白 → NILVAL · 定不出科目列 / 這頁沒有這個期間表頭 → 仍 FAIL(註記不能確認) | 自測:該格 12.3 → FAIL · — → NILVAL · 空白 → NILVAL · 沒科目列 / 沒表頭 → None |",
        "| 2 | **P2** `_num_cands` 去掉整列空白再找:「Price target 3 190」黏成不存在的 3190,標籤旁檢查誤過 | `_SPLITNUM`:只接「千分位逗點後的空白」「小數點後的空白」(`3, 190.00` · `1, 234. 5` · `4,388. 00`);`3 190` · `12 345` · `Dec 3, 2025` 不黏 | 自測 7 個案例 |",
        "| 3 | v0134 已合併 MAIN(PR #561)| 已合併的版本一個檔都不改:出 v0135(啟動器 · `vrn2_release_v0135` · 一鍵 · 本交接);v0103 留在啟動器裡(只增不減 · ⑪ 取最新版 = v0104)| 啟動器 %s |" % R["selftest"],
        "| 4 | 回歸 | 容器同一本冊 v0102 / v0103 / v0104 判決逐類相同 | %s |" % R["verifier_regress"],
        "| 5 | 端到端 | %s | %s |" % (R["e2e"], R["ui"]),
        "| 6 | 一鍵 | %s | — |" % R["oneclick"],
        "", "---", ""])
sub("## 7. 本輪修正(v0133 → v0134 · 整合一支)", "## 7.0d v0133 → v0134(整合一支)")
i = one("| 0 | **使用者用 v0134 的一行跑**")
old0 = lines[i].replace("| 0 |", "| 0b |", 1).replace("| 待執行 |", "| 被 v0135 取代(v0134 已合併 MAIN · 可跑,但 ⑪ 是驗證器 v0103)|", 1)
j = one("| 0b | **使用者用 v0133 的一行跑**") if any(l.startswith("| 0b | **使用者用 v0133") for l in lines) else None
lines[i] = "| 0 | **使用者用 v0135 的一行跑**(`vrn2_release_v0135/VRN2_OneClick_v0135.md`)| 待執行 | 預期:同 v0134(U/I 自己跳出 · ⑪ 用驗證器 v0104 · 註冊核對 處理器 v0104);Daiwa PBR n.a. 那筆會寫「原文該格是 …」:空白 / 別的記號 → NILVAL · 數字 → FAIL 照實留。貼回 ⑪ 驗證摘要 + ②b / ⑤b。 |"
lines[i + 1:i + 1] = [old0]
if j is not None:
    j = one("| 0b | **使用者用 v0133 的一行跑**")
    lines[j] = lines[j].replace("| 0b |", "| 0c |", 1)
sub("一鍵(取得 v0134 →", lambda l: l.replace("取得 v0134", "取得 v0135", 1))
before("- **全部整進一支**:",
       ["- **驗證器放寬要看該格(Codex #561)**:空值記號(n.a. / - / NM)找不到不能直接 NILVAL,先定科目列、對期間欄看原文該格是什麼(數字 → FAIL · 空白 / 別的記號 → NILVAL · 定不出 → FAIL);字距拆開的數字只接千分位逗點 / 小數點後的空白,空白分開的兩個數不黏。",
        "- **已合併 MAIN 的版本不改**:修正一律出新版號(v0134 合併後 → v0135),發行夾 / 一鍵 / 交接跟著新版號;舊發行夾與舊版元件留著(只增不減),啟動器 ⑪ 取最新版。"])
out.write_text("\n".join(lines), encoding="utf-8", newline="\n")
print("[計] %s · %d 字" % (out.name, len("\n".join(lines))))
