// VRN-2 U/I「輸入(window I/O)」區塊(v0133)真瀏覽器實測(Chromium · Playwright)
// 用法:node ui_input.js <VRN2_UI_latest.html> <截圖夾> [期望出現的來源夾字串]
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');

(async () => {
  const file = path.resolve(process.argv[2]);
  const shots = path.resolve(process.argv[3]);
  const want = process.argv[4] || '';
  fs.mkdirSync(shots, { recursive: true });
  const res = [];
  const ok = (name, cond, extra) => { res.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra).slice(0, 160) }); };
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--allow-file-access-from-files'] });
  const ctx = await browser.newContext({ viewport: { width: 1400, height: 900 } });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto('file://' + file);
  await page.waitForLoadState('load');

  ok('輸入區塊在左側面板裡 · 只有一塊', (await page.$$('#vrn2panel #vrn2-input')).length === 1 && (await page.$$('#vrn2-input')).length === 1);
  const radios = await page.$$eval('#vrn2-input input[name=vcat]', rs => rs.map(r => ({ v: r.value, checked: r.checked, disabled: r.disabled })));
  ok('三類:個股報告/訊息 已選可用 · 產業報告/展望 與 其他投資報告 disabled',
    radios.length === 3 && radios[0].v === 'stock' && radios[0].checked && !radios[0].disabled && radios[1].v === 'industry' && radios[1].disabled && !radios[1].checked
    && radios[2].v === 'other' && radios[2].disabled && !radios[2].checked, JSON.stringify(radios));
  const labels = await page.$$eval('#vrn2-input label', ls => ls.map(l => l.textContent.replace(/\s+/g, ' ').trim()));
  ok('標籤文字 · 未開放兩類標「尚未開放」', labels[0].startsWith('個股報告/訊息') && labels[1].includes('產業報告/展望') && labels[1].includes('尚未開放')
    && labels[2].includes('其他投資報告') && labels[2].includes('尚未開放'), labels.join(' | '));
  await page.click('#vrn2-input input[value=industry]', { force: true }).catch(() => { });
  await page.click('#vrn2-input input[value=other]', { force: true }).catch(() => { });
  const after = await page.$$eval('#vrn2-input input[name=vcat]', rs => rs.map(r => r.checked));
  ok('點未開放的兩類 → 選擇不變(還是個股)', after[0] === true && after[1] === false && after[2] === false, after.join(','));
  const hrefs = await page.$$eval('#vrn2-input a.vinp', as => as.map(a => a.getAttribute('href')));
  ok('三個按鈕走 vrn2://:pick 資料夾 · pick 檔案 · audit(都是 cat=stock)',
    JSON.stringify(hrefs) === JSON.stringify(['vrn2://pick?kind=folder&cat=stock', 'vrn2://pick?kind=files&cat=stock', 'vrn2://audit']), hrefs.join(' | '));
  const txt = await page.$eval('#vrn2-input-now', e => e.textContent);
  ok('目前輸入:來源夾 + 稽核(個股範圍 / 範圍外 / 非 PDF)' + (want ? ' · 含 ' + want.slice(-24) : ''),
    txt.includes('個股範圍') && txt.includes('範圍外') && txt.includes('非 PDF') && (!want || txt.includes(want)), txt.slice(0, 160));
  const box = await page.$eval('#vrn2-input', e => { const r = e.getBoundingClientRect(); return { x: Math.round(r.x), w: Math.round(r.width), vis: e.offsetParent !== null }; });
  ok('區塊在 190px 固定面板內可見', box.vis && box.x >= 0 && box.x + box.w <= 200, JSON.stringify(box));
  const order = await page.evaluate(() => { const np = document.getElementById('vnopush'); const b = document.getElementById('vrn2-input'); const op = [...document.querySelectorAll('#vrn2panel div')].find(d => d.textContent.trim() === '開啟');
    const before = (x, y) => !!(x.compareDocumentPosition(y) & Node.DOCUMENT_POSITION_FOLLOWING); return !!np && !!b && !!op && before(np, b) && before(b, op); });
  ok('位置:在「這次不上船」之後、「開啟」之前', order);
  const vact = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('原本 4 個 vrn2:// 動作不變', JSON.stringify(vact) === JSON.stringify(['vrn2://run', 'vrn2://run?nopush=1', 'vrn2://run-clean', 'vrn2://restore-archive']), vact.join(' | '));
  await page.check('#vnopush');
  const h2 = await page.$$eval('#vrn2-input a.vinp', as => as.map(a => a.getAttribute('href')));
  const v2 = await page.$$eval('a.vact', as => as.map(a => a.getAttribute('href')));
  ok('勾「這次不上船」:重跑類帶 nopush=1 · 輸入按鈕不受影響', JSON.stringify(h2) === JSON.stringify(hrefs) && v2[0] === 'vrn2://run?nopush=1' && v2[2] === 'vrn2://run-clean?nopush=1', v2.join(' | '));
  await page.uncheck('#vnopush');
  const fb = await page.$eval('#vrn2-input', e => e.textContent);
  ok('備援提示:VRN2_SOURCE / --source', fb.includes('VRN2_SOURCE') && fb.includes('--source'));
  const tabs = await page.$$eval('#vrn2tabs button', bs => bs.length);
  ok('右側分頁腳本照常(分頁 ≥ 9 · 區塊沒被切進分頁)', tabs >= 9 && !(await page.$('.vtab #vrn2-input')), tabs);
  await page.screenshot({ path: path.join(shots, 'ui_input_panel.png'), clip: { x: 0, y: 0, width: 200, height: 900 } });
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(200);
  ok('手機寬度區塊仍可見', await page.isVisible('#vrn2-input'));
  await page.screenshot({ path: path.join(shots, 'ui_input_phone.png') });
  ok('沒有頁面腳本錯誤', errors.length === 0, errors.join(' | '));
  await browser.close();
  const pass = res.filter(r => r.ok).length;
  for (const r of res) console.log(`  [${r.ok ? 'OK' : 'FAIL'}] ${r.name}${r.extra ? ' · ' + r.extra : ''}`);
  console.log(`[計] U/I 輸入區塊真瀏覽器實測 ${pass}/${res.length} · ${pass === res.length ? 'PASS' : 'FAIL'}`);
  process.exit(pass === res.length ? 0 : 1);
})().catch(e => { console.error('[RED] ' + e.stack); process.exit(2); });
