"""VRN2_IndependentVerifier_v0104 = v0103 + Codex #561 兩項修正(錨點替換 · 只增;v0103 沒落地過任何機器 · 由 v0104 取代內嵌)。
用法:python make_verifier_v0104.py <v0103.py> <輸出 v0104.py>
  ① P1 空值記號(n.a. / - / NM)原文找不到 → 先看科目列在這個期間欄到底印了什麼:印的是數字 → 仍 FAIL(值被弄壞)· 印的是空白 / 別的空值記號 → NILVAL(不算錯值);定不出科目列或表頭 → 仍 FAIL
  ② P2 字距拆開的數字只接「千分位逗點後的空白」「小數點後的空白」(3, 190.00 → 3190.00);「Price target 3 190」兩個獨立的數不再被黏成 3190"""
import sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
s = src.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:80])
    s = s.replace(a, b)


rep('"""VRN2_IndependentVerifier_v0103 — VRN-2 輸出值獨立驗證(v0103:',
    '"""VRN2_IndependentVerifier_v0104 — VRN-2 輸出值獨立驗證(v0104:空值記號 NILVAL 只在原文該格確實是空白 / 別的記號(該格是數字仍 FAIL)· 字距拆開的數字只接千分位逗點 / 小數點後的空白(Codex #561);v0103:')
rep('VERSION = "VRN2_IndependentVerifier_v0103"', 'VERSION = "VRN2_IndependentVerifier_v0104"')

# ② 字距:只接逗點 / 小數點後的空白
rep('''    out = [(m.start(), m.end()) for m in re.finditer(r"\\d[\\d,]*(?:\\.\\d+)?", s_) if _numv(m.group()) == fv]
    s2 = s_.replace(" ", "")
    if s2 != s_:
        pos = [i for i, ch in enumerate(s_) if ch != " "]
        for m in re.finditer(r"\\d[\\d,]*(?:\\.\\d+)?", s2):
            if _numv(m.group()) == fv and pos:
                st, en = pos[m.start()], pos[m.end() - 1] + 1
                if (st, en) not in out:
                    out.append((st, en))
    return sorted(out)
''', '''    out = [(m.start(), m.end()) for m in re.finditer(r"\\d[\\d,]*(?:\\.\\d+)?", s_) if _numv(m.group()) == fv]
    for m in _SPLITNUM.finditer(s_):                                        # v0104 只接千分位逗點 / 小數點後的空白(Codex #561:「3 190」是兩個數 · 不黏)
        g = m.group()
        if " " in g and _numv(g.replace(" ", "")) == fv and (m.start(), m.end()) not in out:
            out.append((m.start(), m.end()))
    return sorted(out)


_SPLITNUM = re.compile(r"(?<![\\d.,])\\d{1,3}(?:,\\s*\\d{3}(?!\\d))+(?:\\.\\s*\\d+)?(?![\\d])|(?<![\\d.,])\\d[\\d,]*\\.\\s+\\d+(?![\\d])")
''')
rep('''    """v0103 一列字串裡等於 fv 的數字位置 [(start, end)]:原樣 · 加上去掉空白後再找(字距把 3,190.00 拆成「3, 190.00」也對得到 · 位置映回原字串)。"""''',
    '''    """v0103 一列字串裡等於 fv 的數字位置 [(start, end)]:原樣 · 加上字距拆開的(3,190.00 印成「3, 190.00」)· v0104 只接千分位逗點 / 小數點後的空白,空白分開的兩個數不黏。"""''')

# ① 空值記號:看該格
rep('''def verify_fin(rows, pdfdir, allrows=None):
''', '''def _nil_cell(lines, labs, per):
    """v0104 空值記號(n.a. / - / NM)原文找不到 → 看科目列在這個期間欄印了什麼(Codex #561):
    數字 → (False, 原文該格是數字:值被弄壞 · 仍 FAIL)· 空白 / 別的空值記號 → (True, 說明:NILVAL)· 定不出科目列 / 這頁沒有這個期間表頭 → None(仍 FAIL)。"""
    if not labs or not any(t == per for _, tk in lines for _, _, t in tk):
        return None
    res = None
    for k, lb, _how in labs:
        y, tk = lines[k]
        x0, x1 = lb[1] + 2, _seg_end(tk, lb[1])
        hits = [((a + b) / 2, a, b, t) for a, b, t in sorted(tk) if x0 < a < x1 and _isval(t)]
        b2 = _align(lines, y, per, hits)
        if b2 is None:
            res = res or (True, "原文該格空白(科目列在 %s 欄沒有值)" % per)
            continue
        dx, colw, hx, vx, hw, hy, qq = b2
        tok = next((t for vx_, a, b, t in hits if vx_ == vx), "")
        if dx <= max(0.55 * colw, hw * 0.9, 12):
            if re.search(r"\\d", tok):
                return False, "原文該格是數字 %r(不是空值 · 值被弄壞)" % tok
            return True, "原文該格是 %r(別的空值記號)" % tok
        res = res or (True, "原文該格空白(最近的值離 %s 表頭 %.0f pt)" % (per, dx))
    return res


def verify_fin(rows, pdfdir, allrows=None):
''')
rep('''        if kind == "NIL" and verdict in ("FAIL", "PRESENT"):                   # v0103 空值記號找不到 → 不算錯值
            verdict, note = "NILVAL", "空值記號 %r 原文該格可能是空白 / 別的記號 · 不算錯值 · %s" % (val, note)
''', '''        if kind == "NIL" and verdict in ("FAIL", "PRESENT"):                   # v0103 空值記號找不到 → v0104 先看該格(Codex #561):空白 / 別的記號才 NILVAL · 數字仍 FAIL
            nc = _nil_cell(lines, labs, per)
            if nc and nc[0]:
                verdict, note = "NILVAL", "空值記號 %r · %s · 不算錯值 · %s" % (val, nc[1], note)
            else:
                note = "空值記號 %r · %s · %s" % (val, nc[1] if nc else "定不出科目列 / 這頁沒有這個期間表頭 · 不能確認該格是空的", note)
''')

# 自測
rep('''    chk("v0103 字距拆開的數字:「close NT$ 3, 190.00」對得到 3190 · 位置映回原字串 · 原本連著的也在",
        _num_cands("close (Dec 3, 2025) NT$ 3, 190.00", 3190.0) and all(_numv(re.sub(r"\\s", "", "close (Dec 3, 2025) NT$ 3, 190.00"[a:b])) == 3190.0 for a, b in _num_cands("close (Dec 3, 2025) NT$ 3, 190.00", 3190.0))
        and _num_cands("Price target NT$4,388.00", 4388.0) == [(16, 24)] and not _num_cands("Price target NT$4,388.00", 3190.0))
''', '''    chk("v0103 字距拆開的數字:「close NT$ 3, 190.00」對得到 3190 · 位置映回原字串 · 原本連著的也在",
        _num_cands("close (Dec 3, 2025) NT$ 3, 190.00", 3190.0) and all(_numv(re.sub(r"\\s", "", "close (Dec 3, 2025) NT$ 3, 190.00"[a:b])) == 3190.0 for a, b in _num_cands("close (Dec 3, 2025) NT$ 3, 190.00", 3190.0))
        and _num_cands("Price target NT$4,388.00", 4388.0) == [(16, 24)] and not _num_cands("Price target NT$4,388.00", 3190.0))
    chk("v0104 空白分開的兩個數不黏(Codex #561):「Price target 3 190」沒有 3190 · 「12 345」沒有 12345 · 「Dec 3, 2025」沒有 32025 · 「1, 234. 5」= 1234.5 · 「4,388. 00」= 4388",
        not _num_cands("Price target 3 190", 3190.0) and not _num_cands("close 12 345", 12345.0) and not _num_cands("Dec 3, 2025", 32025.0) and not _num_cands("Dec 3, 2025", 3202.0)
        and _num_cands("NT$ 1, 234. 5", 1234.5) == [(4, 13)] and (3, 12) in _num_cands("PT 4,388. 00", 4388.0) and _num_cands("Price target 3 190", 190.0) == [(15, 18)])
    nl = [(700.0, [(100, 130, "2024A"), (200, 230, "2025E"), (300, 330, "2026E")]), (690.0, [(0, 40, "Revenue"), (105, 125, "12.3"), (205, 215, "—")])]
    nlab = [(1, (0, 40, "revenue"), "同")]
    n1, n2, n3 = _nil_cell(nl, nlab, "2024A"), _nil_cell(nl, nlab, "2025E"), _nil_cell(nl, nlab, "2026E")
    chk("v0104 空值記號看該格(Codex #561):該格是 12.3 → 不是空值(仍 FAIL)· 該格是 — → NILVAL · 該格空白 → NILVAL · 定不出科目列 / 沒表頭 → None",
        n1 is not None and n1[0] is False and "12.3" in n1[1] and n2 is not None and n2[0] is True and "—" in n2[1] and n3 is not None and n3[0] is True and "空白" in n3[1]
        and _nil_cell(nl, [], "2024A") is None and _nil_cell(nl, nlab, "2027E") is None)
''')
rep('''    chk("v0103 標籤旁預設看前 4 頁 · 訊息寫「前 4 頁」"''', '''    chk("v0103 標籤旁預設看前 4 頁 · 訊息寫「前 4 頁」"''')
out.write_text(s, encoding="utf-8", newline="\n")
compile(s, out.name, "exec")
print("[計] %s · %d 位元組" % (out.name, len(s.encode("utf-8"))))
