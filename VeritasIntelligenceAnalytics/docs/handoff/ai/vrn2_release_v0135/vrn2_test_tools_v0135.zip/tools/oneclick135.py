"""一鍵 v0135:從 MAIN 的 VRN2_OneClick_v0134.md 取程式碼與 boot → 換版號 · $Want = 啟動器 v0135 SHA-256 · 驗證器 v0104 → Run-VRN2-v0135.ps1 + VRN2_OneClick_v0135.md + boot135.ps1 + oneline135.txt(冪等)。
用法:python oneclick135.py <MAIN 的 VRN2_OneClick_v0134.md> <ActivateVRN-2 v0135 SHA-256> <輸出夾>"""
import base64, hashlib, re, sys
from pathlib import Path
src, want, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]); assert re.fullmatch(r"[0-9a-f]{64}", want); out.mkdir(parents=True, exist_ok=True)
md = src.read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
assert base64.b64decode(one.split()[-1]).decode("utf-16-le") == boot + "\n"
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); ps = ps.replace(old_want, want)
n = ps.count("v0134"); ps = ps.replace("v0134", "v0135")
n3 = ps.count("驗證器 v0103"); assert n3 == 1, n3; ps = ps.replace("驗證器 v0103", "驗證器 v0104")
def rep(a, b):
    global ps; assert ps.count(a) == 1, (ps.count(a), a[:80]); ps = ps.replace(a, b)
rep("# ===== VRN-2 一鍵 v0135(啟動器 v0135 整合一支:處理器 v0104 · 驗證器 v0104 ·", "# ===== VRN-2 一鍵 v0135(啟動器 v0135 Codex #561 修正:驗證器 v0104 空值記號看該格 · 字距只接逗點 / 小數點後的空白;v0134 整合一支:處理器 v0104 ·")
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1); boot = boot.replace(h_old, cs).replace("v0134", "v0135") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
old_code = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); old_boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); old_one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
md = md.replace(old_code, "@PS@").replace(old_boot, "@BOOT@").replace(old_one, "@ONE@")
md = re.sub(r"[0-9a-f]{64}", want, md, count=1)
md = md.replace("v0134", "v0135").replace("驗證器 v0103", "驗證器 v0104")
md = md.replace("# VRN-2 一鍵 v0135(cmd / PowerShell 都能貼 · 啟動器 v0135 整合一支:處理器 v0104 · 驗證器 v0104 · U/I 自己跳出 · ⑨ 交接不回退)",
                "# VRN-2 一鍵 v0135(cmd / PowerShell 都能貼 · 啟動器 v0135 = v0134 + Codex #561 修正:驗證器 v0104 · 處理器 v0104 · U/I 自己跳出 · ⑨ 交接不回退)")
a = "v0135 = 操作員令(2026-10-21)"; assert md.count(a) == 1
md = md.replace(a, "v0135 = v0134 + Codex #561 修正(PR #561 合併後):獨立驗證器 v0104 —— 空值記號(n.a. / - / NM)只在原文該格確實是空白 / 別的記號才 NILVAL(該格是數字仍 FAIL)· 字距拆開的數字只接千分位逗點 / 小數點後的空白;一鍵流程、處理器 v0104、主體都同 v0134。\nv0134 = 操作員令(2026-10-21)")
md = md.replace("| 步驟 | v0135 改了什麼 |", "| 步驟 | v0134 改了什麼(v0135 同 · 只換驗證器)|")
md = re.sub(r"程式碼 SHA-256\(本文 · 一行核對的就是這個\):`[0-9a-f]{12}", "程式碼 SHA-256(本文 · 一行核對的就是這個):`" + cs[:12], md)
md = md.replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n")).replace("@ONE@", one)
assert re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) == ps and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot
assert "vrn2_release_v0135" in boot and "VRN2_OneClick_v0135.md" in boot and "v0134" not in boot
(out / "VRN2_OneClick_v0135.md").write_text(md, encoding="utf-8", newline="\n"); (out / "boot135.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline135.txt").write_text(one + "\n", encoding="utf-8"); (out / "Run-VRN2-v0135.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("launcher %s · code %s · one-liner %d 字 · md %d · 換版號 %d 處" % (want[:12], cs[:12], len(one), len(md), n))
