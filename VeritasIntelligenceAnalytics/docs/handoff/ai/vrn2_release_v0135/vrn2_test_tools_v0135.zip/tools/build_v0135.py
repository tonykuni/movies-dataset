"""ActivateVRN-2 v0134(MAIN · PR #561 已合併)→ v0135 組裝(錨點替換 · 每個錨點只准出現一次 · 不改 v0134 原檔)。
用法:python build_v0135.py <v0134 啟動器> <new 夾> <輸出 v0135 啟動器>
  new 夾:VRN2_IndependentVerifier_v0104.py · VRN2_Handover_v0135.md
v0135 = Codex #561 兩項修正只動獨立驗證器(v0104 內嵌 · v0102 / v0103 留著 · ⑪ 取最新版)+ 交接 v0135;處理器 / 管理器鏈 / ENG397 / 摘要器 / 工具橋 / OCR 橋 一個位元組都不動。"""
import base64
import hashlib
import sys
from pathlib import Path

src_p, new_d, out_p = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src_p.read_text(encoding="utf-8")


def b64(raw: bytes) -> str:
    t = base64.b64encode(raw).decode("ascii")
    return "\n".join(t[i:i + 120] for i in range(0, len(t), 120))


def rep(a: str, b: str) -> None:
    global s
    assert s.count(a) == 1, (s.count(a), a[:90])
    s = s.replace(a, b)


iv = (new_d / "VRN2_IndependentVerifier_v0104.py").read_bytes()
hand = (new_d / "VRN2_Handover_v0135.md").read_bytes()
isha, hsha = hashlib.sha256(iv).hexdigest(), hashlib.sha256(hand).hexdigest()

rep('r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0134 整合一支:',
    'r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0135 Codex #561 修正:獨立驗證器 v0104 —— 空值記號(n.a. / - / NM)只在原文該格確實是空白 / 別的記號才 NILVAL(該格是數字仍 FAIL)· 字距拆開的數字只接千分位逗點 / 小數點後的空白;v0102 / v0103 留著 · ⑪ 取最新版 · 其餘同 v0134;'
    'v0134 整合一支:')
rep('VERSION = "ActivateVRN-2 v0134"', 'VERSION = "ActivateVRN-2 v0135"')
rep('UI_HANDLER_NAME = "VRN2_UIAction_v0104.py"\n',
    'EXTRAS.append(("VRN2_IndependentVerifier_v0104.py", "%s", """\n%s\n"""))   # v0135 獨立驗證器 v0104(Codex #561:空值記號看該格 · 字距只接逗點 / 小數點後的空白 · ⑪ 取最新版 · v0102 / v0103 留著)\n' % (isha, b64(iv))
    + 'UI_HANDLER_NAME = "VRN2_UIAction_v0104.py"\n')
import re
s, n = re.subn(r'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0134\.md", "[0-9a-f]{64}"\n', 'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0135.md", "' + hsha + '"\n', s)
assert n == 1, n
# 內嵌交接換成 v0135 的 base64
i0 = s.index('HANDOVER_B64 = """\n'); i1 = s.index('\n"""', i0 + 20)
s = s[:i0] + 'HANDOVER_B64 = """\n' + b64(hand) + s[i1:]
rep('    """v0134 交接報告落地(⑨ 之前):內嵌的 VRN2_Handover_v0134.md 只在倉裡沒有時寫',
    '    """v0134 交接報告落地(⑨ 之前 · v0135 內嵌的是 VRN2_Handover_v0135.md):內嵌的交接只在倉裡沒有時寫')
# 自測:驗證器檢查改看 v0104
rep('    iv3_ = next((e for e in EXTRAS if e[0] == "VRN2_IndependentVerifier_v0103.py"), None)',
    '    iv3_ = next((e for e in EXTRAS if e[0] == "VRN2_IndependentVerifier_v0104.py"), None)')
rep('    with tempfile.TemporaryDirectory(prefix="act134iv-") as td_:\n        p_ = _cb_Path(td_) / "VRN2_IndependentVerifier_v0103.py"',
    '    with tempfile.TemporaryDirectory(prefix="act135iv-") as td_:\n        p_ = _cb_Path(td_) / "VRN2_IndependentVerifier_v0104.py"')
rep('    chk("v0134 內嵌獨立驗證器 v0103(v0102 留著 · ⑪ 取最新版):標籤旁前 4 頁 · _num_cands · _upside_recalc · src_score2 · _inm · NILVAL · 自測 → %s"',
    '    chk("v0135 內嵌獨立驗證器 v0104(v0102 / v0103 留著 · ⑪ 取最新版):Codex #561 / #562 _nil_cell · _val_row · _SPLITNUM · 標籤旁前 4 頁 · _num_cands · _upside_recalc · src_score2 · _inm · NILVAL · 自測 → %s"')
rep('        ivn_ == ["VRN2_IndependentVerifier_v0102.py", "VRN2_IndependentVerifier_v0103.py"] and all(x in iv3src for x in ("def _num_cands(", "def _upside_recalc(", "def src_score2(", "def _inm(", "NILVAL", "pages=(1, 2, 3, 4)"))',
    '        ivn_ == ["VRN2_IndependentVerifier_v0102.py", "VRN2_IndependentVerifier_v0103.py", "VRN2_IndependentVerifier_v0104.py"] and all(x in iv3src for x in ("def _num_cands(", "def _upside_recalc(", "def src_score2(", "def _inm(", "def _nil_cell(", "def _val_row(", "_SPLITNUM", "NILVAL", "pages=(1, 2, 3, 4)"))')
out_p.write_text(s, encoding="utf-8", newline="\n")
compile(s, out_p.name, "exec")
left = [l[:100] for l in s.split("\n") if "IndependentVerifier_v0103" in l and "EXTRAS.append" not in l and "ivn_ ==" not in l]
print("[計] %s · %d 位元組 · 驗證器 %s · 交接 %s · sha256 %s · 其餘 v0103 字樣 %d" % (out_p.name, len(s.encode("utf-8")), isha[:12], hsha[:12], hashlib.sha256(s.encode("utf-8")).hexdigest()[:12], len(left)))
for l in left:
    print("   ", l)
