#!/bin/bash
# 把 v0135 發行夾放進 movies-dataset 倉(不放 .ps1 · 一鍵程式碼嵌在 md 裡)· logs / 測試工具壓成 zip(固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v135
D=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
R=$D/vrn2_release_v0135; mkdir -p $R
python3 - <<'PY'
import zipfile, pathlib, re
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v135"); W4 = W.parent / "v134"
R = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0135")
def z(name, files):
    with zipfile.ZipFile(R / name, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            data = p.read_bytes()
            if p.suffix == ".log":
                data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 21, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(zi, data)
logs = [("selftest_v0135.log", W / "selftest_v0135.log")] + [("e2e_%s.log" % k, W / ("e2e_%s.log" % k)) for k in ("A1", "P1", "P2", "P1pick", "P2pick", "R", "R2", "audit")] + \
       [("scen_oneclick_v0134_to_v0135.log", W / "scen_oneclick.log"), ("ui_input_oneclick_v0135.log", W / "ui_input_oc.log"), ("chk5b_unit_v0135.log", W / "chk5b_unit.log"),
        ("verifier_v0104_selftest.log", W4 / "selftest_iv104.log"), ("verifier_v0104_regress_same_book.log", W4 / "vtest" / "run104.log"), ("verifier_v0103_regress_same_book.log", W4 / "vtest" / "run103.log"), ("ui_test_v0135.log", W / "ui_test.log")]
z("logs_v0135.zip", [(a, p) for a, p in logs if p.exists()])
tools = sorted((W / "tools").glob("*"))
z("vrn2_test_tools_v0135.zip", [("tools/" + p.name, p) for p in tools if p.is_file() and p.suffix != ".ps1"])
PY
for f in ActivateVRN-2_v0135.zip VRN2_Release_v0135.json VRN2_OneClick_v0135.md VRN2_Verification_v0135.md; do cp $W/release135/$f $R/; done
cp $W/new/VRN2_Handover_v0135.md $D/VRN2_Handover_v0135.md
cp $W/new/VRN2_Handover_v0135.md $D/VRN2_Handover_latest.md
ls -la $R; sha256sum $D/VRN2_Handover_latest.md $D/VRN2_Handover_v0135.md | cut -c1-16
