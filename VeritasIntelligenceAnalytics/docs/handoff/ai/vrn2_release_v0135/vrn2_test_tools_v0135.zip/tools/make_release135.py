"""vrn2_release_v0135:ActivateVRN-2_v0135.zip(ActivateVRN-2.py · 固定時間戳)+ VRN2_Release_v0135.json(冪等)。
用法:python make_release135.py <ActivateVRN-2_v0135.py> <results.json> <輸出夾>"""
import ast
import base64
import hashlib
import json
import sys
import zipfile
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)
raw = src.read_bytes()
sha = hashlib.sha256(raw).hexdigest()
zp = out / "ActivateVRN-2_v0135.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    zi = zipfile.ZipInfo("ActivateVRN-2.py", date_time=(2026, 10, 21, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    z.writestr(zi, raw)
tree = ast.parse(raw.decode("utf-8"))
consts, extras = {}, []
for n in tree.body:
    if isinstance(n, ast.Assign):
        try:
            v = ast.literal_eval(n.value)
        except Exception:  # noqa: BLE001
            continue
        for tg in n.targets:
            if isinstance(tg, ast.Name):
                consts[tg.id] = v
            elif isinstance(tg, ast.Tuple):
                for e, vv in zip(tg.elts, v):
                    consts[e.id] = vv
    elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and getattr(n.value.func, "attr", "") == "append":
        extras.append(ast.literal_eval(n.value.args[0]))


def comp(name, h, b64):
    b = base64.b64decode("".join(b64.split()))
    assert hashlib.sha256(b).hexdigest() == h, name
    return {"file": name, "bytes": len(b), "sha256": h}


order = [comp(*c) for c in consts["MGR_CHAIN"]] + [comp(consts["MGR_NAME"], consts["MGR_SHA"], consts["MGR_B64"])]
order += [comp(*c) for c in consts["ENGINES"]] + [comp(*c) for c in list(consts["EXTRAS"]) + extras]
order += [comp(consts["OCR_BRIDGE_NAME"], consts["OCR_BRIDGE_SHA"], consts["OCR_BRIDGE_B64"]), comp(consts["HANDOVER_NAME"], consts["HANDOVER_SHA"], consts["HANDOVER_B64"])]
R = json.loads(res_p.read_text(encoding="utf-8"))
man = {
    "system": "VRN-2",
    "independent": True,
    "release": "ActivateVRN-2 v0135",
    "date": "2026-10-21",
    "codex_561": ["P1 空值記號一律 NILVAL 沒看該格 → v0104 _nil_cell(該格是數字仍 FAIL)", "P2 _num_cands 去掉整列空白把兩個數黏成一個 → v0104 _SPLITNUM 只接千分位逗點 / 小數點後的空白", "v0134 已合併 MAIN(PR #561)→ 不改 · 出 v0135"],
    "operator_order_2026_10_21": ["integrate into one code to handle all above.(把 Windows 實跑 C:\測試樣本報告 抓到的事全部整進同一支啟動器)", "完成收尾跳出HTML U/I來操作 實測結果100%輸出符合", "換輸入檔案audit\"C:\測試樣本報告\""],
    "supersedes": "ActivateVRN-2 v0134(docs/handoff/ai/vrn2_release_v0134 · PR #561 已合併 MAIN)· 主體 + 處理器 v0102 / v0103 / v0104 + 驗證器 v0102 / v0103 共 19 個元件逐位元組相同 · 新增 驗證器 v0104 · 交接 v0135",
    "design": {
        "frontend": "VIA_Reports/vrn2/VRN2_UI_latest.html(管理器 ⑦ 產生 · 啟動器 ⑪ 寫回驗證 · ⑫ PIVOT 連結 · ⑫b 輸入區塊)",
        "backend": "vrn2:// 協定(HKCU 註冊 · 寫完讀回核對)→ VRN2_UIAction_v0104.py → 啟動器 ActivateVRN-2.py(①~⑫)· ⑪ 獨立驗證器 v0104(取最新版 · v0102 / v0103 留著)",
        "window_io": "vrn2://pick?kind=folder|files&cat=stock → Windows 原生對話框(System.Windows.Forms · tkinter 備援)→ 稽核 → VRN2_Input_latest.json → ②b 當來源夾(寫新一版 VRN2_SSOT · 管理器不動)",
        "categories": {"stock": "個股報告/訊息(開放)", "industry": "產業報告/展望(尚未開放 · U/I disabled · 處理器拒絕)", "other": "其他投資報告(尚未開放 · 同上)"},
        "file_types": "pdf · docx · doc · txt · png · jpg · jpeg · tif · tiff · bmp(同 ENG397 EXT · 自測逐鍵核對)· 本版主體只擷取 PDF · 非 PDF 照實記「已收下 · 本版主體只擷取 PDF」",
        "registration_check": "貼包多一行「註冊核對」:⑤ 元件登記 · ⑥c vrn2://(讀回核對)· ② 定位登記;一鍵 ⑤b 把 HKCU 指令解析成 python + 處理器,處理器整條路徑(正規化)= 本機 VRN-2 程式夾的 VRN2_UIAction_v0103.py 且檔在(或那一夾有啟動器本輪寫的 VRN2_UIAction_Config.json v0134)· python 檔在 · U/I 有輸入區塊;⑤b 的燈併進一鍵 NEXT(紅 → 紅 · 黃 → 最多黃;Codex #550 修正)",
        "rules": "只增不減(處理器 v0102 / v0103 · 驗證器 v0102 / v0103 留著)· 已合併 MAIN 的版本不改、修正出新版號· VRN-2 主體一個位元組都不動 · 路徑只從對話框與啟動器寫的設定讀 · 不從網址讀路徑",
        "v0135_codex561": {"nil_cell": "空值記號(n.a. / - / NM)原文找不到 → 先定科目列、對期間欄看原文該格:數字 → 仍 FAIL · 空白 / 別的記號 → NILVAL · 定不出 → 仍 FAIL", "split_num": "字距拆開的數字只接千分位逗點 / 小數點後的空白(3, 190.00 · 1, 234. 5);3 190 · 12 345 · Dec 3, 2025 不黏", "versioning": "v0134 已合併 MAIN → 不改 · v0135 只換內嵌驗證器 + 交接"},
    "v0134_integrated": {"ui_open": "只認 --no-open / VRN2_NO_UI=1(VIA 設定檔的 VIA_NO_OPEN=1 不再讓一鍵不開 U/I)", "handover_land": "⑨ 內嵌交接只在倉裡沒有時寫 · latest = 倉裡最高版號(不回退)", "handler_v0104": "檔名規則取最新版管理器的 _SK_EXCL", "verifier_v0104": "標籤旁看前 4 頁 · 字距拆開的數字(只接千分位逗點 / 小數點後的空白)· 上漲空間推算相符(註記推算)· 覆蓋率去標點 · 科目名去 * † $ 括號 · 空值記號只在原文該格確實是空白 / 別的記號才 NILVAL(該格是數字仍 FAIL;Codex #561)", "not_changed_honestly": "DUPKEY(同鍵不同值)· 標籤對調 · ModelWare EPS → 擷取 / 摘要器下一輪"}
    },
    "embedded_components_landing_order": order,
    "tested_in": {
        "where": "Claude Code 雲端容器 · Linux · Python 3.13 · 測試用隔離 venv(repo 與系統 Python 未動)· OCR 隔離環境另建 Python 3.11 venv(rapidocr_onnxruntime · numpy<2)只在暫存區",
        "inputs": "repo 內真實 PDF 19 份(個股 14)· U/I 選資料夾子集 6 PDF(個股 5)+ txt / docx / png · U/I 選檔案 2 PDF + 1 txt → 暫存夾",
        "chain_stub": "使用者機器的管理器前版鏈 v0154–v0230 不在 repo → 測試替身(只供 p1loop / _rep / input_dir 等)· 不可提交",
        "vrn1": "VIA-VDF-VRN 倉 main @ 876a4f6(PR #80 已合併 · 工具冊 ssot/VRN_ToolManifest_v0100.json)· 另一份 = main 62475b0(沒有工具冊 · 實測 ⑫ 灰 + git switch 指令)",
    },
    "results": R,
    "launcher": {"file": "ActivateVRN-2_v0135.py", "bytes": len(raw), "sha256": sha},
    "launcher_zip": {"file": zp.name, "sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "member": "ActivateVRN-2.py"},
    "oneclick": "VRN2_OneClick_v0135.md",
    "test_tools_zip": "vrn2_test_tools_v0135.zip",
    "logs_zip": "logs_v0135.zip",
}
(out / "VRN2_Release_v0135.json").write_text(json.dumps(man, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
print("[計] launcher %s · zip %s · 元件 %d" % (sha[:12], man["launcher_zip"]["sha256"][:12], len(order)))
