"""v0170 收尾:驗證紀錄 · 交接 v0171(從 v0170 抄 · 只增)· 放進倉 vrn2_release_v0170 · logs / 工具 zip。桌機主控台的值不進倉(只寫結論與筆數)。"""
import csv, hashlib, json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v170"); rel = W / "release170"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


R = json.loads((rel / "VRN2_Release_v0170.json").read_text(encoding="utf-8"))
H = R["handleall"]
ra = [l for l in lines(W / "rall126_selftest.log") if re.search(r"^\[PASS\] 9[01] |^\[FAIL\]|--selftest · ", l)]
assert any("93 項 · 不過 0" in l for l in ra), ra[-1:]
sel = {}
for name, log in (("workbench_v0105", "wb105_selftest.log"), ("consensusjoin_v0106", "cj106_selftest.log"), ("launcher_v0170", "launcher170_selftest.log")):
    ls_ = lines(W / log)
    fails = [l for l in ls_ if l.startswith("[FAIL]")]
    assert not fails, (name, fails[:2])
    sel[name] = next((l for l in reversed(ls_) if l.startswith(("[GREEN]", "[PASS]"))), "")[:160]
ps = json.loads((W / "pscheck170.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
assert [x["e"] for x in ps] == [0, 0, 0, 0, 0] and ps[0]["h"] == ps[1]["h"] and ps[2]["h"] == ps[3]["h"]
rc = [l for l in lines(W / "tiny170.rc") if l.strip()]
pat = r"boot:|boot SHA|④ 自動選模式|④ 同意閘未開|快照補位|已中止|① 套件 ·|Workbench v0105|ConsensusJoin v0106|⑪ 獨立驗證 · 年度|===== 收尾|\[(VRN-2|人工|VCGC|資料源|提醒)\] \d"
e2e = {n: [l.replace(str(W / "t170a"), "<sbx>").replace(SCR, "<scratch>")[:220] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)][:16] for n in ("auto1", "auto2", "tamper")}
states = {}
for n in ("auto1", "auto2"):
    d = json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))
    states[n] = {"state": d["state"], "per_owner": d["per_owner"]}
wb1 = (W / "wb_auto1.html").read_text(encoding="utf-8")
assert wb1.count('id="wb105-css"') == 1 and wb1.count('id="wb105"') == 1 and "資料驗證狀況" in wb1
wb_mark = re.search(r"<!-- VRN2_Workbench v0105 over (v\d{4}) -->", wb1).group(1)
sd = json.loads((W / "snapdeny_result.json").read_text(encoding="utf-8"))
assert sd["snapshot_reused"].get("asof") == "2026-11-01" and sd["factset_filled"] > 0 and sd["yfinance_filled"] > 0 and sd["owner"] == "提醒", sd
sdl = [l for l in lines(W / "snapdeny.log") if l.startswith("[")]
assert not [l for l in sdl if l.startswith("[FAIL]")] and sdl[-1].startswith("[GREEN]"), sdl[-3:]
wbs = (W / "wb_snap.html").read_text(encoding="utf-8")
assert "快照 ASOF 2026-11-01" in wbs and wbs.count('id="wb105"') == 1
snap_check = ("邊界實測(沙盒樹 · 前版 run 換成桌機 13:01 形狀的 DENY 收據(合成)· 其餘全真程式):補位 %d 檔 · ASOF 2026-11-01 · "
              "Combined %d 列 · FactSet 中位數 %d · Yahoo 中位數 %d · 收尾列「提醒」 · Workbench ASOF 徽章在;整輪 e2e 裡 Workbench v0105 over %s 已渲染"
              % (sd["snapshot_reused"].get("codes", 0), sd["combined_rows"], sd["factset_filled"], sd["yfinance_filled"], wb_mark))
R["results"] = {"roundall_v0126_selftest": ra[-1:], "module_selftests": sel, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "closeout_states": states,
                "snapshot_backfill_boundary_test": dict(sd, note="沙盒擷取環境缺 requests → 前版鏈走「擷取環境缺」路徑到不了同意閘(桌機才到得了 · 12:31 / 13:01 實錄是 gate_closed DENY);"
                                                                 "本測在 v0106 邊界把前版 run 換成桌機形狀的 DENY 收據(合成矩陣 · 合成數字),之後 run / plan_fixes / join / Workbench / owner_of 全走真程式;閘從頭到尾沒被設"),
                "workbench_v0105_e2e": "rendered over %s in the sandbox (desktop will chain its local v0104): wb105 CSS × 1 · verification-lamp panel · consensus panel · ASOF badge" % wb_mark,
                "not_run": "the desktop itself (one line · auto = full round on the new launcher; opening the gate stays optional and operator-only) · the operator's own --confirm"}
(rel / "VRN2_Release_v0170.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0170 驗證紀錄(2026-11-02 · Workbench v0105 U/I · ConsensusJoin v0106 共識欄快照補位 · 套件 v0170 · RoundAll v0126 · Handle-All v0118)

## 1. 這輪要解的(操作員 2026-11-02)

「開閘共識欄 · 要有共識資料 · Workbench 面板緊湊 / 字體比頁首略小 / 有底色的字白色 / 矩陣欄寬自動 / 紅黃綠資料驗證燈 · 授權自行完成 VRN-2 收尾」。
同意閘(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT)仍只由操作員設 —— 本輪**沒有**任何程式代設;「開閘共識欄」用的是**碟上快照補位 + ASOF 寫實標示**。

## 2. 改了什麼(add-only · 引擎 / 管理器 / 驗證器都不動)

| 件 | 內容 |
|---|---|
| VRN2_Workbench_v0105(runtime 新成員)| **動態前版薄尾**:同夾找版號比自己小的最高前版(桌機 = v0104 · 本倉 runtime = v0102;v0103 / v0104 是桌機另一條線加的,原始碼不在本倉 → 不指名、不重寫,前版先渲染、v0105 只做後處理)。CSS 蓋版(面板緊湊 · 面板最大字 17px < 頁首 h1 20px · .pill / .sm-st 實底白字 · 矩陣 table-layout:auto + 表頭 sticky + 緊湊 padding)+ `<main>` 開頭插兩個自包含面板:「資料驗證狀況」(9 列紅黃綠灰燈:原文值核對 · 獨立驗證 · 冪等 · 完成判定 · ⑥e · ⑥f · ⑬b · ⑬ · Combined 共識欄)與「共識資料」(兩家目標價中位數矩陣 · 快照輪次紅底白字 ASOF 徽章)。前版簽章用 inspect 讀(不假設 v0104 跟 v0102 一樣)· 後處理失敗前版頁照出(黃字) |
| VRN2_ConsensusJoin_v0106(runtime 新成員)| v0105 薄尾:**只在「net_deny.gate_closed = True 且 per_code 空」**時,用碟上最新共識快照 `consensus/factset_yfinance_consensus_matrix.csv`(引擎上次成功落盤 · 只讀)補位 per_code;收據寫 `snapshot_reused{asof · source · codes}`,why 開頭「快照補位(ASOF …)」。合規 DENY(VCGC 判定)不補位 · 快照沒有這批代號不補位(原因寫實)· `VIA_VRN2_NO_SNAPSHOT=1` 關掉 · 開閘輪次照舊真抓並蓋掉快照 |
| ActivateVRN-2_v0170(套件)| WORKBENCH 指到 v0105 · CONSENSUS_JOIN_ACTIVE 指到 v0106 · 收據鍵多收 snapshot_reused · 自測多 v0170 段(v0106 鏈改接 run / join · 沒快照誠實不補)· **跳過 v0169 啟動器號**(發行夾 v0169 只換 RoundAll)|
| VRN2_Runtime_v0160 | = v0159 的 198 個成員逐位元組不動 + 上面兩個新模組(200 個成員)|
| VRN2_RoundAll_v0126 | ⑤ 自動修新步 **consensus_snapshot**(閘未開 DENY · per_code 空 · 閘仍關 · 碟上有快照 → 跑 ConsensusJoin v0106 → 重組 Combined → 增量庫 / Workbench 跟著)· 收尾頁負責方:⑥f 列帶「快照補位」→ **提醒**(比「同意閘未開 → 人工」優先)· 自測 93 項 |
| VRN2_HandleAll_v0118 | 指到 v0170 · 整輪 + 閘未開的提問改寫實:「有快照 → 補位(列提醒);沒有 → 留空(列人工)」· 照舊永不代設閘 |

## 3. 測試(全部綠)

| 項目 | 結果 |
|---|---|
| RoundAll v0126 自測 | %s |
| Workbench v0105 自測 | %s(含:對桌機 13:01 真 v0104 頁的乾跑 —— CSS / 區塊 / 9 燈注入成功 · Combined 空時共識燈誠實紅)|
| ConsensusJoin v0106 自測 | %s |
| 啟動器 v0170 自測 | %s |
| PowerShell 剖析 | %s |
| e2e(最短一行 · 沙盒含三份原文 + 合成快照)| %s · auto 整輪(閘關 · Workbench v0105 面板已渲染)→ repair → 竄改開機檔不執行 · 收尾狀態 %s(VRN-2 3 項 = 沙盒 numpy/scikit 環境令 3 份新 PDF 摘要缺 · 桌機沒這問題 · v0166 起已記錄)|
| DENY → 快照補位(沙盒到不了同意閘 → 邊界實測)| %s |

## 4. 桌機下一步(一行 · 不用先開閘)

直接貼 `vrn2_release_v0170/VRN2_HandleAll_v0118.md` 的最短一行(%d 字元)→ auto = **整輪**(新啟動器 v0170 · 約 40 分鐘):
⑥f 被 DENY 後會自動用桌機碟上的 2026-11-01 快照補回 Combined 共識欄(收尾列「提醒」· Workbench 紅底白字標 ASOF)。
要**最新**共識才需要先貼 `$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'`(同一個 PowerShell 視窗 · 操作員決定)。
開機檔 `vrn2_release_v0170/VRN2_HandleAll_v0118_boot.txt` SHA-256 `%s` · Handle-All 一行 `%s` · RoundAll v0126 `%s` · 套件 `%s`。

## 5. VRN-2 收尾的終點(不變)

收尾頁 **VRN-2 0 · VCGC 0**;人工項(MQ-1560 四點 H-fd2ea35f 等 · 以收尾頁列的代碼為準)由操作員親手 `--confirm` 記錄後 → **DATA_GAP(只剩資料源)**。
PASS 要外部缺口全消(⑥e VDF rc 2 PARTIAL 與 AAPL 非台股是來源的事)。SSOT 517 件待 VCGC 核號(四系統對等 · VRN-2 只讀等待)。

## 6. 沒做 / 待辦

- 人工確認只有操作員親手打 `--confirm`(AI 不代確認 —— 即使在「授權自行完成收尾」之下,這是操作員 v0165 輪定的規則)。
- 3014TT 四點(第 2 點從句中開始 · 第 1 / 3 點重複)· MQ-1560 OCR 字詞錯(chi players 應為 chip layers)→ 要改摘要器 + 整輪,操作員點頭才做。
- 桌機 Workbench v0103 / v0104 的原始碼在桌機那條線(本倉沒有);v0105 動態接前版,桌機那邊再出新版(≤ v0104)也照接。
""" % (" · ".join(x[:90] for x in ra[-1:]), sel["workbench_v0105"], sel["consensusjoin_v0106"], sel["launcher_v0170"], pparse,
       " · ".join(rc), json.dumps(states, ensure_ascii=False), snap_check, H["tiny_line_chars"],
       H["boot_line_sha256"][:12], H["line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12])
(rel / "VRN2_Verification_v0170.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0170.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0168 + VRN2_RoundAll_v0125 + VRN2_HandleAll_v0117 · 2026-11-02(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0170 + VRN2_RoundAll_v0126 + VRN2_HandleAll_v0118 · 2026-11-02(Workbench v0105 U/I · "
        "共識欄快照補位(ASOF 寫實 · 不代設閘)· 套件 v0170 · 跳過 v0169 啟動器號)")
src = "\n".join(L)
lsha = hashlib.sha256((W / "pkg170" / "ActivateVRN-2_v0170.py").read_bytes()).hexdigest()
once("> **本輪(v0169)**",
     "> **本輪(v0170)**:操作員「開閘共識欄 · 要有共識資料 · Workbench 緊湊 / 白字 / 欄寬自動 / 紅黃綠資料驗證燈 · 授權自行完成收尾」→ 套件 v0170:"
     "**Workbench v0105**(動態前版尾 · 桌機接它自己的 v0104(原始碼不在本倉 · 另一條線加的)· 前版先渲染 · v0105 只後處理:緊湊 CSS 蓋版 · 面板最大字 17px < 頁首 20px · "
     "實底徽章白字 · 矩陣欄寬自動 + sticky 表頭 · 9 列紅黃綠資料驗證燈面板 · 共識面板帶紅底白字 ASOF 徽章)· **ConsensusJoin v0106**(閘未開 DENY 且沒新抓 → 碟上最新共識快照補位 "
     "Combined 共識欄 · snapshot_reused{asof·source·codes} · 合規 DENY 不補 · VIA_VRN2_NO_SNAPSHOT=1 關掉 · 閘照舊只由操作員設)· **RoundAll v0126**(⑤ 新步 consensus_snapshot · "
     "⑥f「快照補位」列 → 提醒 · 自測 93 項)· **Handle-All v0118**(最短一行 %d 字元 · cmd 一行 %d 字元)。沙盒 e2e:整輪(閘關)→ Workbench v0105 面板全到位 → repair → 竄改不執行;"
     "快照補位走邊界實測(沙盒擷取環境缺 requests 到不了同意閘 → 前版 run 換成桌機 13:01 形狀的合成 DENY 收據,其餘全真程式):補位 6 檔 · ASOF 2026-11-01 · Combined 兩家中位數欄有值 · 收尾列「提醒」。\n"
     "> **本輪(v0169)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
once("| **VRN2_Closeout_v0168.zip**(發行夾 · 套件)| **v0168** | `vrn2_release_v0168` | `931b6a9ac38c` | **新**(啟動器 v0168 · runtime v0159 · 管理器 v0259)|",
     "| **VRN2_Closeout_v0170.zip**(發行夾 · 套件)| **v0170** | `vrn2_release_v0170` | `%s` | **新**(啟動器 v0170 · runtime v0160 · Workbench v0105 · ConsensusJoin v0106)|\n"
     "| **VRN2_HandleAll_v0118.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0118** | `vrn2_release_v0170` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0126 · 閘未開提問寫快照補位)|\n"
     "| **VRN2_RoundAll_v0126.py**(發行夾 · 一支入口 · 不在套件內)| **v0126** | `vrn2_release_v0170` | `%s` | **新**(⑤ consensus_snapshot · ⑥f 快照補位列 → 提醒 · 自測 93 項)|\n"
     "| ActivateVRN-2_v0170.py(套件 · 底座 v0136 · runtime v0160 · 版號跳過 v0169)| **v0170** | 見發行清單 | `%s` | **新**(Workbench v0105 · ConsensusJoin v0106 · 收據 v0170)|\n"
     "| VRN2_Runtime_v0160.zip(套件 · runtime)| **v0160** | 套件內 | `%s` | **新**(v0159 的 198 個成員不動 + VRN2_Workbench_v0105 + VRN2_ConsensusJoin_v0106)|\n"
     "| VRN2_Workbench_v0105.py(runtime · **動態前版尾**:桌機接 v0104 · 本倉接 v0102)| **v0105** | runtime v0160 | 見 runtime 清單 | **新**(緊湊 CSS 蓋版 · 白字徽章 · 欄寬自動 · 資料驗證燈 · 共識面板 + ASOF)|\n"
     "| VRN2_ConsensusJoin_v0106.py(runtime · 薄尾 v0105)| **v0106** | runtime v0160 | 見 runtime 清單 | **新**(閘未開 DENY → 碟上快照補位 · snapshot_reused · 不代設閘)|\n"
     "| VRN2_Closeout_v0168.zip(發行夾 · 套件)| v0168 | `vrn2_release_v0168` | `931b6a9ac38c` | 被 v0170 取代(啟動器 v0168 · runtime v0159 · 管理器 v0259)|"
     % (R["package"]["sha256"][:12], H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12], lsha[:12], R["runtime"]["zip_sha256"][:12]))
once("| 0 | **(v0169)**",
     "| 0 | **(v0170)** 直接貼 `vrn2_release_v0170/VRN2_HandleAll_v0118.md` 的最短一行(不用先開閘)→ auto = 整輪(啟動器 v0170 · 約 40 分鐘):⑥f DENY 後自動用桌機 2026-11-01 快照補回 Combined 共識欄(列「提醒」· Workbench 標 ASOF)· 要**最新**共識才先貼 `$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'` · MQ-1560 四點看過原圖後操作員自己打 `--confirm` | 貼回 / 人工 |\n"
     "| 0 | **(v0169)**")
once("**v0169(2026-11-02)**:", "**v0170(2026-11-02)**:操作員 U/I + 共識欄需求 → Workbench v0105(動態前版尾 · 緊湊 / 白字 / 欄寬自動 / 資料驗證燈 / 共識面板)· ConsensusJoin v0106(閘未開 → 碟上快照補位 · ASOF 寫實)· RoundAll v0126 · Handle-All v0118 · 套件 v0170(runtime v0160 · 跳過 v0169 啟動器號)。\n\n**v0169(2026-11-02)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0170)** **桌機可能有本倉沒有的尾版**:桌機的 VRN2_Workbench_v0103 / v0104 是另一條工作線直接落在桌機 `functional modules\\VRN2` 的(本倉與 runtime 都沒有原始碼)。"
     "要再出新版就照 v0105 的做法:**動態前版**(同夾找版號比自己小的最高版 · 不指名檔名)+ **渲染後處理**(前版先渲染 · 新版只注入 CSS / 自包含區塊),前版簽章用 inspect 讀;"
     "絕不重寫或指名別條線的內容(九頭龍)。\n"
     "- **(v0170)** **共識快照補位的界線**:只補「同意閘未開 DENY 且本輪沒新抓」;ASOF / 來源 / 檔數都寫實(snapshot_reused),收尾列「提醒」;合規 DENY(VCGC)不補;"
     "快照沒有這批代號不補;`VIA_VRN2_NO_SNAPSHOT=1` 關掉;**同意閘永不代設**(操作員 2026-10-31 規則不變)。\n\n")
(REPO / "VRN2_Handover_v0171.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0170"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0170.zip", "VRN2_RoundAll_v0126.py", "VRN2_RoundAll_v0126.md", "VRN2_HandleAll_v0118.md", "VRN2_HandleAll_v0118_boot.txt", "VRN2_Release_v0170.json", "VRN2_Verification_v0170.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 2, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t170a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0170.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall126_selftest.log", "wb105_selftest.log", "cj106_selftest.log", "launcher170_selftest.log", "pscheck170.log", "tiny170.rc", "seed170.log", "confirm_list.log",
                              "snapdeny.log", "snapdeny_result.json", "combined_snap.csv")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")) + sorted(W.glob("cons_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0170.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall126.py", "mk_launcher170.py", "runtime160.py", "build170.py", "finalize170.py", "e2e170.sh", "snapdeny_test.py")] + \
             [W / "new" / n for n in ("VRN2_Workbench_v0105.py", "VRN2_ConsensusJoin_v0106.py")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0171", src.count("\n"), "· launcher sha", lsha[:12])
