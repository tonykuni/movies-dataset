"""沙盒 DENY → 快照補位 路徑實測。
沙盒的擷取環境沒有 requests / yfinance,ConsensusJoin 前版鏈走「擷取環境缺」路徑,到不了同意閘(桌機才到得了:12:31 / 13:01 實錄
engine raise PermissionError VIA_NET_DENY → net_deny.gate_closed = True · per_code 清空)。所以本測在 v0106 的邊界換前版:
把 cj._v0105_run 換成「回桌機 13:01 形狀的 DENY 收據(內容合成 · 代號取沙盒 BasicInfo)」,之後全走真程式:
v0106.run(關補位 → 收據照 DENY)→ RoundAll v0126 plan_fixes(應排 consensus_snapshot)→ v0106.run(開補位 = ⑤ 的修法)
→ v0106.join(Combined 共識欄)→ Workbench v0105 重渲染(ASOF 徽章)→ owner_of(提醒)。只在測試行程內換,不動任何檔。"""
import importlib.util, json, os, sys
from pathlib import Path

T = Path(sys.argv[1])                        # 沙盒 t170a
W = Path(sys.argv[2])                        # v170 工作夾
root = T / "VIA"
v2 = root / "VIA_Reports" / "vrn2"
rt = root / "functional modules" / "VRN2"
for k in ("VIA_NET_CONSENT", "VIA_SCRAPE_CONSENT", "VIA_VRN2_NO_SNAPSHOT"):
    os.environ.pop(k, None)

spec = importlib.util.spec_from_file_location("cj106_t", rt / "VRN2_ConsensusJoin_v0106.py")
cj = importlib.util.module_from_spec(spec); sys.modules["cj106_t"] = cj; spec.loader.exec_module(cj)
spec = importlib.util.spec_from_file_location("rall126_t", T / "home" / "Downloads" / "VRN2_RoundAll_v0126.py")
ra = importlib.util.module_from_spec(spec); sys.modules["rall126_t"] = ra; spec.loader.exec_module(ra)

codes = cj.V0100.codes_from_basic(v2)
NOTE = "VIA_NET_DENY: VIA 網路工具同意閘未開(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT · 操作員決定 · 引擎不代設 · 不換道直連)"


def deny_run(v2_, root_=None, fixtures=None, timeout=900, engine=None):
    """桌機 13:01 形狀的 DENY 收據(合成 · 不是桌機值):net_deny.gate_closed · per_code 空(v0104 規則清空)。"""
    rec = {"engine_wrapper": "VRN2_ConsensusJoin %s" % cj.TAG, "verb": "run", "at": "2026-11-02T06:30:00", "codes": list(codes),
           "yf_ticker_map": {"tpex": []}, "rc": 1, "gate": "", "lamp": "YELLOW",
           "why": "VIA 網路工具 DENY(%s)· 同意閘 VIA_NET_CONSENT / VIA_SCRAPE_CONSENT 是操作員的決定(VRN-2 不代設)· 不換道直連" % NOTE[:120],
           "net_deny": {"note": NOTE, "gate_closed": True}, "net_tool": "SUP_MDL740_NetUnified_v0119 · 閘 關",
           "engine_no_output": {"rc": 1, "last": "PermissionError: " + NOTE}, "per_code": {}, "codes_got": [], "codes_missing": list(codes)}
    return cj.V0100._finish(Path(v2_) / "consensus", rec)


cj._v0105_run = deny_run                      # 只換本行程的前版 run(桌機那步已由 12:31 / 13:01 實錄證明);其餘全走真程式

ok = True


def chk(label, cond):
    global ok
    print("[%s] %s" % ("PASS" if cond else "FAIL", label))
    ok = ok and bool(cond)


chk("⓪ 沙盒代號 %d 檔 · 快照 csv 在" % len(codes), len(codes) >= 6 and (v2 / "consensus" / "factset_yfinance_consensus_matrix.csv").is_file())
os.environ["VIA_VRN2_NO_SNAPSHOT"] = "1"
rec0 = cj.run(v2, root, None, 120)
os.environ.pop("VIA_VRN2_NO_SNAPSHOT", None)
chk("① DENY 收據落地:gate_closed = True · per_code 空(補位關掉)", bool((rec0.get("net_deny") or {}).get("gate_closed")) and not rec0.get("per_code"))
A = type("A", (), {"integrate": "skip"})
plan = ra.plan_fixes(root, {"market": {}, "consensus": {"run": {"lamp": "YELLOW"}}}, "", A(), "")
keys = [k for k, _ in plan]
d_snap = next((d for k, d in plan if k == "consensus_snapshot"), "")
chk("② ⑤ 計畫排 consensus_snapshot(ASOF 2026-11-01 寫在說明)→ 之後跟 combined", "consensus_snapshot" in keys and "ASOF 2026-11-01" in d_snap and keys.index("consensus_snapshot") < keys.index("combined"))
rec = cj.run(v2, root, None, 120)
snap = rec.get("snapshot_reused") or {}
chk("③ 補位:per_code %d 檔 · snapshot_reused.asof 2026-11-01 · why 以「快照補位」開頭" % len(rec.get("per_code") or {}),
    bool(rec.get("per_code")) and snap.get("asof") == "2026-11-01" and str(rec.get("why", "")).startswith("快照補位"))
got = cj.join(v2)
chk("④ join:why 帶「ASOF 2026-11-01」· Combined 檔有寫", "ASOF 2026-11-01" in str(got.get("why")) and (v2 / "output" / "VRN2_Combined_latest.csv").is_file())
import csv
with (v2 / "output" / "VRN2_Combined_latest.csv").open("r", encoding="utf-8-sig", newline="") as fh:
    rows = list(csv.DictReader(fh))
fs = sum(1 for r in rows if (r.get("FACTSET_TARGET_PRICE_MEDIAN") or "").strip())
yf = sum(1 for r in rows if (r.get("YFINANCE_TARGET_PRICE_MEDIAN") or "").strip())
chk("⑤ Combined %d 列 · FactSet 中位數欄有值 %d · Yahoo 中位數欄有值 %d(> 0)" % (len(rows), fs, yf), fs > 0 and yf > 0)
spec = importlib.util.spec_from_file_location("wb105_t", rt / "VRN2_Workbench_v0105.py")
wb = importlib.util.module_from_spec(spec); sys.modules["wb105_t"] = wb; spec.loader.exec_module(wb)
out = wb.render(root)
h = Path(out).read_text(encoding="utf-8")
chk("⑥ Workbench v0105 重渲染:ASOF 徽章 + 共識燈列帶快照說明 + 共識矩陣", "快照 ASOF 2026-11-01" in h and h.count('id="wb105"') == 1 and "快照補位 ASOF 2026-11-01" in h and h.count("<tbody>") >= 1)
row = {"lamp": "YELLOW", "step": "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)", "detail": "共識 YELLOW:" + str(rec.get("why"))[:200]}
own = ra.owner_of(row, {})
chk("⑦ 收尾負責方:這列 → 提醒(不是人工 / VRN-2)", own[0] == "提醒")
json.dump({"snapshot_reused": snap, "combined_rows": len(rows), "factset_filled": fs, "yfinance_filled": yf, "owner": own[0]},
          open(W / "snapdeny_result.json", "w", encoding="utf-8"), ensure_ascii=False)
import shutil
shutil.copy(v2 / "consensus" / "VRN2_Consensus_latest.json", W / "cons_snap.json")
shutil.copy(v2 / "output" / "VRN2_Combined_latest.csv", W / "combined_snap.csv")
shutil.copy(out, W / "wb_snap.html")
print("[%s] 沙盒 DENY → 快照補位 路徑實測(8 項)" % ("GREEN" if ok else "RED"))
sys.exit(0 if ok else 1)
