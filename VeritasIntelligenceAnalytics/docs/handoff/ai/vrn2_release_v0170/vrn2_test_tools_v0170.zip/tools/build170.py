"""v0170(冪等):套件 VRN2_Closeout_v0170.zip(啟動器 v0170 · runtime v0160 = v0159 + Workbench v0105 + ConsensusJoin v0106)→ RoundAll v0126(填套件雜湊)
→ Handle-All v0118(指到 v0170 · 閘未開提示改寫快照補位)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0170)。vrn2_release_v0169 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v170"); pkg, rel = W / "pkg170", W / "release170"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v169/release169")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r168 = json.loads((REPO / "vrn2_release_v0168/VRN2_Release_v0168.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0160.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0160.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0159.zip " + r168["runtime"]["zip_sha256"]
assert rt["retained_members"] == 198 and rt["new_members"] == ["VRN2_Workbench_v0105.py", "VRN2_ConsensusJoin_v0106.py"]
old = {c["path"]: c["sha256"] for c in r168["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0170.py", "VRN2_Runtime_v0160.zip", "VRN2_Runtime_v0160.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0170.py", "VRN2_Runtime_v0160.zip", "VRN2_Runtime_v0160.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0168 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0170 — VRN-2 closeout package (2026-11-02 · Workbench v0105 U/I · ConsensusJoin v0106 gate-closed snapshot backfill)\n\n"
  "Entry: python ActivateVRN-2_v0170.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0126.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0118.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0160.zip = v0159 (198 members byte-identical) + VRN2_Workbench_v0105 + VRN2_ConsensusJoin_v0106.\n\n"
  "v0170 (operator 2026-11-02: consensus columns + Workbench U/I):\n"
  " - VRN2_Workbench_v0105 — dynamic-prior thin tail (chains the newest lower version found next to it: v0104 on the desktop, v0102 in this runtime);\n"
  "   the prior renders first, v0105 only post-processes the page: compact-panel CSS override (largest panel font 17px < header 20px · white text on\n"
  "   solid badge backgrounds · auto table column widths · sticky headers) + a per-receipt red/yellow/green verification-lamp panel + a consensus panel\n"
  "   (FactSet × Yahoo target medians; snapshot rounds carry a red ASOF badge).\n"
  " - VRN2_ConsensusJoin_v0106 — when the operator's consent gate is closed and the engine pass is DENIED with nothing fetched, the newest on-disk\n"
  "   consensus snapshot (consensus/factset_yfinance_consensus_matrix.csv) fills per_code so the Combined consensus columns are populated offline;\n"
  "   the receipt records snapshot_reused{asof/source/codes}. A compliance DENY is never backfilled; VIA_VRN2_NO_SNAPSHOT=1 turns it off. Nothing in\n"
  "   this package ever sets VIA_NET_CONSENT / VIA_SCRAPE_CONSENT (operator-only); an open-gate round still fetches fresh data and overwrites the snapshot.\n"
  "v0168: manager v0259 transposed-table re-check. v0166: manager v0258 table repair. v0164: TARGET_PRICE(ADJ) sync. v0163: no MOPS.\n"
  "Launcher number v0169 is skipped (release folder v0169 only replaced RoundAll; there is no launcher v0169).\n"
  "Verification: see VRN2_Verification_v0170.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0170.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0170", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0170.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0170/" + n, date_time=(2026, 11, 2, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0126.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0170"' in ra and 'VERSION = "v0126"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170"' in ra
(rel / "VRN2_RoundAll_v0126.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0169'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170'")
rep("$F = 'VRN2_RoundAll_v0125.py'", "$F = 'VRN2_RoundAll_v0126.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0117", "Handle-All v0118", ha.count("Handle-All v0117"))
rep("$Mode = ($last -ge 168 -and $haveOut) ? 'repair' : 'full'", "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'")
rep("(上一輪輸出冊是啟動器 v0168 以前做的 · 管理器 v0259 要重做輸出冊:補回華南 6143 這種轉置表 · 原文有、以前漏掉的年度表)",
    "(上一輪輸出冊是啟動器 v0170 以前做的 → 整輪:Workbench v0105 U/I + 共識欄快照補位要在新啟動器輪跑)")
rep("(輸出冊是啟動器 v0168 做的 → 不整輪)", "(輸出冊是啟動器 v0170 做的 → 不整輪)")
rep("⑥f 共識會被 DENY(Combined 共識欄留空 · 收尾頁列「人工」)", "⑥f 共識會被 DENY(碟上有共識快照 → ConsensusJoin v0106 用 ASOF 快照補位 Combined 共識欄 · 收尾頁列「提醒」;沒有快照 → 留空 · 列「人工」)")
rep("ConsensusJoin v0105(TARGET_PRICE(ADJ) 同步還原 · TWSE / TPEX 格式合併)", "ConsensusJoin v0106(閘未開 DENY → 碟上快照補位 ASOF 標示 · v0105 同步還原 · TWSE / TPEX 格式合併)")
rep("ConsensusJoin v0104 + 引擎 v0122", "ConsensusJoin v0106 + 引擎 v0122")
rep("管理器 v0259(轉置表再驗 · v0258 表格修補) · ", "管理器 v0259 · Workbench v0105(緊湊 / 白字 / 欄寬自動 / 資料驗證燈 / 共識面板) · ")
rep("閘關:現有共識不動", "閘關:碟上有快照 → ConsensusJoin v0106 補位 Combined 共識欄(ASOF 標示) · 沒有 → 現有共識不動")
rep("· repair 不重抓 ⑥f(現有共識不動)· 整輪的 ⑥f 會被 DENY · 收尾頁列「人工」",
    "· 不重抓 ⑥f;被 DENY 的輪次碟上有共識快照 → ConsensusJoin v0106 用 ASOF 快照補位 Combined 共識欄(收尾頁列「提醒」)· 沒有快照 → 留空(列「人工」)")
rep("v0168", "v0170", ha.count("v0168"))
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if re.search(r"Handle-All v0117|v0125\.py|v0168", l) and not l.lstrip().startswith("#")]
assert re.search(r"\$col = @\{[^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0169", "vrn2_release_v0170"), ("VRN2_HandleAll_v0117.md", "VRN2_HandleAll_v0118.md"), ("Handle-All v0117 SHA-256 OK", "Handle-All v0118 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0118_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170/VRN2_HandleAll_v0118_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0118(2026-11-02 · 套件 v0170:Workbench v0105 U/I + 共識欄快照補位 · RoundAll v0126)

操作員 2026-11-02:「開閘共識欄 · 要有共識資料 · Workbench 面板緊湊 / 字體比頁首略小 / 有底色的字白色 / 矩陣欄寬自動 / 紅黃綠資料驗證燈」。

| 項目 | 現在 |
|---|---|
| 共識欄 | 同意閘未開的輪次,ConsensusJoin v0106 用碟上最新共識快照(引擎上次成功的矩陣)補位 Combined 共識欄,收據與 Workbench 都標 **ASOF 快照日**(不冒充本輪)· 開閘後 repair 照舊重抓並蓋掉快照 · **同意閘仍只由操作員設** |
| Workbench | v0105(動態前版尾 · 桌機接 v0104):面板緊湊 · 面板最大字 17px(頁首 20px)· 有底色徽章白字 · 矩陣欄寬自動 + 表頭 sticky ·「資料驗證狀況」紅黃綠燈面板(逐收據)·「共識資料」面板(兩家中位數矩陣)|
| 收尾頁 | ⑥f「快照補位」列 → **提醒**(不是人工 / VRN-2)· 沒快照可補照舊:「同意閘未開」→ 人工(附兩種視窗的設法)|
| 套件 | `vrn2_release_v0170/VRN2_Closeout_v0170.zip`(SHA-256 `%s` · 啟動器 v0170 · runtime v0160 = v0159 + 2 個新模組 · 跳過 v0169 啟動器號)|
| 一支 Python | `VRN2_RoundAll_v0126.py`(SHA-256 `%s` · 自測 93 項 · ⑤ 新步 consensus_snapshot)|
| 自動選模式 | 收據是 v0170 以前 → **整輪**(新啟動器 · 約 40 分鐘);已是 v0170 → repair(幾分鐘)|

## PowerShell 7 視窗(%d 字元)——你現在用的視窗

要最新共識才需要先貼這一行(同意閘 · 操作員決定;不貼也會用碟上快照補位):

```powershell
$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'
```

再貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0118 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0126 `%s`)。

## cmd 視窗(%d 字元)

```bat
set VIA_NET_CONSENT=YES
set VIA_SCRAPE_CONSENT=YES
%s
```

`set "X=Y"` 是 cmd 的寫法,在 PowerShell 視窗貼不會生效 · PowerShell 要用 `$env:X = 'Y'`。

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0126.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0126.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0118.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0126.py(套件 v0170 · 共識欄快照補位 · Workbench v0105)

`VRN2_RoundAll_v0126.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0125 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0170/VRN2_Closeout_v0170.zip`(SHA-256 已釘入本檔)· 啟動器 v0170 · runtime v0160 = v0159 + Workbench v0105 + ConsensusJoin v0106 |
| ⑤ 自動修 | 新步 consensus_snapshot:收據是「同意閘未開 DENY · per_code 空」、閘仍關、碟上有共識快照 → 跑 ConsensusJoin v0106(快照補位 · 不連外 · 不代設閘)→ 重組 Combined → 增量庫 / Workbench 跟著 |
| 負責方 | ⑥f 列 detail 帶「快照補位」→ 提醒(Combined 已補 · ASOF 寫實 · 要最新:開閘再 repair)· 比「同意閘未開 → 人工」優先 |
| 自測 | 93 項(v0125 的 91 項 + 90 快照負責方 + 91 快照計畫)|
""" % ra_sha[:12]
(rel / "VRN2_RoundAll_v0126.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0170 (launcher v0170 · runtime v0160) + VRN2_RoundAll_v0126 + VRN2_HandleAll_v0118", "date": "2026-11-02",
        "trigger": "操作員 2026-11-02:「開閘共識欄 · 要有共識資料 · Workbench 面板緊湊 / 字體比頁首略小 / 有底色的字白色 / 矩陣欄寬自動 / 紅黃綠資料驗證燈 · 授權自行完成 VRN-2 收尾」",
        "consent_gate": "unchanged and operator-only: nothing in this release sets VIA_NET_CONSENT / VIA_SCRAPE_CONSENT; the snapshot backfill only reuses data already on disk and labels it ASOF",
        "fixes": {"Workbench_v0105": "dynamic-prior thin tail (desktop chains its local v0104, this runtime chains v0102; prior renders, v0105 post-processes): compact-panel CSS override · largest panel font 17px < header 20px · white text on solid badges · auto table column widths + sticky headers · per-receipt red/yellow/green verification-lamp panel · consensus panel with ASOF badge",
                  "ConsensusJoin_v0106": "gate-closed DENY with empty per_code → fill from the newest on-disk engine matrix (consensus/factset_yfinance_consensus_matrix.csv) · receipt snapshot_reused{asof/source/codes} · why starts with 快照補位(ASOF …) · compliance DENY never backfilled · VIA_VRN2_NO_SNAPSHOT=1 off switch · open-gate rounds fetch fresh and overwrite",
                  "RoundAll_v0126": "plan step consensus_snapshot (gate closed · snapshot on disk · not planned when the gate is open or another consensus step is planned) → Combined rebuild follows · closeout owner: ⑥f 快照補位 → 提醒 (before the 同意閘未開 → 人工 rule)",
                  "HandleAll_v0118": "points at v0170 · the gate-closed full-run prompt now says the snapshot backfill will fill the Combined consensus columns (ASOF-labelled) · still never sets the gate"},
        "package": {"name": "VRN2_Closeout_v0170.zip", "sha256": want, "release_folder": "vrn2_release_v0170", "changed": True,
                    "launcher": "ActivateVRN-2_v0170.py", "launcher_numbering": "v0169 skipped (release v0169 was RoundAll-only)"},
        "runtime": {"name": "VRN2_Runtime_v0160.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 198, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0125.py", "sha256": hashlib.sha256((PREV / "VRN2_RoundAll_v0125.py").read_bytes()).hexdigest(), "status": "superseded 2026-11-02; file kept in vrn2_release_v0169"}],
        "roundall": {"name": "VRN2_RoundAll_v0126.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0126.md"},
        "handleall": {"name": "VRN2_HandleAll_v0118.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0118_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "results": {"status": "see VRN2_Verification_v0170.md"}}
(rel / "VRN2_Release_v0170.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
