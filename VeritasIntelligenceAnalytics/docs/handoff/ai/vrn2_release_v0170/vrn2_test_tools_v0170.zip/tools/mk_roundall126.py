"""VRN2_RoundAll_v0126.py = v0125(倉裡 vrn2_release_v0169)+ 套件 v0170(啟動器 v0170 · runtime v0160 = v0159 + Workbench v0105 + ConsensusJoin v0106)
+ ⑤ 自動修新步 consensus_snapshot(同意閘未開 DENY + 碟上有共識快照 → ConsensusJoin v0106 快照補位 → 重組 Combined)
+ 收尾頁負責方:⑥f detail 帶「快照補位」→ 提醒(Combined 已補 · 要最新:開閘再 repair)。
操作員 2026-11-02:「開閘共識欄 … 要有共識資料 … Workbench LAYOUT 緊湊 / 白字 / 欄寬自動 / 紅黃綠資料驗證燈」。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v170")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0169/VRN2_RoundAll_v0125.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0125')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0125 — ', '"""VRN2_RoundAll v0126 — ', 1)
at = doc.index("v0125(")
doc = doc[:at] + '''v0126(操作員 2026-11-02:「開閘共識欄 · 要有共識資料 · Workbench 面板緊湊 / 字體比頁首略小 / 有底色的字白色 / 矩陣欄寬自動 / 紅黃綠資料驗證燈」):
  · 同意閘(VIA_NET_CONSENT / VIA_SCRAPE_CONSENT)仍只由操作員設(VRN-2 不代設 · 不繞道);閘關的輪次 Combined 共識欄以前整批空白。
  · 套件 v0170(啟動器 v0170 · runtime v0160 = v0159 的 198 個成員不動 + VRN2_ConsensusJoin_v0106 + VRN2_Workbench_v0105):
    ConsensusJoin v0106 在「閘未開 DENY 且 per_code 空」時用碟上最新共識快照(consensus/factset_yfinance_consensus_matrix.csv · 引擎上次成功落盤)
    補位 per_code,收據寫 snapshot_reused{asof · source · codes},why 開頭就是「快照補位(ASOF <日> · n 檔)」;合規 DENY(VCGC 判定)不補位。
    Workbench v0105 = 動態前版薄尾(桌機接 v0104 · 本倉接 v0102):CSS 蓋版(面板緊湊 · 面板最大字 17px < 頁首 20px · 有底色徽章白字 ·
    矩陣欄寬自動 + 表頭 sticky)+「資料驗證狀況」紅黃綠燈面板(逐收據)+「共識資料」面板(兩家中位數矩陣 · 快照輪次 ASOF 紅底白字)。
  · ⑤ 自動修新步 consensus_snapshot:收據 net_deny.gate_closed、per_code 空、閘還是關的、碟上有快照 → 跑 ConsensusJoin v0106(引擎照 DENY ·
    之後快照補位 · 不連外)→ 重組 Combined → 增量庫 / Workbench 跟著。閘開著走原本的 consensus_refresh(真重抓),互不重疊。
  · 收尾頁:⑥f detail 帶「快照補位」→ 提醒(Combined 已用 ASOF 快照補位 · 要最新:開閘再 repair);比「同意閘未開 → 人工」優先
    (快照句裡也有「同意閘未開」字樣)。沒快照可補的輪次照 v0125(人工 · 兩種視窗的設法)。
  · 自測 93 項(v0125 的 91 項 + 90 + 91)。共用 MarketFetch 與 VDF 引擎照舊只讀不改。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0125.py", "用法:python VRN2_RoundAll_v0126.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


# ── 套件 v0168 → v0170 · runtime v0159 → v0160(本文整批 · 版號之後)──
b0 = s.index('VERSION = "v0125"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0168", "v0170").replace("VRN2_Runtime_v0159", "VRN2_Runtime_v0160")
s = pre + post
rep('VERSION = "v0125"', 'VERSION = "v0126"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0125.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0125.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0126.py"', n_dl)
rep('"VRN2_RoundAll_v0125.py" in html_', '"VRN2_RoundAll_v0126.py" in html_')
rep("· v0124 起 90 項 · v0125 起 91 項。", "· v0124 起 90 項 · v0125 起 91 項 · v0126 起 93 項。")
# ── SELFTESTS:Workbench v0105 · ConsensusJoin v0106(前版照舊由鏈自測)──
rep('SELFTESTS = (("VRN2_Workbench_v0102.py", 600),', 'SELFTESTS = (("VRN2_Workbench_v0105.py", 600),')
rep('("VRN2_ConsensusJoin_v0105.py", 900)', '("VRN2_ConsensusJoin_v0106.py", 900)', 2)
rep('''and ("VRN2_ConsensusJoin_v0106.py", 900) in SELFTESTS and ("VRN2_ConsensusJoin_v0104.py", 900) not in SELFTESTS''',
    '''and ("VRN2_ConsensusJoin_v0106.py", 900) in SELFTESTS and ("VRN2_ConsensusJoin_v0105.py", 900) not in SELFTESTS and ("VRN2_Workbench_v0105.py", 600) in SELFTESTS''')
# ── ⑤ 計畫:consensus_snapshot(閘未開 DENY · 碟上有快照 · 不連外)──
rep('''def plan_fixes(root: Path, receipt: dict, fetch_py, args, market_tool: str = "") -> list:''',
    '''def consensus_snapshot_on_disk(v2) -> str:
    """v0126 碟上最新共識快照的 ASOF(consensus/factset_yfinance_consensus_matrix.csv 列上最大台北日 · 只讀);沒有 / 讀不出列 → ""。"""
    import csv as _csv
    p = Path(v2) / "consensus" / "factset_yfinance_consensus_matrix.csv"
    if not p.is_file():
        return ""
    days = []
    try:
        with p.open("r", encoding="utf-8-sig", newline="") as fh:
            for r in _csv.DictReader(fh):
                if not str(r.get("code") or "").strip():
                    continue
                m = re.match(r"(\\d{4})-(\\d{2})-(\\d{2})[T ](\\d{2})", str(r.get("fetched_at_utc") or ""))
                if m:
                    tw = _dt.datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))) + _dt.timedelta(hours=8)
                    days.append(tw.date().isoformat())
                else:
                    days.append("")
    except (OSError, _csv.Error, UnicodeError):
        return ""
    return (max(days) or _dt.date.fromtimestamp(p.stat().st_mtime).isoformat()) if days else ""


def plan_fixes(root: Path, receipt: dict, fetch_py, args, market_tool: str = "") -> list:''')
rep('''        plan.append(("consensus", "⑥f 共識閘只因 404 / 一時抓不到(%s) → 用 ConsensusJoin v0103 重跑(沿用今天抓到的 · 重試 · 暫缺不納入閘)" % ",".join(sorted(q404 | qtr))[:40]))
    planned = {p[0] for p in plan}''',
    '''        plan.append(("consensus", "⑥f 共識閘只因 404 / 一時抓不到(%s) → 用 ConsensusJoin v0103 重跑(沿用今天抓到的 · 重試 · 暫缺不納入閘)" % ",".join(sorted(q404 | qtr))[:40]))
    snap_asof = consensus_snapshot_on_disk(v2)                                 # v0126 閘未開 DENY → 快照補位(不連外 · 閘仍由操作員決定)
    if (not any(k in ("consensus", "consensus_refresh") for k, _ in plan) and (cons_now.get("net_deny") or {}).get("gate_closed")
            and not cons_now.get("per_code") and not net_gate_open() and snap_asof
            and os.environ.get("VIA_VRN2_NO_CONSENSUS") != "1" and os.environ.get("VIA_VRN2_NO_SNAPSHOT") != "1"):
        plan.append(("consensus_snapshot", "⑥f 同意閘未開 DENY · 碟上有 ASOF %s 共識快照 → ConsensusJoin v0106 快照補位(不連外 · 閘仍由操作員決定)→ 重組 Combined" % snap_asof))
    planned = {p[0] for p in plan}''')
rep('planned & {"market", "market_fill", "consensus", "consensus_refresh"}', 'planned & {"market", "market_fill", "consensus", "consensus_refresh", "consensus_snapshot"}')
# ── ⑤ 執行:consensus_snapshot 跑 ConsensusJoin 最新版(v0106 · 引擎照 DENY · 之後快照補位)──
rep('''        elif key == "history":''',
    '''        elif key == "consensus_snapshot":                                     # v0126 閘未開 → 快照補位(不連外 · 不代設閘)
            put, refused = place_consensus(state.get("pkg"), root)
            cj = _latest_in(rt, "VRN2_ConsensusJoin_v[0-9][0-9][0-9][0-9].py")
            rc, lines = run_stream([vpy, "-X", "utf8", str(cj), "run", "--v2", str(v2), "--root", str(root)], cwd=rt, env=dict(env, VIA_VRN2_NO_CONSENSUS_REFRESH="1"), timeout=1200, prefix="    [⑥f] ")
            lamp, detail = _cli_lamp(lines)
            snapline = next((l.split("[YELLOW]", 1)[1].strip() for l in lines if "快照補位" in l and "[YELLOW]" in l), "")
            if snapline:
                lamp, detail = "YELLOW", snapline[:240]
            if put or refused:
                detail = ("%s%s · %s" % (("補放 " + "、".join(put)) if put else "", (" · 不覆寫 " + "、".join(refused)) if refused else "", detail)).strip(" ·")
            step_updates["⑥f"] = (lamp if lamp != "RED" else "YELLOW", detail)
        elif key == "history":''')
# ── 收尾頁負責方:快照補位 → 提醒(比「同意閘未開 → 人工」優先)──
rep('''    if "⑥f" in step and "同意閘未開" in detail:''',
    '''    if "⑥f" in step and "快照補位" in detail:                               # v0126 Combined 已用碟上快照補位(快照句裡也有「同意閘未開」→ 先比對這條)
        return "提醒", ("Combined 共識欄已用碟上快照補位(ASOF 見列內 · 非本輪抓)· 要最新共識:操作員開閘"
                        "($env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES')再跑一次(auto = repair)會重抓並蓋掉快照 · VRN-2 不代設")
    if "⑥f" in step and "同意閘未開" in detail:''')
# ── 自測 90 / 91 ──
rep('''        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''',
    '''        r90 = {"lamp": "YELLOW", "step": "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)",
               "detail": "共識 YELLOW:快照補位:同意閘未開(操作員決定 · VRN-2 不代設)· 引擎這輪 DENY 沒有新抓 → 先用碟上 ASOF 2026-11-01 快照補位 Combined 共識欄(43 檔)· Combined GREEN:52 列"}
        o90 = owner_of(r90, {})
        chk("90 v0126:⑥f「快照補位」列 → 提醒(Combined 已補 · ASOF 寫實 · 開閘 repair 重抓)· 比「同意閘未開 → 人工」優先 · 根同 ⑥f 共識",
            o90[0] == "提醒" and "快照補位" in o90[1] and "repair" in o90[1] and closeout_root(dict(r90, owner="提醒"), {}) == "⑥f 共識")
        envsave91 = {k: os.environ.pop(k) for k in ("VIA_NET_CONSENT", "VIA_SCRAPE_CONSENT") if k in os.environ}   # 快照計畫只在閘關時排;自測不代設、只暫存還原
        with tempfile.TemporaryDirectory() as td91:
            v91 = Path(td91) / "VIA_Reports" / "vrn2"
            (v91 / "consensus").mkdir(parents=True)
            (v91 / "output").mkdir(parents=True)
            (v91 / "output" / "VRN2_BasicInfo_latest.json").write_text("{}", encoding="utf-8")
            (v91 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps(
                {"lamp": "YELLOW", "net_deny": {"gate_closed": True}, "per_code": {}, "codes": ["1101"]}, ensure_ascii=False), encoding="utf-8")
            A91 = type("A91", (), {"integrate": "skip"})
            p91a = [k for k, _ in plan_fixes(Path(td91), {"market": {}, "consensus": {}}, "", A91(), "")]
            (v91 / "consensus" / "factset_yfinance_consensus_matrix.csv").write_text(
                "code,fetched_at_utc,target_median\\n1101,2026-11-01T01:19:00+00:00,120.0\\n", encoding="utf-8")
            asof91 = consensus_snapshot_on_disk(v91)
            plan91 = plan_fixes(Path(td91), {"market": {}, "consensus": {}}, "", A91(), "")
            p91 = [k for k, _ in plan91]
            d91 = next((d for k, d in plan91 if k == "consensus_snapshot"), "")
            os.environ["VIA_VRN2_NO_SNAPSHOT"] = "1"
            try:
                p91c = [k for k, _ in plan_fixes(Path(td91), {"market": {}, "consensus": {}}, "", A91(), "")]
            finally:
                os.environ.pop("VIA_VRN2_NO_SNAPSHOT", None)
        os.environ.update(envsave91)
        chk("91 v0126:⑤ 計畫 · 閘未開 DENY + 碟上快照(ASOF 2026-11-01 · UTC+8)→ consensus_snapshot(說明帶 ASOF)→ 重組 Combined 跟著 · 沒快照 / 關掉 → 不排",
            asof91 == "2026-11-01" and "consensus_snapshot" in p91 and "ASOF 2026-11-01" in d91 and p91.index("consensus_snapshot") < p91.index("combined")
            and "consensus_snapshot" not in p91a and "consensus_snapshot" not in p91c)
        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''')
out = W / "new/VRN2_RoundAll_v0126.py"
out.write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,30}VRN2_Runtime_v0159.{0,30}|.{0,30}Closeout_v0168.{0,30}", s[s.index('VERSION = "v0126"'):])]
print("RoundAll v0126 lines", s.count("\n"), "· stale refs:", len(left), left[:3])
