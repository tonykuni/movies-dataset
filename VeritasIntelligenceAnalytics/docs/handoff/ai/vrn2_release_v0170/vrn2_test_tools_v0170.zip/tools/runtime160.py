"""runtime v0160 = runtime v0159(198 個成員逐位元組不動)+ VRN2_Workbench_v0105(動態前版尾 U/I)+ VRN2_ConsensusJoin_v0106(閘未開快照補位)· 套件夾 pkg170(其他成員從 pkg168 原樣複製)。"""
import hashlib, json, shutil, zipfile
from pathlib import Path
old, new, out = Path("/home/user/vrn2_work/v168/pkg168"), Path("/home/user/vrn2_work/v170/new"), Path("/home/user/vrn2_work/v170/pkg170")
out.mkdir(parents=True, exist_ok=True)
om = json.loads((old / "VRN2_Runtime_v0159.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
assert hashlib.sha256((old / "VRN2_Runtime_v0159.zip").read_bytes()).hexdigest() == om["zip_sha256"]
with zipfile.ZipFile(old / "VRN2_Runtime_v0159.zip") as z:
    members = {n: z.read(n) for n in old_names}
for e in om["files"]:
    assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"], e["path"]
assert len(old_names) == 198
new_names = ["VRN2_Workbench_v0105.py", "VRN2_ConsensusJoin_v0106.py"]
for n in new_names:
    assert n not in members, n
    members[n] = (new / n).read_bytes()
assert "VRN2_Workbench_v0102.py" in members and "VRN2_ConsensusJoin_v0105.py" in members
names = sorted(members); zp = out / "VRN2_Runtime_v0160.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 2, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0160", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0159.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names,
       "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0160.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(str(old / n), str(out / n))
print("runtime v0160", len(names), man["zip_sha256"][:12], "· pkg170", sorted(p.name for p in out.iterdir()))
