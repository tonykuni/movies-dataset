"""ActivateVRN-2_v0170.py = v0168 + Workbench v0105(動態前版尾 · 緊湊/白字/欄寬自動/資料驗證燈/共識面板)+ ConsensusJoin v0106(閘未開 DENY 用碟上快照補位 Combined 共識欄)。
runtime v0160 = runtime v0159(198 個成員一字不改)+ VRN2_Workbench_v0105 + VRN2_ConsensusJoin_v0106。
啟動器版號跳過 v0169(v0169 是只換 RoundAll 的發行夾,沒有 v0169 啟動器)。操作員 2026-11-02:「開閘共識欄 · 要有共識資料 · Workbench U/I 需求」。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v168/pkg168/ActivateVRN-2_v0168.py")
OUT = Path("/home/user/vrn2_work/v170/pkg170/ActivateVRN-2_v0170.py")
OUT.parent.mkdir(parents=True, exist_ok=True)
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0168: v0166 entry + manager VRN_SystemManager_v0259', '''"""VRN-2 v0170: v0168 entry + Workbench v0105 + ConsensusJoin v0106 (operator 2026-11-02: "開閘共識欄 · 要有共識資料 · Workbench 面板緊湊 / 字體比頁首略小 / 有底色的字白色 / 矩陣欄寬自動 / 紅黃綠資料驗證燈").
 - VRN2_Workbench_v0105 (dynamic-prior thin tail: on the desktop it chains the locally newer v0104, in this repo's runtime it chains v0102; the prior
   renders first and v0105 only post-processes the written page): a CSS override block (compact panels · largest panel font 17px < header h1 20px ·
   solid-background badges in white text · auto table column widths with sticky headers) plus two self-contained panels injected at the top of <main> —
   "資料驗證狀況" (one red / yellow / green / gray lamp per receipt: verbatim verify · independent verify · idempotence · completion · market 6e ·
   consensus 6f · history align 13b · incremental store 13 · Combined consensus columns) and "共識資料" (FactSet × Yahoo target-median matrix;
   snapshot rounds show a red ASOF badge so reused data is never presented as fresh).
 - VRN2_ConsensusJoin_v0106 (thin tail over v0105 · v0105 ~ v0100 unchanged): when the consent gate is CLOSED (net_deny.gate_closed) and the engine
   pass produced nothing (per_code empty), reuse the newest on-disk consensus snapshot consensus/factset_yfinance_consensus_matrix.csv (the engine's
   last successful matrix) to fill per_code, so the Combined consensus columns are populated offline; the receipt records snapshot_reused{asof ·
   source · codes} and the why starts with 快照補位(ASOF …). A compliance DENY (VCGC's call) is never backfilled; VIA_VRN2_NO_SNAPSHOT=1 turns it off.
   The gate itself stays operator-only: nothing here sets VIA_NET_CONSENT / VIA_SCRAPE_CONSENT, and an open-gate round still fetches fresh data.
 Runtime v0160 = runtime v0159 (198 members byte-identical) + VRN2_Workbench_v0105 + VRN2_ConsensusJoin_v0106.
 Receipt VRN2_Closeout_v0170.json. Launcher number v0169 is skipped (release folder v0169 only replaced RoundAll; there is no launcher v0169).

VRN-2 v0168: v0166 entry + manager VRN_SystemManager_v0259''')
rep('VERSION = "ActivateVRN-2 v0168"', 'VERSION = "ActivateVRN-2 v0170"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0159.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0160.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0159.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0160.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0168.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0170.json"')
rep('WORKBENCH = "VRN2_Workbench_v0102.py"', 'WORKBENCH = "VRN2_Workbench_v0105.py"   # v0170: dynamic-prior tail (desktop chains v0104 · repo runtime chains v0102) · compact CSS · verification lamps · consensus panel')
rep('CONSENSUS_JOIN_ACTIVE = "VRN2_ConsensusJoin_v0105.py"   # v0164:', 'CONSENSUS_JOIN_ACTIVE = "VRN2_ConsensusJoin_v0106.py"   # v0170: snapshot backfill when the consent gate is closed (ASOF-labelled · operator opens the gate for fresh data) · v0164:')
rep('CONSENSUS_JOIN_ACTIVE, CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py"', 'CONSENSUS_JOIN_ACTIVE, "VRN2_ConsensusJoin_v0105.py", CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py"', 2)
rep('"refresh", "engine_no_output") if k in ran}', '"refresh", "engine_no_output", "snapshot_reused", "snapshot_note") if k in ran}')
rep('''    m259 = selftest_source("VRN_SystemManager_v0259.py").read_text(encoding="utf-8")''',
    '''    wb105 = selftest_source("VRN2_Workbench_v0105.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0105"' in wb105 and "def _prior_path(" in wb105 and "def augment(" in wb105 and "資料驗證狀況" in wb105 and "wb105-css" in wb105
    assert WORKBENCH == "VRN2_Workbench_v0105.py"
    cj106 = selftest_source("VRN2_ConsensusJoin_v0106.py").read_text(encoding="utf-8")
    assert 'VERSION = "v0106"' in cj106 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0105.py"' in cj106 and "def snapshot_fill(" in cj106 and "VIA_VRN2_NO_SNAPSHOT" in cj106
    assert CONSENSUS_JOIN_ACTIVE == "VRN2_ConsensusJoin_v0106.py"
    m259 = selftest_source("VRN_SystemManager_v0259.py").read_text(encoding="utf-8")''')
rep('''    print("[PASS] v0168: manager v0259 is the active manager''', '''    print("[PASS] v0170: Workbench v0105 (dynamic-prior tail · compact CSS · verification lamps · consensus panel) is the active Workbench; ConsensusJoin v0106 (gate-closed snapshot backfill · ASOF-labelled · never sets the consent gate) is the active join")
    print("[PASS] v0168: manager v0259 is the active manager''')
rep('        assert cj.VERSION == "v0105" and cj.PRIOR.VERSION == "v0104" and cj.V0100.join is cj.join and cj.PRIOR.join is cj.join and cj.V0100.run is cj.PRIOR.run',
    '''        assert cj.VERSION == "v0106" and cj.PRIOR.VERSION == "v0105" and cj.PRIOR.PRIOR.VERSION == "v0104"
        assert cj.V0100.join is cj.join and cj.PRIOR.join is cj.join and cj.V0100.run is cj.run and cj.PRIOR.run is cj.run   # v0170: v0106 rewires run (snapshot backfill) and join (ASOF note)
        snap170 = cj.snapshot_fill({"net_deny": {"gate_closed": True}, "per_code": {}, "codes": ["9999"]}, root164 / "nowhere")
        assert snap170.get("snapshot_reused") is None and not snap170.get("per_code")                                        # no snapshot on disk → honest no-op''')
rep('return lamp, detail + " · launcher v0168"', 'return lamp, detail + " · launcher v0170"')
rep('note="VRN-2 private runtime; exact ship v0159 (launcher v0168 · no MOPS · store MOPS rows purged); manager v0259 transposed re-check (over v0258 table repair · v0257 · v0255);',
    'note="VRN-2 private runtime; exact ship v0160 (launcher v0170 · Workbench v0105 · ConsensusJoin v0106 snapshot backfill · no MOPS); manager v0259 transposed re-check (over v0258 table repair · v0257 · v0255);')
rep('print("NEXT: [%s] VRN-2 v0168 · rc %s', 'print("NEXT: [%s] VRN-2 v0170 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0170", len(s.splitlines()), "lines")
