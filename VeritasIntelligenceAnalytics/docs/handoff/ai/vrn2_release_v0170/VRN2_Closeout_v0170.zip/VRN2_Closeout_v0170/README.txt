VRN2_Closeout_v0170 — VRN-2 closeout package (2026-11-02 · Workbench v0105 U/I · ConsensusJoin v0106 gate-closed snapshot backfill)

Entry: python ActivateVRN-2_v0170.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0126.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0118.md (same release folder).
Runtime: VRN2_Runtime_v0160.zip = v0159 (198 members byte-identical) + VRN2_Workbench_v0105 + VRN2_ConsensusJoin_v0106.

v0170 (operator 2026-11-02: consensus columns + Workbench U/I):
 - VRN2_Workbench_v0105 — dynamic-prior thin tail (chains the newest lower version found next to it: v0104 on the desktop, v0102 in this runtime);
   the prior renders first, v0105 only post-processes the page: compact-panel CSS override (largest panel font 17px < header 20px · white text on
   solid badge backgrounds · auto table column widths · sticky headers) + a per-receipt red/yellow/green verification-lamp panel + a consensus panel
   (FactSet × Yahoo target medians; snapshot rounds carry a red ASOF badge).
 - VRN2_ConsensusJoin_v0106 — when the operator's consent gate is closed and the engine pass is DENIED with nothing fetched, the newest on-disk
   consensus snapshot (consensus/factset_yfinance_consensus_matrix.csv) fills per_code so the Combined consensus columns are populated offline;
   the receipt records snapshot_reused{asof/source/codes}. A compliance DENY is never backfilled; VIA_VRN2_NO_SNAPSHOT=1 turns it off. Nothing in
   this package ever sets VIA_NET_CONSENT / VIA_SCRAPE_CONSENT (operator-only); an open-gate round still fetches fresh data and overwrites the snapshot.
v0168: manager v0259 transposed-table re-check. v0166: manager v0258 table repair. v0164: TARGET_PRICE(ADJ) sync. v0163: no MOPS.
Launcher number v0169 is skipped (release folder v0169 only replaced RoundAll; there is no launcher v0169).
Verification: see VRN2_Verification_v0170.md. Hashes: PACKAGE_SHA256.json.
