"""v0173(冪等):套件 v0172 不動(雜湊照釘)→ RoundAll v0129(⑬b 只在輸入變了才重跑)→ Handle-All v0121(指到 v0129)
→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0173)。vrn2_release_v0172 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v173"); rel = W / "release173"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v172/release172")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0172/VRN2_Release_v0172.json").read_text(encoding="utf-8"))
want = r170["package"]["sha256"]
ra = (W / "new/VRN2_RoundAll_v0129.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0172"' in ra and 'VERSION = "v0129"' in ra
assert 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172"' in ra            # 套件 zip 照舊從 v0170 發行夾取
(rel / "VRN2_RoundAll_v0129.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0173'")
rep("$F = 'VRN2_RoundAll_v0128.py'", "$F = 'VRN2_RoundAll_v0129.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0120", "Handle-All v0121", ha.count("Handle-All v0120"))
rep("repair = '取套件 v0172 → ⑤ 自動修(VRN P0 三項:", "repair = '取套件 v0172 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;VRN P0 三項:")
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if re.search(r"Handle-All v0120|v0128\.py|release_v0172'", l) and not l.lstrip().startswith("#")]
assert re.search(r"\$col = @\{[^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0172", "vrn2_release_v0173"), ("VRN2_HandleAll_v0120.md", "VRN2_HandleAll_v0121.md"), ("Handle-All v0120 SHA-256 OK", "Handle-All v0121 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0121_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0173/VRN2_HandleAll_v0121_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0121(2026-11-03 · RoundAll v0129:⑬b 只在輸入變了才重跑 · 套件 v0172 不動)

桌機 2026-11-03 05:54(Handle-All v0120 · RoundAll v0128 · repair 55 秒)**VRN P0 三項都上桌**:⑬b「補放 HistoryAlign v0103 · Parquet 寫成」·
Combined v0107 52 列(FactSet 中位數 49 · Yahoo 48)· 增量庫加 UPSIDE_ADJ(內容有變的 42 列追加 · 舊列保留)· Workbench v0107(前版 v0104)·
收尾 **REVIEW(VRN-2 0 · VCGC 0 · 人工 1 · 資料源 3)**;07:59 再跑:Combined 不再排 · 增量庫追加 0(冪等)。

剩一個重工(本輪修):每次 repair 都排「市場資料比歷史對齊新 / 歷史對齊沒跑 → 重跑 ⑬b」,其實兩者都不是 —— 收據的歷史對齊燈 GRAY「無歷史 47」是真的沒有歷史財報
(不用 MOPS 之後)→ 舊條件只看燈 → ⑬b + 增量庫 + Workbench 每次白做一次。**RoundAll v0129** 只在輸入真的變了才重跑,計畫照實寫原因;都齊了 → 「沒有要修的」。

| 項目 | 現在 |
|---|---|
| 套件 | 照舊 `vrn2_release_v0172/VRN2_Closeout_v0172.zip`(SHA-256 `%s`)|
| 一支 Python | `VRN2_RoundAll_v0129.py`(SHA-256 `%s` · 自測 99 項)|
| 自動選模式 | 收據 ≥ v0170 → **repair**(都齊了幾秒鐘 · 有變才修)|

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0121 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0129 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0129.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0129.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0121.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0129.py(套件 v0172 不動 · ⑬b 只在輸入變了才重跑)

`VRN2_RoundAll_v0129.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0128 +:

| 改了什麼 | 說明 |
|---|---|
| ⑤ ⑬b 觸發 | 舊條件「收據歷史對齊燈 GRAY」拿掉(GRAY「無歷史」是真的沒有歷史資料 · 重跑也一樣);改看輸入:這輪會重抓 / 重填市場資料 · 還沒有歷史對齊收據 · 市場資料比它新 · 年度數據比它新 · Parquet 沒寫(v0128)|
| 計畫文字 | 照實寫是哪一個原因(以前固定寫「市場資料比歷史對齊新 / 歷史對齊沒跑」)|
| 效果 | 桌機現況(三項已修、輸入沒變)repair = 「沒有要修的」→ 不再每次重做 ⑬b + 增量庫 + Workbench |
| 自測 | 99 項(v0128 的 98 項 + 97)|

套件 `vrn2_release_v0172/VRN2_Closeout_v0172.zip`(SHA-256 `%s` · 本檔內已釘 · 不動)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0129.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0129 + VRN2_HandleAll_v0121 (package v0172 unchanged)", "date": "2026-11-03",
        "trigger": "桌機 2026-11-03 05:54 / 07:59 Handle-All v0120 主控台貼回(VRN P0 三項上桌 · 收尾 REVIEW · VRN-2 0)· 授權「自動解決 · 完成既有範圍不可擴張」",
        "desktop_0554": {"result": "repair 55 s: step 13b installed HistoryAlign v0103 → Parquet written · Combined rebuilt by ConsensusJoin v0107 (52 rows · FactSet median 49 · Yahoo 48) · store: 42 Combined rows whose content changed (now carrying UPSIDE_ADJ) appended, old rows kept (OutputStore v0101 rule) · Workbench v0107 over the desktop's v0104 · closeout REVIEW: VRN-2 0 · VCGC 0 · 人工 1 · 資料源 3",
                         "rerun_0759": "Combined no longer planned · store appended 0 (idempotent) · but step 13b + store + Workbench re-ran again"},
        "fix": {"RoundAll_v0129": "step 13b is re-run only when its inputs changed (market refetch/refill planned · no HistoryAlign receipt · market json newer · FinancialData newer) or the Parquet was not written; a GRAY '無歷史' receipt with unchanged inputs no longer triggers it · the plan text names the actual reason · selftest 99"},
        "package": {"name": r170["package"]["name"], "sha256": want, "release_folder": "vrn2_release_v0172", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0128.py", "sha256": r170["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0172"}],
        "roundall": {"name": "VRN2_RoundAll_v0129.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0129.md"},
        "handleall": {"name": "VRN2_HandleAll_v0121.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0121_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "RoundAll v0129 · HandleAll v0121 · release v0173 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0173.md"}}
(rel / "VRN2_Release_v0173.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
