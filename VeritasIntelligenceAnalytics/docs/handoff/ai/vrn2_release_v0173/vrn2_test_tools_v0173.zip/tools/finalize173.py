"""v0173 收尾:驗證紀錄(含桌機 05:54 / 07:59 v0128 實錄補記 · 只寫結論與筆數)· 交接 v0174(從 v0173 抄 · 只增)· 放進倉 vrn2_release_v0173 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v173"); rel = W / "release173"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
T = Path("<sbx>")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


R = json.loads((rel / "VRN2_Release_v0173.json").read_text(encoding="utf-8"))
H = R["handleall"]
ra = [l for l in lines(W / "rall129_selftest.log") if re.search(r"^\[FAIL\]|--selftest · ", l)]
assert ra and "99 項 · 不過 0" in ra[-1], ra[-1:]
ps = json.loads((W / "pscheck173.log").read_text())
by = {x["f"]: x for x in ps}
assert all(x["e"] == 0 for x in ps) and by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"] and by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"]
pparse = "pwsh 剖析錯 %s · Handle-All 一行 = 可讀版 True · 開機行 = 可讀版 True" % sorted(x["e"] for x in ps)
rc = [l for l in lines(W / "tiny173.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
plans = {}
for n in ("steady", "fin", "steady2"):
    pl = [l for l in lines(W / ("tiny_%s.log" % n)) if "⑤ 自動修計畫" in l]
    plans[n] = pl[0].split("⑤ 自動修計畫:", 1)[-1] if pl else "(沒有要修的)"
assert "⑬b" not in plans["steady"] and plans["fin"].startswith("年度數據比歷史對齊新 → 重跑 ⑬b") and "⑬b" not in plans["steady2"]
assert "[RED] boot SHA-256 mismatch - not run" in (W / "tiny_tamper.log").read_text(encoding="utf-8")
R["results"] = {"roundall_v0129_selftest": ra[-1:], "pwsh_parse": pparse, "e2e_rc": rc,
                "e2e_plans": {k: v[:240] for k, v in plans.items()},
                "e2e_note": "sandbox steady state = receipt history GRAY with HistoryAlign newer than market / FinancialData → step 13b not planned (v0128 planned it every time) · FinancialData touched → '年度數據比歷史對齊新 → 重跑 ⑬b' · again steady → not planned · the remaining Combined rebuild in the sandbox is sandbox-only (its fetch env lacks requests → no TP-sync evidence; the desktop 07:59 run had no such trigger)",
                "desktop_0554_0759": R["desktop_0554"],
                "not_run": "the desktop itself with v0121 (expected: repair plan empty → '沒有要修的' in seconds) · the operator's own --confirm (H-fd2ea35f)"}
(rel / "VRN2_Release_v0173.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0173 驗證紀錄(2026-11-03 · 桌機 v0128 實錄補記 · RoundAll v0129:⑬b 只在輸入變了才重跑 · Handle-All v0121 · 套件 v0172 不動)

## 1. 桌機 2026-11-03 05:54(Handle-All v0120 · RoundAll v0128 · repair 55 秒)—— VRN P0 三項上桌

| 項目 | 桌機結果 |
|---|---|
| 套件 | v0172 從 GitHub 取下 · SHA-256 `bd952da149bd` · 11 檔逐檔相符 |
| F1 Parquet | ⑬b「補放 VRN2_HistoryAlign_v0103.py · **Parquet 寫成**」(前版 ArrowInvalid 那本)|
| F2 小數欄 | 計畫「Combined 還沒有 UPSIDE_ADJ → ConsensusJoin v0107 重組」→ Combined 52 列 · FactSet 中位數 49 · Yahoo 48 · 欄序正確(含 UPSIDE_ADJ)· 增量庫:內容有變的 42 列追加(帶 UPSIDE_ADJ)、舊列保留(OutputStore v0101 規則 · 追加 = 補缺同一批 42 列,不是重複)|
| F3 合併檢視 | Workbench **v0107(前版 v0104)** 渲染成功 |
| 收尾 | **REVIEW · VRN-2 0 · VCGC 0** · 人工 1(MQ-1560 四點 `--confirm H-fd2ea35f`)· 資料源 3 |
| 07:59 再跑 | Combined 不再排 · 增量庫追加 0(冪等)· 但 ⑬b + 增量庫 + Workbench 又做了一次 → 本輪修 |

## 2. 本輪修:⑬b 不再每次白做

根因:收據的歷史對齊燈 GRAY「無歷史 47」是**真的沒有歷史財報**(不用 MOPS 之後),v0128 以前的觸發條件只看燈是不是 GRAY → 每次 repair 都成立,
計畫還寫成「市場資料比歷史對齊新 / 歷史對齊沒跑」(兩者都不是)。**RoundAll v0129** 只看輸入:這輪會重抓 / 重填市場資料 · 還沒有歷史對齊收據 ·
市場資料比它新 · 年度數據比它新 · Parquet 沒寫(v0128)—— 計畫照實寫是哪一個;都沒有 → 不重跑(收尾頁照舊列灰 · 不是待修)。

## 3. 測試

| 項目 | 結果 |
|---|---|
| RoundAll v0129 自測 | %s |
| PowerShell 剖析 | %s |
| e2e(最短一行 · 沙盒 · 模擬桌機穩態)| %s |
| 穩態 | 計畫:`%s`(沒有 ⑬b)|
| 年度數據變新 | 計畫:`%s` |
| 再穩態 | 計畫:`%s`(沒有 ⑬b)|

沙盒的 Combined 重組是沙盒限定(擷取環境缺 requests → 沒有 TARGET_PRICE(ADJ) 同步還原證據);桌機 07:59 沒有這個觸發。

## 4. 桌機下一步

1. 貼 `vrn2_release_v0173/VRN2_HandleAll_v0121.md` 的最短一行 → 應是「⑤ 自動修 · 沒有要修的」· 收尾 REVIEW(VRN-2 0 · VCGC 0)· 幾秒到一分鐘。
2. MQ-1560 看過原圖:`python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0129.py" --confirm H-fd2ea35f --note "…"`(只有操作員打才算)→ DATA_GAP = VRN 側終點。
3. Graphify:用 `via_graphify_v0101/VIA_Graphify_v0101.md` 的那一行(桌機這次跑的是 v0100 那行 → 4 系統全灰)。
""" % (ra[-1][:120], pparse, " · ".join(rc), plans["steady"][:200], plans["fin"][:200], plans["steady2"][:200])
(rel / "VRN2_Verification_v0173.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0173.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0172 + VRN2_RoundAll_v0128 + VRN2_HandleAll_v0120 · 2026-11-03(")
L[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0172 + VRN2_RoundAll_v0129 + VRN2_HandleAll_v0121 · 2026-11-03(桌機 v0128 實錄:VRN P0 三項上桌 · 收尾 REVIEW:VRN-2 0 · VCGC 0 · ⑬b 不再每次白做)"
src = "\n".join(L)
once("> **本輪(v0172)**",
     "> **本輪(v0173)**:桌機 05:54 Handle-All v0120 / RoundAll v0128 repair 55 秒 —— **VRN P0 三項上桌**(⑬b 補放 HistoryAlign v0103 · Parquet 寫成 · Combined v0107 52 列含 UPSIDE_ADJ · "
     "增量庫內容有變的 42 列追加 · Workbench v0107 over v0104)· 收尾 REVIEW(**VRN-2 0 · VCGC 0** · 人工 1 · 資料源 3);07:59 再跑增量庫追加 0。剩一個重工:收據歷史對齊 GRAY「無歷史」"
     "讓每次 repair 都重跑 ⑬b + 增量庫 + Workbench → **RoundAll v0129** 只看輸入有沒有變(計畫照實寫原因)· **Handle-All v0121** · 套件 v0172 不動。\n"
     "> **本輪(v0172)**")
once("| **VRN2_HandleAll_v0120.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0120** | `vrn2_release_v0172` |",
     "| **VRN2_HandleAll_v0121.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0121** | `vrn2_release_v0173` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0129)|\n"
     "| **VRN2_RoundAll_v0129.py**(發行夾 · 一支入口 · 不在套件內)| **v0129** | `vrn2_release_v0173` | `%s` | **新**(⑬b 只在輸入變了才重跑 · 自測 99 項 · 套件 v0172 照釘)|\n"
     "| **VRN2_HandleAll_v0120.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0120** | `vrn2_release_v0172` |"
     % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12]))
once("| 0 | **(v0172)**",
     "| 0 | **(v0173)** 貼 `vrn2_release_v0173/VRN2_HandleAll_v0121.md` 的最短一行 → 應「⑤ 自動修 · 沒有要修的」· 收尾 REVIEW(VRN-2 0 · VCGC 0)· MQ-1560 看過原圖後操作員自己打 "
     "`python \"%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0129.py\" --confirm H-fd2ea35f --note \"…\"` → DATA_GAP = VRN 側終點 · Graphify 用 v0101 那行 | 貼回 / 人工 |\n"
     "| 0 | **(v0172)**")
once("**v0172(2026-11-03)**:", "**v0173(2026-11-03)**:桌機 v0128 實錄(三項上桌 · VRN-2 0)· RoundAll v0129(⑬b 只在輸入變了才重跑)· Handle-All v0121 · 套件 v0172 不動。\n\n**v0172(2026-11-03)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0173)** **⑤ 觸發只看輸入有沒有變,不看收據燈**:GRAY 可能是「真的沒有資料」(例:不用 MOPS 之後歷史對齊「無歷史」),用燈當觸發會每次 repair 白做一輪;計畫文字要寫實際原因。"
     "增量庫 Combined「追加 n · 補缺 n」是同一批內容有變的列(OutputStore v0101 · 舊列保留),不是重複。\n"
     "- **(v0173)** **版號**:本線下一版 RoundAll v0130+ · Handle-All v0122+(其他照 v0172 規則);出號前照舊查本分支與 main。\n\n")
(REPO / "VRN2_Handover_v0174.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0173"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0129.py", "VRN2_RoundAll_v0129.md", "VRN2_HandleAll_v0121.md", "VRN2_HandleAll_v0121_boot.txt", "VRN2_Release_v0173.json", "VRN2_Verification_v0173.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(T), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0173.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall129_selftest.log", "pscheck173.log", "tiny173.rc", "e2e173.out")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0173.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall129.py", "gen_build173.py", "build173.py", "build173_tail.py", "finalize173.py", "e2e173.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0174", src.count("\n"))
