md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0121(2026-11-03 · RoundAll v0129:⑬b 只在輸入變了才重跑 · 套件 v0172 不動)

桌機 2026-11-03 05:54(Handle-All v0120 · RoundAll v0128 · repair 55 秒)**VRN P0 三項都上桌**:⑬b「補放 HistoryAlign v0103 · Parquet 寫成」·
Combined v0107 52 列(FactSet 中位數 49 · Yahoo 48)· 增量庫加 UPSIDE_ADJ(內容有變的 42 列追加 · 舊列保留)· Workbench v0107(前版 v0104)·
收尾 **REVIEW(VRN-2 0 · VCGC 0 · 人工 1 · 資料源 3)**;07:59 再跑:Combined 不再排 · 增量庫追加 0(冪等)。

剩一個重工(本輪修):每次 repair 都排「市場資料比歷史對齊新 / 歷史對齊沒跑 → 重跑 ⑬b」,其實兩者都不是 —— 收據的歷史對齊燈 GRAY「無歷史 47」是真的沒有歷史財報
(不用 MOPS 之後)→ 舊條件只看燈 → ⑬b + 增量庫 + Workbench 每次白做一次。**RoundAll v0129** 只在輸入真的變了才重跑,計畫照實寫原因;都齊了 → 「沒有要修的」。

| 項目 | 現在 |
|---|---|
| 套件 | 照舊 `vrn2_release_v0172/VRN2_Closeout_v0172.zip`(SHA-256 `%s`)|
| 一支 Python | `VRN2_RoundAll_v0129.py`(SHA-256 `%s` · 自測 99 項)|
| 自動選模式 | 收據 ≥ v0170 → **repair**(都齊了幾秒鐘 · 有變才修)|

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0121 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0129 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0129.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0129.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0121.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0129.py(套件 v0172 不動 · ⑬b 只在輸入變了才重跑)

`VRN2_RoundAll_v0129.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0128 +:

| 改了什麼 | 說明 |
|---|---|
| ⑤ ⑬b 觸發 | 舊條件「收據歷史對齊燈 GRAY」拿掉(GRAY「無歷史」是真的沒有歷史資料 · 重跑也一樣);改看輸入:這輪會重抓 / 重填市場資料 · 還沒有歷史對齊收據 · 市場資料比它新 · 年度數據比它新 · Parquet 沒寫(v0128)|
| 計畫文字 | 照實寫是哪一個原因(以前固定寫「市場資料比歷史對齊新 / 歷史對齊沒跑」)|
| 效果 | 桌機現況(三項已修、輸入沒變)repair = 「沒有要修的」→ 不再每次重做 ⑬b + 增量庫 + Workbench |
| 自測 | 99 項(v0128 的 98 項 + 97)|

套件 `vrn2_release_v0172/VRN2_Closeout_v0172.zip`(SHA-256 `%s` · 本檔內已釘 · 不動)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0129.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0129 + VRN2_HandleAll_v0121 (package v0172 unchanged)", "date": "2026-11-03",
        "trigger": "桌機 2026-11-03 05:54 / 07:59 Handle-All v0120 主控台貼回(VRN P0 三項上桌 · 收尾 REVIEW · VRN-2 0)· 授權「自動解決 · 完成既有範圍不可擴張」",
        "desktop_0554": {"result": "repair 55 s: step 13b installed HistoryAlign v0103 → Parquet written · Combined rebuilt by ConsensusJoin v0107 (52 rows · FactSet median 49 · Yahoo 48) · store: 42 Combined rows whose content changed (now carrying UPSIDE_ADJ) appended, old rows kept (OutputStore v0101 rule) · Workbench v0107 over the desktop's v0104 · closeout REVIEW: VRN-2 0 · VCGC 0 · 人工 1 · 資料源 3",
                         "rerun_0759": "Combined no longer planned · store appended 0 (idempotent) · but step 13b + store + Workbench re-ran again"},
        "fix": {"RoundAll_v0129": "step 13b is re-run only when its inputs changed (market refetch/refill planned · no HistoryAlign receipt · market json newer · FinancialData newer) or the Parquet was not written; a GRAY '無歷史' receipt with unchanged inputs no longer triggers it · the plan text names the actual reason · selftest 99"},
        "package": {"name": r170["package"]["name"], "sha256": want, "release_folder": "vrn2_release_v0172", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0128.py", "sha256": r170["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0172"}],
        "roundall": {"name": "VRN2_RoundAll_v0129.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0129.md"},
        "handleall": {"name": "VRN2_HandleAll_v0121.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0121_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "RoundAll v0129 · HandleAll v0121 · release v0173 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0173.md"}}
(rel / "VRN2_Release_v0173.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
