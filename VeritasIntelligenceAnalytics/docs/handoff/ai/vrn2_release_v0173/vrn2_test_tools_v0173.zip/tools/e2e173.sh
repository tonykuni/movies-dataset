#!/bin/bash
# v0173 e2e:沿用 v0172 沙盒(t172a · 收據 v0172)→ 模擬桌機穩態(收據歷史對齊 GRAY「無歷史」· 歷史對齊收據比市場 / 年度數據新)
# → steady(repair · 應「沒有要修的」)→ fin(年度數據變新 → ⑬b 照實寫原因重跑)→ steady2(又齊了 → 不動)→ 竄改開機檔不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v173; T=<sbx>; PA=$S/pa_venv/bin/python
B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0173; mkdir -p $D
cp $W/release173/VRN2_RoundAll_v0129.py $W/release173/VRN2_RoundAll_v0129.md $W/release173/VRN2_HandleAll_v0121.md $W/release173/VRN2_HandleAll_v0121_boot.txt $W/release173/VRN2_Release_v0173.json $D/
(cd $B && git add -A && git -c user.email=t@t -c user.name=t commit -qm r173 && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
V2=$T/VIA/VIA_Reports/vrn2
python3 - "$V2" <<'PYEOF'
import json, os, sys, time
from pathlib import Path
v2 = Path(sys.argv[1]); rp = v2 / "VRN2_Closeout_v0172.json"
r = json.loads(rp.read_text(encoding="utf-8")); r.setdefault("history_align", {})["lamp"] = "GRAY"; r["history_align"]["why"] = "對上 0 · 無歷史 14(模擬桌機)"
rp.write_text(json.dumps(r, ensure_ascii=False, indent=1), encoding="utf-8")
now = time.time()
for p, dt in ((v2 / "market" / "VRN2_Market_latest.json", 300), (v2 / "output" / "VRN2_FinancialData_latest.json", 200), (v2 / "VRN2_HistoryAlign_latest.json", 100)):
    os.utime(p, (now - dt, now - dt))
print("sim steady: receipt history GRAY · HistoryAlign newer than market / FinancialData")
PYEOF
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release173/tiny_line.txt)
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$PA" VRN2_ROUNDALL_ARGS="--python $PA" VIA_ACCEL_LIGHT_SEC=2)
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 3000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny173.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; }
rm -f $W/tiny173.rc
run steady
touch $V2/output/VRN2_FinancialData_latest.json
run fin
run steady2
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0173/VRN2_HandleAll_v0121_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny173.rc
echo E2E173_DONE
