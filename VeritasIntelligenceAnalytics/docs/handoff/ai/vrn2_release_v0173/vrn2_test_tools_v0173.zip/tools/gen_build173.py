from pathlib import Path
s = Path("/home/user/vrn2_work/v171/build171.py").read_text(encoding="utf-8")
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)
rep(s.split('"""', 2)[1], 'v0173(冪等):套件 v0172 不動(雜湊照釘)→ RoundAll v0129(⑬b 只在輸入變了才重跑)→ Handle-All v0121(指到 v0129)\n→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0173)。vrn2_release_v0172 及更早不動。')
rep('W = Path("/home/user/vrn2_work/v171"); rel = W / "release171"', 'W = Path("/home/user/vrn2_work/v173"); rel = W / "release173"')
rep('PREV = Path("/home/user/vrn2_work/v170/release170")', 'PREV = Path("/home/user/vrn2_work/v172/release172")')
rep('r170 = json.loads((REPO / "vrn2_release_v0170/VRN2_Release_v0170.json").read_text(encoding="utf-8"))', 'r170 = json.loads((REPO / "vrn2_release_v0172/VRN2_Release_v0172.json").read_text(encoding="utf-8"))')
rep('ra = (W / "new/VRN2_RoundAll_v0127.py").read_text(encoding="utf-8")', 'ra = (W / "new/VRN2_RoundAll_v0129.py").read_text(encoding="utf-8")')
rep('''assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0170"' in ra and 'VERSION = "v0127"' in ra''',
    '''assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0172"' in ra and 'VERSION = "v0129"' in ra''')
rep('''assert 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170"' in ra''', '''assert 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172"' in ra''')
rep('(rel / "VRN2_RoundAll_v0127.py").write_text(ra', '(rel / "VRN2_RoundAll_v0129.py").write_text(ra')
rep('''rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0170'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0171'")''',
    '''rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0172'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0173'")''')
rep('''rep("$F = 'VRN2_RoundAll_v0126.py'", "$F = 'VRN2_RoundAll_v0127.py'")''', '''rep("$F = 'VRN2_RoundAll_v0128.py'", "$F = 'VRN2_RoundAll_v0129.py'")''')
rep('''rep("Handle-All v0118", "Handle-All v0119", ha.count("Handle-All v0118"))''',
    '''rep("Handle-All v0120", "Handle-All v0121", ha.count("Handle-All v0120"))
rep("repair = '取套件 v0172 → ⑤ 自動修(VRN P0 三項:", "repair = '取套件 v0172 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;VRN P0 三項:")
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha''')
rep('''re.search(r"Handle-All v0118|v0126\\.py", l)''', '''re.search(r"Handle-All v0120|v0128\\.py|release_v0172'", l)''')
rep('''for a, b in (("vrn2_release_v0170", "vrn2_release_v0171"), ("VRN2_HandleAll_v0118.md", "VRN2_HandleAll_v0119.md"), ("Handle-All v0118 SHA-256 OK", "Handle-All v0119 SHA-256 OK"),''',
    '''for a, b in (("vrn2_release_v0172", "vrn2_release_v0173"), ("VRN2_HandleAll_v0120.md", "VRN2_HandleAll_v0121.md"), ("Handle-All v0120 SHA-256 OK", "Handle-All v0121 SHA-256 OK"),''')
rep('(rel / "VRN2_HandleAll_v0119_boot.txt")', '(rel / "VRN2_HandleAll_v0121_boot.txt")')
rep("vrn2_release_v0171/VRN2_HandleAll_v0119_boot.txt", "vrn2_release_v0173/VRN2_HandleAll_v0121_boot.txt")
i0 = s.index('md = """'); i1 = s.index('print("roundall"')
s = s[:i0] + Path("/home/user/vrn2_work/v173/build173_tail.py").read_text(encoding="utf-8") + s[i1:]
Path("build173.py").write_text(s, encoding="utf-8")
print("ok")
