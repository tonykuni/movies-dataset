"""VRN2_RoundAll_v0129.py = 本線 v0128(倉裡 vrn2_release_v0172 · 套件 v0172 照釘)+ ⑬b 只在輸入真的變了才重跑(桌機 05:54 / 07:59 實錄:
收據的歷史對齊燈是 GRAY「無歷史 47」= 真的沒有歷史資料,不是沒跑 → v0128 以前每次 repair 都重跑 ⑬b → 增量庫 / Workbench 跟著重做 · 收尾寫「補修 3 步」)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v173")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0172/VRN2_RoundAll_v0128.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0128')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0128 — ', '"""VRN2_RoundAll v0129 — ', 1)
at = doc.index("v0128(")
doc = doc[:at] + '''v0129(桌機 2026-11-03 05:54 v0128 repair 實錄:三項都修上 —— ⑬b「補放 HistoryAlign v0103 · Parquet 寫成」· Combined v0107 52 列 ·
  Workbench v0107(前版 v0104)· 收尾 REVIEW(VRN-2 0 · VCGC 0 · 人工 1 · 資料源 3);07:59 再跑一次:Combined 不再排 · 增量庫追加 0(冪等)):
  · 剩一個重工:每次 repair 計畫都有「市場資料比歷史對齊新 / 歷史對齊沒跑 → 重跑 ⑬b」,其實兩者都不是 —— 收據的歷史對齊燈是 GRAY
    「無歷史 47」(不用 MOPS 之後本來就沒有歷史財報),舊觸發條件只看燈是不是 GRAY → 永遠成立 → ⑬b + 增量庫 + Workbench 每次重做(約 1 分鐘)。
  · v0129:⑬b 只在輸入真的變了才重跑,計畫照實寫是哪一個:這輪會重抓 / 重填市場資料 · 還沒有歷史對齊收據 · 市場資料比它新 ·
    年度數據(FinancialData)比它新;Parquet 沒寫照 v0128。輸入沒變的 GRAY = 真的沒有歷史 → 不重跑(收尾頁照舊列灰 · 不是待修)。
  · 自測 99 項(v0128 的 98 項 + 97)。套件照舊 v0172(雜湊照釘)· 共用 MarketFetch 與 VDF 引擎照舊只讀不改。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0128.py", "用法:python VRN2_RoundAll_v0129.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0128"', 'VERSION = "v0129"')
assert re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s) and 'PACKAGE = "VRN2_Closeout_v0172"' in s      # 套件不動 · 雜湊照釘
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0128.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0128.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0129.py"', n_dl)
rep('"VRN2_RoundAll_v0128.py" in html_', '"VRN2_RoundAll_v0129.py" in html_')
rep("· v0127 起 94 項 · v0128 起 98 項。", "· v0127 起 94 項 · v0128 起 98 項 · v0129 起 99 項。")
rep('''def plan_fixes(root: Path, receipt: dict, fetch_py, args, market_tool: str = "") -> list:''',
    '''def history_due_why(v2, planned) -> str:
    """v0129 ⑬b 要不要重跑:只看輸入有沒有變(不看收據燈 —— GRAY「無歷史」是真的沒有歷史資料 · 重跑也一樣)。回原因 · 不用重跑 → ""。"""
    v2 = Path(v2)
    mjson, hrec, fin = v2 / "market" / "VRN2_Market_latest.json", v2 / "VRN2_HistoryAlign_latest.json", v2 / "output" / "VRN2_FinancialData_latest.json"
    if not mjson.is_file():
        return ""
    if planned & {"market", "market_fill"}:
        return "市場資料這輪會重抓 / 重填"
    if not hrec.is_file():
        return "還沒有歷史對齊收據"
    if _mtime(mjson) > _mtime(hrec):
        return "市場資料比歷史對齊新"
    if fin.is_file() and _mtime(fin) > _mtime(hrec):
        return "年度數據比歷史對齊新"
    return ""


def plan_fixes(root: Path, receipt: dict, fetch_py, args, market_tool: str = "") -> list:''')
rep('''    if mjson.is_file() and (planned & {"market", "market_fill"} or not hrec.is_file() or _mtime(mjson) > _mtime(hrec) or (receipt.get("history_align") or {}).get("lamp") == "GRAY"):
        plan.append(("history", "市場資料比歷史對齊新 / 歷史對齊沒跑 → 重跑 ⑬b" + (" · %s 的 Parquet 沒寫 → HistoryAlign v0103 依欄位型別重寫" % pq_due if pq_due else "")))''',
    '''    h_why = history_due_why(v2, planned)                                       # v0129 只看輸入有沒有變(收據 GRAY「無歷史」不再每次重跑)
    if h_why:
        plan.append(("history", "%s → 重跑 ⑬b" % h_why + (" · %s 的 Parquet 沒寫 → HistoryAlign v0103 依欄位型別重寫" % pq_due if pq_due else "")))''')
rep('''        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''',
    '''        import time as _t97
        with tempfile.TemporaryDirectory() as td97:
            v97 = Path(td97) / "VIA_Reports" / "vrn2"
            (v97 / "market").mkdir(parents=True)
            (v97 / "output").mkdir(parents=True)
            m97, f97, h97 = v97 / "market" / "VRN2_Market_latest.json", v97 / "output" / "VRN2_FinancialData_latest.json", v97 / "VRN2_HistoryAlign_latest.json"
            for p97 in (m97, f97, h97):
                p97.write_text("{}", encoding="utf-8")
            now97 = _t97.time()
            os.utime(m97, (now97 - 300, now97 - 300)); os.utime(f97, (now97 - 200, now97 - 200)); os.utime(h97, (now97 - 100, now97 - 100))
            (v97 / "VRN2_Workbench_latest.html").write_text("<html>" + WB_MARK + "</html>", encoding="utf-8")
            rc97 = {"market": {}, "consensus": {}, "history_align": {"lamp": "GRAY", "why": "無歷史 47"}}
            p97a = plan_fixes(Path(td97), rc97, "", A93(), "")
            os.utime(f97, (now97, now97))
            p97b = plan_fixes(Path(td97), rc97, "", A93(), "")
            os.utime(f97, (now97 - 200, now97 - 200)); os.utime(m97, (now97, now97))
            p97c = plan_fixes(Path(td97), rc97, "", A93(), "")
            os.utime(m97, (now97 - 300, now97 - 300)); h97.unlink()
            p97d = plan_fixes(Path(td97), rc97, "", A93(), "")
        chk("97 v0129:⑬b 只在輸入變了才重跑 · 收據 GRAY「無歷史」且輸入沒變 → 計畫空(桌機每次 repair 白做 ⑬b + 增量庫 + Workbench)· 年度數據 / 市場資料比它新 · 沒有收據 → 照實寫原因重跑",
            p97a == [] and [k for k, _ in p97b] == ["history", "workbench"] and p97b[0][1].startswith("年度數據比歷史對齊新")
            and p97c[0] == ("history", "市場資料比歷史對齊新 → 重跑 ⑬b") and p97d[0][1].startswith("還沒有歷史對齊收據"))
        r89 = {"lamp": "YELLOW", "step": "⑥f VIA 網路工具 DENY",''')
(W / "new").mkdir(parents=True, exist_ok=True)
(W / "new" / "VRN2_RoundAll_v0129.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0129 lines", s.count("\n"))
