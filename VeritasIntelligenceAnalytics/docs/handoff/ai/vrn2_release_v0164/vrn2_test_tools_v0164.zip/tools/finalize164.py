"""v0164 收尾:驗證紀錄 · 交接 v0165(從 v0164 抄 · 只增)· 放進倉 vrn2_release_v0164 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v164"); rel = W / "release164"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    return x.replace(str(W / "t164a"), "<sbx>").replace(str(W), "<w>").replace(SCR, "<scratch>").replace(SCR0, "<scratch0>")


R = json.loads((rel / "VRN2_Release_v0164.json").read_text(encoding="utf-8"))
st = [l for l in lines(W / "rall120_selftest.log") if re.search(r"^\[PASS\] 7[5-8] |^\[FAIL\]|--selftest · ", l)]
stv = [l for l in lines(W / "rall120_selftest_venv.log") if "--selftest · " in l]
lst = [l[:200] for l in lines(W / "launcher164_selftest.log") if l.startswith("[PASS] v0164") or l.startswith("[FAIL]")]
mods = {n: [l[:170] for l in lines(W / ("mod_%s.log" % n)) if l.startswith("[FAIL]") or "--selftest · " in l] for n in ("cj105", "st102", "ss102")}
ps = json.loads((W / "pscheck164.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny164.rc") if l.strip()]
pat = r"boot:|boot SHA|⑤ 自動修計畫|\[Combined\] \[|清 MOPS 列|擋 MOPS 列|同步還原 · ⑥e 錨點|===== 收尾|\[(VRN-2|人工|VCGC|資料源)\] \d|NEXT: \[YELLOW\] VRN-2 v0164"
e2e = {n: [short(l)[:230] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)] for n in ("repair", "full", "tamper")}
purge = json.loads((W / "purge_repair.json").read_text(encoding="utf-8")) if (W / "purge_repair.json").is_file() else {}
tps = json.loads((W / "tpsync_repair.json").read_text(encoding="utf-8")) if (W / "tpsync_repair.json").is_file() else {}
sync1 = next(iter((tps.get("per_file") or {}).values()), {})
store_after = [l for l in lines(W / "store_after_repair.txt") if l.count("/") <= 2] if (W / "store_after_repair.txt").is_file() else []
R["results"] = {"selftest": st, "selftest_venv": stv, "launcher_selftest": lst, "module_selftests": mods, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e,
                "e2e_purge": {k: purge.get(k) for k in ("lamp", "removed", "removed_total", "totals_before", "totals_after", "backup_sha256")} | {"folder": Path(str(purge.get("folder") or "")).name},
                "e2e_tp_sync": {k: sync1.get(k) for k in ("mode", "before_date", "ratio", "factor", "target_price", "target_price_adj", "match_from")}, "e2e_store_after": store_after,
                "desktop_scale": "16588 FinancialAligned rows (12004 clean + 4584 marked in 44 files) + 38 Deleted → purge plan 0.08 s · apply 2.9 s · 12004 / 0 left · next sync 0 rows (duckdb 2.0 · container)",
                "not_run": "the desktop store itself (next repair purges it) · the 3706 / 6669 VDF daily rows on the desktop (the sync evidence file will show which rule applies) · a real consensus fetch (gate closed in the container)"}
(rel / "VRN2_Release_v0164.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0164 驗證紀錄(2026-11-01 · 增量庫清 MOPS 列 · TARGET_PRICE(ADJ) 同步還原 · TWSE / TPEX 格式合併 · 套件 v0164 · RoundAll v0120 · Handle-All v0112)

## 1. 起因

操作員 2026-11-01:「**Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原才有可比較性 · 兩個單位所算的目標價中位數並存方便比較 ·
只要最後把他跟 TWSE / TPEX 輸出個格式依樣在合併即可**」+ 桌機 2026-11-01 03:08 收尾(RoundAll v0119 repair):OPEN · VRN-2 1 =「⑥e 擷取 YELLOW · 跑 10 次 · 失敗 0」·
TARGET_PRICE(ADJ) MISSING 5(3706 / 6669「報告日前沒有日資料 · 需 --start 回補」)· 增量庫 FinancialAligned 16588 / Deleted 38(含 16:11 MOPS 那批)。

## 2. 全景定位(錨點)與分類

| 錨點 | 定位 | 可並行 / 須順序 |
|---|---|---|
| 增量庫 MOPS 列 | `<輸出夾>/VRN2/vrn2_store.duckdb` 的 `book_financialaligned` / `book_deleted`(每列帶 run_id · file_sha · row_sha)+ `parquet/<冊>/run=<id>.parquet` · 認列靠 HistoryAlign 寫的 VALUE_SOURCE / RECON_RATIO / HISTORY_VALUE(不靠時間)| 並行(只動 VRN-2 自己的輸出夾)|
| ⑥e「失敗 0」卻 YELLOW | `VRN2_MarketFetch_v0112.fetch`:`lamp = YELLOW if all(rc in (0, 2))` · 「失敗」只數 rc 不在 (0, 2) · VDF 引擎 rc 2 = `status.json` PARTIAL(issues 或日線品質 REVIEW = Yahoo 收盤 ≠ TWSE 收盤)| 並行(收尾頁判法 · MarketFetch / VDF 不改)|
| 3706 / 6669 MISSING | `MarketFetch.fill`:`before = adj[adj.date < 報告日]`,`adj` 只收 adj_close 非空的列 → VDF `def_adjust_prices` 對 CLOSE_MISMATCH 的日子不給 adj_close → 「沒有日資料」其實可能是「Yahoo 收盤對不上」| 須順序:⑥e 落盤 → ⑥f 同步還原 → Combined → ⑬ |
| 兩家中位數 | `ConsensusJoin_v0100.HEAD`:FACTSET_TARGET_PRICE_MEDIAN · YFINANCE_TARGET_PRICE_MEDIAN 早就並存 | 不用改(保留欄序)|
| TWSE / TPEX 格式 | VDF `IDENTITY_PREFIX` = date · ticker · yfinance_ticker · bloomberg_ticker · name · `DATASET_KEYS` [date, ticker] · `parquet/<ds>/ticker=/year=/data.parquet` + `<ds>.parquet` · CSV 大寫表頭 | 須順序:⑥f 之後 |

順序:runtime v0157(ConsensusJoin v0105 · OutputStore v0102 · SSOTSync v0102 · 提案冊 v0101)→ 啟動器 v0164 → 套件 v0164 → RoundAll v0120(釘套件雜湊)→ Handle-All v0112(釘 RoundAll)→ 開機檔 → 最短一行 / cmd 一行。
九頭龍檢查:VDF 引擎 / 共用 MarketFetch / VCGC 的檔一字不改;MarketFetch 的 `VRN2_Market_latest.json` 不改(v0105 只給 join 一份補過的複本);增量庫清之前整檔備份 · 可 `restore-purge`;
前版模組(ConsensusJoin v0104 ~ v0100 · OutputStore v0101 / v0100 · SSOTSync v0101 / v0100)逐位元組不動。

## 3. 修法

| 檔 | 內容 |
|---|---|
| ConsensusJoin v0105 | TARGET_PRICE(ADJ) 同步還原(VDF 已還原 → adj_close ÷ close;CLOSE_MISMATCH 且 Yahoo ÷ TWSE 比值報告日前 10 天內一致(±0.5%%)、離 1 超過 1%%、報告日後回到 MATCH → Yahoo 還原收盤 ÷ TWSE 收盤;其他 MISSING 寫實原因)· 三格同一個因子 · 證據 `market/VRN2_TPAdjSync_latest.json`(含 VDF status.json · 每檔 MISMATCH 列數)· 共識照 VDF 格式寫 `consensus/dataset`(tw_consensus · tw_consensus_estimate)→ 跟 TWSE / TPEX 日線合併(14 天內最後一個交易日)= tw_market_consensus + `output/VRN2_MarketConsensus_latest` |
| OutputStore v0102 | 認列:Deleted 全部 · FinancialAligned 有歷史記號的 (run_id, file_sha) 整組 · `purge-mops`(預設只算 · `--apply` 先複製 DuckDB 檔 + SHA-256 → removed/<冊>.parquet → 刪 → 受影響 run 分檔搬走再重寫剩的 → PURGE_MANIFEST.json)· `restore-purge` · sync = 先清再收(擋 MOPS 列 · mops_skipped)· 新冊 MarketConsensus |
| SSOTSync v0102 + 提案冊 v0101 | 這輪 8 條新規則(VRN2-PROP-0010 ~ 0017 · ssot_id 空白)· ⑤b 照 v0101 送核號請求 · v0101 的自測隔離跑 |
| 啟動器 v0164(`%s`)| runtime v0157 · ⑥f 載 v0105 · ⑬ 載 v0102(清 MOPS 列寫在 ⑬ 那行最前面)|
| RoundAll v0120(`%s`)| ⑤ combined(沒同步還原過)· store(增量庫沒確認乾淨)· market_fill(市場資料還帶 MOPS 財報 → 只重新填值)· 收尾頁 ⑥e 失敗 0 → 資料源 + 錨點 · 「不用 MOPS」字樣不當 DENY · 自測 78 |
| 套件 v0164(`%s`)· Handle-All v0112(一行 `%s` · 開機檔 `%s`)| 最短一行 %d 字元 · cmd 一行 %d 字元 |

## 4. 測試

```text
%s
venv(py3.12 · pandas / pyarrow / duckdb):%s
啟動器 v0164 自測(從套件 zip 解開 · venv):
%s
模組自測(系統 py3.13 duckdb · venv py3.12 duckdb + pyarrow · venv pyarrow 只有):
%s
%s
```

桌機規模模擬(容器):%s

## 5. e2e(桌機 v0153 狀態沙盒 · 增量庫先用 OutputStore v0101 收一批帶 MOPS 歷史記號的列 · 6669 報告日前 Yahoo 分割 · 沙盒 GitHub 分支 · pwsh 7.4.6)

```text
%s
```

repair 後增量庫:%s · 同步還原:%s · 增量庫夾:%s

**沒跑到的**:%s。
""" % (R["launcher"]["sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12], H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], H["cmd_line_chars"],
       "\n".join(st), " ".join(stv), "\n".join(lst), "\n".join("%s: %s" % (k, " | ".join(v)) for k, v in mods.items()), pparse, R["results"]["desktop_scale"],
       "\n".join("[%s] " % n + l for n in e2e for l in e2e[n]) + "\n" + " · ".join(rc),
       json.dumps(R["results"]["e2e_purge"], ensure_ascii=False), json.dumps(R["results"]["e2e_tp_sync"], ensure_ascii=False), ", ".join(store_after), R["results"]["not_run"])
(rel / "VRN2_Verification_v0164.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0164.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0163 + VRN2_RoundAll_v0119 + VRN2_HandleAll_v0111 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0164 + VRN2_RoundAll_v0120 + VRN2_HandleAll_v0112 · 2026-11-01(操作員:Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · "
        "TARGET_PRICE(ADJ) 同步還原 · 兩家中位數並存 · TWSE / TPEX 格式合併 → ConsensusJoin v0105 · OutputStore v0102 · 套件 v0164)")
src = "\n".join(L)
once("> **本輪(v0163)**",
     "> **本輪(v0164)**:操作員 2026-11-01「**Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原才有可比較性 · 兩個單位所算的目標價中位數並存方便比較 · "
     "最後把他跟 TWSE / TPEX 輸出格式一樣再合併**」。**ConsensusJoin v0105**:TARGET_PRICE(ADJ) 同步還原(Yahoo 收盤 ≠ TWSE 收盤時看比值一致 + 之後回到一致 → Yahoo 還原收盤 ÷ TWSE 收盤 · "
     "其他 MISSING 寫實原因 · 證據 `market/VRN2_TPAdjSync_latest.json`)· 兩家中位數照舊並存 · 共識照 VDF(TWSE / TPEX)格式寫 `consensus/dataset` → 合併 `tw_market_consensus` · "
     "**OutputStore v0102**:增量庫先清 MOPS 歷史算的列(整檔備份 `_mops_purge_<時間>` · `restore-purge`)· 以後不收 · 多一本 MarketConsensus · **SSOT 提案冊 v0101**:這輪 8 條新規則 ssot_id 空白等 VCGC 核發 · "
     "**RoundAll v0120**:⑥e「擷取 YELLOW · 失敗 0」= VDF rc 2 PARTIAL → 資料源 + 錨點 · ⑤ combined / store / market_fill · **Handle-All v0112**(最短一行 %d 字元 · cmd 一行 %d 字元)。"
     "**未決**:3706 / 6669 是哪條規則(分割同步還原 or 真的沒有報告日前日線)要看下一個貼回包的 `VRN2_TPAdjSync_latest.json`。\n"
     "> **本輪(v0163)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
once("| **VRN2_HandleAll_v0111.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0111** | `vrn2_release_v0163` |",
     "| **VRN2_HandleAll_v0112.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0112** | `vrn2_release_v0164` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0120)|\n"
     "| **VRN2_RoundAll_v0120.py**(發行夾 · 一支入口 · 不在套件內)| **v0120** | `vrn2_release_v0164` | `%s` | **新**(套件 v0164 · ⑤ combined / store / market_fill · ⑥e 失敗 0 → 資料源 · 自測 78 項)|\n"
     "| **VRN2_Closeout_v0164.zip**(發行夾 · 套件)| **v0164** | `vrn2_release_v0164` | `%s` | **新**(啟動器 v0164 · runtime v0157)|\n"
     "| **VRN2_HandleAll_v0111.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0111** | `vrn2_release_v0163` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12]))
r163 = json.loads((REPO / "vrn2_release_v0163/VRN2_Release_v0163.json").read_text(encoding="utf-8"))
once("| **VRN2_RoundAll_v0119.py**(發行夾 · 一支入口 · 不在套件內)| **v0119** | `vrn2_release_v0163` | `%s` | **新**(" % r163["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0119.py**(發行夾 · 一支入口 · 不在套件內)| **v0119** | `vrn2_release_v0163` | `%s` | 被 v0120 取代(套件 v0163)· (" % r163["roundall"]["sha256"][:12])
rt = R["runtime"]
once("| ActivateVRN-2_v0163.py(套件 · 底座 v0136 · runtime v0156)| **v0163** |",
     "| ActivateVRN-2_v0164.py(套件 · 底座 v0136 · runtime v0157)| **v0164** | 見發行清單 | `%s` | **新**(⑥f ConsensusJoin v0105 · ⑬ OutputStore v0102 · 收據 v0164)|\n"
     "| VRN2_Runtime_v0157.zip(套件 · runtime)| **v0157** | 套件內 | `%s` | **新**(v0156 的 192 個成員不動 + ConsensusJoin v0105 · OutputStore v0102 · SSOTSync v0102 · 提案冊 v0101)|\n"
     "| VRN2_ConsensusJoin_v0105.py(runtime · 薄尾 v0104)| **v0105** | runtime v0157 | 見 runtime 清單 | **新**(TARGET_PRICE(ADJ) 同步還原 · TWSE / TPEX 格式資料集 · 合併)|\n"
     "| VRN2_OutputStore_v0102.py(runtime · 薄尾 v0101)| **v0102** | runtime v0157 | 見 runtime 清單 | **新**(清 MOPS 列 · 備份 · restore-purge · 擋 · MarketConsensus)|\n"
     "| VRN2_SSOTSync_v0102.py + VRN2_SSOT_Proposals_v0101.json(runtime)| **v0102 / v0101** | runtime v0157 | 見 runtime 清單 | **新**(提案 8 條 · ssot_id 空白)|\n"
     "| ActivateVRN-2_v0163.py(套件 · 底座 v0136 · runtime v0156)| **v0163** |" % (R["launcher"]["sha256"][:12], rt["zip_sha256"][:12]))
once("| 0 | **(v0163)**",
     "| 0 | **(v0164)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"` 再貼 `vrn2_release_v0164/VRN2_HandleAll_v0112.md` 的 cmd 一行 → repair:取套件 v0164 → ⑤ combined(同步還原 · TWSE / TPEX 格式合併)→ "
     "store(清 MOPS 列 · 備份)→ 收尾 · **上傳貼回包**(看 `VRN2_StorePurge_latest.json` 清了幾列 · `market/VRN2_TPAdjSync_latest.json` 3706 / 6669 是哪條規則)| 貼回 |\n"
     "| 0 | **(v0163)**")
once("**v0163(2026-10-31)**:", "**v0164(2026-11-01)**:操作員:Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · TARGET_PRICE(ADJ) 同步還原 · 兩家中位數並存 · TWSE / TPEX 格式合併 → ConsensusJoin v0105 / OutputStore v0102 / "
     "SSOTSync v0102 + 提案冊 v0101 · runtime v0157 · 啟動器 v0164 · RoundAll v0120(⑥e 失敗 0 → 資料源 · ⑤ combined / store / market_fill)· Handle-All v0112。\n\n**v0163(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0164)** **增量庫可以清,但只清 MOPS 算的列、先整檔備份**:操作員 2026-11-01 令「增量庫 MOPS 資料清掉」。認列靠 HistoryAlign 寫在列上的記號"
     "(VALUE_SOURCE HISTORY* / 無歷史 / 未對齊 / 口徑不明 · RECON_RATIO · HISTORY_VALUE),FinancialAligned 整組((run_id, file_sha))· Deleted 逐列;不靠時間、不靠 run 名。"
     "清之前 DuckDB 檔整檔複製到 `_mops_purge_<時間>`,`restore-purge` 換回。其他冊(BasicInfo / FinancialData / Summary / Rejected / Combined)不動。\n"
     "- **(v0164)** **TARGET_PRICE(ADJ) 與 ADJ_CLOSE 同一個還原基準**:VDF 不還原 Yahoo 收盤 ≠ TWSE 收盤的日子(CLOSE_MISMATCH);只有比值報告日前一致、報告日後回到一致(除權 / 分割 / 面額變更的追溯調整)"
     "才用 Yahoo 還原收盤 ÷ TWSE 收盤;其他一律 MISSING + 寫實原因(MISSING(…) 開頭 · 收尾頁歸資料源)。MarketFetch 的 market JSON 不改。\n"
     "- **(v0164)** **⑥e「擷取 YELLOW · 失敗 0」不是 VRN-2 的錯**:= VDF 引擎 rc 2(PARTIAL · status.json 的 issues / 日線 REVIEW)· 收尾頁算資料源並寫錨點。不要為它重抓。\n"
     "- **(v0164)** **新規則先進提案冊、編號留白**:SSOT / 正則 / 同義字 / 邏輯 / 政策這類新項目寫進 `VRN2_SSOT_Proposals_v<新版>.json`(ssot_id 空白 · proposed_no 暫編)→ ⑤b 送核號請求 → VCGC 偵測衝突、"
     "測過才公布編號 → apply 自動補填。VRN-2 不自己編正式號、不改 VCGC 的冊。\n\n")
(REPO / "VRN2_Handover_v0165.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0164"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0164.zip", "VRN2_RoundAll_v0120.py", "VRN2_RoundAll_v0120.md", "VRN2_HandleAll_v0112.md", "VRN2_HandleAll_v0112_boot.txt", "VRN2_Release_v0164.json", "VRN2_Verification_v0164.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t164a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0164.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "rall120_selftest.log", W / "rall120_selftest_venv.log", W / "launcher164_selftest.log", W / "pscheck164.log", W / "tiny164.rc", W / "seed164.log"] + \
             sorted(W.glob("mod_*.log")) + sorted(W.glob("tiny_*.log")) + sorted(W.glob("store_after_*.txt")) + sorted(W.glob("purge_*.json")) + sorted(W.glob("tpsync_*.json")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0164.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("runtime157.py", "mk_launcher164.py", "mk_roundall120.py", "build164.py", "finalize164.py", "e2e164.sh", "seed164.py")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0165", src.count("\n"))
