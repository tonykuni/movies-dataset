"""ActivateVRN-2_v0164.py = v0163 + ⑥f ConsensusJoin v0105(TARGET_PRICE(ADJ) 同步還原 · 共識照 TWSE / TPEX 格式落盤後合併)+ ⑬ OutputStore v0102(增量庫清掉 MOPS 算的列 · 先備份 · 以後不收 · MarketConsensus 冊)
· runtime v0157 = runtime v0156(192 個成員一字不改)+ 這兩支。操作員 2026-11-01。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v163/pkg163/ActivateVRN-2_v0163.py")
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0163: v0158 entry + step 6e never touches MOPS', '''"""VRN-2 v0164: v0163 entry + the operator decisions of 2026-11-01 ("Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原
才有可比較性 · 兩個單位所算的目標價中位數並存方便比較 · 最後把他跟 TWSE / TPEX 輸出格式一樣再合併").

 - step 6f VRN2_ConsensusJoin_v0105 (thin tail over v0104 · v0104 ~ v0100 unchanged):
   * TARGET_PRICE(ADJ) synchronous adjustment: when MarketFetch left it MISSING, the VDF daily partitions in VRN-2's own output folder are read (read-only):
     VDF-adjusted day before the report → adj_close / close; CLOSE_MISMATCH with a Yahoo/TWSE close ratio that is constant before the report and back to
     MATCH later (Yahoo's retroactive split / stock-dividend adjustment) → Yahoo adj close / TWSE close; anything else stays MISSING with the real reason.
     TARGET_PRICE(ADJ) · ADJ_CLOSE_BEFORE_REPORT · UPSIDE_PCT(ADJ) use one factor; evidence market/VRN2_TPAdjSync_latest.json (+ VDF status.json and
     per-ticker MISMATCH counts = the anchor of "6e fetch YELLOW · 0 failures", i.e. VDF rc 2 PARTIAL). MarketFetch's market JSON is not modified.
   * FACTSET_TARGET_PRICE_MEDIAN and YFINANCE_TARGET_PRICE_MEDIAN stay side by side (Combined column order unchanged).
   * consensus written in the TWSE / TPEX (VDF) output format under consensus/dataset (identity prefix date · ticker · yfinance_ticker · bloomberg_ticker · name ·
     key [date, ticker] · parquet/<ds>/ticker=/year=/data.parquet + <ds>.parquet + upper-case CSV): tw_consensus · tw_consensus_estimate, then merged with
     the TWSE / TPEX daily rows (as-of the consensus day) = tw_market_consensus + output/VRN2_MarketConsensus_latest.
 - step 13 VRN2_OutputStore_v0102 (thin tail over v0101): before every sync the long-term store drops rows computed from MOPS history
   (Deleted: all · FinancialAligned: every (run_id, file_sha) group carrying a history marker) after copying the DuckDB file (or the touched run files)
   into <out>/VRN2/_mops_purge_<stamp> (restore-purge puts it back); such rows are never appended again (mops_skipped); new book MarketConsensus.
 - SSOT proposals v0101 (VRN2_SSOT_Proposals_v0101.json = v0100's 9 entries + this round's 8 rules · ssot_id blank): step 5b (SSOTSync v0101, unchanged) sends them
   in the number request; VCGC conflict-tests and grants the numbers; apply fills them in. VRN2_SSOTSync_v0102 only isolates v0101's selftest.
 Runtime v0157 = runtime v0156 (192 members byte-identical) + VRN2_ConsensusJoin_v0105 + VRN2_OutputStore_v0102 + VRN2_SSOTSync_v0102 + VRN2_SSOT_Proposals_v0101.json.
 Receipt VRN2_Closeout_v0164.json.

VRN-2 v0163: v0158 entry + step 6e never touches MOPS''')
rep('VERSION = "ActivateVRN-2 v0163"', 'VERSION = "ActivateVRN-2 v0164"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0156.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0157.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0156.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0157.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0163.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0164.json"')
rep('''OUTPUT_STORE = "VRN2_OutputStore_v0101.py"   # v0147: thin tail over v0100 (7 books · per-book back-fill)''',
    '''OUTPUT_STORE = "VRN2_OutputStore_v0101.py"   # v0147: thin tail over v0100 (7 books · per-book back-fill)
OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0102.py"   # v0164: thin tail over v0101 (MOPS rows purged with a backup · never appended again · MarketConsensus book)''')
rep('''CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0104.py"''', '''CONSENSUS_JOIN_ACTIVE = "VRN2_ConsensusJoin_v0105.py"   # v0164: thin tail over v0104 (TARGET_PRICE(ADJ) synchronous adjustment · consensus in the TWSE / TPEX format · merged)
CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0104.py"''')
rep('''        module = _load_runtime_module(runtime, OUTPUT_STORE, "vrn2_output_store_entry")''', '''        module = _load_runtime_module(runtime, OUTPUT_STORE_ACTIVE, "vrn2_output_store_entry")   # v0164 v0102(先清 MOPS 列 · 備份)''')
rep('''            " / ".join("%s %s" % (k, v) for k, v in appended.items()), len(result.get("parquet_files") or []), (" · " + result["why"]) if result.get("why") else "")''',
    '''            " / ".join("%s %s" % (k, v) for k, v in appended.items()), len(result.get("parquet_files") or []), (" · " + result["why"]) if result.get("why") else "")
        purge = result.get("mops_purge") or {}
        if purge.get("removed_total") or purge.get("lamp") == "RED":                                      # v0164 清 MOPS 列寫在前面(不被 300 字截掉)
            detail = "清 MOPS 列 %s(%s)· %s" % (json.dumps(purge.get("removed") or {}, ensure_ascii=False), Path(str(purge.get("folder") or "")).name or purge.get("lamp"), detail)
        if result.get("mops_skipped"):
            detail = "擋 MOPS 列 %s · %s" % (json.dumps(result["mops_skipped"], ensure_ascii=False), detail)''')
rep('''    return {k: result.get(k) for k in ("lamp", "why", "output_dir", "cloud_hint", "store_engine", "store", "run_id", "new_files", "known_files", "appended", "totals", "catalog_files", "parquet_files", "mirrored") if k in result}''',
    '''    return {k: result.get(k) for k in ("lamp", "why", "output_dir", "cloud_hint", "store_engine", "store", "run_id", "new_files", "known_files", "appended", "totals", "catalog_files", "parquet_files", "mirrored", "mops_purge", "mops_skipped") if k in result}''')
rep('''        module = _load_runtime_module(runtime, CONSENSUS_JOIN, "vrn2_consensus_join_entry")''', '''        module = _load_runtime_module(runtime, CONSENSUS_JOIN_ACTIVE, "vrn2_consensus_join_entry")   # v0164 v0105(同步還原 · TWSE / TPEX 格式合併)''')
rep('''"join": {k: joined.get(k) for k in ("lamp", "why", "rows", "target_adj", "factset_median", "yf_median", "eps_cells", "year_n", "files") if k in joined}}''',
    '''"join": {k: joined.get(k) for k in ("lamp", "why", "rows", "target_adj", "factset_median", "yf_median", "eps_cells", "year_n", "files", "tp_adj_sync", "tp_adj_status_rows", "consensus_dataset") if k in joined}}''')
# 前版自測的暫存 runtime:啟動器的 ⑬ / ⑥f 現在載 v0102 / v0105 → 前版的那幾格也要放(薄尾要前版在旁邊)
rep('''        for name in (SSOT_SYNC, "VRN2_SSOTSync_v0100.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py"):   # thin tails need their prior next to them''',
    '''        for name in (SSOT_SYNC, "VRN2_SSOTSync_v0100.py", OUTPUT_STORE_ACTIVE, OUTPUT_STORE, "VRN2_OutputStore_v0100.py"):   # thin tails need their prior next to them (v0164: v0102 active)''')
rep('''        for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"):''',
    '''        for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN_ACTIVE, CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"):''')
rep('''        assert cjs[-1] == "VRN2_ConsensusJoin_v0104.py" and "VRN2_ConsensusJoin_v0103.py" in cjs, cjs[-3:]''',
    '''        assert cjs[-1] == CONSENSUS_JOIN_ACTIVE and CONSENSUS_JOIN in cjs and "VRN2_ConsensusJoin_v0103.py" in cjs, cjs[-3:]     # v0164: v0105 newest · v0104 its PRIOR
        sts = sorted(n for n in names156 if re.fullmatch(r"VRN2_OutputStore_v\\d{4}\\.py", n))
        assert sts[-1] == OUTPUT_STORE_ACTIVE and OUTPUT_STORE in sts and "VRN2_OutputStore_v0100.py" in sts, sts''')
rep('''        return lamp, detail + " · launcher v0163"''', '''        return lamp, detail + " · launcher v0164"''')
rep("exact ship v0156 (launcher v0163 · no MOPS); manager v0257 (over v0255); consensus join v0104 + engine v0122 via VIA network tool;",
    "exact ship v0157 (launcher v0164 · no MOPS · store MOPS rows purged); manager v0257 (over v0255); consensus join v0105 (TP(ADJ) sync · TWSE/TPEX format) over v0104 + engine v0122 via VIA network tool;")
rep('''    print("NEXT: [%s] VRN-2 v0163 · rc %s''', '''    print("NEXT: [%s] VRN-2 v0164 · rc %s''')
rep('''    print("[PASS] v0163: step 6e never asks for MOPS''', '''    with tempfile.TemporaryDirectory(prefix="vrn2-v0164-check-") as temporary:
        root164 = Path(temporary) / "VIA"
        runtime164 = root164 / "functional modules" / "VRN2"
        runtime164.mkdir(parents=True)
        for name in (CONSENSUS_JOIN_ACTIVE, CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0103.py", "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py",
                     OUTPUT_STORE_ACTIVE, OUTPUT_STORE, "VRN2_OutputStore_v0100.py"):
            shutil.copy2(str(selftest_source(name)), str(runtime164 / name))
        cj = _load_runtime_module(runtime164, CONSENSUS_JOIN_ACTIVE, "vrn2_consensus_join_v0164_check")
        assert cj.VERSION == "v0105" and cj.PRIOR.VERSION == "v0104" and cj.V0100.join is cj.join and cj.PRIOR.join is cj.join and cj.V0100.run is cj.PRIOR.run
        assert cj.IDENTITY == ["date", "ticker", "yfinance_ticker", "bloomberg_ticker", "name"] and cj.KEYS["tw_market_consensus"] == ["date", "ticker"]
        assert "factset_target_price_median" in cj.MERGED_COLS and "yfinance_target_price_median" in cj.MERGED_COLS and "median_gap_pct" in cj.MERGED_COLS
        day164 = datetime.date
        rows164 = [{"date": day164(2025, 11, 26), "close": 400.0, "yf_close": 100.0, "yf_adj_close": 96.0, "close_check": "MISMATCH", "adjustment_status": "CLOSE_MISMATCH", "adj_close": None},
                   {"date": day164(2026, 10, 30), "close": 76.8, "yf_close": 76.8, "yf_adj_close": 76.8, "close_check": "MATCH", "adjustment_status": "ADJUSTED", "adj_close": 76.8}]
        sync164 = cj.sync_factor(rows164, day164(2025, 11, 28))
        assert sync164["mode"] == "SYNC_YAHOO_RATIO" and abs(sync164["factor"] - 0.24) < 1e-9                                       # split 1:4 · dividends 0.96
        assert cj.sync_factor(rows164[1:], day164(2025, 11, 28))["reason"].startswith("MISSING(")                                    # no day before the report → MISSING
        st = _load_runtime_module(runtime164, OUTPUT_STORE_ACTIVE, "vrn2_output_store_v0164_check")
        assert st.TAG == "v0102" and st.BOOKS[-1] == "MarketConsensus" and st.V0100.sync is st.sync and st.V0100._append_duckdb is st._append_duckdb
        assert st.mops_marked("FinancialAligned", {"VALUE_SOURCE": "HISTORY(MOPS / TWSE)"}) and not st.mops_marked("FinancialAligned", {"VALUE_SOURCE": "REPORT(估)"})
        assert st.mops_index("FinancialAligned", [{"run_id": "r", "file_sha": "a", "VALUE_SOURCE": "REPORT(估)"}, {"run_id": "r", "file_sha": "a", "VALUE_SOURCE": "REPORT(未對齊)"},
                                                  {"run_id": "r", "file_sha": "b", "VALUE_SOURCE": "REPORT"}]) == [0, 1]
        output164 = root164 / "VIA_Reports" / "vrn2"
        (output164 / "output").mkdir(parents=True)
        steps164 = []
        got164 = output_store(runtime164, output164, "t164", steps164)
        assert got164["lamp"] == "GRAY" and steps164[-1]["step"].startswith("⑬") and json.loads((output164 / "VRN2_StorePurge_latest.json").read_text(encoding="utf-8"))["lamp"] == "GRAY"
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():                     # v0164 SSOT 提案冊 v0101(這輪新規則 8 條 · ssot_id 空白 · 等 VCGC 核發)
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            names164 = bundle.namelist()
            book164 = json.loads(bundle.read("VRN2_SSOT_Proposals_v0101.json").decode("utf-8")) if "VRN2_SSOT_Proposals_v0101.json" in names164 else {}
        entries164 = book164.get("entries") or []
        assert "VRN2_SSOTSync_v0102.py" in names164 and len(entries164) == 17 and all(e.get("ssot_id") == "" for e in entries164) and entries164[-1]["proposed_no"] == "VRN2-PROP-0017"
    print("[PASS] v0164: step 6f loads ConsensusJoin v0105 (TARGET_PRICE(ADJ) synchronous adjustment · consensus in the TWSE / TPEX format · merged) · "
          "step 13 loads OutputStore v0102 (MOPS rows purged with a backup · never appended again · MarketConsensus book) · v0104 / v0101 kept as PRIOR · "
          "SSOT proposals v0101 (8 new rules · ssot_id blank · step 5b requests numbers from VCGC)")
    print("[PASS] v0163: step 6e never asks for MOPS''')
out = Path("/home/user/vrn2_work/v164/pkg164/ActivateVRN-2_v0164.py")
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0164 lines", s.count("\n"))
