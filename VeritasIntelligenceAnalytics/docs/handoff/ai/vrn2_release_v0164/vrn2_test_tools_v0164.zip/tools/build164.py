"""v0164(冪等):套件 VRN2_Closeout_v0164.zip(啟動器 v0164 · runtime v0157 = v0156 + ConsensusJoin v0105 + OutputStore v0102)→ RoundAll v0120(填套件雜湊)
→ Handle-All v0112 → 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單。vrn2_release_v0163 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v164"); pkg, rel = W / "pkg164", W / "release164"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v163/release163")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r158 = json.loads((REPO / "vrn2_release_v0158/VRN2_Release_v0158.json").read_text(encoding="utf-8"))
r163 = json.loads((REPO / "vrn2_release_v0163/VRN2_Release_v0163.json").read_text(encoding="utf-8"))
r162 = r163
rt = json.loads((pkg / "VRN2_Runtime_v0157.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0157.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0156.zip " + r158["runtime"]["zip_sha256"]
assert rt["retained_members"] == 192 and rt["new_members"] == ["VRN2_ConsensusJoin_v0105.py", "VRN2_OutputStore_v0102.py", "VRN2_SSOTSync_v0102.py", "VRN2_SSOT_Proposals_v0101.json"]
old = {c["path"]: c["sha256"] for c in r158["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0164.py", "VRN2_Runtime_v0157.zip", "VRN2_Runtime_v0157.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0164.py", "VRN2_Runtime_v0157.zip", "VRN2_Runtime_v0157.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0158 / v0163 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0164 — VRN-2 closeout package (2026-11-01 · store MOPS rows purged · TARGET_PRICE(ADJ) sync · consensus in the TWSE / TPEX format)\n\n"
  "Entry: python ActivateVRN-2_v0164.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0120.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0112.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0157.zip = v0156 (192 members byte-identical) + VRN2_ConsensusJoin_v0105 + VRN2_OutputStore_v0102 + VRN2_SSOTSync_v0102 + VRN2_SSOT_Proposals_v0101.json.\n\n"
  "v0164 (operator 2026-11-01 'Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原 · 兩家中位數並存 · TWSE/TPEX 格式合併'):\n"
  " step 6f ConsensusJoin v0105: TARGET_PRICE(ADJ) synchronous adjustment (Yahoo adj close / TWSE close when Yahoo's close carries a retroactive\n"
  " split / stock-dividend adjustment) · FactSet and YFinance medians side by side · consensus in the VDF (TWSE / TPEX) output format under\n"
  " consensus/dataset, merged with the TWSE / TPEX daily rows (tw_market_consensus). Step 13 OutputStore v0102: MOPS-derived rows purged from the\n"
  " long-term store after a full backup (<out>/VRN2/_mops_purge_<stamp> · restore-purge) · never appended again · MarketConsensus book.\n"
  "v0163 (operator 2026-10-31 '不可用 MOPS · 全部國內使用 TWSE TPEX'): step 6e passes --no-financial to the shared MarketFetch --fetch, so the\n"
  " borrowed VDF engine never asks MOPS for financial statements; prices / indices / universe stay on the official TWSE / TPEX lanes. MOPS financial\n"
  " data already on disk (market/vdf/parquet/tw_financial, market/vdf/tw_financial.parquet) is moved (not deleted) to market/vdf/_mops_quarantine_<stamp>.\n"
  "v0158: step 3b OCR environment: no venv, no pip from VRN-2 · v0157: step 3 check-only · missing packages through VCGC's install gate.\n"
  "Verification: see VRN2_Verification_v0164.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0164.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0164", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0164.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0164/" + n, date_time=(2026, 11, 1, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0120.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0164"' in ra and 'VERSION = "v0120"' in ra
(rel / "VRN2_RoundAll_v0120.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0163'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164'")
rep("$F = 'VRN2_RoundAll_v0119.py'", "$F = 'VRN2_RoundAll_v0120.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0111", "Handle-All v0112", ha.count("Handle-All v0111"))
rep("v0163", "v0164", ha.count("v0163"))
rep("⑥f ConsensusJoin v0104 · 共識引擎 v0122", "⑥f ConsensusJoin v0105(TARGET_PRICE(ADJ) 同步還原 · TWSE / TPEX 格式合併)· 共識引擎 v0122")
rep("· 重組 Combined · 增量庫 · Workbench;閘關", "· 重組 Combined(同步還原 · 合併)· 增量庫(先清 MOPS 算的列 · 備份)· Workbench;閘關")
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if "v0111" in l and not l.lstrip().startswith("#")]
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0163", "vrn2_release_v0164"), ("VRN2_HandleAll_v0111.md", "VRN2_HandleAll_v0112.md"), ("Handle-All v0111 SHA-256 OK", "Handle-All v0112 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0112_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164/VRN2_HandleAll_v0112_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0112(2026-11-01 · 增量庫清 MOPS 列 · TARGET_PRICE(ADJ) 同步還原 · TWSE / TPEX 格式合併 · 套件 v0164 · RoundAll v0120)

操作員 2026-11-01:「**Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原才有可比較性 · 兩個單位所算的目標價中位數並存方便比較 ·
只要最後把他跟 TWSE / TPEX 輸出個格式依樣在合併即可**」。

| 項目 | 現在 |
|---|---|
| 增量庫(OneDrive\\\\VRN2_out)| ⑬ OutputStore v0102 每次寫入前先清掉 MOPS 歷史算出來的列:Deleted 全部 · FinancialAligned 帶歷史記號的整組(同一輪同一份報告)· **先把整個 DuckDB 檔備份**到 `VRN2\\\\_mops_purge_<時間>`(被清的列另存 `removed\\\\*.parquet` · `restore-purge` 可換回)· 以後不再收 |
| TARGET_PRICE(ADJ) | 同一個還原因子:VDF 已還原 → adj_close ÷ close;報告日前那天 Yahoo 收盤 ≠ TWSE 收盤、但比值報告日前一致、報告日後回到一致(除權 / 分割的追溯調整)→ Yahoo 還原收盤 ÷ TWSE 收盤 · ADJ_CLOSE_BEFORE_REPORT / UPSIDE_PCT(ADJ) 同一個因子 · 其他照舊 MISSING 寫實原因 |
| 兩家中位數 | FACTSET_TARGET_PRICE_MEDIAN 與 YFINANCE_TARGET_PRICE_MEDIAN 並存(Combined 欄序不動)· 合併資料集另給兩家差距 %% 與各自上漲空間 |
| TWSE / TPEX 格式合併 | 共識照 VDF 落盤格式(date · ticker · yfinance_ticker · bloomberg_ticker · name 在前 · `ticker=/year=` 分區 + 整合 parquet + 大寫表頭 CSV)寫 `consensus\\\\dataset`(tw_consensus · tw_consensus_estimate)→ 跟 TWSE / TPEX 日線合併 = `tw_market_consensus` + `output\\\\VRN2_MarketConsensus_latest`(增量庫也收)|
| ⑥e「擷取 YELLOW · 失敗 0」| = VDF 引擎回 rc 2(PARTIAL · 不是失敗)→ 收尾頁算「資料源」並寫錨點(VDF status.json · 哪幾檔 Yahoo 收盤 ≠ TWSE · 填值的缺是不是只有非台股代號)|
| SSOT 提案(沒有編號)| 這輪新增的規則(不用 MOPS 政策 · 同步還原參數 · MOPS 列記號 · TWSE / TPEX 識別欄 · 兩家中位數同義字 · 閘品質用字 · ⑥e 失敗 0 正則 · 合併參數)→ 提案冊 v0101 的 VRN2-PROP-0010 ~ 0017 · **ssot_id 空白** · ⑤b 送進核號請求 · 等 VCGC 偵測衝突後核發 · VRN-2 自動補填 |
| 套件 | `VRN2_Closeout_v0164.zip`(SHA-256 `%s` · 啟動器 v0164 · runtime v0157 = v0156 + ConsensusJoin v0105 + OutputStore v0102 + SSOTSync v0102 + 提案冊 v0101)|
| 一支 Python | `VRN2_RoundAll_v0120.py`(SHA-256 `%s` · 自測 78 項)|

共用 MarketFetch 與 VDF 引擎照舊只讀不改;MOPS 照舊不用(⑥e `--no-financial`)。

## 先看:你開的是哪一種視窗?

- 提示字元前面有 **PS** → PowerShell → 用「PowerShell 7 視窗」那段。
- 前面沒有 PS(例如 `[03:08:12.00] C:\\\\Users\\\\tonyk` 下一行 `>`)→ **cmd** → 用「cmd 視窗」那段。

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定)· 第 2 行 = 下面 PowerShell 那一行的編碼版(一樣核對 SHA-256 才執行)。要整輪才在第 2 行之前多貼 `set "VRN2_MODE=full"`。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)· 要整輪再貼 `$env:VRN2_MODE = 'full'`。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0112 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0120 `%s`)。

## 這次桌機貼下去會怎樣

- auto = repair:① 取套件 v0164 → ⑤ 計畫「combined:TARGET_PRICE(ADJ) 同步還原 + 共識照 TWSE / TPEX 格式合併(ConsensusJoin v0105)」
  「store:增量庫清掉 MOPS 算的列(先備份 · 可還原)+ 補寫」→ Workbench → 收尾頁自動開(幾分鐘 · 不重抓 ⑥e)。
- 增量庫:FinancialAligned / Deleted 裡 16:11 那輪用 MOPS 歷史算的列會被清掉(⑬ 那行寫清了幾列與備份夾名 · 收據 `VRN2_StorePurge_latest.json`)。
- 要整輪(full)才會用啟動器 v0164 從頭跑(約 40 分鐘)· 兩種模式結果一樣會清 MOPS 列。
- BLOCKED / REVIEW / DATA_GAP 都不是成功;VCGC 的 closeout_lamp 才是 VCGC 驗收。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0112.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0120.py(套件 v0164 · 增量庫清 MOPS 列 · TARGET_PRICE(ADJ) 同步還原 · TWSE / TPEX 格式合併)

`VRN2_RoundAll_v0120.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0119 + 操作員 2026-11-01:

| 改了什麼 | 說明 |
|---|---|
| 套件 v0164 | 啟動器 v0164 · runtime v0157 = v0156(192 個成員不動)+ ConsensusJoin v0105 + OutputStore v0102 + SSOTSync v0102 + 提案冊 v0101(這輪新規則 8 條 · 沒有編號 · 等 VCGC 核發)|
| ⑤ combined | 還沒同步還原 / 合併過 → 補放 ConsensusJoin v0105 鏈(只增不覆寫)→ 重組 Combined(TARGET_PRICE(ADJ) 同步還原 · 共識照 TWSE / TPEX 格式落盤 · 合併)|
| ⑤ store | 增量庫還沒確認乾淨 → 補放 OutputStore v0102 鏈 → sync(先清 MOPS 算的列 · 整檔備份到 `_mops_purge_<時間>` · 可 `restore-purge`)|
| 收尾頁 | ⑥e「擷取 YELLOW · 失敗 0」= VDF rc 2 PARTIAL → 資料源(寫錨點)· 「不用 MOPS」的說明字不再被當成 MOPS DENY · Combined MISSING 原因不因日期 / 比值拆類 |
| 貼回包 | 多收 `VRN2_StorePurge_latest.json` · `market\\\\VRN2_TPAdjSync_latest.json` · `market\\\\vdf\\\\status.json` · `output\\\\VRN2_MarketConsensus_latest.csv` |

自測 78 項(v0119 的 74 項 + 75 ~ 78)。套件 `vrn2_release_v0164/VRN2_Closeout_v0164.zip`(SHA-256 `%s` · 本檔內已釘死)。**最省事:`VRN2_HandleAll_v0112.md`(cmd / PowerShell 各一段)**。

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0120.py" --only package,fix,report,closeout,pasteback
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0120.py"
```
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0120.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0164 (ConsensusJoin v0105 · OutputStore v0102 · runtime v0157) + VRN2_RoundAll_v0120 + VRN2_HandleAll_v0112", "date": "2026-11-01",
        "trigger": "操作員 2026-11-01:「Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原才有可比較性 · 兩個單位所算的目標價中位數並存方便比較 · 最後把他跟 TWSE / TPEX 輸出個格式依樣在合併即可」"
                   " + 桌機 2026-11-01 03:08 收尾(RoundAll v0119 repair):OPEN · VRN-2 1 =「⑥e 擷取 YELLOW · 跑 10 次 · 失敗 0」· TARGET_PRICE(ADJ) MISSING 5(3706 / 6669)· 增量庫 FinancialAligned 16588 / Deleted 38",
        "policy": {"MOPS": "not used (step 6e --no-financial · quarantined on disk · now also purged from the long-term store with a backup)", "domestic": "TWSE / TPEX official lanes",
                   "yahoo": "kept (operator 2026-11-01): VDF engine's adjustment factor · TARGET_PRICE(ADJ) uses the same factor", "consensus": "kept: FactSet (cnyes) + YFinance medians side by side",
                   "format": "consensus written in the VDF (TWSE / TPEX) output format and merged with the TWSE / TPEX daily rows"},
        "base_package": {"name": "VRN2_Closeout_v0163 (launcher v0163 · runtime v0156)", "retained": "runtime v0156's 192 members byte-identical inside runtime v0157; every package member except launcher / runtime byte-identical to v0158 / v0163"},
        "fixes": {"ConsensusJoin_v0105": "thin tail over v0104: tp_adj_sync (VDF daily partitions read-only · VDF_ADJUSTED / SYNC_YAHOO_RATIO / MISSING with the real reason · evidence market/VRN2_TPAdjSync_latest.json incl. VDF status.json + per-ticker CLOSE_MISMATCH) · join on an augmented copy of the market JSON (file not modified) · STATUS names the rule · consensus_dataset: tw_consensus / tw_consensus_estimate / tw_market_consensus in the VDF layout under consensus/dataset + output/VRN2_MarketConsensus_latest · selftest 18",
                  "OutputStore_v0102": "thin tail over v0101: mops_marked / mops_index (Deleted all · FinancialAligned whole (run_id, file_sha) groups with a history marker) · purge-mops (dry run · --apply: DuckDB file copied + SHA-256 · removed rows to removed/<book>.parquet · touched run files moved + rewritten · PURGE_MANIFEST.json) · restore-purge · sync = purge then append (MOPS rows filtered · mops_skipped) · MarketConsensus dataset book (DATE, TICKER, row hash · not in catalog) · selftest duckdb + pyarrow",
                  "launcher_v0164": "runtime v0157 · step 6f loads ConsensusJoin v0105 · step 13 loads OutputStore v0102 (detail leads with the purge) · earlier selftest blocks get the active modules next to their priors · selftest block v0164",
                  "RoundAll_v0120": "package v0164 · step 5: combined when not yet synced (ConsensusJoin v0105 chain placed add-only) · store when the store is not confirmed clean (OutputStore v0102 chain placed add-only) · closeout: 6e 'fetch YELLOW · 0 failures' = VDF rc 2 PARTIAL → data source with the anchor · '不用 MOPS' text no longer read as MOPS DENY · Combined MISSING reasons not split by dates / ratios · paste-back + purge receipt / sync evidence / VDF status / merged book · selftest 78",
                  "SSOTSync_v0102": "thin tail over v0101 (flow unchanged): proposals book v0101 = v0100's 9 entries + 8 new (VRN2-PROP-0010 ~ 0017 · ssot_id blank · sent by step 5b for VCGC to conflict-test and number) · v0101's selftest isolated with only the v0100 book",
                  "HandleAll_v0112": "v0111 pointed at RoundAll v0120 (vrn2_release_v0164) · texts package v0164 / ConsensusJoin v0105 / store purge"},
        "not_fixed_here": {"3706_6669_tp_adj": "root cause not yet visible from the desktop (paste-back zip 2026-11-01 03:08 not uploaded): v0105 either synchronises (Yahoo split / stock-dividend adjustment) or writes the exact reason + evidence into market/VRN2_TPAdjSync_latest.json",
                           "6e_partial": "VDF rc 2 PARTIAL is the VDF engine's own quality verdict (read-only for VRN-2); anchored, not changed"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"changed": True},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0119.py", "sha256": r163["roundall"]["sha256"], "status": "superseded 2026-11-01 (package v0163); file kept in vrn2_release_v0163"}],
        "roundall": {"name": "VRN2_RoundAll_v0120.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0120.md"},
        "handleall": {"name": "VRN2_HandleAll_v0112.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0112_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0164/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0164.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0164.py"]).hexdigest()},
        "results": {"status": "see VRN2_Verification_v0164.md"}}
(rel / "VRN2_Release_v0164.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
