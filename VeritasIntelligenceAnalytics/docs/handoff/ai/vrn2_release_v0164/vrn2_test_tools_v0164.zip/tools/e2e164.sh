#!/bin/bash
# v0164 e2e:沙盒(桌機 v0153 狀態)+ 髒的增量庫(OutputStore v0101 收了 MOPS 列)+ 6669 報告日前 Yahoo 分割 → repair ⑤ combined(同步還原 · 合併)+ store(清 MOPS 列 · 備份)· 整輪啟動器 v0164 · 竄改 → 不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v164; T=$W/t164a; P=$S2/venv_vrn2/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
$P -I $W/seed164.py $T $W/rt > $W/seed164.log 2>&1; cat $W/seed164.log
B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164; mkdir -p $D
cp $W/release164/VRN2_Closeout_v0164.zip $W/release164/VRN2_Release_v0164.json $W/release164/VRN2_RoundAll_v0120.py $W/release164/VRN2_RoundAll_v0120.md $W/release164/VRN2_HandleAll_v0112.md $W/release164/VRN2_HandleAll_v0112_boot.txt $D/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release164/tiny_line.txt)
LINE="$LINE; 'PYPROG=' + (\$global:VIA_PYPROG_LAST | ConvertTo-Json -Compress)"
V2=$T/VIA/VIA_Reports/vrn2
run() { N=$1; shift; cd "$T/home" && env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 \
  VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2 "$@" timeout 3000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny164.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log;
  (cd $T/OneDrive/VRN2_out/VRN2 && find . -maxdepth 2 | sort) > $W/store_after_$N.txt 2>/dev/null; cp $V2/VRN2_StorePurge_latest.json $W/purge_$N.json 2>/dev/null; cp $V2/market/VRN2_TPAdjSync_latest.json $W/tpsync_$N.json 2>/dev/null; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; }
rm -f $W/tiny164.rc
run repair
run full VRN2_MODE=full
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164/VRN2_HandleAll_v0112_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny164.rc
