"""e2e 前置(沙盒):① 增量庫指到沙盒 OneDrive\\VRN2_out · 用 OutputStore v0101(舊版 · 不擋)收一輪帶 MOPS 歷史記號的 FinancialAligned / Deleted = 桌機 16:11 的樣子
② CLST-6669 的市場資料拿掉 TARGET_PRICE(ADJ)(MISSING)· VDF 日線 6669 寫成「報告日前 Yahoo 收盤 = TWSE × 0.5(分割)· 之後一致」→ 給 v0105 同步還原。"""
import datetime, importlib.util, json, sys
from pathlib import Path
T = Path(sys.argv[1]); v2 = T / "VIA" / "VIA_Reports" / "vrn2"; rt = Path(sys.argv[2])
out = T / "OneDrive" / "VRN2_out"
cfg = {"output_dir": str(out), "how": "e2e164", "ts": "2026-11-01T03:00:00", "cloud_hint": "OneDrive 同步夾"}
(v2 / "VRN2_Output_Config.json").write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
spec = importlib.util.spec_from_file_location("st101_seed", rt / "VRN2_OutputStore_v0101.py"); st = importlib.util.module_from_spec(spec); spec.loader.exec_module(st)
fa_p, dl_p = v2 / "output" / "VRN2_FinancialAligned_latest.json", v2 / "output" / "VRN2_Deleted_latest.json"
fa0, dl0 = fa_p.read_text(encoding="utf-8"), dl_p.read_text(encoding="utf-8")
st.sync(v2, None, "20261031_1433_e2e")
fa = json.loads(fa0); fn = fa[0]["FILENAME"]
mops = [dict(r, VALUE_FINAL=(r.get("VALUE_FINAL") or 0), VALUE_SOURCE="HISTORY(MOPS / TWSE)", RECON_RATIO=0.999) for r in fa if r.get("FILENAME") == fn][:30]
fa_p.write_text(json.dumps(fa + mops, ensure_ascii=False), encoding="utf-8")
dl_p.write_text(json.dumps(json.loads(dl0) + [{"FILENAME": fn, "ITEM": "Net income", "HISTORY_VALUE": 99.0, "DELETED_REASON": "與歷史數據差 > 3% → 歷史覆蓋"}], ensure_ascii=False), encoding="utf-8")
r = st.sync(v2, None, "20261031_1611_e2e")
fa_p.write_text(fa0, encoding="utf-8"); dl_p.write_text(dl0, encoding="utf-8")
print("seed store", r.get("appended", {}).get("FinancialAligned"), r.get("appended", {}).get("Deleted"), r.get("totals"))
mk = json.loads((v2 / "market" / "VRN2_Market_latest.json").read_text(encoding="utf-8"))
key = next(k for k in mk["per_file"] if k.startswith("CLST-6669"))
m = mk["per_file"][key]
for k in ("target_price_adj", "adjustment_factor_report", "adj_close_before_report", "adj_close_before_report_date", "upside_adj", "upside_pct_adj"):
    m.pop(k, None)
m.update(before_status="MISSING(報告日前沒有日資料 · 需 --start 回補)", adj_close=m.get("adj_close") or 3000.0)
(v2 / "market" / "VRN2_Market_latest.json").write_text(json.dumps(mk, ensure_ascii=False, indent=1), encoding="utf-8")
spec = importlib.util.spec_from_file_location("cj105_seed", rt / "VRN2_ConsensusJoin_v0105.py"); cj = importlib.util.module_from_spec(spec); spec.loader.exec_module(cj)
D = datetime.date
rows = [{"date": D(2025, 9, 24) + datetime.timedelta(days=i), "ticker": "6669", "yfinance_ticker": "6669.TW", "bloomberg_ticker": "6669 TT", "name": "緯穎", "market": "TWSE",
         "close": 3000.0 + 10 * i, "adj_close": None, "volume": 1000.0, "yf_close": (3000.0 + 10 * i) * 0.5, "yf_adj_close": (3000.0 + 10 * i) * 0.5 * 0.97, "close_check": "MISMATCH",
         "adjustment_status": "CLOSE_MISMATCH"} for i in range(7)]
late = [{"date": D(2026, 10, 30), "ticker": "6669", "yfinance_ticker": "6669.TW", "bloomberg_ticker": "6669 TT", "name": "緯穎", "market": "TWSE", "close": float(m["adj_close"]),
         "adj_close": float(m["adj_close"]), "volume": 2000.0, "yf_close": float(m["adj_close"]), "yf_adj_close": float(m["adj_close"]), "close_check": "MATCH", "adjustment_status": "ADJUSTED"}]
cols = ["date", "ticker", "yfinance_ticker", "bloomberg_ticker", "name", "close", "adj_close", "volume", "yf_close", "yf_adj_close", "close_check", "adjustment_status", "market"]
base = v2 / "market" / "vdf" / "parquet" / "tw_equity_daily" / "ticker=6669"
cj.write_parquet(rows, cols, base / "year=2025" / "data.parquet"); cj.write_parquet(late, cols, base / "year=2026" / "data.parquet")
(v2 / "market" / "vdf" / "status.json").write_text(json.dumps({"status": "PARTIAL", "issues": [], "datasets": {"daily": {"quality": {"REVIEW": 7, "OK": 1}}}}), encoding="utf-8")
print("seed 6669", key, m.get("adj_close"))
