"""VRN2_RoundAll_v0120.py = v0119(倉裡 vrn2_release_v0163)+ 操作員 2026-11-01:增量庫 MOPS 列清掉 · TARGET_PRICE(ADJ) 同步還原 · 兩家中位數並存 ·
共識照 TWSE / TPEX 格式合併 · ⑥e「擷取 YELLOW · 失敗 0」的錨點 · 套件 v0164(啟動器 v0164 · runtime v0157)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v164")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0163/VRN2_RoundAll_v0119.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0119')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0119 — ', '"""VRN2_RoundAll v0120 — ', 1)
at = doc.index("v0119(操作員 2026-10-31:「不可用 MOPS")
doc = doc[:at] + '''v0120(操作員 2026-11-01:「Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原才有可比較性 · 兩個單位所算的目標價中位數
並存方便比較 · 最後把他跟 TWSE / TPEX 輸出格式一樣再合併」· 桌機 2026-11-01 03:08 收尾 OPEN · VRN-2 1 =「⑥e 擷取 YELLOW · 跑 10 次 · 失敗 0」):
  · 套件 v0164(啟動器 v0164 · runtime v0157 = v0156 的 192 個成員不動 + ConsensusJoin v0105 + OutputStore v0102):
      ⑥f ConsensusJoin v0105:TARGET_PRICE(ADJ) 同步還原(報告日前那天 Yahoo 收盤 ≠ TWSE 收盤時,比值報告日前一致、報告日後回到一致 → 因子 =
      Yahoo 還原收盤 ÷ TWSE 收盤;其他照舊 MISSING 寫實原因)· 兩家中位數照舊並存 · 共識照 TWSE / TPEX(VDF)落盤格式寫 consensus\\\\dataset
      (tw_consensus · tw_consensus_estimate)再跟 TWSE / TPEX 日線合併(tw_market_consensus · output\\\\VRN2_MarketConsensus_latest)。
      ⑬ OutputStore v0102:增量庫先把 MOPS 歷史算出來的列清掉(Deleted 全部 · FinancialAligned 帶歷史記號的整組)→ 先整檔備份到
      <輸出夾>\\\\VRN2\\\\_mops_purge_<時間>(restore-purge 換回)· 以後不再收 · 多一本 MarketConsensus。
  · ⑤ 自動修:增量庫還沒確認乾淨(VRN2_StorePurge_latest.json 不是「已清 · 綠」)→ store(OutputStore v0102 從套件 runtime 只增不覆寫地補放)·
    還沒同步還原過(market\\\\VRN2_TPAdjSync_latest.json 不在或比市場資料舊)→ combined(ConsensusJoin v0105 鏈補放)→ store → Workbench。
  · 收尾頁:⑥e「擷取 YELLOW · 失敗 0」= VDF 引擎回 rc 2(PARTIAL · 不是失敗 · 多半是 Yahoo 收盤與 TWSE 收盤對不上的日子 = REVIEW)→ 負責方
    資料源(不再算 VRN-2 未結案)· 寫錨點:VDF status.json · 哪幾檔幾列 MISMATCH · 填值的缺是不是只有非台股代號(AAPL)。
    Combined 的 TARGET_PRICE(ADJ) 缺照原因分(MISSING(…) → 資料源 · 同一類不因日期 / 比值不同拆成多類)。
  · 貼回包多收 VRN2_StorePurge_latest.json · market\\\\VRN2_TPAdjSync_latest.json · market\\\\vdf\\\\status.json · output\\\\VRN2_MarketConsensus_latest.csv。
  · SSOT 提案(操作員重申:VRN-2 / VDF 因應問題新增的 SSOT / 正則 / 同義字 / 邏輯 / 政策沒有編號 → VCGC 偵測衝突後公布 → VRN-2 自動補入):
    這輪新規則 8 條進提案冊 v0101(VRN2-PROP-0010 ~ 0017 · ssot_id 空白)· ⑤b 送核號請求 · ③ 自測改跑 SSOTSync v0102(v0101 的自測隔離跑)。
  · 自測 78 項(v0119 的 74 項 + 75 ~ 78)。共用 MarketFetch 與 VDF 引擎照舊只讀不改。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0119.py", "用法:python VRN2_RoundAll_v0120.py")
body = body.replace("v0163", "v0164")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0119"', 'VERSION = "v0120"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0119.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0120.py"', 2)
rep('"VRN2_RoundAll_v0119.py" in html_', '"VRN2_RoundAll_v0120.py" in html_')
rep('PACKAGE_SHA256 = "fd216929c5f19b4031043fbf788e128c57f5dcc2eb6ec9399e08167303a23782"', 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0156.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0157.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0156.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0157.json"')
rep("· v0118 起 72 項 · v0119 起 74 項。", "· v0118 起 72 項 · v0119 起 74 項 · v0120 起 78 項。")
rep('("VRN2_OutputStore_v0101.py", 300), ("VRN2_ConsensusJoin_v0104.py", 900)', '("VRN2_OutputStore_v0102.py", 300), ("VRN2_ConsensusJoin_v0105.py", 900)')
rep('("VRN2_SSOTSync_v0101.py", 300)', '("VRN2_SSOTSync_v0102.py", 300)')
rep('''               "VRN2_FinFailEvidence_latest.json")''', '''               "VRN2_FinFailEvidence_latest.json", "VRN2_StorePurge_latest.json", "market/VRN2_TPAdjSync_latest.json", "market/vdf/status.json",
               "output/VRN2_MarketConsensus_latest.csv")''')
assert 'PACKAGE = "VRN2_Closeout_v0164"' in s and 'LAUNCHER = "ActivateVRN-2_v0164.py"' in s and 'RECEIPT = "VRN2_Closeout_v0164.json"' in s and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0164"' in s

# ---- 共用:增量庫乾淨了沒 · 同步還原做過沒 ----
rep('''def market_fetch_sec() -> int:''', '''STORE_PURGE = "VRN2_StorePurge_latest.json"                                # v0120 OutputStore v0102 清 MOPS 列的收據
TP_SYNC = "VRN2_TPAdjSync_latest.json"                                       # v0120 ConsensusJoin v0105 同步還原的證據(market\\\\)
STORE_CHAIN = ("VRN2_OutputStore_v0102.py", "VRN2_OutputStore_v0101.py", "VRN2_OutputStore_v0100.py")


def store_clean(v2) -> bool:
    """v0120 增量庫確認沒有 MOPS 算的列了嗎:OutputStore v0102 清過(apply)且綠(這次清了幾列都算乾淨)。"""
    r = jread(Path(v2) / STORE_PURGE, {}) or {}
    return bool(r.get("apply")) and r.get("lamp") == "GREEN"


def tp_sync_due(v2) -> bool:
    """v0120 還沒用 ConsensusJoin v0105 同步還原 / 合併過(證據不在 · 比市場資料舊 · 合併冊不在)。"""
    v2 = Path(v2)
    m, t = v2 / "market" / "VRN2_Market_latest.json", v2 / "market" / TP_SYNC
    return m.is_file() and (not t.is_file() or _mtime(m) > _mtime(t) or not (v2 / "output" / "VRN2_MarketConsensus_latest.json").is_file())


def e_partial_reason(ctx: dict) -> str:
    """v0120 ⑥e「擷取 YELLOW · 失敗 0」的錨點:VDF 引擎回 rc 2 = PARTIAL(不是失敗)· 哪幾檔 Yahoo 收盤 ≠ TWSE · 填值的缺是不是只有非台股代號。"""
    sync = ctx.get("tp_sync") or {}
    vdf = sync.get("vdf") or {}
    mm = vdf.get("tickers") or {}
    parts = ["VDF 引擎回 rc 2(PARTIAL · 不是失敗 · 價格照收)"]
    if vdf.get("status"):
        parts.append("VDF status.json %s%s" % (vdf.get("status"), (" · 日線品質 %s" % json.dumps(vdf.get("daily_quality"), ensure_ascii=False)) if vdf.get("daily_quality") else ""))
    if mm:
        parts.append("Yahoo 收盤 ≠ TWSE(CLOSE_MISMATCH)%s" % "、".join("%s %d 列(%s)" % (c, int(v.get("mismatch") or 0), v.get("mismatch_dates") or "—") for c, v in sorted(mm.items()) if v.get("mismatch"))[:220])
    miss = ctx.get("market_missing") or {}
    if miss:
        parts.append("填值缺 %s" % "、".join("%s %d" % kv for kv in sorted(miss.items())))
    if sync.get("counts"):
        parts.append("TARGET_PRICE(ADJ) 同步還原 %s(ConsensusJoin v0105)" % json.dumps(sync["counts"], ensure_ascii=False))
    if len(parts) == 1:
        parts.append("沒有同步還原證據(market\\\\VRN2_TPAdjSync_latest.json)· 套件 v0164 的 ⑥f 會寫")
    return " · ".join(parts)


def market_fetch_sec() -> int:''')

# ---- 收尾頁:⑥e 失敗 0 → 資料源(錨點)· Combined MISSING 原因不拆 ----
rep('''        if ctx.get("mops_deny"):
            return "VCGC", "VDF 引擎打 MOPS 財報被 VIA 網路工具 DENY(價格照抓)→ VCGC 決定"
        return "VRN-2", ""''', '''        if ctx.get("mops_deny"):
            return "VCGC", "VDF 引擎打 MOPS 財報被 VIA 網路工具 DENY(價格照抓)→ VCGC 決定"
        if re.search(r"失敗 0\\b", detail) and not re.search(r"擷取 RED|逾時|Traceback|致命錯", detail):    # v0120 VDF rc 2 PARTIAL(跑 N 次 · 失敗 0)
            return "資料源", e_partial_reason(ctx)
        return "VRN-2", ""''')
rep('''    ctx["combined_now"] = isinstance(comb, list) and bool(comb)
    return ctx''', '''    ctx["combined_now"] = isinstance(comb, list) and bool(comb)
    ctx["tp_sync"] = jread(v2 / "market" / TP_SYNC, {}) or {}                  # v0120 ⑥e 錨點 + 同步還原
    miss = {}
    for r in ((jread(v2 / "market" / "VRN2_Market_latest.json", {}) or {}).get("per_file") or {}).values():
        if isinstance(r, dict) and r.get("status") == "MISSING":
            why = "非台股代號(範圍外)" if "代號不是 4 碼" in str(r.get("reason") or "") else str(r.get("reason") or "?")[:30]
            miss[why] = miss.get(why, 0) + 1
    ctx["market_missing"] = miss
    return ctx''')
rep('''                elif re.search(r"報告日前沒有日資料|MISSING|沒有目標價或還原因子", why):
                    add("TARGET_PRICE(ADJ)", why[:40], "資料源", fname)''', '''                elif re.search(r"報告日前沒有日資料|MISSING|沒有目標價或還原因子", why):
                    add("TARGET_PRICE(ADJ)", re.sub(r"\\d{4}-\\d{2}-\\d{2}|\\d+(?:\\.\\d+)?%?", "#", why)[:40], "資料源", fname)   # v0120 日期 / 比值不拆類''')

rep('''    if re.search(r"MOPS|network bridge denied", text) or "網路工具 DENY" in text and not re.search(r"⑥f|⑥ Combined 冊", step):   # v0112 ⑥f 共識的 DENY 下面分''',
    '''    text_m = re.sub(r"不用 MOPS[^·|]*|MOPS 財報移[^·|]*|_mops_quarantine\\S*|MOPS 財報已經不在", "", text)          # v0120 「不用 MOPS」的說明字不是 DENY
    if re.search(r"MOPS|network bridge denied", text_m) or "網路工具 DENY" in text_m and not re.search(r"⑥f|⑥ Combined 冊", step):   # v0112 ⑥f 共識的 DENY 下面分''')

# ---- 診斷:同步還原 / ⑥e 錨點(資訊列)----
rep('''    hist = jread(v2 / "VRN2_HistoryAlign_latest.json", {}) or {}
    if hist:
        f(hist.get("lamp", "GRAY"), "歷史對齊", str(hist.get("why", ""))[:240])''', '''    tps = jread(v2 / "market" / TP_SYNC, {}) or {}                            # v0120 ConsensusJoin v0105 的證據(資訊列 · 缺的照 Combined 那列分)
    if tps:
        vq = tps.get("vdf") or {}
        f("GRAY", "TARGET_PRICE(ADJ) 同步還原 · ⑥e 錨點", "%s · VDF status %s · CLOSE_MISMATCH %s" % (tps.get("why", ""), vq.get("status") or "—",
          "、".join("%s %s 列" % (c, v.get("mismatch")) for c, v in sorted((vq.get("tickers") or {}).items()) if v.get("mismatch")) or "無"))
    purge = jread(v2 / STORE_PURGE, {}) or {}
    if purge:
        f("GRAY" if purge.get("lamp") != "RED" else "RED", "增量庫 MOPS 列", "%s · %s" % (purge.get("why", ""), purge.get("folder") or ""))
    hist = jread(v2 / "VRN2_HistoryAlign_latest.json", {}) or {}
    if hist:
        f(hist.get("lamp", "GRAY"), "歷史對齊", str(hist.get("why", ""))[:240])''')

# ---- ⑤ 計畫:同步還原 / 清 MOPS 列 ----
rep('''    if (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and (planned & {"market", "consensus", "consensus_refresh"} or not comb.is_file() or max(_mtime(mjson), _mtime(cjson)) > _mtime(comb)):
        plan.append(("combined", "Combined 比市場 / 共識舊(或不在)→ 重組"))''', '''    if (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and (planned & {"market", "consensus", "consensus_refresh"} or not comb.is_file() or max(_mtime(mjson), _mtime(cjson)) > _mtime(comb)):
        plan.append(("combined", "Combined 比市場 / 共識舊(或不在)→ 重組"))
    elif (v2 / "output" / "VRN2_BasicInfo_latest.json").is_file() and tp_sync_due(v2):                # v0120
        plan.append(("combined", "TARGET_PRICE(ADJ) 同步還原 + 共識照 TWSE / TPEX 格式合併(ConsensusJoin v0105)→ 重組 Combined"))''')
rep('''    if cfg.get("output_dir") and (planned or missing_books):
        plan.append(("store", "⑬ 增量庫補寫(%s)" % ("本輪有修正" if planned else "庫裡還沒有 " + "、".join(missing_books))))''', '''    dirty = cfg.get("output_dir") and not store_clean(v2) and os.environ.get("VIA_VRN2_NO_MOPS_PURGE") != "1"   # v0120 增量庫還沒確認清掉 MOPS 列
    if cfg.get("output_dir") and (planned or missing_books or dirty):
        plan.append(("store", "⑬ 增量庫%s補寫(%s)" % ("清掉 MOPS 算的列(先備份 · 可還原)+ " if dirty else "", "本輪有修正" if planned else ("庫裡還沒有 " + "、".join(missing_books) if missing_books else "OutputStore v0102"))))''')

# ---- ⑤ 計畫:市場資料還帶 MOPS 財報(v0163 以前填的 financial_annual)→ 只重新填值 ----
rep('''    lk = vdf_lock_state(v2)                                                    # v0117 ⑥e 擷取鎖''', '''    mk_now = jread(v2 / "market" / "VRN2_Market_latest.json", {}) or {}         # v0120 v0163 以前填的市場資料還帶 MOPS 財報 → ⑬b 會拿去對
    stale_fin = [f for f, r in (mk_now.get("per_file") or {}).items() if isinstance(r, dict) and r.get("financial_annual")]
    if (stale_fin and not mops_on_disk and market_tool and fetch_py and os.environ.get("VIA_VRN2_NO_MARKET") != "1"):
        plan.append(("market_fill", "市場資料還帶 %d 份 MOPS 財報(financial_annual · v0163 以前填的)→ 只重新填值(不重抓 · 不用 MOPS)· ⑬b 跟著重算" % len(stale_fin)))
    lk = vdf_lock_state(v2)                                                    # v0117 ⑥e 擷取鎖''')
rep('''    if mjson.is_file() and ("market" in planned or not hrec.is_file()''', '''    if mjson.is_file() and (planned & {"market", "market_fill"} or not hrec.is_file()''')
rep('''and (planned & {"market", "consensus", "consensus_refresh"} or not comb.is_file()''', '''and (planned & {"market", "market_fill", "consensus", "consensus_refresh"} or not comb.is_file()''')
rep('''        if key == "market":
            tool, basic = Path(state["market_tool"]), v2 / "output" / "VRN2_BasicInfo_latest.json"''', '''        if key in ("market", "market_fill"):                                   # v0120 market_fill = 只重新填值
            tool, basic = Path(state["market_tool"]), v2 / "output" / "VRN2_BasicInfo_latest.json"''')
rep('''            for verb in ("--fetch", "--fill"):
                head = [py, "-X", "utf8", str(runner), "--tool", str(tool), "--python", py] if runner.is_file() else [py, "-X", "utf8", str(tool)]''', '''            for verb in (("--fetch", "--fill") if key == "market" else ("--fill",)):
                head = [py, "-X", "utf8", str(runner), "--tool", str(tool), "--python", py] if runner.is_file() else [py, "-X", "utf8", str(tool)]''')
rep('''            detail = "擷取 %s:%s · 填值 %s:%s" % (lamps[0][0], lamps[0][1], lamps[-1][0], lamps[-1][1])
            step_updates["⑥e"] = (lamp, detail)''', '''            detail = ("擷取 %s:%s · 填值 %s:%s" % (lamps[0][0], lamps[0][1], lamps[-1][0], lamps[-1][1]) if key == "market"
                      else "只重新填值(不重抓 · 不用 MOPS)· 填值 %s:%s" % (lamps[-1][0], lamps[-1][1]))
            step_updates["⑥e"] = (lamp, detail)''')

# ---- ⑤ 執行:combined 先補放 v0105 鏈 · store 先補放 v0102 鏈 ----
rep('''        elif key == "combined":
            cj = _latest_in(rt, "VRN2_ConsensusJoin_v[0-9][0-9][0-9][0-9].py")''', '''        elif key == "combined":
            if state.get("pkg"):
                place_consensus(state.get("pkg"), root)                         # v0120 ConsensusJoin v0105 鏈只增不覆寫地補放
            cj = _latest_in(rt, "VRN2_ConsensusJoin_v[0-9][0-9][0-9][0-9].py")''')
rep('''        elif key == "store":
            st = _latest_in(rt, "VRN2_OutputStore_v[0-9][0-9][0-9][0-9].py")''', '''        elif key == "store":
            refused = []
            for name in STORE_CHAIN if state.get("pkg") else ():                # v0120 OutputStore v0102 鏈只增不覆寫地補放
                try:
                    dest, why = install_runtime_member(state.get("pkg"), root, name)
                except (OSError, KeyError, zipfile.BadZipFile) as error:
                    dest, why = None, "%s: %s" % (type(error).__name__, str(error)[:80])
                if dest is None:
                    refused.append(why)
            st = _latest_in(rt, "VRN2_OutputStore_v[0-9][0-9][0-9][0-9].py")''')
rep('''                detail = "%s · 追加 %s · 補缺 %s · 累計 %s" % (rec.get("store_engine", ""), json.dumps(rec.get("appended") or {}, ensure_ascii=False), json.dumps(rec.get("backfilled") or {}, ensure_ascii=False), json.dumps(rec.get("totals") or {}, ensure_ascii=False))
            step_updates["⑬ "] = (lamp, detail)''', '''                detail = "%s · 追加 %s · 補缺 %s · 累計 %s" % (rec.get("store_engine", ""), json.dumps(rec.get("appended") or {}, ensure_ascii=False), json.dumps(rec.get("backfilled") or {}, ensure_ascii=False), json.dumps(rec.get("totals") or {}, ensure_ascii=False))
                pg = rec.get("mops_purge") or {}
                if pg.get("removed_total") or pg.get("lamp") == "RED":
                    detail = "清 MOPS 列 %s(備份 %s)· %s" % (json.dumps(pg.get("removed") or {}, ensure_ascii=False), Path(str(pg.get("folder") or "")).name or "—", detail)
            if refused:
                detail = "%s · 不覆寫:%s" % (detail, " / ".join(refused)[:160])
            step_updates["⑬ "] = (lamp, detail)''')

# ---- 自測 75 ~ 78 ----
rep('''        src64 = Path(__file__).read_text(encoding="utf-8")''', '''        ctx75 = {"tp_sync": {"vdf": {"status": "PARTIAL", "daily_quality": {"REVIEW": 9}, "tickers": {"3706": {"mismatch": 7, "mismatch_dates": "2025-08-15 ~ 2025-11-27"}}},
                             "counts": {"SYNC_YAHOO_RATIO": 3, "MISSING": 2}}, "market_missing": {"非台股代號(範圍外)": 1}}
        row75 = {"lamp": "YELLOW", "step": "⑥ 步驟 ⑥e 市場擷取", "detail": "RoundAll 修正後 · 擷取 YELLOW:VDF AllInOne_v039 增量 · 跑 10 次 · 失敗 0 · 09-18~10-04(2檔) rc0 · 填值 YELLOW:缺 1"}
        o75 = owner_of(row75, ctx75)
        o75b = owner_of(dict(row75, detail=row75["detail"].replace("失敗 0", "失敗 2")), ctx75)
        o75c = owner_of(dict(row75, detail="擷取 RED:逾時 5400 秒 · 失敗 0"), ctx75)
        o75d = owner_of({"lamp": "YELLOW", "step": "⑥ 步驟 ⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 Market", "detail": "VRN2_MarketFetch_v0112.py · Python C:/py · 不用 MOPS(--no-financial)"
                         " · MOPS 財報移到 _mops_quarantine_20261101_0300 · 擷取 YELLOW:VDF 增量 · 跑 10 次 · 失敗 0 · 填值 YELLOW:缺 1"}, ctx75)
        o75e = owner_of({"lamp": "YELLOW", "step": "⑥ ⑥e MOPS 財報被拒(VIA 網路工具 DENY)", "detail": "Existing VIA network bridge denied mopsov"}, ctx75)
        chk("75 ⑥e「擷取 YELLOW · 失敗 0」= VDF rc 2 PARTIAL → 資料源(錨點:status PARTIAL · 3706 MISMATCH 7 列 · 填值缺 = 非台股 · 同步還原 3)· 失敗 2 → VRN-2 · 逾時照舊 VRN-2 · 「不用 MOPS」說明字不算 DENY(真的 DENY 照舊 VCGC)",
            o75 and o75[0] == "資料源" and "rc 2" in o75[1] and "3706 7 列" in o75[1] and "非台股代號" in o75[1] and "SYNC_YAHOO_RATIO" in o75[1]
            and o75b[0] == "VRN-2" and o75c[0] == "VRN-2" and o75d[0] == "資料源" and o75e[0] == "VCGC")
        v76 = td / "v76"
        o76 = v76 / "VIA_Reports" / "vrn2"
        (o76 / "output").mkdir(parents=True)
        (o76 / "market").mkdir()
        (o76 / "output" / "VRN2_BasicInfo_latest.json").write_text("[]", encoding="utf-8")
        (o76 / "output" / "VRN2_Combined_latest.json").write_text("[]", encoding="utf-8")
        (o76 / "market" / "VRN2_Market_latest.json").write_text("{}", encoding="utf-8")
        (o76 / "VRN2_HistoryAlign_latest.json").write_text("{}", encoding="utf-8")
        (o76 / "VRN2_Output_Config.json").write_text(json.dumps({"output_dir": str(td / "out76")}), encoding="utf-8")
        (o76 / "VRN2_OutputStore_latest.json").write_text(json.dumps({"totals": {"Combined": 1, "FinancialAligned": 16588, "Deleted": 38}}), encoding="utf-8")
        os.utime(o76 / "output" / "VRN2_Combined_latest.json", (time.time() + 5, time.time() + 5))
        os.utime(o76 / "VRN2_HistoryAlign_latest.json", (time.time() + 5, time.time() + 5))
        p76a = dict(plan_fixes(v76, {"steps": []}, None, A(), ""))
        (o76 / "VRN2_StorePurge_latest.json").write_text(json.dumps({"apply": True, "lamp": "GREEN", "removed_total": 4622}), encoding="utf-8")
        (o76 / "market" / "VRN2_TPAdjSync_latest.json").write_text("{}", encoding="utf-8")
        (o76 / "output" / "VRN2_MarketConsensus_latest.json").write_text("[]", encoding="utf-8")
        os.utime(o76 / "market" / "VRN2_TPAdjSync_latest.json", (time.time() + 9, time.time() + 9))
        p76b = dict(plan_fixes(v76, {"steps": []}, None, A(), ""))
        (o76 / "market" / "VRN2_Market_latest.json").write_text(json.dumps({"per_file": {"a.pdf": {"financial_annual": [{"year": 2024, "std": "revenue", "value": 1.0}]}}}), encoding="utf-8")
        p76c = [k for k, _ in plan_fixes(v76, {"steps": []}, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")]
        p76d = [k for k, _ in plan_fixes(v76, {"steps": []}, None, A(), "")]
        chk("76 ⑤ 計畫:增量庫沒確認乾淨 → store「清掉 MOPS 算的列(先備份 · 可還原)」· 沒同步還原過 → combined(ConsensusJoin v0105)· 清過且綠 + 同步還原比市場新 → 都不排 · 市場資料還帶 MOPS 財報 → market_fill(只重新填值)→ ⑬b → Combined",
            "store" in p76a and "清掉 MOPS" in p76a["store"] and "combined" in p76a and "ConsensusJoin v0105" in p76a["combined"] and "store" not in p76b and "combined" not in p76b
            and p76c[:1] == ["market_fill"] and "history" in p76c and "combined" in p76c and "market" not in p76c and "market_fill" not in p76d)
        comb77 = [{"FILENAME": "a.pdf", "TICKER": "3706", "TARGET_PRICE": "128", "TARGET_PRICE(ADJ)": "", "STATUS": "TARGET_PRICE(ADJ): 缺:MISSING(VDF 日線最早 2026-03-02 · 報告日 2025-11-28 前沒有資料 · ⑥e 視窗沒抓到 · 需回補)"},
                  {"FILENAME": "b.pdf", "TICKER": "6669", "TARGET_PRICE": "4000", "TARGET_PRICE(ADJ)": "", "STATUS": "TARGET_PRICE(ADJ): 缺:MISSING(VDF 日線最早 2026-04-01 · 報告日 2025-10-01 前沒有資料 · ⑥e 視窗沒抓到 · 需回補)"},
                  {"FILENAME": "c.pdf", "TICKER": "6669", "TARGET_PRICE": "4000", "TARGET_PRICE(ADJ)": "", "STATUS": "TARGET_PRICE(ADJ): 缺:MISSING(Yahoo 收盤 ÷ TWSE 收盤 報告日前 5 天不一致 · 0.5012 差 1.20% · 不像除權 / 分割的追溯調整 · 不猜)"}]
        g77, own77 = combined_gaps(comb77)
        chk("77 Combined TARGET_PRICE(ADJ) 缺:同步還原寫的 MISSING(…) 原因 → 資料源 · 日期 / 比值不同不拆類(2 類 · 3 份)",
            own77 == "資料源" and len([k for k in g77["TARGET_PRICE(ADJ)"]]) == 2 and sum(g77["TARGET_PRICE(ADJ)"].values()) == 3)
        chk("78 套件 v0164(啟動器 v0164 · runtime v0157)· ③ 自測跑 OutputStore v0102 / ConsensusJoin v0105 · 貼回包收清 MOPS 列收據 / 同步還原證據 / VDF status / 合併冊 · ⑤ 補放 v0102 鏈",
            PACKAGE == "VRN2_Closeout_v0164" and LAUNCHER == "ActivateVRN-2_v0164.py" and RUNTIME_ZIP == "VRN2_Runtime_v0157.zip"
            and ("VRN2_OutputStore_v0102.py", 300) in SELFTESTS and ("VRN2_ConsensusJoin_v0105.py", 900) in SELFTESTS and ("VRN2_ConsensusJoin_v0104.py", 900) not in SELFTESTS
            and ("VRN2_SSOTSync_v0102.py", 300) in SELFTESTS and ("VRN2_SSOTSync_v0101.py", 300) not in SELFTESTS
            and all(p in PASTE_FILES for p in ("VRN2_StorePurge_latest.json", "market/VRN2_TPAdjSync_latest.json", "market/vdf/status.json", "output/VRN2_MarketConsensus_latest.csv"))
            and STORE_CHAIN[0] == "VRN2_OutputStore_v0102.py")
        src64 = Path(__file__).read_text(encoding="utf-8")''')
out = W / "new" / "VRN2_RoundAll_v0120.py"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0120 lines", s.count("\n"), "· v0163 left in body:", len(re.findall("v0163", s[s.index('VERSION = "v0120"'):])))
