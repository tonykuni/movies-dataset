VRN2_Closeout_v0164 — VRN-2 closeout package (2026-11-01 · store MOPS rows purged · TARGET_PRICE(ADJ) sync · consensus in the TWSE / TPEX format)

Entry: python ActivateVRN-2_v0164.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0120.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0112.md (same release folder).
Runtime: VRN2_Runtime_v0157.zip = v0156 (192 members byte-identical) + VRN2_ConsensusJoin_v0105 + VRN2_OutputStore_v0102 + VRN2_SSOTSync_v0102 + VRN2_SSOT_Proposals_v0101.json.

v0164 (operator 2026-11-01 'Yahoo 和共識照用 · 增量庫 MOPS 資料清掉 · Target Price(Adj) 也應該同步還原 · 兩家中位數並存 · TWSE/TPEX 格式合併'):
 step 6f ConsensusJoin v0105: TARGET_PRICE(ADJ) synchronous adjustment (Yahoo adj close / TWSE close when Yahoo's close carries a retroactive
 split / stock-dividend adjustment) · FactSet and YFinance medians side by side · consensus in the VDF (TWSE / TPEX) output format under
 consensus/dataset, merged with the TWSE / TPEX daily rows (tw_market_consensus). Step 13 OutputStore v0102: MOPS-derived rows purged from the
 long-term store after a full backup (<out>/VRN2/_mops_purge_<stamp> · restore-purge) · never appended again · MarketConsensus book.
v0163 (operator 2026-10-31 '不可用 MOPS · 全部國內使用 TWSE TPEX'): step 6e passes --no-financial to the shared MarketFetch --fetch, so the
 borrowed VDF engine never asks MOPS for financial statements; prices / indices / universe stay on the official TWSE / TPEX lanes. MOPS financial
 data already on disk (market/vdf/parquet/tw_financial, market/vdf/tw_financial.parquet) is moved (not deleted) to market/vdf/_mops_quarantine_<stamp>.
v0158: step 3b OCR environment: no venv, no pip from VRN-2 · v0157: step 3 check-only · missing packages through VCGC's install gate.
Verification: see VRN2_Verification_v0164.md. Hashes: PACKAGE_SHA256.json.
