param($W)
$e1 = $null; [System.Management.Automation.Language.Parser]::ParseFile("$W/operator103/Run-VRN1-VRN2-v0103.ps1", [ref]$null, [ref]$e1) | Out-Null; "operator v0103 parse errors: $($e1.Count)"
$e2 = $null; [System.Management.Automation.Language.Parser]::ParseFile("$W/release142/Run-VRN2-v0142.ps1", [ref]$null, [ref]$e2) | Out-Null; "vrn2 one-click v0142 parse errors: $($e2.Count)"
$e3 = $null; [System.Management.Automation.Language.Parser]::ParseFile("$W/release142/boot142.ps1", [ref]$null, [ref]$e3) | Out-Null; "boot142 parse errors: $($e3.Count)"
$e4 = $null; [System.Management.Automation.Language.Parser]::ParseFile("$W/operator103/boot_pair103.ps1", [ref]$null, [ref]$e4) | Out-Null; "boot_pair103 parse errors: $($e4.Count)"
function Sha([string]$s) { -join ([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($s)) | ForEach-Object { $_.ToString('x2') }) }
$md = [IO.File]::ReadAllText("$W/operator103/VRN1_VRN2_OneClick_v0103.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code = [regex]::Match($md, '(?s)```powershell\n(.*?)\n```').Groups[1].Value
$boot = [regex]::Match($md, '(?s)```text\n(.*?)\n```').Groups[1].Value
$H = [regex]::Match($boot, "\`$H  = '([0-9a-f]{64})'").Groups[1].Value
"operator md: code sha = boot H → $((Sha $code) -eq $H) ($((Sha $code).Substring(0,12)))"
$one = [regex]::Match($md, '(?s)```bat\n(.*?)\n```').Groups[1].Value; $b64 = $one.Split(' ')[-1]
"operator one-liner decodes to boot → $(([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($b64))) -eq ($boot + "`n"))"
$md2 = [IO.File]::ReadAllText("$W/release142/VRN2_OneClick_v0142.md", [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code2 = [regex]::Match($md2, '(?s)```powershell\n(.*?)\n```').Groups[1].Value
$H2 = [regex]::Match($code, "\`$H2 = '([0-9a-f]{64})'").Groups[1].Value
"vrn2 v0142 code sha = operator H2 → $((Sha $code2) -eq $H2) ($((Sha $code2).Substring(0,12)))"
$boot2 = [regex]::Match($md2, '(?s)```text\n(.*?)\n```').Groups[1].Value; $Hb = [regex]::Match($boot2, "\`$H  = '([0-9a-f]{64})'").Groups[1].Value
"vrn2 v0142 code sha = its boot H → $((Sha $code2) -eq $Hb)"
$want = [regex]::Match($code2, "\`$Want   = '([0-9a-f]{64})'").Groups[1].Value
"vrn2 one-click Want = release zip sha → $((Get-FileHash -LiteralPath "$W/release142/VRN2_Closeout_v0142.zip" -Algorithm SHA256).Hash.ToLower() -eq $want)"
