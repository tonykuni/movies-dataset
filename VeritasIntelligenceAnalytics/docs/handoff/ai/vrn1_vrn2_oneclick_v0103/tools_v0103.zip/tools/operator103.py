"""操作員一鍵 v0103:從倉裡的 VRN1_VRN2_OneClick_v0102.md 取程式碼 → ② 改指 VRN-2 一鍵 v0142(發行夾 vrn2_release_v0142 · 程式碼雜湊)→ 重算本段 SHA / boot / 一行。
用法:python operator103.py <VRN1_VRN2_OneClick_v0102.md> <VRN2 一鍵 v0142 程式碼 SHA-256> <輸出夾>"""
import base64, hashlib, re, sys
from pathlib import Path
src, h2, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]); assert re.fullmatch(r"[0-9a-f]{64}", h2); out.mkdir(parents=True, exist_ok=True)
md = src.read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
assert base64.b64decode(one.split()[-1]).decode("utf-16-le") == boot + "\n"
def rep(a, b, n=1):
    global ps
    assert ps.count(a) == n, (ps.count(a), a[:80]); ps = ps.replace(a, b)
rep("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0136'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0142'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0136 程式碼 SHA-256", ps).group(1)
rep("  $H2 = '%s'   # VRN-2 一鍵 v0136 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0142 程式碼 SHA-256" % h2)
rep("  # ===== VRN-1 / VRN-2 操作員一鍵 v0102(2026-10-21 · 操作員「ONE CODE TO HANDLE ALL.」",
    "  # ===== VRN-1 / VRN-2 操作員一鍵 v0103(2026-10-28 · ② 改指 VRN-2 一鍵 v0142:套件 · 摘要器 v0117 · Workbench U/I v0100;v0102 2026-10-21 · 操作員「ONE CODE TO HANDLE ALL.」")
rep("  #   ② VRN-2 一鍵 v0136(從 GitHub 讀 · SHA-256 相符才執行 · 啟動器 ①~⑫:② 寫 VRN-2 借出工具冊 · ⑪ 驗證器 v0105 · ⑫a 啟動器自己把 VRN-1 倉 fast-forward 到 main · ⑫ 借 VRN-1",
    "  #   ② VRN-2 一鍵 v0142(從 GitHub 讀 · SHA-256 相符才執行 · 套件 v0142:③ 取套件雜湊核對 · ④ ActivateVRN-2_v0142 ①~⑫(⑨ ⑩ ⑫ 灰 · 收尾驗證不上船)· 四點原文核對 · Workbench U/I 自動產出開啟 · ⑪ 驗證器 v0110")
n = ps.count("v0136"); ps = ps.replace("VRN2_OneClick_v0136.md", "VRN2_OneClick_v0142.md").replace("VRN-2 一鍵 v0136", "VRN-2 一鍵 v0142").replace("v0136", "v0142")
assert "v0136" not in ps
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1)
boot = boot.replace(h_old, cs).replace("vrn1_vrn2_oneclick_v0102", "vrn1_vrn2_oneclick_v0103").replace("VRN1_VRN2_OneClick_v0102.md", "VRN1_VRN2_OneClick_v0103.md").replace("操作員一鍵 v0102", "操作員一鍵 v0103") + "\n"
assert "v0102" not in boot
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
# 文字區:三個程式碼區塊先抽成佔位符,只改說明文字,再放回(程式碼逐字 = 上面算雜湊的那份)
ps_old = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot_old = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one_old = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
text = md.replace("```powershell\n" + ps_old + "\n```", "```powershell\n@PS@\n```").replace("```text\n" + boot_old + "\n```", "```text\n@BOOT@\n```").replace("```bat\n" + one_old + "\n```", "```bat\n@ONE@\n```")
old_cs = hashlib.sha256(ps_old.encode("utf-8")).hexdigest()
text = text.replace(old_cs, cs).replace(old_cs[:12], cs[:12]).replace(old_h2, h2).replace(old_h2[:12], h2[:12])
text = text.replace("v0102", "v0103").replace("VRN-2 一鍵 v0136", "VRN-2 一鍵 v0142").replace("vrn2_release_v0136", "vrn2_release_v0142").replace("VRN2_OneClick_v0136", "VRN2_OneClick_v0142")
head_old = text.split("\n", 1)[0]
head_new = "# VRN-1 / VRN-2 操作員一鍵 v0103(cmd / PowerShell 都能貼 · v0102 + ② 改指 VRN-2 一鍵 v0142:套件 · 摘要器 ENG062 v0117 · Workbench U/I v0100)"
text = text.replace(head_old, head_new, 1)
text = text.replace("操作員令(2026-10-21):「ONE CODE TO HANDLE ALL.」。v0103 = v0101 + ② 改指 **VRN-2 一鍵 v0142**",
                    "操作員令(2026-10-28):本地實測貼回(v0136 線)+「模板視覺鎖定 … 整合為一個系統 … 透明去背 logo」。v0103 = v0102 + ② 改指 **VRN-2 一鍵 v0142**(套件 v0142:摘要器 v0117 四點開頭不帶頁首 / 標題 / 小標題 · Workbench U/I v0100 範本視覺鎖定、綁本輪收據與輸出冊、收尾後自動開啟 · `VRN2_Logo.png` 自動去背;v0141 的冪等閘 / 四點補齊 / 原文核對 v0104 / 驗證器 v0110 照舊);v0102 原文:v0101 + ② 改指 VRN-2 一鍵 v0136", 1)
text = text.replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n")).replace("@ONE@", one)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == ps and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot
(out / "VRN1_VRN2_OneClick_v0103.md").write_text(text, encoding="utf-8", newline="\n"); (out / "boot_pair103.ps1").write_text(boot, encoding="utf-8", newline="\n"); (out / "oneline_pair103.txt").write_text(one + "\n", encoding="utf-8"); (out / "Run-VRN1-VRN2-v0103.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("operator v0103 · code %s · H2 %s · 換 v0136→v0142 %d 處 · one-liner %d 字" % (cs[:12], h2[:12], n, len(one)))
