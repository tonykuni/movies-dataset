"""操作員一鍵 v0102 實測紀錄(Codex #564 修正後):從實際日誌組出來 · 冪等。"""
import pathlib, re
P = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/pair102")
cs64 = re.search(r"\$H  = '([0-9a-f]{64})'", (P / "out/boot_pair.ps1").read_text(encoding="utf-8")).group(1)
def lamps(f):
    L = (P / f).read_text(encoding="utf-8", errors="replace").split("\n")
    out = {}
    for l in L:
        m = re.match(r"^\[(GREEN|YELLOW|RED|GRAY)\] ([①②③]) [^·]*· (.*)$", l.strip())
        if m: out[m.group(2)] = (m.group(1), m.group(3)[:150])
        if l.startswith("NEXT: ["): out["NEXT"] = l.strip()[:120]
    return out
f, a = lamps("scen_full.log"), lamps("scen_again.log")
def row(d):
    return " · ".join("%s %s:%s" % (k, d[k][0], d[k][1]) for k in ("①", "②", "③") if k in d) + " · " + d.get("NEXT", "")
rc_full = (P / "scen_full.rc").read_text().split()[1]; rc_again = (P / "scen_again.rc").read_text().split()[1]
ui = []
for name, label in (("ui_vrn2_ui.log", "VRN-2 U/I `VRN2_UI_latest.html`"), ("ui_vrn2_pivot.log", "VRN-2 PIVOT `pivot\\VRN_Pivot_v0100.html`"), ("ui_vrn1_verified.log", "VRN-1 驗證過的輸出 `VRN_Verified_Output_v0100.html`"), ("ui_vrn1_pivot.log", "VRN-1 PIVOT `VRN_Pivot_v0100.html`")):
    t = (P / "ui_again" / name).read_text(encoding="utf-8", errors="replace")
    p_, n_ = len(re.findall(r"\[(?:PASS|OK)\]", t)), len(re.findall(r"\[(?:FAIL|NG)\]", t))
    ui.append("| %s | %d / %d |" % (label, p_, p_ + n_))
unit = [l.strip() for l in (P / "logs/unit_pair102.log").read_text(encoding="utf-8", errors="replace").split("\n") if l.strip().startswith("[") or l.strip().startswith("[計]")]
md = """# VRN-1 / VRN-2 操作員一鍵 v0102 · 容器實測紀錄(2026-10-21)

操作員令:「ONE CODE TO HANDLE ALL.」(v0136 合併 MAIN 之後)。
一鍵程式碼 SHA-256 `%s`(`VRN1_VRN2_OneClick_v0102.md` 的 powershell 區塊)· 內含 VRN-2 一鍵 v0136 程式碼雜湊 `eebbd1755d50…`(啟動器 v0136 `cb6bf142a0e3…` · 驗證器 v0105)。

v0102 = v0101 + ② 改指 VRN-2 一鍵 v0136(驗證器 v0105:DUPKEY 看位置證據 · 對調診斷 · EPS 格 · 貼給 AI 每類錯值都出現;啟動器 ⑫a 自己把 VRN-1 倉 fast-forward 到 main)。
一段貼上去:① VRN-1 倉(不在 → 從 GitHub 複製 · 在 → stash 保存 · 切 main · 只快轉)→ ② VRN-2 v0136 全流程(U/I 自己跳出)→ ③ VRN-1 MAIN(check → run · 沒有 pwsh 就 winget 裝)→ ④ 總結 + 要人判 + GitHub Actions。
只呼叫兩邊自己的入口,不改任何一邊的程式 / 冊 / 號;VCGC / VDF 不碰(四系統各自獨立)。v0101 的開關全部照舊。

## Codex #564(PR 上的四條 · 都在本段程式碼裡 · 都修)

| 等級 | 指出 | 修法 | 單元 |
|---|---|---|---|
| P1 | ① 切不到 main(main 在別的 worktree / 未追蹤檔擋住)仍 `git pull --ff-only` → 別的分支被快轉到 main、或分岔的分支被當最新 | 切完後核對 HEAD 真的是 main 才拉;否則黃「切不到 main → 不拉 · 照現狀 <分支>@<sha> 跑」,理由(第一次失敗的 git 訊息)印出 | A:main 佔在別的 worktree → 黃、HEAD 不變 |
| P2 | `--untracked-files=no` 看不到未追蹤的檔 → 可能擋住切換 | 未追蹤的檔另外數、留著不動(不用 `stash -u` 動操作員的檔);真擋到時切換會失敗 → 走上面那條黃、不拉 | B:未追蹤 1 個 → 說明裡寫出來 |
| P2 | `VRN_PAIR_SKIP` 跳過一邊 → 總結仍 GREEN「兩個系統都跑完」 | 跳過一邊 → 最多 YELLOW:「這次只跑了 VRN-x(VRN_PAIR_SKIP=…)· 不算兩邊都完成」 | B |
| P2 | 一行的 boot 紅燈只 `return`、最後沒 `exit` → cmd `%%ERRORLEVEL%%` 永遠 0 | boot 紅燈 `exit 1` · 執行包 try/catch · 最後 `exit` 最終燈(GREEN 0 / YELLOW 2 / RED 1) | C1 exit 2 · C2(程式碼被改)exit 1 · C3(不是 git 倉)exit 1 |

單元(pwsh 7.4.6 · git 夾具):
```
%s
```

| 情境 | 結果 |
|---|---|
| **VRN-1 倉不在**(只有 VIA 樹 · Downloads 是 MAIN 的 v0135)· 貼「一行」(pwsh 7.4.6 · `-EncodedCommand`)· 結束碼 %s | %s |
| 再貼一次 · 結束碼 %s | %s |
| winget 自動安裝 | 容器測不到(Linux 沒有 winget / Windows PowerShell)· 與 v0101 同一段碼、沒改 |

② 黃與總結黃只因 Linux 沒 HKCU / 瀏覽器(VRN-2 ⑤b · ⑤c);Windows 上為綠。結束碼由 boot 帶回(YELLOW → 2)。

**收尾判準:輸出驗證無誤於 HTML U/I**(真 Chromium · 最後狀態 = 再貼一次之後):

| 頁 | 實測 |
|---|---|
%s

日誌:`logs_v0102.zip`(兩次情境 · 單元 A–C3 · 四張 U/I)· 測試工具:`tools_v0102.zip`(產生器 · 情境腳本 · 單元腳本 · 不含 .ps1)。v0100 / v0101 照舊留著。
""" % (cs64, "\n".join(unit), rc_full, row(f), rc_again, row(a), "\n".join(ui))
(P / "VRN1_VRN2_Verification_v0102.md").write_text(md, encoding="utf-8", newline="\n")
print("verification written · code", cs64[:12], "· rc", rc_full, rc_again)
