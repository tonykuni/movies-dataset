#!/bin/bash
P=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/pair102
bash $P/scen_pair102.sh full
bash $P/scen_pair102_again.sh again
bash $P/ui_all.sh $P/out_vrn1_again $P/t/VIA $P/ui_again > $P/ui_again.log 2>&1
echo alldone >> $P/scen_again.rc
