#!/bin/bash
# 操作員一鍵 v0102 放進 movies-dataset 倉(不放 .ps1)· logs / 工具壓 zip(固定時間戳 · 冪等)
P=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/pair102
D=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0102; mkdir -p $D
python3 - <<'PY'
import zipfile, pathlib, re
P = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/pair102")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0102")
def z(name, files):
    with zipfile.ZipFile(D / name, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 21, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [("scen_full_clone_v0102.log", P / "scen_full.log"), ("scen_again_v0102.log", P / "scen_again.log"), ("before_full.txt", P / "before_full.txt"), ("before_again.txt", P / "before_again.txt"), ("ui_again.log", P / "ui_again.log")] + [(q.name, q) for q in sorted((P / "logs").glob("unit_*.log"))]
logs += [(q.name, q) for q in sorted((P / "ui_again").glob("ui_*.log"))] if (P / "ui_again").exists() else []
z("logs_v0102.zip", logs)
z("tools_v0102.zip", [("tools/" + q.name, q) for q in sorted(P.glob("*.py")) + sorted(P.glob("*.sh"))])
PY
cp $P/out/VRN1_VRN2_OneClick_v0102.md $D/; cp $P/VRN1_VRN2_Verification_v0102.md $D/
ls -la $D
