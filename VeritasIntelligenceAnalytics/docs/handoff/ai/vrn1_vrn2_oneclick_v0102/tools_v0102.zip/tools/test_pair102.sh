#!/bin/bash
# 操作員一鍵 v0102 單元(pwsh):A ① 切不到 main → 不拉 · B VRN_PAIR_SKIP → 最多黃 · C boot 雜湊不對 exit 1 / 最終燈 exit 2
S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; P=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/pair102
U=$P/ut; rm -rf $U; mkdir -p $U; cd $U; PW=$S2/pwsh/pwsh; G="git -c user.email=t@t -c user.name=t"
pass=0; fail=0; chk() { if [ "$2" = "1" ]; then pass=$((pass+1)); echo "  [OK] $1"; else fail=$((fail+1)); echo "  [FAIL] $1"; fi; }
# VRN-1 夾具:origin(2 提交)· clone · worktree 佔住 main · clone 切到 feat(落後 1)
$G init -q -b main src >/dev/null; (cd src && echo 1 > a.txt && $G add -A && $G commit -qm c1 && echo 2 > a.txt && $G commit -qam c2)
git clone -q src cl; (cd cl && git switch -q -c feat HEAD~1 && git worktree add -q ../wt main); OLD=$(git -C cl rev-parse --short HEAD); echo "fixture: cl on $(git -C cl rev-parse --abbrev-ref HEAD)@$OLD · main checked out in wt"
# VRN2_ROOT:任何 git 倉(② 跳過用不到 · 但 boot 要)
export PATH="$S2/pwsh:$PATH"
# A:切不到 main(main 在別的 worktree)→ ① 黃 · 不拉 · HEAD 不變;③ 紅(沒有 VRN-1.ps1)
env VIA_VRN1_ROOT=$U/cl VRN_PAIR_SKIP=VRN-2 VRN2_ROOT=$U/src $PW -NoProfile -File $P/out/Run-VRN1-VRN2-v0102.ps1 > A.log 2>&1; rcA=$?
chk "A ① 切不到 main(main 在別的 worktree · 理由印出)→ 黃、不拉(HEAD 仍 feat@$OLD)· 總結紅(③ 沒有 VRN-1.ps1)" "$([ "$(git -C cl rev-parse --short HEAD)" = "$OLD" ] && grep -q '\[YELLOW\] ① VRN-1 git pull · 切不到 main → 不拉' A.log && grep -qE 'already used by worktree|already checked out' A.log && grep -q 'NEXT: \[RED\]' A.log && echo 1)"
grep -E "^\[(GREEN|YELLOW|RED)\] [①③]|^NEXT" A.log | cut -c1-160
# B:VRN-1 夾具 2(乾淨 · 在 main)+ 假 VRN-1.ps1 收尾完成 → ① 綠 · ③ 綠 · 跳過 VRN-2 → 最終黃 exit 2
git clone -q src cl2; mkdir -p cl2/artifacts; printf 'param([Parameter(ValueFromRemainingArguments=$true)]$a)\nWrite-Host "[STUB] VRN-1 $($a -join \x27 \x27)"\nWrite-Host "[收尾] 完成"\nexit 0\n' > cl2/artifacts/VRN-1.ps1
env VIA_VRN1_ROOT=$U/cl2 VRN_PAIR_SKIP=VRN-2 VRN2_ROOT=$U/src $PW -NoProfile -File $P/out/Run-VRN1-VRN2-v0102.ps1 > B.log 2>&1; rcB=$?
chk "B 跳過 VRN-2 · ① 綠 ③ 綠 → 最終 YELLOW「這次只跑了 VRN-1」(exit 碼由 boot 帶回 · 見 C1)" "$(grep -q '\[GREEN\] ① ' B.log && grep -q '\[GREEN\] ③ ' B.log && grep -q 'NEXT: \[YELLOW\] 這次只跑了 VRN-1' B.log && echo 1)"
grep -E "^\[(GREEN|YELLOW|RED)\] [①③]|^NEXT" B.log | cut -c1-160
# C:boot —— 假 GitHub:bare + 工作倉 R(origin=bare)· 分支上放 md
git init -q --bare bare.git; git clone -q bare.git R 2>/dev/null; D=R/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0102; mkdir -p $D
cp $P/out/VRN1_VRN2_OneClick_v0102.md $D/; (cd R && $G add -A && $G commit -qm md && git push -q origin HEAD:refs/heads/claude/optimistic-goodall-yhalc5)
B64=$(cut -d' ' -f6 $P/out/oneline_pair.txt)
# C1:正確 md · 跳過 VRN-2 · 假 VRN-1 → 最終黃 → exit 2
env VIA_VRN1_ROOT=$U/cl2 VRN_PAIR_SKIP=VRN-2 VRN2_ROOT=$U/R $PW -NoProfile -EncodedCommand "$B64" > C1.log 2>&1; rc1=$?
chk "C1 boot 雜湊相符 → 執行 → 最終燈 YELLOW 帶回 exit 2" "$(grep -q '\[GREEN\] 一鍵程式碼 SHA-256' C1.log && [ $rc1 -eq 2 ] && echo 1)"
# C2:md 被改 → 雜湊不對 → exit 1
sed -i 's/操作員一鍵 v0102(cmd/操作員一鍵 v0102(cmd X/' $D/VRN1_VRN2_OneClick_v0102.md; sed -i '0,/^  \$ErrorActionPreference/s//  # tampered\n  $ErrorActionPreference/' $D/VRN1_VRN2_OneClick_v0102.md; (cd R && $G commit -qam tamper && git push -q origin HEAD:refs/heads/claude/optimistic-goodall-yhalc5)
env VIA_VRN1_ROOT=$U/cl2 VRN_PAIR_SKIP=VRN-2 VRN2_ROOT=$U/R $PW -NoProfile -EncodedCommand "$B64" > C2.log 2>&1; rc2=$?
chk "C2 boot 程式碼被改 → 雜湊不對 → 不執行 · exit 1" "$(grep -q '\[RED\] 一鍵程式碼 SHA-256 不對' C2.log && ! grep -q '① VRN-1 git pull' C2.log && [ $rc2 -eq 1 ] && echo 1)"
# C3:VRN2_ROOT 不是 git 倉 → exit 1
env VIA_VRN1_ROOT=$U/cl2 VRN_PAIR_SKIP=VRN-2 VRN2_ROOT=$U/nope $PW -NoProfile -EncodedCommand "$B64" > C3.log 2>&1; rc3=$?
chk "C3 boot VRN2_ROOT 不是 git 倉 → exit 1" "$(grep -q '不是 git 倉' C3.log && [ $rc3 -eq 1 ] && echo 1)"
echo "[計] 操作員一鍵 v0102 單元 $pass/$((pass+fail)) · $([ $fail -eq 0 ] && echo PASS || echo FAIL)"
