#!/bin/bash
# 收尾判準:輸出驗證無誤於 HTML U/I —— 兩個系統的 U/I 用真的 Chromium 逐頁實測
# 用法:ui_all.sh <VRN-1 輸出夾> <VIA 根> <結果夾>
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
O1=$1; V=$2; R=$3; mkdir -p $R; export NODE_PATH=/opt/node-tools/node_modules
R1=$O1/autotest/round1
node $S/vrn1fix/ui_verified.js $R1/verified/VRN_Verified_Output_v0100.html $R1/verified/VRN_Verified_Output_v0100.json $R/shots_vrn1_verified > $R/ui_vrn1_verified.log 2>&1; echo "vrn1_verified rc $?" >> $R/ui.rc
node $S/v131/tools/ui_pivot.js $R1/pivot/VRN_Pivot_v0100.html $R1/pivot/VRN_Pivot_v0100.json VRN-1 $R/shots_vrn1_pivot > $R/ui_vrn1_pivot.log 2>&1; echo "vrn1_pivot rc $?" >> $R/ui.rc
node $S2/tools/ui_test.js $V/VIA_Reports/vrn2/VRN2_UI_latest.html $R/shots_vrn2_ui $V/VIA_Reports/vrn2/output > $R/ui_vrn2_ui.log 2>&1; echo "vrn2_ui rc $?" >> $R/ui.rc
node $S/v131/tools/ui_pivot.js $V/VIA_Reports/vrn2/pivot/VRN_Pivot_v0100.html $V/VIA_Reports/vrn2/pivot/VRN_Pivot_v0100.json VRN-2 $R/shots_vrn2_pivot > $R/ui_vrn2_pivot.log 2>&1; echo "vrn2_pivot rc $?" >> $R/ui.rc
for f in $R/ui_*.log; do echo "$(basename $f): $(grep -E '\[計\]' $f | tail -1)"; grep -E '\[(FAIL|NG)\]|FAIL' $f | head -5; done
