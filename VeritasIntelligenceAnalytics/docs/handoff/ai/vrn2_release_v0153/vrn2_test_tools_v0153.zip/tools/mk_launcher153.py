"""ActivateVRN-2_v0153.py = v0152 + 管理器 v0257(一列一科目:並排兩張表的右表值不再掛到左表科目)· 桌機 2026-10-30 18:34 Handle-All 貼回(DUPKEY 45)。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v152/new/ActivateVRN-2_v0152.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0152: v0151 entry + the desktop runs of 2026-10-30 (RoundAll v0105 / v0107 · operator: "GENERATE A PS CODE TO HANDLE ALL").',
    '"""VRN-2 v0153: v0152 entry + the desktop run of 2026-10-30 18:34 (Handle-All v0100 → RoundAll v0108 verify: close-out BLOCKED · VRN-2 0).\n\n'
    ' - the independent verifier v0114 still counted DUPKEY 45 in the annual book: 6933_AMAX-KY page 8 holds two tables side by side\n'
    '   (balance sheet ∥ income statement) and the right table\'s values were written under the left table\'s item (流動資產 2020 =\n'
    '   1,331,956 and 3,411,492); 凱基 2891 page 5 had 8 row-less duplicates. Manager v0257 (thin tail over v0255): the same file · page ·\n'
    '   table · row · item · period with different values → the leftmost cell keeps the item, a later value takes the label written in\n'
    '   its own row (renamed · noted) or moves to the Rejected book; row-less duplicates move to the Rejected book. The same item on\n'
    '   different rows (Percent of Revenues · Other adjustments) is not touched. The 14 container PDFs: 0 rows change.\n'
    ' Runtime v0153 = runtime v0152 (188 members byte-identical) + VRN_SystemManager_v0257.\n\n'
    'v0152: v0151 entry + the desktop runs of 2026-10-30 (RoundAll v0105 / v0107 · operator: "GENERATE A PS CODE TO HANDLE ALL").')
for a, b in (('VERSION = "ActivateVRN-2 v0152"', 'VERSION = "ActivateVRN-2 v0153"'), ('RUNTIME_ZIP = "VRN2_Runtime_v0152.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0153.zip"'),
             ('RUNTIME_MANIFEST = "VRN2_Runtime_v0152.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0153.json"'), ('RECEIPT_NAME = "VRN2_Closeout_v0152.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0153.json"'),
             ('launcher = root / "package" / "ActivateVRN-2_v0152.py"', 'launcher = root / "package" / "ActivateVRN-2_v0153.py"'),
             ('return lamp, detail + " · launcher v0152"', 'return lamp, detail + " · launcher v0153"'), ('print("NEXT: [%s] VRN-2 v0152 · rc %s', 'print("NEXT: [%s] VRN-2 v0153 · rc %s'),
             ('MANAGER = "VRN_SystemManager_v0255.py"   # v0244–v0254 belong to the desktop line in functional modules/VRN; this runtime line continues at v0255 (PRIOR pinned v0243)',
              'MANAGER = "VRN_SystemManager_v0257.py"   # v0153: one row, one item (PRIOR v0255 · v0256 is the desktop line\'s in functional modules/VRN); v0255 kept (PRIOR pinned v0243)'),
             ('return runtime / MANAGER, lamp, detail + " · active manager v0255"', 'return runtime / MANAGER, lamp, detail + " · active manager v0257"'),
             ('note="VRN-2 private runtime; exact ship v0153; manager v0255; shared VRN retained"', 'note="VRN-2 private runtime; exact ship v0153; manager v0257 (over v0255); shared VRN retained"')):
    rep(a, b)
rep('''    v114 = selftest_source("VRN2_IndependentVerifier_v0114.py").read_text(encoding="utf-8")''', r'''    m257 = selftest_source("VRN_SystemManager_v0257.py").read_text(encoding="utf-8")
    assert 'TAG = "v0257"' in m257 and 'PRIOR_NAME = "VRN_SystemManager_v0255.py"' in m257 and "def _rowfix(" in m257 and '_out_books = _timed("輸出冊", _out_books_v0257)' in m257
    assert MANAGER == "VRN_SystemManager_v0257.py"
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            mgr = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN_SystemManager_v\d{4}\.py", n))
        assert mgr[-1] == "VRN_SystemManager_v0257.py" and "VRN_SystemManager_v0255.py" in mgr and "VRN_SystemManager_v0243.py" in mgr, mgr[-3:]
    print("[PASS] v0153: manager v0257 is the active manager (one row, one item: side-by-side right-table values renamed to their own row label or moved to Rejected · row-less duplicates rejected) · v0255 kept as PRIOR")
    v114 = selftest_source("VRN2_IndependentVerifier_v0114.py").read_text(encoding="utf-8")''')
rep('''        assert ivs2[-1] == "VRN2_IndependentVerifier_v0114.py" and "VRN2_IndependentVerifier_v0113.py" in ivs2, ivs2[-3:]''',
    '''        assert ivs2[-1] == "VRN2_IndependentVerifier_v0114.py" and "VRN2_IndependentVerifier_v0113.py" in ivs2, ivs2[-3:]           # v0153: v0114 still the newest verifier''')
(S / "v153/new/ActivateVRN-2_v0153.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0153 lines", s.count("\n"))
