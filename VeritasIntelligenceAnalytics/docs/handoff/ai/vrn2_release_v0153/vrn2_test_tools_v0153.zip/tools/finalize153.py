"""收尾 v0153:測試結果 → VRN2_Release_v0153.json.results · VRN2_Verification_v0153.md(套件 / RoundAll / Handle-All 已定,不重算)。"""
import collections, glob, json, re, zipfile
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v153"); rel = W / "release153"


def j(p, d=None):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return d


def lines(p):
    try:
        return [re.sub(r"\x1b\[[0-9;]*m", "", l) for l in Path(p).read_text(encoding="utf-8", errors="replace").splitlines()]
    except OSError:
        return []


def grep(p, pat, all_=False):
    hits = [l for l in lines(p) if re.search(pat, l)]
    return hits if all_ else (hits[-1] if hits else "")


def esc(x):
    return str(x).replace("|", "\\|")


def short(s):
    return re.sub(r"/tmp/claude-0/[^ ·)(]*?/(t153d?|v153|v152)/", r"<\1>/", str(s))


def ha(name):
    keep = [l for l in lines(W / ("ha153_%s.log" % name)) if re.match(r"^\[(GREEN|YELLOW|RED|GRAY|計)\] (①|②|③|④|⑤|⑥ ⑪|⑪b|⑧|VRN2_MODE|Handle)|^總表|^===== 收尾|^  \[(VRN-2|VCGC|人工|資料源)\]|^  下一步", l)]
    return [short(l)[:230] for l in keep if not l.startswith(("[GREEN] ③ 自測 · VRN2", "[GREEN] ② "))]


selft = {"VRN_SystemManager_v0257(VIA 樹內 · PRIOR v0255 → v0243 …)": grep(W / "m257_selftest.log", r"^\[PASS\] v0257")[:220],
         "VRN2_RoundAll_v0109": grep(W / "rall109_selftest.log", r"--selftest · .*不過 0")[:200],
         "ActivateVRN-2_v0153(套件夾複本 · 不靠 ../new)": grep(W / "ActivateVRN-2_v0153_selftest_iso.log", r"\[PASS\] v0153")[:220]}
replay = [short(l) for l in lines(W / "try_rowfix.log")]
reclass = lines(W / "reclass109.log")
rc = (W / "ha153.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "ha153.rc").exists() else "not run"
v2 = W / "t153d/VIA/VIA_Reports/vrn2"
before = j(W / "d_fin_before.json", []) or []
after = j(v2 / "output/VRN2_FinancialData_latest.json", []) or []
key = lambda x: json.dumps({k: x.get(k) for k in ("FILENAME", "PAGE", "TABLE", "ROW", "SECTION", "ITEM", "PERIOD", "SUBCOL", "VALUE")}, sort_keys=True, ensure_ascii=False)
same_rows = collections.Counter(map(key, before)) == collections.Counter(map(key, after))
page = j(v2 / "VRN2_CloseoutUI_latest.json", {}) or {}
rec = j(v2 / "VRN2_Closeout_v0153.json", {}) or {}
st_rows = [l for l in lines(W / "ha153_d_auto_full.log") if re.match(r"^\[(GREEN|YELLOW|RED)\] ③ 自測 · ", l)]
z = sorted(glob.glob(str(W / "t153d/home/Downloads/VRN2_PasteBack_*.zip")))
mem = [m for m in zipfile.ZipFile(z[-1]).namelist() if "Closeout" in m] if z else []
desk = {"auto → 模式(只有 v0151 收據)": grep(W / "ha153_d_auto_full.log", r"④ 自動選模式")[:200],
        "⑤ 取 RoundAll": short(re.sub(r" → .*", "", grep(W / "ha153_d_auto_full.log", r"⑤ VRN2_RoundAll_v0109.py SHA-256")))[:160],
        "① 套件": short(grep(W / "ha153_d_auto_full.log", r"^\[GREEN\] ① 套件"))[:200],
        "③ 自測": "%d 支 · 綠 %d · 紅 / 黃 %d · 管理器 v0257:%s" % (len(st_rows), sum(1 for l in st_rows if l.startswith("[GREEN]")), sum(1 for l in st_rows if not l.startswith("[GREEN]")),
                                                     (grep(W / "ha153_d_auto_full.log", r"③ 自測 · VRN_SystemManager_v0257") or "(沒有)")[:120]),
        "④ 啟動器 v0153": short(re.sub(r" · NEXT: .*", "", grep(W / "ha153_d_auto_full.log", r"④ 跑啟動器")))[:160],
        "管理器": short(grep(W / "ha153_d_auto_full.log", r"active manager|管理器 VRN_SystemManager_v0257|VRN_SystemManager_v0257\.py 已在|成功模組登記"))[:200],
        "v0257 一列一科目(容器 14 份 · 應該沒有撞鍵)": short(grep(W / "ha153_d_auto_full.log", r"v0257 一列一科目") or "沒有印(0 列撞鍵 · 輸出冊不重寫)")[:160],
        "年度數據冊 v0255 做的 vs v0257 做的": "%d 列 → %d 列 · 逐列(檔 · 頁 · 表 · 列 · 段落 · 科目 · 期間 · 子欄 · 值)%s" % (len(before), len(after), "完全相同" if same_rows else "不同"),
        "⑥ ⑪ 驗證器版本": short(grep(W / "ha153_d_auto_full.log", r"⑥ ⑪ 驗證器版本"))[:120],
        "總表(full)": grep(W / "ha153_d_auto_full.log", r"^總表")[:120],
        "再貼(auto → 模式 · 收據 v0153)": grep(W / "ha153_d_auto_verify.log", r"④ 自動選模式")[:160],
        "再貼 ⑪b": short(grep(W / "ha153_d_auto_verify.log", r"^\[(GREEN|YELLOW)\] ⑪b"))[:200],
        "report": grep(W / "ha153_d_report.log", r"^\[計\] Handle")[:120],
        "收尾頁(最後)": "%s · %s · %s · 列 %d(其中合併 %d 列)" % (page.get("state"), page.get("state_text"), json.dumps(page.get("per_owner"), ensure_ascii=False), len(page.get("items") or []), sum(1 for i in page.get("items") or [] if i.get("also"))),
        "v0153 收據 roundall.fixed": sorted((rec.get("roundall") or {}).get("fixed") or {}),
        "貼回包帶收據": mem,
        "RoundAll 被竄改": grep(W / "ha153_d_tamper.log", r"^\[RED\] ⑤")[:160] + " · 存檔:" + ("沒有(不執行)" if "No such file" in (W / "d_tamper_file.txt").read_text() else "有?"),
        "容器才有的 VCGC 項": "③ 環境檢查缺 7(accelerator / curl_cffi / cv2 / duckdb / lz4 / pyvips / watchdog)· ⑥e 擷取 Python 沒有合 VDF 界線的 —— 容器沒裝,桌機有"}
R = {"selftests": selft, "replay_desktop_book_v0257": replay, "reclassify_desktop_closeout_v0109": reclass, "pwsh_hash_chain": lines(W / "pscheck153.log"), "rc": rc, "desktop_like_sandbox": desk,
     "handover_line": "桌機情境(複製 v0151 沙盒:只有 v0151 收據)貼 Handle-All v0101 → auto 選 full → 套件 v0153 · ③ 自測 %s · 啟動器 v0153(管理器 v0257)→ 年度數據冊與 v0255 做的%s → 再貼 auto 選 verify → report;收尾 %s(VRN-2 0);RoundAll 被竄改 → ⑤ 紅、不執行。"
                      % (desk["③ 自測"].split(" · 管理器")[0], "逐列完全相同" if same_rows else "不同(看驗證紀錄)", page.get("state")),
     "not_claimed": ["Windows desktop run of package v0153 / manager v0257 / RoundAll v0109 / Handle-All v0101: not yet (next paste-back); the 6933 AMAX and 凱基 2891 PDFs are only on the desktop — v0257 is proven by its selftest (side-by-side rows built like page 8 · fused label+value cell · row-less pairs) and by replaying the desktop's own annual book (exactly the 45 DUPKEY rows rejected); whether the desktop's extracted row also holds the right table's labels (rename instead of reject) shows only in the next run",
                     "the close-out merge rules (one row per root cause) are proven on the desktop 18:34 rows; a new step name is not merged",
                     "MOPS DENY (VCGC) · MQ-1560 OCR / EST 1 / annual gaps 3 (human) · Apple not a TW stock / 3706 · 6669 no adjusted close in the week before the report date (VDF daily windows PARTIAL · data source): not changed",
                     "VDF_v0102_Redownload_4.zip (VDF's own system): read only — not installed, not changed, not committed (four systems independent)",
                     "the container's VCGC items (missing accelerator packages, fetch Python outside VDF bounds) are container-only; the desktop has them"]}
relj = j(rel / "VRN2_Release_v0153.json"); relj["results"] = R
(rel / "VRN2_Release_v0153.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
md = ["# VRN-2 v0153 + 管理器 v0257 + VRN2_RoundAll_v0109 + VRN2_HandleAll_v0101 容器實測紀錄(2026-10-30)", "",
      "桌機 18:34 貼回 Handle-All v0100(RoundAll v0108 verify):收尾 BLOCKED · VRN-2 0,但驗證器 DUPKEY 45(6933 AMAX 第 8 頁並排兩張表 37 · 凱基 2891 第 5 頁沒有列號 8)→ v0153(見發行清單 `fixes` · `not_fixed_here`)。", "",
      "## 1. 自測", "", "| 檔 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(v) or "(沒有 PASS 行)") for k, v in selft.items()] + ["",
      "## 2. 管理器 v0257 拿桌機 18:34 的年度數據冊重放(沒有擷取快取 → 留最左邊、其他剔除)· 容器 14 份真檔(有擷取快取)", "", "```", *replay, "```", "",
      "## 3. RoundAll v0109 的收尾規則重算桌機 18:34 那份收尾頁(只讀)", "", "```", *reclass, "```", "",
      "## 4. PowerShell 雜湊鏈與剖析(pwsh 7.4.6)", "", "```", *R["pwsh_hash_chain"], "```", "",
      "## 5. 桌機情境:貼 Handle-All v0101(複製 v0151 沙盒 · 只有 v0151 收據 + 上一輪輸出)→ auto(full)→ auto(verify)→ report → 竄改", "", "| 項目 | 結果 |", "|---|---|"] + ["| %s | %s |" % (esc(k), esc(short(v))) for k, v in desk.items()] + ["",
      "```", *ha("d_auto_full"), "```", "", "```", *ha("d_auto_verify"), "```", "",
      "回合結束碼:`%s`" % rc, "", "## 6. 沒做到 / 沒驗到(照實)", ""] + ["- %s" % x for x in R["not_claimed"]]
(rel / "VRN2_Verification_v0153.md").write_text("\n".join(md) + "\n", encoding="utf-8", newline="\n")
print("finalize153 ok ·", R["handover_line"][:400])
