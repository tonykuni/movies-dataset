"""VRN2_RoundAll_v0109.py = v0108 + 套件 v0153(管理器 v0257 一列一科目)+ 收尾頁同一件事只列一次 + 驗證器 DUPKEY > 0 算 VRN-2 · 桌機 2026-10-30 18:34 Handle-All 貼回。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v152/new/VRN2_RoundAll_v0108.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0108'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0108 — ', '"""VRN2_RoundAll v0109 — ', 1)
at = doc.index("v0108(桌機 2026-10-30 17:06")
doc = doc[:at] + r'''v0109(桌機 2026-10-30 18:34 · Handle-All v0100 → v0108 只重跑 ⑪b:收尾 BLOCKED · VRN-2 0 · VCGC 3 · 人工 5 · 資料源 2 · Daiwa aspeed PBR 26E → NILVAL):
  · 套件 v0153(啟動器 v0153 · runtime v0153 = v0152 的 188 個成員不動 + 管理器 VRN_SystemManager_v0257「一列一科目」):驗證器還數到 DUPKEY 45 ——
    6933 AMAX 第 8 頁兩張表並排(資產負債表 ∥ 損益表),右表的值被掛在左表科目下(流動資產 2020 = 1,331,956 又 = 3,411,492)· 凱基 2891 第 5 頁 8 筆沒有列號。
    v0257:同檔 · 頁 · 表 · 列號 · 科目 · 期間卻有不同值 → 最左邊那格留給本列科目;右邊的值取同一列自己的科目名(改名 · 註明)或移剔除冊;
    沒有列號的 → 都移剔除冊。同一個科目字在不同列(Percent of Revenues · Other adjustments)不動。這要整輪重跑(輸出冊由管理器重做)。
  · 收尾頁負責方:⑪ 獨立驗證的 DUPKEY > 0 → VRN-2(以前算人工:驗證器自己寫「錯值」);年度 FAIL 證據照舊。
  · 收尾頁同一件事只列一次(數負責方也只算一件):⑪b 與收據的 ⑪ 是同一份驗證結果 · 「四點原文核對」與「輸出缺項 · 四點原文核對」是同一批 OCR 摘錄 ·
    ⑥e 的步驟列 / last_error / MOPS 說明是同一個 MOPS DENY → 合成一列(負責方取最重的 · 燈取最差的 · 另見哪幾列寫在「為什麼」)。
  · 自測改跑管理器 v0257(它也重跑 v0255 的冪等閘測試 · 計數檔每份一個:v0255 的假引擎 3 路共用一個計數檔會互蓋 · 偶發紅)。給 Handle-All v0101 用(auto:上一輪輸出冊不是啟動器 v0153 做的 → 整輪)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0108.py", "用法:python VRN2_RoundAll_v0109.py")
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
body = body.replace("v0152", "v0153")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0108"', 'VERSION = "v0109"')
rep('("VRN_SystemManager_v0255.py", 1800)', '("VRN_SystemManager_v0257.py", 1800)')     # v0257 的自測也重跑 v0255 的冪等閘(計數檔不互蓋)
rep('''    if "⑪" in step:
        if "年度數據 FAIL 證據" in step''', '''    if "⑪" in step:
        dk = re.search(r"'DUPKEY': (\\d+)", detail)
        if dk and int(dk.group(1)) > 0 and "FAIL 證據" not in step:                # v0109:驗證器自己寫「錯值 / 分不出」→ 輸出冊的事
            return "VRN-2", ("年度數據同鍵兩值 DUPKEY %s(同一列同科目同期間兩個不同的值 · 並排的另一張表 / 沒有列號)→ 管理器 v0257 起處理(改名 / 剔除)"
                             "· 舊輸出冊要整輪重跑" % dk.group(1))
        if "年度數據 FAIL 證據" in step''')
rep('''def closeout_state(items: list) -> tuple:''', r'''def closeout_root(item: dict, ctx: dict) -> str:
    """v0109 同一件事的幾列 → 同一個根(收尾頁只列一次 · 數負責方算一件):⑪b 與收據的 ⑪ = 同一份驗證結果 · 四點原文核對與「輸出缺項 · 四點原文核對」=
    同一批 OCR 摘錄 · ⑥e 步驟列 / last_error / MOPS 說明 = 同一個 MOPS DENY。認不出來的不合併(空字串)。"""
    step, detail, owner = str(item.get("step", "")), str(item.get("detail", "")), item.get("owner")
    if re.match(r"(⑪b 重跑獨立驗證|⑥ 步驟 ⑪ 獨立驗證)", step):
        return "⑪ 獨立驗證"
    if owner == "人工" and ("四點原文核對" in step or (step.startswith("⑥ 輸出缺項") and "四點原文核對" in detail)):
        return "人工|四點原文 OCR"
    if owner == "VCGC" and ctx.get("mops_deny") and re.match(r"⑥ (步驟 ⑥e 市場擷取|⑥e 擷取錯誤|⑥e MOPS)", step):
        return "VCGC|⑥e MOPS DENY"
    return ""


def merge_same(items: list, ctx: dict) -> list:
    """v0109 同一個根的列合成一列:負責方取最重的(VRN-2 > VCGC > 人工 > 資料源)· 燈取最差的 · 內容取負責方最重那列 · 另見哪幾列寫進「為什麼」。順序照第一次出現。"""
    groups, order = {}, []
    for it in items:
        k = closeout_root(it, ctx)
        key = k or ("#%d" % len(order))
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(it)
    out = []
    for key in order:
        members = groups[key]
        if len(members) == 1:
            out.append(members[0])
            continue
        lead = max(members, key=lambda m: (OWNER_RANK.get(m.get("owner"), 0), -members.index(m)))
        worst = min((m.get("lamp") for m in members), key=lambda l: {"RED": 0, "YELLOW": 1}.get(l, 2))
        also = [m["step"] for m in members if m is not lead]
        out.append(dict(lead, lamp=worst, also=also, why=(str(lead.get("why") or "") + " · 同一件事另見:" + "、".join(also))[:500]))
    return out


def closeout_state(items: list) -> tuple:''')
rep('''        if got:
            items.append(dict(r, owner=got[0], why=got[1]))
    real = [i for i in items if i["owner"] not in ("提醒", "彙總")]''', '''        if got:
            items.append(dict(r, owner=got[0], why=got[1]))
    items = merge_same(items, ctx)                                            # v0109 同一件事只列一次
    real = [i for i in items if i["owner"] not in ("提醒", "彙總")]''')
rep('''"items": [{k: i.get(k) for k in ("owner", "lamp", "step", "detail", "hint", "why")} for i in items]''',
    '''"items": [{k: i.get(k) for k in ("owner", "lamp", "step", "detail", "hint", "why", "also")} for i in items]''')
# 自測 ㊸ ㊹
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''', r'''        # ㊸ ㊹ v0109 收尾頁
        cx9 = {"receipt": True, "mops_deny": True, "fetch_env_ok": True, "no_cov": {"6933", "4171"}, "gate_other": set(), "combined_gaps": {"TARGET_PRICE(ADJ)": {"原文沒有目標價": 9}}, "combined_owner": "資料源", "combined_now": True}
        dk_on = {"lamp": "YELLOW", "step": "⑪b 重跑獨立驗證", "detail": "VRN2_IndependentVerifier_v0114 · 有待核對 · 年度數據 11513 筆 · {'ALIGNED': 10424, 'DUPKEY': 45, 'NILVAL': 1}"}
        dk_off = dict(dk_on, detail=dk_on["detail"].replace("'DUPKEY': 45, ", ""))
        dk_fin = {"lamp": "YELLOW", "step": "⑥ ⑪ 年度數據 FAIL 證據(對不齊)", "detail": "{'DUPKEY': 3} · 對不齊"}
        chk("㊸ 收尾頁:⑪ 驗證器數到 DUPKEY > 0(同一列同科目同期間兩個值 · 驗證器寫「錯值 / 分不出」)→ VRN-2 · 沒有 DUPKEY → 人工 · 年度 FAIL 證據照舊規則",
            owner_of(dk_on, cx9)[0] == "VRN-2" and "v0257" in owner_of(dk_on, cx9)[1] and owner_of(dk_off, cx9)[0] == "人工" and owner_of(dk_fin, cx9)[0] == "人工")
        d1834 = [("YELLOW", "⑪b 重跑獨立驗證", dk_off["detail"]), ("YELLOW", "⑥ 步驟 ⑪ 獨立驗證(背景 · 只讀)", "RoundAll 修正後 · VRN2_IndependentVerifier_v0114 · 有待核對"),
                 ("YELLOW", "⑥ 步驟 ⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 Market", "擷取 RED:失敗 4"), ("YELLOW", "⑥ 四點原文核對", "REVIEW_OCR · {\"PASS\": 204, \"OCR_PENDING\": 4}"),
                 ("YELLOW", "⑥ 輸出缺項", "{\"book\": \"四點原文核對\", \"reason\": \"REVIEW_OCR\"}"), ("YELLOW", "⑥ 完成判定 · 輸出冊(基本資料 / 年度數據 / 一標題四重點)", "個股 52 份 · 缺項 3 份"),
                 ("YELLOW", "⑥ Combined 冊", "52 列 · 欄序正確 · 空格"), ("YELLOW", "⑥ ⑥e 擷取錯誤(last_error.txt)", "[ERROR] PermissionError: Existing VIA network bridge denied this request"),
                 ("YELLOW", "⑥ ⑥e MOPS 財報被拒(VIA 網路工具 DENY)", "VDF 引擎打 MOPS"), ("YELLOW", "⑥ 市場資料", "{\"OK\": 51, \"MISSING\": 1}"),
                 ("YELLOW", "② 擷取 Python · VDF 版本界線(⑥e)", "沒有合 pandas>=2.2 的 Python"), ("YELLOW", "⑥ 收尾收據", "ActivateVRN-2 v0151 · rc 2 · 3367 秒")]
        its = [dict({"lamp": l, "step": st, "detail": d}, owner=owner_of({"lamp": l, "step": st, "detail": d}, cx9)[0], why=owner_of({"lamp": l, "step": st, "detail": d}, cx9)[1]) for l, st, d in d1834]
        merged = merge_same(its, cx9)
        real9 = [i for i in merged if i["owner"] not in ("提醒", "彙總")]
        st9, _t9, po9 = closeout_state(real9)
        its2 = [dict(i) for i in its]
        its2[0] = dict(its2[0], detail=dk_on["detail"], owner="VRN-2", why=owner_of(dk_on, cx9)[1])
        m2 = merge_same(its2, cx9)
        st2, _t2, po2 = closeout_state([i for i in m2 if i["owner"] not in ("提醒", "彙總")])
        lead = next(i for i in m2 if i.get("also") and "⑪" in i["step"])
        chk("㊹ 收尾頁同一件事只列一次:桌機 18:34 那 12 列 → ⑪b + 收據 ⑪ 合一 · 四點 + 輸出缺項(四點)合一 · ⑥e 步驟 / last_error / MOPS 合一 · 擷取 Python 環境不併 → %s %s · 有 DUPKEY → %s %s(負責方取最重 · 另見寫在為什麼)"
            % (st9, po9, st2, po2),
            st9 == "BLOCKED" and po9 == {"人工": 3, "VCGC": 2, "資料源": 2} and len(merged) == len(its) - 4 and st2 == "OPEN" and po2.get("VRN-2") == 1 and po2.get("人工") == 2
            and lead["owner"] == "VRN-2" and "同一件事另見" in lead["why"] and lead["also"] == ["⑥ 步驟 ⑪ 獨立驗證(背景 · 只讀)"])
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · %d 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(ran), len(bad)), flush=True)''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0108.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0109.py"').replace('"VRN2_RoundAll_v0108.py" in html_', '"VRN2_RoundAll_v0109.py" in html_')
assert "VRN2_RoundAll_v0108.py" not in s.replace("vrn2_release_v0152/VRN2_RoundAll_v0108", "")
(S / "v153/new/VRN2_RoundAll_v0109.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0109 lines", s.count("\n"))
