#!/bin/bash
# 假 GitHub 分支:vrn2_release_v0153(套件 zip · RoundAll v0108 · md)推到沙盒 remote.git 的 claude/optimistic-goodall-yhalc5 · $1 = 沙盒
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=$S/v153; T=$W/$1; B=$T.br
rm -rf "${B:?}"; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0153; mkdir -p $D
cp $W/release153/VRN2_Closeout_v0153.zip $W/release153/VRN2_Release_v0153.json $W/release153/VRN2_RoundAll_v0109.py $W/release153/VRN2_RoundAll_v0109.md $W/release153/VRN2_HandleAll_v0101.md $D/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 >/dev/null 2>&1) && echo "branch ok $1"
