"""VRN2_Handover_v0154.md:從 v0153 只增不減(v0153 已推上分支 · 不改)。數字來自 release153/VRN2_Release_v0153.json 的 results(finalize153 寫)。"""
import json
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v153")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0153.md").read_text(encoding="utf-8")
R = json.loads((W / "release153/VRN2_Release_v0153.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((W / "pkg153/VRN2_Runtime_v0153.json").read_text(encoding="utf-8"))["files"]}


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)


lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0152 + VRN2_RoundAll_v0108 + VRN2_HandleAll_v0100 · 2026-10-30(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0153 + VRN2_RoundAll_v0109 + VRN2_HandleAll_v0101 · 2026-10-30(v0152 + 桌機 18:34 Handle-All 貼回 → "
            "管理器 VRN_SystemManager_v0257「一列一科目」(並排兩張表的右表值不再掛到左表科目 · 沒有列號的同鍵兩值移剔除冊)· RoundAll v0109(⑪ DUPKEY → VRN-2 · 收尾頁同一件事只列一次)· "
            "Handle-All v0101(auto:收據不是 v0153 → 整輪);runtime v0152 的 188 個成員一個位元組都不動 · +1 個新檔;v0151 / v0152 發行夾逐位元不變)")
src = "\n".join(lines)
anchor = "> **桌機 2026-10-30 17:06(RoundAll v0107 只重做報告 · 快速模式)**"
new_round = ("> **桌機 2026-10-30 18:34(Handle-All v0100 → RoundAll v0108 verify · 527 秒)**:③ 舊套件夾 `VRN2_Closeout_v0151` 以系統管理員身分 icacls /reset → 讀得到了 · auto 選 verify · "
             "⑪b IndependentVerifier v0114:Daiwa aspeed PBR 26E → NILVAL(年度 FAIL 0)· 收尾 **BLOCKED · VRN-2 0 · VCGC 3 · 人工 5 · 資料源 2**。但驗證器還數到 **DUPKEY 45**:"
             "`6933_AMAX-KY_個股介紹報告.pdf` 第 8 頁兩張表並排(資產負債表 ∥ 損益表)右表的值被掛在左表科目下(流動資產 2020 = 1,331,956 又 = 3,411,492 · 權益總額 = 699,650 又 = -0.54)37 筆 · "
             "凱基 2891 第 5 頁沒有列號的同鍵兩值 8 筆 —— 收尾頁卻算「人工」。同時上傳了 VDF 自己的 `VDF_v0102_Redownload_4.zip`(VDF 獨立系統 v0102 · 經 VCGC 安裝)—— VRN-2 只讀不動。\n"
             "> **本輪(v0153)**:① **管理器 v0257**(薄尾 · PRIOR v0255):同檔 · 頁 · 表 · 列號 · 科目 · 期間 · 段落 · 子欄卻有不同值 → 那一列最左邊的格留給本列科目;右邊的值取同一列自己的科目名(改名 · VERIFY 註明)或移剔除冊(帶理由);"
             "沒有列號 → 都移剔除冊;同一個科目字在不同列(MS-3661 Percent of Revenues · MS-2308 Other adjustments)不動。桌機這份年度數據冊拿來試:剔除正好那 45 筆;容器 14 份真檔 0 列變動。"
             "② **RoundAll v0109**:⑪ 的 DUPKEY > 0 → VRN-2 · 收尾頁同一件事只列一次(⑪b + 收據 ⑪ · 四點 + 輸出缺項(四點)· ⑥e 步驟 + last_error + MOPS)→ 18:34 那 14 列重算 = BLOCKED · VCGC 1 · 人工 3 · 資料源 2(DUPKEY 還在 → OPEN · VRN-2 1)· 自測 46 項。"
             "③ **Handle-All v0101**:auto 只在收據是啟動器 v0153 時選 verify,不然整輪(輸出冊要由 v0257 重做)。"
             "④ **沙盒**:%s\n") % res.get("handover_line", "見 VRN2_Verification_v0153.md")
assert src.count(anchor) == 1
src = src.replace(anchor, new_round + anchor, 1)
anchor = "| **VRN2_HandleAll_v0100.md**(發行夾 · PowerShell 7 一段碼 · 不是 .ps1)| **v0100** | `vrn2_release_v0152` | 一行版 `"
rows = ("| **VRN2_HandleAll_v0101.md**(發行夾 · PowerShell 7 一段碼 · 不是 .ps1)| **v0101** | `vrn2_release_v0153` | 一行版 `%s` | **新**(套件 v0153 · RoundAll v0109 · auto:收據不是 v0153 → 整輪)|\n"
        "| **VRN2_RoundAll_v0109.py**(發行夾 · 一支入口 · 不在套件內)| **v0109** | `vrn2_release_v0153` | `%s` | **新**(套件 v0153 · ⑪ DUPKEY → VRN-2 · 收尾頁同一件事只列一次 · 自測 46 項)|\n"
        "| ActivateVRN-2_v0153.py(套件 · 底座 v0136)| **v0153** | 見發行清單 | `%s` | **新**(收據 v0153 · 管理器 v0257 · 自測多一段 v0153)|\n"
        "| **VRN_SystemManager**(VRN-2 私有 runtime 線)| **v0257**(薄尾 · PRIOR v0255 · v0256 是共用夾的桌機線)| runtime v0153 | `%s` | **新**(一列一科目:並排表右表值改名 / 剔除 · 沒有列號的同鍵兩值剔除)|\n") % (
    R["handleall"]["line_sha256"][:12], R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], rt["VRN_SystemManager_v0257.py"])
assert src.count(anchor) == 1
src = src.replace(anchor, rows + anchor, 1)
once("| **VRN2_RoundAll_v0108.py**(發行夾 · 一支入口 · 不在套件內)| **v0108** | `vrn2_release_v0152` | `58576a79c441` | **新**(",
     "| **VRN2_RoundAll_v0108.py**(發行夾 · 一支入口 · 不在套件內)| **v0108** | `vrn2_release_v0152` | `58576a79c441` | 被 v0109 取代(DUPKEY 算人工 · 收尾頁同一件事列好幾次)· ")
once("## 7. 本輪(v0151 → v0152 + VRN2_RoundAll_v0108 + VRN2_HandleAll_v0100 · 操作員「GENERATE A PS CODE TO HANDLE ALL」)",
     "## 7. 本輪(v0152 → v0153 + 管理器 v0257 + VRN2_RoundAll_v0109 + VRN2_HandleAll_v0101 · 桌機 18:34 Handle-All 貼回)\n\n| # | 剩下的 | 根因 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | ⑪ DUPKEY 45(6933 AMAX 第 8 頁 37 · 凱基 2891 第 5 頁 8)| 並排兩張表擷取成一列 → 右表的值掛在左表科目下;沒有列號的同鍵兩值 | 管理器 v0257 一列一科目(改名 / 剔除 · 不猜)| 自測 10 · 桌機冊重放剔除正好 45 · 容器 14 份 0 變動 |\n"
     "| b | 收尾頁把 DUPKEY 算人工 · 同一件事列 2~3 次 | 規則只看燈號與步驟名 | RoundAll v0109 DUPKEY → VRN-2 · 同根合一 | 自測 ㊸ ㊹ · 18:34 那 14 列重算 |\n"
     "| c | Handle-All auto 在舊輸出冊上只重驗 | v0100 只看收據 ≥ v0151 | v0101:收據不是 v0153 → 整輪 | 沙盒桌機情境 auto → full |\n"
     "| — | MOPS DENY(VCGC)· MQ-1560 OCR / EST 1 / 年度缺項 3 份(人工)· Apple 非台股 / 神達 · 緯穎報告日前一週沒有還原價(VDF 日線視窗 PARTIAL · 資料源)· VDF v0102 安裝 | VCGC 決定 / 要人看原文 / 外部來源 / VDF 自己的系統 | **沒修**(收尾頁分給負責方 · VDF 只讀)| — |\n\n---\n\n"
     "## 7.0p 前一輪(v0151 → v0152 + VRN2_RoundAll_v0108 + VRN2_HandleAll_v0100 · 操作員「GENERATE A PS CODE TO HANDLE ALL」)")
once("| 0 | **(v0152 · 2026-10-30 17:06 後)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0152/VRN2_HandleAll_v0100.md` 的**那一行**",
     "| 0 | **(v0153 · 2026-10-30 18:34 後)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0153/VRN2_HandleAll_v0101.md` 的**那一行**(auto → full · 約 66 分鐘:管理器 v0257 重做輸出冊)· ⑪ DUPKEY 應為 0 · 收尾頁應為 BLOCKED(VCGC 1 · 人工 3 · 資料源 2);DUPKEY 不是 0 或「VRN-2 要修」不是 0 → 貼回包 | 貼回 |\n"
     "| 0 | **(v0152 · 2026-10-30 17:06 後)** 桌機 PowerShell 7.6.9 貼 `vrn2_release_v0152/VRN2_HandleAll_v0100.md` 的**那一行**")
once("**v0152(2026-10-30)**:", "**v0153(2026-10-30)**:桌機 18:34 = BLOCKED(VRN-2 0 · VCGC 3 · 人工 5 · 資料源 2),但 ⑪ DUPKEY 45 是 VRN-2 的輸出冊問題(v0109 起算 VRN-2);v0257 整輪後預期 BLOCKED · VCGC 1 · 人工 3 · 資料源 2,以桌機收尾頁為準。\n\n**v0152(2026-10-30)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0153)** **收尾頁「VRN-2 0」不等於輸出冊乾淨**:每次桌機貼回都要看驗證摘要的 DUPKEY / PRESENT 理由行;驗證器寫「錯值」的就是 VRN-2 的事,不能留在「人工」。\n"
     "- **(v0153)** **撞鍵要把 ROW / SECTION / SUBCOL 算進鍵**:只用 (檔 · 頁 · 表 · 科目 · 期間) 會把「同一個科目字在不同列」(Percent of Revenues · YoY (%))誤當錯;真正的錯是同一列同科目同期間兩個值。\n"
     "- **(v0153)** **修輸出冊的薄尾只動撞鍵的列**:找得到同一列自己的科目名才改名,找不到就移剔除冊(帶理由)· 不猜科目 · 先拿桌機那份冊重放、再拿容器真檔確認 0 變動。\n"
     "- **(v0153)** **別的系統的包(例 VDF v0102)只讀**:看它的說明與證據,告訴操作員跟 VRN-2 剩下的項目有沒有關;安裝 / 修改是那個系統與 VCGC 的事。\n\n")
(REPO / "VRN2_Handover_v0154.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0154 lines", src.count("\n"))
