"""v0153 雜湊鏈 + PowerShell 剖析(pwsh 7.4.6):套件 zip → RoundAll 釘的套件雜湊 → RoundAll 檔 → Handle-All / PS7 一行 / 解開版的 $H → md 裡的碼 = 檔 → 剖析 0 錯 · 一行版與可讀版詞序列相同。"""
import base64, hashlib, json, re, subprocess
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v153"); rel = W / "release153"
PW = "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/pwsh/pwsh"
out = []
def ok(name, cond, detail=""):
    out.append("[%s] %s%s" % ("PASS" if cond else "FAIL", name, (" · " + detail) if detail else "")); return cond
sha = lambda b: hashlib.sha256(b).hexdigest()
zsha = sha((rel / "VRN2_Closeout_v0153.zip").read_bytes())
ra = (rel / "VRN2_RoundAll_v0109.py").read_text(encoding="utf-8"); rsha = sha(ra.encode("utf-8"))
relj = json.loads((rel / "VRN2_Release_v0153.json").read_text(encoding="utf-8"))
ok("套件 zip = RoundAll 釘的 = 發行清單", ('PACKAGE_SHA256 = "%s"' % zsha) in ra and relj["package"]["sha256"] == zsha == relj["roundall"]["pinned_package_sha256"], zsha[:12])
line = (rel / "handleall_line.txt").read_text(encoding="utf-8").rstrip("\n"); src = (rel / "handleall_src.ps1").read_text(encoding="utf-8")
ps7 = (rel / "oneline_roundall_ps7.txt").read_text(encoding="utf-8").rstrip("\n"); boot = (rel / "boot_roundall.ps1").read_text(encoding="utf-8")
ok("RoundAll 檔 = Handle-All 一行 / 可讀版 / PS7 一行 / 解開版的 $H = 發行清單", ("$H = '%s'" % rsha) in line and ("$H = '%s'" % rsha) in src and ("$H = '%s'" % rsha) in ps7 and ("$H  = '%s'" % rsha) in boot
   and relj["roundall"]["sha256"] == rsha, rsha[:12])
hmd = (rel / "VRN2_HandleAll_v0101.md").read_text(encoding="utf-8"); blocks = re.findall(r"(?s)```powershell\n(.*?)\n```", hmd)
lsha = sha(line.encode("utf-8"))
ok("HandleAll md:第一段 = 一行檔 · 第二段 = 可讀版 · 一行 SHA-256 標在 md 與發行清單", len(blocks) == 2 and blocks[0] == line and blocks[1] == src.rstrip("\n") and lsha[:12] in hmd and relj["handleall"]["line_sha256"] == lsha, lsha[:12])
rmd = (rel / "VRN2_RoundAll_v0109.md").read_text(encoding="utf-8")
b64s = re.findall(r"EncodedCommand (\S+)", rmd)
ok("RoundAll md:PS7 一行 = 檔 · 兩行 -EncodedCommand 解開 = 解開版 · 都在 8191 字元內", ps7 in rmd and len(b64s) == 2 and all(base64.b64decode(b).decode("utf-16-le") == boot for b in b64s)
   and all(len(l) < 8191 for l in rmd.splitlines() if "EncodedCommand" in l) and rsha[:12] in rmd and zsha[:12] in rmd)
ok("Handle-All / PS7 一行沒有 exit(視窗不關)· 沒有 # 註解", not re.search(r"\bexit\b", line) and not re.search(r"\bexit\b", ps7) and not re.search(r"(^|\s)#", line), "%d 字元" % len(line))
ps = r'''
$r = @()
foreach ($f in $args) { $t = $null; $e = $null; [void][System.Management.Automation.Language.Parser]::ParseFile($f, [ref]$t, [ref]$e); $sig = ($t | Where-Object { $_.Kind -notin 'NewLine', 'Semi', 'EndOfInput', 'LineContinuation', 'Comment' } | ForEach-Object { $_.Text }) -join "`u{1}"; $r += [pscustomobject]@{ f = (Split-Path $f -Leaf); e = $e.Count; n = $t.Count; h = [BitConverter]::ToString([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($sig))) } }
$r | ConvertTo-Json -Compress
'''
(W / "ps7/parse153.ps1").write_text(ps, encoding="utf-8")
files = [rel / "handleall_line.txt", rel / "handleall_src.ps1", rel / "oneline_roundall_ps7.txt", rel / "boot_roundall.ps1"]
res = json.loads(subprocess.run([PW, "-NoProfile", "-File", str(W / "ps7/parse153.ps1")] + [str(f) for f in files], capture_output=True, text=True).stdout)
ok("PowerShell 剖析(pwsh %s)0 錯:%s" % (subprocess.run([PW, "-NoProfile", "-Command", "$PSVersionTable.PSVersion.ToString()"], capture_output=True, text=True).stdout.strip(), " · ".join("%s %d 詞" % (r["f"], r["n"]) for r in res)), all(r["e"] == 0 for r in res))
ok("Handle-All 一行版 = 可讀版(去掉換行 / 分號後詞序列相同)", res[0]["h"] == res[1]["h"])
(W / "pscheck153.log").write_text("\n".join(out) + "\n", encoding="utf-8")
print("\n".join(out))
