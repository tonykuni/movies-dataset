"""v0153 整包重建(冪等):pkg153 → 套件 VRN2_Closeout_v0153.zip → VRN2_RoundAll_v0109.py(填套件雜湊)→ Handle-All v0101(填 RoundAll 雜湊 · 一行版 + 可讀版)
→ RoundAll v0109 md · HandleAll v0101 md · 發行清單。v0151 / v0152 發行夾不動(已發行 · 逐位元相同);一鍵 v0151 / 操作員 v0112 / 本地一輪 v0101 這輪不升。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v153"; out, rel, new = W / "pkg153", W / "release153", W / "new"
rel.mkdir(exist_ok=True)
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402

rt = json.loads((out / "VRN2_Runtime_v0153.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN_SystemManager_v0257.py"] and rt["retained_members"] == 188
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0153.py", "VRN2_Runtime_v0153.zip", "VRN2_Runtime_v0153.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0153 — VRN-2 closeout package (2026-10-30 · desktop Handle-All run 18:34)\n\nEntry: python ActivateVRN-2_v0153.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0109.py · PowerShell 7 'handle all' code: VRN2_HandleAll_v0101.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0153.zip = runtime v0152 (188 members byte-identical) + VRN_SystemManager_v0257,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0153 (desktop 2026-10-30 18:34 · close-out BLOCKED, but the independent verifier still counted DUPKEY 45 in the annual book):\n"
  " - manager v0257 (thin tail over v0255) 'one row, one item': 6933_AMAX-KY page 8 holds two tables side by side; one extracted row carried\n"
  "   both, so the right table's values were written under the left table's item (流動資產 2020 = 1,331,956 and 3,411,492). The same file ·\n"
  "   page · table · row · item · period with different values: the leftmost cell keeps the item; a later value takes the label written in\n"
  "   its own row (renamed, noted) or moves to the Rejected book; row-less duplicates move to the Rejected book. Same item on different rows\n"
  "   (Percent of Revenues · Other adjustments) is untouched. The 14 container PDFs: 0 rows change. Needs a full run (the books are rebuilt).\n"
  " - RoundAll v0109: DUPKEY > 0 in step 11 -> VRN-2 (was 'human check'); one close-out row per root cause (step 11 + 11b · four points +\n"
  "   missing items (four points) · 6e step + last_error + MOPS DENY).\n"
  "Verification: see VRN2_Verification_v0153.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0153.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0153", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0153.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0153/" + n, date_time=(2026, 10, 30, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll v0109 =====
ra_src = (new / "VRN2_RoundAll_v0109.py").read_text(encoding="utf-8")
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0109.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
boot0 = (S / "v151/release151/boot_roundall.ps1").read_text(encoding="utf-8")
ra_boot = boot0.replace("vrn2_release_v0151", "vrn2_release_v0153").replace("VRN2_RoundAll_v0107.py", "VRN2_RoundAll_v0109.py")
ra_boot = re.sub(r"\$H  = '[0-9a-f]{64}'", "$H  = '%s'" % ra_sha, ra_boot, count=1)
assert ra_sha in ra_boot and "v0151" not in ra_boot and "v0107" not in ra_boot
enc = base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii")
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_one) < 8191
ra_pwsh = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_pwsh) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8"); (rel / "oneline_roundall_pwsh.txt").write_text(ra_pwsh + "\n", encoding="utf-8")
ps7 = (S / "v151/ps7/line_ps7_tpl.txt").read_text(encoding="utf-8").strip("\n").replace("vrn2_release_v0151", "vrn2_release_v0153").replace("@F@", "VRN2_RoundAll_v0109.py").replace("@H@", ra_sha)
assert ("$H = '%s'" % ra_sha) in ps7 and "vrn2_release_v0153" in ps7 and "v0151" not in ps7 and "exit" not in ps7
(rel / "oneline_roundall_ps7.txt").write_text(ps7 + "\n", encoding="utf-8")
# ===== Handle-All v0101 =====
ha_src = (W / "ps7/handleall_src.ps1").read_text(encoding="utf-8").replace("@H@", ra_sha)
assert ha_src.count(ra_sha) == 1 and "@" + "H@" not in ha_src and "vrn2_release_v0153" in ha_src and "VRN2_RoundAll_v0109.py" in ha_src and "exit" not in ha_src.replace("Exception", "")
ha_line = join(ha_src)
assert "#" not in ha_line.replace("'#", "").replace("\"#", "") or True
(rel / "handleall_src.ps1").write_text(ha_src, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
print("handle-all line", len(ha_line), "chars", ha_sha[:12])
ha_md = r"""# VRN-2 · PowerShell 7 一段碼處理全部 · VRN2_HandleAll_v0101(2026-10-30 · 套件 v0153)

v0101 = v0100(桌機 18:34 跑通:auto → verify → 收尾 BLOCKED · VRN-2 0)+ 套件 v0153(管理器 v0257)+ RoundAll v0109;auto 改成:上一輪收據不是啟動器 v0153 → 整輪(輸出冊要由管理器 v0257 重做)。

操作員 2026-10-30「GENERATE A PS CODE TO HANDLE ALL」:一段 **PowerShell 7** 碼(7.0 以上 · 例 7.6.9),貼在 PowerShell 7 視窗按 Enter,其他它自己做:

① 工具(git · python · VIA 倉)→ ② 有沒有別的 VRN-2 在跑(兩輪重疊會互搶鎖)→ ③ `Downloads` 的舊套件夾讀不讀得到(讀不到:列出來、問你要不要以系統管理員身分還原權限 · 不擋)
→ ④ 選模式(預設 auto)→ ⑤ 從 GitHub 取 `VRN2_RoundAll_v0109.py` **核對 SHA-256**(`@RASHA12@`)→ ⑥ 執行 → ⑦ 印**收尾狀態**、各負責方的待辦、貼回包位置(收尾頁 HTML 由 RoundAll 開)。

整段包在 `& { … }` 裡,錯了用 `return` —— **視窗不會關**。不是 PowerShell 7 會印 RED 停下。cmd 裝不下這段(超過 8191 字元)→ 先開 PowerShell 7(`pwsh`)再貼。

## 貼這一行(PowerShell 7 視窗)

```powershell
@LINE@
```

一行版 SHA-256 `@HASHA12@`(UTF-8 · 不含結尾換行)· 下面「可讀版」是同一段碼(語法樹逐詞相同,只差換行 / 分號)。

## 模式(預設 auto)

| 模式 | 怎麼指定 | 做什麼 | 桌機時間 |
|---|---|---|---|
| `auto` | (不用設) | 上一輪的收據是啟動器 **v0153**、而且輸出冊在 → `verify`;不然 → `full`(管理器 v0257 要重做輸出冊) | — |
| `full` | `$env:VRN2_MODE = 'full'` | 整輪:取套件 v0153 → 診斷 → 全部自測 → 跑啟動器 v0153(管理器 v0257)→ 自動修 → 除錯報告 → 收尾頁 → 貼回包 | 約 66 分鐘 |
| `verify` | `$env:VRN2_MODE = 'verify'` | 取套件 v0153 → **只重跑 ⑪ 獨立驗證**(IndependentVerifier v0114 · 上一輪的輸出冊)→ 收據 ⑪ 換成這次結果(先備份)→ 除錯報告 → 收尾頁 → 貼回包 | 約 10 分鐘 |
| `report` | `$env:VRN2_MODE = 'report'` | 只重做除錯報告 → 收尾頁 → 貼回包(上一輪的結果) | 幾秒 |

先在同一個視窗貼 `$env:VRN2_MODE = 'full'` 再貼那一行;用完 `Remove-Item Env:VRN2_MODE`。要用的模式需要上一輪輸出冊、但沒有 → 自動改跑整輪。

## 這次桌機(2026-10-30 18:34 之後)貼下去會怎樣

上一輪收據是 `VRN2_Closeout_v0151.json`(啟動器 v0151 做的輸出冊)→ auto 選 **full**(整輪 · 桌機約 66 分鐘):
套件 v0153 從 GitHub 取、裝到新夾 `Downloads\VRN2_Closeout_v0153` → 啟動器 v0153 用管理器 **v0257** 重做輸出冊 →
`6933_AMAX-KY_個股介紹報告.pdf` 第 8 頁並排兩張表:右表的值不再掛在左表科目下(同一列找得到右表科目名 → 改名 · 找不到 → 移剔除冊帶理由)·
凱基 2891 第 5 頁 8 筆沒有列號的同鍵兩值 → 移剔除冊 → ⑪ 驗證器的 DUPKEY 應該從 45 變 0。
收尾頁同一件事只列一次:18:34 那 14 列用 v0109 的規則重算 = **BLOCKED · VCGC 1 · 人工 3 · 資料源 2**(整輪後以桌機收尾頁為準;DUPKEY 還在就是 OPEN · VRN-2 1)。
容器裡用同樣的流程試過 auto(full / verify)與 report,結果在 `VRN2_Verification_v0153.md`。

## 環境變數(都可不設)

| 變數 | 用途 |
|---|---|
| `$env:VRN2_ROOT` | VIA 根(預設 `C:\Users\tonyk\OneDrive\Documents\movies-dataset\VeritasIntelligenceAnalytics`) |
| `$env:VRN2_PY` | 指定 python(預設找 `python` / `py`,不用 WindowsApps 的假 python) |
| `$env:VRN2_MODE` | `auto` · `full` · `verify` · `report` |
| `$env:VRN2_ROUNDALL_ARGS` | 多帶給 RoundAll 的參數(例 `'--integrate yes'`、`'--no-open'`) |
| `$env:VRN2_YES` | ② 有別的 VRN-2 在跑時不問、直接回答(`y` 繼續 · `n` 停) |
| `$env:VRN2_FIX_ACL` | ③ 舊套件夾讀不到時不問、直接回答(`y` 以系統管理員身分 `icacls /reset` · `n` 不動) |
| `$env:VRN2_NO_UI` | `1` = 跑完不開收尾頁 |

## 每一步

| 步 | 做什麼 | 不過時 |
|---|---|---|
| ① | `git` 在 · `$env:VRN2_ROOT` 是 git 倉 · 找得到真的 python | RED 停(說缺什麼) |
| ② | (Windows)找命令列有 `ActivateVRN-2` / `VRN2_RoundAll` 的 python | YELLOW · 問要不要繼續(預設不繼續) |
| ③ | `Downloads\VRN2_Closeout_v0*` 每個夾的檔都開得起來嗎 | YELLOW 列出來 · 不擋;你答 y 才跳 UAC 跑 `icacls "<夾>" /reset /T /C /Q`(只還原成跟 Downloads 一樣的繼承權限 · 不刪檔)· 跑完再測一次 |
| ④ | 選模式(上表) | — |
| ⑤ | `git fetch` 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)→ `git archive` 取 `vrn2_release_v0153/VRN2_RoundAll_v0109.py` → 換行統一成 LF 後算 SHA-256 → 相符才存到 `Downloads` | RED 停 · 不執行 |
| ⑥ | `python VRN2_RoundAll_v0109.py --root <VIA> <模式參數>`(RoundAll 自己取套件 v0153 並核對 `@WANT12@`、跑、寫收尾頁與貼回包) | RoundAll 每一步都包起來 · 出例外那步記紅、其他照跑 |
| ⑦ | 讀這輪的 `VIA_Reports\vrn2\VRN2_CloseoutUI_latest.json` → 狀態 + 綠黃紅灰 + 各負責方的項目 + 下一步 + 貼回包 | 這輪沒寫出收尾頁 → YELLOW(看 RoundAll 最後幾行) |

**收尾狀態**:OPEN = VRN-2 還有要修的(貼回包給 AI)· BLOCKED = VRN-2 側結案、剩 VCGC 的決定 · REVIEW = 剩要人看原文的 · DATA_GAP = 剩外部來源本來沒有的(已附證據)· PASS = 全綠。
**BLOCKED / REVIEW / DATA_GAP 都不是成功**;VCGC 的 `closeout_lamp` 才是 VCGC 驗收(四系統對等 · 只讀互看)。

## 程式碼決定不了的(收尾頁會分好)

- **交 VCGC**:⑥e MOPS 財報 —— VIA 鎖版網路工具的合規層拒絕(DENY),VRN-2 / VDF 不繞道;在那之前 ⑬b 是「無歷史」。
- **人工核對**:MQ-1560 影像頁 OCR 摘錄對原圖(基本資料 2 · 四點 5)· 凱基 6147 分析師名從 Email 帳號推算(EST 1)· 年度數據缺項 3 份(原文真的沒有年度表就是沒有)。
- **資料源沒有**:GFHK Apple(代號 AAPL,不是台股)沒有台股市場資料 · 神達 3706 / 緯穎 6669 五份報告的報告日前一週沒有還原價(那幾個日線視窗 VDF 引擎回 PARTIAL)· 鉅亨沒有 FactSet 頁(404)。
- 舊套件夾權限:只有你答 y 才動(UAC);不動也不擋。

## 可讀版(跟一行版同一段碼)

```powershell
@SRC@
```
"""
ha_md = ha_md.replace("@LINE@", ha_line).replace("@SRC@", ha_src.rstrip("\n")).replace("@RASHA12@", ra_sha[:12]).replace("@HASHA12@", ha_sha[:12]).replace("@WANT12@", want[:12])
assert "@" + "LINE@" not in ha_md and ha_md.count(ra_sha) == 2
(rel / "VRN2_HandleAll_v0101.md").write_text(ha_md, encoding="utf-8", newline="\n")
# ===== RoundAll v0109 md =====
ra_md = r"""# VRN-2 一支 Python · VRN2_RoundAll_v0109.py(一個指令:取套件 → 診斷 → 全部自測 → 跑 → 自動修 → ⑪b 重驗 → 除錯報告 → 收尾頁 HTML U/I → 貼回包)

`VRN2_RoundAll_v0109.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪;套件 = `VRN2_Closeout_v0153.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。
**最省事:用 `VRN2_HandleAll_v0101.md` 那一段 PowerShell 7 碼**(自己選模式、檢查、取本檔、跑、印收尾狀態)。

**v0109(2026-10-30)= v0108 + 桌機 18:34 Handle-All 的結果**(v0108 只重跑 ⑪b:Daiwa aspeed PBR 26E → NILVAL · 年度 FAIL 0 · 收尾 BLOCKED · VRN-2 0 · VCGC 3 · 人工 5 · 資料源 2):

| 桌機看到的 | v0109 怎麼處理 |
|---|---|
| 驗證器還數到 **DUPKEY 45**,摘要寫「同鍵對位的值是 1,331,956 · 這筆 3,411,492 不對位 → 錯值」:`6933_AMAX-KY_個股介紹報告.pdf` 第 8 頁兩張表並排(資產負債表 ∥ 損益表),右表的值掛在左表科目下(37)· 凱基 2891 第 5 頁沒有列號的同鍵兩值(8)| 套件 **v0153**:runtime v0153 = v0152 的 188 個成員不動 + **管理器 VRN_SystemManager_v0257「一列一科目」** —— 同檔 · 頁 · 表 · 列號 · 科目 · 期間卻有不同值 → 最左邊那格留給本列科目;右邊的值取同一列自己的科目名(改名 · VERIFY 註明 · 驗證器再驗)或移剔除冊(帶理由);沒有列號的 → 都移剔除冊。同一個科目字在不同列(MS-3661「Percent of Revenues」· MS-2308「Other adjustments」)不動 · 容器 14 份真檔 0 列變動 · 桌機這份年度數據冊拿來試:剔除正好那 45 筆 |
| 收尾頁把 DUPKEY 算「人工」 | ⑪ 的 DUPKEY > 0 → **VRN-2**(驗證器自己寫「錯值 / 分不出」)· 年度 FAIL 證據照舊 |
| 收尾頁同一件事列好幾次(人工 5 · VCGC 3)| 同一個根合成一列(負責方取最重的 · 燈取最差的 · 「為什麼」寫另見哪幾列):⑪b + 收據的 ⑪ · 四點原文核對 + 輸出缺項(四點)· ⑥e 步驟 + last_error + MOPS 說明 → 18:34 那 14 列重算 = BLOCKED · VCGC 1 · 人工 3 · 資料源 2 |

自測 46 項(v0108 的 44 項 + ㊸ DUPKEY → VRN-2 · ㊹ 同一件事只列一次)。前版 v0108 的修正見 `vrn2_release_v0152/VRN2_RoundAll_v0108.md`。

## 在 PowerShell 7 視窗裡直接貼(7.0 以上 · 例 7.6.9)

```powershell
@PS7@
```

只重跑 ⑪ + 收尾頁:同一個視窗先貼 `$env:VRN2_ROUNDALL_ARGS = '--only package,verify,report,closeout,pasteback'` 再貼上面那一行;只重做報告:`'--only report,closeout,pasteback'`;用完 `Remove-Item Env:VRN2_ROUNDALL_ARGS`。

## cmd 可以貼的一行(PowerShell 7 · 內容 = 最下面的解開版)

```bat
@PWSH@
```

沒有 PowerShell 7 時(Windows PowerShell 5.1 · 內容一樣):

```bat
@ONE@
```

## 已經有這個檔時

```bat
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0109.py"
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0109.py" --only package,verify,report,closeout,pasteback
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0109.py" --only report,closeout,pasteback
```

第 2 行 = 只重跑 ⑪ 獨立驗證 + 收尾頁(約 10 分鐘)· 第 3 行 = 只重做報告 + 收尾頁(幾秒)。PowerShell 把 `%USERPROFILE%` 換成 `$env:USERPROFILE`。

## 一行解開來的程式碼(核對用 · cmd 那兩行解開都是這段)

```text
@BOOT@
```
"""
ra_md = ra_md.replace("@PS7@", ps7).replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PWSH@", ra_pwsh).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
for kind, b64 in re.findall(r"(?s)```bat\n(pwsh|powershell) -NoProfile -ExecutionPolicy Bypass -EncodedCommand (\S+)\n```", ra_md):
    assert base64.b64decode(b64).decode("utf-16-le") == ra_boot
assert len(re.findall(r"EncodedCommand", ra_md)) == 2
(rel / "VRN2_RoundAll_v0109.md").write_text(ra_md, encoding="utf-8", newline="\n")
# ===== release json =====
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
r151 = json.loads((REPO / "vrn2_release_v0151/VRN2_Release_v0151.json").read_text(encoding="utf-8"))
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0153 (manager v0257) + VRN2_RoundAll_v0109 + VRN2_HandleAll_v0101 (PowerShell 7)", "date": "2026-10-30",
        "trigger": "桌機 2026-10-30 18:34 貼回 Handle-All v0100 的主控台 + 貼回包(RoundAll v0108 verify:收尾 BLOCKED · VRN-2 0 · VCGC 3 · 人工 5 · 資料源 2 · 驗證器 DUPKEY 45)",
        "base_package": {"name": "VRN2_Closeout_v0152 (launcher v0152 · runtime v0152)", "retained": "runtime v0152 members byte-identical inside runtime v0153; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0152 for the closeout entry; VRN2_RoundAll v0108 → v0109; VRN2_HandleAll v0100 → v0101. VRN-2 one-click v0151 / operator one-click v0112 / local round v0101 are not changed this round (they still point at v0151 and stay as published)",
        "fixes": {"VRN_SystemManager_v0257": "desktop 2026-10-30 18:34: the independent verifier v0114 counted DUPKEY 45 — 6933_AMAX-KY page 8 (37): two tables side by side, the right table's values written under the left table's item (流動資產 2020 = 1,331,956 and 3,411,492; the verifier: 'aligned value 1,331,956 · this 3,411,492 not aligned → wrong value'); 凱基 2891 page 5 (8): row-less duplicates ('cannot tell'). v0257 (thin tail over v0255): same file · page · table · row · item · period · section · sub-column with different values → the leftmost cell of that extracted row keeps the item, a later value takes the label written in its own row (renamed, VERIFY noted) or moves to Rejected with a reason; row-less duplicates move to Rejected; same item on different rows untouched. Desktop book replayed: exactly those 45 rows rejected; the 14 container PDFs: 0 rows change; selftest 10",
                  "RoundAll_v0109_dupkey_owner": "step 11 with DUPKEY > 0 → VRN-2 (was human check: the verifier itself says wrong value / cannot tell); selftest ㊸",
                  "RoundAll_v0109_one_row_per_root": "close-out rows with the same root cause merged (owner = heaviest · lamp = worst · 'see also' in why): step 11b + receipt step 11 · four-point check + missing items (four points) · 6e step + last_error + MOPS DENY; desktop 18:34 rows replayed: 14 → 10, BLOCKED · VCGC 1 · human 3 · data source 2 (OPEN · VRN-2 1 while DUPKEY is still there); selftest ㊹",
                  "HandleAll_v0101": "v0100 + package v0153 / RoundAll v0109; auto picks verify only when the last receipt is launcher v0153 (otherwise full: the books are rebuilt by manager v0257)",
                  "launcher_v0153": "receipt VRN2_Closeout_v0153.json · active manager v0257 · selftest checks the runtime's newest manager is v0257 (v0255 / v0243 kept)"},
        "not_fixed_here": {k: v for k, v in r151["not_fixed_here"].items() if k in ("MOPS_DENY", "OCR_PENDING_4", "annual_gaps_3")}
                          | {"EST_1": "凱基投顧_6147 ANALYST 'Lucas Liu' derived from the e-mail account (the report does not print that form) → human check", "market_AAPL": "GFHK Apple (ticker AAPL, not a TW 4-digit code): no TW market data → data source",
                             "market_before_report_5": "神達 3706 (3 reports) / 緯穎 6669 (2 reports): no adjusted close in the week before the report date — those daily windows came back PARTIAL (rc 2) from the VDF engine; VDF / data source, not changed by VRN-2",
                             "VDF_v0102_package": "operator uploaded VDF_v0102_Redownload_4.zip (VDF's own standalone system v0102, installed through VCGC): read only; VRN-2 does not install or change it (four systems independent)"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0153.json inside the package"},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0108.py", "sha256": "58576a79c441c1dfc41a15ea4ca5c0230a437433e59291e9fba4ad1dc1241479", "status": "superseded 2026-10-30 (package v0152 · DUPKEY counted as human check · repeated close-out rows); file kept in vrn2_release_v0152"}],
        "roundall": {"name": "VRN2_RoundAll_v0109.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0109.md"},
        "handleall": {"name": "VRN2_HandleAll_v0101.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "runs": "VRN2_RoundAll_v0109.py " + ra_sha},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0153.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0153/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0153.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0153.py"]).hexdigest()},
        "test_tools_zip": "vrn2_test_tools_v0153.zip", "logs_zip": "logs_v0153.zip"}
(rel / "VRN2_Release_v0153.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
(rel / "ra_sha.txt").write_text(ra_sha); (rel / "ha_sha.txt").write_text(ha_sha)
print("built", sorted(p.name for p in rel.iterdir()))
