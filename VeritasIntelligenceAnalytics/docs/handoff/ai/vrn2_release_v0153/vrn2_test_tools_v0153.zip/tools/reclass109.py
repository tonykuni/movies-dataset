import json, sys, importlib.util, re
spec = importlib.util.spec_from_file_location("ra109", sys.argv[1]); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
doc = json.load(open(sys.argv[2], encoding="utf-8"))
ctx = dict(doc.get("context") or {}); ctx["receipt"] = True
for k in ("no_cov", "gate_other"):
    ctx[k] = set(ctx.get(k) or [])
rows = [{"lamp": i["lamp"], "step": i["step"], "detail": i["detail"]} for i in doc["items"]]
def run(rows, label):
    its = []
    for r in rows:
        got = m.owner_of(r, ctx)
        if got: its.append(dict(r, owner=got[0], why=got[1]))
    merged = m.merge_same(its, ctx)
    st, txt, po = m.closeout_state([i for i in merged if i["owner"] not in ("提醒", "彙總")])
    print("%s → %s · %s · %s · 列 %d → %d" % (label, st, txt, po, len(its), len(merged)))
    for i in merged:
        if i["owner"] not in ("提醒", "彙總"):
            print("   [%s] %s%s" % (i["owner"], i["step"][:60], ("  (+" + "、".join(a[:24] for a in i["also"]) + ")") if i.get("also") else ""))
print("18:34 原判:", doc["state"], doc["per_owner"])
run(rows, "v0109 規則 · 同一份結果(DUPKEY 45 還在)")
rows2 = [dict(r, detail=re.sub(r"'DUPKEY': \d+, ", "", r["detail"])) for r in rows]
run(rows2, "v0109 規則 · 整輪重跑後(管理器 v0257 → DUPKEY 0 的預期)")
