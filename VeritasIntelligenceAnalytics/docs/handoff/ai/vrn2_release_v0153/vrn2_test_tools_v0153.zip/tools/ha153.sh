#!/bin/bash
# Handle-All v0100 沙盒測試:$1 = 沙盒(t152d = 桌機情境:只有啟動器 v0151 的收據 + 上一輪輸出 · t152 = 全新)· $2 = 回合名 · 其餘 = env 指派(例 VRN2_MODE=report)
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v153; T=$W/$1; N="$2"; shift 2
OCRPY=$S/v131/ocrenv/vrn2_ocr/bin/python; P=$S2/venv_vrn2/bin/python
FX=$(cat $S/v148/fx148.list)
LINE=$(cat $W/release153/handleall_line.txt)
cd "$T/home" && env HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ENVS_HOME="$T/envs" VIA_TOOLS_ROOT="$T/VIA" VIA_ROOT="$T/VIA" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 \
  VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_OUTPUT_DIR="$T/OneDrive/VRN2_out" VRN2_CONSENSUS_FIXTURES="$FX" VRN2_CONSENSUS_YEAR=2026 VRN2_INTEGRATE_TEMP="$T/tmp" \
  VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_SOURCE="$T/samples" VRN2_ROUNDALL_ARGS="--python $P --no-open --integrate yes --launcher-args --no-install" "$@" \
  timeout 7000 "$S2/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -Command "$LINE" > $W/ha153_$N.log 2>&1
echo "$N rc $?" >> $W/ha153.rc
sed -i 's/\x1b\[[0-9;]*m//g' $W/ha153_$N.log
