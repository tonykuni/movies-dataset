import csv, json, sys, glob, collections, importlib.util, io, contextlib
from pathlib import Path
R = Path(sys.argv[1])
spec = importlib.util.spec_from_file_location("m257", R / "VRN_SystemManager_v0257.py"); m = importlib.util.module_from_spec(spec); sys.modules["m257"] = m
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(m)
for label, book, cache in (("桌機 18:34(52 份)", sys.argv[2], None), ("容器 t152(14 份 · 有擷取快取)", sys.argv[3], sys.argv[4])):
    if book.endswith(".json"):
        fin = json.load(open(book, encoding="utf-8"))
    else:
        fin = list(csv.DictReader(open(book, encoding="utf-8-sig")))
    res = []
    if cache:
        for p in glob.glob(cache + "/*.json"):
            try:
                d = json.load(open(p, encoding="utf-8"))
            except Exception:
                continue
            if isinstance(d, dict) and d.get("pages"):
                res.append(d)
    keep, rej, ren, ex = m._rowfix(fin, res)
    print("==", label, "· 年度數據", len(fin), "→ 留", len(keep), "· 改名", ren, "· 剔除", len(rej), collections.Counter(x["FILENAME"][:22] for x in rej).most_common())
    for e in ex: print("   ", e)
    for x in rej[:3]: print("    剔除例:", x["ITEM"], x["PERIOD"], x["VALUE"], "·", x["REASON"][:110])
