#!/bin/bash
# v0153 放進倉:docs/handoff/ai/vrn2_release_v0153/ + VRN2_Handover_v0154.md(固定時間戳 · 冪等)· .ps1 只在 zip 裡 · 不放桌機貼回內容 · 不放 VDF 的包
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v153
D=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0153; mkdir -p $D
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v153")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0153")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 30, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(p.name, p) for p in sorted(W.glob("ha153_*.log"))] + [(n, W / n) for n in ("ha153.rc", "rall109_selftest.log", "m257_selftest.log", "ActivateVRN-2_v0153_selftest_iso.log",
        "try_rowfix.log", "reclass109.log", "pscheck153.log", "mk_market153.log", "drive153.log", "d_tamper_file.txt")]
v2 = W / "t153d/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0153.json", "VRN2_Closeout_v0153.before_roundall.json", "VRN2_RoundAll_latest.json", "VRN2_CloseoutUI_latest.html", "VRN2_CloseoutUI_latest.json", "VRN2_Phase_Timing_latest.json"):
    logs.append(("t153d/" + n, v2 / n))
z(D / "logs_v0153.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh"))]
tools += [("tools/ps7/" + q.name, q) for q in sorted((W / "ps7").glob("*")) if q.suffix in (".py", ".ps1", ".txt") and not q.name.endswith(".sig")]
tools += [("release/" + n, W / "release153" / n) for n in ("handleall_src.ps1", "handleall_line.txt", "boot_roundall.ps1", "oneline_roundall.txt", "oneline_roundall_pwsh.txt", "oneline_roundall_ps7.txt")]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py"))]
z(D / "vrn2_test_tools_v0153.zip", tools)
for n in ("VRN2_Closeout_v0153.zip", "VRN2_Release_v0153.json", "VRN2_RoundAll_v0109.py", "VRN2_RoundAll_v0109.md", "VRN2_HandleAll_v0101.md", "VRN2_Verification_v0153.md"):
    shutil.copy(W / "release153" / n, D / n)
print("staged")
PY
ls -la $D | awk '{print $5, $9}'
