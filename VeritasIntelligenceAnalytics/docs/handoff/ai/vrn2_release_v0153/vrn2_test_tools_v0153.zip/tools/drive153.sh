#!/bin/bash
# 桌機情境(複製 v0151 沙盒:只有啟動器 v0151 的收據 + 上一輪輸出)· Handle-All v0101:auto(→ full · 管理器 v0257)→ auto(→ verify)→ report → 竄改
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=$S/v153; T=$W/t153d; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v151/t151 $T && git -C $T/VIA remote set-url origin $T/remote.git && bash $W/mkbranch153.sh t153d
cp $T/VIA/VIA_Reports/vrn2/output/VRN2_FinancialData_latest.json $W/d_fin_before.json
bash $W/ha153.sh t153d d_auto_full
$S2/venv_vrn2/bin/python $S/v148/mk_market148.py "$T/VIA/VIA_Reports/vrn2" > $W/mk_market153.log 2>&1
bash $W/ha153.sh t153d d_auto_verify
bash $W/ha153.sh t153d d_report VRN2_MODE=report
(cd $T.br && printf '\n# tampered\n' >> VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0153/VRN2_RoundAll_v0109.py && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5)
mv $T/home/Downloads/VRN2_RoundAll_v0109.py $T/home/Downloads/VRN2_RoundAll_v0109.py.keep
bash $W/ha153.sh t153d d_tamper
ls $T/home/Downloads/VRN2_RoundAll_v0109.py > $W/d_tamper_file.txt 2>&1; mv $T/home/Downloads/VRN2_RoundAll_v0109.py.keep $T/home/Downloads/VRN2_RoundAll_v0109.py
bash $W/mkbranch153.sh t153d
echo done-drive >> $W/ha153.rc
