$Files = $args
foreach ($f in $Files) {
  $t = $null; $e = $null
  $ast = [System.Management.Automation.Language.Parser]::ParseFile($f, [ref]$t, [ref]$e)
  "{0}: errors {1} · tokens {2}" -f (Split-Path $f -Leaf), $e.Count, $t.Count
  $e | ForEach-Object { "  " + $_.Message + " @" + $_.Extent.StartLineNumber + ":" + $_.Extent.StartColumnNumber }
  $sig = ($t | Where-Object { $_.Kind -notin 'NewLine', 'Semi', 'EndOfInput', 'LineContinuation', 'Comment' } | ForEach-Object { $_.Text }) -join "`u{1}"
  [IO.File]::WriteAllText("$f.sig", $sig)
}
