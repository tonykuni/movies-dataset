import json, sys, glob
want = dict(a.split("=", 1) for a in sys.argv[2:])
for p in glob.glob(sys.argv[1] + "/p1_cache/*.json"):
    try:
        d = json.load(open(p, encoding="utf-8"))
    except Exception:
        continue
    if want["file"] not in str(d.get("file", "")):
        continue
    for pg in d.get("pages") or []:
        for z in pg.get("zones") or []:
            if z.get("id") == want["table"]:
                print(p.split("/")[-1], d.get("file"), z.get("id"), z.get("bbox"))
                for i, r in enumerate(z.get("rows") or []):
                    print("%2d" % i, [c[:22] for c in r])
                sys.exit(0)
