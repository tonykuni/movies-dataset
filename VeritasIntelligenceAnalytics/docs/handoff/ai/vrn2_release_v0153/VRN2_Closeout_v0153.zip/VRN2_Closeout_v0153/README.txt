VRN2_Closeout_v0153 — VRN-2 closeout package (2026-10-30 · desktop Handle-All run 18:34)

Entry: python ActivateVRN-2_v0153.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0109.py · PowerShell 7 'handle all' code: VRN2_HandleAll_v0101.md (same release folder).
Runtime: VRN2_Runtime_v0153.zip = runtime v0152 (188 members byte-identical) + VRN_SystemManager_v0257,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0153 (desktop 2026-10-30 18:34 · close-out BLOCKED, but the independent verifier still counted DUPKEY 45 in the annual book):
 - manager v0257 (thin tail over v0255) 'one row, one item': 6933_AMAX-KY page 8 holds two tables side by side; one extracted row carried
   both, so the right table's values were written under the left table's item (流動資產 2020 = 1,331,956 and 3,411,492). The same file ·
   page · table · row · item · period with different values: the leftmost cell keeps the item; a later value takes the label written in
   its own row (renamed, noted) or moves to the Rejected book; row-less duplicates move to the Rejected book. Same item on different rows
   (Percent of Revenues · Other adjustments) is untouched. The 14 container PDFs: 0 rows change. Needs a full run (the books are rebuilt).
 - RoundAll v0109: DUPKEY > 0 in step 11 -> VRN-2 (was 'human check'); one close-out row per root cause (step 11 + 11b · four points +
   missing items (four points) · 6e step + last_error + MOPS DENY).
Verification: see VRN2_Verification_v0153.md. Hashes: PACKAGE_SHA256.json.
