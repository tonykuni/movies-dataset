VRN2_Closeout_v0142 — VRN-2 closeout package (2026-10-28)

Entry: python ActivateVRN-2_v0142.py [--source <folder>] [--no-install] [--no-open]
Runtime: VRN2_Runtime_v0142.zip (159 members of runtime v0141 byte-identical + VRN_ENG062_SummarizerV1_v0117.py + VRN2_Workbench_v0100.py + VRN2_Workbench_Assets_v0100.zip)
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0142: summarizer v0117 (excerpts no longer start with a page banner / title / section heading);
Workbench U/I v0100 (operator template locked as the front end, bound to this run's receipts and output books, vrn2:// actions wired,
VRN2_Logo.png auto-transparent) rendered to VIA_Reports/vrn2/VRN2_Workbench_latest.html after the closeout receipt and opened.
Logo: place the seal image as <VIA>/functional modules/VRN/SSOT/VRN2_Logo.png (or .jpg); it is made transparent on render.
Exit codes: 0 GREEN · 2 YELLOW (review items / OCR pending / non-Windows ③) · 1 RED.
