import importlib.util, json, sys, time, traceback, os
from pathlib import Path
mod_path = Path(sys.argv[1]); samples = Path(sys.argv[2]); out = Path(sys.argv[3])
spec = importlib.util.spec_from_file_location("eng062_under_test", mod_path); m = importlib.util.module_from_spec(spec); sys.modules[spec.name] = m; spec.loader.exec_module(m)
res = {}
for pdf in sorted(samples.glob("*.pdf")):
    t = time.time()
    try:
        r = m.summarize_pdf(str(pdf))
        res[pdf.name] = {"title": r.get("title_original"), "points": [{"text": p.get("text"), "status": p.get("status"), "sel": (p.get("evidence") or [{}])[0].get("selection"), "page": (p.get("evidence") or [{}])[0].get("page")} for p in r["points"]], "version": r.get("version"), "secs": round(time.time() - t, 1)}
    except Exception as exc:
        res[pdf.name] = {"error": "%s: %s" % (exc.__class__.__name__, str(exc)[:200]), "secs": round(time.time() - t, 1)}
    print(pdf.name[:40], res[pdf.name].get("error", "ok"), res[pdf.name]["secs"], flush=True)
out.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
