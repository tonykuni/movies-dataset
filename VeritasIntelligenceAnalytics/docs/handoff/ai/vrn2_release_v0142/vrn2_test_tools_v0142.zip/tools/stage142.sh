#!/bin/bash
# v0142 放進 movies-dataset 倉:docs/handoff/ai/vrn2_release_v0142/(套件 zip · 發行 json · 一鍵 md · 實測 md · logs zip · 工具 zip)+ 交接 v0142(latest 是桌機線的,不蓋)+ vrn1_vrn2_oneclick_v0103/(不放 .ps1 · 固定時間戳 · 冪等)
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v142
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0142; mkdir -p $D $REPO/vrn1_vrn2_oneclick_v0103
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v142"); L = W.parent / "local1028"
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0142")
OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0103")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 28, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("full142.log", "full142.rc", "wb_selftest.log", "wb_ui.log", "wb_ui_run.log", "ui_old.log", "scen_first.log", "scen_again.log", "scen_tamper.log", "scen.rc", "pscheck.log", "results142.json")]
logs += [("local1028/" + n, L / n) for n in ("v0116_real.json", "v0117_real.json", "run_v0117_real.log")]
logs += [("shots/" + q.name, q) for q in sorted((W / "shots").glob("wb_*.png"))] + [("shots_run/" + q.name, q) for q in sorted((W / "shots_run").glob("wb_*.png"))]
v2 = W / "t142/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0142.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_Acceptance_latest.json"):
    logs.append(("t142/" + n, v2 / n))
for q in sorted((v2 / "verify_independent").glob("*.digest.txt")):
    logs.append(("t142/" + q.name, q))
z(D / "logs_v0142.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.js")) + sorted(W.glob("*.ps1"))]
tools += [("tools/local1028/" + q.name, q) for q in sorted(L.glob("*.py"))]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py"))]
z(D / "vrn2_test_tools_v0142.zip", tools)
z(OP / "tools_v0103.zip", [("tools/" + q.name, q) for q in (W / "operator103.py", W / "pscheck.ps1", W / "pscheck.log", W / "operator103" / "boot_pair103.ps1", W / "operator103" / "oneline_pair103.txt", W / "operator103" / "Run-VRN1-VRN2-v0103.ps1")])
shutil.copy(W / "operator103" / "VRN1_VRN2_OneClick_v0103.md", OP / "VRN1_VRN2_OneClick_v0103.md"); shutil.copy(W / "operator103" / "VRN1_VRN2_Verification_v0103.md", OP / "VRN1_VRN2_Verification_v0103.md")
print("zips ok")
PY
cp $W/release142/VRN2_Closeout_v0142.zip $W/release142/VRN2_Release_v0142.json $W/release142/VRN2_OneClick_v0142.md $W/release142/VRN2_Verification_v0142.md $D/
cp $W/release142/VRN2_Handover_v0142.md $REPO/VRN2_Handover_v0142.md   # latest 是桌機線(v0145)的,不蓋
ls -la --time-style=+%H:%M $D $REPO/vrn1_vrn2_oneclick_v0103 | awk '{print $5, $7}'
