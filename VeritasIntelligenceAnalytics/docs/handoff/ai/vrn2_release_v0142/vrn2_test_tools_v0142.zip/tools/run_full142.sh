#!/bin/bash
# 整輪:套件啟動器(預設 v0140)跑沙盒 52 份 · $1 = 樹 · $2 = 啟動器檔名(在 pkg 內)· $3 = 日誌名
S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v142
T="$1"; L="${2:-ActivateVRN-2_v0142.py}"; N="${3:-full142}"
OCRPY=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131/ocrenv/vrn2_ocr/bin/python
OCRBR=$T/pkg/VRN2_OCRBridge_v0101.py
P=$S2/venv_vrn2/bin/python
cd "$T/pkg" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VRN2_ROOT="$T/VIA" VIA_TOOLS_ROOT="$T/VIA" VIA_ENVS_HOME="$T/envs" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$OCRBR" PYTHONUTF8=1 PYTHONIOENCODING=utf-8 PYTHONHASHSEED=0 PYTHONDONTWRITEBYTECODE=1 \
  VIA_VRN2_NO_PUSH=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 \
  timeout 7000 $P -X utf8 "$T/pkg/$L" --no-install --no-open --source "$T/samples" > "$W/$N.log" 2>&1
echo "$N rc $?" >> "$W/$N.rc"
sed -i 's/\x1b\[[0-9;]*m//g' "$W/$N.log"
