"""一鍵 v0142:從倉裡的 VRN2_OneClick_v0141.md 取 v0141 一鍵程式碼 → 換成套件 v0142(③ 取 VRN2_Closeout_v0142.zip · ⑤ 多一行 Workbench)→ 重算 SHA / boot / 一行。
用法:python oneclick142.py <VRN2_OneClick_v0141.md> <VRN2_Closeout_v0142.zip SHA-256> <輸出夾>"""
import base64, hashlib, re, sys
from pathlib import Path
src, want, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]); assert re.fullmatch(r"[0-9a-f]{64}", want); out.mkdir(parents=True, exist_ok=True)
md = src.read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1); one = re.search(r"(?s)```bat\n(.*?)\n```", md).group(1)
assert base64.b64decode(one.split()[-1]).decode("utf-16-le") == boot + "\n"
def rep(a, b, n=1):
    global ps
    assert ps.count(a) == n, (ps.count(a), a[:80]); ps = ps.replace(a, b)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1)
rep("  $Want   = '%s'   # VRN2_Closeout_v0141.zip SHA-256(套件 · 內含啟動器 v0141 + runtime v0141 清單)" % old_want,
    "  $Want   = '%s'   # VRN2_Closeout_v0142.zip SHA-256(套件 · 內含啟動器 v0142 + runtime v0142 清單)" % want)
rep("""    Write-Host ("[計] VRN-2 一鍵 v0141 · ActivateVRN-2 v0141(套件 · 私有 runtime v0141:管理器 v0243 · 摘要器 v0116 · 驗證器 v0110 · 原文核對 v0104)· {0}" -f $(if ($NoPush) { '只實測不上船' } else { '收尾驗證(套件啟動器不上船 · ⑨ 灰)' })) -ForegroundColor Yellow""",
    """    Write-Host ("[計] VRN-2 一鍵 v0142 · ActivateVRN-2 v0142(套件 · 私有 runtime v0142:管理器 v0243 · 摘要器 v0117 · 驗證器 v0110 · 原文核對 v0104 · Workbench U/I v0100)· {0}" -f $(if ($NoPush) { '只實測不上船' } else { '收尾驗證(套件啟動器不上船 · ⑨ 灰)' })) -ForegroundColor Yellow""")
rep("""idm = j(v2 / "IDEMPOTENCE_latest.json") or {}""",
    """wb = cl.get("workbench") or {}
if wb:
    print("%s|Workbench U/I v0100 · %s" % ("GREEN" if wb.get("lamp") == "GREEN" else "YELLOW", (wb.get("path") or wb.get("detail") or "")[:150]))
else:
    print("YELLOW|Workbench U/I 沒渲染(收據沒有 workbench 欄)")
idm = j(v2 / "IDEMPOTENCE_latest.json") or {}""")
rep("""  # ===== VRN-2 一鍵 v0141(套件 v0141 = 另一團隊收尾套件 v0104 的 v0140 入口 + 本輪修正:""",
    """  # ===== VRN-2 一鍵 v0142(套件 v0142 = v0141 + 摘要器 ENG062 v0117(四點開頭不再帶頁首列 / 標題列 / 小標題)+ Workbench U/I v0100(操作員 2026-10-28 上傳範本視覺鎖定 · 綁本輪收據與輸出冊 · 收尾後自動產出並開啟 · VRN2_Logo.png 自動去背);v0141 = 另一團隊收尾套件 v0104 的 v0140 入口 + 修正:""")
n = ps.count("v0141"); ps = ps.replace("v0141", "v0142")
assert "摘要器 v0116" not in ps.split("[計] VRN-2 一鍵")[1].split("\n")[0]
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
h_old = re.search(r"\$H  = '([0-9a-f]{64})'", boot).group(1); boot = boot.replace(h_old, cs).replace("v0141", "v0142") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = """# VRN-2 一鍵 v0142(cmd / PowerShell 都能貼 · 套件 v0142 = v0141 + 摘要器 v0117 + Workbench U/I v0100)

操作員令(2026-10-28):貼回的本地實測(v0136 線 · 摘要器 v0114)四點摘要截斷 / 混進頁首;「模板視覺鎖定作為前端 html u/i 與後端連棟整合為一個系統 · 透明去背 logo 無框無特效取代模板 logo」。

v0142 = v0141 入口 + runtime v0142(= v0141 的 159 個成員逐位元保留 + 3 個新檔):

| 元件 | 版本 | 改了什麼 |
|---|---|---|
| 摘要器 ENG062 | v0117(v0116 留著)| 四點開頭的頁首列(`公司 \\| Asia Pacific`)、報告標題列、小標題(`Dual growth engines moving into focus`)去掉;每點仍是來源精確字串(字元區間 · 雜湊重算);折行的第一個字、介系詞開頭的句子不動 · 容器 9 份真檔只改 2 點、其餘逐字相同 |
| Workbench U/I | VRN2_Workbench v0100 + 字型資產包 | 範本版面 CSS / 標記逐字鎖定;{{ 欄位 }} 由本輪收據(完成判定 · 收尾 · 啟動檢查 · 範圍 · 輸入稽核 · 驗收 · 冪等 · 四點原文 · 環境)與輸出冊(BasicInfo / FinancialData / Summary / Rejected)展開;按鈕接 vrn2://(選檔案夾 / 選檔案 / 重新稽核 / 完整重跑 / 不上船 / 清快取 / 還原);其他系統 Gate 只開已登記入口;資料冊分頁 / 整冊 CSV / 日期關鍵字擷取 / 本頁匯出都在瀏覽器端;`VRN2_Logo.png` 自動去白底、無框無特效(沒放 → 範本「理」字)|
| 啟動器 | v0142(v0141 底座)| 收尾收據寫完 → 渲染 `VIA_Reports\\vrn2\\VRN2_Workbench_latest.html` → 舊版 U/I 頁首加一條「開啟 Workbench」→ 開 Workbench(開不了才退回舊版 U/I)· 收據多 `workbench` 欄 |

套件 `VRN2_Closeout_v0142.zip`(SHA-256 `%s` · 從 `vrn2_release_v0142` 取 · 解壓到 `%%USERPROFILE%%\\Downloads\\VRN2_Closeout_v0142`)。
沒有 .ps1:下面那一行(cmd 也能貼)從 GitHub 讀本檔的一鍵程式碼、核對 SHA-256 才執行;一鍵再核對套件雜湊與套件內逐檔雜湊才解壓。
logo:把印章圖存成 `<VIA>\\functional modules\\VRN\\SSOT\\VRN2_Logo.png`(或 jpg)即可,渲染時自動去背;沒放就是範本的「理」字方塊。

| 步驟 | v0142 做什麼 |
|---|---|
| ① ② | CPU / DRAM · PS 加速器(同 v0136)|
| ③ | 本機套件夾的 zip 雜湊對 → 直接用;不是 → GitHub 分支(讀不到 → main)`vrn2_release_v0142` → 套件雜湊 + `PACKAGE_SHA256.json` 逐檔核對 → 解壓(舊套件夾改名備份)|
| ③b | 定位 VRN-2 程式夾 → `VRN2_ROOT` / `VIA_ROOT` 都指過去 |
| ④ | `python ActivateVRN-2_v0142.py [--source …]`:①~⑫(⑨ ⑩ ⑫ 灰)· ⑧ 冪等閘 STALE_RECORD → 自動第 2 輪 · 四點原文核對 → 收據 → **Workbench 渲染 + 開啟** |
| ⑤ | 摘要:⑧ 完成判定 · ⑧b 收尾收據 · **Workbench 一行** · 冪等閘分類 · 輸出冊 · U/I 寫回 · 獨立驗證摘要 |
| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\VRN2\\VRN2_UIAction_v0104.py`(設定檔 v0142)· U/I 沒開就代開 |

開關:`$env:VRN2_SOURCE = 'C:\\測試樣本報告'` 指定來源夾 · `$env:VRN2_PACKAGE` 換套件夾 · `$env:VRN2_LAUNCHER_ARGS = '--no-install'` · `$env:VRN2_NO_REPASS = 1` 不自動再跑 · `$env:VRN2_NO_UI = 1` 不開 U/I。
VRN-2 主體(管理器鏈 · ENG397 v0127 · 摘要器 v0114 ~ v0116 · 驗證器 · 工具橋 · OCR 橋)與 v0141 的 159 個 runtime 成員**一個位元組都不動**;VRN-1 / VDF / VCGC 不碰。

## 在「命令提示字元(cmd)」或 PowerShell 都能貼的一行(建議用這個)

這一行在 cmd 或 PowerShell 貼上都可以:它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)讀本檔的一鍵程式碼 → **核對 SHA-256** → 才執行(不存檔 · 不改執行原則 · 結束碼 GREEN 0 / YELLOW 2 / RED 1)。

```bat
@ONE@
```

或:在 cmd 先輸入 `powershell` 按 Enter,再貼下面整段程式碼。

程式碼 SHA-256(本文 · 一行核對的就是這個):`%s`

```powershell
@PS@
```

## 一行實際做的事(boot · 給看的 · 上面那行就是它的 base64)

```text
@BOOT@
```
""" % (want, cs[:12])
newmd = head.replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", newmd).group(1).split()[-1]).decode("utf-16-le") == boot
assert "vrn2_release_v0142" in boot and "VRN2_OneClick_v0142.md" in boot and "v0141" not in boot and "$RelP   = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0142'" in ps
(out / "VRN2_OneClick_v0142.md").write_text(newmd, encoding="utf-8", newline="\n"); (out / "boot142.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline142.txt").write_text(one + "\n", encoding="utf-8"); (out / "Run-VRN2-v0142.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("package %s · code %s · one-liner %d 字 · 換版號 %d 處" % (want[:12], cs[:12], len(one), n))
