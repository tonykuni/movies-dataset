"""套件 v0142:runtime zip v0142(= v0140 的 155 個成員 + 4 個新版檔 · 固定時間戳 · 冪等)+ 清單 json + 套件夾(無 .ps1)。
用法:python make_pkg141.py <rt141 夾> <v0104 套件夾> <new 夾> <輸出套件夾>"""
import hashlib, json, shutil, sys, zipfile
from pathlib import Path
rt, old, new, out = (Path(x) for x in sys.argv[1:5])
out.mkdir(parents=True, exist_ok=True)
old_manifest = json.loads((old / "VRN2_Runtime_v0141.json").read_text(encoding="utf-8"))
old_names = [e["path"] for e in old_manifest["files"]]
new_names = ["VRN_ENG062_SummarizerV1_v0117.py", "VRN2_Workbench_v0100.py", "VRN2_Workbench_Assets_v0100.zip"]
with zipfile.ZipFile(old / "VRN2_Runtime_v0141.zip") as z:
    old_bytes = {n: z.read(n) for n in old_names}
for e in old_manifest["files"]:
    assert hashlib.sha256(old_bytes[e["path"]]).hexdigest() == e["sha256"], e["path"]
members = dict(old_bytes)
for n in new_names:
    members[n] = (new / n).read_bytes()
names = sorted(members)
zp = out / "VRN2_Runtime_v0142.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 10, 28, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
        z.writestr(zi, members[n])
manifest = {"system": "VRN-2", "version": "v0142", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(),
            "based_on": "VRN2_Runtime_v0141.zip " + old_manifest["zip_sha256"], "retained_members": len(old_names), "new_members": new_names,
            "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0142.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(old / n, out / n)
shutil.copy2(new / "ActivateVRN-2_v0142.py", out / "ActivateVRN-2_v0142.py")
shutil.copy2(old / "VRN2_VerbatimVerifier_v0104.py", out / "VRN2_VerbatimVerifier_v0104.py")
print("runtime v0142: %d members (+%d) · zip %s · launcher %s" % (len(names), len(new_names), manifest["zip_sha256"][:12], hashlib.sha256((out / "ActivateVRN-2_v0142.py").read_bytes()).hexdigest()[:12]))
