"""收尾 v0142:phase pkgdocs → results.json(套件 README / VALIDATION 內容 + 實測數字)· phase verify → VRN2_Verification_v0142.md。用法:python finalize142.py pkgdocs|verify"""
import json, re, sys, glob
from pathlib import Path
from collections import Counter
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v142")
L = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/local1028")
phase = sys.argv[1]
def j(p, d=None):
    try: return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception: return d
def grep(path, pat, last=True):
    try: hits = [l for l in Path(path).read_text(encoding="utf-8", errors="replace").splitlines() if re.search(pat, l)]
    except OSError: return ""
    return (hits[-1] if last else hits[0]) if hits else ""
def passes(path):
    t = Path(path).read_text(encoding="utf-8", errors="replace") if Path(path).exists() else ""
    return len(re.findall(r"\[(?:PASS|OK)\]", t)), len(re.findall(r"\[FAIL\]", t))
o = W / "t142/VIA/VIA_Reports/vrn2"
cl = j(o / "VRN2_Closeout_v0142.json", {}); idem = j(o / "IDEMPOTENCE_latest.json", {}); comp = j(o / "VRN2_Completion_latest.json", {})
summ = j(o / "output/VRN2_Summary_latest.json", []); src = j(o / "output/VRN2_SummarySource_latest.json", {"documents": []}); fin = j(o / "output/VRN2_FinancialData_latest.json", [])
vi = sorted(glob.glob(str(o / "verify_independent/VRN2_IndependentVerify_*.json"))); v = j(vi[-1], {}) if vi else {}
line11 = grep(W / "full142.log", r"⑪ 獨立驗證\(背景 · 只讀\) ·")
m11 = re.search(r"基本資料 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 一標題四重點 (\d+) 份 · 欄位檢查 (\{[^}]*\}) · 年度數據 (\d+) 筆 · (\{[^}]*\})", line11)
line7 = grep(W / "full142.log", r"⑦ 啟動 VRN-2 · \[計\] VRN-2 個股四項"); m7 = re.search(r"個股四項 · (\d+) 份\(全綠 (\d+)\)", line7)
wb = cl.get("workbench") or {}
# ENG062 v0117 vs v0116 on the 9 real files
a = j(L / "v0116_real.json", {}); b = j(L / "v0117_real.json", {}); changed = []
for fn in a:
    if "error" in a[fn] or "error" in b.get(fn, {}): continue
    for i, (x, y) in enumerate(zip([p["text"] for p in a[fn]["points"]], [p["text"] for p in b[fn]["points"]])):
        if x != y: changed.append({"file": fn, "point": i + 1, "before": (x or "")[:80], "after": (y or "")[:80]})
up = {}
try:
    import csv
    rows = list(csv.DictReader(open(L / "Summary.csv", encoding="utf-8-sig")))
    noend = sum(1 for r in rows for k in ("POINT_2", "POINT_3", "POINT_4") if (r[k] or "").strip() and (r[k].split("；")[0].strip()[-1:] not in "。.!?」）)”\"%]"))
    up = {"files": len(rows), "points_no_sentence_end": noend, "source": "operator upload 2026-10-28 (v0136 line · ENG062 v0114)"}
except Exception: pass
wb_self = passes(W / "wb_selftest.log"); wb_ui = passes(W / "wb_ui.log"); wb_ui_run = passes(W / "wb_ui_run.log"); ui_old = passes(W / "ui_old.log")
scen_rc = (W / "scen.rc").read_text(encoding="utf-8").strip().replace("\n", " · ") if (W / "scen.rc").exists() else "not run"
non_green = [(s.get("step"), s.get("lamp")) for s in cl.get("steps", []) if s.get("lamp") != "GREEN"]
sel = Counter(str(p.get("selection") or ((p.get("evidence") or [{}])[0].get("selection") if isinstance(p.get("evidence"), list) and p.get("evidence") else None) or "strict/v0115") for d in src.get("documents", []) for p in d.get("points", []))
R = {
 "order": ["回到電腦本地實測修正(貼回 v0136 線 52 份輸出:四點截斷 / 頁首混入 · 剔除 654 · 缺項 10)", "模板視覺鎖定作為前端 html u/i 與後端連棟整合為一個系統 · 透明去背 logo 無框無特效取代模板 logo(上傳 VIA_VRN-2_Workbench_-_Standalone.html)"],
 "base_package": {"name": "VRN2_Closeout_v0141 (launcher v0141 · runtime v0141 159 members · manager v0243 · ENG062 v0116 · verifier v0110 · verbatim v0104)", "retained": "all 159 runtime members byte-identical; ActivateVRN-2_v0136.py base unchanged"},
 "supersedes": "v0141 for the closeout entry; VRN-2 one-click v0141 for the operator paste; operator one-click v0102 → v0103",
 "design": {
   "ENG062_v0117": "after v0116 selection, the left edge of a chosen span is moved past leading page-banner lines (Company | Asia Pacific), lines that are (part of) the report title (also when glued to the first sentence), and short section headings followed by a new sentence; wrapped first words and preposition-led lines are kept; remaining span must still be eligible; raw_span/quote/quote_sha256 rewritten; validate_summary re-checked",
   "Workbench_v0100": "template CSS/markup locked verbatim; {{ fields }} / sc-for / sc-if expanded server-side from receipts + output books; vrn2:// actions; gates only for registered entries; dataset paging / CSV / extract / page export in vanilla JS; logo auto-transparent (white → alpha, un-premultiplied edges, cropped) as data URI with no background / radius / shadow; fonts from VRN2_Workbench_Assets_v0100.zip (117 woff2) referenced relatively; falls back to system fonts and the template glyph",
   "ActivateVRN-2_v0142": "v0141 + runtime v0142; after the closeout receipt: render Workbench, add a link bar to the legacy U/I page, open the Workbench (fallback legacy); receipt gains 'workbench'"},
 "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · Chromium (Playwright) · 19 real sample files (shipF) + 9 real files of the operator's 52 (others synthetic only)",
 "results": {
   "selftests": {"ENG062_v0117": "PASS (banner / title / glued title / heading trimmed · wrapped word · preposition · CJK heading · exact spans · tamper rejected)", "Workbench_v0100": "%d/%d" % (wb_self[0], wb_self[0] + wb_self[1]), "manager_v0243_with_v0117": "PASS", "launcher_v0142": "PASS (+ workbench link / render fallback / open fallback)"},
   "eng062_real9_diff": {"files": len([k for k in a if "error" not in a[k]]), "points_changed": changed, "note": "all other points byte-identical to v0116"},
   "operator_upload_v0114": up,
   "full_run_v0142_19_real": {"closeout_rc": cl.get("rc"), "rc_reason": "③ 環境檢查 RED in the Linux sandbox only (accelerator deps not in venv; --no-install); every VRN-2 gate GREEN unless listed", "non_green_steps": non_green,
     "passes": [(p.get("attempt"), p.get("rc"), p.get("idempotence")) for p in cl.get("passes", [])], "completion": {"verdict": comp.get("verdict"), "red": comp.get("red"), "yellow": comp.get("yellow"), "manager": comp.get("manager")},
     "stock_reports": {"n": int(m7.group(1)) if m7 else None, "all_green": int(m7.group(2)) if m7 else None}, "idempotence": idem.get("classification"),
     "source_quotes": (cl.get("source_quotes") or {}).get("counts"), "output_gaps": cl.get("output_gaps"), "summary_rows": len(summ), "points_4_of_4": all((r.get("POINTS_OK") or 0) == 4 for r in summ) if summ else None, "selection_levels": dict(sel),
     "independent_verifier": {"version": v.get("version"), "fin_bad": len(v.get("fin_bad") or []), "basic": m11.group(2) if m11 else "", "summary": m11.group(4) if m11 else "", "financial_rows": int(m11.group(5)) if m11 else len(fin), "financial_verdicts": m11.group(6) if m11 else ""},
     "workbench": {"lamp": wb.get("lamp"), "path": (wb.get("path") or "")[-60:], "legacy_linked": wb.get("legacy_linked")}},
   "workbench_real_browser": {"on_t141f_receipts": "%d/%d" % (wb_ui[0], wb_ui[0] + wb_ui[1]), "on_full_run_v0142": "%d/%d" % (wb_ui_run[0], wb_ui_run[0] + wb_ui_run[1])},
   "legacy_ui_real_browser": "%d/%d" % (ui_old[0], ui_old[0] + ui_old[1]),
   "oneclick_scenario_pwsh": scen_rc},
 "not_claimed": ["Windows run on C:\\測試樣本報告 (52): only 9 of those PDFs are real in the container; the other 43 are synthetic stand-ins — the v0117 trim is proven on the 9 real + the sandbox 19, not on all 52",
                 "The seal logo image was shown in chat but not uploaded as a file: the Workbench ships with the logo slot + auto-transparency and renders the template glyph until VRN2_Logo.png/jpg is placed",
                 "Workbench 矩陣一 delete / restore (recycle) and the dedupe plan are read-only in v0100 (buttons explain); the vrn2:// handler v0104 still reopens the legacy U/I after pick/run (it now carries a Workbench link bar)",
                 "剔除冊 654 / 一格多值 / 表頭在表外 (desktop line v0254 work) untouched; MQ-1560 four points stay OCR_PENDING by design"]}
if phase == "pkgdocs":
    R["readme"] = ("VRN2_Closeout_v0142 — VRN-2 closeout package (2026-10-28)\n\n"
      "Entry: python ActivateVRN-2_v0142.py [--source <folder>] [--no-install] [--no-open]\n"
      "Runtime: VRN2_Runtime_v0142.zip (159 members of runtime v0141 byte-identical + VRN_ENG062_SummarizerV1_v0117.py + VRN2_Workbench_v0100.py + VRN2_Workbench_Assets_v0100.zip)\n"
      "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
      "New in v0142: summarizer v0117 (excerpts no longer start with a page banner / title / section heading);\n"
      "Workbench U/I v0100 (operator template locked as the front end, bound to this run's receipts and output books, vrn2:// actions wired,\n"
      "VRN2_Logo.png auto-transparent) rendered to VIA_Reports/vrn2/VRN2_Workbench_latest.html after the closeout receipt and opened.\n"
      "Logo: place the seal image as <VIA>/functional modules/VRN/SSOT/VRN2_Logo.png (or .jpg); it is made transparent on render.\n"
      "Exit codes: 0 GREEN · 2 YELLOW (review items / OCR pending / non-Windows ③) · 1 RED.\n")
    R["validation"] = {k: R["results"][k] for k in ("selftests", "eng062_real9_diff", "full_run_v0142_19_real", "workbench_real_browser", "oneclick_scenario_pwsh")} | {"not_claimed": R["not_claimed"]}
    (W / "results142.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8"); print("results142.json ok · rc", cl.get("rc"), "· wb", wb.get("lamp")); sys.exit(0)
R = j(W / "results142.json", R); rr = R["results"]["full_run_v0142_19_real"]
md = ["# VRN-2 v0142 容器實測紀錄(2026-10-28)", "",
      "操作員令:" + " / ".join(R["order"]), "",
      "## 1. 本輪改了什麼", "",
      "| 元件 | 版本 | 內容 |", "|---|---|---|",
      "| 摘要器 ENG062 | v0117 | " + R["design"]["ENG062_v0117"] + " |",
      "| Workbench U/I | VRN2_Workbench v0100 + Assets v0100 | " + R["design"]["Workbench_v0100"] + " |",
      "| 啟動器 | ActivateVRN-2 v0142 | " + R["design"]["ActivateVRN-2_v0142"] + " |", "",
      "## 2. 自測", "", "| 項 | 結果 |", "|---|---|"] + ["| %s | %s |" % (k, v) for k, v in R["results"]["selftests"].items()] + ["",
      "## 3. 摘要器 v0117 · 容器 9 份真檔(操作員 52 份裡在容器的真檔)", "",
      "| 檔 | 點 | v0116 | v0117 |", "|---|---|---|---|"] + ["| %s | P%d | %s | %s |" % (c["file"], c["point"], c["before"].replace("\n", "⏎").replace("|", "\\|"), c["after"].replace("\n", "⏎").replace("|", "\\|")) for c in R["results"]["eng062_real9_diff"]["points_changed"]] + [
      "", "其餘 %d 份的點逐字相同。操作員貼回的 v0114 輸出:%s 份 · 三點裡沒有句尾的 %s 個(截斷 / 頁首 / 標題重複 · v0115 起的逐字切句已無此類;v0117 再去掉開頭的頁首 / 標題 / 小標題列)。" % (R["results"]["eng062_real9_diff"]["files"], R["results"]["operator_upload_v0114"].get("files"), R["results"]["operator_upload_v0114"].get("points_no_sentence_end")),
      "", "## 4. 沙盒全流程(套件 v0142 · 19 份真檔)", "",
      "| 項 | 結果 |", "|---|---|",
      "| 收尾 rc | %s(%s)|" % (rr["closeout_rc"], rr["rc_reason"]),
      "| 非綠步驟 | %s |" % rr["non_green_steps"], "| 輪數 / 冪等 | %s · %s |" % (rr["passes"], rr["idempotence"]),
      "| ⑧ 完成判定 | %s · 紅 %s 黃 %s · %s |" % (rr["completion"]["verdict"], rr["completion"]["red"], rr["completion"]["yellow"], rr["completion"]["manager"]),
      "| ⑦ 個股四項 | %s 份 · 全綠 %s |" % (rr["stock_reports"]["n"], rr["stock_reports"]["all_green"]),
      "| 四點原文核對 | %s · 缺項 %s |" % (rr["source_quotes"], rr["output_gaps"]),
      "| 摘要 | %s 份 · 四點齊 %s · 層級 %s |" % (rr["summary_rows"], rr["points_4_of_4"], rr["selection_levels"]),
      "| ⑪ 獨立驗證 | %s · 錯值 %s · 基本資料 %s · 四點 %s · 年度 %s 筆 %s |" % (rr["independent_verifier"]["version"], rr["independent_verifier"]["fin_bad"], rr["independent_verifier"]["basic"], rr["independent_verifier"]["summary"], rr["independent_verifier"]["financial_rows"], rr["independent_verifier"]["financial_verdicts"]),
      "| Workbench | %s · …%s · 舊版 U/I 連結 %s |" % (rr["workbench"]["lamp"], rr["workbench"]["path"], rr["workbench"]["legacy_linked"]), "",
      "## 5. 真瀏覽器(Chromium · Playwright)", "",
      "| 頁 | 結果 |", "|---|---|",
      "| Workbench(t141f 收據)| %s |" % R["results"]["workbench_real_browser"]["on_t141f_receipts"],
      "| Workbench(本輪全跑收據)| %s |" % R["results"]["workbench_real_browser"]["on_full_run_v0142"],
      "| 舊版 U/I(含 Workbench 連結列)| %s |" % R["results"]["legacy_ui_real_browser"],
      "| 一鍵情境(pwsh · 第一次從假 GitHub 分支下載套件 → 再貼(本機已驗證)→ 竄改啟動器(偵測 · 從已驗證 zip 重解))| %s(rc 1 = 沙盒 ③ 環境檢查 RED,與 §4 同;③ 取件 / 雜湊 / 逐檔核對 / 竄改偵測 / Workbench 皆綠)|" % R["results"]["oneclick_scenario_pwsh"], "",
      "## 6. 沒有宣稱的", ""] + ["- " + x for x in R["not_claimed"]]
(W / "release142" / "VRN2_Verification_v0142.md").write_text("\n".join(md) + "\n", encoding="utf-8"); print("verification md ok")
