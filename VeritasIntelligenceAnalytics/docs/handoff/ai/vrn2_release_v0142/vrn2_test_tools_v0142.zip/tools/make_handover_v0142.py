"""VRN2_Handover_v0142.md = v0141 交接報告 + v0142(摘要器 v0117 · Workbench U/I v0100 · 啟動器 v0142 · 操作員一鍵 v0103)· 逐行錨點 · 冪等。
用法:python make_handover_v0142.py <v0141.md> <results142.json> <release json> <輸出 md>"""
import json, re, sys
from pathlib import Path
src, res_p, rel_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
R = json.loads(res_p.read_text(encoding="utf-8")); REL = json.loads(rel_p.read_text(encoding="utf-8")); rr = R["results"]["full_run_v0142_19_real"]
lines = src.read_text(encoding="utf-8").split("\n")
def one(prefix):
    hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    assert len(hits) == 1, (prefix[:50], len(hits)); return hits[0]
def sub(prefix, new):
    i = one(prefix); lines[i] = new(lines[i]) if callable(new) else new
def before(prefix, extra):
    i = one(prefix); lines[i:i] = extra
def after(prefix, extra):
    i = one(prefix); lines[i + 1:i + 1] = extra
chg = R["results"]["eng062_real9_diff"]["points_changed"]
sub("# VRN-2 交接報告 · ActivateVRN-2 v0141 · 2026-10-22(",
    "# VRN-2 交接報告 · ActivateVRN-2 v0142 · 2026-10-28(v0141 收尾套件 + 本輪:摘要器 ENG062 v0117 四點開頭不帶頁首 / 標題 / 小標題 · Workbench U/I v0100 範本視覺鎖定綁本輪收據與輸出冊 · 啟動器 v0142 收尾後自動產出並開啟 · 操作員一鍵 v0103;另:倉上薄尾鏈缺前版 → VRN2_ChainShip v0100(PR #570))")
before("> **本輪(v0141 · 套件 = v0140 入口 + runtime v0141",
       ["> **操作員令(2026-10-28)**:「回到電腦本地實測修正」+ 貼回 v0136 線的 52 份本地輸出(U/I 完成頁 · Summary / Rejected / FinancialData / Combined / BasicInfo 五本 CSV);「模板視覺鎖定作為前端 html u/i 與後端連棟整合為一個系統 · 透明去背 logo 無框無特效取代模板 logo」+ 上傳 `VIA_VRN-2_Workbench_-_Standalone.html`(印章圖只在對話裡出現,沒有檔案)。",
        "> **本輪(v0142 · 套件 = v0141 + runtime v0142 · 新增 ENG062 v0117 · VRN2_Workbench v0100 + 字型資產包 · 啟動器 v0142 · 一鍵 v0142 · 操作員一鍵 v0103 · v0141 的 159 個 runtime 成員與啟動器底座一個位元組都不動)**:① **貼回的四點品質**:52 份 × 三點裡 %s 個沒有句尾(240 字截斷 · 頁首 / 圖註 / 報告類型列當重點 · 標題重複 · 半句開頭),那是 v0114 的切句;v0115 起逐字切句已無截斷,容器 9 份真檔(52 份裡在容器的真檔)v0116 只剩「開頭帶頁首列 / 標題列 / 小標題」→ **ENG062 v0117**:選完後把左緣移過頁首列(`公司 | Asia Pacific`)、標題列(含黏在第一句前的標題)、短小標題(後面接新句);折行的第一個字、介系詞開頭不動;區間 / 引文 / 雜湊重算 · validate_summary 再驗;9 份真檔只改 %d 點(%s),其餘逐字相同。② **Workbench U/I**:範本是 Claude 設計物(x-dc 範本 + 合成資料);版面 CSS / 標記逐字鎖定,{{ 欄位 }} / sc-for / sc-if 在 Python 端用本輪收據與輸出冊展開(完成判定 · 收尾 · 啟動檢查 · 範圍 · 輸入稽核 · 驗收 · 冪等 · 四點原文 · 環境 · BasicInfo / FinancialData / Summary / Rejected · scope_in SHA-256 去重 · backup 快照 · 鎖定);按鈕接 vrn2://;Gate 只開已登記入口;分頁 / 匯出 / 擷取在瀏覽器端;logo 自動去背(白 → 透明 · 去白暈 · 裁框)、無底色 / 圓角 / 陰影;字型 117 個 woff2 隨資產包。③ **啟動器 v0142**:收尾收據寫完 → 渲染 → 舊版 U/I 頁首加「開啟 Workbench」列 → 開 Workbench(退回舊版)。④ 沙盒 19 份:⑦ %s/%s · ⑧ %s 紅 %s 黃 %s · 冪等 %s · 四點 %s · Workbench %s · 真瀏覽器 Workbench %s / 舊版 U/I %s · 一鍵情境 %s。⑤ **沒做的**:印章圖沒有檔案(放 `SSOT\\VRN2_Logo.png` 即自動去背);矩陣一刪除 / 回收區唯讀;vrn2:// 處理器 v0104 仍重開舊版 U/I(頁首有 Workbench 連結);剔除冊 / 一格多值是桌機線 v0254 的事。" % (
            R["results"]["operator_upload_v0114"].get("points_no_sentence_end"), len(chg), " · ".join("%s P%d" % (c["file"][:12], c["point"]) for c in chg), rr["stock_reports"]["all_green"], rr["stock_reports"]["n"], rr["completion"]["verdict"], rr["completion"]["red"], rr["completion"]["yellow"], rr["idempotence"], rr["source_quotes"], rr["workbench"]["lamp"], R["results"]["workbench_real_browser"]["on_full_run_v0142"], R["results"]["legacy_ui_real_browser"], R["results"]["oneclick_scenario_pwsh"])])
sub("> **本輪(v0141 · 套件 = v0140 入口 + runtime v0141", lambda l: l.replace("> **本輪(v0141", "> **前一輪(v0141", 1))
sub("| **收尾套件(MAIN)** |", "| **收尾套件(MAIN)** | `C:\\Users\\tonyk\\Downloads\\VRN2_Closeout_v0142\\`(一鍵 ③ 解壓;`ActivateVRN-2_v0142.py` + 底座 `ActivateVRN-2_v0136.py` + `VRN2_Runtime_v0142.zip/.json` + 橋 + 原文核對 v0104 + OCR 橋 v0101)| **v0142** · 套件雜湊 `%s` · 見 `docs/handoff/ai/vrn2_release_v0142/VRN2_Release_v0142.json` · v0141 / v0104 套件夾留著 |" % REL["package"]["sha256"][:12])
sub("| **私有 runtime** |", "| **私有 runtime** | `<ROOT>\\functional modules\\VRN2\\` | v0140 起:runtime 清單逐檔雜湊還原(已在且同 = 沿用 · 不同 = 停不覆寫)· v0142 多 3 檔:ENG062 v0117 · VRN2_Workbench_v0100.py · VRN2_Workbench_Assets_v0100.zip(v0141 的 4 檔照舊)· 共用 `functional modules\\VRN` 不碰 |")
sub("| **收尾收據** |", "| **收尾收據** | `<ROOT>\\VIA_Reports\\vrn2\\VRN2_Closeout_v0142.json` · `IDEMPOTENCE_latest.json` · `VRN2_VerbatimVerify_latest.json` | rc 0 / 2 / 1 · 每輪(passes)· 冪等分類 · 四點原文核對 · **`workbench`(燈 · 路徑 · 舊版連結)** |")
after("| **收尾收據** |", ["| **Workbench U/I** | `<ROOT>\\VIA_Reports\\vrn2\\VRN2_Workbench_latest.html` + `VRN2_Workbench_assets\\`(字型)| 啟動器 v0142 收尾後渲染並開啟;自己跑:`python \"functional modules\\VRN2\\VRN2_Workbench_v0100.py\" render --root <ROOT>`;logo:`<ROOT>\\functional modules\\VRN\\SSOT\\VRN2_Logo.png`(或 jpg · 自動去背;`logo <in> <out.png>` 可單獨去背)|"])
sub("| **U/I** |", "| **U/I(舊版)** | `<ROOT>\\VIA_Reports\\vrn2\\VRN2_UI_latest.html` | 管理器寫;v0142 起頁首多一條「開啟 VRN-2 Workbench」;vrn2:// 處理器 v0104 重開的是這一頁 · 每檔細節 / 驗證過的輸出仍在這裡 |")
sub("| **交接報告** |", "| **交接報告** | `<ROOT>\\docs\\handoff\\ai\\VRN2_Handover_v0142.md` | 本線(套件線)的交接;`VRN2_Handover_latest.md` 是桌機線(v0145)的,不蓋 |")
after("| **VRN_ENG062_SummarizerV1** | **v0116**", ["| **VRN_ENG062_SummarizerV1** | **v0117**(v0114 ~ v0116 留著)| 見 runtime 清單 | 見 runtime 清單 | **新**(開頭頁首 / 標題 / 小標題列去掉 · 區間雜湊重算)|",
                                                     "| **VRN2_Workbench** | **v0100** + Assets v0100(117 woff2 · 4.4 MB)| 見 runtime 清單 | 見 runtime 清單 | **新**(範本視覺鎖定 · 綁收據與輸出冊 · vrn2:// · logo 去背 · 自測 16 · 真瀏覽器 17)|",
                                                     "| **VRN2_ChainShip** | **v0100**(倉 `functional modules/VRN/`)| 26,530 | `cfee9e2d056d` | **新**(PR #570:釘名前版盤點 check · 在位未入倉補船 ship;桌機一鍵貼 `docs/handoff/ai/VRN2_ChainShip_v0100.md` §3)|"])
after("| **v0141** | → **v0243** | v0127 | **v0116** |", ["| **v0142** | 同 v0243 | v0127 | **v0117** | 摘要器開頭去頁首 / 標題 / 小標題 · Workbench U/I v0100 收尾後渲染並開啟 · 舊版 U/I 加連結列 · 收據多 workbench · 操作員一鍵 v0103 改指本版 |"])
out.write_text("\n".join(lines), encoding="utf-8", newline="\n")
print("handover v0142 ok · lines", len(lines))
