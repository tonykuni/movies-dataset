"""vrn2_release_v0131:ActivateVRN-2_v0131.zip(ActivateVRN-2.py · 固定時間戳)+ VRN2_Release_v0131.json(冪等)。
用法:python make_release131.py <ActivateVRN-2_v0131.py> <results.json> <輸出夾>"""
import ast
import base64
import hashlib
import json
import sys
import zipfile
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
out.mkdir(parents=True, exist_ok=True)
raw = src.read_bytes()
sha = hashlib.sha256(raw).hexdigest()
zp = out / "ActivateVRN-2_v0131.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    zi = zipfile.ZipInfo("ActivateVRN-2.py", date_time=(2026, 10, 20, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    z.writestr(zi, raw)
tree = ast.parse(raw.decode("utf-8"))
consts, extras = {}, []
for n in tree.body:
    if isinstance(n, ast.Assign):
        try:
            v = ast.literal_eval(n.value)
        except Exception:  # noqa: BLE001
            continue
        for tg in n.targets:
            if isinstance(tg, ast.Name):
                consts[tg.id] = v
            elif isinstance(tg, ast.Tuple):
                for e, vv in zip(tg.elts, v):
                    consts[e.id] = vv
    elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and getattr(n.value.func, "attr", "") == "append":
        extras.append(ast.literal_eval(n.value.args[0]))


def comp(name, h, b64):
    b = base64.b64decode("".join(b64.split()))
    assert hashlib.sha256(b).hexdigest() == h, name
    return {"file": name, "bytes": len(b), "sha256": h}


order = [comp(*c) for c in consts["MGR_CHAIN"]] + [comp(consts["MGR_NAME"], consts["MGR_SHA"], consts["MGR_B64"])]
order += [comp(*c) for c in consts["ENGINES"]] + [comp(*c) for c in list(consts["EXTRAS"]) + extras]
order += [comp(consts["OCR_BRIDGE_NAME"], consts["OCR_BRIDGE_SHA"], consts["OCR_BRIDGE_B64"]), comp(consts["HANDOVER_NAME"], consts["HANDOVER_SHA"], consts["HANDOVER_B64"])]
R = json.loads(res_p.read_text(encoding="utf-8"))
man = {
    "system": "VRN-2",
    "independent": True,
    "release": "ActivateVRN-2 v0131",
    "date": "2026-10-20",
    "operator_order_2026_10_20": "VRN-1 VRN-2工具可相互取用  可驗證性高精準度還原後表格可改為資料庫形式PIVOT  兩個系統元主體邏輯不變但各式可以找缺少的工具  獨立系統兩個MAIN",
    "supersedes": "ActivateVRN-2 v0129(docs/handoff/ai/vrn2_release_v0129)· 一鍵 v0130(判定三處 · 照舊)",
    "design": {
        "two_mains": {"VRN-1": "functional modules/VRN/VRN_Main_v0100.py(VIA-VDF-VRN 倉 · 另一團隊)", "VRN-2": "ActivateVRN-2.py → VRN-2 SystemManager"},
        "manifest_schema": "VIA_ToolManifest/1(每支工具:檔 · sha256 · 入口 · 契約 · 能不能用)",
        "vrn2_offers": ["section.near(段落標題:VRN-2 管理器第三讀法 + v0239 _sec_near)", "ocr.image(VRN-2 OCR 隔離環境 · rapidocr)"],
        "vrn2_borrows": ["table.pivot_db(VRN-1 VRN_PivotDB · 契約 VIA_PivotFacts/1)"],
        "rules": "借之前逐檔核對對方工具冊 sha256 · 只讀對方的檔(不改 · 不複製 · 載入不寫 __pycache__)· 只寫自己的輸出夾 · 借不到 = 只用自己的(灰 / 黃)· VRN-2 主體一個位元組都不動",
    },
    "embedded_components_landing_order": order,
    "tested_in": {
        "where": "Claude Code 雲端容器 · Linux · Python 3.13 · 測試用隔離 venv(repo 與系統 Python 未動)· OCR 隔離環境另建 Python 3.11 venv(rapidocr_onnxruntime · numpy<2)只在暫存區",
        "inputs": "repo 內真實 PDF 19 份 · 個股範圍 14 份",
        "chain_stub": "使用者機器的管理器前版鏈 v0154–v0230 不在 repo → 測試替身(只供 p1loop / _rep / input_dir 等)· 不可提交",
        "vrn1": "VIA-VDF-VRN 倉 claude/optimistic-goodall-yhalc5(本機 · 含 VRN_PivotDB_v0100 / VRN_ToolBridge_v0100 · 工具冊 ssot/VRN_ToolManifest_v0100.json)",
    },
    "results": R,
    "launcher": {"file": "ActivateVRN-2_v0131.py", "bytes": len(raw), "sha256": sha},
    "launcher_zip": {"file": zp.name, "sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "member": "ActivateVRN-2.py"},
    "oneclick": "VRN2_OneClick_v0131.md",
    "test_tools_zip": "vrn2_test_tools_v0131.zip",
    "logs_zip": "logs_v0131.zip",
}
(out / "VRN2_Release_v0131.json").write_text(json.dumps(man, ensure_ascii=False, indent=1) + "\n", encoding="utf-8", newline="\n")
print("[計] launcher %s · zip %s · 元件 %d" % (sha[:12], man["launcher_zip"]["sha256"][:12], len(order)))
