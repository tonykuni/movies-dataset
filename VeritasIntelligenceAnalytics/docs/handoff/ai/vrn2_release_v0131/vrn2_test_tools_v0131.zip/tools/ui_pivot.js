// PIVOT 資料庫 HTML U/I 真瀏覽器實測（Chromium · Playwright）
// 用法：node ui_pivot.js <VRN_Pivot_v0100.html> <VRN_Pivot_v0100.json> <系統名 VRN-1|VRN-2> <截圖夾>
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
(async () => {
  const file = path.resolve(process.argv[2]);
  const summary = JSON.parse(fs.readFileSync(path.resolve(process.argv[3]), 'utf8'));
  const who = process.argv[4];
  const shots = path.resolve(process.argv[5]);
  fs.mkdirSync(shots, { recursive: true });
  const res = [];
  const ok = (name, cond, extra) => res.push({ name, ok: !!cond, extra: extra === undefined ? '' : String(extra).slice(0, 200) });
  const exe = fs.readdirSync('/opt/pw-browsers').filter(d => d.startsWith('chromium-')).map(d => `/opt/pw-browsers/${d}/chrome-linux/chrome`).find(p => fs.existsSync(p));
  const browser = await chromium.launch({ executablePath: exe });
  const errors = [];
  const page = await (await browser.newContext({ viewport: { width: 1400, height: 900 } })).newPage();
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('file://' + file);
  await page.waitForLoadState('load');
  ok(`標題寫系統名「${who} PIVOT 資料庫」（不寫籠統的 VRN）`, (await page.textContent('h1')).trim() === `${who} PIVOT 資料庫` && (await page.title()) === `${who} PIVOT 資料庫`, await page.textContent('h1'));
  const data = await page.evaluate(() => JSON.parse(document.getElementById('data').textContent));
  const keys = Object.keys(data);
  const tabs = await page.$$eval('#tabs button', bs => bs.map(b => b.textContent));
  ok('分頁數 = 資料表數（8）', tabs.length === keys.length && keys.length === 8, tabs.join(' | '));
  const c = summary.counts;
  for (const k of keys) {
    const want = k === 'facts' ? c.facts : c[k];
    ok(`${k} 列數 = JSON 計數 (${want})`, data[k].rows.length === want, data[k].rows.length);
  }
  for (let i = 0; i < keys.length; i++) {
    await page.click(`#tabs button:nth-child(${i + 1})`);
    const sel = await page.$eval(`#tabs button:nth-child(${i + 1})`, b => b.getAttribute('aria-selected'));
    const shown = await page.$$eval('#tb tr', trs => trs.length);
    const n = data[keys[i]].rows.length;
    ok(`分頁「${data[keys[i]].name}」：選中 · 每頁最多 50 筆 · 頁碼文字`, sel === 'true' && shown === Math.min(50, n) && (await page.textContent('#pg')).includes(`${n} 筆`), `${shown}/${n}`);
  }
  await page.click('#tabs button:nth-child(1)');
  const t0 = data[keys[0]];
  const heads = await page.$$eval('#th th', ths => ths.map(t => t.textContent));
  const yearCols = heads.filter(h => /^\d{4}$/.test(h));
  ok('年度 PIVOT 的欄 = 年（由小到大）', yearCols.length >= 2 && yearCols.join() === [...yearCols].sort().join(), yearCols.join(' '));
  if (t0.rows.length > 50) {
    await page.click('#next');
    ok('下一頁 → 第 2 頁 · 第一列 = 資料第 51 列', (await page.textContent('#pg')).startsWith('第 2 /') && (await page.$eval('#tb tr td', td => td.textContent)) === String(t0.rows[50][0]));
    await page.click('#prev');
  }
  const files = await page.$$eval('#ff option', os => os.map(o => o.value).filter(Boolean));
  ok('檔案篩選是原檔名（不是雜湊 · 全形字照原字）', files.length >= 2 && files.every(f => /\.pdf$/i.test(f)), files.slice(0, 3).join(' | '));
  if (files.length) {
    await page.selectOption('#ff', files[1]);
    const fi = t0.cols.indexOf('file');
    const expect = t0.rows.filter(r => r[fi] === files[1]).length;
    ok('選一個檔 → 只剩那個檔的列', (await page.textContent('#pg')).includes(`${expect} 筆`) && expect > 0, `${files[1]} · ${expect}`);
    await page.selectOption('#ff', '');
  }
  await page.fill('#fq', 'EPS');
  const eps = t0.rows.filter(r => r.join(' ').toLowerCase().includes('eps')).length;
  ok('搜尋 EPS → 只剩含 EPS 的列', (await page.textContent('#pg')).includes(`${eps} 筆`) && eps > 0, eps);
  await page.fill('#fq', '<script>');
  ok('搜尋含 <script> 不出錯、0 筆', (await page.textContent('#pg')).includes('0 筆'));
  await page.fill('#fq', '');
  const html = await page.content();
  ok('資料嵌入安全（只有兩個 <script>）', (html.match(/<script/g) || []).length === 2);
  const num = await page.$$eval('#tb td.n', tds => tds.length);
  ok('數字欄靠右（td.n）', num > 0, num);
  await page.screenshot({ path: path.join(shots, `pivot_${who}_desktop.png`), fullPage: false });
  const phone = await (await browser.newContext({ viewport: { width: 390, height: 844 }, colorScheme: 'dark' })).newPage();
  phone.on('pageerror', e => errors.push(e.message));
  await phone.goto('file://' + file);
  const overflow = await phone.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  ok('手機寬 390：頁面不會左右捲（表格自己捲）', overflow <= 1, overflow);
  const bg = await phone.evaluate(() => getComputedStyle(document.body).backgroundColor);
  ok('深色模式背景', bg === 'rgb(18, 19, 20)', bg);
  await phone.screenshot({ path: path.join(shots, `pivot_${who}_phone_dark.png`), fullPage: false });
  ok('沒有 JS 錯誤', errors.length === 0, errors.join(' | '));
  await browser.close();
  for (const r of res) console.log(`  [${r.ok ? 'PASS' : 'FAIL'}] ${r.name}${r.extra !== '' ? ' · ' + r.extra : ''}`);
  const pass = res.filter(r => r.ok).length;
  console.log(`[UI] ${who} PIVOT ${pass}/${res.length} ${pass === res.length ? 'PASS' : 'FAIL'}`);
  process.exit(pass === res.length ? 0 : 1);
})();
