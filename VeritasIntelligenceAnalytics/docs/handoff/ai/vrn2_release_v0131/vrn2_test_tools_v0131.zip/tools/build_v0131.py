"""ActivateVRN-2 v0129 → v0131 組裝(錨點替換 · 每個錨點只准出現一次 · 不改 v0129 原檔)。

用法:python build_v0131.py <v0129 啟動器> <new 夾> <輸出 v0131 啟動器>
  new 夾:VRN2_ToolBridge_v0100.py · VRN2_Handover_v0131.md
v0131 = 工具相互取用(操作員 2026-10-20「VRN-1 VRN-2 工具可相互取用 · 還原後表格可改為資料庫形式 PIVOT · 兩個系統元主體邏輯不變但各式可以找缺少的工具 · 獨立系統兩個 MAIN」):
  ② 落地 VRN2_ToolBridge_v0100 → 寫借出工具冊(VIA_Reports\\vrn2\\tools)· ⑫ 借 VRN-1 的 PIVOT 工具 → VIA_Reports\\vrn2\\pivot + U/I 連結。
  管理器鏈 / ENG397 / 摘要器 / 驗證器 / 處理器一個位元組都不動。
"""
import base64
import hashlib
import sys
from pathlib import Path

src_p, new_d, out_p = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src_p.read_text(encoding="utf-8")


def b64(raw: bytes) -> str:
    t = base64.b64encode(raw).decode("ascii")
    return "\n".join(t[i:i + 120] for i in range(0, len(t), 120))


def rep(a: str, b: str) -> None:
    global s
    assert s.count(a) == 1, (s.count(a), a[:90])
    s = s.replace(a, b)


bridge = (new_d / "VRN2_ToolBridge_v0100.py").read_bytes()
hand = (new_d / "VRN2_Handover_v0131.md").read_bytes()
bsha, hsha = hashlib.sha256(bridge).hexdigest(), hashlib.sha256(hand).hexdigest()

# ---- 檔頭說明 · 版本 ----
rep('r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0129 邊測邊修:', 'r"""ActivateVRN-2.py — VRN-2 一鍵啟動(v0131 工具相互取用:VRN-1 / VRN-2 兩個獨立系統、兩個 MAIN,各自的工具冊(檔 · sha256 · 入口 · 契約)'
    '→ ② 寫 VRN-2 的借出工具冊(VIA_Reports\\vrn2\\tools · 段落標題 section.near · OCR ocr.image)· ⑫ 借 VRN-1 的 PIVOT 資料庫工具(table.pivot_db · '
    '逐檔核對 VRN-1 工具冊的 sha256 · 只讀 VRN-1 的檔)→ VIA_Reports\\vrn2\\pivot(事實表 + 年度 PIVOT · SQLite / DuckDB / CSV / Parquet / HTML · 只收 ⑪ 判對位的格 · '
    '同格不同值留空列衝突)+ U/I 連結 · VRN-2 主體(管理器鏈 · ENG397 · 驗證器)一個位元組都不動 · 不照抄 VRN-1 的程式碼)\n'
    'v0129 邊測邊修:')
rep('VERSION = "ActivateVRN-2 v0129"', 'VERSION = "ActivateVRN-2 v0131"')

# ---- 內嵌工具橋 ----
rep('UI_HANDLER_NAME = "VRN2_UIAction_v0102.py"\n',
    'UI_HANDLER_NAME = "VRN2_UIAction_v0102.py"\n'
    'EXTRAS.append(("VRN2_ToolBridge_v0100.py", "%s", """\n%s\n"""))   # v0131 工具橋(借出 section.near / ocr.image · 借入 VRN-1 table.pivot_db · sha256 核對 · 帶加速器橋)\n'
    'TOOLBRIDGE_NAME = "VRN2_ToolBridge_v0100.py"\n' % (bsha, b64(bridge)))

# ---- 交接報告 v0131 ----
i = s.index('HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0129.md"')
j = s.index('"""', s.index('HANDOVER_B64 = """') + len('HANDOVER_B64 = """')) + 3
s = s[:i] + 'HANDOVER_NAME, HANDOVER_SHA = "VRN2_Handover_v0131.md", "%s"\nHANDOVER_B64 = """\n%s\n"""' % (hsha, b64(hand)) + s[j:]

# ---- 新函式(main 之前)----
helpers = r'''
def _tools_manifest(vrn, root) -> tuple:
    """v0131 ② 借出工具冊(VRN-2 → 別的系統):落地的 VRN2_ToolBridge 寫 VIA_Reports\\vrn2\\tools\\VRN2_ToolManifest_v0100.json
    (每支工具:檔 · sha256 · 入口 · 契約 · 能不能用)· VRN-1 借段落標題 / OCR 之前核對它 · 寫在 VRN-2 自己的輸出夾(不寫進共用家族 · 不進 git)。"""
    br = vrn / TOOLBRIDGE_NAME
    if not br.exists():
        return "YELLOW", "找不到 %s(落地失敗)· 別的系統借不到 VRN-2 的工具" % TOOLBRIDGE_NAME
    rc, ln = run([sys.executable, "-W", "ignore", str(br), "manifest", str(root)], 300, {"VIA_NO_OPEN": "1"}, cwd=str(vrn))
    line = next((l.strip() for l in ln if "借出工具冊" in l), "")
    return ("GREEN" if rc == 0 and line else "YELLOW"), ((line.split("]", 1)[-1].strip()[:260]) if line else "工具冊沒寫 rc %d" % rc)


_PV_RE = re.compile(r"<!--vrn2-pivot-->.*?<!--/vrn2-pivot-->", re.S)


def _ui_pivot_link(v2, html_path, summary: str) -> tuple:
    """v0131 U/I(VRN2_UI_latest.html)最後加一塊「PIVOT 資料庫」連結(重跑換掉同一塊 · 先寫暫存檔再換 · 「<」一律跳脫)。回 (成功, 說明)。"""
    import html as _h
    ui = v2 / "VRN2_UI_latest.html"
    hp = _cb_Path(html_path)
    if not ui.exists():
        return False, "找不到 U/I"
    if not hp.exists():
        return False, "找不到 PIVOT 頁"
    try:
        href = hp.resolve().relative_to(v2.resolve()).as_posix()
    except ValueError:
        href = hp.resolve().as_uri()
    blk = ('<!--vrn2-pivot--><section id="vrn2-pivot" style="margin:18px 16px;padding:12px 14px;border:1px solid rgba(127,127,127,.4);border-radius:10px;'
           'font:14px/1.55 system-ui,-apple-system,Segoe UI,sans-serif"><b>PIVOT 資料庫</b>(借用 VRN-1 table.pivot_db · 只收 ⑪ 獨立驗證判對位的格)· '
           '<a href="%s">%s</a><br><span style="opacity:.75">%s</span></section><!--/vrn2-pivot-->' % (_h.escape(href), _h.escape(hp.name), _h.escape(summary[:320])))
    page = ui.read_text(encoding="utf-8")
    if _PV_RE.search(page):
        page = _PV_RE.sub(lambda m: blk, page, count=1)
    elif "</body>" in page:
        k = page.rfind("</body>")
        page = page[:k] + blk + page[k:]
    else:
        page += blk
    tmp = ui.with_name(ui.name + ".pv.tmp")
    tmp.write_text(page, encoding="utf-8")
    tmp.replace(ui)
    return True, "U/I 已加 PIVOT 連結"


def _pivot_borrow(vrn, v2) -> tuple:
    """v0131 ⑫ 借 VRN-1 的 PIVOT 工具(VRN-1 工具冊 functional modules\\VRN\\ssot\\VRN_ToolManifest_v0100.json · 逐檔 sha256 · 只讀 VRN-1 的檔)
    → VIA_Reports\\vrn2\\pivot(本輪年度數據冊 + ⑪ 判決 · 冊指紋相同才用)· U/I 加連結 · 借不到(VRN-1 不在 / 冊沒有 / 檔改過)= 灰(VRN-2 照常)。
    回 (燈, 說明, 貼包行)。VIA_VRN2_NO_BORROW=1 → 不借。"""
    if os.environ.get("VIA_VRN2_NO_BORROW") == "1":
        return "GRAY", "VIA_VRN2_NO_BORROW=1 · 這次不借", []
    br = vrn / TOOLBRIDGE_NAME
    if not br.exists():
        return "YELLOW", "找不到 %s(落地失敗)" % TOOLBRIDGE_NAME, []
    rc, ln = run([sys.executable, "-W", "ignore", str(br), "pivot", str(v2)], 1800, {"VIA_NO_OPEN": "1", "VIA_VRN_HEALTH_OUT": str(v2)}, cwd=str(vrn))
    msg = [l.split("]", 1)[-1].strip() for l in ln if l.startswith("[計] ⑫")]
    head = msg[0] if msg else ""
    if rc == 0:
        ok_, why_ = _ui_pivot_link(v2, v2 / "pivot" / "VRN_Pivot_v0100.html", head)
        return "GREEN", "%s · %s" % (head[:300], why_), ["[計] " + m_[:260] for m_ in msg]
    if rc in (3, 4):
        return "GRAY", head[:300] or "rc %d" % rc, ["[計] " + head[:260]] if head else []
    tail = " · ".join(l.strip() for l in ln[-3:])[:220]
    return "YELLOW", "⑫ 沒跑完 rc %d · %s" % (rc, tail), ["[計] ⑫ 沒跑完 rc %d · %s" % (rc, tail)]


'''
k = s.index("\ndef main(argv: list) -> int:")
s = s[:k] + "\n" + helpers.rstrip("\n") + "\n\n" + s[k:]

# ---- main:② 工具冊 · ⑫ PIVOT ----
rep('''        xl, xd = land_extras(vrn)
        step("② 摘要器 ENG062 + 規則目錄 + U/I 處理器", xl, xd)
''', '''        xl, xd = land_extras(vrn)
        step("② 摘要器 ENG062 + 規則目錄 + U/I 處理器", xl, xd)
        ml_, md_ = _tools_manifest(vrn, root)                                # v0131 借出工具冊(別的系統借 VRN-2 的工具前核對 sha256)
        step("② 借出工具冊(VRN-2 → 別的系統)", ml_, md_)
''')
rep('    N = 10\n', '    N = 11\n')
rep('''            il_, id_, ipk_ = _iv_finish(ivp)
            step("⑪ 獨立驗證(背景 · 只讀)", il_, id_)
            PACK.extend(ipk_)
''', '''            il_, id_, ipk_ = _iv_finish(ivp)
            step("⑪ 獨立驗證(背景 · 只讀)", il_, id_)
            PACK.extend(ipk_)
            bar(10, N, "⑫ PIVOT 資料庫(借用 VRN-1 的工具 · sha256 核對 · 只收 ⑪ 判對位的格)")
            pl_, pd_, ppk_ = _pivot_borrow(vrn, v2)                            # v0131 ⑫ 借 VRN-1 table.pivot_db → VIA_Reports\\vrn2\\pivot + U/I 連結
            step("⑫ PIVOT 資料庫(借用 VRN-1)", pl_, pd_)
            PACK.extend(ppk_)
            _tools_manifest(vrn, root)                                            # ⑫ 之後再寫一次工具冊(③b 本輪才建好的 OCR 隔離環境 → ocr.image 標能用)
''')
rep('''            nxt = "VRN-2 完成 · 自測 / 實測全過 · " + ivt + ((" · " + exc_ + " 待 OCR") if exc_ else "")''',
    '''            _pv = next((s_ for s_ in STEPS if s_["step"].startswith("⑫")), None)
            nxt = "VRN-2 完成 · 自測 / 實測全過 · " + ivt + ((" · " + exc_ + " 待 OCR") if exc_ else "") + (
                " · PIVOT 資料庫已寫(借用 VRN-1)" if _pv and _pv["lamp"] == "GREEN" else (" · PIVOT 沒寫(%s)" % _pv["detail"][:50] if _pv else ""))''')

# ---- 自測 ----
rep('''    print("[計] %s 自測 %d/%d · %s" % (VERSION, ok, tot, "PASS" if ok == tot else "FAIL"))
    return 0 if ok == tot else 1


def _sysinfo(''', '''    tbb = next((e for e in EXTRAS if e[0] == TOOLBRIDGE_NAME), None)
    tbsrc = base64.b64decode("".join(tbb[2].split())).decode("utf-8") if tbb else ""
    chk("v0131 內嵌工具橋 %s(借出 section_near / ocr_read · 借入 pivot_vrn2 · sha256 核對 · 有 main · 帶加速器橋 · 不 import VRN-1 程式)" % TOOLBRIDGE_NAME,
        bool(tbb) and all(x in tbsrc for x in ("def section_near(", "def ocr_read(", "def pivot_vrn2(", "def borrow(", "def main(", "[VIA:ACCEL-BRIDGE:v0111]"))
        and "import VRN_" not in tbsrc and "from VRN_" not in tbsrc)
    with tempfile.TemporaryDirectory(prefix="act131tb-") as td_:
        p_ = _cb_Path(td_) / TOOLBRIDGE_NAME
        p_.write_bytes(base64.b64decode("".join(tbb[2].split())) if tbb else b"")
        rc_tb, ln_tb = run([sys.executable, "-W", "ignore", str(p_), "--selftest"], 300, {"VIA_NO_OPEN": "1"}, cwd=td_)
    chk("v0131 工具橋自測(期間字 · 事實表契約 · 借之前 sha256 · 檔改過不借 · OCR 不在照實說)→ %s" % next((l.strip() for l in reversed(ln_tb) if "自測" in l), "rc %d" % rc_tb)[-60:],
        rc_tb == 0)
    chk("v0131 ② 借出工具冊在落地之後 · ⑫ 在 ⑪ 之後、開 U/I 之前", _ms.index('step("② 借出工具冊') > _ms.index("land_extras(vrn)") and
        _ms.index('step("⑪') < _ms.index('step("⑫') < _ms.index("_ui_open("))
    with tempfile.TemporaryDirectory(prefix="act131ui-") as td_:
        v2_ = _cb_Path(td_)
        (v2_ / "pivot").mkdir()
        (v2_ / "pivot" / "VRN_Pivot_v0100.html").write_text("<html></html>", encoding="utf-8")
        (v2_ / "VRN2_UI_latest.html").write_text("<html><body><p>ui</p></body></html>", encoding="utf-8")
        a_ = _ui_pivot_link(v2_, v2_ / "pivot" / "VRN_Pivot_v0100.html", "事實 1/1 <b>")
        esc_ = "事實 1/1 &lt;b&gt;" in (v2_ / "VRN2_UI_latest.html").read_text(encoding="utf-8")
        b_ = _ui_pivot_link(v2_, v2_ / "pivot" / "VRN_Pivot_v0100.html", "事實 2/2")
        pg_ = (v2_ / "VRN2_UI_latest.html").read_text(encoding="utf-8")
    chk("v0131 U/I 加 PIVOT 連結:相對路徑 · 重跑換掉同一塊(不疊加)· 摘要跳脫", a_[0] and b_[0] and pg_.count('id="vrn2-pivot"') == 1 and 'href="pivot/VRN_Pivot_v0100.html"' in pg_
        and esc_ and "事實 2/2" in pg_ and "事實 1/1" not in pg_ and pg_.rstrip().endswith("</body></html>"))
    print("[計] %s 自測 %d/%d · %s" % (VERSION, ok, tot, "PASS" if ok == tot else "FAIL"))
    return 0 if ok == tot else 1


def _sysinfo(''')

compile(s, out_p.name, "exec")
out_p.write_text(s, encoding="utf-8", newline="")
print("[計] %s · %d 位元組 · sha %s · 工具橋 %s · 交接報告 %s" % (out_p.name, len(s.encode()), hashlib.sha256(s.encode()).hexdigest()[:12], bsha[:12], hsha[:12]))
