#!/bin/bash
# v0131 e2e:沙盒樹(mktree)· 啟動器 v0131 · VRN-1 = /home/user/via-vdf-vrn(工具冊在)· 跑兩次(第二次 = 冪等 / 已在且 hash 同)
S=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v131; T=$W/t131
cd /tmp && $S/tools/mktree.sh $T $W/ActivateVRN-2_v0131.py > $W/e2e_setup.log 2>&1
for i in 1 2; do
  cd "$T/Downloads" && env HOME="$T/home" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" VIA_VRN_INPUT="$T/samples" VIA_ENVS_HOME="$T/envs" \
    VIA_VRN2_OCR_PY="$(command -v python3)" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 \
    VIA_VRN1_ROOT=/home/user/via-vdf-vrn timeout 3500 $S/venv_vrn2/bin/python ActivateVRN-2.py --no-install > $W/e2e_run$i.log 2>&1
  echo "run$i rc $?" >> $W/e2e.rc
  sed -i 's/\x1b\[[0-9;]*m//g' $W/e2e_run$i.log
done
echo done >> $W/e2e.rc
