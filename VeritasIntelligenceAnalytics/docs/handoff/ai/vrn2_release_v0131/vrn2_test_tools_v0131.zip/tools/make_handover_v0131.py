"""VRN2_Handover_v0131.md = v0129 交接報告 + v0131 工具相互取用(錨點替換 · 冪等:同一份輸入 → 同一份輸出)。
用法:python make_handover_v0131.py <v0129.md> <結果 json> <輸出 md>
結果 json:{"e2e": "...", "vrn1": "...", "pivot": "...", "launcher_sha": "...", "selftest": "..."}(容器實測數字)"""
import json
import sys
from pathlib import Path

src, res_p, out = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
s = src.read_text(encoding="utf-8")
R = json.loads(res_p.read_text(encoding="utf-8"))


def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80])
    s = s.replace(a, b)


rep("# VRN-2 交接報告 · ActivateVRN-2 v0129 · 2026-10-19(邊測邊修:並排表的段落標題改回同一欄(管理器 v0239 · 驗證器 v0102)· v0128:依 MAIN 登記紀錄定位 · 表頭列移出年度數據 · v0127:HTML U/I 顯示驗證過的輸出)",
    "# VRN-2 交接報告 · ActivateVRN-2 v0131 · 2026-10-20(工具相互取用:VRN-2 借 VRN-1 的 PIVOT 資料庫工具 ⑫ · 借出段落標題 / OCR 給 VRN-1 · 兩個獨立 MAIN · v0129:並排表的段落標題改回同一欄)")
rep("> **本輪(v0129 · 邊測邊修:管理器 v0239 · 獨立驗證器 v0102 · 啟動器邏輯同 v0128)**",
    "> **操作員令(2026-10-20)**:「VRN-1 VRN-2 工具可相互取用 · 可驗證性高精準度還原後表格可改為資料庫形式 PIVOT · 兩個系統元主體邏輯不變但各式可以找缺少的工具 · 獨立系統兩個 MAIN」。\n"
    "> **本輪(v0131 · 啟動器 + 工具橋 VRN2_ToolBridge_v0100 · 管理器鏈 / ENG397 / 摘要器 / 驗證器 / 處理器一個位元組都不動)**:兩個系統各寫各的工具橋、各有自己的**工具冊**"
    "(每支工具的檔 · sha256 · 入口 · 契約 · 能不能用)· 借之前逐檔核對對方工具冊的 sha256(不符 = 不借 · 照實寫)· 只讀對方的檔(不改 · 不複製 · 載入時不寫 __pycache__)· "
    "借不到 = 只用自己的工具(灰 / 黃,不是紅)。① **② 寫 VRN-2 的借出工具冊** `VIA_Reports\\vrn2\\tools\\VRN2_ToolManifest_v0100.json`:`section.near`(段落標題 —— VRN-2 管理器的第三讀法 + v0239 的 `_sec_near`)· "
    "`ocr.image`(OCR 隔離環境)。② **⑫ 借 VRN-1 的 PIVOT 資料庫工具**(`table.pivot_db` · VRN-1 工具冊 `<VRN-1 倉>\\functional modules\\VRN\\ssot\\VRN_ToolManifest_v0100.json`)"
    "→ `VIA_Reports\\vrn2\\pivot\\`:事實表(一格一列)+ 年度 PIVOT(表層 · 報告層)· SQLite 一定有 · DuckDB 有才寫 · CSV · Parquet · HTML · **只收 ⑪ 獨立驗證判對位的格(冊指紋相同才用)** · "
    "同一格兩個不同的證實值 → 格子留空、列進衝突表(不挑)· U/I 最後多一塊「PIVOT 資料庫」連結。③ 容器實測:%s ④ VRN-1 這邊(另一團隊的倉 · 只讀 · 修改另以 patch 交給操作員):%s\n"
    "> **前一輪(v0129 · 邊測邊修:管理器 v0239 · 獨立驗證器 v0102 · 啟動器邏輯同 v0128)**" % (R["e2e"], R["vrn1"]))
rep("> **前一輪(v0128 · 啟動器依紀錄定位", "> **v0128(啟動器依紀錄定位")
rep("- **VRN-1** = 另一團隊(`C:\\Users\\tonyk\\VIA-VDF-VRN`):互相學方法、不照抄程式碼。",
    "- **VRN-1** = 另一團隊(`C:\\Users\\tonyk\\VIA-VDF-VRN`):互相學方法、不照抄程式碼;**v0131 起工具可相互取用**(兩邊各自的工具冊 + sha256 核對 · 只讀對方的檔 · 不複製):"
    "VRN-2 借 VRN-1 的 PIVOT 資料庫工具(⑫)· VRN-1 借 VRN-2 的段落標題讀法(`section.near`)與 OCR(`ocr.image`)。兩個系統各有自己的 MAIN(VRN-1 = `VRN_Main_v0100.py` · VRN-2 = `ActivateVRN-2.py`),主體邏輯各自不變。")
rep("| **啟動器(MAIN)** | `C:\\Users\\tonyk\\Downloads\\ActivateVRN-2.py` | **v0129** · 雜湊見 `docs/handoff/ai/vrn2_release_v0129/VRN2_Release_v0129.json` · 一鍵:`vrn2_release_v0129/VRN2_OneClick_v0129.md`(**cmd / PowerShell 都能貼的一行**)· 程式夾定位依 MAIN 登記紀錄(v0128 起) |",
    "| **啟動器(MAIN)** | `C:\\Users\\tonyk\\Downloads\\ActivateVRN-2.py` | **v0131** · 雜湊見 `docs/handoff/ai/vrn2_release_v0131/VRN2_Release_v0131.json` · 一鍵:`vrn2_release_v0131/VRN2_OneClick_v0131.md`(**cmd / PowerShell 都能貼的一行**)· 程式夾定位依 MAIN 登記紀錄(v0128 起) |\n"
    "| **工具橋** | `<ROOT>\\functional modules\\VRN\\VRN2_ToolBridge_v0100.py` | v0131 落地 · 借出 `section.near` / `ocr.image` · 借入 VRN-1 `table.pivot_db` · 進船包 |\n"
    "| **借出工具冊** | `<ROOT>\\VIA_Reports\\vrn2\\tools\\VRN2_ToolManifest_v0100.json` | ② 寫 · ⑫ 之後再寫一次(本輪才建好的 OCR 隔離環境 → `ocr.image` 標能用)· VRN-1 借之前核對 sha256 |\n"
    "| **PIVOT 資料庫** | `<ROOT>\\VIA_Reports\\vrn2\\pivot\\` | ⑫ 寫:`VRN_Pivot_v0100.sqlite`(+ `.duckdb` 有 duckdb 才寫)· `facts` / `pivot_report_annual` / `pivot_annual` / `conflicts` / `precision_merges` 的 CSV + Parquet · `VRN_Pivot_v0100.html` · `VRN2_Pivot_Borrow_latest.json`(借用紀錄:來源 · sha256)|\n"
    "| **VRN-1 工具冊** | `C:\\Users\\tonyk\\VIA-VDF-VRN\\functional modules\\VRN\\ssot\\VRN_ToolManifest_v0100.json` | VRN-1 的 `build` 寫 · **操作員套用 VRN-1 的 patch 之後才有**(沒有 → ⑫ 灰「借不到」· VRN-2 照常)· 找 VRN-1:`VIA_VRN1_ROOT` → `C:\\Users\\tonyk\\VIA-VDF-VRN` → 家目錄 → VIA 倉旁邊 |")
rep("| **交接報告** | `<ROOT>\\docs\\handoff\\ai\\VRN2_Handover_latest.md`(+ `VRN2_Handover_v0129.md`) | ⑨ 自動落地(與 repo 同一份) |",
    "| **交接報告** | `<ROOT>\\docs\\handoff\\ai\\VRN2_Handover_latest.md`(+ `VRN2_Handover_v0131.md`) | ⑨ 自動落地(與 repo 同一份) |")
rep("| 本輪證據 | `<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0129\\`(v0128:`vrn2_release_v0128\\` · v0127:`vrn2_release_v0127\\`)|",
    "| 本輪證據 | `<ROOT>\\docs\\handoff\\ai\\vrn2_release_v0131\\`(v0130:一鍵判定 · v0129:`vrn2_release_v0129\\` · v0128:`vrn2_release_v0128\\`)|")
rep("### 3.1 現役版本(v0129 內嵌 · 依序自動落地)", "### 3.1 現役版本(v0131 內嵌 · 依序自動落地)")
rep("| ActivateVRN-2.py | **v0129** | 見發行清單 | 見發行清單 | 新(管理器鏈加 v0239 · 驗證器 v0102 · 其餘邏輯同 v0128)· v0128:依 MAIN 登記紀錄定位程式夾 · ⑨ git 失敗訊息一行 · v0238 · v0101 |",
    "| ActivateVRN-2.py | **v0131** | 見發行清單 | 見發行清單(本檔內嵌在啟動器裡,不寫啟動器自己的雜湊)| 新(② 借出工具冊 · ⑫ 借 VRN-1 PIVOT · U/I 連結 · 其餘邏輯同 v0129)|\n"
    "| **VRN2_ToolBridge** | **v0100** | 見發行清單 | 見發行清單 | **新**(工具橋 · 不 import VRN-1 程式 · 借的時候依工具冊路徑載入 · sha256 核對)|")
rep("| **v0129** | → **v0239** | v0127 | v0114 | 並排表的段落標題改回同一欄 · 驗證器 v0102 SECFAIL |",
    "| v0129 | → v0239 | v0127 | v0114 | 並排表的段落標題改回同一欄 · 驗證器 v0102 SECFAIL |\n"
    "| (一鍵 v0130) | 同 v0129 | | | 一鍵判定三處(⑪ 三段 · 只驗本輪的冊 · 成功看本輪 ⑧)|\n"
    "| **v0131** | 同 v0239 | v0127 | v0114 | 工具相互取用:② 借出工具冊 · ⑫ 借 VRN-1 PIVOT 資料庫 · 工具橋 v0100 |")
rep("## 7. 本輪修正(v0128 → v0129)", "## 7. 本輪修正(v0129 → v0131 · 工具相互取用)\n\n"
    "| # | 需求 / 發現 | 做法 | 實測 |\n|---|---|---|---|\n"
    "| 1 | 操作員:VRN-1 / VRN-2 工具可相互取用 · 兩個獨立 MAIN · 主體邏輯不變 | 兩邊各寫各的工具橋(VRN-2 `VRN2_ToolBridge_v0100` · VRN-1 `VRN_ToolBridge_v0100`)· 各自的工具冊(`VIA_ToolManifest/1`:檔 · sha256 · 入口 · 契約 · 能不能用)· 借之前逐檔核對 · 依路徑載入、獨立模組名 · 載入時不寫 __pycache__ · 只寫自己的輸出夾 | 工具橋自測(sha256 不同 → 不借 · 對方標不能用 → 不借 · 找不到 → 只用自己的)|\n"
    "| 2 | 還原後表格可改為資料庫形式 PIVOT | ⑫ 借 VRN-1 的 `table.pivot_db`:VRN-2 年度數據冊 → 契約 `VIA_PivotFacts/1`(VRN-2 這邊自己對欄位:科目照原文 · 段落 › 科目 [子欄] · 同一張表同一個科目字好幾列 → 加 #列號 · 期間 2025E / FY25A / 12/25E / Dec-25F / 2025CT → 年)· **只收 ⑪ 判對位的格**(冊指紋相同才用)→ SQLite / DuckDB / CSV / Parquet / HTML | %s |\n"
    "| 3 | 借給 VRN-1:段落標題 | `section.near`:VRN-2 第三讀法(pdfplumber 字詞框)+ v0239 `_sec_near`(本體不改)· 只餵科目欄起點以右的字(並排表左表的數值欄落在右表科目欄 ±40 pt 內 → 以前判成數據列、回空白 · MS 3661 第 10 頁)· 值不在科目那一列(轉置表 / 欄頭在上)→ 不定 | VRN-1 借去之後 G21 剔除 39 筆真錯(成長率 / 比率段落底下被歸成金額的值)|\n"
    "| 4 | 借給 VRN-1:OCR | `ocr.image`:VRN-2 的 OCR 隔離環境(envs\\vrn2_ocr · rapidocr)跑 VRN2_OCRBridge · 形狀同 VRN-1 的 OCR 結果 · OCR 的字照舊不進判讀 | 沙盒樹沒有隔離環境 → 工具冊標「不能用」· VRN-1 照實寫 REFUSED;照 ③b 另建隔離環境(Python 3.11 · rapidocr · numpy<2)後 → 工具冊標能用 · VRN-1 G23 借到 2 / 2 · P22 讀已知圖數字與拉丁字全中 · MQ-1560 影像 PDF 讀到 17,123 字 |\n\n"
    "## 7a. v0128 → v0129" % R["pivot"])
rep("## 7a. v0127 → v0128", "## 7b. v0127 → v0128")
rep("## 7b. v0126 → v0127", "## 7c. v0126 → v0127")
rep("| 1 | **使用者用 v0129 的一行再跑**", "| 0 | **使用者用 v0131 的一行跑**(`vrn2_release_v0131/VRN2_OneClick_v0131.md`)| 待執行 | 預期:② 借出工具冊 綠 · ⑫ 在 VRN-1 套用 patch 之前是灰「借不到 VRN-1 的 PIVOT 工具」(VRN-2 照常完成)· 套用之後 ⑫ 綠、U/I 最後有 PIVOT 連結 |\n"
    "| 0b | **VRN-1 套用 patch**(另一團隊的倉 · 操作員自己套)| 待操作員 | 套用後 VRN-1 的 `build` 寫工具冊 → VRN-2 ⑫ 才借得到;VRN-1 跑 MAIN 時 G23 借 VRN-2 的段落標題(先跑過一次 VRN-2 v0131,工具冊才在)|\n"
    "| 1 | 使用者用 v0129 的一行再跑")
rep("| **HTML U/I 上看得到驗證過的輸出** | ✅ 第一個分頁 · 每格值 + 徽章 · 指紋相同才套用 |",
    "| **HTML U/I 上看得到驗證過的輸出** | ✅ 第一個分頁 · 每格值 + 徽章 · 指紋相同才套用 |\n"
    "| **還原後表格 → 資料庫形式 PIVOT**(v0131)| ✅ 容器(借 VRN-1 工具 · 只收 ⑪ 判對位的格)· 🟡 使用者機器待 VRN-1 patch |\n"
    "| **工具相互取用 · 兩個獨立 MAIN**(v0131)| ✅ 兩邊工具冊 + sha256 核對 · 本體不改 |")
rep("一鍵(取得 v0129 → 驗雜湊 → ③b 定位 → 執行(啟動器自己跑 ①~⑪ · 開 U/I)→ 摘要 → 印驗證摘要):`docs/handoff/ai/vrn2_release_v0129/VRN2_OneClick_v0129.md`",
    "一鍵(取得 v0131 → 驗雜湊 → ③b 定位 → 執行(啟動器自己跑 ①~⑫ · 開 U/I)→ 摘要 → 印驗證摘要):`docs/handoff/ai/vrn2_release_v0131/VRN2_OneClick_v0131.md`")
rep("- 只實測不上船:PS 檔頭 `$NoPush = $true`",
    "- 不借 VRN-1 的工具:`$env:VIA_VRN2_NO_BORROW = '1'` · VRN-1 不在預設位置:`$env:VIA_VRN1_ROOT = '<VRN-1 倉>'`\n- 只實測不上船:PS 檔頭 `$NoPush = $true`")
rep("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
    "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
    "- **工具可以借,程式碼不照抄**:借 = 讀對方的工具冊 → 逐檔核對 sha256 → 依路徑載入(獨立模組名 · 不寫 __pycache__)→ 只寫自己的輸出夾。對方的檔一個都不改、不複製進自己的夾;對方沒有 / 檔改過 / 自己標不能用 → 不借、照實寫(灰 / 黃 · 不是紅)。\n"
    "- **借讀法,不借判準**:VRN-1 借 VRN-2 的段落標題「讀法」,判準(成長率 / 比率段落底下的金額科目 = 錯)是 VRN-1 自己的;VRN-2 借 VRN-1 的 PIVOT「工具」,哪些格可以進去(⑪ 判對位)是 VRN-2 自己決定的。\n"
    "- **PIVOT 的衝突表是第二道檢查**:同一格兩個不同的證實值 → 至少一個是錯的或科目字有歧義 → 留空、列出來(sign = 符號慣例 · scale = 單位 · value = 真的不同),不挑。同一個數印的位數不同(4,458 / 4,457.8)不是衝突。\n"
    "- **同一張表同一個科目字出現在好幾列是不同的量**(現金流量表的 Other adjustments · 每個科目底下的 Percent of Revenues)→ 帶列號;跨表同名(損益表 / 資產負債表的 Minority interest)也是不同的量 → 報告層留空列衝突。\n")
out.write_text(s, encoding="utf-8", newline="\n")
print("[計] %s · %d 字" % (out.name, len(s)))
