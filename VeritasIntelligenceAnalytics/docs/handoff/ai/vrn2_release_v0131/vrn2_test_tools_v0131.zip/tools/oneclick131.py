"""一鍵 v0131:Run-VRN2-v0131.ps1(由 v0130 錨點替換)+ VRN2_OneClick_v0131.md + boot131.ps1 + oneline131.txt(冪等)。
用法:python oneclick131.py <ActivateVRN-2 v0131 SHA-256> <輸出夾>
v0131 一鍵 = v0130 的判定照舊 + 取 v0131 啟動器(發行夾 vrn2_release_v0131)+ ⑤ 摘要多兩行(借出工具冊 · ⑫ PIVOT 資料庫)。"""
import base64
import hashlib
import re
import sys
from pathlib import Path

S = "/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"
want, out = sys.argv[1], Path(sys.argv[2])
assert re.fullmatch(r"[0-9a-f]{64}", want)
out.mkdir(parents=True, exist_ok=True)
ps = open(S + "/Run-VRN2-v0130.ps1", encoding="utf-8").read().rstrip("\n")


def rep(a, b, n=1):
    global ps
    assert ps.count(a) == n, (ps.count(a), a[:80])
    ps = ps.replace(a, b)


rep("# ===== VRN-2 一鍵 v0130(啟動器 v0129 不變 · 一鍵只改判定:⑪ 報告三段都看 · PS 自驗只驗本輪的冊 · 成功看本輪 ⑧ 完成燈)· v0129 一鍵全流程(",
    "# ===== VRN-2 一鍵 v0131(啟動器 v0131 · 工具相互取用:② 借出工具冊 · ⑫ 借 VRN-1 的 PIVOT 資料庫工具 · VRN-2 主體不動)· v0130 判定(⑪ 報告三段都看 · PS 自驗只驗本輪的冊 · 成功看本輪 ⑧ 完成燈)· v0129 一鍵全流程(")
rep("# v0129 發行所在的 GitHub 分支(只讀取 · 不切換分支 · 讀不到 → 改讀 main)", "# v0131 發行所在的 GitHub 分支(只讀取 · 不切換分支 · 讀不到 → 改讀 main)")
rep("$RelP   = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0129'     # 發行夾(repo 根起算)",
    "$RelP   = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0131'     # 發行夾(repo 根起算)")
rep("$Want   = '600637bf6454af5e49140e3ec0f44903c3961de47a9c927bfa8154f0cd4163a7'   # ActivateVRN-2 v0129 SHA-256",
    "$Want   = '%s'   # ActivateVRN-2 v0131 SHA-256" % want)
rep('("vrn2_v0130_"', '("vrn2_v0131_"')
rep("# ③ 取得啟動器 v0129:", "# ③ 取得啟動器 v0131:")
rep("'vrn2_release_v0129.zip'", "'vrn2_release_v0131.zip'")
rep('Say RED "③ 本機啟動器不是 v0129,且讀不到 GitHub 分支 $Br 或 main(網路 / git)· 請手動下載 ActivateVRN-2.py v0129 到 $A"',
    'Say RED "③ 本機啟動器不是 v0131,且讀不到 GitHub 分支 $Br 或 main(網路 / git)· 請手動下載 ActivateVRN-2.py v0131 到 $A"')
rep("'ActivateVRN-2_v0129.zip'", "'ActivateVRN-2_v0131.zip'")
rep("'VRN2_Release_v0129.json'", "'VRN2_Release_v0131.json'")
rep('Say GREEN "③ 啟動器 v0129 就位', 'Say GREEN "③ 啟動器 v0131 就位')
rep('Say GREEN "③ 本機已是 v0129', 'Say GREEN "③ 本機已是 v0131')
rep('Say YELLOW "③b 交給啟動器 v0129', 'Say YELLOW "③b 交給啟動器 v0131')
rep('Write-Host ("[計] VRN-2 一鍵 v0130 · ActivateVRN-2 v0129 · {0}"', 'Write-Host ("[計] VRN-2 一鍵 v0131 · ActivateVRN-2 v0131 · {0}"')
rep("':(exclude)docs/handoff/ai/VRN2_Handover_v0129.md'", "':(exclude)docs/handoff/ai/VRN2_Handover_v0131.md'")
rep("GREEN = 'VRN-2 一鍵 v0130 跑完 · ⑧ 本輪完成 · 獨立驗證錯值 0 · U/I 已開在「驗證過的輸出」· 把 ⑨ / ⑪ 兩行 + 驗證摘要貼回'",
    "GREEN = 'VRN-2 一鍵 v0131 跑完 · ⑧ 本輪完成 · 獨立驗證錯值 0 · U/I 已開在「驗證過的輸出」(最後有 PIVOT 資料庫連結)· 把 ⑨ / ⑪ / ⑫ 三行 + 驗證摘要貼回'")
# ⑤ 摘要:借出工具冊 · ⑫ PIVOT(本輪寫的才算 · 沒有 = 灰:VRN-1 的工具借不到時 VRN-2 照常)
rep('''    print("YELLOW|U/I %s · 「驗證過的輸出」分頁 · 獨立驗證%s" % (up, "結果是別一輪的(指紋不同)" if m else "尚未寫回"))
''', '''    print("YELLOW|U/I %s · 「驗證過的輸出」分頁 · 獨立驗證%s" % (up, "結果是別一輪的(指紋不同)" if m else "尚未寫回"))
tm = j(v2 / "tools" / "VRN2_ToolManifest_v0100.json") or {}
if tm.get("offers"):
    print("GREEN|② 借出工具冊 %s · %s" % (v2 / "tools" / "VRN2_ToolManifest_v0100.json", " · ".join("%s %s" % (t.get("id"), "能用" if t.get("ready") else "不能用") for t in tm["offers"])))
else:
    print("YELLOW|② 借出工具冊沒寫(看啟動器 ② 那行)")
pb = v2 / "pivot" / "VRN2_Pivot_Borrow_latest.json"
pj = j(pb) or {}
if pj and datetime.datetime.fromtimestamp(pb.stat().st_mtime) >= t0 - datetime.timedelta(seconds=5):
    pc = pj.get("counts") or {}
    print("GREEN|⑫ PIVOT 資料庫(借用 %s %s · sha256 %s)· 事實 %s/%s · 年度 %s 列 · 衝突 %s · %s" % (
        (pj.get("borrow") or {}).get("from", "?"), (pj.get("borrow") or {}).get("id", "?"), str((pj.get("borrow") or {}).get("sha256", ""))[:12],
        pc.get("kept"), pc.get("facts"), pc.get("pivot_report_annual"), pc.get("conflicts"), v2 / "pivot" / "VRN_Pivot_v0100.html"))
else:
    print("GRAY|⑫ PIVOT 資料庫本輪沒寫(VRN-1 的工具借不到或不借 · VRN-2 照常 · 看啟動器 ⑫ 那行)")
''')
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = r"""$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$R  = if ($env:VRN2_ROOT) { $env:VRN2_ROOT } else { 'C:\Users\tonyk\OneDrive\Documents\movies-dataset\VeritasIntelligenceAnalytics' }
$Br = 'claude/optimistic-goodall-yhalc5'
$P  = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0131'
$H  = '@CS@'
Write-Host ('[VRN-2] PowerShell ' + $PSVersionTable.PSVersion + ' · 從 GitHub 讀一鍵 v0131 程式碼(核對 SHA-256 後執行)') -ForegroundColor Yellow
$top = git -C $R rev-parse --show-toplevel 2>$null
if (-not $top) { Write-Host "[RED] $R 不是 git 倉或找不到 git" -ForegroundColor Red; return }
$top = "$top".Trim()
$t = Join-Path ([IO.Path]::GetTempPath()) ('vrn2_boot_' + (Get-Date).ToString('yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Force -Path $t | Out-Null
$z = Join-Path $t 'oneclick.zip'; $okz = $false
foreach ($b in $Br, 'main') {
  foreach ($w in 0, 2, 4, 8, 16) { if ($w) { Start-Sleep -Seconds $w }; git -C $top fetch -q origin $b 2>&1 | Out-Null; if ($LASTEXITCODE -eq 0) { break } }
  git -C $top archive --format=zip -o $z ('origin/' + $b + ':' + $P) VRN2_OneClick_v0131.md 2>&1 | Out-Null
  if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $z)) { $okz = $true; Write-Host ('[計] 一鍵程式碼來源 GitHub ' + $b) -ForegroundColor DarkGray; break }
}
if (-not $okz) { Write-Host "[RED] 讀不到 GitHub 分支 $Br 或 main 的一鍵程式碼(網路 / git)" -ForegroundColor Red; return }
Expand-Archive -LiteralPath $z -DestinationPath $t -Force
$md = [IO.File]::ReadAllText((Join-Path $t 'VRN2_OneClick_v0131.md'), [Text.Encoding]::UTF8) -replace "`r`n", "`n"
$code = [regex]::Match($md, '(?s)```powershell\n(.*?)\n```').Groups[1].Value
$sha = -join ([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($code)) | ForEach-Object { $_.ToString('x2') })
if ($sha -ne $H) { Write-Host "[RED] 一鍵程式碼 SHA-256 不對($sha)· 不執行" -ForegroundColor Red; return }
Write-Host ('[GREEN] 一鍵程式碼 SHA-256 ' + $H.Substring(0, 12) + ' 相符 → 在 PowerShell 裡執行') -ForegroundColor Green
& ([scriptblock]::Create($code))
""".replace("@CS@", cs)
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii")
assert len(one) < 8191, len(one)
md = """# VRN-2 一鍵 v0131(cmd / PowerShell 都能貼 · 啟動器 v0131 · 工具相互取用)

v0131 = 操作員令(2026-10-20)「VRN-1 VRN-2 工具可相互取用 · 可驗證性高精準度還原後表格可改為資料庫形式 PIVOT · 兩個系統元主體邏輯不變但各式可以找缺少的工具 · 獨立系統兩個 MAIN」。
啟動器 `ActivateVRN-2.py` **v0131**(SHA-256 `@WANT@` · 從 `vrn2_release_v0131` 取):

| 步驟 | v0131 新增 | 借不到時 |
|---|---|---|
| ② 借出工具冊 | 落地 `VRN2_ToolBridge_v0100.py` → 寫 `VIA_Reports\\vrn2\\tools\\VRN2_ToolManifest_v0100.json`(段落標題 `section.near` · OCR `ocr.image` · 每支工具的檔 / sha256 / 入口 / 契約)· VRN-1 借之前核對它 | — |
| ⑫ PIVOT 資料庫 | 借 VRN-1 的 `table.pivot_db`(VRN-1 工具冊 · 逐檔 sha256 · 只讀 VRN-1 的檔)→ `VIA_Reports\\vrn2\\pivot\\`(事實表 + 年度 PIVOT · SQLite / DuckDB / CSV / Parquet / HTML · **只收 ⑪ 判對位的格** · 同格不同值留空列衝突)· U/I 最後一塊「PIVOT 資料庫」連結 | 灰「借不到 VRN-1 的 PIVOT 工具」(VRN-1 還沒套用它的 patch · 或不在 `C:\\Users\\tonyk\\VIA-VDF-VRN`)· VRN-2 照常完成 |

VRN-2 主體(管理器鏈 v0231 → v0239 · ENG397 · 摘要器 · 獨立驗證器 · 處理器)**一個位元組都不動**;一鍵的判定照 v0130(⑪ 報告三段 · 只驗本輪的冊 · 成功看本輪 ⑧)· ⑤ 摘要多兩行(借出工具冊 · ⑫ PIVOT)。容器實測見 `VRN2_Verification_v0131.md`。

開關:檔頭 `$NoPush = $true` 只實測不上船 · `$Verify = $false` 啟動器沒驗到時 PS 也不補驗 · `$env:VIA_VRN2_NO_VERIFY = '1'` 啟動器不跑 ⑪ · `$env:VIA_VRN2_NO_BORROW = '1'` 這次不借 VRN-1 的工具 · `$env:VIA_VRN1_ROOT = '<VRN-1 倉>'` VRN-1 不在預設位置 · `$env:VRN2_VERIFY_PAR = '2'` 驗證平行路數 · `$env:VIA_VRN2_VERIFY_WAIT = '3600'` ⑪ 等待上限(秒)。

## 在「命令提示字元(cmd)」或 PowerShell 都能貼的一行(建議用這個)

這一行在 cmd 或 PowerShell 貼上都可以:它開 Windows PowerShell → 從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)讀本檔的一鍵程式碼 → **核對 SHA-256 `@CS@`** → 相符才在 PowerShell 裡執行(不相符就停 · 不執行)。內容是本檔最後「一行的原始碼」用 UTF-16LE 編成 Base64(`-EncodedCommand`)。**不要把下面整段程式碼貼進 cmd**(cmd 不認得 PowerShell)。

```bat
@ONE@
```

或:在 cmd 先輸入 `powershell` 按 Enter(提示字元變成 `PS C:\\Users\\tonyk>`),再貼下面整段程式碼。

程式碼 SHA-256(本文 · 一行核對的就是這個):`@CS12@`

```powershell
@PS@
```

## 一行的原始碼(`-EncodedCommand` 解碼後 · 只讀取並核對 · 不改任何檔)

```text
@BOOT@
```
"""
md = md.replace("@WANT@", want).replace("@CS12@", cs[:12]).replace("@CS@", cs).replace("@ONE@", one).replace("@BOOT@", boot.rstrip("\n")).replace("@PS@", ps)
assert re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1) == ps and md.count("```powershell\n") == 1
assert base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", md).group(1).split()[-1]).decode("utf-16-le") == boot
assert re.search(r"(?s)```text\n(.*?)\n```", md).group(1) == boot.rstrip("\n")
(out / "VRN2_OneClick_v0131.md").write_text(md, encoding="utf-8", newline="\n")
(out / "boot131.ps1").write_text(boot, encoding="utf-8", newline="\n")
(out / "oneline131.txt").write_text(one + "\n", encoding="utf-8")
(out / "Run-VRN2-v0131.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n")
print("launcher %s · code %s · one-liner %d 字 · md %d" % (want[:12], cs[:12], len(one), len(md)))
