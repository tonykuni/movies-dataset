#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Independent verifier v0112: v0111 + a second reading for the basic-info price labels (v0111 kept byte-identical).

v0112: desktop 2026-10-29 19:00 (RoundAll v0102): MS-6669 CURRENT_PRICE_REPORT 3510.00 FAIL "next to the target-price label" and MS-3661 3190.00 FAIL
"not in the first 4 pages", while the source lines are "Shr price, close (Oct 7, 2025) NT$3,510.00" / "... (Dec 3, 2025) NT$3,190.00" (RoundAll v0102
evidence, read with PDFium get_text_range) and the book values equal them. The character-box reader (page_lines) splits / pairs these sidebars
differently on the desktop's library versions (the same MS-3661 PDF passes in the container). When near_label() says no, v0112 reads the page a
second way (PDFium whole-page text + pdfplumber text lines) and accepts the value only when the label on the SAME line, nearest before the value,
is the field's own label (or "<n>% upside" / "NT$<n> price target" right after it). A value whose same-line label is the other price (a swap)
stays FAIL, so the swap / mutation checks keep working.

v0111: v0110 with the source-excerpt reader switched to VRN2_VerbatimVerifier_v0105 (v0110 kept byte-identical).

v0111: a hyphen at a line end matches however PDFium writes it (U+FFFE / U+0002 / "-" + line break, any next character) — the desktop's
only point FAIL (3014TT-20231005.pdf point 3, "…Type-" / "C PD …") came from that. Same structure as v0110 (the --shard children run this file).

v0110: exact source excerpts (verbatim v0104 · MISSING ≠ FAIL); v0105 financial checks intact.

For SOURCE_VERBATIM books, complete PDFium source matches replace the old
synthetic-sentence coverage heuristic. OCR stays pending; mismatches stay FAIL.
"""
from __future__ import annotations
import importlib.util
from pathlib import Path
import re
import sys
import types


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


# [VIA:ACCEL-BRIDGE:v0111] Every verifier shard applies the active locked tool.
BRIDGE = load("independent_v0112_execution", "VIA_ExecutionBridge_v0103.py")
BRIDGE.activate(Path(__file__).resolve().parents[2])
PRIOR = load("independent_v0112_financial_core", "VRN2_IndependentVerifier_v0105.py")
QUOTES = load("independent_v0112_source_reader", "VRN2_VerbatimVerifier_v0105.py")
for _name, _value in list(vars(PRIOR).items()):
    if not _name.startswith("__") and _name not in globals():
        globals()[_name] = _value
VERSION = "VRN2_IndependentVerifier_v0112"
_native_near_label = PRIOR.near_label
_AFTER_LABEL = {3: re.compile(r"^\s*%\s*(?:upside|downside|潛在漲幅|上漲空間|隱含漲幅|漲幅)", re.I), 1: re.compile(r"^\s*(?:price\s*target|target\s*price|目標價)", re.I)}
_TEXT_LINES = {}


def text_lines(pdf, pno):
    """v0112 second reading of a page: PDFium whole-page text (get_text_range) + pdfplumber text lines (not the character boxes of page_lines)."""
    key = (str(pdf), pno)
    if key not in _TEXT_LINES:
        out = []
        try:
            doc = pdfium.PdfDocument(str(pdf))
            if 1 <= pno <= len(doc):
                out += doc[pno - 1].get_textpage().get_text_range().replace("\r", "\n").split("\n")
            doc.close()
        except Exception:  # noqa: BLE001
            pass
        try:
            import pdfplumber
            with pdfplumber.open(str(pdf)) as d:
                if pno <= len(d.pages):
                    out += (d.pages[pno - 1].extract_text() or "").split("\n")
        except Exception:  # noqa: BLE001
            pass
        _TEXT_LINES[key] = [nfk(line) for line in out if line.strip()]
    return _TEXT_LINES[key]


def line_label(line, start, end):
    """Kind of the label that owns the number at line[start:end]: '<n>% upside' / '<n> price target' right after it, else the nearest label before it on the line (0 = none)."""
    for kind, rx in _AFTER_LABEL.items():
        if rx.match(line[end:]):
            return kind
    before = [(m.end(), 1 if m.group(1) else (2 if m.group(2) else 3)) for m in _LABRX.finditer(line) if m.end() <= start]
    return max(before)[1] if before else 0


def near_label(pdf, v, field, pages=(1, 2, 3, 4)):
    """v0112: v0111's character-box check first (its message "前 %d 頁 …" kept when both readings say no); if it says no, the same-line label in
    the second reading decides (never across lines)."""
    ok, why = _native_near_label(pdf, v, field, pages)
    if ok:
        return ok, why
    fv = _numv(re.sub(r"[^\d.,]", "", str(v)).strip(".,"))
    if fv is None:
        return ok, why
    want = _KIND[field]
    for pg in pages:
        for line in text_lines(pdf, pg):
            for st_, en_ in _num_cands(line, fv):
                if line_label(line, st_, en_) == want:
                    return True, "第 %d 頁 · 同列標籤(第二種讀法 · %s)" % (pg, line[max(0, st_ - 40):en_ + 12].strip()[-72:])
    return ok, why


PRIOR.near_label = near_label            # verify_basic / _swap_hint look near_label up in the v0105 core's globals
QUOTE_RESULT = None
QUOTE_DOCUMENTS = {}


def __getattr__(name):
    return getattr(PRIOR, name)


def rebind(function):
    result = types.FunctionType(function.__code__, globals(), function.__name__, function.__defaults__, function.__closure__)
    result.__kwdefaults__ = function.__kwdefaults__
    return result


def verify_summary(rows, pdfdir, basic=None, fin=None):
    result = PRIOR.verify_summary(rows, pdfdir, basic, fin)
    if QUOTE_RESULT is None:
        return result
    index = {(row.get("file"), row.get("point")): row for row in QUOTE_RESULT["rows"]}
    global_failure = any(row["state"] == "FAIL" and not row.get("point") for row in QUOTE_RESULT["rows"])
    for item in result:
        name = item["FILENAME"]
        if (QUOTE_DOCUMENTS.get(name) or {}).get("mode") != "SOURCE_VERBATIM":
            continue
        for point in range(1, 5):
            proof = index.get((name, point), {})
            state = proof.get("state")
            if global_failure:
                state = "FAIL"
            verdict = {"PASS": "PASS", "OCR_PENDING": "OCR", "MISSING": "MISSING"}.get(state, "FAIL")
            note = "完整原文與來源 PDF 雜湊相符 · p.%s · pypdfium2" % proof.get("page") if state == "PASS" else ("影像頁 · OCR 原文需核對原圖" if state == "OCR_PENDING" else ("原文不足 · 沒有可引用的句子 · 待核對" if state == "MISSING" else proof.get("reason", "原文來源證據未齊")))
            item["checks"][f"POINT_{point}"] = verdict + " · " + note
    return result


_run_files = rebind(PRIOR.run_files)


def run_files(od, pdfdir, files):
    global QUOTE_RESULT, QUOTE_DOCUMENTS
    source = Path(od) / "VRN2_SummarySource_latest.json"
    QUOTE_RESULT, QUOTE_DOCUMENTS = None, {}
    if source.is_file():
        document = json.loads(source.read_text(encoding="utf-8-sig"))
        QUOTE_DOCUMENTS = {row["file"]: row for row in document["documents"]}
        QUOTE_RESULT = QUOTES.verify(od, pdfdir)
    return _run_files(od, pdfdir, files)


run_parallel = rebind(PRIOR.run_parallel)
write_digest = rebind(PRIOR.write_digest)
ui_payload = rebind(PRIOR.ui_payload)
main = rebind(PRIOR.main)
def selftest():
    global QUOTE_RESULT, QUOTE_DOCUMENTS
    result = PRIOR.selftest()
    original = PRIOR.verify_summary
    saved = QUOTE_RESULT, QUOTE_DOCUMENTS
    try:
        PRIOR.verify_summary = lambda *args: [{"FILENAME": "a.pdf", "checks": {"POINT_1": "PASS"}}]
        QUOTE_DOCUMENTS = {"a.pdf": {"mode": "SOURCE_VERBATIM"}}
        QUOTE_RESULT = {"rows": [{"file": "a.pdf", "point": 1, "state": "FAIL", "reason": "tampered source"}]}
        assert verify_summary([], ".")[0]["checks"]["POINT_1"].startswith("FAIL")
        QUOTE_RESULT["rows"][0]["state"] = "OCR_PENDING"
        assert verify_summary([], ".")[0]["checks"]["POINT_1"].startswith("OCR")
        QUOTE_RESULT["rows"][0]["state"] = "MISSING"
        assert verify_summary([], ".")[0]["checks"]["POINT_1"].startswith("MISSING")
        assert ui_payload([], [], [], "fp", 0, 1, True, "test")["ver"] == VERSION
    finally:
        PRIOR.verify_summary = original
        QUOTE_RESULT, QUOTE_DOCUMENTS = saved
    print("[PASS] v0110: source mismatch remains FAIL; OCR remains pending; missing excerpt is MISSING; payload carries actual verifier version")
    assert QUOTES.VERSION == "v0105" and QUOTES.comparable("Type-\nC PD") == QUOTES.comparable("Type\ufffeC PD")
    print("[PASS] v0111: excerpt reader = VerbatimVerifier v0105 (line-end hyphen as U+FFFE / U+0002 / '-' + newline, any next character)")
    sidebar = ["Stock Rating Equal-weight", "Price target NT$3,500.00", "Shr price, close (Oct 7, 2025) NT$3,510.00", "Up/downside to price target (%) -0.3",
               "Our PT of NT$730 implies 18% upside", "We reiterate our OW rating with a NT$730 price target."]
    saved_lines, saved_native = dict(_TEXT_LINES), globals()["_native_near_label"]
    try:
        _TEXT_LINES[("sidebar.pdf", 1)] = [nfk(line) for line in sidebar]
        globals()["_native_near_label"] = lambda pdf, v, field, pages=(1, 2, 3, 4): (False, "前 4 頁有這個數 · 但旁邊是目標價標籤")   # the desktop's character-box miss
        got = {k: near_label("sidebar.pdf", v, k, (1,))[0] for k, v in (("CURRENT_PRICE_REPORT", "3510.00"), ("TARGET_PRICE", "3500.00"), ("UPSIDE_PCT", "-0.3"))}
        swapped = (near_label("sidebar.pdf", "3500.00", "CURRENT_PRICE_REPORT", (1,))[0], near_label("sidebar.pdf", "3510.00", "TARGET_PRICE", (1,))[0])
        prose = (near_label("sidebar.pdf", "18", "UPSIDE_PCT", (1,))[0], near_label("sidebar.pdf", "730.00", "TARGET_PRICE", (1,))[0], near_label("sidebar.pdf", "730", "CURRENT_PRICE_REPORT", (1,))[0])
        assert got == {"CURRENT_PRICE_REPORT": True, "TARGET_PRICE": True, "UPSIDE_PCT": True}, got
        assert swapped == (False, False), swapped
        assert prose == (True, True, False), prose
        assert "第二種讀法" in near_label("sidebar.pdf", "3510.00", "CURRENT_PRICE_REPORT", (1,))[1]
    finally:
        _TEXT_LINES.clear(); _TEXT_LINES.update(saved_lines)
        globals()["_native_near_label"] = saved_native
    assert PRIOR.near_label is near_label
    print("[PASS] v0112: price labels read a second way when the character-box reader says no — same-line label only (MS-6669 3510 / MS-3661 3190 sidebars PASS · swapped target / price stays FAIL · '18% upside' and 'NT$730 price target' prose)")
    return result


if __name__ == "__main__":
    if sys.argv[1:2] == ["--shard"]:
        od, pdfdir, selection, target = sys.argv[2:6]
        vb, vf, vs = run_files(od, pdfdir, json.loads(Path(selection).read_text(encoding="utf-8")))
        Path(target).write_text(json.dumps({"basic": vb, "fin": vf, "summary": vs}, ensure_ascii=False), encoding="utf-8")
        raise SystemExit(0)
    if sys.argv[1:2] == ["--selftest"]:
        raise SystemExit(selftest())
    arguments = sys.argv[1:]
    ui = arguments[arguments.index("--ui") + 1] if "--ui" in arguments else None
    positional = [item for i, item in enumerate(arguments) if item != "--ui" and not (i > 0 and arguments[i-1] == "--ui")]
    raise SystemExit(main(*positional[:3], ui=ui))
