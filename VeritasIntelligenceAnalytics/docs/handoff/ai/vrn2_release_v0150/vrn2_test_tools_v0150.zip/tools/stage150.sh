#!/bin/bash
# v0150 放進倉:docs/handoff/ai/vrn2_release_v0150/ + vrn1_vrn2_oneclick_v0111/(固定時間戳 · 冪等)· 新成員只在私有 runtime zip 與 test tools zip
W=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v150
REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
D=$REPO/vrn2_release_v0150; OP=$REPO/vrn1_vrn2_oneclick_v0111; mkdir -p $D $OP
python3 - <<'PY'
import zipfile, pathlib, re, shutil
W = pathlib.Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v150")
D = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0150"); OP = pathlib.Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0111")
def z(target, files):
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for arc, p in files:
            if not p.exists(): continue
            data = p.read_bytes()
            if p.suffix in (".log", ".txt", ".rc"): data = re.sub(rb"\x1b\[[0-9;]*m", b"", data)
            zi = zipfile.ZipInfo(arc, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zf.writestr(zi, data)
logs = [(n, W / n) for n in ("ra150_first.log", "ra150_fix.log", "ra150.rc", "t150_setup.log", "mk_market150.log", "pscheck150.log", "scen150.rc", "scen150_first.log", "scen150_again.log", "scen150_tamper.log", "scen150_setup.log")]
logs += [(n, W / n) for n in ("ActivateVRN-2_v0150_selftest.log", "ActivateVRN-2_v0150_selftest_iso.log", "roundall103_selftest.log", "iv112_selftest.log", "cj102_selftest.log",
                                 "regress150.log", "repro_ms3661_150.log", "evidence_ms3661_150.log", "run_roundall150.sh", "scen150.sh", "drive150.sh")]
logs += [("release/oneline_roundall_pwsh.txt", W / "release150" / "oneline_roundall_pwsh.txt"), ("release/oneline_roundall.txt", W / "release150" / "oneline_roundall.txt"), ("release/boot_roundall.ps1", W / "release150" / "boot_roundall.ps1")]
v2 = W / "t150/VIA/VIA_Reports/vrn2"
for n in ("VRN2_Closeout_v0150.json", "VRN2_Closeout_v0150.before_roundall.json", "VRN2_RoundAll_latest.json", "IDEMPOTENCE_latest.json", "VRN2_VerbatimVerify_latest.json", "VRN2_Completion_latest.json", "VRN2_OutputStore_latest.json", "VRN2_Output_Config.json", "VRN2_Phase_Timing_latest.json", "VRN2_HistoryAlign_latest.json", "VRN2_Integrate_latest.json", "consensus/VRN2_Consensus_latest.json", "consensus/factset_yfinance_consensus_quality_matrix.csv", "market/VRN2_Market_latest.json", "output/VRN2_Combined_latest.csv", "output/VRN2_FinancialAligned_latest.csv", "output/VRN2_Deleted_latest.csv", "VRN2_Workbench_latest.html", "VRN2_FailEvidence_latest.json"):
    logs.append(("t150/" + n, v2 / n))
z(D / "logs_v0150.zip", logs)
tools = [("tools/" + q.name, q) for q in sorted(W.glob("*.py")) + sorted(W.glob("*.sh")) + sorted(W.glob("*.ps1"))] + [("release/" + q.name, q) for q in (W / "release150" / "boot_roundall.ps1", W / "release150" / "oneline_roundall.txt", W / "release150" / "oneline_roundall_pwsh.txt", W / "release150" / "Run-VRN2-v0150.ps1", W / "release150" / "boot150.ps1")]
tools += [("new/" + q.name, q) for q in sorted((W / "new").glob("*.py")) if q.name in ("VRN2_IndependentVerifier_v0112.py", "VRN2_ConsensusJoin_v0102.py", "ActivateVRN-2_v0150.py", "VRN2_RoundAll_v0103.py")]
z(D / "vrn2_test_tools_v0150.zip", tools)
z(OP / "tools_v0111.zip", [("tools/" + q.name, q) for q in (W / "operator111" / "boot_pair111.ps1", W / "operator111" / "oneline_pair111.txt", W / "operator111" / "Run-VRN1-VRN2-v0111.ps1")])
for n in ("VRN1_VRN2_OneClick_v0111.md", "VRN1_VRN2_Verification_v0111.md"): shutil.copy(W / "operator111" / n, OP / n)
for n in ("VRN2_Closeout_v0150.zip", "VRN2_Release_v0150.json", "VRN2_OneClick_v0150.md", "VRN2_Verification_v0150.md", "VRN2_RoundAll_v0103.py", "VRN2_RoundAll_v0103.md"): shutil.copy(W / "release150" / n, D / n)
print("staged")
PY
ls -la --time-style=+%H:%M $D $OP | awk '{print $5, $7}'
