"""ActivateVRN-2_v0150.py = v0149 + ConsensusJoin v0102 · ⑪ IndependentVerifier v0112(runtime 最新)· ⑥e 標籤寫清楚(桌機 2026-10-29 19:00 RoundAll v0102 貼回)。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v149/new/ActivateVRN-2_v0149.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0149: v0148 entry + fixes from the desktop run of VRN2_RoundAll_v0101 (2026-10-29 17:01 · red 4 · yellow 11).',
    '"""VRN-2 v0150: v0149 entry + fixes from the desktop run of VRN2_RoundAll_v0102 (2026-10-29 19:00 · red 0 · yellow 20 · 5957 s).\n\n'
    ' - step 11 VRN2_IndependentVerifier_v0112 (latest in the runtime): MS-6669 3510.00 / MS-3661 3190.00 CURRENT_PRICE FAILs were the character-box\n'
    '   reader missing / mispairing the key-data sidebar on the desktop (the book values equal the source lines "Shr price, close (...) NT$3,510.00"\n'
    '   / "... NT$3,190.00"); when it says no, the page is read a second way and only the same-line label counts (swaps stay FAIL).\n'
    ' - step 6f VRN2_ConsensusJoin_v0102: the engine gate FAIL_CLOSED came only from 6933 / 4171 "statusCode=404 頁面或商品不存在" (cnyes has no\n'
    '   FactSet page for them); those codes are left out and the same engine runs again (resume) so the gate judges the covered codes.\n'
    ' - step 6e detail names the fetch Python and whether it met the VDF bounds ("Python 本行程" made RoundAll v0102 fetch everything a second\n'
    '   time, ~35 min).\n'
    ' Runtime v0150 = runtime v0149 (184 members byte-identical) + VRN2_IndependentVerifier_v0112 + VRN2_ConsensusJoin_v0102.\n\n'
    'v0149: v0148 entry + fixes from the desktop run of VRN2_RoundAll_v0101 (2026-10-29 17:01 · red 4 · yellow 11).')
rep('VERSION = "ActivateVRN-2 v0149"', 'VERSION = "ActivateVRN-2 v0150"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0149.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0150.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0149.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0150.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0149.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0150.json"')
rep('CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0101.py"   # v0148: thin tail over v0100 (TPEx → .TWO from the market book)',
    'CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0102.py"   # v0150: thin tail over v0101 (no-FactSet-page 404 codes left out of the gate) · v0101: TPEx → .TWO')
rep('''        for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0100.py"):''',
    '''        for name in (HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", DATA_INTEGRATE, "VRN2_DataIntegrate_v0100.py", CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"):''')
rep('''        for name in (CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0100.py", HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", UI_HANDLER, "VRN2_UIAction_v0109.py", "VRN2_UIAction_v0108.py"):''',
    '''        for name in (CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py", HISTORY_ALIGN, "VRN2_HistoryAlign_v0101.py", "VRN2_HistoryAlign_v0100.py", UI_HANDLER, "VRN2_UIAction_v0109.py", "VRN2_UIAction_v0108.py"):''')
rep('''        assert cj.VERSION == "v0101" and cj.ticker_map(output) == {"5274": "5274.TWO", "2330": "2330.TW"}''',
    '''        assert cj.VERSION == "v0102" and cj.PRIOR.VERSION == "v0101" and cj.ticker_map(output) == {"5274": "5274.TWO", "2330": "2330.TW"}''')
rep('launcher = root / "package" / "ActivateVRN-2_v0149.py"', 'launcher = root / "package" / "ActivateVRN-2_v0150.py"')
rep('return lamp, detail + " · launcher v0149"', 'return lamp, detail + " · launcher v0150"')
rep('print("NEXT: [%s] VRN-2 v0149 · rc %s', 'print("NEXT: [%s] VRN-2 v0150 · rc %s')
# ⑥e label: say which Python and whether it met the VDF bounds (RoundAll v0102 read "Python 本行程" as "the wrong Python")
rep('''        py_label = Path(fetch_py).parent.parent.name if fetch_py != sys.executable else "本行程"
        if runner.is_file() and not picked.get("python"):''', '''        py_label = Path(fetch_py).parent.parent.name if fetch_py != sys.executable else "本行程"
        if picked.get("python"):
            py_label = "%s(合 VDF 界線 · %s)" % (picked["python"], picked.get("requirements_from") or "VDF 引擎")
        elif runner.is_file():''')
# v0150 selftest block (before the v0149 PASS line)
rep('''    print("[PASS] v0149: VerbatimVerifier v0105 (line-end hyphen · U+FFFE)''', r'''    with tempfile.TemporaryDirectory(prefix="vrn2-v0150-check-") as temporary:
        runtime = Path(temporary) / "VIA" / "functional modules" / PRIVATE_FOLDER
        runtime.mkdir(parents=True)
        for name in (CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"):
            shutil.copy2(str(selftest_source(name)), str(runtime / name))
        cj = _load_runtime_module(runtime, CONSENSUS_JOIN, "vrn2_consensus_join_v0150_check")
        rows = [{"code": c, "check_id": "FETCH_PIPELINE", "actual": "TARGET_PRICE_STATUS_NOT_200: statusCode=404 message=頁面或商品不存在", "status": "FAIL"} for c in ("6933", "4171")]
        assert cj.VERSION == "v0102" and sorted(cj.no_coverage(rows, ["2330", "6933", "4171"])) == ["4171", "6933"]
        assert cj.no_coverage(rows + [{"code": "2330", "check_id": "HTTP_PAGE_200", "actual": "500", "status": "FAIL"}], ["2330", "6933", "4171"]) == {}
        assert cj.PRIOR.run is cj.run and cj.PRIOR.PRIOR.run is cj.run
    body = Path(__file__).read_text(encoding="utf-8")
    assert '"%s(合 VDF 界線 · %s)" % (picked["python"]' in body
    print("[PASS] v0150: ConsensusJoin v0102 (no-FactSet-page 404 codes left out of the gate · other FAILs keep FAIL_CLOSED) · ⑥e detail names the fetch Python + VDF bounds")
    print("[PASS] v0149: VerbatimVerifier v0105 (line-end hyphen · U+FFFE)''')
(S / "v150/new").mkdir(parents=True, exist_ok=True)
(S / "v150/new/ActivateVRN-2_v0150.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0150 lines", s.count("\n"))
