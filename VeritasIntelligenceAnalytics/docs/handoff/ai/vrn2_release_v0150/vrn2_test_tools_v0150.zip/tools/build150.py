"""v0150 整包重建(冪等):pkg150 → 套件 zip → VRN2_RoundAll_v0103.py(填套件雜湊)+ 一行啟動(pwsh / powershell / cmd)md → 發行清單 → 一鍵 v0150 md → 操作員 v0111 md → 本地實測一輪改指。"""
import base64, hashlib, json, re, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); out, rel, op11, new = S / "v150/pkg150", S / "v150/release150", S / "v150/operator111", S / "v150/new"
rel.mkdir(exist_ok=True); op11.mkdir(exist_ok=True)
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
rt = json.loads((out / "VRN2_Runtime_v0150.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN2_IndependentVerifier_v0112.py", "VRN2_ConsensusJoin_v0102.py"]
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0150.py", "VRN2_Runtime_v0150.zip", "VRN2_Runtime_v0150.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0150 — VRN-2 closeout package (2026-10-29)\n\nEntry: python ActivateVRN-2_v0150.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0103.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.\n"
  "Runtime: VRN2_Runtime_v0150.zip = runtime v0149 (184 members byte-identical) + VRN2_IndependentVerifier_v0112 + VRN2_ConsensusJoin_v0102,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0150 (desktop run of VRN2_RoundAll_v0102 · 2026-10-29 19:00 · red 0 · yellow 20 · 5957 s):\n"
  " - step 11 IndependentVerifier v0112: MS-6669 / MS-3661 CURRENT_PRICE FAILs were the character-box reader missing / mispairing the key-data sidebar;\n"
  "   when it says no, the page is read a second way and only the same-line label counts (swapped target / price stays FAIL).\n"
  " - step 6f ConsensusJoin v0102: gate FAIL_CLOSED came only from 6933 / 4171 (cnyes 404, no FactSet page); those are left out and the engine runs again.\n"
  " - step 6e detail names the fetch Python (RoundAll v0102 read 'Python 本行程' as the wrong Python and fetched everything twice).\n"
  "Verification: see VRN2_Verification_v0150.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0150.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0150", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0150.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0150/" + n, date_time=(2026, 10, 29, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll v0103 =====
ra_src = (new / "VRN2_RoundAll_v0103.py").read_text(encoding="utf-8")
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0103.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
boot0 = (S / "v149/release149/boot_roundall.ps1").read_text(encoding="utf-8")
ra_boot = boot0.replace("vrn2_release_v0149", "vrn2_release_v0150").replace("VRN2_RoundAll_v0102.py", "VRN2_RoundAll_v0103.py")
ra_boot = re.sub(r"\$H  = '[0-9a-f]{64}'", "$H  = '%s'" % ra_sha, ra_boot, count=1)
assert ra_sha in ra_boot and "v0149" not in ra_boot and "v0102" not in ra_boot and "$ProgressPreference" in ra_boot
enc = base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii")
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_one) < 8191
ra_pwsh = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_pwsh) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8"); (rel / "oneline_roundall_pwsh.txt").write_text(ra_pwsh + "\n", encoding="utf-8")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0103.py(一個指令:取套件 → 診斷 → 全部自測 → 跑 → 自動修 → 除錯報告 → 貼回包)

`VRN2_RoundAll_v0103.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪;套件 = `VRN2_Closeout_v0150.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。
v0103 = v0102 + 桌機 2026-10-29 19:00 跑 v0102 的貼回修正(紅 0 · 黃 20 · 5957 秒 · rc 2;3014TT 第 3 點 · SyntaxWarning · ⑥e 選錯 Python 這三個上一輪的問題都已經沒了):

| 桌機看到的 | 根因 | v0150 / v0103 怎麼修 |
|---|---|---|
| ⑪ MS-6669 現價 3510.00 FAIL「在目標價標籤旁」· MS-3661 現價 3190.00 FAIL「前 4 頁沒有這個數」 | v0102 印的證據:冊值就等於原文「Shr price, close (Oct 7, 2025) NT$3,510.00」「Shr price, close (Dec 3, 2025) NT$3,190.00」→ 是**驗證器誤判**:字元框讀法在桌機的函式庫版本把 MS 的側欄漏讀 / 配錯(同一份 MS-3661 在容器是 PASS) | **IndependentVerifier v0112**:字元框說不對時,換第二種讀法(PDFium 整頁文字 + pdfplumber 文字行),只看**同一列**數字前面最近的標籤(或緊接著的「% upside」「price target」);目標價 / 現價對調照樣 FAIL(容器變造測試 12 / 12 抓到) |
| ⑥f gate FAIL_CLOSED(共識 41 / 43) | 品質矩陣只有兩列不過:6933 / 4171「statusCode=404 頁面或商品不存在」—— 鉅亨根本沒有這兩檔的 FactSet 頁(新上市 / 未評等),不是抓失敗 | **ConsensusJoin v0102**:不過的列全是 404 頁面不存在 → 這幾檔不納入,同一個引擎再跑一次(續跑 · 秒級)→ 閘只評有覆蓋的;Combined STATUS 寫「鉅亨沒有 FactSet 頁(404)」。有別的不過列 → 照 FAIL_CLOSED |
| 總 5957 秒,其中 ⑤ 又把 ⑥e 整輪重抓一次(約 35 分鐘 · 結果一樣) | 啟動器 v0149 的 ⑥e 明細寫「Python 本行程」(本行程就是合 VDF 界線的那個),v0102 當成「用錯 Python」 | 啟動器 v0150 明細寫出 Python 路徑 + 「合 VDF 界線」;**RoundAll v0103** 看到 ⑥e 已經經 MarketFetchRun 跑過就不重抓 |
| ⑥e 擷取 RED:財報 4 次失敗 · `PermissionError: Existing VIA network bridge denied this request` · ⑬b 無歷史 44 | VDF 引擎打 MOPS(公開資訊觀測站)財報時,VIA 鎖版網路工具的合規層回 DENY;VDF / VRN-2 照規則不繞道 | **沒改**(VRN-2 不繞過 VIA 網路工具)· ⑥ 現在印清楚是這個原因 → 要不要放行 mops.twse.com.tw 是 VCGC 的決定;價格 / 還原價不受影響 |
| ⑪ 證據:MS-8358 / MS-8210 只看到電話號碼那幾行 | v0102 用「字串包含」比對(730 對到 2730-2869 · 38 對到 4388) | v0103 逐值、數字相等才算、跳過 Email / 電話行;每個冊值各列原文那幾行或「前 4 頁沒有這個數」 |

## 一個指令(PowerShell 7.6.9 / cmd 都能貼 · 建議)

```bat
@PWSH@
```

沒有 PowerShell 7(`pwsh`)時用這一行(Windows PowerShell 5.1 · 內容一樣):

```bat
@ONE@
```

它從 GitHub 分支 `claude/optimistic-goodall-yhalc5`(讀不到 → `main`)取 `VRN2_RoundAll_v0103.py` → **核對 SHA-256**(`@RASHA12@`)→ 存到 `Downloads` → 用你的 python 執行 → 跑完印總表、`NEXT:` 與貼回包位置。
VIA 根不在 `C:\\Users\\tonyk\\OneDrive\\Documents\\movies-dataset\\VeritasIntelligenceAnalytics` 就先設(cmd:`set VRN2_ROOT=…` · PowerShell:`$env:VRN2_ROOT='…'`)。

## 已經有這個檔時

```bat
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0103.py"
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0103.py" --skip-run --integrate yes
python "%USERPROFILE%\\Downloads\\VRN2_RoundAll_v0103.py" --only preflight,selftest
```

PowerShell 把 `%USERPROFILE%` 換成 `$env:USERPROFILE`。常用參數:`--source <報告夾>` · `--integrate ask|yes|no|skip` · `--no-open` · `--ship` · `--offline` · `--python <VRN-2 的 python>` · `--skip-selftest` · `--selftest`。

## 程式碼決定不了的

- ⑥e MOPS 財報:VIA 鎖版網路工具的合規層拒絕 → 交 VCGC 決定(VRN-2 / VDF 不繞)。在那之前 ⑬b 會是「無歷史」(灰),價格與還原價照常。
- ⑪ MS-8358 現價 510.00 / MS-8210 上漲空間 18:看 `⑪ 基本資料 FAIL 證據` 那幾行(v0103 逐值印原文)—— 原文前 4 頁沒有這個數 = 擷取取錯 / 推算;有 = 貼給 AI 判。

## 一行解開來的程式碼(核對用 · 兩行解開都是這段)

```text
@BOOT@
```
"""
ra_md = ra_md.replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PWSH@", ra_pwsh).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
for kind, b64 in re.findall(r"(?s)```bat\n(pwsh|powershell) -NoProfile -ExecutionPolicy Bypass -EncodedCommand (\S+)\n```", ra_md):
    assert base64.b64decode(b64).decode("utf-16-le") == ra_boot
assert len(re.findall(r"EncodedCommand", ra_md)) == 2
(rel / "VRN2_RoundAll_v0103.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0150 + VRN2_RoundAll_v0103", "date": "2026-10-29",
        "trigger": "桌機 2026-10-29 19:00 跑 VRN2_RoundAll_v0102(52 份 · 5957 秒 · 紅 0 黃 20 · rc 2)→ 能在容器重現 / 驗證的修成 v0150(見 fixes)",
        "base_package": {"name": "VRN2_Closeout_v0149 (launcher v0149 · runtime v0149)", "retained": "runtime v0149 members byte-identical inside runtime v0150; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0149 for the closeout entry; VRN2_RoundAll v0102 → v0103; VRN-2 one-click v0149 → v0150; operator one-click v0110 → v0111",
        "desktop_confirmed_fixed": {"3014TT_POINT_3": "四點原文核對 REVIEW_OCR {PASS 204, OCR_PENDING 4} · FAIL 0 (VerbatimVerifier v0105)", "SyntaxWarning": "gone (RoundAll v0102)",
                                    "6e_python": "C:\\Python313 passes the VDF bounds and the engine ran (MarketFetchRun v0100)"},
        "fixes": {"IndependentVerifier_v0112": "MS-6669 3510.00 / MS-3661 3190.00 CURRENT_PRICE FAILs: book = source line ('Shr price, close (...) NT$3,510.00'), the character-box reader missed / mispaired the sidebar on the desktop; second reading (PDFium whole-page text + pdfplumber lines), same-line label only; container regression 193 PASS unchanged; swap mutation 12 / 12 still FAIL",
                  "ConsensusJoin_v0102": "gate FAIL_CLOSED only from 6933 / 4171 'statusCode=404 頁面或商品不存在' (no FactSet page on cnyes) → those codes left out and the same engine re-run (resume); any other FAIL row keeps FAIL_CLOSED; Combined STATUS notes the 404",
                  "launcher_v0150_6e_label": "6e detail names the fetch Python and 'meets VDF bounds' instead of 'Python 本行程'",
                  "RoundAll_v0103_no_refetch": "no 6e re-fetch when the launcher already ran MarketFetchRun (v0102 re-fetched everything, ~35 min, same result)",
                  "RoundAll_v0103_evidence": "per-value evidence, numbers must be equal (not substring: 38 ≠ 4388, 730 ≠ 2730-2869), contact lines skipped",
                  "RoundAll_v0103_mops_deny": "explains 'Existing VIA network bridge denied this request' = VIA locked network tool compliance DENY for MOPS financials → no history → 13b GRAY; VCGC decision"},
        "not_fixed_here": {"MOPS_DENY": "VDF financial fetch through the VIA network bridge is denied by its compliance layer (DENY is never bypassed by VDF / VRN-2) → 13b history stays empty until VCGC allows mops.twse.com.tw",
                           "MS_8358_8210": "MS-8358 CURRENT_PRICE 510.00 and MS-8210 UPSIDE 18: v0102 evidence showed only contact lines; v0103 prints per-value source lines next run",
                           "annual_fail_1": "260914_daiwa_aspeed.pdf PBR 26E 'n.a.' cell the verifier cannot locate (not in the container samples)",
                           "6e_duration": "VDF engine re-fetches every price window each round by operator rule (~30 min on the desktop); not changed"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0150.json inside the package"},
        "roundall": {"name": "VRN2_RoundAll_v0103.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0103.md"},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · 19 real sample files", "results": {"status": "see VRN2_Verification_v0150.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0150/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0150.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0150.py"]).hexdigest()},
        "oneclick": "VRN2_OneClick_v0150.md", "test_tools_zip": "vrn2_test_tools_v0150.zip", "logs_zip": "logs_v0150.zip"}
(rel / "VRN2_Release_v0150.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
# ===== one-click v0150 from v0149 =====
md = (REPO / "vrn2_release_v0149/VRN2_OneClick_v0149.md").read_text(encoding="utf-8")
ps = re.search(r"(?s)```powershell\n(.*?)\n```", md).group(1); boot = re.search(r"(?s)```text\n(.*?)\n```", md).group(1)
old_want = re.search(r"\$Want   = '([0-9a-f]{64})'", ps).group(1); old_cs = hashlib.sha256(ps.encode("utf-8")).hexdigest(); assert old_cs in boot
HEAD9 = "  # ===== VRN-2 一鍵 v0149(套件 v0149 = 啟動器 v0149 + runtime v0149 = v0148 + VerbatimVerifier v0105 + IndependentVerifier v0111 + MarketFetchRun v0100;"
BAN9 = "[計] VRN-2 一鍵 v0149 · ActivateVRN-2 v0149(套件 · 私有 runtime v0149 = v0148 + "
outl, nh, nb = [], 0, 0
for line in ps.split("\n"):
    if line.startswith(HEAD9):
        nh += 1
        line = ("  # ===== VRN-2 一鍵 v0150(套件 v0150 = 啟動器 v0150 + runtime v0150 = v0149 + IndependentVerifier v0112 + ConsensusJoin v0102;v0150 = 桌機 2026-10-29 19:00 跑 VRN2_RoundAll_v0102 的貼回修正:"
                "⑪ 價格標籤第二種讀法(MS-6669 / MS-3661 誤判)· ⑥f 鉅亨沒有 FactSet 頁的代號不納閘 · ⑥e 明細寫清楚 Python · 另一支 Python 升 VRN2_RoundAll_v0103;"
                "v0149 = 套件 v0149 = 啟動器 v0149 + runtime v0149 = v0148 + VerbatimVerifier v0105 + IndependentVerifier v0111 + MarketFetchRun v0100;" + line[len(HEAD9):])
    elif BAN9 in line:
        nb += 1
        i = line.index(BAN9)
        line = line[:i] + "[計] VRN-2 一鍵 v0150 · ActivateVRN-2 v0150(套件 · 私有 runtime v0150 = v0149 + IndependentVerifier v0112(價格標籤第二種讀法)· ConsensusJoin v0102(404 無覆蓋不納閘);另一支 Python VRN2_RoundAll_v0103.py;v0149 = v0148 + " + line[i + len(BAN9):].replace("另一支 Python VRN2_RoundAll_v0102.py;", "")
    else:
        line = line.replace("VRN2_Handover_v0150.md", "VRN2_Handover_v0151.md").replace("v0149", "v0150").replace("VRN2_RoundAll_v0102", "VRN2_RoundAll_v0103")
    outl.append(line)
assert nh == 1 and nb == 1, (nh, nb)
ps = "\n".join(outl)
ps = re.sub(r"\$Want   = '[0-9a-f]{64}'   # VRN2_Closeout_v0150\.zip SHA-256[^\n]*", lambda m: "$Want   = '%s'   # VRN2_Closeout_v0150.zip SHA-256(套件 · 內含啟動器 v0150 + runtime v0150 清單 = v0149 + IndependentVerifier v0112 · ConsensusJoin v0102)" % want, ps, count=1)
assert want in ps and old_want not in ps
for line in ps.splitlines():
    code = line.split("#", 1)[0]
    assert not ("v0149" in code and "v0149 =" not in code), line[:200]
assert "VRN2_UIAction_v0110\\.py" in ps and "VRN2_RoundAll_v0103.py" in ps
cs = hashlib.sha256(ps.encode("utf-8")).hexdigest()
boot = boot.replace(old_cs, cs).replace("vrn2_release_v0149", "vrn2_release_v0150").replace("VRN2_OneClick_v0149.md", "VRN2_OneClick_v0150.md").replace("v0149", "v0150") + "\n"
one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot.encode("utf-16-le")).decode("ascii"); assert len(one) < 8191
head = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", md, count=1)
head = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", head, count=1)
head = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", head, count=1)
head = head.replace(old_want, "@WANT@").replace(old_cs, "@CS@").replace(old_cs[:12], "@CS@")


def hrep(a, b):
    global head
    assert head.count(a) == 1, (head.count(a), a[:80]); head = head.replace(a, b)


def hline(prefix, b):
    global head
    ls = head.split("\n"); idx = [i for i, l in enumerate(ls) if l.startswith(prefix)]; assert len(idx) == 1, (prefix, idx); ls[idx[0]] = b; head = "\n".join(ls)


hline("# VRN-2 一鍵 v0149(", "# VRN-2 一鍵 v0150(cmd / PowerShell 都能貼 · 套件 v0150 = 啟動器 v0150 + runtime v0150 = v0149 + IndependentVerifier v0112 · ConsensusJoin v0102)")
hrep("v0149 = v0148 入口 + runtime v0149(= runtime v0148 的 181 個成員逐位元保留 + 3 個新檔):",
     "桌機 2026-10-29 19:00 跑 `VRN2_RoundAll_v0102.py`(52 份 · 5957 秒 · 紅 0 · 黃 20)→ 能在容器重現 / 驗證的修成 v0150;另一支 Python 升 **`VRN2_RoundAll_v0103.py`**(同發行夾 · 一個指令:`VRN2_RoundAll_v0103.md` 的 pwsh 那一行)。\n\n"
     "v0150 = v0149 入口 + runtime v0150(= runtime v0149 的 184 個成員逐位元保留 + 2 個新檔):\n\n| 元件 | 版本 | 修了什麼 |\n|---|---|---|\n"
     "| ⑪ 獨立驗證 | VRN2_IndependentVerifier v0112(v0111 留著)| 價格標籤:字元框讀法說不對時,換第二種讀法只看同一列的標籤 —— MS-6669 3510 / MS-3661 3190 是誤判(冊值 = 原文那行);對調照樣 FAIL |\n"
     "| ⑥f 共識合併 | VRN2_ConsensusJoin v0102(v0101 / v0100 與共識引擎都不動)| 品質閘 FAIL_CLOSED 只因鉅亨沒有 FactSet 頁(404 · 6933 / 4171)→ 這幾檔不納入、同一個引擎再跑一次;別的不過照 FAIL_CLOSED |\n"
     "| 啟動器 | ActivateVRN-2 v0150 | 指向 ConsensusJoin v0102 · ⑥e 明細寫出擷取 Python 與「合 VDF 界線」· 收據 `VRN2_Closeout_v0150.json` · 自測多一段 v0150 |\n\n"
     "前一版 v0149 = v0148 入口 + runtime v0149(= runtime v0148 的 181 個成員逐位元保留 + 3 個新檔):")
hrep("| 啟動器 | ActivateVRN-2 v0149 |", "| 啟動器(v0149)| ActivateVRN-2 v0149 |")
hrep("| 步驟 | v0149 做什麼 |", "| 步驟 | v0150 做什麼 |")
hrep("| ① ② ③ ③b | 同 v0148(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|", "| ① ② ③ ③b | 同 v0149(套件雜湊 + 逐檔核對 → 解壓 → 定位 VRN-2 程式夾)|")
hline("| ④ | `python ActivateVRN-2_v0149.py", "| ④ | `python ActivateVRN-2_v0150.py [--source …]`:單機閘 → ①~⑤ → ⑤b SSOT-ID 核號同步 → ⑥ → ⑦(管理器 v0255)→ ⑥e 市場擷取(MarketFetchRun:合 VDF 界線的 Python)→ ⑥f 共識合併(上櫃 .TWO · 404 無覆蓋不納閘 · Combined 冊)→ ⑧~⑫(⑪ 驗證器 v0112)→ ⑫b 補放 → 四點原文核對(v0105)→ 收據 → ⑬b 歷史對齊 → ⑬ 長線 Parquet 庫 → ⑬c 舊資料庫整合掃描 → Workbench v0102 |")
hline("| ⑤ | 摘要多七行", "| ⑤ | 摘要多七行:⑬ 輸出位置 / 增量庫 · ⑤b SSOT-ID · 階段耗時 · ⑥e 市場擷取 · ⑥f 共識合併 · ⑬b 歷史對齊 · ⑬c 舊資料庫整合(都讀 `VRN2_Closeout_v0150.json`)+ 一行指向 `VRN2_RoundAll_v0103.py` |")
hline("| ⑤b ⑤c |", "| ⑤b ⑤c | vrn2:// 處理器 = `functional modules\\\\VRN2\\\\VRN2_UIAction_v0110.py`(設定檔 v0150 · `vrn2://integrate` 取最新的 DataIntegrate = v0101)· U/I 有輸入區塊 · 沒開就代開 |")
for a, b in (("VRN2_OneClick_v0149", "VRN2_OneClick_v0150"), ("套件 `VRN2_Closeout_v0149.zip`", "套件 `VRN2_Closeout_v0150.zip`"), ("從 `vrn2_release_v0149` 取", "從 `vrn2_release_v0150` 取"), ("Downloads\\VRN2_Closeout_v0149`", "Downloads\\VRN2_Closeout_v0150`")):
    head = head.replace(a, b)
newmd = head.replace("@WANT@", want).replace("@CS@", cs[:12]).replace("@ONE@", one).replace("@PS@", ps).replace("@BOOT@", boot.rstrip("\n"))
assert re.search(r"(?s)```powershell\n(.*?)\n```", newmd).group(1) == ps and "@" + "WANT@" not in newmd and cs in boot
(rel / "VRN2_OneClick_v0150.md").write_text(newmd, encoding="utf-8", newline="\n"); (rel / "boot150.ps1").write_text(boot, encoding="utf-8", newline="\n"); (rel / "oneline150.txt").write_text(one + "\n", encoding="utf-8"); (rel / "Run-VRN2-v0150.ps1").write_text(ps + "\n", encoding="utf-8", newline="\n"); (rel / "code_sha.txt").write_text(cs)
print("one-click v0150", cs[:12])
# ===== operator v0111 from v0110 =====
md10 = (REPO / "vrn1_vrn2_oneclick_v0110/VRN1_VRN2_OneClick_v0110.md").read_text(encoding="utf-8")
p10 = re.search(r"(?s)```powershell\n(.*?)\n```", md10).group(1); boot10 = re.search(r"(?s)```text\n(.*?)\n```", md10).group(1)
cs10_old = hashlib.sha256(p10.encode("utf-8")).hexdigest(); assert cs10_old in boot10
p11 = p10


def rep11(a, b):
    global p11
    assert p11.count(a) == 1, (p11.count(a), a[:80]); p11 = p11.replace(a, b)


rep11("  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0149'", "  $P2 = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0150'")
old_h2 = re.search(r"\$H2 = '([0-9a-f]{64})'   # VRN-2 一鍵 v0149 程式碼 SHA-256", p11).group(1); assert old_h2 == old_cs
rep11("  $H2 = '%s'   # VRN-2 一鍵 v0149 程式碼 SHA-256" % old_h2, "  $H2 = '%s'   # VRN-2 一鍵 v0150 程式碼 SHA-256" % cs)
rep11("  # ===== VRN-1 / VRN-2 操作員一鍵 v0110(2026-10-29 · ② 改指 VRN-2 一鍵 v0149:",
      "  # ===== VRN-1 / VRN-2 操作員一鍵 v0111(2026-10-29 · ② 改指 VRN-2 一鍵 v0150:⑪ 價格標籤第二種讀法 · ⑥f 404 無覆蓋不納閘;另一支 Python VRN2_RoundAll_v0103.py;v0110 · ② 改指 VRN-2 一鍵 v0149:")
rep11("操作員一鍵 v0110 · {0} · VRN-1 {1} · VIA {2}", "操作員一鍵 v0111 · {0} · VRN-1 {1} · VIA {2}")
outl = []
for line in p11.split("\n"):
    if "操作員一鍵 v0111(2026-10-29 · ② 改指 VRN-2 一鍵 v0150" not in line:
        line = line.replace("VRN2_OneClick_v0149.md", "VRN2_OneClick_v0150.md").replace("VRN-2 一鍵 v0149", "VRN-2 一鍵 v0150").replace("套件 v0149 = 啟動器 v0149 + runtime v0149", "套件 v0150 = 啟動器 v0150 + runtime v0150").replace("ActivateVRN-2_v0149 單機閘", "ActivateVRN-2_v0150 單機閘")
    outl.append(line)
p11 = "\n".join(outl)
for line in p11.splitlines():
    code = line.split("#", 1)[0]
    assert "v0149" not in code, line[:160]
cs11 = hashlib.sha256(p11.encode("utf-8")).hexdigest()
boot11 = boot10.replace(cs10_old, cs11).replace("vrn1_vrn2_oneclick_v0110", "vrn1_vrn2_oneclick_v0111").replace("VRN1_VRN2_OneClick_v0110.md", "VRN1_VRN2_OneClick_v0111.md").replace("操作員一鍵 v0110", "操作員一鍵 v0111") + "\n"
assert "v0110" not in boot11
one11 = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(boot11.encode("utf-16-le")).decode("ascii"); assert len(one11) < 8191
title10, rest10 = md10.split("\n\n", 1)
assert title10.startswith("# VRN-1 / VRN-2 操作員一鍵 v0110(")
rest = re.sub(r"(?s)```powershell\n.*?\n```", "```powershell\n@PS@\n```", rest10, count=1)
rest = re.sub(r"(?s)```text\n.*?\n```", "```text\n@BOOT@\n```", rest, count=1)
rest = re.sub(r"(?s)```bat\n.*?\n```", "```bat\n@ONE@\n```", rest, count=1)
rest = rest.replace(cs10_old, cs11).replace(cs10_old[:12], cs11[:12])
text = ("# VRN-1 / VRN-2 操作員一鍵 v0111(cmd / PowerShell 都能貼 · v0110 + ② 改指 VRN-2 一鍵 v0150:⑪ 價格標籤第二種讀法 · ⑥f 404 無覆蓋不納閘)\n\n"
        "桌機 2026-10-29 19:00 跑 `VRN2_RoundAll_v0102.py`(紅 0 · 黃 20)→ VRN-2 v0150 + `VRN2_RoundAll_v0103.py`(`vrn2_release_v0150` · 一個指令見 `VRN2_RoundAll_v0103.md` 的 pwsh 那行)。v0111 = v0110 + ② 改指 **VRN-2 一鍵 v0150**"
        "(套件 v0150 = 啟動器 v0150 + runtime v0150 = v0149 + IndependentVerifier v0112 · ConsensusJoin v0102);其餘一字不改。\n\n" + rest)
text = text.replace("@PS@", p11).replace("@BOOT@", boot11.rstrip("\n")).replace("@ONE@", one11)
assert re.search(r"(?s)```powershell\n(.*?)\n```", text).group(1) == p11 and base64.b64decode(re.search(r"(?s)```bat\n(.*?)\n```", text).group(1).split()[-1]).decode("utf-16-le") == boot11
(op11 / "VRN1_VRN2_OneClick_v0111.md").write_text(text, encoding="utf-8", newline="\n"); (op11 / "boot_pair111.ps1").write_text(boot11, encoding="utf-8", newline="\n"); (op11 / "oneline_pair111.txt").write_text(one11 + "\n", encoding="utf-8"); (op11 / "Run-VRN1-VRN2-v0111.ps1").write_text(p11 + "\n", encoding="utf-8", newline="\n"); (op11 / "code_sha.txt").write_text(cs11)
(op11 / "VRN1_VRN2_Verification_v0111.md").write_text(
    "# VRN-1 / VRN-2 操作員一鍵 v0111 · 容器驗證(2026-10-29)\n\nv0111 = v0110 的程式碼只改四處:② 發行夾 `vrn2_release_v0149` → `vrn2_release_v0150`、`$H2` → VRN-2 一鍵 v0150 程式碼 SHA-256(`%s`)、橫幅「操作員一鍵 v0110」→「v0111」、② 的步驟名 / 檔名 v0149 → v0150;歷史子句與 md 歷史段落照舊。\n\n"
    "| 檢查 | 結果 |\n|---|---|\n| pwsh 7.4.6 語法剖析(Run-VRN1-VRN2-v0111.ps1 · boot_pair111.ps1)| 見 `vrn2_release_v0150/logs_v0150.zip` 的 `pscheck150.log` |\n| 本段程式碼 SHA-256 = boot 裡的 `$H` | 同上 |\n| 一行(-EncodedCommand)解碼 = boot | 同上 |\n"
    "| `$H2` = `VRN2_OneClick_v0150.md` 程式碼 SHA-256 | 同上 |\n| 橫幅版號 | `操作員一鍵 v0111` |\n| 本地實測一輪 v0100 的 `$H_OP` = 本段程式碼 SHA-256 | 同上 |\n\n沒有 .ps1 進倉:一鍵程式碼只在本夾的 md 裡,`tools_v0111.zip` 是容器測試用副本。\n" % cs[:12], encoding="utf-8", newline="\n")
print("operator v0111", cs11[:12])
# ===== LocalRound re-point =====
lr = REPO / "VRN2_LocalRound_v0100.md"; s = lr.read_text(encoding="utf-8")
if "VRN1_VRN2_OneClick_v0111.md" in s:
    s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0111 程式碼 SHA-256", "$H_OP = '%s'   # 操作員一鍵 v0111 程式碼 SHA-256" % cs11, s, count=1); assert cs11 in s
    lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP refreshed", cs11[:12]); raise SystemExit(0)


def lrep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:80]); s = s.replace(a, b)


lrep("# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0149(開 Workbench)→ 打包貼回材料)", "# VRN-2 本地實測一輪 v0100(一段 PowerShell 貼上:logo → 補船 → 跑 v0150(開 Workbench)→ 打包貼回材料)")
lrep("> **2026-10-29 v0149 改指(", "> **2026-10-29 v0150 改指(桌機 19:00 跑 VRN2_RoundAll_v0102 的貼回):** 本段現在指 操作員一鍵 **v0111** → VRN-2 一鍵 **v0150**(⑪ 價格標籤第二種讀法 · ⑥f 鉅亨沒有 FactSet 頁的代號不納閘)。另一支 Python 升 **`vrn2_release_v0150/VRN2_RoundAll_v0103.py`**(不重抓 ⑥e · ⑪ 證據逐值 · MOPS 被拒的說明)。\n> **2026-10-29 v0149 改指(")
lrep("本段現在指 操作員一鍵 **v0110** → VRN-2 一鍵 **v0149**", "本段當時指 操作員一鍵 **v0110** → VRN-2 一鍵 **v0149**")
lrep("從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0110.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0149 套件**(啟動器 v0149 → ", "從 GitHub 讀操作員一鍵 `VRN1_VRN2_OneClick_v0111.md` 的程式碼(核對 SHA-256)→ 執行(預設只跑 VRN-2:**v0150 套件**(啟動器 v0150 → ⑪ 驗證器 v0112 · ⑥f ConsensusJoin v0102;v0149 的 ")
lrep("最後 300 行貼包 · `VRN2_Closeout_v0149.json` ·", "最後 300 行貼包 · `VRN2_Closeout_v0150.json` ·")
s = re.sub(r"\$H_OP = '[0-9a-f]{64}'   # 操作員一鍵 v0110 程式碼 SHA-256\(VRN1_VRN2_OneClick_v0110\.md powershell 區塊 · ② 指 VRN-2 一鍵 v0149\)", "$H_OP = '%s'   # 操作員一鍵 v0111 程式碼 SHA-256(VRN1_VRN2_OneClick_v0111.md powershell 區塊 · ② 指 VRN-2 一鍵 v0150)" % cs11, s, count=1); assert cs11 in s
lrep("  $k3 = '③ 跑 VRN-2 v0149'", "  $k3 = '③ 跑 VRN-2 v0150'")
lrep("  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0110' 'VRN1_VRN2_OneClick_v0110.md' $H_OP", "  $code = FetchCode 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn1_vrn2_oneclick_v0111' 'VRN1_VRN2_OneClick_v0111.md' $H_OP")
lrep("  foreach ($rel in 'VRN2_Closeout_v0149.json', 'VRN2_RoundAll_latest.json',", "  foreach ($rel in 'VRN2_Closeout_v0150.json', 'VRN2_RoundAll_latest.json',")
lr.write_text(s, encoding="utf-8", newline="\n"); print("localround H_OP", cs11[:12])
