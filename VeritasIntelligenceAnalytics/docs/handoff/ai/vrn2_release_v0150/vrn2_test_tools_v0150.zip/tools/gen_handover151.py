"""VRN2_Handover_v0151.md:從 v0150 只增不減。"""
import json
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v150")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0150.md").read_text(encoding="utf-8")
R = json.loads((S / "release150/VRN2_Release_v0150.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((S / "pkg150/VRN2_Runtime_v0150.json").read_text(encoding="utf-8"))["files"]}


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)


lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0149 + VRN2_RoundAll_v0102 · 2026-10-29(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0150 + VRN2_RoundAll_v0103 · 2026-10-29(v0149 + 本輪:桌機 19:00 跑 VRN2_RoundAll_v0102(52 份 · 5957 秒 · 紅 0 黃 20 · rc 2)的貼回 → "
            "IndependentVerifier v0112(價格標籤第二種讀法 · MS-6669 / MS-3661 誤判)· ConsensusJoin v0102(鉅亨沒有 FactSet 頁的 404 代號不納閘)· RoundAll v0103(不重抓 ⑥e · 證據逐值 · MOPS DENY 說明)· "
            "一鍵 v0150 · 操作員一鍵 v0111 · 本地實測一輪改指;runtime v0149 的 184 個成員一個位元組都不動 · +2 個新檔)")
src = "\n".join(lines)
old_round = "> **桌機貼回(2026-10-29 17:01 · 跑 VRN2_RoundAll_v0101"
assert src.count(old_round) == 1
e2e = res["roundall_e2e"]; fx = res.get("roundall_fix_pass") or {}
new_round = ("> **桌機貼回(2026-10-29 19:00 · 跑 VRN2_RoundAll_v0102 · 52 份 · 5957 秒 · 紅 0 黃 20 · rc 2)**:上一輪的三個問題都好了 —— 四點原文核對 FAIL 0(3014TT 第 3 點 PASS)· SyntaxWarning 沒了 · ⑥e 選到合 VDF 界線的 C:\\Python313 並真的跑了引擎。"
             "剩下:⑪ 基本資料 FAIL 4(MS-6669 / MS-3661 / MS-8358 現價 · MS-8210 上漲)· ⑥f gate FAIL_CLOSED(6933 / 4171 鉅亨 404)· ⑥e 財報 4 次 PermissionError「Existing VIA network bridge denied」→ ⑬b 無歷史 44 · RoundAll ⑤ 又把 ⑥e 重抓一輪(約 35 分鐘)· 年度 FAIL 1(daiwa aspeed n.a.)。\n"
             "> **本輪(v0150 · 套件 = 啟動器 v0150 + runtime v0150 = v0149 的 184 個成員不動 + IndependentVerifier v0112 + ConsensusJoin v0102 · 一支 Python `vrn2_release_v0150/VRN2_RoundAll_v0103.py` · 一鍵 v0150 · 操作員一鍵 v0111)**:"
             "① **IndependentVerifier v0112**(結構複本 · 分片子行程跑本檔):RoundAll v0102 印的證據顯示 MS-6669 / MS-3661 的冊值就等於原文「Shr price, close (…) NT$3,510.00 / 3,190.00」→ 驗證器誤判(字元框讀法在桌機的函式庫版本漏讀 / 配錯 MS 側欄;同一份 MS-3661 在容器 PASS)。"
             "字元框說不對時,換第二種讀法(PDFium 整頁文字 + pdfplumber 文字行)只看同一列數字前最近的標籤(或緊接著的「%% upside」「price target」);容器回歸 193 PASS 不變 · 目標價 ↔ 現價對調 12 / 12 照樣 FAIL · 真 MS-3661 模擬字元框漏讀 → PASS、對調 → FAIL。"
             "② **ConsensusJoin v0102**:品質矩陣不過的列全是「statusCode=404 頁面或商品不存在」(鉅亨沒有 FactSet 頁)→ 這幾檔不納入、同一個引擎再跑一次(續跑);有別的不過列照 FAIL_CLOSED;Combined STATUS 註記 404。"
             "③ **啟動器 v0150**:⑥e 明細寫出擷取 Python 與「合 VDF 界線」(不再寫「Python 本行程」)。"
             "④ **RoundAll v0103**:⑥e 經 MarketFetchRun 跑過就不重抓 · ⑪ 證據逐值(數字相等 · 跳過 Email / 電話行)· MOPS DENY 的說明 · 自測 23 項。"
             "⑤ **端到端(沙盒仿桌機 · pwsh 一行指令從假 GitHub 分支取 RoundAll v0103)**:%s;只修回合:%s。"
             "**沒修 / 要決定**:MOPS 財報被 VIA 鎖版網路工具的合規層拒絕(DENY · 不繞)→ 交 VCGC · MS-8358 / MS-8210 等 v0103 逐值證據 · daiwa aspeed 年度 1 格 · ⑥e 每輪重抓價格約 30 分鐘(操作員規則)。\n"
             % (e2e.get("summary", "見驗證紀錄"), fx.get("summary", "見驗證紀錄")))
src = src.replace(old_round, new_round + old_round, 1)
once("> **本輪(v0149 · 套件 = 啟動器 v0149 + runtime v0149", "> **前一輪(v0149 · 套件 = 啟動器 v0149 + runtime v0149")
anchor = "| **VRN2_RoundAll_v0102.py**(發行夾 · 一支入口 · 不在套件內)| **v0102** |"
assert src.count(anchor) == 1
rows = ("| **VRN2_RoundAll_v0103.py**(發行夾 · 一支入口 · 不在套件內)| **v0103** | `vrn2_release_v0150` | `%s` | **新**(套件 v0150 · 不重抓 ⑥e · ⑪ 證據逐值 · MOPS DENY 說明 · 自測 23 項)|\n"
        "| ActivateVRN-2_v0150.py(套件 · 底座 v0136)| **v0150** | 見發行清單 | `%s` | **新**(ConsensusJoin v0102 · ⑥e 明細寫出 Python · 收據 v0150 · 自測 8 段)|\n"
        "| **VRN2_IndependentVerifier** | **v0112**(結構複本 · v0111 留著)| runtime v0150 | `%s` | **新**(價格標籤第二種讀法 · 同列標籤 · 對調照 FAIL)|\n"
        "| **VRN2_ConsensusJoin** | **v0102**(薄尾 · v0101 / v0100 留著)| runtime v0150 | `%s` | **新**(404 無覆蓋代號不納閘 · 再跑一次 · 6 項)|\n") % (
    R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], rt["VRN2_IndependentVerifier_v0112.py"], rt["VRN2_ConsensusJoin_v0102.py"])
src = src.replace(anchor, rows + anchor, 1)
once("## 7. 本輪(v0148 → v0149 + VRN2_RoundAll_v0102 · 桌機 2026-10-29 17:01 跑 RoundAll v0101 的貼回 · 操作員「我的PS是7.6.9請用一個指令完成剩餘工作完成系統」)",
     "## 7. 本輪(v0149 → v0150 + VRN2_RoundAll_v0103 · 桌機 2026-10-29 19:00 跑 RoundAll v0102 的貼回)\n\n| # | 桌機看到的 | 根因 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | ⑪ MS-6669 現價 3510 FAIL「在目標價標籤旁」· MS-3661 現價 3190 FAIL「前 4 頁沒有這個數」 | 冊值 = 原文那行(v0102 證據);字元框讀法在桌機漏讀 / 配錯側欄 | IndependentVerifier v0112:第二種讀法 · 同列標籤 | 真 MS-3661 模擬漏讀 → PASS · 對調 → FAIL · 回歸 193 不變 · 變造 12 / 12 |\n"
     "| b | ⑥f gate FAIL_CLOSED | 只因 6933 / 4171 鉅亨 404(沒有 FactSet 頁)| ConsensusJoin v0102:不納入 · 再跑一次 | 自測 ④(假引擎)+ v0101 離線引擎實跑 |\n"
     "| c | ⑤ 又把 ⑥e 重抓一輪(約 35 分鐘)| 明細「Python 本行程」被 v0102 當成用錯 Python | 啟動器 v0150 明細寫路徑 + 合界線 · RoundAll v0103 經 runner 跑過不重抓 | 自測 ⑳ |\n"
     "| d | ⑪ 證據只看到電話行 | 字串包含(730 ⊂ 2730-2869 · 38 ⊂ 4388)| RoundAll v0103 逐值 · 數字相等 · 跳過聯絡行 | 自測 ㉑ · 真 MS-3661 三個值各對到自己那行 |\n"
     "| e | ⑥e 財報 PermissionError「Existing VIA network bridge denied」· ⑬b 無歷史 | VIA 鎖版網路工具合規層對 MOPS 回 DENY | **不繞**;RoundAll v0103 印說明 → 交 VCGC | 自測 ㉒ |\n"
     "| — | MS-8358 / MS-8210 · daiwa 年度 1 格 · ⑥e 30 分鐘 | 要證據 / 操作員規則 | **沒修** | — |\n\n---\n\n"
     "## 7.0m 前一輪(v0148 → v0149 + VRN2_RoundAll_v0102 · 桌機 2026-10-29 17:01 跑 RoundAll v0101 的貼回 · 操作員「我的PS是7.6.9請用一個指令完成剩餘工作完成系統」)")
once("| 0 | **(v0149)** 桌機(PowerShell 7.6.9)貼 `vrn2_release_v0149/VRN2_RoundAll_v0102.md` 的 **pwsh 那一行**",
     "| 0 | **(v0150)** 桌機(cmd 或 PowerShell 7.6.9)貼 `vrn2_release_v0150/VRN2_RoundAll_v0103.md` 的 **pwsh 那一行** · 跑完看 ⑪ 是否只剩 MS-8358 / MS-8210 與它們的逐值證據 | 貼回 |\n"
     "| 0a | **(v0150)** MOPS 財報:VIA 鎖版網路工具合規層 DENY → VCGC 決定要不要放行 mops.twse.com.tw(⑬b 歷史對齊靠它)| VCGC |\n"
     "| 0 | **(v0149)** 桌機(PowerShell 7.6.9)貼 `vrn2_release_v0149/VRN2_RoundAll_v0102.md` 的 **pwsh 那一行**")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0150)** **驗證器說 FAIL 先看證據再改**:冊值 = 原文那行 → 是驗證器的讀法問題(換讀法 · 只放寬到同一列的標籤),不是去改擷取;放寬後一定跑對調變造(目標價 ↔ 現價)確認還抓得到。\n"
     "- **(v0150)** **品質閘的「沒有資料」和「抓失敗」要分開**:鉅亨 404 頁面不存在 = 沒有覆蓋,不納入閘再跑;其他不過照 FAIL_CLOSED。引擎檔不改。\n"
     "- **(v0150)** **收據的文字是給程式讀的**:「Python 本行程」讓下游誤判又重抓 35 分鐘;明細要寫出路徑與判斷依據(合 VDF 界線),下游看結構欄位(runner / fetch_python)不看字串。\n"
     "- **(v0150)** **證據比對用數字相等,不用字串包含**(730 ⊂ 2730-2869),並跳過 Email / 電話行。\n"
     "- **(v0150)** **VIA 網路工具 DENY 一律不繞**:要的資料被拒就說清楚是誰拒、交給誰決定(VCGC)。\n\n")
(REPO / "VRN2_Handover_v0151.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0151 lines", src.count("\n"))
