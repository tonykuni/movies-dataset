"""VRN2_RoundAll_v0103.py = v0102 + 桌機 2026-10-29 19:00 貼回修正(套件 v0150 · 不重抓 ⑥e · 證據逐值 · MOPS DENY 說明)。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v149/new/VRN2_RoundAll_v0102.py").read_text(encoding="utf-8")
start = src.index('"""VRN2_RoundAll v0102')
end = src.index('"""', start + 3) + 3
head, doc, body = src[:start], src[start:end], src[end:]
at = doc.index("v0102(桌機 2026-10-29 17:01")
gen = doc.index("操作員令(2026-10-29)")
new_head = doc[:at].replace('"""VRN2_RoundAll v0102 — ', '"""VRN2_RoundAll v0103 — ', 1)
v0103_part = r'''v0103(桌機 2026-10-29 19:00 跑 v0102 的貼回 · 紅 0 黃 20 · 5957 秒 · rc 2):3014TT 第 3 點 / SyntaxWarning / ⑥e 選錯 Python 都好了;這輪修:
  · 套件 v0150(啟動器 v0150 · runtime v0150 = v0149 的 184 個成員不動 + IndependentVerifier v0112 · ConsensusJoin v0102)。
  · ⑤ 不再重抓 ⑥e:啟動器 v0149 已經用合 VDF 界線的 Python(MarketFetchRun)抓過,但它的明細寫「Python 本行程」,v0102 誤判成「用錯 Python」
    又整輪重抓一次(約 35 分鐘、結果一樣)。收據 ⑥e 有 runner(經 MarketFetchRun 跑)就不重抓。
  · ⑥ ⑪ 基本資料 FAIL 證據改成逐值:每個冊值(現價 / 目標價 / 上漲空間)各列原 PDF 前 4 頁「數字相等」的行(不是字串包含 —— v0102 把 38 對到 4388、
    730 對到電話 2730-2869),跳過 Email / 電話行;沒有就寫「前 4 頁沒有這個數」。
  · ⑥ ⑥e 財報被拒的說明:last_error 有「Existing VIA network bridge denied this request」= VDF 引擎打 MOPS 財報時,VIA 鎖版網路工具的合規層回 DENY;
    VDF / VRN-2 照規則不繞 → 沒有歷史財報 → ⑬b「無歷史」。要不要放行是 VCGC(網路工具)的決定。
  · ③ 自測:ConsensusJoin v0101 → v0102(鉅亨沒有 FactSet 頁的 404 代號不納入閘)。
  · 驗證器 v0112(⑪ · 在 VIA 樹裡跑):MS-6669 3510 / MS-3661 3190 的現價 FAIL 是字元框讀法漏讀 / 配錯側欄 —— 冊值就等於原文
    「Shr price, close (…) NT$3,510.00」;字元框說不對時,換第二種讀法只看同一列的標籤(對調照樣 FAIL)。

'''
general = doc[gen:]
general = general.replace("這些都在 VRN-2 套件 v0149 裡", "這些都在 VRN-2 套件 v0150 裡").replace("Downloads\\\\VRN2_Closeout_v0149", "Downloads\\\\VRN2_Closeout_v0150")
general = general.replace("ActivateVRN-2_v0149(", "ActivateVRN-2_v0150(").replace("用法:python VRN2_RoundAll_v0102.py", "用法:python VRN2_RoundAll_v0103.py")
assert "v0149" not in general, re.findall(r".{20}v0149.{20}", general)
doc = new_head + v0103_part + doc[at:gen] + general
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
body = body.replace("v0149", "v0150")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0102"', 'VERSION = "v0103"')
rep('("VRN2_ConsensusJoin_v0101.py", 900)', '("VRN2_ConsensusJoin_v0102.py", 900)')
rep('''    if market_tool and fetch_py and market.get("lamp") in ("YELLOW", "RED") and "Python 本行程" in str(market.get("detail", "")) and os.environ.get("VIA_VRN2_NO_MARKET") != "1":''',
    '''    if market_tool and fetch_py and market.get("lamp") in ("YELLOW", "RED") and "Python 本行程" in str(market.get("detail", "")) and not market.get("runner") and os.environ.get("VIA_VRN2_NO_MARKET") != "1":   # v0103:經 MarketFetchRun 跑過的不重抓''')
# evidence: numbers equal (not substring) · skip contact lines · per field
i = s.index('EVIDENCE_PY = r"""'); j = s.index('EVIDENCE_FIELDS = (')
s = s[:i] + r'''EVIDENCE_PY = r"""
import json, re, sys
pdf, values = sys.argv[1], json.loads(sys.argv[2])
labels = re.compile(r"price|target|close|upside|股價|目標|收盤|現價|潛在|漲幅|上漲", re.I)
contact = re.compile(r"@|\+\d{1,3}[\s-]*\d|\b\d{3,4}-\d{4}\b|tel\b|fax\b|電話|傳真", re.I)
def num(t):
    try:
        return float(str(t).replace(",", "").replace(" ", ""))
    except ValueError:
        return None
want = [(f, num(re.sub(r"[^\d.,-]", "", str(v)))) for f, v in values]
out = []
try:
    import pypdfium2 as pdfium
    doc = pdfium.PdfDocument(pdf)
    for i in range(min(4, len(doc))):
        for line in doc[i].get_textpage().get_text_range().replace("\r", "\n").split("\n"):
            if not line.strip() or contact.search(line):
                continue
            ns = [num(m.group()) for m in re.finditer(r"-?\d[\d,]*(?:\.\d+)?", line)]
            hit = [f for f, w in want if w is not None and any(n is not None and abs(n - w) < 1e-6 for n in ns)]
            if hit or (labels.search(line) and re.search(r"\d", line)):
                out.append({"page": i + 1, "line": line.strip()[:200], "values": hit})
except Exception as error:
    out.append({"error": "%s: %s" % (type(error).__name__, str(error)[:160])})
out.sort(key=lambda r: (not r.get("values"), r.get("page", 0)))
print(json.dumps(out[:60], ensure_ascii=False))
"""
''' + s[j:]
rep('''                done = subprocess.run([vpy, "-X", "utf8", "-c", EVIDENCE_PY, str(pdf), json.dumps([values.get(k) for k in ("CURRENT_PRICE_REPORT", "TARGET_PRICE", "UPSIDE_PCT") if values.get(k)])],''',
    '''                done = subprocess.run([vpy, "-X", "utf8", "-c", EVIDENCE_PY, str(pdf), json.dumps([[k, values.get(k)] for k in ("CURRENT_PRICE_REPORT", "TARGET_PRICE", "UPSIDE_PCT") if values.get(k)])],''')
rep('''    for ev in fail_evidence(root, vpy):
        hits = [r for r in ev["lines"] if r.get("values")][:3] or [r for r in ev["lines"] if r.get("line")][:3]
        err = next((r["error"] for r in ev["lines"] if r.get("error")), "")
        f("YELLOW", "⑪ 基本資料 FAIL 證據", "%s · %s · 冊值 %s · 原文 %s" % (ev["file"], " / ".join("%s %s" % (k, str(v)[:70]) for k, v in ev["fails"].items()), json.dumps(ev["values"], ensure_ascii=False)[:200],
          " | ".join("第 %s 頁「%s」" % (r.get("page"), r.get("line")) for r in hits)[:500] or err or "前 4 頁沒有對到的行"),''',
    '''    for ev in fail_evidence(root, vpy):
        err = next((r["error"] for r in ev["lines"] if r.get("error")), "")
        per = []                                                          # v0103 逐值:每個冊值各列數字相等的行(跳過 Email / 電話)
        for k in ("CURRENT_PRICE_REPORT", "TARGET_PRICE", "UPSIDE_PCT"):
            if ev["values"].get(k):
                rows = [r for r in ev["lines"] if k in (r.get("values") or [])][:2]
                per.append("%s %s → %s" % (k, ev["values"][k], " / ".join("第 %s 頁「%s」" % (r.get("page"), r.get("line")) for r in rows) if rows else "前 4 頁沒有這個數"))
        f("YELLOW", "⑪ 基本資料 FAIL 證據", "%s · %s · %s" % (ev["file"], " / ".join("%s %s" % (k, str(v)[:70]) for k, v in ev["fails"].items()), " | ".join(per)[:700] or err or "前 4 頁沒有對到的行"),''')
# MOPS DENY explanation
rep('''        f("YELLOW", "⑥e 擷取錯誤(last_error.txt)", " | ".join(tail)[:600], "VDF 引擎自己的錯誤(VRN-2 只讀不改)· 網路 / 憑證 / 套件 → 照錯誤處理;整段在貼回包 vrn2/market/vdf/last_error.txt")''',
    '''        f("YELLOW", "⑥e 擷取錯誤(last_error.txt)", " | ".join(tail)[:600], "VDF 引擎自己的錯誤(VRN-2 只讀不改)· 網路 / 憑證 / 套件 → 照錯誤處理;整段在貼回包 vrn2/market/vdf/last_error.txt")
        whole = err.read_text(encoding="utf-8", errors="replace")
        if "Existing VIA network bridge denied" in whole:                   # v0103
            f("YELLOW", "⑥e MOPS 財報被拒(VIA 網路工具 DENY)", "VDF 引擎打 MOPS(公開資訊觀測站)財報時,VIA 鎖版網路工具的合規層回 DENY → PermissionError;VDF / VRN-2 照規則不繞道 → 沒有歷史財報 → ⑬b 無歷史",
              "要不要放行 mops.twse.com.tw 是 VCGC(鎖版網路工具)的決定;價格 / 還原價(TWSE / TPEX / Yahoo)不受影響")''')
# selftests ⑳ ~ ㉒
rep('''    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · 20 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(bad)), flush=True)''', r'''        # ⑳ ~ ㉒ v0103
        rr = {"market": {"lamp": "YELLOW", "detail": "VRN2_MarketFetch_v0112.py · Python 本行程 · 擷取 RED:…", "runner": "VRN2_MarketFetchRun_v0100.py", "fetch_python": {"python": "/x/py"}}, "consensus": {"run": {"lamp": "GREEN"}}, "history_align": {"lamp": "GRAY"}}
        chk("⑳ 修正計畫:⑥e 已經經 MarketFetchRun(合 VDF 界線)跑過 → 不重抓(v0102 因為「Python 本行程」又抓了一輪)", "market" not in [k for k, _ in plan_fixes(root, rr, "/x/py", A(), "/x/MarketFetch.py")])
        ev_ok = False
        try:
            try:
                import pymupdf as fitz  # noqa: WPS433
            except ImportError:
                import fitz  # noqa: WPS433
            import pypdfium2  # noqa: F401,WPS433
            doc = fitz.open()
            page = doc.new_page()
            for i, line in enumerate(("Morgan Stanley Taiwan", "We reiterate our OW rating with a NT$730 price target.", "Irene.Yen@morganstanley.com +886 2 2730-2869",
                                      "Shr price, close (Sep 15, 2026) NT$510.00", "Price target NT$4,388.00 · upside 38%")):
                page.insert_text((72, 72 + 16 * i), line, fontsize=10)
            pdf = Path(td) / "ev.pdf"
            doc.save(str(pdf))
            done = subprocess.run([sys.executable, "-X", "utf8", "-c", EVIDENCE_PY, str(pdf), json.dumps([["CURRENT_PRICE_REPORT", "510.00"], ["TARGET_PRICE", "730.00"], ["UPSIDE_PCT", "38"]])], capture_output=True, text=True, encoding="utf-8", timeout=120)
            got = json.loads(done.stdout.strip().splitlines()[-1])
            lines_of = {k: [r["line"] for r in got if k in r.get("values", [])] for k in ("CURRENT_PRICE_REPORT", "TARGET_PRICE", "UPSIDE_PCT")}
            ev_ok = (lines_of["CURRENT_PRICE_REPORT"] == ["Shr price, close (Sep 15, 2026) NT$510.00"] and lines_of["TARGET_PRICE"] == ["We reiterate our OW rating with a NT$730 price target."]
                     and lines_of["UPSIDE_PCT"] == ["Price target NT$4,388.00 · upside 38%"] and not any("@" in r.get("line", "") for r in got))
            chk("㉑ 證據逐值:數字相等才算(38 不對到 4388 · 730 不對到電話 2730-2869)· Email / 電話行跳過", ev_ok)
        except Exception as error:  # noqa: BLE001
            print("[SKIP] ㉑ 沒有 PyMuPDF / pypdfium2(%s)· 不產生 PDF" % type(error).__name__)
        (v2 / "market" / "vdf" / "last_error.txt").write_text("CMD: python VDF_TW_AllInOne_v039.py --datasets financial\n[FIN] 1303 1/43\n[ERROR] PermissionError: Existing VIA network bridge denied this request\n", encoding="utf-8")
        sys.stdout = io.StringIO()
        try:
            rep4 = diagnose(root, None)
        finally:
            sys.stdout = sys_stdout
        a4 = {x["area"]: x for x in rep4["findings"]}
        chk("㉒ 除錯:⑥e last_error 是 VIA 網路工具 DENY(MOPS)→ 說明「不繞道 · 交 VCGC 決定」· ⑬b 無歷史的原因", "VCGC" in a4.get("⑥e MOPS 財報被拒(VIA 網路工具 DENY)", {}).get("next", "") and "MOPS" in a4.get("⑥e MOPS 財報被拒(VIA 網路工具 DENY)", {}).get("finding", ""))
    for k, v in saved_env.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v
    RESULTS.clear()
    print("[%s] %s %s --selftest · 23 項 · 不過 %d" % ("PASS" if not bad else "FAIL", NAME, VERSION, len(bad)), flush=True)''')
rep('hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0102.py"))', 'hint = rerun_hint(Path("C:/Users/x/Downloads/VRN2_RoundAll_v0103.py"))')
(S / "v150/new/VRN2_RoundAll_v0103.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0103 lines", s.count("\n"))
