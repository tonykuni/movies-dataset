VRN2_Closeout_v0150 — VRN-2 closeout package (2026-10-29)

Entry: python ActivateVRN-2_v0150.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0103.py — package → preflight → all selftests → run → safe auto-fixes → diagnosis → paste-back zip.
Runtime: VRN2_Runtime_v0150.zip = runtime v0149 (184 members byte-identical) + VRN2_IndependentVerifier_v0112 + VRN2_ConsensusJoin_v0102,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0150 (desktop run of VRN2_RoundAll_v0102 · 2026-10-29 19:00 · red 0 · yellow 20 · 5957 s):
 - step 11 IndependentVerifier v0112: MS-6669 / MS-3661 CURRENT_PRICE FAILs were the character-box reader missing / mispairing the key-data sidebar;
   when it says no, the page is read a second way and only the same-line label counts (swapped target / price stays FAIL).
 - step 6f ConsensusJoin v0102: gate FAIL_CLOSED came only from 6933 / 4171 (cnyes 404, no FactSet page); those are left out and the engine runs again.
 - step 6e detail names the fetch Python (RoundAll v0102 read 'Python 本行程' as the wrong Python and fetched everything twice).
Verification: see VRN2_Verification_v0150.md. Hashes: PACKAGE_SHA256.json.
