"""v0162 收尾:驗證紀錄 · 交接 v0163(從 v0162 抄 · 只增)· 放進倉 vrn2_release_v0162 · logs / 工具 zip。桌機資料不進倉(只放結論)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v162"); rel = W / "release162"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    return x.replace(str(W / "t162a"), "<sbx>").replace(str(W), "<w>").replace(SCR, "<scratch>").replace(SCR0, "<scratch0>")


R = json.loads((rel / "VRN2_Release_v0162.json").read_text(encoding="utf-8"))
st = [l for l in lines(W / "rall118_selftest.log") if re.search(r"^\[PASS\] 7[0-2] |^\[FAIL\]|--selftest · ", l)]
stv = [l for l in lines(W / "rall118_selftest_venv.log") if "--selftest · " in l]
ps = json.loads((W / "pscheck162.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny162.rc") if l.strip()]
pat = r"boot:|boot SHA|擷取鎖 ·|⑤ 修 · ⑥e|===== 收尾|\[(VRN-2|人工|VCGC)\] \d|PYPROG=|MAXWIDTH="
e2e = {n: [short(l)[:190] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)] for n in ("stale", "live", "full", "tamper")}
R["results"] = {"selftest": st, "selftest_venv": stv, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e,
                "desktop_1611": "console text only (paste-back VRN2_PasteBack_20261031_161126.zip not uploaded): v0117 moved the stale lock (PID 20940, 2026-10-30T23:09:15Z) · 6e re-fetch ran · MOPS financial fetched ticker by ticker (no DENY · VCGC 0) · step 5 fetch stopped at 2400 s (3rd financial group 17/22) · close-out OPEN · VRN-2 5 (6e + 13b) · console flooded by progress text",
                "not_run": "the real re-fetch continuing after the 2400 s stop and the Windows console progress rendering (Linux container; PSStyle.Progress.MaxWidth set / restored is checked in e2e)"}
(rel / "VRN2_Release_v0162.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0162 驗證紀錄(2026-10-31 · RoundAll v0118 · Handle-All v0110 · 套件 v0158 不動)

## 1. 起因(桌機 16:11 · 主控台文字 · RoundAll v0117 repair · 2518 秒)

- v0117 生效:過期 `RUNNING.lock`(PID 20940 · 2026-10-30T23:09:15Z 留下)移到 `RUNNING.lock.stale_20261031_152959` → ⑥e 開始重抓 · 舊 last_error.txt 改名留著。
- **MOPS 財報這次沒被網路工具擋**(VCGC 0 項):[FIN] 一檔約 30 秒逐檔抓(5 檔 → 19 檔 → 22 檔三組補缺)。
- ⑤ 重抓 ⑥e 的上限寫死 2400 秒 → 第 3 組第 17 檔(4966)被停 · 最後一組 latest(43 檔)沒跑 · 填值照舊(完整 51 · 缺 1)。
- ⑬b 歷史對齊因此不完整(對上 15 · 沒對上 22 · 無歷史 7 · 檢驗 479 不過 10 · 口徑不明 6)。
- 收尾 **OPEN · VRN-2 5 項** = ⑤ 重抓 ⑥e / ⑥ 步驟 ⑥e / ⑤ 重跑 ⑬b / ⑥ 步驟 ⑬b / ⑥ 歷史對齊 —— 其實是同一件事(⑥e 沒抓完)。
- 主控台被進度列文字灌滿:進度列文字含中文 / ⑥ / ·(一個字佔兩格)· 超過視窗寬就折行 → PowerShell 重畫算錯行數 → 舊的那條一直留在畫面上。
- 下一次 repair 也不會自己接著抓:last_error.txt 已改名、收據 ⑥e 寫的是「RoundAll 修正後 · 擷取 RED:逾時 2400 秒」(不是擷取鎖)。

## 2. 修法

| 檔 | 內容 |
|---|---|
| RoundAll v0118(`%s`)| ⑤ 重抓 ⑥e 擷取上限 2400 → 5400 秒(`VRN2_MARKET_FETCH_SEC` · 最少 600)· 填值 2400 · 收據 ⑥e「RoundAll 修正後 · 擷取 RED:逾時 N 秒」→ ⑤ 再排重抓(VDF 引擎 MOPS 回應 12 小時快取)· 收尾頁 ⑥e 各列同一項 · ⑥e 沒抓完時 ⑬b 三列併入 · 自測 72 |
| Handle-All v0110(一行 `%s` · 開機檔 `%s`)| `$PSStyle.Progress.MaxWidth` = 視窗一半寬(跑完還原)· RoundAll 跑時只留它那一條真百分比 · 進度列標題改英數 · 逾時保底 整輪 8 h / 其他 4 h |

最短一行 %d 字元 · cmd 一行 %d 字元 · 套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip` 不動。

## 3. 測試

```text
%s
venv(有 PyMuPDF):%s
%s
e2e 結束碼:%s
```

自測 71 用的就是桌機 16:11 那 5 列(步驟名 + 內容):⑥e 沒抓完 → 合成 1 項(另見 4 列);⑥e 完整 → ⑥e / ⑬b 各 1 項。VCGC 全景骨架卡:RoundAll v0118 SWALLOW 10 項(同 v0117)。

## 4. e2e(桌機 v0153 狀態沙盒 · 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設)

```text
%s
```

`MAXWIDTH=120`:Handle-All 跑完把進度列寬度還原(跑的時候是視窗一半寬)。

**沒跑到的**:2400 秒之後真的接著抓(容器沒有合 VDF 界線的 Python)· Windows 主控台的進度列實際長相(容器是 Linux)→ 桌機下一輪確認。

## 5. 桌機預期

repair → ⑤ 計畫有「⑥e 上一輪 RoundAll 重抓到 2400 秒逾時 → 接著抓」→ 日線 / 已抓財報走快取 · 接著抓剩下的財報(含 latest)· 上限 5400 秒 → ⑬b 用完整財報重算 → 收尾:
⑥e 抓完就沒有 ⑥e 那一項;⑬b 若仍黃(沒對上 / 口徑不明)單獨一項 → 看貼回包的 `VRN2_HistoryAlign_latest.json` 再決定(VRN-2 擷取 / 單位口徑 / 報告估計 vs 實際)。
畫面上只剩一條會動的進度列。
""" % (R["roundall"]["sha256"][:12], H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], H["cmd_line_chars"],
       "\n".join(st), " ".join(stv), pparse, " · ".join(rc), "\n".join("[%s] " % n + l for n in e2e for l in e2e[n]))
(rel / "VRN2_Verification_v0162.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0162.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0117 + VRN2_HandleAll_v0109 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0118 + VRN2_HandleAll_v0110 · 2026-10-31(桌機 16:11:過期鎖移開成功 · MOPS 財報這次沒被擋 · "
        "⑤ 重抓 ⑥e 2400 秒被停 → RoundAll v0118 上限 5400 秒 + 接著抓 + 收尾頁 ⑥e / ⑬b 合一項;Handle-All v0110 進度列不再灌滿畫面;套件 v0158 不動)")
src = "\n".join(L)
once("> **本輪(v0161)**",
     "> **本輪(v0162)**:桌機 16:11(RoundAll v0117 repair · 2518 秒 · 只有主控台文字)· 過期鎖 PID 20940 移開成功 · **MOPS 財報這次沒被網路工具擋(VCGC 0)**,一檔約 30 秒 · "
     "⑤ 重抓 ⑥e 上限寫死 2400 秒 → 第 3 組 17/22 被停 · latest 沒跑 · ⑬b 跟著不完整 · 收尾 OPEN · VRN-2 5 項(同一件事)· 主控台被進度列灌滿(中文字佔兩格 · 折行後重畫算錯)。"
     "**RoundAll v0118**:擷取上限 5400 秒(`VRN2_MARKET_FETCH_SEC`)· 上一輪逾時 → 接著抓 · 收尾頁 ⑥e 各列與(⑥e 沒抓完時)⑬b 合一項 · 自測 72。"
     "**Handle-All v0110**:`$PSStyle.Progress.MaxWidth` = 視窗一半寬 · RoundAll 跑時只留一條進度列 · 逾時保底 8 h / 4 h(最短一行 %d 字元 · cmd 一行 %d 字元)。\n"
     "> **本輪(v0161)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
once("| **VRN2_HandleAll_v0109.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0109** | `vrn2_release_v0161` |",
     "| **VRN2_HandleAll_v0110.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0110** | `vrn2_release_v0162` | 一行版 `%s` · 開機檔 `%s` | **新**(進度列寬度 · 逾時保底 · 指向 RoundAll v0118)|\n"
     "| **VRN2_RoundAll_v0118.py**(發行夾 · 一支入口 · 不在套件內)| **v0118** | `vrn2_release_v0162` | `%s` | **新**(⑥e 重抓上限 5400 · 接著抓 · ⑥e / ⑬b 合一項 · 自測 72 項)|\n"
     "| **VRN2_HandleAll_v0109.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0109** | `vrn2_release_v0161` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12]))
r161 = json.loads((REPO / "vrn2_release_v0161/VRN2_Release_v0161.json").read_text(encoding="utf-8"))
once("| **VRN2_RoundAll_v0117.py**(發行夾 · 一支入口 · 不在套件內)| **v0117** | `vrn2_release_v0161` | `%s` | **新**(" % r161["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0117.py**(發行夾 · 一支入口 · 不在套件內)| **v0117** | `vrn2_release_v0161` | `%s` | 被 v0118 取代(⑤ 重抓 ⑥e 2400 秒上限 · ⑥e / ⑬b 分開算)· (" % r161["roundall"]["sha256"][:12])
once("| 0 | **(v0161)**",
     "| 0 | **(v0162)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"` 再貼 `vrn2_release_v0162/VRN2_HandleAll_v0110.md` 的 cmd 一行 → repair 接著抓 ⑥e(上限 5400 秒 · 約 1 小時)→ ⑬b 重算 → "
     "收尾:⑥e 抓完就沒有 ⑥e 那一項 · ⑬b 若仍黃 → **上傳貼回包**(要看 VRN2_HistoryAlign_latest.json)| 貼回 |\n"
     "| 0 | **(v0161)**")
once("**v0161(2026-10-31)**:", "**v0162(2026-10-31)**:MOPS 財報這次沒被擋 · ⑤ 重抓 ⑥e 2400 秒被停 → RoundAll v0118 上限 5400 秒 + 接著抓 · 收尾頁 ⑥e / ⑬b 合一項;Handle-All v0110 進度列寬度;套件 v0158 不動。\n\n**v0161(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0162)** **外部來源一放行,時間就變長**:MOPS 以前被擋所以 ⑥e 幾秒就結束;放行後一檔約 30 秒。寫死的逾時要跟著工作量走(可調的環境變數 + 逾時後下一輪能接著做),"
     "而且逾時本身也要能被下一輪辨認(收據字樣 → ⑤ 計畫)。\n"
     "- **(v0162)** **PowerShell 進度列不要放超過半個視窗寬的中文**:中文 / ⑥ / · 一個字佔兩格,超寬折行後重畫會一直疊在畫面上;用 `$PSStyle.Progress.MaxWidth` 限寬,同時只留一條會動的進度列。\n"
     "- **(v0162)** **收尾頁數的是「件」不是「列」**:同一個原因的列(步驟列 / ⑤ 修正列 / 下游步驟)要合成一項,不然操作員看到 VRN-2 5 項會以為有 5 件事。\n\n")
(REPO / "VRN2_Handover_v0163.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0162"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0118.py", "VRN2_RoundAll_v0118.md", "VRN2_HandleAll_v0110.md", "VRN2_HandleAll_v0110_boot.txt", "VRN2_Release_v0162.json", "VRN2_Verification_v0162.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t162a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0162.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "rall118_selftest.log", W / "rall118_selftest_venv.log", W / "pscheck162.log", W / "tiny162.rc"] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("vdf_after_*.txt")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0162.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall118.py", "build162.py", "finalize162.py", "e2e162.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0163", src.count("\n"))
