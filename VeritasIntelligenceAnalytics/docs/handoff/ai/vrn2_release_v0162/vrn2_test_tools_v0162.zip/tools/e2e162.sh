#!/bin/bash
# v0161 e2e:桌機 v0153 狀態沙盒 + 倉的 VIA 網路工具 / PS 加速器進度模組 · 沙盒 GitHub 分支 · pwsh 7.4.6 · 同意閘不設
# 過期鎖(PID 已不在)→ repair ⑤ 移開 · 整輪 ④ 先移開 · 還在跑的鎖(活的 python · 比鎖早起)→ 不動 · 收尾頁「人工」· 竄改開機檔 → 不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v162; T=$W/t162a; P=$S2/venv_vrn2/bin/python; REPO=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai; mkdir -p $D/vrn2_release_v0158 $D/vrn2_release_v0162
cp $REPO/vrn2_release_v0158/VRN2_Closeout_v0158.zip $REPO/vrn2_release_v0158/VRN2_Release_v0158.json $D/vrn2_release_v0158/
cp $W/release162/VRN2_Release_v0162.json $W/release162/VRN2_RoundAll_v0118.py $W/release162/VRN2_RoundAll_v0118.md $W/release162/VRN2_HandleAll_v0110.md $W/release162/VRN2_HandleAll_v0110_boot.txt $D/vrn2_release_v0162/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release162/tiny_line.txt)
LINE="$LINE; 'PYPROG=' + (\$global:VIA_PYPROG_LAST | ConvertTo-Json -Compress); 'MAXWIDTH=' + \$PSStyle.Progress.MaxWidth"
VD=$T/VIA/VIA_Reports/vrn2/market/vdf; mkdir -p $VD
BUSY='CMD: C:\Python313\python.exe -u -W ignore VDF_TW_AllInOne_v039.py --tickers 1303,1319,1476 --datasets financial --quarters latest

[ERROR] RuntimeError: Another writer may be active. Inspect C:\x\VIA_Reports\vrn2\market\vdf\RUNNING.lock; remove only after confirming the old process has stopped.'
run() { N=$1; shift; cd "$T/home" && env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 \
  VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2 "$@" timeout 3000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny162.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; ls $VD > $W/vdf_after_$N.txt; }
rm -f $W/tiny162.rc
printf '%s' "$BUSY" > $VD/last_error.txt; printf '{"pid": 999999, "at": "2026-10-31T02:40:00+00:00"}' > $VD/RUNNING.lock; run stale
python3 -c "import time; time.sleep(300)" & LP=$!; sleep 2; printf '%s' "$BUSY" > $VD/last_error.txt; printf '{"pid": %d, "at": "%s"}' $LP "$(date -u +%Y-%m-%dT%H:%M:%S+00:00)" > $VD/RUNNING.lock; run live VRN2_MODE=report; kill $LP 2>/dev/null; rm -f $VD/RUNNING.lock
printf '{"pid": 999998, "at": "2026-10-31T03:00:00+00:00"}' > $VD/RUNNING.lock; run full VRN2_MODE=full
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0162/VRN2_HandleAll_v0110_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny162.rc
