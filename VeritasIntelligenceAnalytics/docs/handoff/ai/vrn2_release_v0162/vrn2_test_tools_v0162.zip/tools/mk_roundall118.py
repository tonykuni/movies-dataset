"""VRN2_RoundAll_v0118.py = v0117(倉裡 vrn2_release_v0161)+ ⑤ 重抓 ⑥e 上限 2400 → 5400 秒(VRN2_MARKET_FETCH_SEC)· 上一輪 RoundAll 重抓逾時 → 接著抓 ·
收尾頁 ⑥e / ⑬b 同一件事合一項。套件 v0158 不動。"""
from pathlib import Path

W = Path("/home/user/vrn2_work/v162")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
s = (REPO / "vrn2_release_v0161/VRN2_RoundAll_v0117.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('"""VRN2_RoundAll v0117 — ', '"""VRN2_RoundAll v0118 — ')
rep("v0117(桌機 2026-10-31 14:33 貼回", '''v0118(桌機 2026-10-31 16:11 · RoundAll v0117 repair · 2518 秒 · 收尾 OPEN · VRN-2 5 項):
  · v0117 的修法在桌機生效:過期 RUNNING.lock(PID 20940 · 07:09 留下)移開 → ⑥e 開始重抓;這次 MOPS 財報沒有被網路工具擋(VCGC 0 項),
    一檔約 30 秒逐檔抓。但 ⑤ 重抓 ⑥e 的上限寫死 2400 秒 → 抓到第 3 組財報(22 檔的第 17 檔)被停,最後一組 latest(43 檔)沒跑;
    ⑬b 歷史對齊因此也不完整(對上 15 · 沒對上 22 · 無歷史 7)· 收尾頁把同一件事算成 VRN-2 5 項。
  · ⑤ 重抓 ⑥e 的擷取上限 2400 → 5400 秒(VRN2_MARKET_FETCH_SEC 可調)· 填值仍 2400 秒。
  · 上一輪 RoundAll 重抓 ⑥e 逾時(收據 ⑥e「RoundAll 修正後 · 擷取 RED:逾時 N 秒」)→ 這輪接著重抓(VDF 引擎 MOPS 回應有 12 小時快取 · 已抓的不重打)。
  · 收尾頁:⑤ 重抓 ⑥e / ⑥ 步驟 ⑥e / ⑥e 擷取錯誤 = 同一項;⑥e 沒抓完時 ⑬b 歷史對齊三列也併進同一項(歷史對齊跟著 ⑥e 不完整);⑥e 完整了 ⑬b 自己一項。
  · 自測 72 項(v0117 的 69 項 + 70 ~ 72)。

v0117(桌機 2026-10-31 14:33 貼回''')
rep("用法:python VRN2_RoundAll_v0117.py", "用法:python VRN2_RoundAll_v0118.py")
rep('VERSION = "v0117"', 'VERSION = "v0118"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0117.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0118.py"', 2)
rep('"VRN2_RoundAll_v0117.py" in html_', '"VRN2_RoundAll_v0118.py" in html_')
rep("自測 64 項(v0115 的 59 項 + 60 ~ 64)· v0117 起 69 項。", "自測 64 項(v0115 的 59 項 + 60 ~ 64)· v0117 起 69 項 · v0118 起 72 項。")

# ---- 重抓上限 ----
rep('''def retire_last_error(v2) -> str:''', '''def market_fetch_sec() -> int:
    """v0118 ⑤ 重抓 ⑥e 的擷取上限(秒):MOPS 財報一檔約 30 秒 · 補缺 + latest 常常要 50 ~ 60 分 → 預設 5400 · VRN2_MARKET_FETCH_SEC 可調。"""
    try:
        return max(600, int(os.environ.get("VRN2_MARKET_FETCH_SEC") or 5400))
    except ValueError:
        return 5400


_E_TIMEOUT = re.compile(r"RoundAll 修正後 · 擷取 RED:逾時 (\\d+) 秒")


def retire_last_error(v2) -> str:''')
rep('''timeout=2400, prefix="    [⑥e] ")''', '''timeout=market_fetch_sec() if verb == "--fetch" else 2400, prefix="    [⑥e] ")''')

# ---- ⑤ 計畫:上一輪 RoundAll 重抓逾時 → 接著抓 ----
rep('''    if (market_tool and fetch_py and market.get("lamp") in ("YELLOW", "RED") and "Python 本行程" in str(market.get("detail", "")) and not market.get("runner")''',
    '''    step_e = next((x for x in receipt.get("steps") or [] if str(x.get("step", "")).startswith("⑥e")), {})       # v0118 上一輪 RoundAll 重抓逾時
    e_to = _E_TIMEOUT.search(str(step_e.get("detail", "")))
    if (e_to and market_tool and fetch_py and step_e.get("lamp") in ("YELLOW", "RED") and not (lk.get("exists") and not lk.get("stale"))
            and os.environ.get("VIA_VRN2_NO_MARKET") != "1" and not any(k == "market" for k, _ in plan)):
        plan.append(("market", "⑥e 上一輪 RoundAll 重抓到 %s 秒逾時 → 接著抓(MOPS 回應 12 小時內有快取 · 這次上限 %d 秒)" % (e_to.group(1), market_fetch_sec())))
    if (market_tool and fetch_py and market.get("lamp") in ("YELLOW", "RED") and "Python 本行程" in str(market.get("detail", "")) and not market.get("runner")''')

# ---- 收尾頁:負責方 + 合併 ----
rep('''    if "擷取鎖" in step or ((ctx.get("vdf_busy") or VDF_BUSY in detail) and re.match(''', '''    if re.match(r"(⑤ 修 · ⑥e|⑥ 步驟 ⑥e 市場擷取)", step) and re.search(r"逾時 \\d+ 秒", detail):      # v0118 RoundAll 自己的重抓上限(先於擷取鎖)
        return "VRN-2", "RoundAll 重抓 ⑥e 到上限被停(MOPS 財報一檔約 30 秒)→ v0118 起上限 %d 秒 · 再跑 repair 會接著抓(已抓的有快取)" % market_fetch_sec()
    if re.match(r"(⑤ 修 · 市場資料比歷史對齊新|⑥ 步驟 ⑬b|⑥ 歷史對齊)", step) and ctx.get("e_incomplete") and not ctx.get("mops_deny"):   # v0118
        return "VRN-2", "⑥e 財報還沒抓完(上一輪重抓逾時)→ 歷史對齊跟著不完整 · ⑥e 抓完再看這項"
    if "擷取鎖" in step or ((ctx.get("vdf_busy") or VDF_BUSY in detail) and re.match(''')
rep('''    if "擷取鎖" in step or (ctx.get("vdf_busy") and re.match(r"⑥ (步驟 ⑥e 市場擷取|⑥e 擷取錯誤)", step)):   # v0117 ⑥e 步驟列 / last_error / 擷取鎖說明 = 同一個擷取鎖
        return "%s|⑥e 擷取鎖" % owner''', '''    if "擷取鎖" in step or (ctx.get("vdf_busy") and re.match(r"⑥ (步驟 ⑥e 市場擷取|⑥e 擷取錯誤)", step)):   # v0117 ⑥e 步驟列 / last_error / 擷取鎖說明 = 同一個擷取鎖
        return "%s|⑥e 擷取" % owner                                         # v0118 跟 ⑥e 其他列同一個根
    if re.match(r"(⑤ 修 · ⑥e|⑥ 步驟 ⑥e 市場擷取|⑥ ⑥e 擷取錯誤)", step):             # v0118 ⑤ 重抓 / 步驟列 / last_error = 同一次擷取
        return "%s|⑥e 擷取" % owner
    if re.match(r"(⑤ 修 · 市場資料比歷史對齊新|⑥ 步驟 ⑬b|⑥ 歷史對齊)", step):      # v0118 ⑬b 三列 = 同一次對齊;⑥e 沒抓完 → 併進 ⑥e
        return ("%s|⑥e 擷取" if ctx.get("e_incomplete") else "%s|⑬b 歷史對齊") % owner''')
rep('''"vdf_lock": vdf_lock_state(v2), "vdf_busy": VDF_BUSY in text,''',
    '''"vdf_lock": vdf_lock_state(v2), "vdf_busy": VDF_BUSY in text,
           "e_incomplete": any(str(x.get("step", "")).startswith("⑥e") and x.get("lamp") in ("YELLOW", "RED") for x in receipt.get("steps") or []),''')

# ---- 自測 70 ~ 72 ----
rep('''        src64 = Path(__file__).read_text(encoding="utf-8")''', '''        v70 = td / "v70"
        (v70 / "VIA_Reports" / "vrn2" / "market" / "vdf").mkdir(parents=True)
        rc70 = {"market": {"lamp": "YELLOW", "detail": "擷取 RED:VDF AllInOne_v039 · 失敗 5", "runner": "VRN2_MarketFetchRun_v0100.py"},
                "steps": [{"step": "⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 MarketFetch)", "lamp": "YELLOW", "detail": "RoundAll 修正後 · 擷取 RED:逾時 2400 秒 · 已停止 · 填值 YELLOW"}]}
        rc70g = {"market": rc70["market"], "steps": [dict(rc70["steps"][0], lamp="GREEN")]}
        saved70 = os.environ.get("VRN2_MARKET_FETCH_SEC")
        try:
            p70a = [k for k, _ in plan_fixes(v70, rc70, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")]
            d70a = next(d for k, d in plan_fixes(v70, rc70, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py") if k == "market")
            p70b = [k for k, _ in plan_fixes(v70, rc70g, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")]
            os.environ["VIA_VRN2_NO_MARKET"] = "1"
            p70c = [k for k, _ in plan_fixes(v70, rc70, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")]
            os.environ.pop("VIA_VRN2_NO_MARKET", None)
            os.environ.pop("VRN2_MARKET_FETCH_SEC", None)
            s70a = market_fetch_sec()
            os.environ["VRN2_MARKET_FETCH_SEC"] = "7200"
            s70b = market_fetch_sec()
            os.environ["VRN2_MARKET_FETCH_SEC"] = "abc"
            s70c = market_fetch_sec()
        finally:
            os.environ.pop("VIA_VRN2_NO_MARKET", None)
            if saved70 is None:
                os.environ.pop("VRN2_MARKET_FETCH_SEC", None)
            else:
                os.environ["VRN2_MARKET_FETCH_SEC"] = saved70
        chk("70 ⑤ 上一輪 RoundAll 重抓 ⑥e 逾時(收據「RoundAll 修正後 · 擷取 RED:逾時 2400 秒」)→ 接著抓 · ⑥e 綠了 / VIA_VRN2_NO_MARKET=1 → 不抓 · 擷取上限預設 5400 秒(VRN2_MARKET_FETCH_SEC 可調 · 亂填照預設)",
            "market" in p70a and "2400 秒逾時" in d70a and "5400" in d70a and "market" not in p70b and "market" not in p70c and s70a == 5400 and s70b == 7200 and s70c == 5400)
        rows71 = [("⑤ 修 · ⑥e 上一輪被擷取鎖擋住", "擷取 RED:逾時 2400 秒 · 已停止"), ("⑤ 修 · 市場資料比歷史對齊新 / 歷史對齊沒跑", "對上 15 · 沒對上 22"),
                  ("⑥ 步驟 ⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 Market", "RoundAll 修正後 · 擷取 RED:逾時 2400 秒 · 已停止"), ("⑥ 步驟 ⑬b 歷史對齊(歷史覆蓋預估 · 加減乘除檢驗 · 刪除區)", "RoundAll 修正後 · 對上 15"),
                  ("⑥ 歷史對齊", "對上 15 · 沒對上 22 · 無歷史 7")]
        ctx71 = {"e_incomplete": True}
        own71 = [owner_of({"lamp": "YELLOW", "step": st71, "detail": d71}, ctx71) for st71, d71 in rows71]
        items71 = [{"lamp": "YELLOW", "step": st71, "detail": d71, "owner": o71[0], "why": o71[1]} for (st71, d71), o71 in zip(rows71, own71)]
        m71a = merge_same([dict(i) for i in items71], ctx71)
        m71b = merge_same([dict(i) for i in items71], {"e_incomplete": False})
        chk("71 收尾頁:⑤ 重抓 ⑥e / ⑥ 步驟 ⑥e / ⑬b 三列 = 桌機 16:11 的 VRN-2 5 項 → ⑥e 沒抓完時合成 1 項(說明重抓上限 · 歷史對齊跟著不完整)· ⑥e 完整時 ⑥e / ⑬b 各 1 項",
            all(o[0] == "VRN-2" for o in own71) and "5400" in own71[0][1] and "歷史對齊跟著不完整" in own71[1][1] and len(m71a) == 1 and len(m71b) == 2
            and len(m71a[0].get("also") or []) == 4)
        src72 = Path(__file__).read_text(encoding="utf-8")
        chk("72 ⑤ 重抓 ⑥e 的擷取(--fetch)用 market_fetch_sec() 當上限 · 填值(--fill)照舊 2400 秒",
            src72.count("timeout=market_fetch_sec() if verb == " + '"--fetch" else 2400') == 1)
        src64 = Path(__file__).read_text(encoding="utf-8")''')
out = W / "new" / "VRN2_RoundAll_v0118.py"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0118 lines", s.count("\n"))
