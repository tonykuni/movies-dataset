"""v0162(冪等):RoundAll v0118(套件 v0158 不動)→ Handle-All v0110(進度列寬度 · 逾時保底放寬 · 指向 RoundAll v0118)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單。
vrn2_release_v0161 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v162"); rel = W / "release162"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v161/release161")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r161 = json.loads((REPO / "vrn2_release_v0161/VRN2_Release_v0161.json").read_text(encoding="utf-8"))
want = r161["package"]["sha256"]
assert hashlib.sha256((REPO / "vrn2_release_v0158/VRN2_Closeout_v0158.zip").read_bytes()).hexdigest() == want
ra = (W / "new/VRN2_RoundAll_v0118.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'VERSION = "v0118"' in ra
(rel / "VRN2_RoundAll_v0118.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0161'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0162'")
rep("$F = 'VRN2_RoundAll_v0117.py'", "$F = 'VRN2_RoundAll_v0118.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep('Write-Host "[VRN-2] Handle-All v0109 · PowerShell', 'Write-Host "[VRN-2] Handle-All v0110 · PowerShell')
rep("$ErrorActionPreference = 'Continue'\n$ProgressPreference = 'Continue'\n", "$ErrorActionPreference = 'Continue'\n$ProgressPreference = 'Continue'\n"
    "# v0110 進度列不超過視窗一半寬(中文 / ⑥ / · 一個字佔兩格 · 超寬會折行,PowerShell 的進度列重畫算錯行數,舊的那條就一直疊在畫面上)\n"
    "$pw0 = $null; try { if ($PSStyle) { $pw0 = $PSStyle.Progress.MaxWidth; $PSStyle.Progress.MaxWidth = [Math]::Max(30, [int][Math]::Floor(($Host.UI.RawUI.WindowSize.Width - 2) / 2)) } } catch { }\n")
rep("Write-VIAProgress -Activity 'VRN-2 Handle-All v0109 · VIA 加速器' -Status $s -Percent $p -Id 10 } else { Write-Progress -Id 10 -Activity 'VRN-2 Handle-All v0109' -Status $s -PercentComplete $p }",
    "Write-VIAProgress -Activity 'VRN-2 Handle-All v0110' -Status $s -Percent $p -Id 10 } else { Write-Progress -Id 10 -Activity 'VRN-2 Handle-All v0110' -Status $s -PercentComplete $p }")
rep("# v0108 RoundAll 不自己開頁(--no-open)· 跑完由這裡開收尾頁 · 逾時保底:整輪 5 小時 · 其他 2 小時($env:VRN2_TIMEOUT_SEC 可調 · VIA_PY_TIMEOUT_SEC=0 = 不設限)",
    "# v0108 RoundAll 不自己開頁(--no-open)· 跑完由這裡開收尾頁 · v0110 逾時保底:整輪 8 小時 · 其他 4 小時(⑤ 重抓 ⑥e 最長 90 分 + 填值 40 分)($env:VRN2_TIMEOUT_SEC 可調 · VIA_PY_TIMEOUT_SEC=0 = 不設限)")
rep("$to = ($Mode -eq 'full') ? 18000 : 7200", "$to = ($Mode -eq 'full') ? 28800 : 14400")
rep('& $Stage 35 "⑥ RoundAll · 模式 $($Mode) · 真百分比看下一條進度列"',
    "& $Stage 35 \"⑥ RoundAll · 模式 $($Mode)\"\n# v0110 RoundAll 跑的時候只留它那一條真百分比(少一條就少一次重畫)\nWrite-Progress -Id 10 -Activity 'VRN-2 Handle-All v0110' -Completed")
rep("Write-Progress -Id 10 -Activity 'VRN-2 Handle-All v0109' -Completed", "Write-Progress -Id 10 -Activity 'VRN-2 Handle-All v0110' -Completed\ntry { if ($null -ne $pw0) { $PSStyle.Progress.MaxWidth = $pw0 } } catch { }")
rep("(幾分鐘 · 要重抓 ⑥e 時更久)'", "(幾分鐘 · 要重抓 ⑥e 時 1 小時上下)'")
assert "exit" not in ha.replace("Exception", "") and "v0109" not in ha
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0161", "vrn2_release_v0162"), ("VRN2_HandleAll_v0109.md", "VRN2_HandleAll_v0110.md"), ("Handle-All v0109 SHA-256 OK", "Handle-All v0110 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0110_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0162/VRN2_HandleAll_v0110_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0110(2026-10-31 · RoundAll v0118 · 套件 v0158 不動)

v0110 = v0109 + 桌機 16:11 那輪(RoundAll v0117 repair · 2518 秒)看到的三件事:

| 項目 | v0109 那輪 | 現在 |
|---|---|---|
| 進度列把畫面灌滿 | 進度列文字有中文 / ⑥ / ·(一個字佔兩格)· 比視窗寬就折行 · PowerShell 重畫時算錯行數 → 舊的那條一直疊在畫面上 | 進度列最寬 = 視窗一半(`$PSStyle.Progress.MaxWidth`)· RoundAll 跑的時候只留它那一條真百分比 · 跑完還原 |
| ⑥e 重抓被停 | ⑤ 重抓 ⑥e 上限寫死 2400 秒 · MOPS 財報這次沒被擋(一檔約 30 秒)→ 抓到第 3 組第 17 檔被停 · latest 那組沒跑 | 上限 5400 秒(`VRN2_MARKET_FETCH_SEC` 可調)· 上一輪逾時 → 這輪接著抓(MOPS 回應 12 小時快取 · 已抓的不重打)|
| 收尾頁 VRN-2 5 項 | ⑤ 重抓 / ⑥e 步驟 / ⑬b 三列 分開算 | 同一件事合成 1 項(⑥e 沒抓完時 ⑬b 歷史對齊跟著併進來)|
| 逾時保底 | 整輪 5 小時 · 其他 2 小時 | 整輪 8 小時 · 其他 4 小時(`$env:VRN2_TIMEOUT_SEC` 可調)|
| 一支 Python | RoundAll v0117 | `VRN2_RoundAll_v0118.py`(SHA-256 `%s` · 自測 72 項)· 套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s` · 不動) |

## 先看:你開的是哪一種視窗?

- 提示字元前面有 **PS**(`PS C:\\Users\\tonyk>`)→ **PowerShell** → 用「PowerShell 7 視窗」那段。
- 前面沒有 PS(例如 `[16:11:29.38] C:\\Users\\tonyk` 下一行 `>`)→ **cmd** → 用「cmd 視窗」那段。cmd 不認 `$env:…` / `$r=…`。

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定)· 第 2 行 = 下面 PowerShell 那一行的編碼版(解碼後一字不差 · 一樣核對 SHA-256 才執行)。
要整輪才在第 2 行之前多貼 `set "VRN2_MODE=full"`。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)· 要整輪再貼 `$env:VRN2_MODE = 'full'`。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0110 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0118 `%s`)。

## 這次桌機貼下去會怎樣

- auto = repair:⑤ 計畫裡有「⑥e 上一輪 RoundAll 重抓到 2400 秒逾時 → 接著抓」→ 日線與已抓的財報走 12 小時快取 · 接著抓剩下的財報(含 latest 43 檔)·
  上限 5400 秒 → ⑬b 歷史對齊用完整的財報重算 → Combined → 增量庫 → Workbench(整輪約 1 小時上下)。
- 畫面上只會有一條會動的進度列(RoundAll 的真百分比),不再疊滿畫面。
- 收尾:⑥e 抓完 → 不再有 ⑥e 那一項;⑬b 若還是黃(沒對上 / 口徑不明)會單獨一項,把貼回包給我看明細。
- BLOCKED / REVIEW / DATA_GAP 都不是成功;VCGC 的 closeout_lamp 才是 VCGC 驗收。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (ra_sha[:12], want[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0110.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0118.py(套件 v0158 不動 · ⑥e 重抓上限 · 收尾頁合併)

`VRN2_RoundAll_v0118.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0117 +

| 改了什麼 | 說明 |
|---|---|
| ⑤ 重抓 ⑥e 上限 | 擷取(`--fetch`)2400 → 5400 秒(`VRN2_MARKET_FETCH_SEC` 可調 · 最少 600)· 填值(`--fill`)照舊 2400 秒 |
| 接著抓 | 收據 ⑥e 是「RoundAll 修正後 · 擷取 RED:逾時 N 秒」→ ⑤ 再排一次重抓(MOPS 回應 12 小時快取)|
| 收尾頁 | ⑤ 重抓 ⑥e / ⑥ 步驟 ⑥e / ⑥e 擷取錯誤 / 擷取鎖 = 同一項;⑥e 沒抓完時 ⑬b 三列也併進來;⑥e 完整了 ⑬b 自己一項 |

自測 72 項(v0117 的 69 項 + 70 ~ 72)。套件 `vrn2_release_v0158/VRN2_Closeout_v0158.zip`(SHA-256 `%s` · 本檔內已釘死)。**最省事:`VRN2_HandleAll_v0110.md`(cmd / PowerShell 各一段)**。

```bat
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0118.py" --only package,fix,report,closeout,pasteback
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0118.py"
```
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0118.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0118 + VRN2_HandleAll_v0110 (package v0158 unchanged)", "date": "2026-10-31",
        "trigger": "桌機 2026-10-31 16:11(主控台文字 · 貼回包 VRN2_PasteBack_20261031_161126 未上傳):RoundAll v0117 repair 2518 秒 · 過期鎖 PID 20940 移開成功 · MOPS 財報這次沒被擋(VCGC 0)· ⑤ 重抓 ⑥e 2400 秒逾時(第 3 組財報 17/22)· 收尾 OPEN · VRN-2 5 項(⑥e / ⑬b 同一件事)· 主控台被進度列文字灌滿",
        "package": {"name": "VRN2_Closeout_v0158.zip", "folder": "vrn2_release_v0158", "sha256": want, "changed": False},
        "fixes": {"RoundAll_v0118": "step 5 6e re-fetch limit 2400 → market_fetch_sec() = VRN2_MARKET_FETCH_SEC or 5400 (fill keeps 2400) · receipt 6e 'RoundAll 修正後 · 擷取 RED:逾時 N 秒' → step 5 re-fetches again (VDF engine caches MOPS responses 12 h) · close-out: 6e rows (step 5 / step / last_error / lock) share one root; 13b rows join it while 6e is incomplete, own root otherwise · owner text for the RoundAll time limit · selftest 72",
                  "HandleAll_v0110": "$PSStyle.Progress.MaxWidth = half the window width while running (CJK / circled digits / middle dots take two cells; a wrapped progress line is redrawn with the wrong line count and piles up) · Handle-All stage bar completed while RoundAll runs (only its real-percent bar) · ASCII activity · ceilings full 8 h / other 4 h · restore MaxWidth at the end"},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0117.py", "sha256": r161["roundall"]["sha256"], "status": "superseded 2026-10-31 (step 5 6e re-fetch fixed at 2400 s · 6e / 13b rows counted separately); file kept in vrn2_release_v0161"}],
        "roundall": {"name": "VRN2_RoundAll_v0118.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0118.md"},
        "handleall": {"name": "VRN2_HandleAll_v0110.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0110_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "not_fixed_here": r161["not_fixed_here"], "results": {"status": "see VRN2_Verification_v0162.md"}}
(rel / "VRN2_Release_v0162.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
