VRN2_Closeout_v0163 — VRN-2 closeout package (2026-10-31 · no MOPS)

Entry: python ActivateVRN-2_v0163.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0119.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0111.md (same release folder).
Runtime: VRN2_Runtime_v0156.zip unchanged.

v0163 (operator 2026-10-31 '不可用 MOPS · 全部國內使用 TWSE TPEX'): step 6e passes --no-financial to the shared MarketFetch --fetch, so the
 borrowed VDF engine never asks MOPS for financial statements; prices / indices / universe stay on the official TWSE / TPEX lanes. MOPS financial
 data already on disk (market/vdf/parquet/tw_financial, market/vdf/tw_financial.parquet) is moved (not deleted) to market/vdf/_mops_quarantine_<stamp>.
v0158: step 3b OCR environment: no venv, no pip from VRN-2 · v0157: step 3 check-only · missing packages through VCGC's install gate.
Verification: see VRN2_Verification_v0163.md. Hashes: PACKAGE_SHA256.json.
