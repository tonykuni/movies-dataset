"""v0163(冪等):套件 VRN2_Closeout_v0163.zip(啟動器 v0163 · runtime v0156 原樣)→ RoundAll v0119(填套件雜湊)→ Handle-All v0111 → 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單。
vrn2_release_v0162 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v163"); pkg, rel = W / "pkg163", W / "release163"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v162/release162")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r158 = json.loads((REPO / "vrn2_release_v0158/VRN2_Release_v0158.json").read_text(encoding="utf-8"))
r162 = json.loads((REPO / "vrn2_release_v0162/VRN2_Release_v0162.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0156.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == r158["runtime"]["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0156.zip").read_bytes()).hexdigest()   # runtime v0156 原樣
old = {c["path"]: c["sha256"] for c in r158["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0163.py", "VRN2_Runtime_v0156.zip", "VRN2_Runtime_v0156.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n != "ActivateVRN-2_v0163.py":
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0158 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0163 — VRN-2 closeout package (2026-10-31 · no MOPS)\n\n"
  "Entry: python ActivateVRN-2_v0163.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0119.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0111.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0156.zip unchanged.\n\n"
  "v0163 (operator 2026-10-31 '不可用 MOPS · 全部國內使用 TWSE TPEX'): step 6e passes --no-financial to the shared MarketFetch --fetch, so the\n"
  " borrowed VDF engine never asks MOPS for financial statements; prices / indices / universe stay on the official TWSE / TPEX lanes. MOPS financial\n"
  " data already on disk (market/vdf/parquet/tw_financial, market/vdf/tw_financial.parquet) is moved (not deleted) to market/vdf/_mops_quarantine_<stamp>.\n"
  "v0158: step 3b OCR environment: no venv, no pip from VRN-2 · v0157: step 3 check-only · missing packages through VCGC's install gate.\n"
  "Verification: see VRN2_Verification_v0163.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0163.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0163", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0163.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0163/" + n, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0119.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0163"' in ra and 'VERSION = "v0119"' in ra
(rel / "VRN2_RoundAll_v0119.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0162'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0163'")
rep("$F = 'VRN2_RoundAll_v0118.py'", "$F = 'VRN2_RoundAll_v0119.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0110", "Handle-All v0111", ha.count("Handle-All v0110"))
rep("v0158", "v0163", ha.count("v0158"))
rep("⑥e 擷取鎖過期 → 移開後重抓 ⑥e", "⑥e 不用 MOPS(MOPS 財報移開 · 只用 TWSE / TPEX)· 擷取鎖過期 → 移開後重抓 ⑥e")
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if "v0110" in l and not l.lstrip().startswith("#")]
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0162", "vrn2_release_v0163"), ("VRN2_HandleAll_v0110.md", "VRN2_HandleAll_v0111.md"), ("Handle-All v0110 SHA-256 OK", "Handle-All v0111 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0111_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0163/VRN2_HandleAll_v0111_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0111(2026-10-31 · 不用 MOPS · 套件 v0163 · RoundAll v0119)

操作員 2026-10-31:「**不可用 MOPS · 全部國內使用 TWSE TPEX**」。

| 項目 | 現在 |
|---|---|
| ⑥e 市場擷取 | 借用的 MarketFetch `--fetch` 一律加 `--no-financial` → VDF 引擎不再打 MOPS 財報(它的財報資料集讀 mopsov.twse.com.tw)· 價格 / 指數 / 代號清單走 TWSE / TPEX 官方 |
| 已抓下的 MOPS 財報 | `market\\vdf\\parquet\\tw_financial`、`market\\vdf\\tw_financial.parquet` → 移到 `market\\vdf\\_mops_quarantine_<時間>`(**不刪**)· ④ 跑啟動器前 / ⑤ 自動修 / 啟動器 v0163 ⑥e 前都會做 |
| ⑤ 自動修(repair)| 有 MOPS 財報 → 移開 → 重抓價格(`--no-financial`)+ 重新填值 → ⑬b 重算 → Combined → 增量庫 → Workbench |
| ⑬b 歷史對齊 | 沒有 MOPS 歷史 → 灰「無歷史」(TWSE / TPEX 開放資料只有最新一季 · 沒有多年財報)|
| 套件 | `VRN2_Closeout_v0163.zip`(SHA-256 `%s` · 啟動器 v0163 · runtime v0156 原樣)|
| 一支 Python | `VRN2_RoundAll_v0119.py`(SHA-256 `%s` · 自測 74 項)|

共用 MarketFetch 與 VDF 引擎照舊只讀不改(只改 VRN-2 傳的參數與 VRN-2 自己的輸出夾)。

## 先看:你開的是哪一種視窗?

- 提示字元前面有 **PS** → PowerShell → 用「PowerShell 7 視窗」那段。
- 前面沒有 PS(例如 `[16:11:29.38] C:\\Users\\tonyk` 下一行 `>`)→ **cmd** → 用「cmd 視窗」那段。

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定)· 第 2 行 = 下面 PowerShell 那一行的編碼版(一樣核對 SHA-256 才執行)。要整輪才在第 2 行之前多貼 `set "VRN2_MODE=full"`。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)· 要整輪再貼 `$env:VRN2_MODE = 'full'`。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0111 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0119 `%s`)。

## 這次桌機貼下去會怎樣

- auto = repair:① 取套件 v0163 → ⑤ 計畫「MOPS 財報 → 移到 _mops_quarantine(不刪)」「MOPS 財報移開後重抓價格 + 重新填值」→ 日線走 TWSE / TPEX(十幾分鐘)→
  ⑬b 沒有 MOPS 歷史 → 灰 → Combined → 增量庫 → Workbench → 收尾頁自動開。
- 增量庫(OneDrive\\VRN2_out)裡 16:11 那輪已追加的 FinancialAligned 4584 列 / Deleted 38 列是用 MOPS 歷史算的 · 增量庫只增不刪 → 要不要清由你決定(見交接)。
- BLOCKED / REVIEW / DATA_GAP 都不是成功;VCGC 的 closeout_lamp 才是 VCGC 驗收。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0111.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0119.py(套件 v0163 · 不用 MOPS)

`VRN2_RoundAll_v0119.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0118 + 操作員 2026-10-31「不可用 MOPS · 全部國內使用 TWSE TPEX」:

| 改了什麼 | 說明 |
|---|---|
| 套件 v0163 | 啟動器 v0163:⑥e `--fetch` 一律 `--no-financial` · ⑥e 前把已落盤的 MOPS 財報移到 `_mops_quarantine`(不刪)· runtime v0156 原樣 |
| ④ 跑啟動器前 | 先移 MOPS 財報(啟動器也會做 · 先做不衝突)|
| ⑤ 自動修 | 有 MOPS 財報 → 移開 → 重抓價格(`--no-financial`)+ 重新填值 → ⑬b → Combined → 增量庫 → Workbench · ⑤ 重抓 ⑥e 也一律 `--no-financial` |

自測 74 項(v0118 的 72 項 + 73 ~ 74)。套件 `vrn2_release_v0163/VRN2_Closeout_v0163.zip`(SHA-256 `%s` · 本檔內已釘死)。**最省事:`VRN2_HandleAll_v0111.md`(cmd / PowerShell 各一段)**。

```bat
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0119.py" --only package,fix,report,closeout,pasteback
python "%%USERPROFILE%%\\Downloads\\VRN2_RoundAll_v0119.py"
```
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0119.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0163 (step 6e no MOPS) + VRN2_RoundAll_v0119 + VRN2_HandleAll_v0111", "date": "2026-10-31",
        "trigger": "操作員 2026-10-31:「不可用 MOPS · 全部國內使用 TWSE TPEX」(桌機 16:11 那輪 ⑤ 重抓 ⑥e 經 VDF 引擎逐檔打 MOPS 財報)",
        "policy": {"MOPS": "not used by VRN-2 (no request, MOPS-sourced financial data on disk moved aside · not deleted)", "domestic": "TWSE / TPEX official lanes (prices · indices · universe · monthly revenue)",
                   "open_question": "Yahoo: the VDF engine's daily adjusted-price factor (yfinance · engine has no switch) and VRN-2's YFinance consensus median (step 6f) are still used — asked the operator"},
        "base_package": {"name": "VRN2_Closeout_v0158 (launcher v0158 · runtime v0156)", "retained": "runtime v0156 zip byte-identical; every member except the launcher byte-identical to v0158"},
        "fixes": {"launcher_v0163": "market_fetch: --no-financial on --fetch · quarantine_mops_financial(output) before the fetch (market/vdf/_mops_quarantine_<stamp> · sequence suffix within one second) · step label '… · 不用 MOPS' · receipt VRN2_Closeout_v0163.json · selftest block v0163",
                  "RoundAll_v0119": "package v0163 · step 4 quarantines MOPS financial data before the launcher · step 5 plan: MOPS data on disk → mops_quarantine, then market (prices --no-financial + fill) → 13b → Combined → store → Workbench · step 5 re-fetch always --no-financial · selftest 74",
                  "HandleAll_v0111": "v0110 pointed at RoundAll v0119 (vrn2_release_v0163) · texts package v0163 / no MOPS"},
        "not_fixed_here": dict(r162["not_fixed_here"]) if isinstance(r162.get("not_fixed_here"), dict) else r162.get("not_fixed_here"),
        "store_note": "the incremental store (OneDrive VRN2_out) already holds FinancialAligned 4584 / Deleted 38 rows appended at 16:11 with MOPS history coverage · append-only · left as is · operator decides",
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0118.py", "sha256": r162["roundall"]["sha256"], "status": "superseded 2026-10-31 (package v0158 · 6e financial from MOPS); file kept in vrn2_release_v0162"}],
        "roundall": {"name": "VRN2_RoundAll_v0119.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0119.md"},
        "handleall": {"name": "VRN2_HandleAll_v0111.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0111_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0163/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0163.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0163.py"]).hexdigest()},
        "results": {"status": "see VRN2_Verification_v0163.md"}}
(rel / "VRN2_Release_v0163.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
