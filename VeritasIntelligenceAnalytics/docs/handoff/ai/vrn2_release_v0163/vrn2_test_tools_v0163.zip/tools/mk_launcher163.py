"""ActivateVRN-2_v0163.py = v0158 + ⑥e 不用 MOPS(操作員 2026-10-31「不可用 MOPS · 全部國內使用 TWSE TPEX」):MarketFetch --fetch 一律 --no-financial ·
已落盤的 MOPS 財報(market/vdf/parquet/tw_financial · tw_financial.parquet)移到 market/vdf/_mops_quarantine_<時間>(不刪)。runtime v0156 不動。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v160/pkg158/VRN2_Closeout_v0158/ActivateVRN-2_v0158.py")
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0158: v0157 entry + step 3b', '''"""VRN-2 v0163: v0158 entry + step 6e never touches MOPS (operator 2026-10-31 "不可用 MOPS · 全部國內使用 TWSE TPEX").

 - step 6e: the shared VRN2_MarketFetch --fetch always gets --no-financial, so the borrowed VDF engine is never asked for MOPS financial
   statements (its financial dataset reads mopsov.twse.com.tw); prices / indices / universe stay on the official TWSE / TPEX lanes.
 - financial statements already written by earlier runs (market/vdf/parquet/tw_financial, market/vdf/tw_financial.parquet) came from MOPS:
   they are moved (not deleted) to market/vdf/_mops_quarantine_<stamp> before the fetch, so --fill and step 13b no longer read them.
 - the shared MarketFetch and the VDF engine are read-only for VRN-2 (only the arguments VRN-2 passes and VRN-2's own output folder change).
 Runtime v0156 is used unchanged. Receipt VRN2_Closeout_v0163.json.

VRN-2 v0158: v0157 entry + step 3b''')
rep('VERSION = "ActivateVRN-2 v0158"', 'VERSION = "ActivateVRN-2 v0163"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0158.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0163.json"\nMOPS_DATASETS = ("parquet/tw_financial", "tw_financial.parquet")   # v0163: the VDF engine\'s financial dataset = MOPS statements')
rep('''def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:''', '''def quarantine_mops_financial(output: Path) -> str:
    """v0163: move MOPS-sourced financial data out of the way (market/vdf/_mops_quarantine_<stamp> · nothing deleted) · returns the folder name or ''."""
    vdf = Path(output) / "market" / "vdf"
    found = [vdf / rel for rel in MOPS_DATASETS if (vdf / rel).exists()]
    if not found:
        return ""
    base_name = "_mops_quarantine_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    target, n = vdf / base_name, 1
    while target.exists():                                                      # 同一秒第二次 → 加序號
        n += 1
        target = vdf / ("%s_%d" % (base_name, n))
    for item in found:
        dest = target / item.relative_to(vdf)
        dest.parent.mkdir(parents=True, exist_ok=True)
        item.replace(dest)
    return target.name


def market_fetch(root: Path, output: Path, steps: list, lim: dict) -> dict:''')
rep('''        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        fetch_py = fill_py = market_python()''', '''        wait = int(lim.get("VRN2_MARKET_WAIT", 1800))
        moved = quarantine_mops_financial(output)                              # v0163 不用 MOPS:舊的 MOPS 財報移開(不刪)
        if moved:
            print("[計] ⑥e 不用 MOPS · 已落盤的 MOPS 財報移到 market\\\\vdf\\\\%s(不刪)" % moved, flush=True)
        fetch_py = fill_py = market_python()''')
rep('''            command = head + [verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)]''',
    '''            command = head + [verb, "--basic", str(basic), "--out", str(market), "--timeout", str(wait)] + (["--no-financial"] if verb == "--fetch" else [])   # v0163 不抓 MOPS 財報''')
rep('''        detail = "%s · Python %s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, py_label, fetched.get("lamp", "—"), fetched.get("msg", ""), filled.get("lamp", "—"), filled.get("msg", "沒跑"))''',
    '''        detail = "%s · Python %s · 不用 MOPS(--no-financial)%s · 擷取 %s:%s · 填值 %s:%s" % (tool.name, py_label, (" · MOPS 財報移到 " + moved) if moved else "", fetched.get("lamp", "—"), fetched.get("msg", ""), filled.get("lamp", "—"), filled.get("msg", "沒跑"))''')
rep('''                 "runner": runner.name if runner.is_file() else "", "fetch_python": picked}''', '''                 "runner": runner.name if runner.is_file() else "", "fetch_python": picked, "no_mops": True, "mops_quarantine": moved}''')
rep('''    steps.append({"step": "⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 MarketFetch)", "lamp": lamp, "detail": detail[:300]})''',
    '''    steps.append({"step": "⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 MarketFetch · 不用 MOPS)", "lamp": lamp, "detail": detail[:300]})''')
rep('''        return lamp, detail + " · launcher v0158"''', '''        return lamp, detail + " · launcher v0163"''')
rep("(launcher v0158); manager v0257", "(launcher v0163 · no MOPS); manager v0257")
rep('''    print("NEXT: [%s] VRN-2 v0158 · rc %s''', '''    print("NEXT: [%s] VRN-2 v0163 · rc %s''')
rep('''    ocr_src = selftest_source(BASE_NAME).read_text(encoding="utf-8")''', '''    with tempfile.TemporaryDirectory(prefix="vrn2-v0163-check-") as temporary:
        out163 = Path(temporary) / "VIA" / "VIA_Reports" / "vrn2"
        vdf163 = out163 / "market" / "vdf"
        fin163 = vdf163 / "parquet" / "tw_financial" / "ticker=2330" / "year=2025"
        fin163.mkdir(parents=True)
        (fin163 / "data.parquet").write_bytes(b"mops")
        (vdf163 / "tw_financial.parquet").write_bytes(b"mops")
        (vdf163 / "parquet" / "tw_equity_daily").mkdir(parents=True)
        moved163 = quarantine_mops_financial(out163)
        q163 = vdf163 / moved163
        assert moved163.startswith("_mops_quarantine_") and (q163 / "parquet" / "tw_financial" / "ticker=2330" / "year=2025" / "data.parquet").read_bytes() == b"mops"
        assert (q163 / "tw_financial.parquet").is_file() and not (vdf163 / "parquet" / "tw_financial").exists() and not (vdf163 / "tw_financial.parquet").exists()
        assert (vdf163 / "parquet" / "tw_equity_daily").is_dir() and quarantine_mops_financial(out163) == ""                            # prices stay · nothing left to move
        root163 = Path(temporary) / "VIA"
        shared163 = root163 / "functional modules" / "VRN"
        shared163.mkdir(parents=True)
        (shared163 / "VRN2_MarketFetch_v0112.py").write_text("import sys\\nprint('[計] 市場%s · GREEN · nofin=%s' % ('擷取' if '--fetch' in sys.argv else '填值', '--no-financial' in sys.argv))\\n", encoding="utf-8")
        (out163 / "output").mkdir(parents=True)
        (out163 / "output" / "VRN2_BasicInfo_latest.json").write_text("[]", encoding="utf-8")
        fin163.mkdir(parents=True)
        (fin163 / "data.parquet").write_bytes(b"mops2")
        saved163 = os.environ.pop("VIA_VRN2_NO_MARKET", None)
        try:
            steps163 = []
            got163 = market_fetch(root163, out163, steps163, {"VRN2_MARKET_WAIT": 120})
        finally:
            if saved163 is not None:
                os.environ["VIA_VRN2_NO_MARKET"] = saved163
        assert got163["results"]["--fetch"]["msg"].endswith("nofin=True") and got163["results"]["--fill"]["msg"].endswith("nofin=False")
        assert got163["no_mops"] and got163["mops_quarantine"].startswith("_mops_quarantine_") and not (vdf163 / "parquet" / "tw_financial").exists()
        assert steps163[-1]["step"].startswith("⑥e 市場擷取") and "不用 MOPS" in steps163[-1]["step"] and "不用 MOPS(--no-financial)" in steps163[-1]["detail"]
    print("[PASS] v0163: step 6e never asks for MOPS · MarketFetch --fetch gets --no-financial (--fill unchanged) · MOPS financial data already on disk "
          "moved to market/vdf/_mops_quarantine_<stamp> (nothing deleted · prices stay)")
    ocr_src = selftest_source(BASE_NAME).read_text(encoding="utf-8")''')
assert "datetime" in s.split("def load_base")[0]
out = Path("/home/user/vrn2_work/v163/pkg163/ActivateVRN-2_v0163.py")
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0163 lines", s.count("\n"))
