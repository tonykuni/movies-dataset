#!/bin/bash
# v0163 e2e:沙盒(桌機 v0153 狀態)+ 假的 MOPS 財報(market/vdf/parquet/tw_financial · tw_financial.parquet)→ repair ⑤ 移開 · 整輪 ④ 移開 + 啟動器 v0163 ⑥e 不用 MOPS · 竄改 → 不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v163; T=$W/t163a; P=$S2/venv_vrn2/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
B=$T.br; D=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0163; mkdir -p $D
cp $W/release163/VRN2_Closeout_v0163.zip $W/release163/VRN2_Release_v0163.json $W/release163/VRN2_RoundAll_v0119.py $W/release163/VRN2_RoundAll_v0119.md $W/release163/VRN2_HandleAll_v0111.md $W/release163/VRN2_HandleAll_v0111_boot.txt $D/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release163/tiny_line.txt)
LINE="$LINE; 'PYPROG=' + (\$global:VIA_PYPROG_LAST | ConvertTo-Json -Compress)"
VD=$T/VIA/VIA_Reports/vrn2/market/vdf
mops() { mkdir -p "$VD/parquet/tw_financial/ticker=2330/year=2025" && printf 'mops' > "$VD/parquet/tw_financial/ticker=2330/year=2025/data.parquet" && printf 'mops' > "$VD/tw_financial.parquet"; }
run() { N=$1; shift; cd "$T/home" && env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 \
  VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2 "$@" timeout 3000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny163.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; (cd $VD && find . -maxdepth 3 | sort) > $W/vdf_after_$N.txt; }
rm -f $W/tiny163.rc
mops; run repair
mops; run full VRN2_MODE=full
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0163/VRN2_HandleAll_v0111_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny163.rc
python3 -c "
import json,glob
r=json.load(open('$T/VIA/VIA_Reports/vrn2/VRN2_Closeout_v0163.json',encoding='utf-8'))
e=[s for s in r['steps'] if s['step'].startswith('⑥e')]
print('receipt', r.get('version'), '·', e[0]['step'] if e else '-', '·', (e[0]['detail'][:160] if e else ''))
print('market', {k: r.get('market',{}).get(k) for k in ('no_mops','mops_quarantine')})
" >> $W/tiny163.rc 2>&1
