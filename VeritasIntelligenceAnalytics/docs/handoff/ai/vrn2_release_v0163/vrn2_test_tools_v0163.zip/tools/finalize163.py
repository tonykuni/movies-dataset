"""v0163 收尾:驗證紀錄 · 交接 v0164(從 v0163 抄 · 只增)· 放進倉 vrn2_release_v0163 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v163"); rel = W / "release163"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    return x.replace(str(W / "t163a"), "<sbx>").replace(str(W), "<w>").replace(SCR, "<scratch>").replace(SCR0, "<scratch0>")


R = json.loads((rel / "VRN2_Release_v0163.json").read_text(encoding="utf-8"))
st = [l for l in lines(W / "rall119_selftest.log") if re.search(r"^\[PASS\] 7[34] |^\[FAIL\]|--selftest · ", l)]
stv = [l for l in lines(W / "rall119_selftest_venv.log") if "--selftest · " in l]
lst = [l[:170] for l in lines(W / "launcher163_selftest.log") if l.startswith("[PASS] v0163") or l.startswith("[FAIL]")]
ps = json.loads((W / "pscheck163.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny163.rc") if l.strip()]
pat = r"boot:|boot SHA|不用 MOPS|MOPS 財報|===== 收尾|\[(VRN-2|人工|VCGC)\] \d"
e2e = {n: [short(l)[:190] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)] for n in ("repair", "full", "tamper")}
vdf = {n: [l for l in lines(W / ("vdf_after_%s.txt" % n)) if "quarantine" in l and l.count("/") <= 2] for n in ("repair", "full")}
R["results"] = {"selftest": st, "selftest_venv": stv, "launcher_selftest": lst, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "vdf_folder_after": vdf,
                "not_run": "the desktop re-fetch of prices with --no-financial (no Python inside the VDF engine's bounds in the container) · the MOPS data on the desktop (moved by the next repair)"}
(rel / "VRN2_Release_v0163.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0163 驗證紀錄(2026-10-31 · 不用 MOPS · 套件 v0163 · RoundAll v0119 · Handle-All v0111)

## 1. 起因

操作員 2026-10-31:「**不可用 MOPS · 全部國內使用 TWSE TPEX**」。桌機 16:11 那輪 ⑤ 重抓 ⑥e 經借用的 VDF 引擎逐檔打 MOPS 財報
(引擎 `def_collect_financial` 讀 `mopsov.twse.com.tw/mops/web/ajax_t164sb…` · `latest` 只用 TWSE / TPEX 開放資料決定季別),
⑬b 歷史對齊與增量庫的 FinancialAligned 因此用了 MOPS 歷史。

## 2. 修法(共用 MarketFetch 與 VDF 引擎只讀不改 · 只改 VRN-2 傳的參數與 VRN-2 自己的輸出夾)

| 檔 | 內容 |
|---|---|
| 啟動器 v0163(`%s`)| ⑥e `MarketFetch --fetch` 一律 `--no-financial`(MarketFetch 原本就有這個開關)· ⑥e 前把已落盤的 MOPS 財報(`market/vdf/parquet/tw_financial` · `tw_financial.parquet`)移到 `market/vdf/_mops_quarantine_<時間>`(不刪 · 同一秒第二次加序號)· 步驟名「… · 不用 MOPS」· 收據 v0163 |
| 套件 v0163(`%s`)| 啟動器 v0163 + 其他成員跟 v0158 逐位元組相同 · runtime v0156 原樣 |
| RoundAll v0119(`%s`)| 釘套件 v0163 · ④ 跑啟動器前先移 MOPS 財報 · ⑤ 有 MOPS 財報 → 移開 → 重抓價格(`--no-financial`)+ 重新填值 → ⑬b → Combined → 增量庫 → Workbench · ⑤ 重抓一律 `--no-financial` · 自測 74 |
| Handle-All v0111(一行 `%s` · 開機檔 `%s`)| 指向 RoundAll v0119 · 最短一行 %d 字元 · cmd 一行 %d 字元 |

國內資料來源:價格 / 指數 / 代號清單 / 月營收 = TWSE / TPEX 官方(openapi.twse.com.tw · tpex.org.tw)· 財報不抓(TWSE / TPEX 開放資料只有最新一季 · 沒有多年財報 → ⑬b 灰「無歷史」)。

## 3. 測試

```text
%s
venv(有 PyMuPDF):%s
啟動器 v0163 自測(從套件 zip 解開 · venv):
%s
%s
e2e:%s
```

VCGC 全景骨架卡:RoundAll v0119 SWALLOW 10 項(同 v0118)· 啟動器 v0163 4 項(同 v0158)。

## 4. e2e(桌機 v0153 狀態沙盒 · 放假的 MOPS 財報 · 沙盒 GitHub 分支 · pwsh 7.4.6)

```text
%s
```

輸出夾事後:%s

**沒跑到的**:桌機上用 `--no-financial` 真的重抓價格(容器沒有合 VDF 界線的 Python)· 桌機上的 MOPS 財報(下一輪 repair 的 ⑤ 會移開)。

## 5. 還在用的非 TWSE / TPEX 來源(已問操作員)

- **Yahoo 還原價**:VDF 引擎日線的還原因子(yfinance · 引擎設定註明是「user-authorized」例外 · 引擎沒有關掉的開關 · VDF 的事)→ Combined 的 TARGET_PRICE(ADJ) 靠它。
- **YFinance 共識中位數**(⑥f · VRN-2 自己的)· **鉅亨 FactSet 共識**(⑥f)—— 這兩個是分析師共識,不是交易所資料。

## 6. 增量庫

OneDrive\\VRN2_out 的增量庫在 16:11 那輪已追加 FinancialAligned 4584 列 / Deleted 38 列(用了 MOPS 歷史)· 增量庫只增不刪 · 沒動 · 要不要清由操作員決定。
""" % (R["launcher"]["sha256"][:12], R["package"]["sha256"][:12], R["roundall"]["sha256"][:12], H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], H["cmd_line_chars"],
       "\n".join(st), " ".join(stv), "\n".join(lst), pparse, " · ".join(rc), "\n".join("[%s] " % n + l for n in e2e for l in e2e[n]),
       " · ".join("%s → %s" % (n, ", ".join(v)) for n, v in vdf.items()))
(rel / "VRN2_Verification_v0163.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0163.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0158 + VRN2_RoundAll_v0118 + VRN2_HandleAll_v0110 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0163 + VRN2_RoundAll_v0119 + VRN2_HandleAll_v0111 · 2026-10-31(操作員:不可用 MOPS · 全部國內使用 TWSE TPEX → "
        "⑥e 一律 --no-financial · 已落盤的 MOPS 財報移到 _mops_quarantine(不刪)· 套件 v0163)")
src = "\n".join(L)
once("> **本輪(v0162)**",
     "> **本輪(v0163)**:操作員 2026-10-31「**不可用 MOPS · 全部國內使用 TWSE TPEX**」。借用的 VDF 引擎財報資料集讀 MOPS(`ajax_t164sb`)→ "
     "**啟動器 v0163 / RoundAll v0119**:⑥e 的 MarketFetch `--fetch` 一律 `--no-financial` · 已落盤的 MOPS 財報(`market/vdf/parquet/tw_financial` · `tw_financial.parquet`)"
     "移到 `market/vdf/_mops_quarantine_<時間>`(不刪)· ⑤ 有 MOPS 財報 → 移開 → 重抓價格 + 重新填值 → ⑬b(無歷史)→ Combined → 增量庫 → Workbench · 套件 v0163(其他成員跟 v0158 逐位元組相同)· "
     "**Handle-All v0111**(最短一行 %d 字元 · cmd 一行 %d 字元)。**未決**:Yahoo 還原價(VDF 引擎 · 沒有開關)/ YFinance 與鉅亨 FactSet 共識(⑥f)要不要也停 —— 已問操作員;"
     "增量庫 16:11 追加的 FinancialAligned 4584 / Deleted 38 列用了 MOPS 歷史 · 沒動。\n"
     "> **本輪(v0162)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
once("| **VRN2_HandleAll_v0110.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0110** | `vrn2_release_v0162` |",
     "| **VRN2_HandleAll_v0111.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0111** | `vrn2_release_v0163` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0119 · 不用 MOPS)|\n"
     "| **VRN2_RoundAll_v0119.py**(發行夾 · 一支入口 · 不在套件內)| **v0119** | `vrn2_release_v0163` | `%s` | **新**(套件 v0163 · 不用 MOPS · MOPS 財報移開 · 自測 74 項)|\n"
     "| **VRN2_Closeout_v0163.zip**(發行夾 · 套件)| **v0163** | `vrn2_release_v0163` | `%s` | **新**(啟動器 v0163 · runtime v0156 原樣)|\n"
     "| **VRN2_HandleAll_v0110.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0110** | `vrn2_release_v0162` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12]))
r162 = json.loads((REPO / "vrn2_release_v0162/VRN2_Release_v0162.json").read_text(encoding="utf-8"))
once("| **VRN2_RoundAll_v0118.py**(發行夾 · 一支入口 · 不在套件內)| **v0118** | `vrn2_release_v0162` | `%s` | **新**(" % r162["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0118.py**(發行夾 · 一支入口 · 不在套件內)| **v0118** | `vrn2_release_v0162` | `%s` | 被 v0119 取代(套件 v0158 · ⑥e 財報打 MOPS)· (" % r162["roundall"]["sha256"][:12])
once("| ActivateVRN-2_v0158.py(套件 · 底座 v0136 · runtime v0156)| **v0158** |",
     "| ActivateVRN-2_v0163.py(套件 · 底座 v0136 · runtime v0156)| **v0163** | 見發行清單 | `%s` | **新**(⑥e --no-financial · MOPS 財報移到 _mops_quarantine · 收據 v0163)|\n"
     "| ActivateVRN-2_v0158.py(套件 · 底座 v0136 · runtime v0156)| **v0158** |" % R["launcher"]["sha256"][:12])
once("| 0 | **(v0162)**",
     "| 0 | **(v0163)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"` 再貼 `vrn2_release_v0163/VRN2_HandleAll_v0111.md` 的 cmd 一行 → repair:取套件 v0163 → ⑤ MOPS 財報移開 → 重抓價格(`--no-financial`)→ "
     "⑬b 無歷史 → 收尾 · **上傳貼回包** · 回覆 Yahoo / 共識要不要也停 · 增量庫 MOPS 列要不要清 | 貼回 / 決定 |\n"
     "| 0 | **(v0162)**")
once("**v0162(2026-10-31)**:", "**v0163(2026-10-31)**:操作員令不可用 MOPS · 國內全用 TWSE / TPEX → 啟動器 v0163 / RoundAll v0119 ⑥e 一律 --no-financial · MOPS 財報移到 _mops_quarantine(不刪)· 套件 v0163;Handle-All v0111。\n\n**v0162(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0163)** **不可用 MOPS(操作員 2026-10-31)**:國內資料一律 TWSE / TPEX 官方。VRN-2 叫 ⑥e 時一律 `--no-financial`;任何 MOPS 來的資料(VDF 引擎的 tw_financial)"
     "移到 `_mops_quarantine`(不刪)· 不要再用它算 ⑬b / FinancialAligned。網路工具「放行 MOPS」不等於可以用 —— 政策優先。\n"
     "- **(v0163)** **別系統工具的資料來源由 VRN-2 傳的參數控制**:VDF 引擎 / 共用 MarketFetch 照舊只讀不改;要換來源先找它們已有的開關(這次是 MarketFetch 的 `--no-financial`),沒有開關就攤開給該系統。\n\n")
(REPO / "VRN2_Handover_v0164.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0163"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0163.zip", "VRN2_RoundAll_v0119.py", "VRN2_RoundAll_v0119.md", "VRN2_HandleAll_v0111.md", "VRN2_HandleAll_v0111_boot.txt", "VRN2_Release_v0163.json", "VRN2_Verification_v0163.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t163a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0163.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / "rall119_selftest.log", W / "rall119_selftest_venv.log", W / "launcher163_selftest.log", W / "pscheck163.log", W / "tiny163.rc"] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("vdf_after_*.txt")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0163.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_launcher163.py", "mk_roundall119.py", "build163.py", "finalize163.py", "e2e163.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0164", src.count("\n"))
