"""VRN2_RoundAll_v0119.py = v0118(倉裡 vrn2_release_v0162)+ 不用 MOPS(操作員 2026-10-31「不可用 MOPS · 全部國內使用 TWSE TPEX」)· 套件 v0163(啟動器 v0163)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v163")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0162/VRN2_RoundAll_v0118.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0118')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0118 — ', '"""VRN2_RoundAll v0119 — ', 1)
at = doc.index("v0118(桌機 2026-10-31 16:11")
doc = doc[:at] + '''v0119(操作員 2026-10-31:「不可用 MOPS · 全部國內使用 TWSE TPEX」):
  · 套件 v0163(啟動器 v0163 · runtime 沿用 v0156):⑥e 借用的 MarketFetch --fetch 一律加 --no-financial → VDF 引擎不再打 MOPS 財報
    (它的財報資料集讀 mopsov.twse.com.tw)· 價格 / 指數 / 代號清單照舊走 TWSE / TPEX 官方。
  · 已落盤的 MOPS 財報(market\\\\vdf\\\\parquet\\\\tw_financial · tw_financial.parquet)移到 market\\\\vdf\\\\_mops_quarantine_<時間>(不刪):
    ④ 跑啟動器前 · ⑤ 自動修(有 → 移開 → 重抓價格 + 重新填值 → ⑬b 重算 → Combined → 增量庫 → Workbench)。
  · ⑤ 重抓 ⑥e 也加 --no-financial。⑬b 歷史對齊因此沒有 MOPS 歷史(TWSE / TPEX 開放資料只有最新一季 · 沒有多年財報)→ 灰「無歷史」。
  · 共用 MarketFetch 與 VDF 引擎照舊只讀不改(只改 VRN-2 傳的參數與 VRN-2 自己的輸出夾)。自測 74 項(v0118 的 72 項 + 73 ~ 74)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0118.py", "用法:python VRN2_RoundAll_v0119.py")
keep = {"v0114 啟動器 v0158 不建 OCR venv": "@K2@",
        "③b OCR 隔離環境沒就緒(啟動器 v0158 不建不 pip)": "@K3@"}
for a, b in keep.items():
    assert body.count(a) == 1, a
    body = body.replace(a, b)
body = body.replace("v0158", "v0163")
for a, b in keep.items():
    body = body.replace(b, a)
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0118"', 'VERSION = "v0119"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0118.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0119.py"', 2)
rep('"VRN2_RoundAll_v0118.py" in html_', '"VRN2_RoundAll_v0119.py" in html_')
rep('PACKAGE_SHA256 = "dfca4f6b13fb7ce727184ab25721cb8d7ea14c6c989b10cfbf7e7f662edced62"', 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
rep("· v0118 起 72 項。", "· v0118 起 72 項 · v0119 起 74 項。")
assert 'PACKAGE = "VRN2_Closeout_v0163"' in s and 'LAUNCHER = "ActivateVRN-2_v0163.py"' in s and 'RECEIPT = "VRN2_Closeout_v0163.json"' in s and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0163"' in s

# ---- 不用 MOPS:隔離 + --no-financial ----
rep('''def market_fetch_sec() -> int:''', '''MOPS_DATASETS = ("parquet/tw_financial", "tw_financial.parquet")          # v0119 VDF 引擎的財報資料集 = MOPS 財報


def quarantine_mops_financial(v2) -> str:
    """v0119 不用 MOPS:已落盤的 MOPS 財報移到 market/vdf/_mops_quarantine_<時間>(不刪 · 同一秒第二次加序號)· 回夾名或 ''。"""
    vdf = Path(v2) / "market" / "vdf"
    found = [vdf / rel for rel in MOPS_DATASETS if (vdf / rel).exists()]
    if not found:
        return ""
    base_name = "_mops_quarantine_" + stamp()
    target, n = vdf / base_name, 1
    while target.exists():
        n += 1
        target = vdf / ("%s_%d" % (base_name, n))
    for item in found:
        dest = target / item.relative_to(vdf)
        dest.parent.mkdir(parents=True, exist_ok=True)
        item.replace(dest)
    return target.name


def market_fetch_sec() -> int:''')
rep('''    """v0118 ⑤ 重抓 ⑥e 的擷取上限(秒):MOPS 財報一檔約 30 秒 · 補缺 + latest 常常要 50 ~ 60 分 → 預設 5400 · VRN2_MARKET_FETCH_SEC 可調。"""''',
    '''    """v0118 ⑤ 重抓 ⑥e 的擷取上限(秒):預設 5400 · VRN2_MARKET_FETCH_SEC 可調(v0119 起不抓 MOPS 財報 · 只剩價格 · 通常十幾分鐘)。"""''')
rep('''                rc, lines = run_stream(head + [verb, "--basic", str(basic), "--out", str(v2 / "market")], cwd=tool.parent''',
    '''                rc, lines = run_stream(head + [verb, "--basic", str(basic), "--out", str(v2 / "market")] + (["--no-financial"] if verb == "--fetch" else []), cwd=tool.parent''')
rep('''    cmd = [vpy, "-X", "utf8", str(Path(pkg) / LAUNCHER)]
    src = args.source or os.environ.get("VRN2_SOURCE") or ""''', '''    try:
        moved = quarantine_mops_financial(Path(root) / "VIA_Reports" / "vrn2")   # v0119 不用 MOPS(啟動器 v0163 也會做 · 先做不衝突)
        if moved:
            say("GREEN", "④ 不用 MOPS", "已落盤的 MOPS 財報移到 market\\\\vdf\\\\%s(不刪 · ⑬b 不再用它)" % moved)
    except OSError as error:
        say("YELLOW", "④ 不用 MOPS", "MOPS 財報移不開(%s)· 啟動器 v0163 會再移一次" % type(error).__name__)
    cmd = [vpy, "-X", "utf8", str(Path(pkg) / LAUNCHER)]
    src = args.source or os.environ.get("VRN2_SOURCE") or ""''')
rep('''    lk = vdf_lock_state(v2)                                                    # v0117 ⑥e 擷取鎖''', '''    mops_on_disk = [rel for rel in MOPS_DATASETS if (v2 / "market" / "vdf" / rel).exists()]   # v0119 不用 MOPS
    if mops_on_disk:
        plan.append(("mops_quarantine", "MOPS 財報(操作員 2026-10-31:不可用 MOPS)移到 market\\\\vdf\\\\_mops_quarantine(不刪)"))
        if market_tool and fetch_py and os.environ.get("VIA_VRN2_NO_MARKET") != "1":
            plan.append(("market", "MOPS 財報移開後重抓價格 + 重新填值(--no-financial · 只用 TWSE / TPEX)· ⑬b 跟著重算"))
    lk = vdf_lock_state(v2)                                                    # v0117 ⑥e 擷取鎖''')
rep('''    if (lock_hit and market_tool and fetch_py and not (lk.get("exists") and not lk.get("stale")) and market.get("lamp") in ("YELLOW", "RED")
            and os.environ.get("VIA_VRN2_NO_MARKET") != "1"):''', '''    if (lock_hit and market_tool and fetch_py and not (lk.get("exists") and not lk.get("stale")) and market.get("lamp") in ("YELLOW", "RED")
            and os.environ.get("VIA_VRN2_NO_MARKET") != "1" and not any(k == "market" for k, _ in plan)):''')
rep("⑥e 上一輪被擷取鎖擋住 → 鎖移開後重抓(價格 + 財報補缺 · 擷取 Python %s)", "⑥e 上一輪被擷取鎖擋住 → 鎖移開後重抓(價格 · 不用 MOPS · 擷取 Python %s)")
rep("接著抓(MOPS 回應 12 小時內有快取 · 這次上限 %d 秒)", "接著抓(價格 · 不用 MOPS · 這次上限 %d 秒)")
rep('''        return "VRN-2", "RoundAll 重抓 ⑥e 到上限被停(MOPS 財報一檔約 30 秒)→ v0118 起上限 %d 秒 · 再跑 repair 會接著抓(已抓的有快取)" % market_fetch_sec()''',
    '''        return "VRN-2", "RoundAll 重抓 ⑥e 到上限被停 → 上限 %d 秒 · v0119 起不抓 MOPS 財報(只剩價格)· 再跑 repair 會重抓" % market_fetch_sec()''')
rep('''        elif key == "vdf_lock":                                                # v0117 再看一次才移(避免剛好有新的擷取起來)''', '''        elif key == "mops_quarantine":                                         # v0119 不用 MOPS
            try:
                moved = quarantine_mops_financial(v2)
                lamp, detail = "GREEN", ("MOPS 財報移到 market\\\\vdf\\\\%s(不刪)" % moved) if moved else "MOPS 財報已經不在"
            except OSError as error:
                lamp, detail = "YELLOW", "MOPS 財報移不開(%s)" % type(error).__name__
        elif key == "vdf_lock":                                                # v0117 再看一次才移(避免剛好有新的擷取起來)''')

# ---- 自測 73 ~ 74 ----
rep('''        src64 = Path(__file__).read_text(encoding="utf-8")''', '''        v73 = td / "v73"
        vdf73 = v73 / "VIA_Reports" / "vrn2" / "market" / "vdf"
        (vdf73 / "parquet" / "tw_financial" / "ticker=2330" / "year=2025").mkdir(parents=True)
        (vdf73 / "parquet" / "tw_financial" / "ticker=2330" / "year=2025" / "data.parquet").write_bytes(b"mops")
        (vdf73 / "tw_financial.parquet").write_bytes(b"mops")
        (vdf73 / "parquet" / "tw_equity_daily").mkdir(parents=True)
        (vdf73.parent / "VRN2_Market_latest.json").write_text("{}", encoding="utf-8")
        rc73 = {"market": {"lamp": "GREEN", "detail": "擷取 GREEN", "runner": "VRN2_MarketFetchRun_v0100.py"}, "steps": []}
        p73a = [k for k, _ in plan_fixes(v73, rc73, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")]
        p73b = [k for k, _ in plan_fixes(v73, rc73, None, A(), "")]
        m73a = quarantine_mops_financial(v73 / "VIA_Reports" / "vrn2")
        (vdf73 / "tw_financial.parquet").write_bytes(b"mops2")
        m73b = quarantine_mops_financial(v73 / "VIA_Reports" / "vrn2")
        p73c = [k for k, _ in plan_fixes(v73, rc73, "/py/python", A(), "/tools/VRN2_MarketFetch_v0112.py")]
        chk("73 不用 MOPS:已落盤的 MOPS 財報(tw_financial)→ ⑤ 先移到 _mops_quarantine(不刪 · 同一秒第二次加序號)再重抓價格 + 重新填值 · 沒有擷取 Python 也照移 · 移完就不再排 · 價格資料不動",
            p73a[:2] == ["mops_quarantine", "market"] and "history" in p73a and p73b[:1] == ["mops_quarantine"] and "market" not in p73b
            and m73a.startswith("_mops_quarantine_") and (vdf73 / m73a / "parquet" / "tw_financial" / "ticker=2330" / "year=2025" / "data.parquet").read_bytes() == b"mops"
            and m73b.startswith("_mops_quarantine_") and m73b != m73a and (vdf73 / "parquet" / "tw_equity_daily").is_dir() and "mops_quarantine" not in p73c)
        src74 = Path(__file__).read_text(encoding="utf-8")
        chk("74 ⑤ 重抓 ⑥e 的 --fetch 帶 --no-financial(--fill 不帶)· ④ 跑啟動器前先移 MOPS 財報 · 套件 / 啟動器 v0163(--no-financial 也在啟動器裡)",
            src74.count('+ (["--no-' + 'financial"] if verb == "--fetch" else [])') == 1 and src74.count("moved = quarantine_" + "mops_financial(Path(root)") == 1
            and LAUNCHER == "ActivateVRN-2_v0163.py" and PACKAGE == "VRN2_Closeout_v0163")
        src64 = Path(__file__).read_text(encoding="utf-8")''')
out = W / "new" / "VRN2_RoundAll_v0119.py"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0119 lines", s.count("\n"), "· v0158 left in body:", len(re.findall("v0158", s[s.index('VERSION = "v0119"'):])))
