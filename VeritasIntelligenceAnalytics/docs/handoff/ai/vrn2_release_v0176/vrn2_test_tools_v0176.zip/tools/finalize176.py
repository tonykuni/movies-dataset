"""v0176 收尾:驗證紀錄 · 交接 v0177(從 v0176 抄 · 只增)· 收尾規格 §13(只增)· 放進倉 vrn2_release_v0176 · logs / 工具 zip。桌機 / 上傳資料不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v176"); rel = W / "release176"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def last(p):
    return [l for l in lines(p) if l.strip()][-1]


R = json.loads((rel / "VRN2_Release_v0176.json").read_text(encoding="utf-8"))
H = R["handleall"]
ra = [l for l in lines(W / "rall132_selftest.log") if re.search(r"^\[FAIL\]|--selftest · ", l)]
assert ra and "· 不過 0" in ra[-1], ra[-1:]
lsum = [l for l in lines(W / "launcher176_selftest.log") if l.startswith("[PASS] v0176")]
assert lsum and not [l for l in lines(W / "launcher176_selftest.log") if l.startswith("[FAIL]")]
mods = {"BookSource v0101(含 v0100 自測)": last(W / "booksource101_selftest.log"), "OutputStore v0104(含 v0103 → v0100 自測)": last(W / "store104_selftest.log")}
assert all("不過 0" in v for v in mods.values()), mods
ps = json.loads((W / "pscheck176.log").read_text())
by = {x["f"]: x for x in ps}
assert all(x["e"] == 0 for x in ps) and by["handleall_line.txt.ps1"]["h"] == by["handleall_src.ps1.ps1"]["h"] and by["boot_line.txt.ps1"]["h"] == by["boot_src.ps1.ps1"]["h"]
pparse = "pwsh 剖析錯 %s · Handle-All 一行 = 可讀版 True · 開機行 = 可讀版 True" % sorted(x["e"] for x in ps)
rc = [l for l in lines(W / "tiny176.rc") if l.strip()]
assert all(" rc 0" in l for l in rc) and len(rc) == 4, rc
assert "[RED] boot SHA-256 mismatch - not run" in (W / "tiny_tamper.log").read_text(encoding="utf-8")
states = {n: json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
base = {n: json.loads(Path("/home/user/vrn2_work/v175/closeout_%s.json" % n).read_text(encoding="utf-8"))["per_owner"] for n in ("auto1", "auto2")}
assert states["auto1"].get("VRN-2") == base["auto1"].get("VRN-2") and states["auto2"].get("VRN-2") == base["auto2"].get("VRN-2"), (states, base)
E = json.loads((W / "e2e176_check.json").read_text(encoding="utf-8"))
assert E["plan_ok"] and E["store_no_double"] and E["leading_marks_left"] == 0 and E["combined_title_format_rows"] == E["combined_rows"] > 0, E
desk = json.loads((W / "deskshape176.json").read_text(encoding="utf-8"))
deskb = json.loads((W / "deskshape176b.json").read_text(encoding="utf-8"))
assert desk["leading_marks_after"] == 0 and desk["stripped_points_are_suffix_of_original"] and desk["summary_other_columns_identical"] and desk["second_run_unchanged"]
assert deskb["upside_basis_rows"] == deskb["with_target_price"] and deskb["second_run"]["topic_rows"] == 0
R["results"] = {"roundall_v0132_selftest": ra[-1:], "launcher_v0176_selftest": lsum, "module_selftests": mods, "pwsh_parse": pparse, "e2e_rc": rc, "closeout_per_owner": states,
                "closeout_vrn2_items_same_as_v0175_baseline": True, "e2e": E, "desktop_shape_check": {"summary_book": desk, "combined_from_basic_view": deskb},
                "not_run": "the desktop itself (one line · auto = repair · ⑬a v0101 + ⑬ v0104 tidy + Workbench) · the operator's own --confirm (H-fd2ea35f)"}
(rel / "VRN2_Release_v0176.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")

md = """# VRN-2 v0176 驗證紀錄(2026-11-03 · 四點去開頭符號 · 主題與摘要 Name(YFinance Ticker, 評等) - 原文標題 · 評價點用調整後目標價 ÷ 調整後收盤 · 套件 v0176 · RoundAll v0132 · Handle-All v0124)

## 1. 操作員要求 → 做法

| 要求 | 做法 |
|---|---|
| 四點摘要前面出現任何標點符號(如 ➢)則刪除 | ⑬a `VRN2_BookSource_v0101`:Summary 冊 TITLE / POINT_1 ~ POINT_4 開頭的項目符號 · 標點 · 編號 · 空白刪掉 · 內文一字不改(原文核對照樣找得到)· 1.5 倍 / 2026 年 / 25Q3 / 「引言」 這類開頭不動 |
| 第一點通常為評價 · 用每日更新後的 ADJ 目標價 · ADJ CLOSE 算上漲空間 | Combined 主題與摘要:評價點排第一 · 上漲空間 = TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1(與 Combined 的 UPSIDE_PCT(ADJ) 同一公式)· 句尾接算法 · 沒有評價句 → 補一句(仍是四點)· 調整後價缺 → 數字不動 |
| 標題格式 Name(YFinance Ticker, 評等) - 原文標題 | 主題與摘要開頭 = Name(YFinance Ticker, 評等) - 原文標題(Name:Combined → 基本資料 → 英文名 → 代號)|
| 增量庫不重複 | `VRN2_OutputStore_v0104`:Summary 去符號後再算雜湊 · Combined 主題與摘要不算 · 舊列就地整理(先備份 · restore-fill)· 調整後收盤變了照樣追加(每日歷史)|

## 2. 測試

| 項目 | 結果 |
|---|---|
| 模組自測 | %s |
| 啟動器 v0176 自測 | 全過 · %s |
| RoundAll v0132 自測 | %s |
| PowerShell 剖析 | %s |
| 桌機形狀(操作員 10/28 上傳的 Summary 冊 CSV · 只在暫存夾 · 11/03 桌機貼回另見 ➢ 7 · • 6 · ⚫ 2 · 標題 - 3 · 同一套規則)| %s 份 · 開頭符號 %s → 0 · 去掉後都是原文的尾段 · 其他欄逐一相同 · 非空點數 %s → %s(一點都沒少)· 再跑不變 |
| 桌機形狀(02 頁基本資料 52 列 + 上傳 Summary 組 Combined · 調整後價用合成數字)| 主題與摘要 52 列全部重組 · 有目標價 %s 列 → 改算上漲空間 %s 列 · YFinance 代號進標題 %s(=有代號的全部)· 評等進標題 %s(=有評等的全部)· 標題 + 至多四點 %s · 再跑主題與摘要 0 列 |
| e2e(最短一行 · 沙盒)| %s · auto1 整輪(啟動器 v0176)→ 模擬桌機 v0175 狀態(四點帶 ➢ / • · 主題與摘要舊格式 · 收據沒有 summary_cleanup / summary_tidy)→ auto2 repair:%s → 竄改開機檔不執行 |
| e2e 結果 | Summary %s 份 · 開頭符號剩 %s 格 · Combined %s 列 · 新格式 %s 列 · 有調整後價 %s 列 · 改算上漲空間 %s 列 · 除錯列:%s |
| 增量庫 | %s |
| 收尾負責方 | VRN-2 項與 v0175 基準相同(沙盒限定 · 沒有真 OCR 環境)|

## 3. 桌機下一步

1. 貼 `vrn2_release_v0176/VRN2_HandleAll_v0124.md` 的最短一行(收據 ≥ v0170 → repair · ⑬a v0101 → ⑬ v0104 整理 → Workbench)。
2. MQ-1560 看過原圖:`python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0132.py" --confirm H-fd2ea35f --note "…"`(只有操作員打才算)。
""" % (" · ".join("%s:%s" % (k, v[-36:]) for k, v in mods.items()), lsum[0][:120], ra[-1][:100], pparse,
       desk["summary_rows"], sum(desk["leading_marks_before"].values()), desk["non_empty_points_before_after"][0], desk["non_empty_points_before_after"][1],
       deskb["with_target_price"], deskb["upside_basis_rows"], deskb["yfinance_in_title"], deskb["rating_in_title"], deskb["at_most_title_plus_four"],
       " · ".join(rc), E["plan"][:220], E["summary_rows"], E["leading_marks_left"], E["combined_rows"], E["combined_title_format_rows"], E["combined_rows_with_tp_adj_and_adj_close"],
       E["upside_basis_rows"], E["points_format_row"][:160], E["store"][:240])
(rel / "VRN2_Verification_v0176.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0176.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0175 + VRN2_RoundAll_v0131 + VRN2_HandleAll_v0123 · 2026-11-03(")
L[0] = "# VRN-2 交接報告 · ActivateVRN-2 v0176 + VRN2_RoundAll_v0132 + VRN2_HandleAll_v0124 · 2026-11-03(四點去開頭符號 · 主題與摘要 Name(YFinance Ticker, 評等) - 原文標題 · 調整後上漲空間 · 增量庫 v0104)"
src = "\n".join(L)
once("> **本輪(v0175)**",
     "> **本輪(v0176)**:操作員 11/03 要求 → **⑬a VRN2_BookSource v0101**(v0100 薄尾):Summary 四點 / 標題開頭的符號 · 標點 · 編號刪掉(內文不改)· Combined 主題與摘要 = Name(YFinance Ticker, 評等) - 原文標題 · "
     "評價點排第一 · 上漲空間 = TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1(句尾附算法)· **OutputStore v0104**(Summary 去符號後再算雜湊 · Combined 主題與摘要不算 → 不重複追加 · 舊列就地整理 · 先備份 · restore-fill)· "
     "**RoundAll v0132**(⑤ 收據沒有 summary_cleanup / summary_tidy 也排 · ⑥ 新列「四點 / 主題與摘要」· 自測 103)· **Handle-All v0124** · 套件 v0176(啟動器 v0176 · runtime v0165)。"
     "同輪 **VCGC**(操作員授權):registry-sync --apply(新 36 · 變更 120 · 退役 1)· 編號 --apply --scope 43 支尾版(+996 列)· 四層缺號 0 · audit 遺失 0 · 改身分 0 · 重號 0。\n"
     "> **本輪(v0175)**")
rows = ("| **VRN2_HandleAll_v0124.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0124** | `vrn2_release_v0176` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0132)|\n"
        "| **VRN2_RoundAll_v0132.py**(發行夾 · 一支入口 · 不在套件內)| **v0132** | `vrn2_release_v0176` | `%s` | **新**(套件 v0176 · ⑤ source / store 整理 · ⑥ 四點 / 主題與摘要 · 自測 103)|\n"
        "| ActivateVRN-2_v0176.py(套件 · 底座 v0136 · runtime v0165)| **v0176** | 見發行清單 | `%s` | **新**(BookSource v0101 · OutputStore v0104)|\n"
        "| VRN2_Runtime_v0165.zip(套件 · runtime)| **v0165** | 套件內 | `%s` | **新**(v0164 的 207 個成員不動 + BookSource v0101 + OutputStore v0104)|\n"
        "| VRN2_BookSource_v0101.py(runtime · v0100 薄尾)| **v0101** | runtime v0165 | 見 runtime 清單 | **新**(四點去開頭符號 · 主題與摘要新格式 · 調整後上漲空間)|\n"
        "| VRN2_OutputStore_v0104.py(runtime · v0103 薄尾)| **v0104** | runtime v0165 | 見 runtime 清單 | **新**(雜湊不受格式影響 · 舊列就地整理 · restore-fill)|\n") % (
    H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12],
    next(c["sha256"] for c in R["components"] if c["path"] == "ActivateVRN-2_v0176.py")[:12], R["runtime"]["zip_sha256"][:12])
once("| **VRN2_HandleAll_v0123.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0123** | `vrn2_release_v0175` |",
     rows + "| **VRN2_HandleAll_v0123.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0123** | `vrn2_release_v0175` |")
once("| 0 | **(v0175)**",
     "| 0 | **(v0176)** 貼 `vrn2_release_v0176/VRN2_HandleAll_v0124.md` 的最短一行(repair · ⑬a v0101 去符號 + 主題與摘要 → ⑬ v0104 整理 → Workbench)→ 看 03 / 02 頁 Summary 四點沒有開頭符號 · Combined 主題與摘要新格式 · "
     "除錯列「四點 / 主題與摘要」綠 · MQ-1560 `--confirm H-fd2ea35f`(操作員)| 貼回 / 人工 |\n"
     "| 0 | **(v0175)**")
once("**v0175(2026-11-03)**:", "**v0176(2026-11-03)**:BookSource v0101(四點去開頭符號 · 主題與摘要 Name(YFinance Ticker, 評等) - 原文標題 · 評價點 TARGET_PRICE(ADJ) ÷ ADJ_CLOSE)· OutputStore v0104(不重複追加 · 舊列就地整理)· RoundAll v0132 · Handle-All v0124 · 套件 v0176 · VCGC registry-sync + 編號套用(操作員授權)。\n\n**v0175(2026-11-03)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0176)** **Summary 四點只去開頭符號**:BookSource v0101 `strip_lead` 只刪開頭的項目符號 / 標點 / 編號 / 空白,內文一字不改(原文核對靠這點);年份 / 季度 / 數字開頭(2026 年 · 25Q3 · 1.5 倍)不算編號。"
     "主題與摘要是組出來的欄(Combined),不是原文;要改格式改 `title_line` / `compose` 並出新號。\n"
     "- **(v0176)** **上漲空間口徑**:主題與摘要評價點的上漲空間 = TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1(與 Combined UPSIDE_PCT(ADJ) 同口徑 · ADJ_CLOSE 是 ⑥e 每日更新的 Yahoo 還原收盤);報告原文的目標價數字不改,只改上漲空間數字並附算法。\n"
     "- **(v0176)** **增量庫雜湊**:推得 / 組出來的欄(SOURCE · BROKER_EN · TOPIC & SUMMARY)與格式性前綴(Summary 開頭符號)都不算進列雜湊(OutputStore v0104);新加這類欄照做,否則整庫重複追加。\n"
     "- **(v0176)** **版號**:本線下一版 BookSource v0102+ · OutputStore v0105+ · Workbench v0110+ · RoundAll v0133+ · Handle-All v0125+ · runtime v0166+ · 啟動器 / 套件 / 收據 v0177+;出號前照舊查本分支與 main。\n\n")
(REPO / "VRN2_Handover_v0177.md").write_text(src, encoding="utf-8", newline="\n")

spec = (REPO / "VIA_Closeout_Spec_20261103.md").read_text(encoding="utf-8")
if "## 13. v0176 輪更新" not in spec:
    spec = spec.rstrip("\n") + "\n\n" + """## 13. v0176 輪更新(2026-11-03 · 只增)

| 項目 | 狀態 |
|---|---|
| 四點開頭符號 | ⑬a `VRN2_BookSource_v0101`:Summary 冊四點 / 標題開頭的項目符號 · 標點 · 編號刪掉(內文不改 · 原文核對照樣過)|
| 主題與摘要 | Combined:`Name(YFinance Ticker, 評等) - 原文標題` · 評價點排第一 · 上漲空間 = TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1(每日 ADJ_CLOSE)· 附算法 |
| 增量庫 | `VRN2_OutputStore_v0104`:格式改了不重複追加 · 舊列就地整理(先備份 · restore-fill)· ADJ_CLOSE 變了照樣追加 |
| VCGC registry-sync | **操作員授權**(2026-11-03)· `registry-sync --apply`:新 36 · 變更 120 · 退役 1 · AST 錯 0 · 撞號 0 · 再跑 新 0 變更 0 退役 0 |
| VCGC 編號套用 | **操作員授權** · `run CGC_MDL237_NumberingSystem --apply --scope`:先 5 支(X-NUM · +153 列)再 38 支(+843 列 · MDL +36 · ENG +2)· 四層缺號 VCGC 0 · VDF 0 · VRN 0 · SUP 0 · audit 遺失 0 · 改身分 0 · 重號 0 · SDD X-NUM GREEN |
| VCGC 仍黃(不在本次授權範圍 · 只記)| 編號冊內不一致 54 列(冊上宣告碼 ≠ 發出號 · 待裁定 · 不改任何一邊)· 命名同號異名 / 版號異形(操作員排序)· 已鎖工作流尾版換了待重驗 14 處 · 需求未全落地 80 條 |
| 桌機要做 | 貼 `vrn2_release_v0176/VRN2_HandleAll_v0124.md` 最短一行(repair)· MQ-1560 `--confirm H-fd2ea35f`(操作員)|
"""
    (REPO / "VIA_Closeout_Spec_20261103.md").write_text(spec, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0176"
D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0176.zip", "VRN2_RoundAll_v0132.py", "VRN2_RoundAll_v0132.md", "VRN2_HandleAll_v0124.md", "VRN2_HandleAll_v0124_boot.txt", "VRN2_Release_v0176.json", "VRN2_Verification_v0176.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 3, 14, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t176a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")) + (((str(W.parent), "<work>"),) if not name.startswith("tools/") else ()):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    if not name.startswith("tools/"):
        data = re.sub(rb"/home/user/[^\s'\"]*", b"<work>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0176.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall132_selftest.log", "launcher176_selftest.log", "booksource101_selftest.log", "store104_selftest.log", "pscheck176.log", "tiny176.rc", "seed176.log", "sim176.log",
                              "confirm_list.log", "e2e176_check.json", "deskshape176.json", "deskshape176b.json")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0176.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall132.py", "mk_launcher176.py", "runtime165.py", "gen_build176.py", "build176.py", "build176_tail.py", "finalize176.py", "e2e176.sh", "e2e176_check.py",
                              "deskshape176.py", "deskshape176b.py")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0177", src.count("\n"))
