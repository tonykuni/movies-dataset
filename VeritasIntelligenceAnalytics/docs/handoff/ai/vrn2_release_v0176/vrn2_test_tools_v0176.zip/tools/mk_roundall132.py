"""VRN2_RoundAll_v0132.py = 本線 v0131(倉裡 vrn2_release_v0175)+ 套件 v0176(啟動器 v0176 · runtime v0165)+ ⑤ ⑬a BookSource v0101 · ⑬ OutputStore v0104 整理 ·
⑥ 四點 / 主題與摘要格式診斷。操作員 2026-11-03(四點去開頭符號 · 第一點評價用調整後目標價 ÷ 調整後收盤 · 標題 Name(YFinance Ticker, 評等) - 原文標題)。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v176")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0175/VRN2_RoundAll_v0131.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0131')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0131 — ', '"""VRN2_RoundAll v0132 — ', 1)
at = doc.index("v0131(")
doc = doc[:at] + '''v0132(操作員 2026-11-03:「四點摘要前面出現任何標點符號如 ➢ 則刪除 · 第一點通常為評價,採取每日更新後的 ADJ 目標價 · ADJ CLOSE 來計算上漲空間 ·
  標題格式 Name(YFinance Ticker, 評等) - 原文標題」):
  · 套件 v0176(啟動器 v0176 · runtime v0165 = v0164 的 207 個成員一字不改 + BookSource v0101 + OutputStore v0104)。
  · ⑤ source:補放鏈 BookSource v0101 + v0100;上次寫欄的收據沒有 summary_cleanup(v0100 寫的 · 四點還帶符號 · 主題與摘要舊格式)→ 也排 ⑬a。
  · ⑤ store:補放鏈多 OutputStore v0104(Summary 去符號 / Combined 主題與摘要不算進雜湊 → 不重複追加 · 舊列就地整理 · 先備份 · restore-fill);
    增量庫收據沒有 summary_tidy(v0104 還沒跑過)→ 也排 store。
  · ⑥ 除錯:新增「四點 / 主題與摘要」一列:Summary 四點 / 標題開頭還有項目符號幾格 · Combined 主題與摘要不是 Name(…) - 標題 開頭幾列 · 評價點補了調整後上漲空間幾列。
  · ③ 自測清單:BookSource v0100 → v0101 · OutputStore v0103 → v0104(兩支都先跑前版自測)。
  · 自測 103 項(實跑計數:v0131 的 101 項 + 102 · 102b;舊項目照舊在 VIA_VRN2_NO_BOOKSOURCE=1 下跑)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0131.py", "用法:python VRN2_RoundAll_v0132.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


b0 = s.index('VERSION = "v0131"')
pre, post = s[:b0], s[b0:]
post = post.replace("v0175", "v0176").replace("VRN2_Runtime_v0164", "VRN2_Runtime_v0165")
s = pre + post
rep('VERSION = "v0131"', 'VERSION = "v0132"')
rep(re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s).group(0), 'PACKAGE_SHA256 = "@PACKAGE_SHA256@"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0131.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0131.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0132.py"', n_dl)
rep('"VRN2_RoundAll_v0131.py" in html_', '"VRN2_RoundAll_v0132.py" in html_')
rep("· v0130 起 100 項 · v0131 起 103 項。", "· v0130 起 100 項 · v0131 起 101 項(實跑計數 · 先前寫 103 是把子項算進去)· v0132 起 103 項。")
n = s.count('("VRN2_OutputStore_v0103.py", 300)')
rep('("VRN2_OutputStore_v0103.py", 300)', '("VRN2_OutputStore_v0104.py", 300)', n)
n = s.count('("VRN2_BookSource_v0100.py", 300)')
rep('("VRN2_BookSource_v0100.py", 300)', '("VRN2_BookSource_v0101.py", 300)', n)
rep('STORE_CHAIN = ("VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py",', 'STORE_CHAIN = ("VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py",')
n = s.count('STORE_CHAIN[0] == "VRN2_OutputStore_v0103.py"')
rep('STORE_CHAIN[0] == "VRN2_OutputStore_v0103.py"', 'STORE_CHAIN[0] == "VRN2_OutputStore_v0104.py"', n)
rep('BOOKSOURCE_CHAIN = ("VRN2_BookSource_v0100.py",)                             # v0131 ⑬a 輸出冊 SOURCE / BROKER_EN',
    'BOOKSOURCE_CHAIN = ("VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py")    # v0132 v0101 四點去符號 · 主題與摘要新格式 · v0131 ⑬a 輸出冊 SOURCE / BROKER_EN')
rep('BOOKSOURCE_CHAIN == ("VRN2_BookSource_v0100.py",)', 'BOOKSOURCE_CHAIN[1:] == ("VRN2_BookSource_v0100.py",)')
# ── source_due:收據沒有 summary_cleanup ──
rep('''    newer = [p.name[5:-12] for p in books if _mtime(p) > _mtime(rec)]
    return ("輸出冊比上次寫欄新(%s)" % "、".join(newer)) if newer else ""''', '''    newer = [p.name[5:-12] for p in books if _mtime(p) > _mtime(rec)]
    if newer:
        return "輸出冊比上次寫欄新(%s)" % "、".join(newer)
    if "summary_cleanup" not in (jread(rec, {}) or {}):                         # v0132 BookSource v0100 寫的 → 四點還帶符號 · 主題與摘要舊格式
        return "四點還帶開頭符號 · 主題與摘要還是舊格式(上次是 BookSource v0100 寫的)"
    return ""''')
rep('"⑬a 輸出冊 SOURCE / BROKER_EN 欄:%s → BookSource v0100 寫最後兩欄(BROKER 原文不改 · 其他值不變)" % s_why',
    '"⑬a 輸出冊 SOURCE / BROKER_EN 欄 · 四點 / 主題與摘要:%s → BookSource v0101 寫最後兩欄 · 四點去開頭符號 · 主題與摘要 = Name(YFinance Ticker, 評等) - 原文標題 · 評價點用調整後目標價 ÷ 調整後收盤(BROKER 原文不改 · 其他值不變)" % s_why')
rep('''    fill_due = cfg.get("output_dir") and store and "derived_fill" not in store and os.environ.get("VIA_VRN2_NO_BOOKSOURCE") != "1"   # v0131 OutputStore v0103 還沒跑過''',
    '''    fill_due = cfg.get("output_dir") and store and ("derived_fill" not in store or "summary_tidy" not in store) and os.environ.get("VIA_VRN2_NO_BOOKSOURCE") != "1"   # v0132 v0104 整理 · v0131 OutputStore v0103 還沒跑過''')
rep('("OutputStore v0103 補 SOURCE / BROKER_EN 欄" if fill_due else "OutputStore v0102")',
    '("OutputStore v0104 補 SOURCE / BROKER_EN 欄 · 整理四點 / 主題與摘要(不重複追加)" if fill_due else "OutputStore v0102")')
rep('''                fl = rec.get("derived_fill") or {}                         # v0131 OutputStore v0103 補欄''', '''                td = rec.get("summary_tidy") or {}                         # v0132 OutputStore v0104 整理
                if any((td.get("changed") or {}).values()) or td.get("lamp") in ("YELLOW", "RED"):
                    detail = "整理 %s · %s" % (td.get("why", ""), detail)
                fl = rec.get("derived_fill") or {}                         # v0131 OutputStore v0103 補欄''')
# ── ⑥ 四點 / 主題與摘要 ──
rep('''    else:
        f("YELLOW", "Combined 冊", "沒有 output\\\\VRN2_Combined_latest.json", "⑥f 沒跑:看 ⑥f 那行")''', '''    else:
        f("YELLOW", "Combined 冊", "沒有 output\\\\VRN2_Combined_latest.json", "⑥f 沒跑:看 ⑥f 那行")
    pf = points_format(v2)                                                    # v0132
    if pf:
        f(pf[0], "四點 / 主題與摘要", pf[1], pf[2])''')
rep('''def source_due(v2, planned) -> str:''', '''LEAD_MARK = re.compile("^[\\\\s\\u00b7\\u2022\\u2023\\u2043\\u2219\\u25a0-\\u25ff\\u2600-\\u27bf\\u2190-\\u21ff\\u30fb\\uff0d\\\\-\\\\*\\\\+>~=#\\u203b\\U0001F300-\\U0001FAFF]|^[(\\uff08]\\\\s*\\\\d{1,2}\\\\s*[)\\uff09]|^\\\\d{1,2}[\\u3001\\uff0e](?!\\\\d)|^[\\u2460-\\u2473\\u2776-\\u277f]")


def points_format(v2):
    """v0132 ⑥:Summary 四點 / 標題開頭還有符號幾格 · Combined 主題與摘要不是「Name(…) - 標題」開頭幾列 · 補了調整後上漲空間幾列 → (燈, 說明, 下一步);沒冊 → None。"""
    summ = jread(Path(v2) / "output" / "VRN2_Summary_latest.json", None)
    comb = jread(Path(v2) / "output" / "VRN2_Combined_latest.json", None)
    if not (isinstance(summ, list) and summ):
        return None
    lead = [(str(r.get("FILENAME") or ""), k) for r in summ if isinstance(r, dict) for k in ("TITLE", "POINT_1", "POINT_2", "POINT_3", "POINT_4") if LEAD_MARK.match(str(r.get(k) or ""))]
    bad_topic, upside, n_c = [], 0, 0
    for r in comb if isinstance(comb, list) else []:
        if not isinstance(r, dict) or "TOPIC & SUMMARY" not in r:
            continue
        n_c += 1
        t, name = str(r.get("TOPIC & SUMMARY") or ""), str(r.get("NAME") or r.get("TICKER") or "").strip()
        if name and not re.match(re.escape(name) + r"(\\(| - | · |$)", t):
            bad_topic.append(str(r.get("FILENAME") or ""))
        upside += int("\\u8abf\\u6574\\u5f8c\\u76ee\\u6a19\\u50f9" in t and "\\u4e0a\\u6f32\\u7a7a\\u9593" in t)
    opted_out = os.environ.get("VIA_VRN2_NO_BOOKSOURCE") == "1"
    lamp = "GREEN" if not (lead or bad_topic) else ("GRAY" if opted_out else "YELLOW")
    text = "Summary %d 份 · 開頭還有符號 %d 格%s · Combined %d 列 · 主題與摘要不是 Name(YFinance Ticker, 評等) - 原文標題 開頭 %d 列%s · 評價點用調整後目標價 ÷ 調整後收盤 %d 列" % (
        len(summ), len(lead), ("(" + "、".join("%s %s" % x for x in lead[:3]) + ")") if lead else "", n_c, len(bad_topic), ("(" + "、".join(bad_topic[:3]) + ")") if bad_topic else "", upside)
    nxt = "" if lamp == "GREEN" else ("VIA_VRN2_NO_BOOKSOURCE=1 關掉了 ⑬a" if opted_out else "再跑 repair:⑤ 排 ⑬a(BookSource v0101)把四點去符號 · 主題與摘要重組")
    return lamp, text, nxt


def source_due(v2, planned) -> str:''')
# ── 自測:101 的收據補 summary_cleanup / summary_tidy · 新 102 ──
rep('''                (v101 / "VRN2_OutputStore_latest.json").write_text(json.dumps({"lamp": "GREEN", "totals": {}, "derived_fill": {"lamp": "GREEN"}}), encoding="utf-8")''',
    '''                (v101 / "VRN2_OutputStore_latest.json").write_text(json.dumps({"lamp": "GREEN", "totals": {}, "derived_fill": {"lamp": "GREEN"}, "summary_tidy": {"lamp": "GREEN"}}), encoding="utf-8")''')
rep('''                (v101 / BOOKSOURCE_RECEIPT).write_text(json.dumps({"lamp": "GREEN"}), encoding="utf-8")''',
    '''                (v101 / BOOKSOURCE_RECEIPT).write_text(json.dumps({"lamp": "GREEN", "summary_cleanup": {"stripped_cells": 0}}), encoding="utf-8")''')
j = s.index('        with tempfile.TemporaryDirectory() as td101c:')
s = s[:j] + '''        with tempfile.TemporaryDirectory() as td102:
            os.environ.pop("VIA_VRN2_NO_BOOKSOURCE", None)
            try:
                v102 = Path(td102) / "VIA_Reports" / "vrn2"
                (v102 / "output").mkdir(parents=True)
                (v102 / "output" / "VRN2_Summary_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TITLE": "- 標題甲", "POINT_1": "\\u27a2 營收成長", "POINT_2": "目標價 120"}], ensure_ascii=False), encoding="utf-8")
                (v102 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "NAME": "示例公司", "TOPIC & SUMMARY": "- 標題甲 · \\u27a2 營收成長"}], ensure_ascii=False), encoding="utf-8")
                (v102 / "VRN2_Output_Config.json").write_text(json.dumps({"output_dir": str(Path(td102) / "out")}), encoding="utf-8")
                (v102 / STORE_PURGE).write_text(json.dumps({"apply": True, "lamp": "GREEN"}), encoding="utf-8")
                (v102 / "VRN2_OutputStore_latest.json").write_text(json.dumps({"lamp": "GREEN", "totals": {"Summary": 1, "Combined": 1}, "derived_fill": {"lamp": "GREEN"}}), encoding="utf-8")
                (v102 / "VRN2_Workbench_latest.html").write_text('<html><style id="wb109-tpl"></style></html>', encoding="utf-8")
                t102 = time.time()
                for b102 in ("Summary", "Combined"):
                    os.utime(v102 / "output" / ("VRN2_%s_latest.json" % b102), (t102 - 100, t102 - 100))
                (v102 / BOOKSOURCE_RECEIPT).write_text(json.dumps({"lamp": "GREEN", "module": "VRN2_BookSource v0100"}), encoding="utf-8")
                os.utime(v102 / "VRN2_Workbench_latest.html", (t102 + 200, t102 + 200))
                p102a = plan_fixes(Path(td102), {"market": {}, "consensus": {}}, "", A93(), "")
                pf102a = points_format(v102)
                (v102 / "output" / "VRN2_Summary_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "TITLE": "標題甲", "POINT_1": "營收成長", "POINT_2": "目標價 120"}], ensure_ascii=False), encoding="utf-8")
                (v102 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps([{"FILENAME": "a.pdf", "NAME": "示例公司", "TOPIC & SUMMARY": "示例公司(9999.TW, 買進) - 標題甲 · 目標價 120\\uff1b調整後目標價 118 ÷ 調整後收盤 100 = 上漲空間 18.0% · 營收成長"}], ensure_ascii=False), encoding="utf-8")
                for b102 in ("Summary", "Combined"):
                    os.utime(v102 / "output" / ("VRN2_%s_latest.json" % b102), (t102 - 100, t102 - 100))
                (v102 / BOOKSOURCE_RECEIPT).write_text(json.dumps({"lamp": "GREEN", "module": "VRN2_BookSource v0101", "summary_cleanup": {"stripped_cells": 3}}), encoding="utf-8")
                os.utime(v102 / "VRN2_Workbench_latest.html", (t102 + 200, t102 + 200))
                p102b = plan_fixes(Path(td102), {"market": {}, "consensus": {}}, "", A93(), "")
                (v102 / "VRN2_OutputStore_latest.json").write_text(json.dumps({"lamp": "GREEN", "totals": {"Summary": 1, "Combined": 1}, "derived_fill": {"lamp": "GREEN"}, "summary_tidy": {"lamp": "GREEN"}}), encoding="utf-8")
                os.utime(v102 / "VRN2_Workbench_latest.html", (t102 + 200, t102 + 200))
                p102c = plan_fixes(Path(td102), {"market": {}, "consensus": {}}, "", A93(), "")
                pf102c = points_format(v102)
            finally:
                os.environ["VIA_VRN2_NO_BOOKSOURCE"] = "1"
        chk("102 v0132:上次寫欄是 BookSource v0100(收據沒有 summary_cleanup)→ 排 ⑬a 再 ⑬ 再重渲染 · ⑥ 四點 / 主題與摘要 YELLOW(開頭符號 2 格 · 舊格式 1 列)· v0101 寫過 + 增量庫沒有 summary_tidy → 只排 ⑬(+ 重渲染)· 都齊了 → 計畫空 · ⑥ GREEN(評價點 1 列)",
            [k for k, _ in p102a] == ["source", "store", "workbench"] and "BookSource v0100" in p102a[0][1] and pf102a[0] == "YELLOW" and "開頭還有符號 2 格" in pf102a[1] and "開頭 1 列" in pf102a[1]
            and [k for k, _ in p102b] == ["store", "workbench"] and "整理四點" in p102b[0][1] and p102c == [] and pf102c[0] == "GREEN" and "調整後收盤 1 列" in pf102c[1])
        chk("102b v0132:補放鏈 BookSource v0101 + v0100 · OutputStore v0104 → v0100 · 自測清單 BookSource v0101 / OutputStore v0104 · 套件 v0176 · 開頭符號規則認得 ➢ • ⚫ - (1) ① 1、 · 不誤判 1.5 / 2026 / 「",
            BOOKSOURCE_CHAIN == ("VRN2_BookSource_v0101.py", "VRN2_BookSource_v0100.py") and STORE_CHAIN[:2] == ("VRN2_OutputStore_v0104.py", "VRN2_OutputStore_v0103.py")
            and ("VRN2_BookSource_v0101.py", 300) in SELFTESTS and ("VRN2_OutputStore_v0104.py", 300) in SELFTESTS and PACKAGE == "VRN2_Closeout_v0176" and RUNTIME_ZIP == "VRN2_Runtime_v0165.zip"
            and all(LEAD_MARK.match(x) for x in ("\\u27a2 a", "\\u2022 a", "\\u26ab a", "- a", "(1) a", "\\u2460 a", "1\\u3001a"))
            and not any(LEAD_MARK.match(x) for x in ("1.5 倍", "2026 年", "\\u300c 引言", "營收")))
''' + s[j:]
(W / "new").mkdir(exist_ok=True)
(W / "new" / "VRN2_RoundAll_v0132.py").write_text(s, encoding="utf-8", newline="\n")
left = [m.group(0) for m in re.finditer(r".{0,30}VRN2_Runtime_v0164.{0,30}|.{0,30}Closeout_v0175.{0,30}", s[s.index('VERSION = "v0132"'):])]
print("RoundAll v0132 lines", s.count("\n"), "· stale refs:", len(left), left[:3])
