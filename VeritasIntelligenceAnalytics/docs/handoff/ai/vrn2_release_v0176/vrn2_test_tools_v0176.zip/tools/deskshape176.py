"""桌機形狀檢查 v0176:操作員上傳的 Summary / Combined 冊 CSV(只在暫存夾)→ 當成輸出冊 JSON → BookSource v0101 → 只記筆數與結論(不印任何值)。"""
import collections, csv, importlib.util, io, json, re, sys, tempfile
from pathlib import Path
summ_csv, comb_csv, mod = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
def rows(p):
    t = p.read_bytes().decode("utf-8-sig")
    return [dict(r) for r in csv.DictReader(io.StringIO(t, newline=""))]
S, C = rows(summ_csv), rows(comb_csv)
spec = importlib.util.spec_from_file_location("bs", mod); bs = importlib.util.module_from_spec(spec); spec.loader.exec_module(bs)
P = ("TITLE", "POINT_1", "POINT_2", "POINT_3", "POINT_4")
lead_before = collections.Counter()
for r in S:
    for k in P:
        v = str(r.get(k) or "")
        m = re.match(r"^\s*(\S)", v)
        if m and bs.strip_lead(v) != v:
            lead_before[m.group(1)] += 1
with tempfile.TemporaryDirectory() as td:
    v2 = Path(td) / "vrn2"; (v2 / "output").mkdir(parents=True)
    (v2 / "output" / "VRN2_Summary_latest.json").write_text(json.dumps(S, ensure_ascii=False, indent=1), encoding="utf-8")
    (v2 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps(C, ensure_ascii=False, indent=1), encoding="utf-8")
    rec = bs.apply(v2)
    S2 = json.loads((v2 / "output" / "VRN2_Summary_latest.json").read_text(encoding="utf-8"))
    C2 = json.loads((v2 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
    rec2 = bs.apply(v2)
    S3 = json.loads((v2 / "output" / "VRN2_Summary_latest.json").read_text(encoding="utf-8"))
    C3 = json.loads((v2 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
suffix_ok = all(str(a.get(k) or "").endswith(str(b.get(k) or "").rstrip()) or not str(b.get(k) or "") for a, b in zip(S, S2) for k in P)
others_same = all({k: v for k, v in b.items() if k not in P + tuple(bs.COLS)} == {k: v for k, v in a.items() if k not in P} for a, b in zip(S, S2))
left = sum(1 for b in S2 for k in P if bs.strip_lead(str(b.get(k) or "")) != str(b.get(k) or ""))
pts_before = sum(1 for a in S for k in P[1:] if str(a.get(k) or "").strip()); pts_after = sum(1 for b in S2 for k in P[1:] if str(b.get(k) or "").strip())
fmt = 0; with_rating = 0; upside = 0; val_first = 0; have_adj = 0
for c in C2:
    t = str(c.get("TOPIC & SUMMARY") or ""); name = str(c.get("NAME") or c.get("TICKER") or "").strip()
    fmt += int(bool(name) and bool(re.match(re.escape(name) + r"(\(| - | · |$)", t)))
    with_rating += int(bool(str(c.get("RATING") or "").strip()) and ", " in t.split(" - ", 1)[0])
    upside += int("調整後目標價" in t and "調整後收盤" in t)
    have_adj += int(bool(bs._num(c.get("TARGET_PRICE(ADJ)"))) and bool(bs._num(c.get("ADJ_CLOSE"))))
    segs = t.split(" · ")
    val_first += int(len(segs) > 1 and bool(bs._VAL.search(segs[1])))
others_c = all({k: v for k, v in b.items() if k not in ("TOPIC & SUMMARY",) + tuple(bs.COLS)} == {k: v for k, v in a.items() if k != "TOPIC & SUMMARY"} for a, b in zip(C, C2))
print(json.dumps({"summary_rows": len(S), "combined_rows": len(C), "lamp": rec.get("lamp"),
                  "leading_marks_before": dict(lead_before.most_common()), "leading_marks_after": left,
                  "stripped_points_are_suffix_of_original": suffix_ok, "summary_other_columns_identical": others_same, "non_empty_points_before_after": [pts_before, pts_after],
                  "combined_title_format_rows": "%d / %d" % (fmt, len(C2)), "title_with_rating_rows": with_rating, "rows_with_tp_adj_and_adj_close": have_adj,
                  "valuation_point_first_rows": val_first, "upside_recomputed_rows": upside, "combined_other_columns_identical": others_c,
                  "receipt_summary_cleanup": {k: v for k, v in (rec.get("summary_cleanup") or {}).items() if k != "rule"},
                  "second_run_unchanged": S3 == S2 and C3 == C2, "second_run_cleanup": {k: v for k, v in (rec2.get("summary_cleanup") or {}).items() if k != "rule"}}, ensure_ascii=False))
