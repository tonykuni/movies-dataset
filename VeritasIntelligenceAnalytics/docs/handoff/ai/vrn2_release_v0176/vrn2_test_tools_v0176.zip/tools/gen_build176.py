"""從 build175.py 生 build176.py(套件 v0176 · RoundAll v0132 · Handle-All v0124)。"""
import re
from pathlib import Path

s = Path("/home/user/vrn2_work/v175/build175.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep(s.split('"""', 2)[1], "v0176(冪等):套件 VRN2_Closeout_v0176.zip(啟動器 v0176 · runtime v0165 = v0164 + BookSource v0101 + OutputStore v0104)\n"
    "→ RoundAll v0132(填套件雜湊)→ Handle-All v0124(指到 v0132 · 收據 ≥ v0170 照舊 repair)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0176)。vrn2_release_v0175 及更早不動。")
rep('W = Path("/home/user/vrn2_work/v175"); pkg, rel = W / "pkg175", W / "release175"', 'W = Path("/home/user/vrn2_work/v176"); pkg, rel = W / "pkg176", W / "release176"')
rep('PREV = Path("/home/user/vrn2_work/v174/release174")', 'PREV = Path("/home/user/vrn2_work/v175/release175")')
rep('(REPO / "vrn2_release_v0174/VRN2_Release_v0174.json")', '(REPO / "vrn2_release_v0175/VRN2_Release_v0175.json")', 2)
rep('(pkg / "VRN2_Runtime_v0164.json")', '(pkg / "VRN2_Runtime_v0165.json")')
rep('(pkg / "VRN2_Runtime_v0164.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0163.zip "', '(pkg / "VRN2_Runtime_v0165.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0164.zip "')
rep('rt["retained_members"] == 204 and rt["new_members"] == ["VRN2_BookSource_v0100.py", "VRN2_OutputStore_v0103.py", "VRN2_Workbench_v0109.py"]',
    'rt["retained_members"] == 207 and rt["new_members"] == ["VRN2_BookSource_v0101.py", "VRN2_OutputStore_v0104.py"]')
rep('"ActivateVRN-2_v0175.py", "VRN2_Runtime_v0164.zip", "VRN2_Runtime_v0164.json"', '"ActivateVRN-2_v0176.py", "VRN2_Runtime_v0165.zip", "VRN2_Runtime_v0165.json"', 2)
rep("# 其他成員跟 v0174 逐位元組相同", "# 其他成員跟 v0175 逐位元組相同")
i0 = s.index('files["README.txt"] = ('); i1 = s.index('files["VALIDATION_RESULT.json"]')
s = s[:i0] + '''files["README.txt"] = ("VRN2_Closeout_v0176 — VRN-2 closeout package (2026-11-03 · four points without leading bullets · TOPIC & SUMMARY title format · adjusted upside)\\n\\n"
  "Entry: python ActivateVRN-2_v0176.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0132.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0124.md (same release folder).\\n"
  "Runtime: VRN2_Runtime_v0165.zip = v0164 (207 members byte-identical) + VRN2_BookSource_v0101 + VRN2_OutputStore_v0104.\\n\\n"
  "v0176 (operator 2026-11-03: drop any leading punctuation such as the arrow bullet from the four summary points · point 1 is usually the valuation:\\n"
  "upside from the daily TARGET_PRICE(ADJ) and ADJ_CLOSE · title format Name(YFinance Ticker, Rating) - original title):\\n"
  " - ⑬a VRN2_BookSource_v0101 (thin tail over v0100): Summary TITLE / POINT_1..4 lose leading bullets, punctuation and numbering only (the verbatim\\n"
  "   check still finds every point); Combined TOPIC & SUMMARY = Name(YFinance Ticker, Rating) - title · valuation point first with upside recomputed as\\n"
  "   TARGET_PRICE(ADJ) / ADJ_CLOSE - 1 and the basis appended · no valuation point -> one is added (still four) · missing adjusted price -> order only.\\n"
  " - VRN2_OutputStore_v0104 (thin tail over v0103): the row hash ignores those leading bullets (Summary) and TOPIC & SUMMARY (Combined), so the cleaned\\n"
  "   books are not appended again; stored rows are tidied in place (DuckDB file backed up first · restore-fill --folder <_summary_tidy_ folder>).\\n"
  "   A new ADJ_CLOSE still appends a Combined row (daily history).\\n"
  "v0175: ⑬a BookSource v0100 (BROKER_EN + SOURCE) · OutputStore v0103 · Workbench v0109. v0163: no MOPS.\\n"
  "Verification: see VRN2_Verification_v0176.md. Hashes: PACKAGE_SHA256.json.\\n").encode("utf-8")
''' + s[i1:]
s = s.replace("VRN2_Verification_v0175.md", "VRN2_Verification_v0176.md")
rep('manifest = {"system": "VRN-2", "version": "v0175",', 'manifest = {"system": "VRN-2", "version": "v0176",')
rep('zpr = rel / "VRN2_Closeout_v0175.zip"', 'zpr = rel / "VRN2_Closeout_v0176.zip"')
rep('zipfile.ZipInfo("VRN2_Closeout_v0175/" + n, date_time=(2026, 11, 3, 2, 0, 0))', 'zipfile.ZipInfo("VRN2_Closeout_v0176/" + n, date_time=(2026, 11, 3, 14, 0, 0))')
rep('(W / "new/VRN2_RoundAll_v0131.py")', '(W / "new/VRN2_RoundAll_v0132.py")')
rep("'PACKAGE = \"VRN2_Closeout_v0175\"' in ra and 'VERSION = \"v0131\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175\"' in ra",
    "'PACKAGE = \"VRN2_Closeout_v0176\"' in ra and 'VERSION = \"v0132\"' in ra and 'RELEASE_REL = \"VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176\"' in ra")
rep('(rel / "VRN2_RoundAll_v0131.py").write_text(ra', '(rel / "VRN2_RoundAll_v0132.py").write_text(ra')
m0 = re.search(r'^rep\("\$P = ', s, re.M).start()
m1 = s.index("ha_line = join(ha)")
s = s[:m0] + '''rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176'")
rep("$F = 'VRN2_RoundAll_v0131.py'", "$F = 'VRN2_RoundAll_v0132.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0123", "Handle-All v0124", ha.count("Handle-All v0123"))
rep("套件 v0175 裝在新夾 VRN2_Closeout_v0175", "套件 v0176 裝在新夾 VRN2_Closeout_v0176")
rep("取套件 v0175 → 診斷 → 全部自測 → 跑啟動器 v0175(", "取套件 v0176 → 診斷 → 全部自測 → 跑啟動器 v0176(")
rep("⑬a BookSource v0100(輸出冊實體 SOURCE / BROKER_EN)· 增量庫 OutputStore v0103(不重複追加 · 舊列補欄)· Workbench v0109(",
    "⑬a BookSource v0101(四點去開頭符號 · 主題與摘要 = Name(YFinance Ticker, 評等) - 原文標題 · 評價點用調整後目標價 ÷ 調整後收盤 · 含 v0100 SOURCE / BROKER_EN)· 增量庫 OutputStore v0104(不重複追加 · 舊列就地整理 · 含 v0103 補欄)· Workbench v0109(")
rep("repair = '取套件 v0175 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 輸出冊寫 SOURCE / BROKER_EN 兩欄 · 增量庫 v0103 舊列補欄(先備份)·",
    "repair = '取套件 v0176 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 四點去開頭符號 · 主題與摘要新格式 · 評價點上漲空間 = 調整後目標價 ÷ 調整後收盤 − 1 · 輸出冊 SOURCE / BROKER_EN 兩欄 · 增量庫 v0104 舊列就地整理(先備份)·")
rep("只重跑 ⑪ 獨立驗證(套件 v0175 的", "只重跑 ⑪ 獨立驗證(套件 v0176 的")
left = [l for l in ha.split("\\n") if re.search(r"Handle-All v0123|v0131[.]py|release_v0175|套件 v0175|Closeout_v0175", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
''' + s[m1:]
rep('("vrn2_release_v0174", "vrn2_release_v0175"), ("VRN2_HandleAll_v0122.md", "VRN2_HandleAll_v0123.md"), ("Handle-All v0122 SHA-256 OK", "Handle-All v0123 SHA-256 OK")',
    '("vrn2_release_v0175", "vrn2_release_v0176"), ("VRN2_HandleAll_v0123.md", "VRN2_HandleAll_v0124.md"), ("Handle-All v0123 SHA-256 OK", "Handle-All v0124 SHA-256 OK")')
rep('(rel / "VRN2_HandleAll_v0123_boot.txt")', '(rel / "VRN2_HandleAll_v0124_boot.txt")')
rep("vrn2_release_v0175/VRN2_HandleAll_v0123_boot.txt", "vrn2_release_v0176/VRN2_HandleAll_v0124_boot.txt")
i0 = s.index('md = """'); i1 = s.index('print("package"')
s = s[:i0] + Path("/home/user/vrn2_work/v176/build176_tail.py").read_text(encoding="utf-8") + s[i1:]
Path("/home/user/vrn2_work/v176/build176.py").write_text(s, encoding="utf-8")
print("ok")
