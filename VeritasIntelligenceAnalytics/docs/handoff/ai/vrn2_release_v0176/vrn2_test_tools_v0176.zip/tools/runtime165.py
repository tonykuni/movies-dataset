"""runtime v0165 = runtime v0164(207 個成員逐位元組不動)+ BookSource v0101 + OutputStore v0104 · 套件夾 pkg176(其他成員從 pkg175 原樣複製)。"""
import hashlib, json, shutil, zipfile
from pathlib import Path
old, new, out = Path("/home/user/vrn2_work/v175/pkg175"), Path("/home/user/vrn2_work/v176/new"), Path("/home/user/vrn2_work/v176/pkg176")
out.mkdir(parents=True, exist_ok=True)
om = json.loads((old / "VRN2_Runtime_v0164.json").read_text(encoding="utf-8")); old_names = [e["path"] for e in om["files"]]
assert hashlib.sha256((old / "VRN2_Runtime_v0164.zip").read_bytes()).hexdigest() == om["zip_sha256"]
with zipfile.ZipFile(old / "VRN2_Runtime_v0164.zip") as z:
    members = {n: z.read(n) for n in old_names}
for e in om["files"]:
    assert hashlib.sha256(members[e["path"]]).hexdigest() == e["sha256"], e["path"]
assert len(old_names) == 207, len(old_names)
new_names = ["VRN2_BookSource_v0101.py", "VRN2_OutputStore_v0104.py"]
for n in new_names:
    assert n not in members, n
    members[n] = (new / n).read_bytes()
assert "VRN2_BookSource_v0100.py" in members and "VRN2_OutputStore_v0103.py" in members
names = sorted(members); zp = out / "VRN2_Runtime_v0165.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        zi = zipfile.ZipInfo(n, date_time=(2026, 11, 3, 14, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, members[n])
man = {"system": "VRN-2", "version": "v0165", "zip_sha256": hashlib.sha256(zp.read_bytes()).hexdigest(), "based_on": "VRN2_Runtime_v0164.zip " + om["zip_sha256"], "retained_members": len(old_names), "new_members": new_names,
       "files": [{"path": n, "sha256": hashlib.sha256(members[n]).hexdigest()} for n in names]}
(out / "VRN2_Runtime_v0165.json").write_text(json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
for n in ("ActivateVRN-2_v0136.py", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"):
    shutil.copy2(str(old / n), str(out / n))
print("runtime v0165", len(names), man["zip_sha256"][:12], "· pkg176", sorted(p.name for p in out.iterdir()))
