"""e2e v0176 結果檢查(只讀沙盒產物 · 寫 e2e176_check.json · 路徑遮掉 · 不印任何報告內容值)。"""
import json, re
from pathlib import Path
W = Path("/home/user/vrn2_work/v176"); V2 = W / "t176a" / "VIA" / "VIA_Reports" / "vrn2"


def txt(p):
    return Path(p).read_text(encoding="utf-8", errors="replace") if Path(p).is_file() else ""


LEAD = re.compile("^[\\s·•■-◿☀-➿←-⇿\\-\\*]")
log1, log2 = txt(W / "tiny_auto1.log"), txt(W / "tiny_auto2.log")
summ = json.loads(txt(W / "out_auto2" / "VRN2_Summary_latest.json") or "[]")
comb = json.loads(txt(W / "out_auto2" / "VRN2_Combined_latest.json") or "[]")
store = json.loads(txt(V2 / "VRN2_OutputStore_latest.json") or "{}")
bsr = json.loads(txt(V2 / "VRN2_BookSource_latest.json") or "{}")
clo = json.loads(txt(W / "closeout_auto2.json") or "{}")
plan = next((l for l in log2.splitlines() if "⑤ 自動修計畫" in l), "")
src_fix = next((l for l in log2.splitlines() if "⑤ 修 · ⑬a" in l), "")
st_fix = next((l for l in log2.splitlines() if "⑤ 修 · ⑬ 增量庫" in l), "")
pf = next((l for l in log2.splitlines() if "四點 / 主題與摘要" in l and "Summary" in l), "")
a1 = next((l for l in log1.splitlines() if "⑬a 輸出冊 Source / Broker 欄 ·" in l), "")
P = ("TITLE", "POINT_1", "POINT_2", "POINT_3", "POINT_4")
lead_left = sum(1 for r in summ for k in P if LEAD.match(str(r.get(k) or "")))
fmt = sum(1 for c in comb if str(c.get("NAME") or c.get("TICKER") or "").strip() and re.match(re.escape(str(c.get("NAME") or c.get("TICKER")).strip()) + r"(\(| - | · |$)", str(c.get("TOPIC & SUMMARY") or "")))
up = sum(1 for c in comb if "調整後目標價" in str(c.get("TOPIC & SUMMARY") or ""))
with_adj = sum(1 for c in comb if str(c.get("TARGET_PRICE(ADJ)") or "").strip() and str(c.get("ADJ_CLOSE") or "").strip())
report_books = ("BasicInfo", "FinancialData", "Summary", "Combined", "Rejected", "FinancialAligned", "Deleted")
app = store.get("appended") or {}
out = {"auto1_13a": re.sub(r"\x1b\[[0-9;]*m", "", a1).strip()[:220],
       "plan": plan.split("⑤ 自動修計畫", 1)[-1].strip(":: ")[:420],
       "plan_ok": "⑬a" in plan and "⑬ 增量庫" in plan and plan.index("⑬a") < plan.index("⑬ 增量庫"),
       "source_fix": re.sub(r"\x1b\[[0-9;]*m", "", src_fix).strip()[:240], "store_fix": re.sub(r"\x1b\[[0-9;]*m", "", st_fix).strip()[:300],
       "points_format_row": re.sub(r"\x1b\[[0-9;]*m", "", pf).strip()[:260],
       "summary_rows": len(summ), "leading_marks_left": lead_left, "combined_rows": len(comb), "combined_title_format_rows": fmt, "combined_rows_with_tp_adj_and_adj_close": with_adj, "upside_basis_rows": up,
       "booksource_receipt": {"module": bsr.get("module"), "lamp": bsr.get("lamp"), "summary_cleanup": {k: v for k, v in (bsr.get("summary_cleanup") or {}).items() if k != "rule"}},
       "store": "auto2 追加 %s · 整理 %s · 累計 %s" % (json.dumps({b: app.get(b) for b in report_books if b in app}, ensure_ascii=False),
                                                  json.dumps((store.get("summary_tidy") or {}).get("changed") or {}, ensure_ascii=False), json.dumps(store.get("totals") or {}, ensure_ascii=False)),
       "store_no_double": bool(app) and all(not app.get(b) for b in report_books) and "summary_tidy" in store,
       "closeout_per_owner": clo.get("per_owner")}
s = json.dumps(out, ensure_ascii=False, indent=1).replace(str(W / "t176a"), "<sbx>")
(W / "e2e176_check.json").write_text(s, encoding="utf-8")
print(s)
