"""桌機形狀檢查 v0176(b):上傳的 Summary 冊 CSV + 基本資料頁(02 · 52 列)→ 依 ConsensusJoin 的舊公式組 Combined(TOPIC = 標題 · 四點)
· 調整後目標價 / 調整後收盤用合成數字(TARGET_PRICE × 0.97 / 固定 100 · 不是桌機值)→ BookSource v0101 → 只記筆數。"""
import csv, io, json, re, sys, tempfile, importlib.util
from pathlib import Path
summ_csv, basic_json, mod = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
S = [dict(r) for r in csv.DictReader(io.StringIO(summ_csv.read_bytes().decode("utf-8-sig"), newline=""))]
B = json.loads(basic_json.read_text(encoding="utf-8-sig"))["rows"]
spec = importlib.util.spec_from_file_location("bs", mod); bs = importlib.util.module_from_spec(spec); spec.loader.exec_module(bs)
P = ("POINT_1", "POINT_2", "POINT_3", "POINT_4")
bys = {r["FILENAME"]: r for r in S}
C = []
for b in B:
    s = bys.get(b.get("FILENAME"), {})
    tp = bs._num(b.get("TARGET_PRICE"))
    C.append({"REPORT_DATE": b.get("REPORT_DATE"), "FILENAME": b.get("FILENAME"), "TICKER": b.get("TICKER"), "YFINANCE_TICKER": b.get("YFINANCE_TICKER"), "NAME": b.get("NAME"),
              "BROKER": b.get("BROKER"), "RATING": b.get("RATING"), "TARGET_PRICE": b.get("TARGET_PRICE"), "TARGET_PRICE(ADJ)": ("%.2f" % (tp * 0.97)) if tp else "",
              "ADJ_CLOSE": "100.00" if tp else "", "TOPIC & SUMMARY": " · ".join([str(s.get("TITLE") or b.get("TITLE") or "").strip()] + [str(s.get(k)) for k in P if str(s.get(k) or "").strip()]).strip(" ·"), "STATUS": ""})
with tempfile.TemporaryDirectory() as td:
    v2 = Path(td) / "vrn2"; (v2 / "output").mkdir(parents=True)
    basic_rows = [{k: v for k, v in b.items() if k not in bs.COLS} for b in B]
    for name, rows in (("Summary", S), ("Combined", C), ("BasicInfo", basic_rows)):
        (v2 / "output" / ("VRN2_%s_latest.json" % name)).write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
    rec = bs.apply(v2)
    C2 = json.loads((v2 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
    rec2 = bs.apply(v2)
matched = sum(1 for b in B if b.get("FILENAME") in bys)
fmt = sum(1 for c in C2 if str(c.get("NAME") or "").strip() and re.match(re.escape(str(c["NAME"]).strip()) + r"(\(| - | · |$)", str(c["TOPIC & SUMMARY"])))
yf_in = sum(1 for c in C2 if str(c.get("YFINANCE_TICKER") or "").strip() and "(" + str(c["YFINANCE_TICKER"]).strip() in str(c["TOPIC & SUMMARY"]))
rating_in = sum(1 for c in C2 if str(c.get("RATING") or "").strip() and (", " + str(c["RATING"]).strip() + ")") in str(c["TOPIC & SUMMARY"]))
up = sum(1 for c in C2 if "調整後目標價" in c["TOPIC & SUMMARY"])
val_src = sum(1 for c in C2 if len(c["TOPIC & SUMMARY"].split(" · ")) > 1 and bs._VAL.search(c["TOPIC & SUMMARY"].split(" · ")[1]) and "調整後目標價" not in c["TOPIC & SUMMARY"].split(" · ")[1])
added = sum(1 for c in C2 if c["TOPIC & SUMMARY"].split(" · ")[1:2] and c["TOPIC & SUMMARY"].split(" · ")[1].startswith("評價"))
four = sum(1 for c in C2 if len(c["TOPIC & SUMMARY"].split(" · ")) <= 5)
print(json.dumps({"basic_rows": len(B), "summary_rows": len(S), "basic_with_summary": matched, "with_target_price": sum(1 for c in C if c["TARGET_PRICE(ADJ)"]),
                  "title_format_rows": fmt, "yfinance_in_title": yf_in, "rating_in_title": rating_in, "upside_basis_rows": up,
                  "valuation_point_from_report_first": sum(1 for c in C2 if "調整後目標價" in c["TOPIC & SUMMARY"].split(" · ")[1:2][0] if c["TOPIC & SUMMARY"].split(" · ")[1:2]) - added,
                  "valuation_point_added": added, "at_most_title_plus_four": "%d / %d" % (four, len(C2)), "receipt": {k: v for k, v in (rec.get("summary_cleanup") or {}).items() if k != "rule"},
                  "second_run": {k: v for k, v in (rec2.get("summary_cleanup") or {}).items() if k != "rule"}}, ensure_ascii=False))
