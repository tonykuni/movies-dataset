#!/bin/bash
# v0176 e2e(RoundAll v0132 · Handle-All v0124 · 套件 v0176:BookSource v0101 · OutputStore v0104):沙盒(桌機 v0153 狀態)+ 三份原文(只在沙盒)
# + 合成共識快照 → auto1(收據 v0153 < v0170 → 整輪 · 啟動器 v0176 → ⑬a v0101 · ⑬ v0104)
# → 模擬桌機 v0175 現況(四點帶 ➢ / • · 主題與摘要舊格式 · BookSource 收據沒有 summary_cleanup · 增量庫收據沒有 summary_tidy)→ --confirm list → auto2(repair)
# → ⑤ source → store → workbench(補放 BookSource v0101 / OutputStore v0104)→ 竄改不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v176; W4=/home/user/vrn2_work/v164; T=$W/t176a; P=$S2/venv_vrn2/bin/python; PA=$S/pa_venv/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
REL=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
cp /home/user/vrn2_work/v165/pdfs/daiwa6278.pdf "$T/samples/Daiwa-6278 20260521.pdf"; cp /home/user/vrn2_work/v165/pdfs/ctbc3264.pdf "$T/samples/欣銓(3264,B_買進)-CTBC260918.pdf"; cp /home/user/vrn2_work/v168/pdfs/hn6143.pdf "$T/samples/華南投顧-6143-振曜-1141128.pdf"; for f in "$T/VIA/VIA_Reports/vrn2/VRN2_Input_latest.json" "$T/VIA/functional modules/VRN2/SSOT/"*.json; do sed -i "s|$S/v153/t153d/samples|$T/samples|g; s|$S/v151/t151/samples|$T/samples|g" "$f"; done
$P -I $W4/seed164.py $T $W4/rt > $W/seed176.log 2>&1; tail -2 $W/seed176.log
$P - "$T" <<'PYEOF' >> $W/seed176.log 2>&1
# 合成共識快照:沙盒 BasicInfo 前 6 檔代號 · 形狀同引擎矩陣 · 數字合成(不是任何原文 / 桌機值)· ASOF = 台北 2026-11-01
import csv, json, re, sys
from pathlib import Path
v2 = Path(sys.argv[1]) / "VIA" / "VIA_Reports" / "vrn2"
basic = json.loads((v2 / "output" / "VRN2_BasicInfo_latest.json").read_text(encoding="utf-8"))
codes = []
for r in basic if isinstance(basic, list) else []:
    c = str(r.get("TICKER") or r.get("ticker") or "").strip()
    if re.fullmatch(r"[1-9]\d{3}", c) and c not in codes:
        codes.append(c)
codes = codes[:6]
head = ["code", "symbol", "company_name", "fetched_at_utc", "current_price", "target_median", "target_mean", "target_analyst_count", "target_rate_date",
        "yf_target_median", "yf_target_mean", "yf_target_analyst_count", "yf_current_price", "eps_2026_median", "eps_2026_forward_pe", "source_agreement_gate", "source_page", "source_yfinance"]
out = v2 / "consensus"
out.mkdir(parents=True, exist_ok=True)
with (out / "factset_yfinance_consensus_matrix.csv").open("w", encoding="utf-8", newline="") as fh:
    w = csv.writer(fh); w.writerow(head)
    for i, c in enumerate(codes):
        base = 100.0 + 10 * i
        w.writerow([c, "TWS:%s:STOCK" % c, "合成快照%d" % i, "2026-11-01T01:19:00+00:00", base, round(base * 1.2, 2), round(base * 1.21, 2), 5 + i,
                    "2026-10-30", round(base * 1.1, 2), round(base * 1.12, 2), 7 + i, base, round(9.5 + i, 2), round(14.0 + i, 2), "PASS", "https://example.invalid/%s" % c, "yfinance"])
print("seed snapshot codes", codes)
PYEOF
B=$T.br; D1=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176; mkdir -p $D1
cp $W/release176/VRN2_Closeout_v0176.zip $W/release176/VRN2_RoundAll_v0132.py $W/release176/VRN2_RoundAll_v0132.md $W/release176/VRN2_HandleAll_v0124.md $W/release176/VRN2_HandleAll_v0124_boot.txt $W/release176/VRN2_Release_v0176.json $D1/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release176/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2)
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 6000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny176.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; cp -a $V2/output $W/out_$N 2>/dev/null; cp $V2/VRN2_Workbench_latest.html $W/wb_$N.html 2>/dev/null; cp $V2/consensus/VRN2_Consensus_latest.json $W/cons_$N.json 2>/dev/null; }
rm -rf "${W:?}/out_auto1" "${W:?}/out_auto2" "${W:?}/out_tamper"; rm -f $W/tiny176.rc
run auto1
RA=$T/home/Downloads/VRN2_RoundAll_v0132.py
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm list > $W/confirm_list.log 2>&1; echo "confirm list rc $?" >> $W/tiny176.rc
cp $V2/VRN2_Workbench_latest.html $W/wb_auto1_full.html 2>/dev/null
python3 - "$V2" <<'PYEOF' > $W/sim176.log 2>&1
# 模擬桌機 v0175 現況(四點帶 ➢ / • · 標題帶 - · 主題與摘要 = 標題 · 四點(舊格式)· BookSource 收據沒有 summary_cleanup · 增量庫收據沒有 summary_tidy)· 只動沙盒
import json, sys
from pathlib import Path
v2 = Path(sys.argv[1]); out = v2 / "output"
pts = ("POINT_1", "POINT_2", "POINT_3", "POINT_4")
sp = out / "VRN2_Summary_latest.json"
summ = json.loads(sp.read_text(encoding="utf-8"))
marks = ("\u27a2 ", "\u2022 ", "\u26ab ", "")
for r in summ:
    for i, k in enumerate(pts):
        if str(r.get(k) or "").strip():
            r[k] = marks[i] + str(r[k])
    if str(r.get("TITLE") or "").strip():
        r["TITLE"] = "- " + str(r["TITLE"])
sp.write_text(json.dumps(summ, ensure_ascii=False, indent=1), encoding="utf-8")
by = {str(r.get("FILENAME")): r for r in summ}
cp = out / "VRN2_Combined_latest.json"
comb = json.loads(cp.read_text(encoding="utf-8"))
for r in comb:
    s = by.get(str(r.get("FILENAME")), {})
    r["TOPIC & SUMMARY"] = " · ".join([str(s.get("TITLE") or "").strip()] + [str(s.get(k)) for k in pts if str(s.get(k) or "").strip()]).strip(" ·")
cp.write_text(json.dumps(comb, ensure_ascii=False, indent=1), encoding="utf-8")
bs = v2 / "VRN2_BookSource_latest.json"
rec = json.loads(bs.read_text(encoding="utf-8")) if bs.is_file() else {}
had = "summary_cleanup" in rec
rec.pop("summary_cleanup", None); rec["module"] = "VRN2_BookSource v0100"
bs.write_text(json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
st = v2 / "VRN2_OutputStore_latest.json"
srec = json.loads(st.read_text(encoding="utf-8")) if st.is_file() else {}
had_t = "summary_tidy" in srec
srec.pop("summary_tidy", None)
st.write_text(json.dumps(srec, ensure_ascii=False, indent=1), encoding="utf-8")
print("Summary rows", len(summ), "· Combined rows", len(comb), "· auto1 receipt had summary_cleanup", had, "· store receipt had summary_tidy", had_t)
PYEOF
cat $W/sim176.log
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$PA" VRN2_ROUNDALL_ARGS="--python $PA" VIA_ACCEL_LIGHT_SEC=2)
run auto2
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176/VRN2_HandleAll_v0124_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny176.rc
echo E2E176_DONE
