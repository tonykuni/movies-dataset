"""ActivateVRN-2_v0176.py = v0175 + ⑬a BookSource v0101(四點去開頭符號 · 主題與摘要新格式 · 評價點用調整後目標價 ÷ 調整後收盤算上漲空間)+ OutputStore v0104(不重複追加 · 舊列就地整理)。
runtime v0165 = runtime v0164(207 個成員一字不改)+ VRN2_BookSource_v0101 + VRN2_OutputStore_v0104。"""
from pathlib import Path
SRC = Path("/home/user/vrn2_work/v175/pkg175/ActivateVRN-2_v0175.py")
OUT = Path("/home/user/vrn2_work/v176/pkg176/ActivateVRN-2_v0176.py")
s = SRC.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0175: v0174 entry + ⑬a book Source / Broker columns', '''"""VRN-2 v0176: v0175 entry + ⑬a BookSource v0101 + OutputStore v0104 (operator 2026-11-03: "四點摘要前面出現任何標點符號如 ➢ 則刪除 · 第一點通常為評價,
 採取每日更新後的 ADJ 目標價 · ADJ CLOSE 來計算上漲空間 · 標題格式 Name(YFinance Ticker, 評等) - 原文標題").
 - ⑬a VRN2_BookSource_v0101 (thin tail over v0100 · v0100 unchanged): Summary TITLE / POINT_1 ~ POINT_4 lose their leading bullets / punctuation / numbering
   (➢ • ⚫ ● ■ ▶ → - * · (1) ① 1、 …) and nothing else (the verbatim check still finds every point); Combined "TOPIC & SUMMARY" becomes
   "Name(YFinance Ticker, 評等) - 原文標題 · 評價 · 點 · 點 · 點": the valuation point (目標價 / 上漲空間 / 評等 / target / upside / rating …) goes first and its upside is
   recomputed from the daily TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1 with the basis appended (調整後目標價 X ÷ 調整後收盤 Y = 上漲空間 Z%); no valuation point → one is
   added as point 1 (still four points); a missing adjusted price → numbers untouched (order only). JSON / CSV / Parquet alike, idempotent, receipt summary_cleanup.
 - ⑬ VRN2_OutputStore_v0104 (thin tail over v0103): the row hash strips the same leading symbols from Summary rows and ignores Combined TOPIC & SUMMARY (derived from
   hashed columns), so the cleaned books are not appended again; old store rows are tidied in place (DuckDB file copied first · rowid update · affected run partitions
   moved to _summary_tidy_<time>/ and rewritten · restore-fill --folder). A changed ADJ_CLOSE still appends a new Combined row (the daily upside is history).
 Runtime v0165 = runtime v0164 (207 members byte-identical) + VRN2_BookSource_v0101 + VRN2_OutputStore_v0104. Receipt VRN2_Closeout_v0176.json.

VRN-2 v0175: v0174 entry + ⑬a book Source / Broker columns''')
rep('VERSION = "ActivateVRN-2 v0175"', 'VERSION = "ActivateVRN-2 v0176"')
rep('RUNTIME_ZIP = "VRN2_Runtime_v0164.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0165.zip"')
rep('RUNTIME_MANIFEST = "VRN2_Runtime_v0164.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0165.json"')
rep('RECEIPT_NAME = "VRN2_Closeout_v0175.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0176.json"')
rep('OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0103.py"   # v0175:', 'OUTPUT_STORE_ACTIVE = "VRN2_OutputStore_v0104.py"   # v0176: hash ignores leading bullets (Summary) / TOPIC & SUMMARY (Combined) · old rows tidied in place (backup · restore-fill) · v0175:')
rep('BOOK_SOURCE = "VRN2_BookSource_v0100.py"   # v0175 ⑬a:', 'BOOK_SOURCE = "VRN2_BookSource_v0101.py"   # v0176 ⑬a: + four points without leading bullets · TOPIC & SUMMARY = Name(YF, 評等) - 標題 · valuation first · upside from TP(ADJ) ÷ ADJ_CLOSE · v0175 ⑬a:')
rep('''    return {"lamp": lamp, "detail": detail, **{k: result.get(k) for k in ("columns", "unmapped") if k in result}}''',
    '''    return {"lamp": lamp, "detail": detail, **{k: result.get(k) for k in ("columns", "unmapped", "summary_cleanup", "module") if k in result}}''')
rep('''"catalog_files", "parquet_files", "mirrored", "mops_purge", "mops_skipped") if k in result}''',
    '''"catalog_files", "parquet_files", "mirrored", "mops_purge", "mops_skipped", "derived_fill", "summary_tidy") if k in result}''')
rep('OUTPUT_STORE_ACTIVE, "VRN2_OutputStore_v0102.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py", BOOK_SOURCE)',
    'OUTPUT_STORE_ACTIVE, "VRN2_OutputStore_v0103.py", "VRN2_OutputStore_v0102.py", OUTPUT_STORE, "VRN2_OutputStore_v0100.py", BOOK_SOURCE, "VRN2_BookSource_v0100.py")', 2)
rep('''        assert st.TAG == "v0103" and st.PRIOR.PRIOR.TAG.startswith("v0103") and st.BOOKS[-1] == "MarketConsensus"''',
    '''        assert st.TAG == "v0104" and st.PRIOR.PRIOR.TAG.startswith("v0104") and st.PRIOR.TAG.startswith("v0104") and st.BOOKS[-1] == "MarketConsensus"''')
rep('''    bs100 = selftest_source(BOOK_SOURCE).read_text(encoding="utf-8")''', '''    bs100 = selftest_source("VRN2_BookSource_v0100.py").read_text(encoding="utf-8")''')
rep('''    assert WORKBENCH == "VRN2_Workbench_v0109.py" and OUTPUT_STORE_ACTIVE == "VRN2_OutputStore_v0103.py" and BOOK_SOURCE == "VRN2_BookSource_v0100.py"''',
    '''    bs101 = selftest_source(BOOK_SOURCE).read_text(encoding="utf-8")
    assert 'VERSION = "v0101"' in bs101 and 'PRIOR_NAME = "VRN2_BookSource_v0100.py"' in bs101 and "def strip_lead(" in bs101 and "def compose(" in bs101 and bs101.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    st104 = selftest_source(OUTPUT_STORE_ACTIVE).read_text(encoding="utf-8")
    assert 'TAG = "v0104"' in st104 and 'PRIOR_NAME = "VRN2_OutputStore_v0103.py"' in st104 and "def tidy_summary(" in st104 and "def row_hash104(" in st104 and st104.splitlines()[2].strip() == "# [VIA:ACCEL-BRIDGE:v0111]"
    assert WORKBENCH == "VRN2_Workbench_v0109.py" and OUTPUT_STORE_ACTIVE == "VRN2_OutputStore_v0104.py" and BOOK_SOURCE == "VRN2_BookSource_v0101.py"''')
rep('''        shutil.copy2(str(selftest_source(BOOK_SOURCE)), str(runtime175 / BOOK_SOURCE))''',
    '''        for name175 in (BOOK_SOURCE, "VRN2_BookSource_v0100.py"):
            shutil.copy2(str(selftest_source(name175)), str(runtime175 / name175))''')
rep('''            os.environ.pop("VIA_VRN2_NO_BOOKSOURCE", None)
    cj106 = selftest_source(''', '''            os.environ.pop("VIA_VRN2_NO_BOOKSOURCE", None)
        summ176 = {"REPORT_DATE": "2026-05-20", "FILENAME": "b.pdf", "TICKER": "9999", "BROKER": "凱基", "TITLE": "- 標題甲",
                   "POINT_1": "\\u27a2 營收成長", "POINT_2": "\\u2022 目標價 120 元,上漲空間 20%", "POINT_3": "\\u26ab 毛利率回升", "POINT_4": "下半年出貨"}
        comb176 = {"REPORT_DATE": "2026-05-20", "FILENAME": "b.pdf", "TICKER": "9999", "YFINANCE_TICKER": "9999.TW", "NAME": "示例公司", "BROKER": "凱基", "RATING": "買進",
                   "TARGET_PRICE": "120", "TARGET_PRICE(ADJ)": "118.00", "ADJ_CLOSE": "100.00", "TOPIC & SUMMARY": "舊", "STATUS": "x"}
        (output175 / "output" / "VRN2_Summary_latest.json").write_text(json.dumps([summ176], ensure_ascii=False), encoding="utf-8")
        (output175 / "output" / "VRN2_Combined_latest.json").write_text(json.dumps([comb176], ensure_ascii=False), encoding="utf-8")
        got176 = book_source(runtime175, output175, steps175)
        s176 = json.loads((output175 / "output" / "VRN2_Summary_latest.json").read_text(encoding="utf-8"))[0]
        c176 = json.loads((output175 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))[0]
        assert got176["lamp"] == "GREEN" and s176["POINT_1"] == "營收成長" and s176["POINT_2"].startswith("目標價 120") and s176["TITLE"] == "標題甲" and s176["POINT_4"] == "下半年出貨"
        assert c176["TOPIC & SUMMARY"].startswith("示例公司(9999.TW, 買進) - 標題甲 · 目標價 120 元,上漲空間 18.0%") and "調整後目標價 118 ÷ 調整後收盤 100 = 上漲空間 18.0%" in c176["TOPIC & SUMMARY"]
        assert (got176.get("summary_cleanup") or {}).get("upside_rows") == 1 and list(c176)[-2:] == ["BROKER_EN", "SOURCE"] and steps175[-1]["step"].startswith("⑬a")
        again176 = book_source(runtime175, output175, steps175)
        assert (again176.get("summary_cleanup") or {}).get("topic_rows") == 0 and json.loads((output175 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))[0] == c176
    cj106 = selftest_source(''')
rep('''    print("[PASS] v0175: ⑬a BookSource v0100''', '''    print("[PASS] v0176: ⑬a BookSource v0101 (Summary 四點 / 標題去開頭符號 · Combined 主題與摘要 = 示例公司(9999.TW, 買進) - 標題甲 · 評價點第一 · 上漲空間 118 ÷ 100 − 1 = 18.0% · 再跑不變) · OutputStore v0104 active (chain v0103 → v0100)")
    print("[PASS] v0175: ⑬a BookSource v0100''')
rep('return lamp, detail + " · launcher v0175"', 'return lamp, detail + " · launcher v0176"')
rep('note="VRN-2 private runtime; exact ship v0164 (launcher v0175 · BookSource v0100 · OutputStore v0103 · Workbench v0109 ·',
    'note="VRN-2 private runtime; exact ship v0165 (launcher v0176 · BookSource v0101 · OutputStore v0104 · Workbench v0109 ·')
rep('print("NEXT: [%s] VRN-2 v0175 · rc %s', 'print("NEXT: [%s] VRN-2 v0176 · rc %s')
OUT.write_text(s, encoding="utf-8", newline="\n")
print("launcher v0176", len(s.splitlines()), "lines")
