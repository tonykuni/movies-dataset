"""v0176(冪等):套件 VRN2_Closeout_v0176.zip(啟動器 v0176 · runtime v0165 = v0164 + BookSource v0101 + OutputStore v0104)
→ RoundAll v0132(填套件雜湊)→ Handle-All v0124(指到 v0132 · 收據 ≥ v0170 照舊 repair)→ 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0176)。vrn2_release_v0175 及更早不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v176"); pkg, rel = W / "pkg176", W / "release176"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v175/release175")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r170 = json.loads((REPO / "vrn2_release_v0175/VRN2_Release_v0175.json").read_text(encoding="utf-8"))
r171 = json.loads((REPO / "vrn2_release_v0175/VRN2_Release_v0175.json").read_text(encoding="utf-8"))
rt = json.loads((pkg / "VRN2_Runtime_v0165.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == hashlib.sha256((pkg / "VRN2_Runtime_v0165.zip").read_bytes()).hexdigest() and rt["based_on"] == "VRN2_Runtime_v0164.zip " + r170["runtime"]["zip_sha256"]
assert rt["retained_members"] == 207 and rt["new_members"] == ["VRN2_BookSource_v0101.py", "VRN2_OutputStore_v0104.py"]
old = {c["path"]: c["sha256"] for c in r170["components"]}
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0176.py", "VRN2_Runtime_v0165.zip", "VRN2_Runtime_v0165.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py",
          "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (pkg / n).read_bytes() for n in pnames}
for n in pnames:
    if n not in ("ActivateVRN-2_v0176.py", "VRN2_Runtime_v0165.zip", "VRN2_Runtime_v0165.json"):
        assert hashlib.sha256(files[n]).hexdigest() == old[n], n                 # 其他成員跟 v0175 逐位元組相同
files["README.txt"] = ("VRN2_Closeout_v0176 — VRN-2 closeout package (2026-11-03 · four points without leading bullets · TOPIC & SUMMARY title format · adjusted upside)\n\n"
  "Entry: python ActivateVRN-2_v0176.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0132.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0124.md (same release folder).\n"
  "Runtime: VRN2_Runtime_v0165.zip = v0164 (207 members byte-identical) + VRN2_BookSource_v0101 + VRN2_OutputStore_v0104.\n\n"
  "v0176 (operator 2026-11-03: drop any leading punctuation such as the arrow bullet from the four summary points · point 1 is usually the valuation:\n"
  "upside from the daily TARGET_PRICE(ADJ) and ADJ_CLOSE · title format Name(YFinance Ticker, Rating) - original title):\n"
  " - ⑬a VRN2_BookSource_v0101 (thin tail over v0100): Summary TITLE / POINT_1..4 lose leading bullets, punctuation and numbering only (the verbatim\n"
  "   check still finds every point); Combined TOPIC & SUMMARY = Name(YFinance Ticker, Rating) - title · valuation point first with upside recomputed as\n"
  "   TARGET_PRICE(ADJ) / ADJ_CLOSE - 1 and the basis appended · no valuation point -> one is added (still four) · missing adjusted price -> order only.\n"
  " - VRN2_OutputStore_v0104 (thin tail over v0103): the row hash ignores those leading bullets (Summary) and TOPIC & SUMMARY (Combined), so the cleaned\n"
  "   books are not appended again; stored rows are tidied in place (DuckDB file backed up first · restore-fill --folder <_summary_tidy_ folder>).\n"
  "   A new ADJ_CLOSE still appends a Combined row (daily history).\n"
  "v0175: ⑬a BookSource v0100 (BROKER_EN + SOURCE) · OutputStore v0103 · Workbench v0109. v0163: no MOPS.\n"
  "Verification: see VRN2_Verification_v0176.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0176.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0176", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0176.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0176/" + n, date_time=(2026, 11, 3, 14, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (W / "new/VRN2_RoundAll_v0132.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0176"' in ra and 'VERSION = "v0132"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176"' in ra
(rel / "VRN2_RoundAll_v0132.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0175'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176'")
rep("$F = 'VRN2_RoundAll_v0131.py'", "$F = 'VRN2_RoundAll_v0132.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0123", "Handle-All v0124", ha.count("Handle-All v0123"))
rep("套件 v0175 裝在新夾 VRN2_Closeout_v0175", "套件 v0176 裝在新夾 VRN2_Closeout_v0176")
rep("取套件 v0175 → 診斷 → 全部自測 → 跑啟動器 v0175(", "取套件 v0176 → 診斷 → 全部自測 → 跑啟動器 v0176(")
rep("⑬a BookSource v0100(輸出冊實體 SOURCE / BROKER_EN)· 增量庫 OutputStore v0103(不重複追加 · 舊列補欄)· Workbench v0109(",
    "⑬a BookSource v0101(四點去開頭符號 · 主題與摘要 = Name(YFinance Ticker, 評等) - 原文標題 · 評價點用調整後目標價 ÷ 調整後收盤 · 含 v0100 SOURCE / BROKER_EN)· 增量庫 OutputStore v0104(不重複追加 · 舊列就地整理 · 含 v0103 補欄)· Workbench v0109(")
rep("repair = '取套件 v0175 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 輸出冊寫 SOURCE / BROKER_EN 兩欄 · 增量庫 v0103 舊列補欄(先備份)·",
    "repair = '取套件 v0176 → ⑤ 自動修(只修輸入有變 / 還缺的 · 都齊了就不動;⑬a 四點去開頭符號 · 主題與摘要新格式 · 評價點上漲空間 = 調整後目標價 ÷ 調整後收盤 − 1 · 輸出冊 SOURCE / BROKER_EN 兩欄 · 增量庫 v0104 舊列就地整理(先備份)·")
rep("只重跑 ⑪ 獨立驗證(套件 v0175 的", "只重跑 ⑪ 獨立驗證(套件 v0176 的")
left = [l for l in ha.split("\n") if re.search(r"Handle-All v0123|v0131[.]py|release_v0175|套件 v0175|Closeout_v0175", l) and not l.lstrip().startswith("#")]
assert "exit" not in ha.replace("Exception", "") and not left, left[:2]
assert "$Mode = ($last -ge 170 -and $haveOut) ? 'repair' : 'full'" in ha
assert re.search(r"[$]col = @[{][^}]*REVIEW = 'Yellow';", ha)
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0175", "vrn2_release_v0176"), ("VRN2_HandleAll_v0123.md", "VRN2_HandleAll_v0124.md"), ("Handle-All v0123 SHA-256 OK", "Handle-All v0124 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0124_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0176/VRN2_HandleAll_v0124_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0124(2026-11-03 · 四點去開頭符號 · 主題與摘要新格式 · 調整後上漲空間 · 套件 v0176 · RoundAll v0132)

操作員 2026-11-03 要求 → 做法:

| 要求 | v0176 |
|---|---|
| 四點摘要前面出現任何標點符號(如 ➢)則刪除 | ⑬a `VRN2_BookSource_v0101`:Summary 冊 POINT_1 ~ POINT_4 與 TITLE 開頭的項目符號 / 標點 / 編號(➢ • ⚫ ● ■ ◆ ▶ → - * · (1) ① 1、 …)與空白刪掉,**內文一字不改**(原文核對照樣找得到)· 1.5 倍 / 2026 年 / 「引言」 這類開頭不動 · JSON / CSV / Parquet 同一套 · 沒變就不寫 |
| 第一點通常為評價 · 用每日更新後的 ADJ 目標價 · ADJ CLOSE 算上漲空間 | Combined「主題與摘要」:評價那一點(目標價 / 上漲空間 / 評等 / target / upside / rating …)排第一 · 上漲空間改用 **TARGET_PRICE(ADJ) ÷ ADJ_CLOSE − 1**(⑥e 每日更新的調整後收盤)· 句尾接「;調整後目標價 X ÷ 調整後收盤 Y = 上漲空間 Z%%」· 四點沒有評價句 → 第一點補一句(仍是四點)· 調整後價缺 → 數字不動(只排序)|
| 標題格式 Name(YFinance Ticker, 評等) - 原文標題 | 主題與摘要開頭 = `Name(YFinance Ticker, 評等) - 原文標題`(Name 取 Combined → 基本資料 → 英文名 → 代號;沒有評等就只寫代號)· 原文標題也去開頭符號 |
| 增量庫不能因為格式改了就重複追加 | `VRN2_OutputStore_v0104`:列雜湊對 Summary 去開頭符號後再算、Combined 的主題與摘要不算(由其他欄組成)→ **0 列重複追加** · 庫裡舊列就地整理(先整個 DuckDB 檔備份 · 可 `restore-fill --folder <_summary_tidy_ 夾>`)· 調整後收盤變了照樣追加一列(每日上漲空間是歷史)|
| 怎麼確認 | 收尾頁 / 除錯報告多一列「四點 / 主題與摘要」:開頭還有符號幾格 · 主題與摘要不是新格式幾列 · 評價點用調整後價幾列 · 全 0 = 綠 |

| 項目 | 現在 |
|---|---|
| 套件 | `vrn2_release_v0176/VRN2_Closeout_v0176.zip`(SHA-256 `%s` · 啟動器 v0176 · runtime v0165 = v0164 + BookSource v0101 + OutputStore v0104)|
| 一支 Python | `VRN2_RoundAll_v0132.py`(SHA-256 `%s` · 自測 103 項 · repair:⑬a 去符號 + 主題與摘要 → ⑬ 不重複追加 + 舊列整理 → 重渲染)|
| 自動選模式 | 收據 ≥ v0170 → **repair(幾分鐘)**:⑬a + ⑬ + Workbench |

## PowerShell 7 視窗(%d 字元)

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0124 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0132 `%s`)。

## cmd 視窗(%d 字元)

```bat
%s
```

## 人工核對(看過原文之後 · 收尾只剩這件在你手上)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0132.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0132.py" --confirm H-fd2ea35f --note "MQ-1560 原圖四點與摘錄一致"
```

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], len(cmd_line), cmd_line, "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0124.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0132.py(套件 v0176 · BookSource v0101 · OutputStore v0104)

`VRN2_RoundAll_v0132.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0131 +:

| 改了什麼 | 說明 |
|---|---|
| 套件 | `vrn2_release_v0176/VRN2_Closeout_v0176.zip`(SHA-256 `%s` 已釘入本檔)· 啟動器 v0176 · runtime v0165 = v0164 + BookSource v0101 + OutputStore v0104 |
| ⑤ source | 補放鏈 BookSource v0101 + v0100 · 上次寫欄的收據沒有 summary_cleanup(BookSource v0100 寫的:四點還帶符號 · 主題與摘要舊格式)→ 也排 ⑬a |
| ⑤ store | 補放鏈多 OutputStore v0104(不重複追加 · 舊列就地整理 · 先備份)· 增量庫收據沒有 summary_tidy 也排 |
| ③ 自測清單 | BookSource v0101(先跑 v0100 自測)· OutputStore v0104(先跑 v0103 自測)|
| ⑥ 除錯 | 新一列「四點 / 主題與摘要」:開頭還有符號幾格 · 主題與摘要不是 Name(…) - 標題 開頭幾列 · 評價點用調整後價幾列 |
| 自測 | 103 項(實跑計數:v0131 的 101 項 + 102 · 102b · 舊項目在 VIA_VRN2_NO_BOOKSOURCE=1 下跑)|
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0132.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_Closeout_v0176 (launcher v0176 · runtime v0165) + VRN2_RoundAll_v0132 + VRN2_HandleAll_v0124", "date": "2026-11-03",
        "trigger": "操作員 2026-11-03:四點摘要前面出現任何標點符號如 ➢ 則刪除 · 第一點通常為評價,採取每日更新後的 ADJ 目標價 · ADJ CLOSE 來計算上漲空間 · 標題格式 Name(YFinance Ticker, 評等) - 原文標題",
        "data_rule": "BookSource v0101 removes only leading bullets / punctuation / numbering from Summary TITLE and POINT_1..4 (inner text unchanged, so the verbatim check still finds every point); "
                     "Combined TOPIC & SUMMARY = Name(YFinance Ticker, Rating) - title · valuation point first · upside = TARGET_PRICE(ADJ) / ADJ_CLOSE - 1 with the basis appended; "
                     "no valuation point -> one is added as point 1 (still four); a missing adjusted price -> numbers untouched; every other column unchanged; JSON / CSV / Parquet alike; idempotent",
        "store_rule": "OutputStore v0104 row hash strips the same leading symbols from Summary rows and ignores Combined TOPIC & SUMMARY (no re-append); stored rows tidied in place after a DuckDB file backup (restore-fill); "
                      "a changed ADJ_CLOSE still appends a Combined row",
        "fixes": {"BookSource_v0101": "thin tail over v0100 · selftest v0100 + 11", "OutputStore_v0104": "thin tail over v0103 · selftest v0103 + 2 engines × 6 + 2",
                  "launcher_v0176": "BookSource v0101 / OutputStore v0104 active · selftest adds the four-point / topic check", "RoundAll_v0132": "package v0176 pin · ⑤ source when the receipt has no summary_cleanup · store when no summary_tidy · ⑥ four-point / topic row · selftest 103",
                  "HandleAll_v0124": "points at RoundAll v0132 / release v0176"},
        "package": {"name": "VRN2_Closeout_v0176.zip", "sha256": want, "release_folder": "vrn2_release_v0176", "changed": True, "launcher": "ActivateVRN-2_v0176.py"},
        "runtime": {"name": "VRN2_Runtime_v0165.zip", "zip_sha256": rt["zip_sha256"], "based_on": rt["based_on"], "retained_members": 207, "new_members": rt["new_members"]},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files) if n != "PACKAGE_SHA256.json"],
        "roundall_previous": [{"name": "VRN2_RoundAll_v0131.py", "sha256": r171["roundall"]["sha256"], "status": "superseded 2026-11-03; file kept in vrn2_release_v0175"}],
        "roundall": {"name": "VRN2_RoundAll_v0132.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0132.md"},
        "handleall": {"name": "VRN2_HandleAll_v0124.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0124_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "version_check": "BookSource v0101 · OutputStore v0104 · runtime v0165 · launcher / package / receipt v0176 · RoundAll v0132 · HandleAll v0124 checked free on this branch and origin/main",
        "results": {"status": "see VRN2_Verification_v0176.md"}}
(rel / "VRN2_Release_v0176.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
