VRN2_Closeout_v0176 — VRN-2 closeout package (2026-11-03 · four points without leading bullets · TOPIC & SUMMARY title format · adjusted upside)

Entry: python ActivateVRN-2_v0176.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0132.py · PowerShell 7 / cmd 'handle all': VRN2_HandleAll_v0124.md (same release folder).
Runtime: VRN2_Runtime_v0165.zip = v0164 (207 members byte-identical) + VRN2_BookSource_v0101 + VRN2_OutputStore_v0104.

v0176 (operator 2026-11-03: drop any leading punctuation such as the arrow bullet from the four summary points · point 1 is usually the valuation:
upside from the daily TARGET_PRICE(ADJ) and ADJ_CLOSE · title format Name(YFinance Ticker, Rating) - original title):
 - ⑬a VRN2_BookSource_v0101 (thin tail over v0100): Summary TITLE / POINT_1..4 lose leading bullets, punctuation and numbering only (the verbatim
   check still finds every point); Combined TOPIC & SUMMARY = Name(YFinance Ticker, Rating) - title · valuation point first with upside recomputed as
   TARGET_PRICE(ADJ) / ADJ_CLOSE - 1 and the basis appended · no valuation point -> one is added (still four) · missing adjusted price -> order only.
 - VRN2_OutputStore_v0104 (thin tail over v0103): the row hash ignores those leading bullets (Summary) and TOPIC & SUMMARY (Combined), so the cleaned
   books are not appended again; stored rows are tidied in place (DuckDB file backed up first · restore-fill --folder <_summary_tidy_ folder>).
   A new ADJ_CLOSE still appends a Combined row (daily history).
v0175: ⑬a BookSource v0100 (BROKER_EN + SOURCE) · OutputStore v0103 · Workbench v0109. v0163: no MOPS.
Verification: see VRN2_Verification_v0176.md. Hashes: PACKAGE_SHA256.json.
