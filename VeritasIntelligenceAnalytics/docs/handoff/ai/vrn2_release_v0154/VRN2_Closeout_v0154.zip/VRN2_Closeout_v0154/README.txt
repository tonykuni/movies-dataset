VRN2_Closeout_v0154 — VRN-2 closeout package (2026-10-30 · desktop Handle-All full run 20:09)

Entry: python ActivateVRN-2_v0154.py [--source <folder>] [--no-install] [--no-open]
One-file runner (outside the package): VRN2_RoundAll_v0110.py · PowerShell 7 'handle all': VRN2_HandleAll_v0102.md (same release folder; short paste line inside).
Runtime: VRN2_Runtime_v0154.zip = runtime v0153 (189 members byte-identical) + VRN2_ConsensusJoin_v0103,
restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).

New in v0154 (desktop 2026-10-30 20:09 · DUPKEY 0 after manager v0257 · close-out OPEN 'VRN-2 2' = step 6f consensus):
 - ConsensusJoin v0103 (thin tail over v0102): the first engine pass had 6933 / 7728 / 4171 answer 404 (no FactSet page); v0102 dropped them and
   ran the engine again, but the engine's checkpoint hash includes the code list -> no resume -> all 40 codes fetched again -> cnyes answered
   8358 / 2891 with pages without __NEXT_DATA__ -> gate FAIL_CLOSED. v0103: before every engine pass, today's fetched payloads are moved into
   the checkpoint of the code list being run (the engine's own hash / payload / archive functions) -> the engine resumes them offline;
   404 / transient failures are retried after a wait (only those codes are fetched); still failing -> no_coverage (404) / source_gap
   (transient · YELLOW · data source) and left out of the gate; Combined rows carry their own reason instead of the batch summary.
 - RoundAll v0110: close-out classes gate rows as 404 / transient / other; transient from ConsensusJoin < v0103 -> VRN-2 (root cause named) and
   step 5 re-runs 6f with v0103 (repair mode); source_gap -> data source; 6f rows + Combined consensus gaps = one item.
Verification: see VRN2_Verification_v0154.md. Hashes: PACKAGE_SHA256.json.
