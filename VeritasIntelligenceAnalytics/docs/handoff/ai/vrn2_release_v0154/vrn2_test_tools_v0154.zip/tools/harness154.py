"""t154d 重演:RoundAll(v0109 / v0110)只重做報告 → 收尾頁怎麼判;v0110 ⑤ 自動修(用套件 v0154 的 ConsensusJoin v0103 重跑 ⑥f)→ 收尾頁。
不連網:代理指到關著的埠(鉅亨 / Yahoo 都連不上 = 一時抓不到)· yfinance 用空殼(引擎的套件檢查要它在)。
用法:python harness154.py <沙盒> <RoundAll.py> <套件夾> <before|repair> <VRN-2 Python>"""
import importlib.util
import json
import os
import sys
from pathlib import Path

T, RA, PKG, MODE, PY = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4], sys.argv[5]
stub = Path(__file__).resolve().parent / "yfstub"
(stub / "yfinance").mkdir(parents=True, exist_ok=True)
(stub / "yfinance" / "__init__.py").write_text("__version__ = '0+sandbox-stub'\n\ndef Ticker(*a, **k):\n    raise RuntimeError('SANDBOX_STUB_NO_NETWORK')\n", encoding="utf-8")
dead = "http://127.0.0.1:9"
os.environ.update(HOME=str(T / "home"), USERPROFILE=str(T / "home"), VRN2_DOWNLOADS=str(T / "home" / "Downloads"), TMPDIR=str(T / "tmp"), TEMP=str(T / "tmp"), VIA_ROOT=str(T / "VIA"),
                  PYTHONPATH=str(stub), HTTPS_PROXY=dead, https_proxy=dead, HTTP_PROXY=dead, http_proxy=dead, NO_PROXY="", no_proxy="", VIA_VRN2_CONSENSUS_RETRY_WAIT="0", VRN2_NO_UI="1")
for k in ("VRN2_CONSENSUS_FIXTURES", "VIA_VRN2_NO_CONSENSUS"):
    os.environ.pop(k, None)
spec = importlib.util.spec_from_file_location("ra_h", RA)
ra = importlib.util.module_from_spec(spec)
sys.modules["ra_h"] = ra
spec.loader.exec_module(ra)
sys.stdout.reconfigure(encoding="utf-8")
root = T / "VIA"


class A:
    integrate = "no"


if MODE == "repair":
    ra.step_fix(root, PY, {"fetch_python": PY, "pkg": str(PKG)}, A())
rep = ra.diagnose(root, PY)
summary = {"tool": "%s %s" % (ra.NAME, ra.VERSION), "results": ra.RESULTS, "report": rep, "root": str(root), "package": str(PKG), "python": PY, "overall": ra.worst([r["lamp"] for r in ra.RESULTS])}
page = ra.step_closeout(root, summary)
doc = json.loads((root / "VIA_Reports" / "vrn2" / "VRN2_CloseoutUI_latest.json").read_text(encoding="utf-8"))
print("=" * 30, ra.VERSION, MODE, "· 收尾", doc.get("state"), doc.get("state_label"), json.dumps(doc.get("per_owner") or {}, ensure_ascii=False))
for it in doc.get("items") or []:
    if "⑥f" in str(it.get("step")) or "Combined" in str(it.get("step")):
        print("  [%s] %s · %s\n      為什麼:%s" % (it.get("owner"), it.get("step"), str(it.get("detail"))[:260], str(it.get("why"))[:420]))
cons = json.loads((root / "VIA_Reports" / "vrn2" / "consensus" / "VRN2_Consensus_latest.json").read_text(encoding="utf-8"))
print("  共識收據:", cons.get("engine_wrapper"), "· gate", cons.get("gate"), "· lamp", cons.get("lamp"), "· source_gap", sorted(cons.get("source_gap") or {}), "· no_coverage", sorted(cons.get("no_coverage") or {}),
      "· retries", len(cons.get("retries") or []) if "retries" in cons else "—", "· seed", [s.get("seeded") for s in cons.get("seed") or []])
