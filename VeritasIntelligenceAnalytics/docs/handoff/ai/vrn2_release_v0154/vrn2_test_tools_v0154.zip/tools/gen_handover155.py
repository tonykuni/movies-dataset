"""VRN2_Handover_v0155.md:從 v0154 只增不減(v0154 已推上分支 · 不改)。數字來自 release154/VRN2_Release_v0154.json 的 results(finalize154 寫)。"""
import json
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v154")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "VRN2_Handover_v0154.md").read_text(encoding="utf-8")
R = json.loads((W / "release154/VRN2_Release_v0154.json").read_text(encoding="utf-8")); res = R["results"]
rt = {f["path"]: f["sha256"][:12] for f in json.loads((W / "pkg154/VRN2_Runtime_v0154.json").read_text(encoding="utf-8"))["files"]}


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:100]); src = src.replace(a, b)


lines = src.split("\n"); assert lines[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0153 + VRN2_RoundAll_v0109 + VRN2_HandleAll_v0101 · 2026-10-30(")
lines[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0154 + VRN2_RoundAll_v0110 + VRN2_HandleAll_v0102 · 2026-10-30(v0153 + 桌機 20:09 整輪貼回 → "
            "ConsensusJoin v0103(拿掉代號再跑不整批重抓:今天抓到的搬進新清單的 checkpoint · 404 / 一時抓不到先重試 · 還是不過 → 不納入閘 · 暫缺算資料源 · 引擎沒產出不沿用上次的矩陣)· "
            "RoundAll v0110(⑥f 負責方分 404 / 一時抓不到 / 其他 · Combined 每列看自己的原因 · ⑤ 用 v0103 重跑 ⑥f · ⑥f 各列合一)· "
            "Handle-All v0102(auto → repair · 短開機行 1,719 字元 ASCII:PSReadLine 不再當掉);runtime v0153 的 189 個成員一個位元組都不動 · +1 個新檔;v0151 ~ v0153 發行夾逐位元不變)")
src = "\n".join(lines)
anchor = "> **桌機 2026-10-30 18:34(Handle-All v0100 → RoundAll v0108 verify · 527 秒)**"
new_round = ("> **桌機 2026-10-30 20:09(Handle-All v0101 → RoundAll v0109 整輪 · 2225 秒)**:⑪ 錯值 0 · 年度 11505 筆 · **沒有 DUPKEY**(管理器 v0257 改名 37 · 剔除 8 —— v0153 修的生效)· "
             "收尾 **OPEN · VRN-2 2 · VCGC 1 · 人工 2 · 資料源 2**:VRN-2 那兩項都是 ⑥f 共識 —— 第一次 43 檔 · 6933 / 7728 / 4171 回 404 → ConsensusJoin v0102 拿掉這三檔再跑 → "
             "引擎 checkpoint 的雜湊含代號清單 → 第二次 40 檔**全部重抓**(沒有一行 Resume)→ 8358 / 2891 `ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__` → gate FAIL_CLOSED。"
             "Combined 6 列被算成 404,其中 8358 / 2891 是因為 join 把整批摘要(含「…不納入閘:4171,6933,7728」)抄進每一列。之後貼 8.7k 字元的一行 → PSReadLine 2.4.5 `IndexOutOfRangeException`。\n"
             "> **本輪(v0154)**:① **ConsensusJoin v0103**(薄尾 · PRIOR v0102 · 引擎一字不改):每次跑引擎前,checkpoint 是今天的、清單不同 → 用引擎自己的函式把抓到的 payload 搬進這次清單的 checkpoint(續跑不上網)· "
             "不過列分 404 / 一時抓不到 / 其他 · 前兩種等一下重試(只重抓沒抓到的 · 30 秒 × n · 一時抓不到 2 次 · 404 1 次)· 還是不過 → no_coverage / source_gap(黃 · 資料源)拿掉再跑 · "
             "其他 → FAIL_CLOSED 照舊 · join 每列寫自己的原因 · 引擎這次沒有產出 → 不沿用上次的矩陣。② **RoundAll v0110**:收尾頁 ⑥f 照 v0103 的三類判負責方(v0103 以前做的一時抓不到 → VRN-2 寫根因)· "
             "Combined 每列原因 · ⑥f 各列 + Combined「共識缺」= 一項 · **⑤ 自動修**:用套件 runtime 的 v0103(只增不覆寫補放)重跑 ⑥f。③ **Handle-All v0102**:auto → **repair**(收據 v0153 以後 · 輸出冊在)· "
             "**短開機行**(ASCII 1,719 字元 · 從 GitHub 取 md、核對 Handle-All 那一行的 SHA-256 才執行)+ cmd 一行(pwsh -EncodedCommand)。④ **沙盒**:%s\n") % res.get("handover_line", "見 VRN2_Verification_v0154.md")
assert src.count(anchor) == 1
src = src.replace(anchor, new_round + anchor, 1)
anchor = "| **VRN2_HandleAll_v0101.md**(發行夾 · PowerShell 7 一段碼 · 不是 .ps1)| **v0101** | `vrn2_release_v0153` | 一行版 `"
rows = ("| **VRN2_HandleAll_v0102.md**(發行夾 · PowerShell 7 短開機行 + 一段碼 · 不是 .ps1)| **v0102** | `vrn2_release_v0154` | 一行版 `%s` · 短開機行 `%s` | **新**(套件 v0154 · RoundAll v0110 · auto → repair · 短開機行 ASCII %d 字元 · cmd 一行)|\n"
        "| **VRN2_RoundAll_v0110.py**(發行夾 · 一支入口 · 不在套件內)| **v0110** | `vrn2_release_v0154` | `%s` | **新**(套件 v0154 · ⑥f 三類負責方 · Combined 每列原因 · ⑤ 用 v0103 重跑 ⑥f · 自測 50 項)|\n"
        "| ActivateVRN-2_v0154.py(套件 · 底座 v0136)| **v0154** | 見發行清單 | `%s` | **新**(收據 v0154 · CONSENSUS_JOIN v0103 · 自測多一段 v0154)|\n"
        "| **VRN2_ConsensusJoin** | **v0103**(薄尾 · v0102 / v0101 / v0100 留著)| runtime v0154 | `%s` | **新**(今天的 payload 搬進新清單的 checkpoint · 404 / 一時抓不到重試 · no_coverage / source_gap · 不沿用上次的矩陣 · 13 項)|\n") % (
    R["handleall"]["line_sha256"][:12], R["handleall"]["boot_line_sha256"][:12], R["handleall"]["boot_line_chars"], R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12], rt["VRN2_ConsensusJoin_v0103.py"])
assert src.count(anchor) == 1
src = src.replace(anchor, rows + anchor, 1)
once("| **VRN2_RoundAll_v0109.py**(發行夾 · 一支入口 · 不在套件內)| **v0109** | `vrn2_release_v0153` | `716bfe2bd911` | **新**(",
     "| **VRN2_RoundAll_v0109.py**(發行夾 · 一支入口 · 不在套件內)| **v0109** | `vrn2_release_v0153` | `716bfe2bd911` | 被 v0110 取代(⑥f 一時抓不到算「別的不過」· Combined 404 抄整批摘要)· ")
once("## 7. 本輪(v0152 → v0153 + 管理器 v0257 + VRN2_RoundAll_v0109 + VRN2_HandleAll_v0101 · 桌機 18:34 Handle-All 貼回)",
     "## 7. 本輪(v0153 → v0154 + ConsensusJoin v0103 + VRN2_RoundAll_v0110 + VRN2_HandleAll_v0102 · 桌機 20:09 整輪貼回)\n\n| # | 剩下的 | 根因 | 修法 | 實測 |\n|---|---|---|---|---|\n"
     "| a | ⑥f gate FAIL_CLOSED(8358 / 2891 `ASSIGNED_JSON_NOT_FOUND`)· 收尾 VRN-2 2 項 | v0102 拿掉 404 代號再跑 → 引擎 checkpoint 雜湊含代號清單 → 整批重抓 → 鉅亨第二輪回沒有資料的頁 | ConsensusJoin v0103:今天的 payload 搬進新清單的 checkpoint · 404 / 一時抓不到重試 · 還是不過 → 不納入閘(暫缺 = 黃 · 資料源)| 自測 13(含不連網的引擎實跑)· 桌機狀態重演:v0109 OPEN VRN-2 2 → v0110 repair BLOCKED VRN-2 0 |\n"
     "| b | Combined 6 列算成 404(其中 2 列不是)| join 把整批摘要抄進每列;收尾頁用字串找「鉅亨沒有 FactSet 頁」| v0103 join 每列寫自己的原因 · RoundAll v0110 每列看代號 | 自測 ⑩ ㊺ |\n"
     "| c | 修 ⑥f 要再整輪 37 分鐘 | RoundAll 沒有只重跑 ⑥f 的路 | ⑤ 自動修:套件 runtime 的 v0103 補放 → 重跑 ⑥f → Combined;Handle-All auto → repair | 沙盒 e2e:auto → repair 29 秒 · 再一次 → 沒有要修的 |\n"
     "| d | PowerShell 7 貼 8.7k 字元一行就當掉 | PSReadLine 2.4.5 在 133 × 33 視窗的已知毛病 | 短開機行(ASCII 1,719 字元 · 約 13 行)取 md 核對 SHA-256 才執行 · cmd 一行不經輸入列 | 剖析 0 錯 · 詞序列相同 · 竄改 → 不執行 |\n"
     "| e | (沙盒整輪測出)引擎整批沒抓到時讀上次的矩陣當這次的 | v0101 只看矩陣檔在不在 | v0103 看矩陣時間:比這次早 → 不沿用 · engine_no_output → 收尾頁算資料源 | 自測 ⑫ ㊿ · 沙盒整輪(全部連不上)|\n"
     "| — | MOPS DENY(VCGC)· MQ-1560 OCR 4 點 / 年度缺項 3 份(人工)· Apple 非台股 / 神達 · 緯穎報告日前沒有還原價 / 鉅亨沒有 FactSet 頁(資料源)| VCGC 決定 / 要人看原文 / 外部來源 | 不在 VRN-2 | 收尾頁分好 |\n\n"
     "## 7.0q 前一輪(v0152 → v0153 + 管理器 v0257 + VRN2_RoundAll_v0109 + VRN2_HandleAll_v0101 · 桌機 18:34 Handle-All 貼回)")
once("| 0 | **(v0153 · 2026-10-30 18:34 後)**",
     "| 0 | **(v0154 · 2026-10-30 20:09 後)** 桌機 PowerShell 7 貼 `vrn2_release_v0154/VRN2_HandleAll_v0102.md` **最上面那行短的**(cmd 視窗用 cmd 那行)→ auto 選 repair(幾分鐘 · 不整輪)→ ⑥f 用 ConsensusJoin v0103 重跑 → 收尾頁 ⑥f 應是綠或資料源 · VRN-2 0;還是 VRN-2 → 貼回包 | 貼回 |\n"
     "| 0 | **(v0153 · 2026-10-30 18:34 後)**")
once("**v0153(2026-10-30)**:", "**v0154(2026-10-30)**:桌機 20:09 = OPEN(VRN-2 2 = ⑥f 共識 · 管理器 v0257 生效 DUPKEY 0);v0154 修 ⑥f(ConsensusJoin v0103)· 收尾頁 ⑥f 分類 · repair 模式 · 短開機行;沙盒重演 repair 後 VRN-2 0。\n\n**v0153(2026-10-30)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n",
     "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0154)** **「續跑沿用」要用引擎自己的規則驗**:共識引擎的 checkpoint 雜湊含代號清單 / 日期 / 模式 —— 換清單就是新的一份。要沿用就用它自己的函式(雜湊 · payload 路徑 · sha256 · 封存)搬,不要自己算。\n"
     "- **(v0154)** **一時抓不到 ≠ 程式錯**:`ASSIGNED_JSON_NOT_FOUND` / 逾時 / 429 / 5xx / 連線中斷 → 先等一下重試、只重抓那幾檔;重試後還是沒有 → 寫明「鉅亨這次沒給」(黃 · 資料源)。404 頁面不存在也可能一時的(7728)。\n"
     "- **(v0154)** **每列的原因要是那一列自己的**:不要把整批摘要抄進每列,收尾頁也不要用字串搜整批摘要來判斷某一檔。\n"
     "- **(v0154)** **引擎沒產出時不讀舊檔**:rc ≠ 0、沒有 Gate 行 → 矩陣 / 品質矩陣都可能是上次的;看檔案時間。\n"
     "- **(v0154)** **給操作員貼的一行要短**:PowerShell 7 的輸入列(PSReadLine)在小視窗貼很長的一行會當掉;長碼放 md,貼一行短的(ASCII)去取、核對 SHA-256 再執行。\n\n")
(REPO / "VRN2_Handover_v0155.md").write_text(src, encoding="utf-8", newline="\n"); print("handover v0155 lines", src.count("\n"))
