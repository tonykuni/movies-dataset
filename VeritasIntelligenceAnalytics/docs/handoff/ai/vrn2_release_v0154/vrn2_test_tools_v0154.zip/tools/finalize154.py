"""收尾 v0154:測試結果 → VRN2_Release_v0154.json.results · VRN2_Verification_v0154.md(套件 / RoundAll / Handle-All 已定,不重算)。"""
import json, re
from pathlib import Path
W = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad/v154"); rel = W / "release154"


def lines(p):
    try:
        return [re.sub(r"\x1b\[[0-9;]*m", "", l) for l in Path(p).read_text(encoding="utf-8", errors="replace").splitlines()]
    except OSError:
        return []


def grep(p, pat, all_=False):
    hits = [l for l in lines(p) if re.search(pat, l)]
    return hits if all_ else (hits[-1] if hits else "")


def short(s):
    return re.sub(r"/tmp/claude-0/[^ ·)(]*?/(t154[a-z]?|v154|v153)/", r"<\1>/", str(s))


def closeout(name):
    head = grep(W / ("ha154_%s.log" % name), r"^===== 收尾")
    owners = [l.strip() for l in grep(W / ("ha154_%s.log" % name), r"^  \[(VRN-2|VCGC|人工|資料源)\] \d+ 項", True)]
    return short(head.replace("===== ", "")) + (" · " + " · ".join(owners) if owners else "")


def harness(name):
    hd = grep(W / ("%s.log" % name), r"^={10,}")
    rc = grep(W / ("%s.log" % name), r"共識收據")
    return short(re.sub(r"^=+ ", "", hd)), short(rc.strip())


R = json.loads((rel / "VRN2_Release_v0154.json").read_text(encoding="utf-8"))
selft = {"VRN2_ConsensusJoin_v0103(引擎 v0121)": grep(W / "cj103_selftest.log", r"v0103 --selftest"),
         "VRN2_ConsensusJoin_v0103(只有 runtime 的引擎 v0120)": grep(W / "cj103_selftest_v0120.log", r"v0103 --selftest"),
         "VRN2_RoundAll_v0110": grep(W / "rall110_selftest.log", r"--selftest · .*不過"),
         "ActivateVRN-2_v0154(套件夾複本)": "%d 段 PASS · %s" % (len(grep(W / "ActivateVRN-2_v0154_selftest_iso.log", r"^\[PASS\] v01", True)), grep(W / "ActivateVRN-2_v0154_selftest_iso.log", r"^\[PASS\] v0154")[:150])}
cj_lines = grep(W / "cj103_selftest.log", r"^\[(PASS|FAIL)\] (②|③|④|⑤|⑥|⑦|⑧|⑨|⑩ join|⑪ 引擎實跑|⑫|⑬)", True)
eng = grep(W / "cj103_selftest.log", r"引擎實跑:離線").strip()
ps = lines(W / "pscheck154.log")
rep = {k: harness(k) for k in ("h154_before_VRN2_RoundAll_v0109", "h154_before_VRN2_RoundAll_v0110", "h154_repair_v0110")}
rep_lines = [short(l)[:260] for l in grep(W / "h154_repair_v0110.log", r"\[⑥f\] \[計\]|⑤ 自動修計畫|^\[(GREEN|YELLOW|RED)\] ⑤ 修", True)]
e2e = {"e_report(VRN2_MODE=report · 短開機行)": closeout("e_report"), "e_auto_repair(auto → repair)": closeout("e_auto_repair"), "e_auto_again(auto → repair · 再一次)": closeout("e_auto_again"),
       "e_cmd_report(cmd 一行 · pwsh -EncodedCommand)": closeout("e_cmd_report"), "e_tamper(分支上的 md 被改)": short(grep(W / "ha154_e_tamper.log", r"boot:")),
       "f_full_fixture(整輪 · ⑥f 離線 fixture)": closeout("f_full_fixture"), "g_full_live(整輪 · ⑥f 即時 · 全部連不上)": closeout("g_full_live")}
mode = {k: short(grep(W / ("ha154_%s.log" % k), r"④ 自動選模式"))[:200] for k in ("e_auto_repair", "e_auto_again")}
fix_again = short(grep(W / "ha154_e_auto_again.log", r"⑤ 自動修 · 沒有要修的"))
f6 = {k: short(grep(W / ("ha154_%s.log" % k), r"\[計\] ⑥f 共識合併"))[:300] for k in ("f_full_fixture", "g_full_live")}
st_rows = {k: grep(W / ("ha154_%s.log" % k), r"^\[(GREEN|YELLOW|RED)\] ③ 自測 · ", True) for k in ("f_full_fixture", "g_full_live")}
st_sum = {k: "%d 支 · 綠 %d · 非綠 %d" % (len(v), sum(1 for l in v if l.startswith("[GREEN]")), sum(1 for l in v if not l.startswith("[GREEN]"))) for k, v in st_rows.items()}
rc = (W / "ha154.rc").read_text(encoding="utf-8").strip().replace("\n", " · ")
R["results"] = {"selftests": selft, "consensus_selftest_lines": [l[:220] for l in cj_lines], "engine_run_no_network": eng[:300], "pscheck": ps,
                "desktop_2009_replay": {k: {"closeout": v[0], "consensus": v[1]} for k, v in rep.items()}, "repair_lines": rep_lines[:12],
                "handleall_e2e": e2e, "auto_mode": mode, "second_repair": fix_again, "full_run_6f": f6, "full_run_selftests": st_sum, "rc": rc,
                "handover_line": "沙盒(桌機 20:09 ⑥f 狀態 · 13 檔版):RoundAll v0109 = %s → v0110 = %s → v0110 repair = %s" % (rep["h154_before_VRN2_RoundAll_v0109"][0], rep["h154_before_VRN2_RoundAll_v0110"][0], rep["h154_repair_v0110"][0])}
(rel / "VRN2_Release_v0154.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")


def tbl(d):
    return "\n".join("| %s | %s |" % (k.replace("|", "\\|"), str(v).replace("|", "\\|")) for k, v in d.items())


md = """# VRN-2 v0154 驗證紀錄(2026-10-30 · ConsensusJoin v0103 · RoundAll v0110 · Handle-All v0102 短開機行)

## 1. 桌機 20:09 整輪(Handle-All v0101 → RoundAll v0109 · 2225 秒)看到的

- ⑪ 獨立驗證 v0114:錯值 0 · 年度 11505 筆 · 沒有 DUPKEY(管理器 v0257 改名 37 · 剔除 8 —— v0153 修的生效)。
- 收尾 **OPEN · VRN-2 2 · VCGC 1 · 人工 2 · 資料源 2**;VRN-2 那兩項都是 ⑥f 共識:
  第一次 43 檔(`Run ID RUN_20261030_120938`)· 6933 / 7728 / 4171 `TARGET_PRICE_STATUS_NOT_200: statusCode=404` → ConsensusJoin v0102「拿掉這三檔、同一個引擎再跑一次(其他代號續跑沿用)」→
  第二次 `Run ID RUN_20261030_121215` · **40 檔全部 `def Fetch`**(一行 `def Resume` 都沒有)→ 8358 / 2891 `ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__` → gate FAIL_CLOSED · rc 1。
- **根因**:引擎 `def_compute_pipeline_input_hash()` 的雜湊含 `codes`(代號清單)· 日期 · 模式 → 清單一變就不是同一份 checkpoint(`def_initialize_checkpoint` 封存舊的、開新的)→ v0102 說的「續跑沿用」沒有發生。
  同一天 14:36 那輪 7728 有 FactSet 頁、20:09 回 404 → 鉅亨對短時間的第二輪整批請求會回沒有資料的頁 / 404。
- 收尾頁另外把 Combined 6 列算成「鉅亨沒有這檔的 FactSet 頁(404)」:沒有共識的列,v0100 的 join 把**整批**摘要抄進 `CONSENSUS: 缺:`,那串摘要裡有
  「鉅亨沒有 FactSet 頁(404)不納入閘:4171,6933,7728」→ 8358 / 2891 也被算成 404。
- 之後再貼 8.7k 字元的 Handle-All 一行:PSReadLine 2.4.5 在 133 × 33 的視窗裡 `IndexOutOfRangeException`(`ConvertOffsetToPoint`)—— PowerShell 輸入列的毛病,不是 VRN-2 的碼。

## 2. 自測

| 檔 | 結果 |
|---|---|
%s

ConsensusJoin v0103 的各項:

```text
%s
```

引擎實跑(不連網 · 代理指到關著的埠 · yfinance 空殼):`%s`

## 3. PowerShell 剖析 + 雜湊鏈(pwsh 7.4.6)

```text
%s
```

## 4. 桌機 20:09 的 ⑥f 狀態重演(沙盒 13 檔版:第一次 4171 回 404 → v0102 拿掉再跑 → checkpoint 換新 → 2330 / 3661 沒有 __NEXT_DATA__ · 全部用引擎自己的 checkpoint 函式寫)

| 跑的 | 收尾 | 共識收據 |
|---|---|---|
%s

repair 那一輪 ⑤ 的過程(重演裡鉅亨連不上 → 2330 / 3661 / 4171 都是「一時抓不到」;桌機上 4171 會照樣回 404):

```text
%s
```

## 5. Handle-All v0102(短開機行 · 沙盒 GitHub 分支 · pwsh 7.4.6)

| 回合 | 結果 |
|---|---|
%s

- auto 選模式:`%s`
- 第二次 repair:`%s`
- 整輪 ⑥f:fixture = `%s`;即時(全部連不上)= `%s`
- 整輪 ③ 自測:%s
- 結束碼:%s

## 6. 限制(誠實寫)

- 容器連不到鉅亨 / Yahoo:即時路徑用「代理指到關著的埠」測(= 一時抓不到);404 的分類用自測的列與桌機的原文字串測。
- 沙盒的 yfinance / duckdb 是空殼,只讓套件檢查過(引擎真的匯入 duckdb 會失敗 → 照引擎沒有 duckdb 的路)· 不在套件裡。
- 沙盒的 VCGC 項(envcheck 缺 · 沒有合 VDF 界線的擷取 Python · 沒有 duckdb)是容器環境的,桌機以桌機收尾頁為準。
- 共識引擎檔(v0120 在 runtime · 桌機用的 v0121 在 functional modules\\VRN2)一字不改;v0103 只用它自己的函式搬 checkpoint。

## 7. 桌機下一步

PowerShell 7 貼 `VRN2_HandleAll_v0102.md` 最上面那行短的(1,719 字元 · 全是 ASCII)→ auto 選 **repair**(上一輪收據 v0153 · 輸出冊在)→
⑤ 用 ConsensusJoin v0103 重跑 ⑥f(今天的 checkpoint 才搬 · 明天起照引擎一天一抓)→ 收尾頁 ⑥f 應該是:全部過閘(綠)或「鉅亨這次沒給資料 / 沒有 FactSet 頁」(資料源)· VRN-2 0。
cmd 視窗用同一份 md 的 cmd 那行(不經 PowerShell 輸入列)。
""" % (tbl(selft), "\n".join(l[:220] for l in cj_lines), eng[:300], "\n".join(ps),
       "\n".join("| %s | %s | %s |" % (k.replace("h154_", "").replace("_VRN2_RoundAll", " RoundAll"), v[0].replace("|", "\\|"), v[1].replace("|", "\\|")) for k, v in rep.items()),
       "\n".join(rep_lines[:12]), tbl(e2e), " / ".join(mode.values()), fix_again, f6["f_full_fixture"], f6["g_full_live"], " · ".join("%s %s" % kv for kv in st_sum.items()), rc)
(rel / "VRN2_Verification_v0154.md").write_text(md, encoding="utf-8", newline="\n")
print(json.dumps(R["results"]["handover_line"], ensure_ascii=False))
print("verification md lines", md.count("\n"))
