#!/bin/bash
# Handle-All v0102 沙盒測試(短開機行):$1 = 沙盒 · $2 = 回合名 · $3 = line(PowerShell 7 貼短行)| cmd(pwsh -EncodedCommand)· 其餘 = env 指派
# 不連網:代理指到關著的埠 · yfinance / duckdb 空殼只給套件檢查看(引擎真的匯入 duckdb 時失敗 → 照引擎走沒有 duckdb 的路)
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v154; T=$W/$1; N="$2"; K="$3"; shift 3
P=$S2/venv_vrn2/bin/python; STUB=$W/stub154; DEAD=http://127.0.0.1:9
mkdir -p $STUB/yfinance $STUB/duckdb $T/tmp $T/home/Downloads
printf "__version__ = '0+sandbox-stub'\n\ndef Ticker(*a, **k):\n    raise RuntimeError('SANDBOX_STUB_NO_NETWORK')\n" > $STUB/yfinance/__init__.py
printf "import sys\nif not (sys.argv and sys.argv[0] == '-c'):\n    raise ImportError('sandbox stub: duckdb only for the package probe')\n__version__ = '0+probe-stub'\n" > $STUB/duckdb/__init__.py
if [ "$K" = cmd ]; then RUN=(-EncodedCommand "$(cut -d' ' -f6 $W/release154/boot_cmd.txt)"); else RUN=(-Command "$(cat $W/release154/boot_line.txt)"); fi
cd "$T/home" && env HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 \
  PYTHONPATH="$STUB" VIA_FETCH_PY="$P" HTTPS_PROXY=$DEAD https_proxy=$DEAD HTTP_PROXY=$DEAD http_proxy=$DEAD NO_PROXY= no_proxy= VIA_VRN2_CONSENSUS_RETRY_WAIT=0 \
  VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P --no-open --integrate no" "$@" \
  timeout 3000 "$S2/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass "${RUN[@]}" > $W/ha154_$N.log 2>&1
echo "$N rc $?" >> $W/ha154.rc
sed -i 's/\x1b\[[0-9;]*m//g' $W/ha154_$N.log
