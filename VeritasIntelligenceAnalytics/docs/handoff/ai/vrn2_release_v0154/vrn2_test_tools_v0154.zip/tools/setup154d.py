"""t154d = 桌機 2026-10-30 20:09 之後的 ⑥f 狀態(沙盒 13 檔版):第一次 13 檔 → 4171 回 404 → ConsensusJoin v0102 拿掉 4171 再跑 →
引擎 checkpoint 雜湊含代號清單 → 新的 12 檔 checkpoint(第一次的封存)→ 2330 / 3661 這次沒有 __NEXT_DATA__ → gate FAIL_CLOSED。
payload 用沙盒先前離線 fixture 跑出來的(當成「第一次抓到的」);全部用引擎自己的 checkpoint 函式寫。"""
import csv
import importlib.util
import json
import sys
from pathlib import Path

T = Path(sys.argv[1])
fm = T / "VIA" / "functional modules" / "VRN2"
v2 = T / "VIA" / "VIA_Reports" / "vrn2"
out = v2 / "consensus"


def load(path, alias):
    spec = importlib.util.spec_from_file_location(alias, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[alias] = mod
    spec.loader.exec_module(mod)
    return mod


eng = sorted(fm.glob("VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine_v0*.py"))[-1]
mod = load(eng, "eng_setup")
fx_cp = json.loads((out / mod.OUTPUT_CHECKPOINT).read_text(encoding="utf-8"))
codes13 = list(fx_cp["codes"])
assert "4171" in codes13 and "2330" in codes13 and "3661" in codes13 and len(codes13) == 13
NOPAGE = "TARGET_PRICE_STATUS_NOT_200: statusCode=404 message=頁面或商品不存在"
BLIP = "ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__"
# 第一次(13 檔 · 今天 · 即時)
_, cpA = mod.def_initialize_checkpoint(str(out), codes13, fixture_map={}, resume=True)
for c in codes13:
    if c == "4171":
        cpA.setdefault("failed", {})[c] = {"error": NOPAGE, "stage": "FETCH"}
        continue
    mod.def_save_checkpoint_payload(str(out), cpA, mod.def_load_checkpoint_payload(str(out), fx_cp, c))
cpA["status"] = "PARTIAL"
mod.def_save_checkpoint_state(out / mod.OUTPUT_CHECKPOINT, cpA)
# 第二次(v0102:拿掉 4171 · 清單變了 → 新 checkpoint · 整批重抓 · 2330 / 3661 沒有 __NEXT_DATA__)
codes12 = [c for c in codes13 if c != "4171"]
_, cpB = mod.def_initialize_checkpoint(str(out), codes12, fixture_map={}, resume=True)
assert cpB["input_hash"] != cpA["input_hash"] and not cpB["completed"]
for c in codes12:
    if c in ("2330", "3661"):
        cpB.setdefault("failed", {})[c] = {"error": BLIP, "stage": "FETCH"}
        continue
    mod.def_save_checkpoint_payload(str(out), cpB, mod.def_load_checkpoint_payload(str(out), cpA, c))
cpB["status"] = "PARTIAL"
mod.def_save_checkpoint_state(out / mod.OUTPUT_CHECKPOINT, cpB)
with (out / "factset_yfinance_consensus_quality_matrix.csv").open("w", encoding="utf-8-sig", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=["code", "check_id", "actual", "expected", "status", "severity", "note"])
    w.writeheader()
    for c in codes12:
        if c in ("2330", "3661"):
            w.writerow({"code": c, "check_id": "FETCH_PIPELINE", "actual": BLIP, "expected": "successful fetch", "status": "FAIL", "severity": "FAIL", "note": "Ticker fetch failed."})
        else:
            w.writerow({"code": c, "check_id": "HTTP_PAGE_200", "actual": "200", "expected": "200", "status": "PASS", "severity": "FAIL", "note": ""})
cons = json.loads((out / "VRN2_Consensus_latest.json").read_text(encoding="utf-8"))
per = {k: v for k, v in (cons.get("per_code") or {}).items() if k not in ("2330", "3661", "4171")}
why = "共識 10 / 12 代號(缺 2330,3661)· YFinance 中位數 10 · gate FAIL_CLOSED · rc 1 · 鉅亨沒有 FactSet 頁(404)不納入閘:4171"
cons.update(engine_wrapper="VRN2_ConsensusJoin 共識合併 v0102", gate="FAIL_CLOSED", rc=1, lamp="YELLOW", codes=codes12, codes_got=[c for c in codes12 if c in per], codes_missing=["2330", "3661"],
            per_code=per, no_coverage={"4171": NOPAGE}, first_gate={"gate": "FAIL_CLOSED", "rc": 1, "why": "共識 12 / 13 代號(缺 4171)· gate FAIL_CLOSED · rc 1"}, codes_all=codes13, why=why)
cons.pop("retries", None)
(out / "VRN2_Consensus_latest.json").write_text(json.dumps(cons, ensure_ascii=False, indent=1), encoding="utf-8")
cj = load(fm / "VRN2_ConsensusJoin_v0102.py", "cj102_setup")
joined = cj.join(v2)
rp = v2 / "VRN2_Closeout_v0153.json"
r = json.loads(rp.read_text(encoding="utf-8"))
detail = "共識 YELLOW:%s · Combined %s:%s" % (why, joined.get("lamp"), joined.get("why"))
for s in r["steps"]:
    if s["step"].startswith("⑥f"):
        s.update(lamp="YELLOW", detail=detail[:300])
r["consensus"] = {"lamp": "YELLOW", "detail": detail, "run": {"lamp": "YELLOW", "why": why, "gate": "FAIL_CLOSED", "rc": 1, "codes": codes12, "codes_missing": ["2330", "3661"]}, "join": {"lamp": joined.get("lamp"), "why": joined.get("why")}}
r["rc"] = 2
r.setdefault("market", {})["fetch_python"] = {"python": sys.argv[2], "requirements_from": "沙盒(桌機:合 VDF 界線的 via_core_312)"}   # 桌機的擷取環境是好的
r.pop("roundall", None)
rp.write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
(v2 / "VRN2_Closeout_v0153.before_roundall.json").write_text(json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
comb = json.loads((v2 / "output" / "VRN2_Combined_latest.json").read_text(encoding="utf-8"))
print("setup:", "A", cpA["input_hash"][:16], "B", cpB["input_hash"][:16], "completed B", len(cpB["completed"]), "· Combined", joined.get("lamp"), len(comb), "列 ·",
      [str(x.get("STATUS"))[:120] for x in comb if str(x.get("TICKER"))[:4] in ("2330", "4171")][:2])
