"""ActivateVRN-2_v0154.py = v0153 + ⑥f ConsensusJoin v0103(再跑不整批重抓 · 一時抓不到先重試 · 暫缺不納入閘)· 桌機 2026-10-30 20:09 整輪貼回。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v153/new/ActivateVRN-2_v0153.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0153: v0152 entry + the desktop run of 2026-10-30 18:34 (Handle-All v0100 → RoundAll v0108 verify: close-out BLOCKED · VRN-2 0).',
    '"""VRN-2 v0154: v0153 entry + the desktop run of 2026-10-30 20:09 (Handle-All v0101 → RoundAll v0109 full run · 2225 s · DUPKEY 0 ·\n'
    ' close-out OPEN "VRN-2 2" = step 6f consensus).\n\n'
    ' - step 6f: the first engine pass fetched 43 codes; 6933 / 7728 / 4171 answered "statusCode=404 頁面或商品不存在". ConsensusJoin v0102\n'
    '   dropped them and ran the engine again, but the engine\'s checkpoint hash includes the code list, so the second pass did not resume:\n'
    '   all 40 codes were fetched again and cnyes answered 8358 / 2891 with pages without __NEXT_DATA__ (ASSIGNED_JSON_NOT_FOUND) -> gate\n'
    '   FAIL_CLOSED. ConsensusJoin v0103 (thin tail over v0102): before every engine pass it moves today\'s fetched payloads into the\n'
    '   checkpoint of the code list being run (the engine\'s own hash / payload / archive functions) so the engine resumes them without\n'
    '   going online; 404 / transient fetch failures are retried after a wait (only the failed codes are fetched); still failing -> 404 in\n'
    '   no_coverage, transient in source_gap (YELLOW · data source) and left out of the gate; the Combined rows carry their own reason.\n'
    ' Runtime v0154 = runtime v0153 (189 members byte-identical) + VRN2_ConsensusJoin_v0103.\n\n'
    'v0153: v0152 entry + the desktop run of 2026-10-30 18:34 (Handle-All v0100 → RoundAll v0108 verify: close-out BLOCKED · VRN-2 0).')
for a, b in (('VERSION = "ActivateVRN-2 v0153"', 'VERSION = "ActivateVRN-2 v0154"'), ('RUNTIME_ZIP = "VRN2_Runtime_v0153.zip"', 'RUNTIME_ZIP = "VRN2_Runtime_v0154.zip"'),
             ('RUNTIME_MANIFEST = "VRN2_Runtime_v0153.json"', 'RUNTIME_MANIFEST = "VRN2_Runtime_v0154.json"'), ('RECEIPT_NAME = "VRN2_Closeout_v0153.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0154.json"'),
             ('launcher = root / "package" / "ActivateVRN-2_v0153.py"', 'launcher = root / "package" / "ActivateVRN-2_v0154.py"'),
             ('return lamp, detail + " · launcher v0153"', 'return lamp, detail + " · launcher v0154"'), ('print("NEXT: [%s] VRN-2 v0153 · rc %s', 'print("NEXT: [%s] VRN-2 v0154 · rc %s'),
             ('note="VRN-2 private runtime; exact ship v0153; manager v0257 (over v0255); shared VRN retained"', 'note="VRN-2 private runtime; exact ship v0154; manager v0257 (over v0255); consensus join v0103; shared VRN retained"'),
             ('CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0102.py"   # v0150: thin tail over v0101 (no-FactSet-page 404 codes left out of the gate) · v0101: TPEx → .TWO',
              'CONSENSUS_JOIN = "VRN2_ConsensusJoin_v0103.py"   # v0154: thin tail over v0102 (resume today\'s payloads on a new code list · retry transient · source_gap) · v0150: 404 out of the gate · v0101: TPEx → .TWO')):
    rep(a, b)
rep('CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"', 'CONSENSUS_JOIN, "VRN2_ConsensusJoin_v0102.py", "VRN2_ConsensusJoin_v0101.py", "VRN2_ConsensusJoin_v0100.py"', 3)
rep('assert cj.VERSION == "v0102" and cj.PRIOR.VERSION == "v0101" and cj.ticker_map(output)', 'assert cj.VERSION == "v0103" and cj.PRIOR.VERSION == "v0102" and cj.PRIOR.PRIOR.VERSION == "v0101" and cj.ticker_map(output)')
rep('assert cj.VERSION == "v0102" and sorted(cj.no_coverage(rows, ["2330", "6933", "4171"])) == ["4171", "6933"]', 'assert cj.VERSION == "v0103" and sorted(cj.no_coverage(rows, ["2330", "6933", "4171"])) == ["4171", "6933"]')
rep('''        assert cj.PRIOR.run is cj.run and cj.PRIOR.PRIOR.run is cj.run
''', '''        assert cj.PRIOR.run is cj.run and cj.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.run is cj.run and cj.PRIOR.PRIOR.PRIOR.join is cj.join
        transient = [{"code": "8358", "check_id": "FETCH_PIPELINE", "actual": "ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__", "status": "FAIL"}]
        nopage, blip, other = cj.classify(rows + transient + [{"code": "2330", "check_id": "HTTP_PAGE_200", "actual": "500", "status": "FAIL"}], ["2330", "6933", "4171", "8358"])
        assert sorted(nopage) == ["4171", "6933"] and list(blip) == ["8358"] and [r["code"] for r in other] == ["2330"]          # v0154: 404 · transient · other
        assert cj.seed_checkpoint(Path(temporary) / "none", "/no/engine.py", ["2330"]).get("seeded") == 0                       # nothing to move → the engine fetches as before
''')
rep('''    return {"lamp": lamp, "detail": detail, "run": {k: ran.get(k) for k in ("lamp", "why", "engine", "python", "codes", "codes_got", "codes_missing", "gate", "rc", "receipt", "yf_ticker_map", "yf_404") if k in ran},''',
    '''    return {"lamp": lamp, "detail": detail, "run": {k: ran.get(k) for k in ("lamp", "why", "engine", "python", "codes", "codes_got", "codes_missing", "gate", "rc", "receipt", "yf_ticker_map", "yf_404",
                                                                        "no_coverage", "source_gap", "first_gate", "retries", "seed") if k in ran},''')
rep('''    print("[PASS] v0153: manager v0257 is the active manager''', '''    cj103 = selftest_source(CONSENSUS_JOIN).read_text(encoding="utf-8")
    assert CONSENSUS_JOIN == "VRN2_ConsensusJoin_v0103.py" and 'VERSION = "v0103"' in cj103 and 'PRIOR_NAME = "VRN2_ConsensusJoin_v0102.py"' in cj103
    assert "def seed_checkpoint(" in cj103 and "def classify(" in cj103 and "VIA_VRN2_CONSENSUS_RETRIES" in cj103 and "source_gap" in cj103
    if Path(__file__).with_name(RUNTIME_ZIP).is_file():
        with zipfile.ZipFile(Path(__file__).with_name(RUNTIME_ZIP)) as bundle:
            cjs = sorted(n for n in bundle.namelist() if re.fullmatch(r"VRN2_ConsensusJoin_v\\d{4}\\.py", n))
        assert cjs[-1] == "VRN2_ConsensusJoin_v0103.py" and "VRN2_ConsensusJoin_v0102.py" in cjs, cjs[-3:]
    print("[PASS] v0154: ConsensusJoin v0103 is the active consensus join (today's payloads resumed on a new code list · 404 / transient retried · still failing → no_coverage / source_gap, out of the gate) · v0102 kept as PRIOR")
    print("[PASS] v0153: manager v0257 is the active manager''')
(S / "v154/new/ActivateVRN-2_v0154.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0154 lines", s.count("\n"))
