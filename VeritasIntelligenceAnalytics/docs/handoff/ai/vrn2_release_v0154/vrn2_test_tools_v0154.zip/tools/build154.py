"""v0154 整包重建(冪等):pkg154 → 套件 VRN2_Closeout_v0154.zip → VRN2_RoundAll_v0110.py(填套件雜湊)→ Handle-All v0102(填 RoundAll 雜湊 · 一行 + 可讀版)
→ 短開機行(PowerShell 7 · 只有 ASCII · 從 GitHub 取 Handle-All md、核對那一行的 SHA-256 才執行)+ cmd 一行(pwsh -EncodedCommand 同一段)→ md · 發行清單。
v0151 / v0152 / v0153 發行夾不動(已發行)。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v154"; out, rel, new = W / "pkg154", W / "release154", W / "new"
rel.mkdir(exist_ok=True)
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402

rt = json.loads((out / "VRN2_Runtime_v0154.json").read_text(encoding="utf-8")); assert rt["new_members"] == ["VRN2_ConsensusJoin_v0103.py"] and rt["retained_members"] == 189
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0154.py", "VRN2_Runtime_v0154.zip", "VRN2_Runtime_v0154.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0154 — VRN-2 closeout package (2026-10-30 · desktop Handle-All full run 20:09)\n\nEntry: python ActivateVRN-2_v0154.py [--source <folder>] [--no-install] [--no-open]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0110.py · PowerShell 7 'handle all': VRN2_HandleAll_v0102.md (same release folder; short paste line inside).\n"
  "Runtime: VRN2_Runtime_v0154.zip = runtime v0153 (189 members byte-identical) + VRN2_ConsensusJoin_v0103,\n"
  "restored into <VIA>/functional modules/VRN2 (private; shared functional modules/VRN untouched).\n\n"
  "New in v0154 (desktop 2026-10-30 20:09 · DUPKEY 0 after manager v0257 · close-out OPEN 'VRN-2 2' = step 6f consensus):\n"
  " - ConsensusJoin v0103 (thin tail over v0102): the first engine pass had 6933 / 7728 / 4171 answer 404 (no FactSet page); v0102 dropped them and\n"
  "   ran the engine again, but the engine's checkpoint hash includes the code list -> no resume -> all 40 codes fetched again -> cnyes answered\n"
  "   8358 / 2891 with pages without __NEXT_DATA__ -> gate FAIL_CLOSED. v0103: before every engine pass, today's fetched payloads are moved into\n"
  "   the checkpoint of the code list being run (the engine's own hash / payload / archive functions) -> the engine resumes them offline;\n"
  "   404 / transient failures are retried after a wait (only those codes are fetched); still failing -> no_coverage (404) / source_gap\n"
  "   (transient · YELLOW · data source) and left out of the gate; Combined rows carry their own reason instead of the batch summary.\n"
  " - RoundAll v0110: close-out classes gate rows as 404 / transient / other; transient from ConsensusJoin < v0103 -> VRN-2 (root cause named) and\n"
  "   step 5 re-runs 6f with v0103 (repair mode); source_gap -> data source; 6f rows + Combined consensus gaps = one item.\n"
  "Verification: see VRN2_Verification_v0154.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0154.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0154", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0154.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0154/" + n, date_time=(2026, 10, 30, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest(); (rel / "zip_sha.txt").write_text(want)
print("package", want[:12])
# ===== RoundAll v0110 =====
ra_src = (new / "VRN2_RoundAll_v0110.py").read_text(encoding="utf-8")
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, ra_src, count=1)
assert '"@PACKAGE_SHA256@"' not in ra and want in ra
(rel / "VRN2_RoundAll_v0110.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
print("roundall", ra_sha[:12])
boot0 = (S / "v151/release151/boot_roundall.ps1").read_text(encoding="utf-8")
ra_boot = boot0.replace("vrn2_release_v0151", "vrn2_release_v0154").replace("VRN2_RoundAll_v0107.py", "VRN2_RoundAll_v0110.py")
ra_boot = re.sub(r"\$H  = '[0-9a-f]{64}'", "$H  = '%s'" % ra_sha, ra_boot, count=1)
assert ra_sha in ra_boot and "v0151" not in ra_boot and "v0107" not in ra_boot
enc = base64.b64encode(ra_boot.encode("utf-16-le")).decode("ascii")
ra_one = "powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_one) < 8191
ra_pwsh = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + enc; assert len(ra_pwsh) < 8191
(rel / "boot_roundall.ps1").write_text(ra_boot, encoding="utf-8", newline="\n"); (rel / "oneline_roundall.txt").write_text(ra_one + "\n", encoding="utf-8"); (rel / "oneline_roundall_pwsh.txt").write_text(ra_pwsh + "\n", encoding="utf-8")
ps7 = (S / "v151/ps7/line_ps7_tpl.txt").read_text(encoding="utf-8").strip("\n").replace("vrn2_release_v0151", "vrn2_release_v0154").replace("@F@", "VRN2_RoundAll_v0110.py").replace("@H@", ra_sha)
assert ("$H = '%s'" % ra_sha) in ps7 and "vrn2_release_v0154" in ps7 and "v0151" not in ps7 and "exit" not in ps7
(rel / "oneline_roundall_ps7.txt").write_text(ps7 + "\n", encoding="utf-8")
# ===== Handle-All v0102 =====
ha_src = (W / "ps7/handleall_src.ps1").read_text(encoding="utf-8").replace("@H@", ra_sha)
assert ha_src.count(ra_sha) == 1 and "@" + "H@" not in ha_src and "vrn2_release_v0154" in ha_src and "VRN2_RoundAll_v0110.py" in ha_src and "exit" not in ha_src.replace("Exception", "")
ha_line = join(ha_src)
(rel / "handleall_src.ps1").write_text(ha_src, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
print("handle-all line", len(ha_line), "chars", ha_sha[:12])
# ===== 短開機行(PowerShell 7)+ cmd 一行 =====
bt_src = (W / "ps7/boot_src.ps1").read_text(encoding="utf-8").replace("@HA@", ha_sha)
bt_line = join(bt_src)
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800 and ha_sha in bt_line and not re.search(r"\bexit\b", bt_line)
(rel / "boot_src.ps1").write_text(bt_src, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
bt_sha = hashlib.sha256(bt_line.encode("utf-8")).hexdigest()
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(bt_line.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191
(rel / "boot_cmd.txt").write_text(cmd_line + "\n", encoding="utf-8")
print("boot line", len(bt_line), "chars", bt_sha[:12], "· cmd", len(cmd_line))
ha_md = r"""# VRN-2 · PowerShell 7 一段碼處理全部 · VRN2_HandleAll_v0102(2026-10-30 · 套件 v0154)

v0102 = v0101(桌機 20:09 整輪跑通:DUPKEY 0 · 管理器 v0257 改名 37 · 剔除 8 · 收尾 OPEN「VRN-2 2 項」= ⑥f 共識)+ 套件 v0154(ConsensusJoin v0103)+ RoundAll v0110,
再加一條**短的開機行**:PowerShell 7 的輸入列(PSReadLine 2.4.5)在 133 × 33 的視窗裡貼約 8,700 字元的一行會當掉
(`Oops, something went wrong` · `IndexOutOfRangeException` · `ConvertOffsetToPoint`)—— 那是 PowerShell 輸入列的毛病,不是 VRN-2 的碼。
短開機行只有 @BTLEN@ 個字元(全是 ASCII · 約 @BTROWS@ 行),它從 GitHub 取本檔、核對下面「Handle-All 那一行」的 SHA-256(`@HASHA12@`)相符才執行。

## PowerShell 7 視窗貼這一行(短 · 不會讓輸入列當掉)

```powershell
@BOOT@
```

## cmd 視窗貼這一行(內容 = 上面那行 · 經 pwsh 執行 · 不經 PowerShell 輸入列)

```bat
@CMD@
```

還是當掉(很窄的視窗):先在 PowerShell 7 貼 `Remove-Module PSReadLine`(只關這個視窗的輸入列加強 · 關掉視窗就恢復)再貼上面那一行。

## 它會做什麼

① 工具(git · python · VIA 倉)→ ② 有沒有別的 VRN-2 在跑 → ③ `Downloads` 的舊套件夾讀不讀得到(讀不到:列出來、問要不要以系統管理員身分還原權限 · 不擋)
→ ④ 選模式(預設 auto)→ ⑤ 從 GitHub 取 `VRN2_RoundAll_v0110.py` **核對 SHA-256**(`@RASHA12@`)→ ⑥ 執行 → ⑦ 印**收尾狀態**、各負責方的待辦、貼回包位置。
整段包在 `& { … }` 裡,錯了用 `return` —— **視窗不會關**。

## 模式(預設 auto)

| 模式 | 怎麼指定 | 做什麼 | 桌機時間 |
|---|---|---|---|
| `auto` | (不用設) | 上一輪收據是啟動器 **v0153 以後**、而且輸出冊在 → `repair`;不然 → `full` | — |
| `repair` | `$env:VRN2_MODE = 'repair'` | 取套件 v0154 → **⑤ 自動修**:⑥f 共識閘只因 404 / 一時抓不到 FAIL_CLOSED(ConsensusJoin v0103 以前做的)→ 套件的 ConsensusJoin v0103 只增不覆寫地補放 → 用它重跑 ⑥f(今天抓到的沿用 · 只重抓沒抓到的 · 重試)→ 重組 Combined → 增量庫 · Workbench → 除錯報告 → 收尾頁 → 貼回包 | 幾分鐘 |
| `full` | `$env:VRN2_MODE = 'full'` | 整輪:取套件 v0154 → 診斷 → 全部自測 → 跑啟動器 v0154 → 自動修 → 除錯報告 → 收尾頁 → 貼回包 | 約 40 分鐘 |
| `verify` | `$env:VRN2_MODE = 'verify'` | 取套件 v0154 → 只重跑 ⑪ 獨立驗證(IndependentVerifier v0114)→ 除錯報告 → 收尾頁 → 貼回包 | 約 10 分鐘 |
| `report` | `$env:VRN2_MODE = 'report'` | 只重做除錯報告 → 收尾頁 → 貼回包 | 幾秒 |

先在同一個視窗貼 `$env:VRN2_MODE = 'full'` 再貼那一行;用完 `Remove-Item Env:VRN2_MODE`。要用的模式需要上一輪輸出冊、但沒有 → 自動改跑整輪。

## 這次桌機(2026-10-30 20:09 整輪之後)貼下去會怎樣

上一輪收據是 `VRN2_Closeout_v0153.json`、輸出冊在 → auto 選 **repair**(不整輪):⑤ 看到 ⑥f 共識閘 FAIL_CLOSED 只因 8358 / 2891 一時抓不到(`ASSIGNED_JSON_NOT_FOUND`)
→ 用 ConsensusJoin **v0103** 重跑 ⑥f:今天的 checkpoint 是別份代號清單 → 抓到的 38 份搬進 43 檔清單的 checkpoint(引擎續跑沿用)→ 只重抓 8358 / 2891 / 4171 / 6933 / 7728
→ 還是 404 的不納入閘(鉅亨沒有 FactSet 頁)· 一時抓不到的重試(等 30 / 60 秒)· 還是沒有 → 「鉅亨這次沒給資料」(黃 · 資料源)→ 重組 Combined(那幾列寫它自己的原因)→ 收尾頁。
(明天以後再跑:checkpoint 不是今天的 → 照引擎一天一抓 43 檔;拿掉 404 再跑那次不再上網。)
收尾頁同一件事只列一次:⑥f 步驟列 + 共識閘 FAIL 列 + Combined 的「共識缺」= 一項。容器裡用同樣的流程重演了桌機 20:09 的狀態,結果在 `VRN2_Verification_v0154.md`。

## 環境變數(都可不設)

| 變數 | 用途 |
|---|---|
| `$env:VRN2_ROOT` | VIA 根(預設 `C:\Users\tonyk\OneDrive\Documents\movies-dataset\VeritasIntelligenceAnalytics`)· cmd 用 `set VRN2_ROOT=…` |
| `$env:VRN2_PY` | 指定 python(預設找 `python` / `py`,不用 WindowsApps 的假 python) |
| `$env:VRN2_MODE` | `auto` · `repair` · `full` · `verify` · `report` |
| `$env:VRN2_ROUNDALL_ARGS` | 多帶給 RoundAll 的參數(例 `'--integrate yes'`、`'--no-open'`) |
| `$env:VRN2_YES` | ② 有別的 VRN-2 在跑時不問、直接回答(`y` 繼續 · `n` 停) |
| `$env:VRN2_FIX_ACL` | ③ 舊套件夾讀不到時不問、直接回答(`y` 以系統管理員身分 `icacls /reset` · `n` 不動) |
| `$env:VRN2_NO_UI` | `1` = 跑完不開收尾頁 |
| `$env:VIA_VRN2_CONSENSUS_RETRY_WAIT` / `VIA_VRN2_CONSENSUS_RETRIES` | ⑥f 一時抓不到時等幾秒(預設 30 · 第 n 次 × n)/ 重試幾次(預設 2 · 0 = 不重試) |

## 程式碼決定不了的(收尾頁會分好)

- **交 VCGC**:⑥e MOPS 財報 —— VIA 鎖版網路工具的合規層拒絕(DENY),VRN-2 / VDF 不繞道。
- **人工核對**:MQ-1560 影像頁 OCR 摘錄對原圖(四點 4)· 年度數據缺項 3 份(原文真的沒有年度表就是沒有)。
- **資料源沒有**:GFHK Apple(代號 AAPL,不是台股)· 神達 3706 / 緯穎 6669 報告日前沒有還原價(VDF 日線視窗 PARTIAL)· 鉅亨沒有 FactSet 頁(404)· 鉅亨這次沒給資料(重試後仍沒有 · 下輪再抓)。

## Handle-All 那一行(短開機行從 GitHub 取這段、核對 SHA-256 `@HASHA12@` 相符才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
@LINE@
```

一行版 @HALEN@ 字元(UTF-8 · 不含結尾換行)· 下面「可讀版」是同一段碼(語法樹逐詞相同,只差換行 / 分號)。

## 可讀版 · Handle-All(跟一行版同一段碼)

```powershell
@SRC@
```

## 可讀版 · 短開機行(跟最上面那行同一段碼)

```powershell
@BTSRC@
```
"""
for k, v in (("@BOOT@", bt_line), ("@CMD@", cmd_line), ("@LINE@", ha_line), ("@SRC@", ha_src.rstrip("\n")), ("@BTSRC@", bt_src.rstrip("\n")), ("@RASHA12@", ra_sha[:12]), ("@HASHA12@", ha_sha[:12]),
             ("@BTLEN@", "{:,}".format(len(bt_line))), ("@BTROWS@", str(-(-len(bt_line) // 133))), ("@HALEN@", "{:,}".format(len(ha_line)))):
    ha_md = ha_md.replace(k, v)
assert "@" + "LINE@" not in ha_md and len(re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", ha_md)) == 1 and ha_md.count(ra_sha) == 2
got = re.search(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", ha_md).group(1)
assert got == ha_line and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == bt_line
(rel / "VRN2_HandleAll_v0102.md").write_text(ha_md, encoding="utf-8", newline="\n")
# ===== RoundAll v0110 md =====
ra_md = r"""# VRN-2 一支 Python · VRN2_RoundAll_v0110.py(一個指令:取套件 → 診斷 → 全部自測 → 跑 → 自動修 → ⑪b 重驗 → 除錯報告 → 收尾頁 HTML U/I → 貼回包)

`VRN2_RoundAll_v0110.py`(只用 Python 標準庫 · SHA-256 `@RASHA12@`)一支跑完 VRN-2 一輪;套件 = `VRN2_Closeout_v0154.zip`(SHA-256 `@WANT12@`,本檔內已釘死)。
**最省事:用 `VRN2_HandleAll_v0102.md` 最上面那一行短的**(PowerShell 7 · 自己選模式、檢查、取本檔、跑、印收尾狀態)。

**v0110(2026-10-30)= v0109 + 桌機 20:09 整輪的結果**(DUPKEY 0 · 管理器 v0257 改名 37 · 剔除 8 · 收尾 OPEN「VRN-2 2 項」= ⑥f 共識):

| 桌機看到的 | v0110 怎麼處理 |
|---|---|
| ⑥f 第一次 43 檔:6933 / 7728 / 4171 回 404 → ConsensusJoin v0102 拿掉再跑 → 第二次 40 檔**全部重抓**(引擎 checkpoint 雜湊含代號清單 · 對不上)→ 8358 / 2891 這次沒有 `__NEXT_DATA__` → gate FAIL_CLOSED | 套件 **v0154**:runtime v0154 = v0153 的 189 個成員不動 + **ConsensusJoin v0103**:跑引擎前把今天抓到的 payload 搬進這次清單的 checkpoint(引擎自己的函式 · 續跑不上網)· 404 / 一時抓不到先等一下重試(只重抓沒抓到的)· 還是不過 → 404 進 no_coverage · 一時抓不到進 source_gap(黃 · 資料源)→ 拿掉再跑 |
| 收尾頁把 ⑥f 步驟列 + 共識閘 FAIL 列算成 **VRN-2 2 項** | 共識閘不過列分 404 / 一時抓不到 / 其他;一時抓不到 + 是 v0103 以前做的 → VRN-2 1 項(寫出根因)· v0103 的 source_gap → 資料源 · ⑥f 各列 + Combined 的「共識缺」= 一項 |
| Combined 空格 6 列算成「鉅亨沒有 FactSet 頁(404)」,其中 8358 / 2891 不是 | 每列看它自己(代號在 no_coverage / source_gap)· 整批摘要裡的「…不納入閘:4171,6933,7728」不再算進別檔 |
| 要再整輪 37 分鐘才能修 ⑥f | **⑤ 自動修**(新):共識閘只因 404 / 一時抓不到、是 v0103 以前做的 → 套件的 ConsensusJoin 鏈只增不覆寫地補放 → 用 v0103 重跑 ⑥f → 重組 Combined → 增量庫 / Workbench;Handle-All v0102 的 `repair` 模式(`--only package,fix,report,closeout,pasteback`)|

自測 50 項(v0109 的 44 項 + ㊺ Combined 每列原因 · ㊻ ⑥f 負責方 · ㊼ ⑤ 重跑 ⑥f · ㊽ 同一件事只列一次 · ㊾ 補放 ConsensusJoin · ㊿ 共識引擎這次沒有產出)。前版 v0109 的修正見 `vrn2_release_v0153/VRN2_RoundAll_v0109.md`。

## 在 PowerShell 7 視窗裡直接貼(約 2,300 字元)

```powershell
@PS7@
```

只修 ⑥f + 收尾頁:同一個視窗先貼 `$env:VRN2_ROUNDALL_ARGS = '--only package,fix,report,closeout,pasteback'` 再貼上面那一行;只重做報告:`'--only report,closeout,pasteback'`;用完 `Remove-Item Env:VRN2_ROUNDALL_ARGS`。
貼長行讓 PowerShell 輸入列當掉 → 用 `VRN2_HandleAll_v0102.md` 最上面那行短的,或先貼 `Remove-Module PSReadLine`。

## cmd 可以貼的一行(PowerShell 7 · 內容 = 最下面的解開版)

```bat
@PWSH@
```

沒有 PowerShell 7 時(Windows PowerShell 5.1 · 內容一樣):

```bat
@ONE@
```

## 已經有這個檔時

```bat
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0110.py"
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0110.py" --only package,fix,report,closeout,pasteback
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0110.py" --only report,closeout,pasteback
```

第 2 行 = 只修(⑥f 用 v0103 重跑等)+ 收尾頁(幾分鐘)· 第 3 行 = 只重做報告 + 收尾頁(幾秒)。PowerShell 把 `%USERPROFILE%` 換成 `$env:USERPROFILE`。

## 一行解開來的程式碼(核對用 · cmd 那兩行解開都是這段)

```text
@BOOT@
```
"""
ra_md = ra_md.replace("@PS7@", ps7).replace("@RASHA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PWSH@", ra_pwsh).replace("@ONE@", ra_one).replace("@BOOT@", ra_boot.rstrip("\n"))
for kind, b64 in re.findall(r"(?s)```bat\n(pwsh|powershell) -NoProfile -ExecutionPolicy Bypass -EncodedCommand (\S+)\n```", ra_md):
    assert base64.b64decode(b64).decode("utf-16-le") == ra_boot
assert len(re.findall(r"EncodedCommand", ra_md)) == 2
(rel / "VRN2_RoundAll_v0110.md").write_text(ra_md, encoding="utf-8", newline="\n")
# ===== release json =====
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
r153 = json.loads((REPO / "vrn2_release_v0153/VRN2_Release_v0153.json").read_text(encoding="utf-8"))
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0154 (ConsensusJoin v0103) + VRN2_RoundAll_v0110 + VRN2_HandleAll_v0102 (PowerShell 7 · short paste line)", "date": "2026-10-30",
        "trigger": "桌機 2026-10-30 20:09 貼回 Handle-All v0101 整輪的主控台(2225 秒 · DUPKEY 0 · 收尾 OPEN · VRN-2 2 = ⑥f 共識 8358 / 2891 ASSIGNED_JSON_NOT_FOUND)+ 之後貼長行時 PSReadLine 2.4.5 當掉",
        "base_package": {"name": "VRN2_Closeout_v0153 (launcher v0153 · runtime v0153)", "retained": "runtime v0153 members byte-identical inside runtime v0154; ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0153 for the closeout entry; VRN2_RoundAll v0109 → v0110; VRN2_HandleAll v0101 → v0102. VRN-2 one-click v0151 / operator one-click v0112 / local round v0101 are not changed this round",
        "fixes": {"VRN2_ConsensusJoin_v0103": "desktop 20:09 step 6f: first pass 43 codes, 6933 / 7728 / 4171 → 404 (no FactSet page); v0102 dropped them and ran the engine again, but the engine's checkpoint hash includes the code list → no resume → all 40 codes fetched again → 8358 / 2891 answered pages without __NEXT_DATA__ (ASSIGNED_JSON_NOT_FOUND) → gate FAIL_CLOSED · rc 1. v0103 (thin tail over v0102): before every engine pass, today's payloads move into the checkpoint of the list being run (engine's own def_compute_pipeline_input_hash / def_save_checkpoint_payload / def_archive_checkpoint) → resumed offline; gate FAIL rows classed 404 / transient / other; 404 and transient retried after VIA_VRN2_CONSENSUS_RETRY_WAIT (30 s × n · transient up to VIA_VRN2_CONSENSUS_RETRIES = 2 · 404 once); still failing → no_coverage / source_gap (YELLOW) and left out of the gate; other FAIL → FAIL_CLOSED as before; join writes each row's own reason; engine produced nothing this pass (rc ≠ 0 · no Gate line) → the previous matrix is not reused (engine_no_output). selftest 13 incl. a real engine run with no network",
                  "RoundAll_v0110_owner": "gate rows 404 / transient / other (same classes as v0103); transient made by ConsensusJoin < v0103 → VRN-2 (root cause named); source_gap → data source; other → VRN-2; selftest ㊻",
                  "RoundAll_v0110_combined_reason": "Combined gaps by the row's own code (no_coverage / source_gap); the batch summary's '…不納入閘:4171,6933,7728' no longer marks other codes as 404 (desktop: 6 rows, 2 wrong); selftest ㊺",
                  "RoundAll_v0110_repair": "step 5: gate FAIL_CLOSED only from 404 / transient and made before v0103 → place the package runtime's ConsensusJoin chain + engine (manifest hash · add-only · same name different content refused) → re-run 6f with v0103 → Combined → store → Workbench; selftests ㊼ ㊾",
                  "RoundAll_v0110_one_item": "6f step row + gate FAIL rows + 'Combined' whose VRN-2 gaps are all consensus gaps = one close-out item; selftest ㊽",
                  "HandleAll_v0102": "auto → repair when the last receipt is launcher v0153+ and the books exist (only 6f changed this round); new mode repair = --only package,fix,report,closeout,pasteback",
                  "HandleAll_v0102_short_line": "PSReadLine 2.4.5 crashed (IndexOutOfRangeException · ConvertOffsetToPoint) on the ~8.7k-char pasted line in a 133×33 console: a %d-char ASCII boot line fetches VRN2_HandleAll_v0102.md from GitHub, checks the SHA-256 of the marked Handle-All line and runs it; the cmd line runs the same boot through pwsh -EncodedCommand (no PSReadLine)" % len(bt_line),
                  "launcher_v0154": "receipt VRN2_Closeout_v0154.json · CONSENSUS_JOIN v0103 · ⑥f receipt keeps no_coverage / source_gap / first_gate / retries / seed · selftest checks the runtime's newest ConsensusJoin is v0103 (v0102 kept)"},
        "not_fixed_here": {k: v for k, v in r153["not_fixed_here"].items() if k != "EST_1"} | {"cnyes_transient": "if cnyes still answers some codes without data after the retries, they stay YELLOW · data source (source_gap) until the next run"},
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0154.json inside the package"},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0109.py", "sha256": r153["roundall"]["sha256"], "status": "superseded 2026-10-30 (package v0153 · 6f transient counted as other · Combined 404 from batch summary); file kept in vrn2_release_v0153"}],
        "roundall": {"name": "VRN2_RoundAll_v0110.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0110.md"},
        "handleall": {"name": "VRN2_HandleAll_v0102.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "runs": "VRN2_RoundAll_v0110.py " + ra_sha,
                      "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line), "boot_line_ascii": True, "cmd_line_chars": len(cmd_line)},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · desktop 20:09 consensus state replayed (13-code sandbox)", "results": {"status": "see VRN2_Verification_v0154.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0154/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0154.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0154.py"]).hexdigest()},
        "test_tools_zip": "vrn2_test_tools_v0154.zip", "logs_zip": "logs_v0154.zip"}
(rel / "VRN2_Release_v0154.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
(rel / "ra_sha.txt").write_text(ra_sha); (rel / "ha_sha.txt").write_text(ha_sha); (rel / "bt_sha.txt").write_text(bt_sha)
print("built", sorted(p.name for p in rel.iterdir()))
