"""VRN2_RoundAll_v0110.py = v0109 + 套件 v0154(ConsensusJoin v0103:再跑不整批重抓 · 一時抓不到先重試)+ 收尾頁 ⑥f 負責方 / Combined 每列原因 + ⑤ 用 v0103 重跑 ⑥f。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v153/new/VRN2_RoundAll_v0109.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0109'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0109 — ', '"""VRN2_RoundAll v0110 — ', 1)
at = doc.index("v0109(桌機 2026-10-30 18:34")
doc = doc[:at] + r'''v0110(桌機 2026-10-30 20:09 · Handle-All v0101 整輪 2225 秒:DUPKEY 0 · 管理器 v0257 改名 37 · 剔除 8 · 收尾 OPEN「VRN-2 2 項」= ⑥f 共識):
  · 套件 v0154(啟動器 v0154 · runtime v0154 = v0153 的 189 個成員不動 + ConsensusJoin v0103)。⑥f 第一次 43 檔 · 6933 / 7728 / 4171 回 404 →
    v0102 拿掉這三檔再跑 → 引擎 checkpoint 雜湊含代號清單 → 對不上 → 40 檔全部重抓 → 8358 / 2891 這次拿到沒有 __NEXT_DATA__ 的頁 → gate FAIL_CLOSED。
    v0103:跑引擎前把今天抓到的 payload 搬進這次清單的 checkpoint(引擎自己的函式 · 續跑不上網)· 404 / 一時抓不到先等一下重試(只重抓沒抓到的)·
    重試後仍沒有 → 404 進 no_coverage · 一時抓不到進 source_gap(黃 · 資料源)→ 拿掉再跑;Combined 那幾列寫它自己的原因。
  · 收尾頁:共識閘不過列分 404 / 一時抓不到 / 其他(同 v0103)· 一時抓不到 + 收據是 v0103 以前做的 → VRN-2(說明根因 · ⑤ 會用 v0103 重跑)·
    v0103 做的 source_gap → 資料源(鉅亨這次沒給)· 其他 → VRN-2。⑥f 的步驟列 / 共識閘 FAIL 列 / 鉅亨這次沒給 / ⑤ 修 ⑥f = 同一件事只列一次。
  · Combined 空格原因:每列看它自己(代號在 no_coverage / source_gap)· 整批摘要裡「鉅亨沒有 FactSet 頁(404)不納入閘:…」那串代號不再讓別檔也算成 404
    (桌機 6 列算成 404,其實 8358 / 2891 不是)。
  · ⑤ 自動修(新):共識閘 FAIL_CLOSED 只因 404 / 一時抓不到、而且是 ConsensusJoin v0103 以前做的 → 先把套件 runtime 的 ConsensusJoin 鏈與共識引擎
    只增不覆寫地放進 functional modules\\VRN2(核對清單雜湊 · 同名不同內容不覆寫)→ 用 v0103 重跑 ⑥f(沿用今天抓到的)→ 重組 Combined → 增量庫 / Workbench。
    v0103 也不再把上次的矩陣當這次的(引擎整批沒抓到 · 沒有 Gate 行)→ 收尾頁算資料源(網路被擋 → VCGC)。
    給 Handle-All v0102 的「repair」模式用(上一輪輸出冊是啟動器 v0153 做的 → 不整輪 · 只修 ⑥f · 幾分鐘)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0109.py", "用法:python VRN2_RoundAll_v0110.py")
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
body = body.replace("v0153", "v0154")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0109"', 'VERSION = "v0110"')
rep('("VRN2_ConsensusJoin_v0102.py", 900)', '("VRN2_ConsensusJoin_v0103.py", 900)')
# --- 共識閘不過列的分法(同 ConsensusJoin v0103)---
rep('''_NO_PAGE = re.compile(r"statusCode=404|頁面或商品不存在|鉅亨沒有 FactSet 頁")
''', r'''_NO_PAGE = re.compile(r"statusCode=404|頁面或商品不存在|鉅亨沒有 FactSet 頁")
_TRANSIENT = re.compile(r"ASSIGNED_JSON_NOT_FOUND|NEXT_DATA_NOT_OBJECT|PAGE_PROPS_NOT_OBJECT|JSON_DECODE_FAILED|HTTP_GET_FAILED|HTTP_STATUS_(?:408|425|429|5\d\d)"
                        r"|HTTP Error (?:408|425|429|5\d\d)|timed out|[Tt]imeout|Connection ?(?:[Rr]eset|aborted|refused)|RemoteDisconnected|IncompleteRead|Temporary failure")   # v0110 同 ConsensusJoin v0103
_PERMANENT = re.compile(r"HTTP Error (?:400|401|403|404|410)\b")
_LISTS = re.compile(r"(?:鉅亨沒有 FactSet 頁\(404\)|鉅亨這次沒給資料\(抓了 \d+ 次\)暫)不納入閘:[\d,]+")   # v0110 整批摘要裡的代號清單(不是這一列自己的原因)


def gate_rows(v2) -> tuple:
    """v0110 共識品質閘不過的列 → (404 代號, 一時抓不到的代號, 其他代號)· 分法同 ConsensusJoin v0103。"""
    nopage, transient, other = set(), set(), set()
    for r in quality_fails(v2) if Path(v2).is_dir() else []:
        code, text = str(r.get("code") or "").strip(), "%s %s" % (r.get("actual") or "", r.get("note") or "")
        if _NO_PAGE.search(text):
            nopage.add(code)
        elif str(r.get("check_id") or "") == "FETCH_PIPELINE" and _TRANSIENT.search(text) and not _PERMANENT.search(text):
            transient.add(code)
        else:
            other.add(code)
    return nopage, transient, other


def combined_consensus_only(gaps: dict) -> bool:
    """v0110 Combined 算到 VRN-2 的空格全是「共識缺」(⑥f 沒抓到的後果)→ 收尾頁跟 ⑥f 算同一件事。"""
    adj = [w for w in (gaps.get("TARGET_PRICE(ADJ)") or {}) if not re.search(r"原文沒有目標價|沒有市場資料|代號不是台股 4 碼|報告日前沒有日資料|MISSING|沒有目標價或還原因子", w)]
    cons = [w for col, d in gaps.items() if col not in ("TARGET_PRICE(ADJ)", "_files") and isinstance(d, dict) for w in d if w.startswith("共識缺:") and not re.search(r"yfinance|via_tw_fetch|擷取環境", w)]
    return not adj and bool(cons)
''')
# --- Combined 空格:每列看它自己 ---
rep('''def combined_gaps(comb, no_cov=(), fetch_env_ok=None) -> tuple:''', '''def combined_gaps(comb, no_cov=(), fetch_env_ok=None, gap=()) -> tuple:''')
rep('''            if col in r and not str(r.get(col) or "").strip():
                m = re.search(r"CONSENSUS: 缺:([^|]*)", st)
                fname = str(r.get("FILENAME") or "")
                if (code and code in no_cov) or _NO_PAGE.search(st):
                    add(col, "鉅亨沒有這檔的 FactSet 頁(404)", "資料源", fname)
                elif m:''', '''            if col in r and not str(r.get(col) or "").strip():
                st_row = _LISTS.sub("", st)                                    # v0110 整批摘要的代號清單不算這一列的原因
                m = re.search(r"CONSENSUS: 缺:([^|]*)", st_row)
                fname = str(r.get("FILENAME") or "")
                if (code and code in no_cov) or _NO_PAGE.search(st_row):
                    add(col, "鉅亨沒有這檔的 FactSet 頁(404)", "資料源", fname)
                elif (code and code in gap) or "鉅亨這次沒給資料" in st_row:
                    add(col, "鉅亨這次沒給資料(暫缺 · 下輪再抓)", "資料源", fname)
                elif "共識引擎這次沒有產出" in st_row:
                    add(col, "共識引擎這次沒有產出(整批沒抓到)", "資料源", fname)
                elif m:''')
rep('''    no_cov = {str(c) for c in (cons.get("no_coverage") or {})}
    other = set()
    for r in quality_fails(v2) if v2.is_dir() else []:
        (no_cov if _NO_PAGE.search(str(r.get("actual") or "") + " " + str(r.get("note") or "")) else other).add(str(r.get("code") or "").strip())
    ctx = {"receipt": bool(receipt), "mops_deny": "Existing VIA network bridge denied" in text, "fetch_env_ok": (bool(fpick.get("python")) if isinstance(fpick, dict) else None),
           "no_cov": no_cov - other, "gate_other": other}
    comb = jread(v2 / "output" / "VRN2_Combined_latest.json", None)
    ctx["combined_gaps"], ctx["combined_owner"] = combined_gaps(comb if isinstance(comb, list) else [], ctx["no_cov"], ctx["fetch_env_ok"])''',
    '''    no_cov = {str(c) for c in (cons.get("no_coverage") or {})}
    q404, qtr, other = gate_rows(v2)                                          # v0110 一時抓不到另算(不再當成「別的不過」)
    no_cov |= q404
    ctx = {"receipt": bool(receipt), "mops_deny": "Existing VIA network bridge denied" in text, "fetch_env_ok": (bool(fpick.get("python")) if isinstance(fpick, dict) else None),
           "no_cov": no_cov - other - qtr, "gate_other": other, "gate_transient": qtr, "source_gap": {str(c): v for c, v in (cons.get("source_gap") or {}).items()},
           "cj_v0103": "retries" in cons, "engine_no_output": cons.get("engine_no_output")}
    comb = jread(v2 / "output" / "VRN2_Combined_latest.json", None)
    ctx["combined_gaps"], ctx["combined_owner"] = combined_gaps(comb if isinstance(comb, list) else [], ctx["no_cov"], ctx["fetch_env_ok"], set(ctx["source_gap"]))''')
# --- owner_of ⑥f ---
rep('''        if "共識閘 FAIL 列" in step or re.search(r"共識 (YELLOW|RED)", detail):
            if re.search(r"缺 yfinance|擷取環境缺", detail) or ctx.get("fetch_env_ok") is False and "共識 GREEN" not in detail:
                return "VCGC", "共識要 yfinance(擷取環境)→ VCGC 建 via_tw_fetch"
            if ctx.get("no_cov") and not ctx.get("gate_other"):
                return "資料源", "鉅亨沒有 %s 的 FactSet 頁(404)· 其他代號閘照評" % ",".join(sorted(ctx["no_cov"]))
            return "VRN-2", ""''', '''        if "共識閘 FAIL 列" in step or "鉅亨這次沒給" in step or re.search(r"共識 (YELLOW|RED)|共識合併 v\\d{4} · run", detail):
            if re.search(r"缺 yfinance|擷取環境缺", detail) or ctx.get("fetch_env_ok") is False and "共識 GREEN" not in detail:
                return "VCGC", "共識要 yfinance(擷取環境)→ VCGC 建 via_tw_fetch"
            if ctx.get("engine_no_output"):                                   # v0110 引擎這次沒有產出(品質矩陣 / 矩陣都是上次的 · 不看)
                return "資料源", ("共識引擎這次整批沒抓到(%s)· 上次的矩陣不沿用 · 網路被擋(VIA 網路工具 / 代理)→ 交 VCGC · 鉅亨沒回 → 下輪再抓"
                                  % str((ctx["engine_no_output"] or {}).get("last") or "")[:80])
            if ctx.get("gate_other"):                                         # v0110 404 / 一時抓不到以外的不過
                return "VRN-2", "共識閘有 404 / 一時抓不到以外的不過(%s)→ 看 consensus\\\\factset_yfinance_consensus_quality_matrix.csv" % ",".join(sorted(ctx["gate_other"]))
            if ctx.get("gate_transient") and not ctx.get("cj_v0103"):
                return "VRN-2", ("%s 一時抓不到(第一次有):ConsensusJoin v0103 以前拿掉 404 代號再跑時代號清單變了 → 引擎 checkpoint 對不上 → 整批重抓"
                                 " → v0103 起沿用今天抓到的 · ⑤ 自動修用 v0103 重跑 ⑥f" % ",".join(sorted(ctx["gate_transient"])))
            if ctx.get("gate_transient"):
                return "資料源", "鉅亨整批沒給資料(%s · ConsensusJoin v0103 重試後仍抓不到)· 下輪再抓" % ",".join(sorted(ctx["gate_transient"]))
            if ctx.get("source_gap"):
                tries = max(int((v or {}).get("tries") or 1) for v in ctx["source_gap"].values())
                return "資料源", "鉅亨這次沒給 %s 的資料(抓了 %d 次仍沒有 · 下輪再抓)%s · 其他代號閘照評" % (
                    ",".join(sorted(ctx["source_gap"])), tries, (" · 沒有 FactSet 頁(404):%s" % ",".join(sorted(ctx["no_cov"]))) if ctx.get("no_cov") else "")
            if ctx.get("no_cov"):
                return "資料源", "鉅亨沒有 %s 的 FactSet 頁(404)· 其他代號閘照評" % ",".join(sorted(ctx["no_cov"]))
            return "VRN-2", ""''')
# --- 同一件事只列一次:⑥f ---
rep('''    if owner == "VCGC" and ctx.get("mops_deny") and re.match(r"⑥ (步驟 ⑥e 市場擷取|⑥e 擷取錯誤|⑥e MOPS)", step):
        return "VCGC|⑥e MOPS DENY"
    return ""''', '''    if owner == "VCGC" and ctx.get("mops_deny") and re.match(r"⑥ (步驟 ⑥e 市場擷取|⑥e 擷取錯誤|⑥e MOPS)", step):
        return "VCGC|⑥e MOPS DENY"
    if "⑥f" in step and "Yahoo 代號" not in step:                          # v0110 ⑥f 步驟列 · 共識閘 FAIL 列 · 鉅亨這次沒給 · ⑤ 修 ⑥f = 同一次共識
        return "⑥f 共識"
    if step.startswith("⑥ Combined 冊") and owner == "VRN-2" and combined_consensus_only(ctx.get("combined_gaps") or {}):   # v0110 VRN-2 的空格全是 ⑥f 的後果
        return "⑥f 共識"
    return ""''')
# --- ⑤ 自動修:用 v0103 重跑 ⑥f ---
rep('''    if fetch_py and run.get("lamp") == "YELLOW" and "yfinance" in str(run.get("why", "")) and os.environ.get("VIA_VRN2_NO_CONSENSUS") != "1":
        plan.append(("consensus", "⑥f 缺 yfinance · 找到 %s → 重跑共識" % fetch_py))
''', '''    if fetch_py and run.get("lamp") == "YELLOW" and "yfinance" in str(run.get("why", "")) and os.environ.get("VIA_VRN2_NO_CONSENSUS") != "1":
        plan.append(("consensus", "⑥f 缺 yfinance · 找到 %s → 重跑共識" % fetch_py))
    cons_now = jread(cjson, {}) or {}
    q404, qtr, qother = gate_rows(v2)
    if (fetch_py and not any(k == "consensus" for k, _ in plan) and str(cons_now.get("gate") or run.get("gate") or "").upper() == "FAIL_CLOSED" and (q404 or qtr) and not qother
            and "retries" not in cons_now and os.environ.get("VIA_VRN2_NO_CONSENSUS") != "1"):          # v0110 ConsensusJoin v0103 以前做的
        plan.append(("consensus", "⑥f 共識閘只因 404 / 一時抓不到(%s) → 用 ConsensusJoin v0103 重跑(沿用今天抓到的 · 重試 · 暫缺不納入閘)" % ",".join(sorted(q404 | qtr))[:40]))
''')
rep('''        elif key == "consensus":
            cj = _latest_in(rt, "VRN2_ConsensusJoin_v[0-9][0-9][0-9][0-9].py")
            rc, lines = run_stream([vpy, "-X", "utf8", str(cj), "run", "--v2", str(v2), "--root", str(root)], cwd=rt, env=env, timeout=1200, prefix="    [⑥f] ")
            lamp, detail = _cli_lamp(lines)''', '''        elif key == "consensus":
            put, refused = place_consensus(state.get("pkg"), root)               # v0110 套件 runtime 的 ConsensusJoin 鏈 / 共識引擎只增不覆寫地補放
            cj = _latest_in(rt, "VRN2_ConsensusJoin_v[0-9][0-9][0-9][0-9].py")
            rc, lines = run_stream([vpy, "-X", "utf8", str(cj), "run", "--v2", str(v2), "--root", str(root)], cwd=rt, env=env, timeout=1200, prefix="    [⑥f] ")
            lamp, detail = _cli_lamp(lines)
            if put or refused:
                detail = ("%s%s · %s" % (("補放 " + "、".join(put)) if put else "", (" · 不覆寫 " + "、".join(refused)) if refused else "", detail)).strip(" ·")''')
rep('''# ===== 8b. ⑪b 只重跑獨立驗證(v0108)=====''', '''def place_consensus(pkg, root) -> tuple:
    """v0110 ⑤ 重跑 ⑥f 前:套件 runtime 的 ConsensusJoin 鏈與共識引擎(核對清單雜湊)只增不覆寫地放進 functional modules\\\\VRN2
    (修 / 只重做報告的輪次啟動器沒跑 → runtime 沒還原)。回 (補放了哪些, 同名不同內容沒覆寫的)。"""
    if not pkg or not (Path(pkg) / RUNTIME_ZIP).is_file():
        return [], []
    with zipfile.ZipFile(Path(pkg) / RUNTIME_ZIP) as z:
        names = sorted(n for n in z.namelist() if re.fullmatch(r"(VRN2_ConsensusJoin|VIA_CNYES_FactSet_YFinance_Consensus_Fusion_Engine)_v\\d{4}\\.py", n))
    put, refused = [], []
    for name in names:
        got, why = install_runtime_member(pkg, root, name)
        if got is None:
            refused.append(name)
        elif why == "補放":
            put.append(name)
    return put, refused


# ===== 8b. ⑪b 只重跑獨立驗證(v0108)=====''')
rep('''        guarded("⑤ 自動修", step_fix, root, vpy, state, args)''', '''        guarded("⑤ 自動修", step_fix, root, vpy, dict(state, pkg=pkg), args)      # v0110 ⑥f 重跑要套件 runtime''')
# --- 除錯報告:鉅亨這次沒給資料 ---
rep('''          "共識引擎(原樣內附)品質閘不過就 FAIL_CLOSED;FactSet 沒有覆蓋的代號(未評等 / 新上市)= 真的沒有,其餘看 quality_matrix.csv")
''', '''          "共識引擎(原樣內附)品質閘不過就 FAIL_CLOSED;FactSet 沒有覆蓋的代號(未評等 / 新上市)= 真的沒有,其餘看 quality_matrix.csv")
    gap = cons_rec.get("source_gap") or {}
    if gap:                                                                   # v0110 ConsensusJoin v0103 重試後仍抓不到
        tries = cons_rec.get("retries") or []
        f("YELLOW", "⑥f 鉅亨這次沒給資料", "%d 檔 · %s · 重試 %d 次(等 %s 秒)· 這幾檔不納入閘、其他代號照評 · Combined 那幾列寫「鉅亨這次沒給資料」" % (
            len(gap), " | ".join("%s 抓了 %s 次:%s" % (c, (v or {}).get("tries"), str((v or {}).get("why") or "")[:80]) for c, v in sorted(gap.items())[:6]),
            len(tries), " / ".join(str(t.get("wait_s")) for t in tries) or "—"),
          "鉅亨對這幾檔回的頁沒有資料(例:ASSIGNED_JSON_NOT_FOUND = 頁面沒有 __NEXT_DATA__)· 不是 VRN-2 的程式 · 下輪再抓")
''')
# --- 自測 ㊺ ~ ㊾ ---
rep('''            and lead["owner"] == "VRN-2" and "同一件事另見" in lead["why"] and lead["also"] == ["⑥ 步驟 ⑪ 獨立驗證(背景 · 只讀)"])
    for k, v in saved_env.items():''', r'''            and lead["owner"] == "VRN-2" and "同一件事另見" in lead["why"] and lead["also"] == ["⑥ 步驟 ⑪ 獨立驗證(背景 · 只讀)"])
        # ㊺ ~ ㊾ v0110 ⑥f 共識(桌機 20:09)
        r10 = td / "r110" / "VIA"
        v10 = r10 / "VIA_Reports" / "vrn2"
        (v10 / "consensus").mkdir(parents=True)
        (v10 / "output").mkdir(parents=True)
        (v10 / "output" / "VRN2_BasicInfo_latest.json").write_text("[]", encoding="utf-8")
        qm = v10 / "consensus" / "factset_yfinance_consensus_quality_matrix.csv"
        qm.write_text("\ufeffcode,check_id,actual,expected,status,severity,note\n8358,FETCH_PIPELINE,ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__,successful fetch,FAIL,FAIL,Ticker fetch failed.\n"
                      "2891,FETCH_PIPELINE,ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__,successful fetch,FAIL,FAIL,Ticker fetch failed.\n2330,HTTP_PAGE_200,200,200,PASS,FAIL,ok\n", encoding="utf-8")
        why102 = "共識 38 / 40 代號(缺 8358,2891)· gate FAIL_CLOSED · rc 1 · 鉅亨沒有 FactSet 頁(404)不納入閘:4171,6933,7728"
        (v10 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps({"gate": "FAIL_CLOSED", "why": why102, "no_coverage": {"4171": "404", "6933": "404", "7728": "404"}}, ensure_ascii=False), encoding="utf-8")
        comb10 = [{"TICKER": "8358", "FILENAME": "a.pdf", "TARGET_PRICE": "", "FACTSET_TARGET_PRICE_MEDIAN": "", "STATUS": "CONSENSUS: 缺:" + why102 + " | BASIC: B"},
                  {"TICKER": "6933", "FILENAME": "b.pdf", "TARGET_PRICE": "", "FACTSET_TARGET_PRICE_MEDIAN": "", "STATUS": "CONSENSUS: 缺:" + why102 + " | BASIC: B"}]
        g1, o1 = combined_gaps(comb10, {"6933", "4171", "7728"}, True)
        g2, o2 = combined_gaps(comb10, {"6933"}, True, {"8358"})
        chk("㊺ Combined 空格每列看它自己:整批摘要裡「鉅亨沒有 FactSet 頁(404)不納入閘:4171,6933,7728」不再讓 8358 也算 404(桌機 6 列裡 2 列算錯)· 8358 在 source_gap → 鉅亨這次沒給(資料源)",
            g1["FACTSET_TARGET_PRICE_MEDIAN"].get("鉅亨沒有這檔的 FactSet 頁(404)") == 1 and o1 == "VRN-2" and g2["FACTSET_TARGET_PRICE_MEDIAN"] == {"鉅亨沒有這檔的 FactSet 頁(404)": 1, "鉅亨這次沒給資料(暫缺 · 下輪再抓)": 1} and o2 == "資料源")
        q404, qtr, qot = gate_rows(v10)
        cx10 = closeout_context(r10)
        row10 = {"lamp": "YELLOW", "step": "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)", "detail": "共識 YELLOW:" + why102 + " · Combined GREEN:Combined 52 列"}
        own102 = owner_of(row10, cx10)
        cx10b = dict(cx10, gate_transient=set(), cj_v0103=True, source_gap={"2891": {"why": "ASSIGNED_JSON_NOT_FOUND: __NEXT_DATA__", "tries": 3}})
        own103 = owner_of(dict(row10, detail="共識 YELLOW:共識 39 / 39 代號 · gate PASS · 鉅亨這次沒給資料(抓了 3 次)暫不納入閘:2891"), cx10b)
        own_other = owner_of(row10, dict(cx10, gate_other={"2330"}))
        chk("㊻ 收尾頁 ⑥f:8358 / 2891 沒有 __NEXT_DATA__ = 一時抓不到(不是「別的不過」)· v0103 以前做的 → VRN-2(說明整批重抓的根因)· v0103 的 source_gap → 資料源 · 別的不過 → VRN-2",
            q404 == set() and qtr == {"8358", "2891"} and qot == set() and cx10["gate_transient"] == {"8358", "2891"} and not cx10["cj_v0103"]
            and own102[0] == "VRN-2" and "checkpoint" in own102[1] and own103[0] == "資料源" and "2891" in own103[1] and "抓了 3 次" in own103[1] and own_other[0] == "VRN-2" and "2330" in own_other[1])
        rcp10 = {"consensus": {"run": {"lamp": "YELLOW", "gate": "FAIL_CLOSED", "why": why102}}}
        p10 = [k for k, _ in plan_fixes(r10, rcp10, "/x/py", A(), "")]
        cj10 = json.loads((v10 / "consensus" / "VRN2_Consensus_latest.json").read_text(encoding="utf-8"))
        (v10 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps(dict(cj10, retries=[]), ensure_ascii=False), encoding="utf-8")
        p10b = [k for k, _ in plan_fixes(r10, rcp10, "/x/py", A(), "")]
        (v10 / "consensus" / "VRN2_Consensus_latest.json").write_text(json.dumps(cj10, ensure_ascii=False), encoding="utf-8")
        qm.write_text(qm.read_text(encoding="utf-8") + "1234,FETCH_PIPELINE,HTTP_GET_FAILED: HTTP Error 404: Not Found,successful fetch,FAIL,FAIL,x\n", encoding="utf-8")
        p10c = [k for k, _ in plan_fixes(r10, rcp10, "/x/py", A(), "")]
        p10d = [k for k, _ in plan_fixes(r10, rcp10, None, A(), "")]
        chk("㊼ ⑤ 自動修:共識閘只因 404 / 一時抓不到、是 v0103 以前做的 → 用 v0103 重跑 ⑥f + 重組 Combined · 已是 v0103(收據有 retries)→ 不重跑 · 有別的不過 / 沒有擷取 Python → 不重跑",
            p10[:2] == ["consensus", "combined"] and "consensus" not in p10b and "consensus" not in p10c and "consensus" not in p10d)
        rows10 = [("YELLOW", "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)", row10["detail"]), ("YELLOW", "⑥ ⑥f 共識閘 FAIL 列", "2 列 · 代號 2891,8358 · 8358 FETCH_PIPELINE 實際 ASSIGNED_JSON_NOT_FOUND"),
                  ("GREEN", "⑥ ⑥f Yahoo 代號", "對應表 40 筆"), ("YELLOW", "⑥ ⑥f Yahoo 代號", "Yahoo 404:6933.TW"), ("YELLOW", "⑥ Combined 冊", "52 列 · 欄序正確 · 空格")]
        cx10m = dict(cx10, combined_gaps=g1, combined_owner=o1)
        its10 = [dict({"lamp": l, "step": st_, "detail": d}, owner=(owner_of({"lamp": l, "step": st_, "detail": d}, cx10m) or (None, ""))[0], why=(owner_of({"lamp": l, "step": st_, "detail": d}, cx10m) or (None, ""))[1]) for l, st_, d in rows10]
        its10 = [i for i in its10 if i["owner"]]
        m10 = merge_same(its10, cx10m)
        st10, _t10, po10 = closeout_state([i for i in m10 if i["owner"] not in ("提醒", "彙總")])
        m10b = merge_same(its10, dict(cx10m, combined_gaps={"TARGET_PRICE(ADJ)": {"別的原因": 1}, "FACTSET_TARGET_PRICE_MEDIAN": g1["FACTSET_TARGET_PRICE_MEDIAN"]}))
        chk("㊽ 收尾頁同一件事只列一次:⑥f 步驟列 + 共識閘 FAIL 列 + Combined 冊(VRN-2 的空格全是「共識缺」)= 同一次共識 → 1 項(桌機算成 VRN-2 2 項)· Yahoo 代號另列 · Combined 還有別的 VRN-2 空格 → 不併 → %s %s" % (st10, po10),
            po10 == {"VRN-2": 1, "資料源": 1} and len(m10) == 2 and any(i.get("also") == ["⑥ ⑥f 共識閘 FAIL 列", "⑥ Combined 冊"] for i in m10) and len(m10b) == 3
            and combined_consensus_only(g1) and not combined_consensus_only(g2))
        pk10 = td / "pk110"
        pk10.mkdir()
        body10 = b"VERSION = 'v0103'\n"
        with zipfile.ZipFile(pk10 / RUNTIME_ZIP, "w") as z:
            z.writestr("VRN2_ConsensusJoin_v0103.py", body10)
            z.writestr("VRN2_ConsensusJoin_v0102.py", b"old\n")
            z.writestr("VRN2_Workbench_v0102.py", b"wb\n")
        (pk10 / RUNTIME_MANIFEST).write_text(json.dumps({"files": [{"path": "VRN2_ConsensusJoin_v0103.py", "sha256": hashlib.sha256(body10).hexdigest()},
                                                                   {"path": "VRN2_ConsensusJoin_v0102.py", "sha256": hashlib.sha256(b"old\n").hexdigest()}]}), encoding="utf-8")
        fm10 = r10 / "functional modules" / "VRN2"
        fm10.mkdir(parents=True)
        (fm10 / "VRN2_ConsensusJoin_v0102.py").write_bytes(b"different\n")
        put10, ref10 = place_consensus(pk10, r10)
        put10b, ref10b = place_consensus(pk10, r10)
        chk("㊾ ⑤ 重跑 ⑥f 前補放套件 runtime 的 ConsensusJoin:v0103 補放(雜湊對清單)· 已在的同名不同內容 v0102 不覆寫 · 別的模組不動 · 再跑一次 = 已在(不重放)",
            put10 == ["VRN2_ConsensusJoin_v0103.py"] and ref10 == ["VRN2_ConsensusJoin_v0102.py"] and (fm10 / "VRN2_ConsensusJoin_v0103.py").read_bytes() == body10
            and (fm10 / "VRN2_ConsensusJoin_v0102.py").read_bytes() == b"different\n" and not (fm10 / "VRN2_Workbench_v0102.py").exists() and put10b == [] and ref10b == ["VRN2_ConsensusJoin_v0102.py"])
        cx_no = dict(cx10, engine_no_output={"rc": 1, "last": "RuntimeError: NO_PAYLOAD_FETCHED: [...]"}, gate_other={"2330"})
        own_no = owner_of({"lamp": "YELLOW", "step": "⑥ 步驟 ⑥f 共識合併(FactSet / YFinance → Combined 冊)", "detail": "共識 YELLOW:共識引擎這次沒有產出(rc 1 · NO_PAYLOAD_FETCHED)· 上次的矩陣不算這次的"}, cx_no)
        g_no, o_no = combined_gaps([{"TICKER": "2330", "TARGET_PRICE": "", "FACTSET_TARGET_PRICE_MEDIAN": "", "STATUS": "CONSENSUS: 缺:共識引擎這次沒有產出(rc 1 · NO_PAYLOAD_FETCHED)"}], set(), True)
        chk("㊿ ⑥f 共識引擎這次沒有產出(ConsensusJoin v0103 不沿用上次的矩陣)→ 資料源(網路被擋則交 VCGC)· 上次的品質矩陣不看 · Combined 那幾格同樣算資料源",
            own_no[0] == "資料源" and "NO_PAYLOAD_FETCHED" in own_no[1] and o_no == "資料源" and g_no["FACTSET_TARGET_PRICE_MEDIAN"] == {"共識引擎這次沒有產出(整批沒抓到)": 1})
    for k, v in saved_env.items():''')
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0109.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0110.py"').replace('"VRN2_RoundAll_v0109.py" in html_', '"VRN2_RoundAll_v0110.py" in html_')
assert "VRN2_RoundAll_v0109.py" not in s.replace("vrn2_release_v0153/VRN2_RoundAll_v0109", ""), [m.start() for m in re.finditer("VRN2_RoundAll_v0109.py", s)]
(S / "v154/new/VRN2_RoundAll_v0110.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0110 lines", s.count("\n"))
