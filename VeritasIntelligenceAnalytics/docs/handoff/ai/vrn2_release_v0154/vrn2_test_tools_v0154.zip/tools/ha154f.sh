#!/bin/bash
# Handle-All v0102 整輪(短開機行 · VRN2_MODE=full)沙盒:$1 = 沙盒 · $2 = 回合名 · $3 = fixture(⑥f 離線 fixture)| live(⑥f 即時 · 代理指到關著的埠 · 空殼 yfinance / duckdb)
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; S2=/tmp/claude-0/-home-user-movies-dataset/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad
W=$S/v154; T=$W/$1; N="$2"; K="$3"; shift 3
OCRPY=$S/v131/ocrenv/vrn2_ocr/bin/python; P=$S2/venv_vrn2/bin/python; DEAD=http://127.0.0.1:9; STUB=$W/stub154
if [ "$K" = fixture ]; then EXTRA=(VRN2_CONSENSUS_FIXTURES="$(cat $S/v148/fx148.list)"); else EXTRA=(PYTHONPATH="$STUB" VIA_FETCH_PY="$P" HTTPS_PROXY=$DEAD https_proxy=$DEAD HTTP_PROXY=$DEAD http_proxy=$DEAD NO_PROXY= no_proxy= VIA_VRN2_CONSENSUS_RETRY_WAIT=0); fi
cd "$T/home" && env HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" TEMP="$T/tmp" VIA_ENVS_HOME="$T/envs" VIA_TOOLS_ROOT="$T/VIA" VIA_ROOT="$T/VIA" \
  VIA_VRN2_OCR_PY="$OCRPY" VIA_VRN2_OCR_BRIDGE="$T/envs/vrn2_ocr/VRN2_OCRBridge_v0100.py" PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=0 \
  VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_OUTPUT_DIR="$T/OneDrive/VRN2_out" VRN2_CONSENSUS_YEAR=2026 VRN2_INTEGRATE_TEMP="$T/tmp" "${EXTRA[@]}" \
  VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_SOURCE="$T/samples" VRN2_MODE=full VRN2_ROUNDALL_ARGS="--python $P --no-open --integrate yes --launcher-args --no-install" "$@" \
  timeout 7000 "$S2/pwsh/pwsh" -NoProfile -ExecutionPolicy Bypass -Command "$(cat $W/release154/boot_line.txt)" > $W/ha154_$N.log 2>&1
echo "$N rc $?" >> $W/ha154.rc
sed -i 's/\x1b\[[0-9;]*m//g' $W/ha154_$N.log
