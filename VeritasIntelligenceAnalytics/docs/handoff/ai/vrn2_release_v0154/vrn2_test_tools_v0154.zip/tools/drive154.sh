#!/bin/bash
# 桌機 20:09 之後的狀態(t154d_snapshot)· Handle-All v0102 短開機行:report → auto(→ repair · ⑥f 用 v0103 重跑)→ auto 再一次(→ repair · 沒有要修的)→ cmd 一行(report)→ 竄改
S=/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad; W=$S/v154; T=$W/t154e
rm -rf "${T:?}" "${T:?}.br" $W/ha154.rc; cp -a $W/t154d_snapshot $T && cp -a $S/v153/t153d/remote.git $T/remote.git && git -C $T/VIA remote set-url origin $T/remote.git && bash $W/mkbranch154.sh t154e
python3 - "$T" <<'PY'
import json, sys
from pathlib import Path
p = Path(sys.argv[1]) / "VIA" / "VIA_Reports" / "vrn2" / "VRN2_Output_Config.json"
c = json.loads(p.read_text(encoding="utf-8")); c["output_dir"] = str(Path(sys.argv[1]) / "OneDrive" / "VRN2_out"); p.write_text(json.dumps(c, ensure_ascii=False, indent=1), encoding="utf-8")
PY
bash $W/ha154.sh t154e e_report line VRN2_MODE=report
bash $W/ha154.sh t154e e_auto_repair line
bash $W/ha154.sh t154e e_auto_again line
bash $W/ha154.sh t154e e_cmd_report cmd VRN2_MODE=report
(cd $T.br && sed -i '0,/^<!-- handle-all line -->$/s//<!-- handle-all line -->/' VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0154/VRN2_HandleAll_v0102.md && python3 - VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0154/VRN2_HandleAll_v0102.md <<'PY'
import sys, re
from pathlib import Path
p = Path(sys.argv[1]); s = p.read_text(encoding="utf-8")
s = re.sub(r"(<!-- handle-all line -->\n```powershell\n& \{ )", r"\1Write-Host tampered; ", s, count=1); p.write_text(s, encoding="utf-8")
PY
git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5)
bash $W/ha154.sh t154e e_tamper line VRN2_MODE=report
bash $W/mkbranch154.sh t154e
echo done-drive >> $W/ha154.rc
