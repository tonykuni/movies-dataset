#!/bin/bash
# v0167 e2e(RoundAll v0123 · Handle-All v0115 · 套件 v0166 照釘):沙盒(桌機 v0153 狀態 + 髒增量庫)+ 操作員上傳的兩份原文(Daiwa-6278 · 欣銓 3264 · 只在沙盒)· 發行夾 v0164 / v0165 / v0166
# → auto(上一輪收據 v0153 < v0166 → 整輪 · 啟動器 v0166 · 管理器 v0258)→ --confirm list → auto 第二次(收據 v0166 → repair)→ 竄改不執行
S=<scratch0>; S2=<scratch>
W=/home/user/vrn2_work/v167; W4=/home/user/vrn2_work/v164; T=$W/t167a; P=$S2/venv_vrn2/bin/python
SUP="/home/user/movies-dataset/VeritasIntelligenceAnalytics/supportive modules"
REL=/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai
rm -rf "${T:?}" "${T:?}.br"; cp -a $S/v153/t153d $T && rm -rf "${T:?}/tmp" && mkdir -p $T/tmp $T/home/OneDrive/Documents && ln -s $T/VIA $T/home/OneDrive/Documents/movies-dataset && git -C $T/VIA remote set-url origin $T/remote.git
cp -a "$SUP/network/." "$T/VIA/supportive modules/network/"
cp "$SUP/registry/CGC_MDL224_ScrapeGate_v0100.py" "$SUP/registry/"CGC_MDL233_ToolActivate_v*.py "$SUP/registry/CGC_MDL056_InstallGate_v0104.py" "$SUP/registry/VIA_PS_Accelerators_25_Roster_v0100.ps1" "$T/VIA/supportive modules/registry/"
cp "$SUP/VIA_PS_PyProgress_Module.ps1" "$SUP/VIA_PS_Accel_Module.ps1" "$T/VIA/supportive modules/"
:
$P -I $W4/seed164.py $T $W4/rt > $W/seed167.log 2>&1; cat $W/seed167.log
B=$T.br; D6=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166; D7=$B/VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0167; mkdir -p $D6 $D7
cp $REL/vrn2_release_v0166/VRN2_Closeout_v0166.zip $REL/vrn2_release_v0166/VRN2_Release_v0166.json $D6/
cp $W/release167/VRN2_RoundAll_v0123.py $W/release167/VRN2_RoundAll_v0123.md $W/release167/VRN2_HandleAll_v0115.md $W/release167/VRN2_HandleAll_v0115_boot.txt $W/release167/VRN2_Release_v0167.json $D7/
(cd $B && git init -q -b x && git add -A && git -c user.email=t@t -c user.name=t commit -qm rel && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null); echo branch ok
LINE=$(sed 's#"$HOME\\OneDrive\\Documents\\movies-dataset"#"$HOME/OneDrive/Documents/movies-dataset"#' $W/release167/tiny_line.txt)
V2=$T/VIA/VIA_Reports/vrn2
ENVV=(env -u VIA_NET_CONSENT -u VIA_SCRAPE_CONSENT HOME="$T/home" USERPROFILE="$T/home" VRN2_DOWNLOADS="$T/home/Downloads" TMPDIR="$T/tmp" VIA_ROOT="$T/VIA" PYTHONDONTWRITEBYTECODE=1 VIA_VRN2_NO_BORROW=1 VIA_VRN2_NO_VRN1_SYNC=1 VRN2_ROOT="$T/VIA" VRN2_PY="$P" VRN2_ROUNDALL_ARGS="--python $P" VIA_ACCEL_LIGHT_SEC=2)
run() { N=$1; shift; cd "$T/home" && "${ENVV[@]}" "$@" timeout 6000 "$S2/pwsh/pwsh" -NoProfile -Command "$LINE" > $W/tiny_$N.log 2>&1; echo "$N rc $?" >> $W/tiny167.rc; sed -i 's/\x1b\[[0-9;]*m//g' $W/tiny_$N.log; cp $V2/VRN2_CloseoutUI_latest.json $W/closeout_$N.json 2>/dev/null; cp -a $V2/output $W/out_$N 2>/dev/null; }
rm -rf "${W:?}/out_auto1" "${W:?}/out_auto2" "${W:?}/out_tamper"; rm -f $W/tiny167.rc
run auto1
RA=$T/home/Downloads/VRN2_RoundAll_v0123.py
cd $T/home && "${ENVV[@]}" $P -X utf8 $RA --root "$T/VIA" --confirm list > $W/confirm_list.log 2>&1; echo "confirm list rc $?" >> $W/tiny167.rc
run auto2
(cd $B && printf 'Write-Host tampered\n' > VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0167/VRN2_HandleAll_v0115_boot.txt && git -c user.email=t@t -c user.name=t commit -qam tamper && git push -q -f $T/remote.git x:refs/heads/claude/optimistic-goodall-yhalc5 2>/dev/null)
run tamper VRN2_MODE=report; cat $W/tiny167.rc
