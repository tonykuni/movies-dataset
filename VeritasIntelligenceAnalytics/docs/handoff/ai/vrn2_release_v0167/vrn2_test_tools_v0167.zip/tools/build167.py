"""v0167(冪等):套件 v0166 不動(雜湊照釘)→ RoundAll v0123 → Handle-All v0115 → 開機行 + 開機檔 + 最短一行 + cmd 一行 → md · 發行清單(vrn2_release_v0167)。
vrn2_release_v0166 及更早不動。"""
import base64, hashlib, json, re, sys
from pathlib import Path
W = Path("/home/user/vrn2_work/v167"); rel = W / "release167"; rel.mkdir(exist_ok=True)
PREV = Path("/home/user/vrn2_work/v166/release166")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
sys.path.insert(0, "/home/user/vrn2_work/v159/ps7")
from join_ps import join  # noqa: E402
r166 = json.loads((REPO / "vrn2_release_v0166/VRN2_Release_v0166.json").read_text(encoding="utf-8"))
want = r166["package"]["sha256"]
ra = (W / "new/VRN2_RoundAll_v0123.py").read_text(encoding="utf-8")
assert ('PACKAGE_SHA256 = "%s"' % want) in ra and 'PACKAGE = "VRN2_Closeout_v0166"' in ra and 'VERSION = "v0123"' in ra
assert 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166"' in ra            # 套件 zip 照舊從 v0166 發行夾取
(rel / "VRN2_RoundAll_v0123.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()

ha = (PREV / "handleall_src.ps1").read_text(encoding="utf-8")
old_ra = re.search(r"\$H = '([0-9a-f]{64})'", ha).group(1)


def rep(a, b, n=1):
    global ha
    assert ha.count(a) == n, (ha.count(a), a[:90])
    ha = ha.replace(a, b)


rep("$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166'", "$P = 'VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0167'")
rep("$F = 'VRN2_RoundAll_v0122.py'", "$F = 'VRN2_RoundAll_v0123.py'")
rep("$H = '%s'" % old_ra, "$H = '%s'" % ra_sha)
rep("Handle-All v0114", "Handle-All v0115", ha.count("Handle-All v0114"))
assert "exit" not in ha.replace("Exception", "") and not [l for l in ha.split("\n") if re.search(r"Handle-All v0114|v0122\.py", l) and not l.lstrip().startswith("#")]
ha_line = join(ha); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt = (PREV / "boot_src.ps1").read_text(encoding="utf-8")
old_ha = re.search(r"\$H = '([0-9a-f]{64})'", bt).group(1)
for a, b in (("vrn2_release_v0166", "vrn2_release_v0167"), ("VRN2_HandleAll_v0114.md", "VRN2_HandleAll_v0115.md"), ("Handle-All v0114 SHA-256 OK", "Handle-All v0115 SHA-256 OK"),
             ("$H = '%s'" % old_ha, "$H = '%s'" % ha_sha)):
    assert bt.count(a) == 1, a
    bt = bt.replace(a, b)
bt_line = join(bt); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800
(rel / "boot_src.ps1").write_text(bt, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0115_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0167/VRN2_HandleAll_v0115_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(tiny.encode("utf-16-le")).decode("ascii")
assert len(cmd_line) < 8191 and not re.search(r"[%^&|<>]", cmd_line)
(rel / "cmd_line.txt").write_text(cmd_line + "\n", encoding="ascii", newline="\n")

md = """# VRN-2 · 一行處理全部 · VRN2_HandleAll_v0115(2026-11-01 · 收尾頁步驟列保留判斷要點 · 套件 v0166 不動 · RoundAll v0123)

桌機 2026-11-01 09:19(v0166 整輪 · 5434 秒):管理器 v0258 補回欣銓 3264 / Daiwa-6278 等年度表(年度數據 11505 → 11865 · ⑪ 錯值 0)· 缺項只剩華南 6143。
收尾 **OPEN**「VRN-2 1 項」= ⑥e 市場擷取「擷取 YELLOW · 失敗 0」:收據那一列 300 字內有「失敗 0」,RoundAll 再截到 220 字 → 只剩「· 失」→ 負責方規則對不到 → 落到 VRN-2。

| 項目 | 現在 |
|---|---|
| keep_facts | 步驟列超過 220 字時,被截掉的判斷要點(失敗 N · 擷取 / 填值燈 · 逾時 · Traceback · 致命錯)移到最前面「要點 … \\|」→ 負責方照整段判斷 |
| 桌機狀態重跑收尾頁(沙盒 dry run)| OPEN(VRN-2 1)→ **REVIEW**(VRN-2 0 · 人工 2 · 資料源 3)|
| 套件 | 照舊 `vrn2_release_v0166/VRN2_Closeout_v0166.zip`(SHA-256 `%s`)|
| 一支 Python | `VRN2_RoundAll_v0123.py`(SHA-256 `%s` · 自測 89 項)|
| 自動選模式 | 收據已是 v0166 → **repair**(幾分鐘 · 不整輪)|

## cmd 視窗(%d 字元)

```bat
set "VIA_SCRAPE_CONSENT=YES"
%s
```

第 1 行 = 同意閘(操作員決定)· 第 2 行 = 下面 PowerShell 那一行的編碼版(一樣核對 SHA-256 才執行)。

## 人工核對(看過原文之後)

```bat
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0123.py" --confirm list
python "%%USERPROFILE%%\\\\Downloads\\\\VRN2_RoundAll_v0123.py" --confirm H-xxxxxxxx --note "原圖四點與摘錄一致"
```

第 1 行列出待核項與代碼 · 第 2 行記一筆確認(代碼照收尾頁那一項)· 撤銷:`--confirm revoke H-xxxxxxxx`。

## PowerShell 7 視窗(%d 字元)

新視窗先貼 `$env:VIA_SCRAPE_CONSENT = 'YES'`(操作員決定)。然後貼:

```powershell
%s
```

第一行應是 `[GREEN] boot: Handle-All v0115 SHA-256 OK`(開機檔 SHA-256 `%s` · Handle-All 那一行 `%s` · RoundAll v0123 `%s`)。

## 開機行(%s 字元)

```powershell
%s
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
%s
```

## 可讀版 · Handle-All

```powershell
%s
```

## 可讀版 · 開機行

```powershell
%s
```
""" % (want[:12], ra_sha[:12], len(cmd_line), cmd_line, len(tiny), tiny, bt_sha[:12], ha_sha[:12], ra_sha[:12], "{:,}".format(len(bt_line)), bt_line, ha_line, ha.rstrip("\n"), bt.rstrip("\n"))
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == tiny
(rel / "VRN2_HandleAll_v0115.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = """# VRN-2 一支 Python · VRN2_RoundAll_v0123.py(套件 v0166 不動 · 收尾頁步驟列保留判斷要點)

`VRN2_RoundAll_v0123.py`(只用 Python 標準庫 · SHA-256 `%s`)= v0122 +:

| 改了什麼 | 說明 |
|---|---|
| keep_facts | 收尾收據的步驟列超過 220 字 → 被截掉的判斷要點(失敗 N · 擷取 / 填值 RED / YELLOW / GREEN · 逾時 N 秒 · Traceback · 致命錯)移到最前面「要點 … \\|」|
| 負責方 | ⑥e「擷取 YELLOW · 失敗 0」(VDF rc 2 PARTIAL)照 v0120 規則 = 資料源 · 截掉的地方有 Traceback / 擷取 RED → 還是 VRN-2 |

桌機 09:19 狀態 dry run:OPEN(VRN-2 1)→ REVIEW(VRN-2 0 · 人工 2 · 資料源 3)。自測 89 項(v0122 的 88 項 + 87)。套件 `vrn2_release_v0166/VRN2_Closeout_v0166.zip`(SHA-256 `%s` · 本檔內已釘 · 不動)。
""" % (ra_sha[:12], want[:12])
(rel / "VRN2_RoundAll_v0123.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "VRN2_RoundAll_v0123 + VRN2_HandleAll_v0115 (package v0166 unchanged)", "date": "2026-11-01",
        "trigger": "桌機 2026-11-01 09:19(Handle-All v0114 整輪 · 套件 v0166 · 管理器 v0258)收尾 OPEN「VRN-2 1 項」= ⑥e 市場擷取列 · 操作員「繼續下一步,依照你的建議進行」",
        "desktop_0919": {"annual_rows": "11505 → 11865 (+363 incl. 欣銓 225 · Daiwa 30 · 南亞 32 · 啟碁 32 · 晶心科 32 · 6933 AMAX +9 values and 3 EPS rows with the corrected SECTION) · Rejected 2609 → 2548 (Daiwa 63 out · 欣銓 '- -' 2 in)",
                         "independent_verifier": "錯值 0 · 11865 = ALIGNED 10821 · SUBALIGNED 752 · TRANSALIGNED 190 · PRESENT 101 (unchanged from 06:32) · NILVAL 1",
                         "books_phase_s": "1279 (v0257 full run 1429)", "gaps": "華南投顧-6143 only (original not uploaded)"},
        "root_cause": "launcher receipt keeps 300 chars of the 6e detail ('… · 失敗 0 · …'); RoundAll v0122 built the closeout row with detail[:220] → '… · 失' → the v0120 rule '失敗 0 = VDF rc 2 PARTIAL → 資料源' did not match → fallback owner VRN-2",
        "fixes": {"RoundAll_v0123": "keep_facts(detail, 220): key facts cut by the truncation (失敗 N · 擷取 / 填值 lamp · 逾時 N 秒 · Traceback · 致命錯) are moved in front ('要點 … |'); owner rules unchanged",
                  "HandleAll_v0115": "v0114 pointed at RoundAll v0123 (vrn2_release_v0167) · auto: receipt v0166 → repair"},
        "package": {"name": r166["package"]["name"], "sha256": want, "release_folder": "vrn2_release_v0166", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0122.py", "sha256": r166["roundall"]["sha256"], "status": "superseded 2026-11-01; file kept in vrn2_release_v0166"}],
        "roundall": {"name": "VRN2_RoundAll_v0123.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0123.md"},
        "handleall": {"name": "VRN2_HandleAll_v0115.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0115_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "results": {"status": "see VRN2_Verification_v0167.md"}}
(rel / "VRN2_Release_v0167.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
print("roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
