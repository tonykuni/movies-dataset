"""v0167 收尾:驗證紀錄 · 交接 v0168(從 v0167 抄 · 只增)· 放進倉 vrn2_release_v0167 · logs / 工具 zip。桌機貼回包的內容不進倉(只寫結論與筆數)。"""
import json, re, shutil, zipfile
from pathlib import Path
W = Path("/home/user/vrn2_work/v167"); rel = W / "release167"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
SCR = "<scratch>"
SCR0 = "<scratch0>"


def lines(p):
    return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()


def short(x):
    for a, b in ((str(W / "t167a"), "<sbx>"), (str(W), "<w>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        x = x.replace(a, b)
    return x


R = json.loads((rel / "VRN2_Release_v0167.json").read_text(encoding="utf-8"))
ra = [l for l in lines(W / "rall123_selftest_venv.log") if re.search(r"^\[PASS\] 87 |^\[FAIL\]|--selftest · ", l)]
ps = json.loads((W / "pscheck167.log").read_text())
pparse = "pwsh 7.4.6 剖析錯 %s · Handle-All 一行 = 可讀版 %s · 開機行 = 可讀版 %s" % ([x["e"] for x in ps], ps[0]["h"] == ps[1]["h"], ps[2]["h"] == ps[3]["h"])
rc = [l for l in lines(W / "tiny167.rc") if l.strip()]
pat = r"boot:|boot SHA|④ 自動選模式|① 套件 ·|===== 收尾|\[(VRN-2|人工|VCGC|資料源)\] \d"
e2e = {n: [short(l)[:220] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)][:12] for n in ("auto1", "auto2", "tamper")}
states = {}
for n in ("auto1", "auto2"):
    d = json.loads((W / ("closeout_%s.json" % n)).read_text(encoding="utf-8"))
    states[n] = {"state": d["state"], "per_owner": d["per_owner"]}
R["results"] = {"selftest": ra, "pwsh_parse": pparse, "e2e_rc": rc, "e2e": e2e, "closeout_states": states,
                "dry_run_desktop_0919": "RoundAll v0122 vs v0123, --only report,closeout on the 09:19 paste-back state (Combined json rebuilt from its csv): v0122 OPEN (VRN-2 1 = 6e row cut at '· 失') → v0123 REVIEW (VRN-2 0 · 人工 2 · 資料源 3 · 6e row '要點 失敗 0 | …' = 資料源 · VDF rc 2 PARTIAL)",
                "not_run": "the desktop itself (next: auto → repair, a few minutes) · the operator's own --confirm · 華南-6143 original"}
(rel / "VRN2_Release_v0167.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
H = R["handleall"]
md = """# VRN-2 v0167 驗證紀錄(2026-11-01 · RoundAll v0123 · Handle-All v0115 · 套件 v0166 不動)

## 1. 起因

桌機 2026-11-01 09:19(Handle-All v0114 整輪 · 5434 秒 · 套件 v0166 · 管理器 v0258)收尾 **OPEN**「VRN-2 還有 1 項要修」。

## 2. 桌機這一輪的數據(結論 · 貼回包不進倉)

| 項目 | 結果 |
|---|---|
| 年度數據 | 11505 → 11865 筆(+363:欣銓 3264 225 · Daiwa-6278 30 · 南亞 32 · 啟碁 32 · 晶心科 32 · 6933 AMAX 補 9 值 + 3 筆 EPS 段落名更正)· 原有的值一筆不少 |
| 剔除冊 | 2609 → 2548(Daiwa 63 筆一格多值改成輸出 · 欣銓「- -」2 筆進剔除冊)|
| ⑪ 獨立驗證 | 錯值 0 · 11865 = 對欄 10821 · 子欄 752 · 轉置 190 · PRESENT 101(跟 06:32 一樣 · 舊的)· 空值 1 · 新增 360 筆全部對欄 |
| 輸出冊階段 | 1279 秒(v0257 整輪 1429 秒 · v0258 沒有變慢)|
| 缺項 | 只剩華南投顧-6143(原文沒上傳)|
| 人工 | MQ-1560 四點 H-fd2ea35f(代碼跟上一輪一樣)· 缺項 6143 |

## 3. 那 1 項 VRN-2 是誤判

⑥e 市場擷取「擷取 YELLOW · 跑 10 次 · 失敗 0」= VDF 引擎 rc 2 PARTIAL(v0120 起算資料源)。啟動器收據那一列保留 300 字,有「失敗 0」;
RoundAll v0122 做收尾頁步驟列時再截到 220 字 → 只剩「…· 失」→ 負責方規則對不到「失敗 0」→ 落到 VRN-2。以前 repair 的收據那一列字比較短,沒踩到。

## 4. 修正:RoundAll v0123

keep_facts:步驟列超過 220 字時,被截掉的判斷要點(失敗 N · 擷取 / 填值 RED / YELLOW / GREEN · 逾時 N 秒 · Traceback · 致命錯)移到最前面「要點 … |」再接前 220 字;
負責方規則不變(擷取 RED / Traceback 還是 VRN-2 · 只有「失敗 0」是資料源)。套件 v0166 不動(雜湊照釘)。

## 5. 測試

| 項目 | 結果 |
|---|---|
| RoundAll v0123 自測 | %s |
| PowerShell 剖析 | %s |
| 桌機 09:19 狀態重做收尾頁(沙盒 · 只讀貼回包) | v0122 OPEN(VRN-2 1)→ v0123 **REVIEW**(VRN-2 0 · 人工 2 · 資料源 3)|
| e2e(最短一行 · 沙盒) | %s · auto 第一次 → 整輪(收據 v0153)· 第二次 → repair(收據 v0166)· 竄改開機檔 → 不執行 · 收尾 %s |

## 6. 一行指令

cmd 一行 %d 字元 · PowerShell 最短一行 %d 字元 · 開機檔 `vrn2_release_v0167/VRN2_HandleAll_v0115_boot.txt`(SHA-256 `%s`)· Handle-All 一行 `%s` · RoundAll v0123 `%s` · 套件 `%s`(不動)。
auto:收據已是 v0166 → repair(幾分鐘)。

## 7. 沒做 / 待辦

- 人工確認只有操作員親手打 `--confirm`(AI 不代打)。
- 華南投顧-6143 原文還沒上傳(剔除冊 40 值 · 轉置表第三讀法對不上)。
- 3014TT 四點(第 2 點從句中開始 · 第 1 / 3 點重複)· MQ-1560 OCR 字詞錯(chi players)→ 摘要器 / OCR 要另一輪(要整輪)。
""" % (" · ".join(x[:90] for x in ra[-1:]), pparse, " · ".join(rc), json.dumps(states, ensure_ascii=False),
       H["cmd_line_chars"], H["tiny_line_chars"], H["boot_line_sha256"][:12], H["line_sha256"][:12], R["roundall"]["sha256"][:12], R["package"]["sha256"][:12])
(rel / "VRN2_Verification_v0167.md").write_text(md, encoding="utf-8", newline="\n")

src = (REPO / "VRN2_Handover_v0167.md").read_text(encoding="utf-8")


def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80])
    src = src.replace(a, b)


L = src.split("\n")
assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0166 + VRN2_RoundAll_v0122 + VRN2_HandleAll_v0114 · 2026-11-01(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0166 + VRN2_RoundAll_v0123 + VRN2_HandleAll_v0115 · 2026-11-01(桌機 v0166 整輪:年度表補回 · ⑪ 錯值 0 · "
        "收尾 OPEN 的 1 項是步驟列截字誤判 → RoundAll v0123 keep_facts · 套件 v0166 不動)")
src = "\n".join(L)
once("> **本輪(v0166)**",
     "> **本輪(v0167)**:桌機 09:19 跑 v0166 整輪(5434 秒)→ 管理器 v0258 補回年度表(11505 → 11865 · 欣銓 225 · Daiwa 30 · 南亞 / 啟碁 / 晶心科各 32 · 6933 +9)· "
     "⑪ 錯值 0(新增 360 筆全對欄)· 輸出冊 1279 秒(沒變慢)· 缺項只剩華南 6143。收尾 OPEN 的「VRN-2 1 項」是 ⑥e「擷取 YELLOW · 失敗 0」那一列被 RoundAll 截到 220 字、"
     "「失敗 0」被截掉 → 負責方規則對不到。**RoundAll v0123**(keep_facts:截掉的判斷要點移到前面)· **Handle-All v0115**(最短一行 %d 字元 · cmd 一行 %d 字元)· 套件 v0166 不動 · "
     "桌機狀態 dry run:OPEN → REVIEW(VRN-2 0 · 人工 2 · 資料源 3)。\n"
     "> **本輪(v0166)**" % (H["tiny_line_chars"], H["cmd_line_chars"]))
r166 = json.loads((REPO / "vrn2_release_v0166/VRN2_Release_v0166.json").read_text(encoding="utf-8"))
once("| **VRN2_HandleAll_v0114.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0114** | `vrn2_release_v0166` |",
     "| **VRN2_HandleAll_v0115.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0115** | `vrn2_release_v0167` | 一行版 `%s` · 開機檔 `%s` | **新**(指向 RoundAll v0123)|\n"
     "| **VRN2_RoundAll_v0123.py**(發行夾 · 一支入口 · 不在套件內)| **v0123** | `vrn2_release_v0167` | `%s` | **新**(keep_facts · 自測 89 項 · 套件 v0166 照釘)|\n"
     "| **VRN2_HandleAll_v0114.md**(發行夾 · 最短一行 + cmd 一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0114** | `vrn2_release_v0166` |" % (H["line_sha256"][:12], H["boot_line_sha256"][:12], R["roundall"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0122.py**(發行夾 · 一支入口 · 不在套件內)| **v0122** | `vrn2_release_v0166` | `%s` | **新**(" % r166["roundall"]["sha256"][:12],
     "| **VRN2_RoundAll_v0122.py**(發行夾 · 一支入口 · 不在套件內)| **v0122** | `vrn2_release_v0166` | `%s` | 被 v0123 取代(套件同為 v0166)· (" % r166["roundall"]["sha256"][:12])
once("| 0 | **(v0166)**",
     "| 0 | **(v0167)** cmd 視窗:`set \"VIA_SCRAPE_CONSENT=YES\"` 再貼 `vrn2_release_v0167/VRN2_HandleAll_v0115.md` 的 cmd 一行 → auto 選 repair(幾分鐘)→ 收尾應是 REVIEW(VRN-2 0)· "
     "MQ-1560 四點看過原圖後操作員自己打 `--confirm H-fd2ea35f`(AI 不代打)· 華南 6143 原文上傳給 AI | 貼回 / 人工 |\n"
     "| 0 | **(v0166)**")
once("**v0166(2026-11-01)**:", "**v0167(2026-11-01)**:桌機 v0166 整輪(年度表補回 · ⑪ 錯值 0)→ 收尾 OPEN 的 1 項 = ⑥e 步驟列截字誤判 → RoundAll v0123(keep_facts)· Handle-All v0115 · 套件 v0166 不動。\n\n**v0166(2026-11-01)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0167)** **截字不能改判斷**:收尾頁 / 負責方規則看的是步驟列文字;任何截短(收據 300 字 · 步驟列 220 字)都要先把判斷要點(失敗 N · 燈 · 逾時 · Traceback · 致命錯)"
     "留在前面(keep_facts),不然規則會落到預設負責方。改截字長度或加新規則時,用最長的真實收據列測一次。\n\n")
(REPO / "VRN2_Handover_v0168.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0167"
D.mkdir(exist_ok=True)
for n in ("VRN2_RoundAll_v0123.py", "VRN2_RoundAll_v0123.md", "VRN2_HandleAll_v0115.md", "VRN2_HandleAll_v0115_boot.txt", "VRN2_Release_v0167.json", "VRN2_Verification_v0167.md"):
    shutil.copy(rel / n, D / n)


def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 11, 1, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    for a, b in ((str(W / "t167a"), "<sbx>"), (SCR, "<scratch>"), (SCR0, "<scratch0>")):
        data = data.replace(a.encode(), b.encode())
    data = re.sub(rb"<tmp>'\"]*", b"<tmp>", data)
    z.writestr(zi, data)


with zipfile.ZipFile(D / "logs_v0167.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall123_selftest_venv.log", "pscheck167.log", "tiny167.rc", "seed167.log", "confirm_list.log")] + sorted(W.glob("tiny_*.log")) + sorted(W.glob("closeout_*.json")):
        if p.is_file():
            put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0167.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_roundall123.py", "build167.py", "finalize167.py", "e2e167.sh")] + \
             [Path("/home/user/vrn2_work/v159/ps7/join_ps.py"), Path("/home/user/vrn2_work/v159/ps7/parse.ps1")] + \
             [rel / n for n in ("tiny_line.txt", "cmd_line.txt", "boot_line.txt", "handleall_src.ps1", "boot_src.ps1")]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0168", src.count("\n"))
