"""VRN2_RoundAll_v0123.py = v0122(倉裡 vrn2_release_v0166)+ 收尾頁步驟列保留判斷要點(keep_facts)。套件仍是 v0166(雜湊照釘)。
桌機 2026-11-01 09:19(v0166 整輪)收尾 OPEN「VRN-2 1 項」= ⑥e 市場擷取:收據那一列 300 字內有「失敗 0」,RoundAll 再截到 220 字 → 只剩「· 失」
→ 「失敗 0 = VDF rc 2 PARTIAL → 資料源」(v0120)對不到 → 落到 VRN-2。"""
import re
from pathlib import Path

W = Path("/home/user/vrn2_work/v167")
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
src = (REPO / "vrn2_release_v0166/VRN2_RoundAll_v0122.py").read_text(encoding="utf-8")
d0 = src.index('"""VRN2_RoundAll v0122')
d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0122 — ', '"""VRN2_RoundAll v0123 — ', 1)
at = doc.index("v0122(")
doc = doc[:at] + '''v0123(桌機 2026-11-01 09:19 · Handle-All v0114 整輪 5434 秒 · 管理器 v0258 · 收尾 OPEN「VRN-2 1 項」· 操作員「繼續下一步,依照你的建議進行」):
  · 那一項是 ⑥e 市場擷取「擷取 YELLOW · 跑 10 次 · 失敗 0」(VDF rc 2 PARTIAL · v0120 起算資料源)。啟動器收據那一列 300 字內有「失敗 0」,
    RoundAll 做步驟列時再截到 220 字 → 只剩「…· 失」→ 負責方規則對不到「失敗 0」→ 落到 VRN-2(以前的 repair 收據字比較短 · 沒踩到)。
  · keep_facts:步驟列內容超過 220 字時,被截掉的判斷要點(失敗 N · 擷取 / 填值 RED / YELLOW / GREEN · 逾時 N 秒 · Traceback · 致命錯)
    移到最前面「要點 … |」再接前 220 字 → 負責方照整段判斷(擷取 RED / Traceback 還是 VRN-2 · 只有「失敗 0」才是資料源)。
  · 套件照舊 v0166(雜湊照釘)· 不用整輪:auto 看收據 v0166 → repair(幾分鐘)。自測 89 項(v0122 的 88 項 + 87)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0122.py", "用法:python VRN2_RoundAll_v0123.py")
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:100])
    s = s.replace(a, b)


rep('VERSION = "v0122"', 'VERSION = "v0123"')
n_dl = s.count('"C:/Users/x/Downloads/VRN2_RoundAll_v0122.py"')
rep('"C:/Users/x/Downloads/VRN2_RoundAll_v0122.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0123.py"', n_dl)
rep('"VRN2_RoundAll_v0122.py" in html_', '"VRN2_RoundAll_v0123.py" in html_')
rep("· v0122 起 88 項。", "· v0122 起 88 項 · v0123 起 89 項。")
rep('''and ("VRN_SystemManager_v0257.py", 1800) not in SELFTESTS and VERSION == "v0122")''', '''and ("VRN_SystemManager_v0257.py", 1800) not in SELFTESTS and VERSION >= "v0122")''')
assert 'PACKAGE = "VRN2_Closeout_v0166"' in s and re.search(r'PACKAGE_SHA256 = "[0-9a-f]{64}"', s) and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0166"' in s
rep('''def market_fetch_sec() -> int:''', '''_KEY_FACT = re.compile(r"失敗 \\d+|(?:擷取|填值) (?:RED|YELLOW|GREEN)|逾時 \\d+ 秒|Traceback|致命錯")


def keep_facts(detail, n: int = 220) -> str:
    """v0123 步驟列內容截到 n 字 · 截掉的部分若有判斷要點(失敗 N · 擷取 / 填值 燈 · 逾時 · Traceback · 致命錯)→ 移到最前面「要點 … |」(負責方照整段判斷)。"""
    text = str(detail or "")
    if len(text) <= n:
        return text
    cut, lost = text[:n], []
    for m in _KEY_FACT.finditer(text):
        fact = m.group(0)
        if m.start() + len(fact) > n and fact not in cut and fact not in lost:
            lost.append(fact)
    return ("要點 %s | %s" % (" · ".join(lost[:6]), cut)) if lost else cut


def market_fetch_sec() -> int:''')
rep('''            f(s.get("lamp", "GRAY"), "步驟 " + str(s.get("step", ""))[:40], str(s.get("detail", ""))[:220], advice_for(s.get("step", "")))''',
    '''            f(s.get("lamp", "GRAY"), "步驟 " + str(s.get("step", ""))[:40], keep_facts(s.get("detail", "")), advice_for(s.get("step", "")))   # v0123 截掉的判斷要點移到前面''')
rep('''        chk("86 v0122:''', '''        d87 = ("VRN2_MarketFetch_v0112.py · Python C:/py(合 VDF 界線 · VDF_TW_AllInOne_v039.py) · 不用 MOPS(--no-financial) · 擷取 YELLOW:VDF AllInOne_v039 增量:"
               + "價格每輪重抓 · 財報只補缺 · " * 8 + "失敗 0 · 09-18~10-04(2檔) rc0 / 08-12~08-21(2檔) rc2")
        st87 = "⑥ 步驟 ⑥e 市場擷取(TWSE / TPEX / Yahoo · 借共用 Market"
        k87 = keep_facts(d87)
        o87 = owner_of({"lamp": "YELLOW", "step": st87, "detail": k87}, {})
        o87old = owner_of({"lamp": "YELLOW", "step": st87, "detail": d87[:220]}, {})
        o87tb = owner_of({"lamp": "YELLOW", "step": st87, "detail": keep_facts(d87 + " · Traceback (most recent call last)")}, {})
        chk("87 v0123:收據步驟列超過 220 字 → 截掉的「失敗 0」移到最前面 → ⑥e「擷取 YELLOW · 失敗 0」= 資料源(桌機 09:19 被算成 VRN-2 1 項)· 後面有 Traceback → 還是 VRN-2 · 短的不動",
            "失敗 0" not in d87[:220] and k87.startswith("要點 失敗 0 | ") and k87.endswith(d87[:220]) and o87[0] == "資料源" and o87old[0] == "VRN-2" and o87tb[0] == "VRN-2"
            and keep_facts("短的 · 失敗 0") == "短的 · 失敗 0" and keep_facts("x" * 300) == "x" * 220)
        chk("86 v0122:''')
out = W / "new/VRN2_RoundAll_v0123.py"
out.write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0123 lines", s.count("\n"))
