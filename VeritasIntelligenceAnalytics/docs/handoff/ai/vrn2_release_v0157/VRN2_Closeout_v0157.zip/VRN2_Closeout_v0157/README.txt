VRN2_Closeout_v0157 — VRN-2 closeout package (2026-10-31 · step 3 installs through VCGC)

Entry: python ActivateVRN-2_v0157.py [--source <folder>] [--no-install] [--no-open] [--pip-install]
One-file runner (outside the package): VRN2_RoundAll_v0113.py · PowerShell 7 'handle all': VRN2_HandleAll_v0105.md (same release folder; tiny paste line inside).
Runtime: VRN2_Runtime_v0156.zip unchanged (190 members of v0154 + Fusion engine v0122 + ConsensusJoin v0104).

New in v0157 (operator 2026-10-31: '預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝'):
 - step 3 runs the manager's envcheck check-only: no pip into this Python (the manager's old --install used numpy>=1.24,<2.0 as a constraint).
 - each missing package goes through VCGC's install gate supportive modules/registry/CGC_MDL056_InstallGate (highest version): pip check
   before / after, VIA_Lib_Registry entry, import smoke, SuperAccel install lane (needs VIA_NET_CONSENT=YES); then envcheck runs again.
 - a package the gate could not install is not retried for 24 h (VIA_Reports/vrn2/VRN2_VCGCInstall_latest.json; VIA_VRN2_INSTALL_RETRY=1 retries).
 - --no-install / --plan: check only. --pip-install or VIA_VRN2_PIP_INSTALL=1: the old in-place pip (operator's explicit choice only).
Verification: see VRN2_Verification_v0157.md. Hashes: PACKAGE_SHA256.json.
