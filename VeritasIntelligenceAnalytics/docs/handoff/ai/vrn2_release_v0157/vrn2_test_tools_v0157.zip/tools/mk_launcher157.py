"""ActivateVRN-2_v0157.py = v0156 + ③ 預設只檢查(不用本環境 pip 補裝)· 缺的經 VCGC 安裝閘 CGC_MDL056_InstallGate(最高版號)· 操作員 2026-10-31。runtime 沿用 v0156。"""
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
s = (S / "v156/new/ActivateVRN-2_v0156.py").read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('"""VRN-2 v0156: v0154 entry + the operator request of 2026-10-31',
    '"""VRN-2 v0157: v0156 entry + the operator decision of 2026-10-31 ("預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝").\n\n'
    ' - step 3 (environment check): the manager\'s envcheck runs check-only (the base still asks for --install; this entry drops it, so the\n'
    '   manager no longer pip-installs into this Python with its numpy>=1.24,<2.0 constraint). Each missing package goes through VCGC\'s\n'
    '   install gate supportive modules/registry/CGC_MDL056_InstallGate (highest version, the one VCGC EnvGovernance picks): pip check before /\n'
    '   after, VIA_Lib_Registry entry, import smoke, SuperAccel install lane behind VIA_NET_CONSENT. One package per call; a package the gate\n'
    '   could not install is not retried for 24 h (VIA_Reports/vrn2/VRN2_VCGCInstall_latest.json · VIA_VRN2_INSTALL_RETRY=1 retries); then\n'
    '   envcheck runs again (check-only) and its result decides the lamp as before. --no-install / --plan: check only, no gate call.\n'
    '   --pip-install or VIA_VRN2_PIP_INSTALL=1 restores the old in-place pip (operator\'s explicit choice).\n'
    ' Runtime v0156 is used unchanged (manager / engines / ConsensusJoin not touched).\n\n'
    'v0156: v0154 entry + the operator request of 2026-10-31')
for a, b in (('VERSION = "ActivateVRN-2 v0156"', 'VERSION = "ActivateVRN-2 v0157"'), ('RECEIPT_NAME = "VRN2_Closeout_v0156.json"', 'RECEIPT_NAME = "VRN2_Closeout_v0157.json"'),
             ('launcher = root / "package" / "ActivateVRN-2_v0156.py"', 'launcher = root / "package" / "ActivateVRN-2_v0157.py"'),
             ('return lamp, detail + " · launcher v0156"', 'return lamp, detail + " · launcher v0157"'), ('print("NEXT: [%s] VRN-2 v0156 · rc %s', 'print("NEXT: [%s] VRN-2 v0157 · rc %s'),
             ('note="VRN-2 private runtime; exact ship v0156; manager v0257 (over v0255); consensus join v0104 + engine v0122 via VIA network tool; shared VRN retained"',
              'note="VRN-2 private runtime; exact ship v0156 (launcher v0157); manager v0257 (over v0255); consensus join v0104 + engine v0122 via VIA network tool; step 3 installs via VCGC; shared VRN retained"')):
    rep(a, b)
rep('LOCK_NAME = "VRN2_Launcher.lock"\n', 'LOCK_NAME = "VRN2_Launcher.lock"\n'
    'INSTALL_GATE_GLOB = "CGC_MDL056_InstallGate_v[0-9][0-9][0-9][0-9].py"   # v0157: VCGC 的安裝閘(supportive modules/registry · 最高版號 · 只呼叫 · 不改)\n'
    'INSTALL_LEDGER = "VRN2_VCGCInstall_latest.json"   # v0157: VCGC 安裝閘裝不起來的套件(24 小時內不重試)\n')
rep('''def main(argv: list | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments == ["--selftest"]:
        return selftest()
''', r'''# ===== v0157 ③ 環境:只檢查 · 缺的經 VCGC 安裝閘(不再用本環境 pip 補裝)=====
_MISS = re.compile(r"\[計\] 缺 (必裝|選裝) (\S+?)\(pip (\S+?) · 用於")


def vcgc_install_gate(root) -> Path | None:
    """VCGC 的安裝閘 CGC_MDL056_InstallGate 最高版號(同 VCGC EnvGovernance 的取法 · 只找檔 · 不改 VCGC 的檔)。"""
    folder = Path(root) / "supportive modules" / "registry"
    hits = list(folder.glob(INSTALL_GATE_GLOB)) if folder.is_dir() else []
    return max(hits, key=lambda p: int(p.stem.rsplit("_v", 1)[1])) if hits else None


def is_envcheck(arguments) -> bool:
    tokens = [str(a) for a in arguments or []]
    return "envcheck" in tokens and any(Path(t).name.startswith("VRN_SystemManager_v") for t in tokens)


def missing_packages(lines) -> list:
    out = []
    for line in lines or []:
        m = _MISS.search(str(line))
        if m and m.group(3) not in [x["pip"] for x in out]:
            out.append({"kind": m.group(1), "module": m.group(2), "pip": m.group(3)})
    return out


def env_step(run, arguments, args, kwargs, root, legacy=False) -> tuple:
    """③:envcheck 只檢查 → 缺的一個一個交 VCGC 安裝閘(24 小時內裝不起來的不重試)→ 再只檢查一次。回 (rc, lines),底座照舊判燈。"""
    tokens = [str(a) for a in arguments]
    allowed = "--install" in tokens                                         # 底座在 --no-install / --plan 時不帶 --install
    if legacy and allowed:
        rc, lines = run(tokens, *args, **kwargs)
        return rc, ["[計] ③ 環境檢查 · 操作員指定舊行為(--pip-install / VIA_VRN2_PIP_INSTALL=1):本環境 pip 補裝 · 不經 VCGC"] + list(lines)
    check = [t for t in tokens if t != "--install"]
    rc, lines = run(check, *args, **kwargs)
    miss = missing_packages(lines)
    if not miss or not allowed:
        why = "沒有缺的" if not miss else "--no-install / --plan:不裝"
        head = "[計] 環境檢查(只檢查 · 不 pip · 缺的經 VCGC 安裝閘)· %s · 缺:必裝 %d · 選裝 %d" % (why, sum(1 for x in miss if x["kind"] == "必裝"), sum(1 for x in miss if x["kind"] == "選裝"))
        print(head, flush=True)
        return rc, [head] + list(lines)
    gate = vcgc_install_gate(root)
    ledger_path = Path(root) / "VIA_Reports" / "vrn2" / INSTALL_LEDGER
    try:
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        ledger = {}
    retry = os.environ.get("VIA_VRN2_INSTALL_RETRY") == "1"
    notes, done, failed, skipped = [], [], [], []
    for x in miss:
        old = ledger.get(x["pip"]) or {}
        if not retry and old and time.time() - float(old.get("ts", 0)) < 86400:
            skipped.append(x["pip"])
            notes.append("[計] 略過 %s(%s)· 24 小時內 VCGC 安裝閘裝不起來(%s)· 交 VCGC:via-install %s" % (x["pip"], x["kind"], str(old.get("why", ""))[:80], x["pip"]))
            continue
        if gate is None:
            failed.append(x["pip"])
            notes.append("[計] 補裝失敗 %s %s · 找不到 VCGC 安裝閘(supportive modules\\registry\\CGC_MDL056_InstallGate_v####.py)→ 交 VCGC · VRN-2 不 pip" % (x["kind"], x["pip"]))
            continue
        grc, glines = run([tokens[0], "-X", "utf8", str(gate), x["pip"]], 1800, {"VIA_NO_OPEN": "1"}, cwd=str(gate.parent))
        tail = next((l.strip() for l in reversed(glines) if re.search(r"\[FAIL\]|\[裝後\]|exit \d|同意閘", str(l))), (glines or [""])[-1:][0] if glines else "")
        if grc == 0:
            done.append(x["pip"])
            ledger.pop(x["pip"], None)
            notes.append("[計] VCGC 安裝閘 %s · 裝好 %s(%s)· %s" % (gate.stem, x["pip"], x["kind"], str(tail)[:100]))
        else:
            failed.append(x["pip"])
            ledger[x["pip"]] = {"ts": time.time(), "day": time.strftime("%Y-%m-%d"), "rc": grc, "gate": gate.name, "kind": x["kind"], "module": x["module"], "why": str(tail)[:160]}
            notes.append("[計] 補裝失敗 %s %s · VCGC 安裝閘 %s rc %s · %s → 交 VCGC:via-install %s" % (x["kind"], x["pip"], gate.stem, grc, str(tail)[:100], x["pip"]))
    try:
        ledger_path.parent.mkdir(parents=True, exist_ok=True)
        ledger_path.write_text(json.dumps(ledger, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass
    rc2, lines2 = run(check, *args, **kwargs) if done else (rc, lines)
    head = "[計] 環境檢查(只檢查 · 不 pip)· VCGC 安裝閘 %s · 裝好 %d%s · 沒裝 %d%s · 略過 %d" % (
        gate.stem if gate else "(找不到)", len(done), (" " + ",".join(done)) if done else "", len(failed), (" " + ",".join(failed)) if failed else "", len(skipped))
    for line in [head] + notes:
        print(line, flush=True)
    return rc2, [head] + notes + list(lines2)


def main(argv: list | None = None) -> int:
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments == ["--selftest"]:
        return selftest()
    legacy_pip = "--pip-install" in arguments or os.environ.get("VIA_VRN2_PIP_INSTALL") == "1"     # v0157: 舊行為只在操作員明說時
    arguments = [a for a in arguments if a != "--pip-install"]
''')
rep('''    original_run = base.run
    def accelerated_run(arguments, *args, **kwargs):
        if args:
            timeout, kwargs = run_limits(arguments, args[0], kwargs, lim)
            args = (timeout,) + tuple(args[1:])
        if arguments and Path(str(arguments[0])).name.lower().startswith("python"):
            arguments = execution_bridge.command(arguments, root, Path(__file__).parent)
        return original_run(arguments, *args, **kwargs)
    base.run = accelerated_run''', '''    original_run = base.run
    def plain_run(arguments, *args, **kwargs):
        if args:
            timeout, kwargs = run_limits(arguments, args[0], kwargs, lim)
            args = (timeout,) + tuple(args[1:])
        if arguments and Path(str(arguments[0])).name.lower().startswith("python"):
            arguments = execution_bridge.command(arguments, root, Path(__file__).parent)
        return original_run(arguments, *args, **kwargs)
    def accelerated_run(arguments, *args, **kwargs):
        if is_envcheck(arguments):                                             # v0157 ③ 只檢查 · 缺的經 VCGC 安裝閘
            return env_step(plain_run, arguments, args, kwargs, root, legacy_pip)
        return plain_run(arguments, *args, **kwargs)
    base.run = accelerated_run''')
rep('''    print("[PASS] v0156: ConsensusJoin v0104 is the active consensus join''', r'''    base_src = selftest_source(BASE_NAME).read_text(encoding="utf-8")
    assert 'run(M + ["envcheck"] + ([] if "--no-install" in argv or "--plan" in argv else ["--install"]), 3600, envx, cwd=str(vrn))' in base_src    # the call v0157 intercepts
    mgr_cmd = ["/py/python", "-W", "ignore", "/x/VRN_SystemManager_v0257.py", "envcheck", "--install"]
    assert is_envcheck(mgr_cmd) and not is_envcheck(["/py/python", "x.py", "envcheck"]) and not is_envcheck(["/py/python", "-W", "ignore", "/x/VRN_SystemManager_v0257.py", "vrn2", "--run"])
    with tempfile.TemporaryDirectory(prefix="vrn2-v0157-check-") as temporary:
        root157 = Path(temporary) / "VIA"
        reg = root157 / "supportive modules" / "registry"
        reg.mkdir(parents=True)
        for v in ("v0103", "v0104", "v0099"):
            (reg / ("CGC_MDL056_InstallGate_%s.py" % v)).write_text("# stub\n", encoding="utf-8")
        calls, state = [], {"checks": 0, "fixed": set()}
        def fake_run(cmd, *a, **k):
            cmd = [str(c) for c in cmd]
            calls.append(cmd)
            if "envcheck" in cmd:
                state["checks"] += 1
                out = ["[計] 環境檢查(envcheck · /py/python)· 掃 加速器 / 網路工具 2 檔 + VRN-2 尾版 1 檔 · 第三方套件 3"]
                if "duckdb" not in state["fixed"]:
                    out.append("[計] 缺 必裝 duckdb(pip duckdb · 用於 X.py)")
                out.append("[計] 缺 選裝 lz4(pip lz4 · 用於 Y.py)")
                return (1 if "duckdb" not in state["fixed"] else 0), out
            if cmd[-1] == "duckdb":
                state["fixed"].add("duckdb")
                return 0, ["  [裝後] 衝突 0 條 · 新增 0 · 解除 0"]
            return 1, ["  [安裝] SuperAccel 委派 · exit 1 · 同意閘未開——安裝需 $env:VIA_NET_CONSENT='YES'(紅線:不代設)", "  [FAIL] pip 安裝失敗 — 誠實停止(不註冊)"]
        rc1, lines1 = env_step(fake_run, mgr_cmd, (3600, {"VIA_NO_OPEN": "1"}), {"cwd": "x"}, root157)
        gate_calls = [c for c in calls if "envcheck" not in c]
        assert all("--install" not in c for c in calls if "envcheck" in c) and state["checks"] == 2                                 # check-only · re-check after an install
        assert [Path(c[3]).name for c in gate_calls] == ["CGC_MDL056_InstallGate_v0104.py"] * 2 and [c[-1] for c in gate_calls] == ["duckdb", "lz4"]
        assert rc1 == 0 and "裝好 1 duckdb" in lines1[0] and "沒裝 1 lz4" in lines1[0] and any("補裝失敗 選裝 lz4" in l and "via-install lz4" in l for l in lines1)
        assert not any("缺 必裝" in l for l in lines1)                                                                                # base: GREEN / YELLOW from these lines as before
        ledger157 = json.loads((root157 / "VIA_Reports" / "vrn2" / INSTALL_LEDGER).read_text(encoding="utf-8"))
        assert list(ledger157) == ["lz4"] and ledger157["lz4"]["gate"] == "CGC_MDL056_InstallGate_v0104.py" and ledger157["lz4"]["kind"] == "選裝"
        calls.clear()
        rc2, lines2 = env_step(fake_run, mgr_cmd, (3600,), {}, root157)
        assert not [c for c in calls if "envcheck" not in c] and any(l.startswith("[計] 略過 lz4") for l in lines2)                  # 24 h: not retried
        calls.clear()
        env_step(fake_run, mgr_cmd[:-1], (3600,), {}, root157)                                                                        # --no-install / --plan (base drops --install)
        assert not [c for c in calls if "envcheck" not in c] and len(calls) == 1
        calls.clear()
        rc3, lines3 = env_step(fake_run, mgr_cmd, (3600,), {}, root157, legacy=True)
        assert calls == [mgr_cmd] and "舊行為" in lines3[0]                                                                           # explicit operator choice only
        state["fixed"].clear()
        calls.clear()
        rc4, lines4 = env_step(fake_run, mgr_cmd, (3600,), {}, Path(temporary) / "no_vcgc")
        assert not [c for c in calls if "envcheck" not in c] and rc4 == 1 and any("找不到 VCGC 安裝閘" in l and "必裝 duckdb" in l for l in lines4)
    print("[PASS] v0157: step 3 runs envcheck check-only (no pip in this Python) · missing packages go one by one through VCGC's newest "
          "CGC_MDL056_InstallGate · re-checked after an install · gate failures not retried for 24 h · --no-install / --plan: no gate call · "
          "no VCGC gate → hand to VCGC · old in-place pip only with --pip-install / VIA_VRN2_PIP_INSTALL=1")
    print("[PASS] v0156: ConsensusJoin v0104 is the active consensus join''')
(S / "v157/new/ActivateVRN-2_v0157.py").write_text(s, encoding="utf-8", newline="\n")
print("launcher v0157 lines", s.count("\n"))
