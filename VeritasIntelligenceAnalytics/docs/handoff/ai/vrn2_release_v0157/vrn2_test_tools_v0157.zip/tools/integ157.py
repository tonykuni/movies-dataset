"""v0157 ③ 整合測:env_step + 真的 VCGC 安裝閘 v0104(沙盒 VIA 那份)· envcheck 輸出用假的(缺 必裝 1 個)· 同意閘不設 → 安裝閘誠實 FAIL · 不裝。"""
import importlib.util, json, subprocess, sys, shutil
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
spec = importlib.util.spec_from_file_location("launcher157", S / "v157/lst/ActivateVRN-2_v0157.py")
L = importlib.util.module_from_spec(spec); sys.modules[spec.name] = L; spec.loader.exec_module(L)
root = S / "v157/integ/VIA"
shutil.rmtree(root, ignore_errors=True)
src = S / "v157/t157a/VIA/supportive modules"
(root / "supportive modules").mkdir(parents=True)
for d in ("registry",):
    (root / "supportive modules" / d).mkdir()
for f in ("VIA_SuperAccel_Module.py",) + tuple(p.name for p in src.glob("SUP_MDL737_SuperAccelModule_v*.py")):
    shutil.copy(src / f, root / "supportive modules" / f)
shutil.copy(src / "registry/CGC_MDL056_InstallGate_v0104.py", root / "supportive modules/registry/")
calls = []
def run(cmd, timeout=None, env_extra=None, cwd=None, silent_max=1500):
    cmd = [str(c) for c in cmd]; calls.append(cmd)
    if "envcheck" in cmd:
        return 1, ["[計] 環境檢查(envcheck · %s)· 第三方套件 1" % sys.executable, "[計] 缺 必裝 vrn2probe(pip vrn2-probe-not-a-real-package · 用於 X.py)"]
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout, env={k: v for k, v in __import__("os").environ.items() if k not in ("VIA_NET_CONSENT", "VIA_SCRAPE_CONSENT")})
    return p.returncode, (p.stdout + p.stderr).splitlines()
rc, lines = L.env_step(run, [sys.executable, "-W", "ignore", "/x/VRN_SystemManager_v0257.py", "envcheck", "--install"], (3600,), {}, root)
gate_calls = [c for c in calls if "envcheck" not in c]
ledger = json.loads((root / "VIA_Reports/vrn2/VRN2_VCGCInstall_latest.json").read_text(encoding="utf-8"))
ok = (len(gate_calls) == 1 and Path(gate_calls[0][3]).name == "CGC_MDL056_InstallGate_v0104.py" and gate_calls[0][-1] == "vrn2-probe-not-a-real-package"
      and rc == 1 and any("補裝失敗 必裝 vrn2-probe-not-a-real-package" in l and "via-install" in l for l in lines)
      and ledger["vrn2-probe-not-a-real-package"]["kind"] == "必裝" and not any("--install" in c for c in calls if "envcheck" in c))
print("\n".join(lines[:4]))
print("ledger:", json.dumps(ledger, ensure_ascii=False)[:300])
print("[%s] v0157 ③ 整合:真的 VCGC 安裝閘 v0104 被呼叫 · 同意閘不設 → 誠實 FAIL · 帳記必裝 · 交 VCGC via-install · envcheck 沒帶 --install" % ("PASS" if ok else "FAIL"))
sys.exit(0 if ok else 1)
