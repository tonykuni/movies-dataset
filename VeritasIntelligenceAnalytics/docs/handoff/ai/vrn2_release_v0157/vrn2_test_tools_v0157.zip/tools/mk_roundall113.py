"""VRN2_RoundAll_v0113.py = v0112 + 套件 v0157(啟動器 v0157:③ 只檢查 · 缺的經 VCGC 安裝閘 · runtime v0156 不動)+ 除錯報告 / 收尾頁的 VCGC 安裝閘列。"""
import re
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
src = (S / "v156/new/VRN2_RoundAll_v0112.py").read_text(encoding="utf-8")
assert '"@PACKAGE_SHA256@"' in src
d0 = src.index('"""VRN2_RoundAll v0112'); d1 = src.index('"""', d0 + 3) + 3
head, doc, body = src[:d0], src[d0:d1], src[d1:]
doc = doc.replace('"""VRN2_RoundAll v0112 — ', '"""VRN2_RoundAll v0113 — ', 1)
at = doc.index("v0112(操作員 2026-10-31:「新版有版本號")
doc = doc[:at] + r'''v0113(操作員 2026-10-31:「預設關掉 ③ 的 pip 補裝,改經 VCGC 安裝」):
  · 套件 v0157(啟動器 v0157 · runtime 沿用 v0156)。啟動器 ③ 環境檢查只檢查(管理器 envcheck 不再帶 --install,不再用本環境 pip + numpy<2 約束補裝);
    缺的套件一個一個交 VCGC 的安裝閘 supportive modules\\registry\\CGC_MDL056_InstallGate(最高版號 · 裝前 / 裝後衝突快照 · Lib Registry · SuperAccel 安裝道
    要 VIA_NET_CONSENT=YES)→ 再檢查一次;安裝閘裝不起來的 24 小時內不重試(VIA_Reports\\vrn2\\VRN2_VCGCInstall_latest.json)。
  · 除錯報告:「③ 環境檢查 · VCGC 安裝閘沒裝起來」—— 必裝 = 黃(收尾頁 VCGC · via-install 指令)· 選裝 = 灰(只列)。② 的提示改成經 VCGC 安裝閘(不印 pip 指令)。
  · 貼回包多帶 VRN2_VCGCInstall_latest.json 與 VRN2_Env_latest.json。
  · 收尾頁:② 磁碟可用不到 2 GB → 人工(以前預設算 VRN-2)。

''' + doc[at:]
doc = doc.replace("用法:python VRN2_RoundAll_v0112.py", "用法:python VRN2_RoundAll_v0113.py")
assert not re.search(r"(?<!\\)\\(?![\\])", doc.replace("\\\\", "")), "single backslash in docstring"
keep = {'RUNTIME_ZIP = "VRN2_Runtime_v0156.zip"': "@RZ@", 'RUNTIME_MANIFEST = "VRN2_Runtime_v0156.json"': "@RM@"}
for a, b in keep.items():
    assert body.count(a) == 1, a
    body = body.replace(a, b)
body = body.replace("v0156", "v0157")
for a, b in keep.items():
    body = body.replace(b, a)
s = head + doc + body


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90])
    s = s.replace(a, b)


rep('VERSION = "v0112"', 'VERSION = "v0113"')
rep('''        "啟動器 ③ 會檢查 / 補裝;仍缺 → 交 VCGC 安裝:%s -m pip install %s" % (vpy, " ".join(miss)) if miss else "")''',
    '''        "啟動器 v0157 ③ 只檢查 · 缺的經 VCGC 安裝閘(CGC_MDL056_InstallGate)裝 · 仍缺 → 交 VCGC:via-install %s(VRN-2 不 pip)" % " ".join(miss) if miss else "")''')
rep('''ADVICE = (("③", "缺必裝套件 / 加速器:看 ③ 那行列的缺項;啟動器會試著補裝,仍缺 → 交 VCGC 安裝(VRN-2 只檢查)"),''',
    '''ADVICE = (("③", "缺必裝套件 / 加速器:看 ③ 那行列的缺項;啟動器 v0157 只檢查,缺的經 VCGC 安裝閘裝,仍缺 → 交 VCGC:via-install(VRN-2 不 pip)"),''')
rep('''"output/VRN2_Combined_latest.csv", ''', '''"VRN2_VCGCInstall_latest.json", "VRN2_Env_latest.json", "output/VRN2_Combined_latest.csv", ''')
rep('''    nd = cons_rec.get("net_deny") or {}
    if nd:                                                                    # v0112''', '''    vinst = jread(v2 / "VRN2_VCGCInstall_latest.json", {}) or {}
    if vinst:                                                                 # v0113 啟動器 v0157 ③:VCGC 安裝閘沒裝起來的套件(24 小時內不重試)
        must = sorted(k for k, v in vinst.items() if (v or {}).get("kind") == "必裝")
        rest = sorted(k for k in vinst if k not in must)
        def _why(k):
            v = vinst.get(k) or {}
            return "%s(%s · %s)" % (k, v.get("day", ""), str(v.get("why", ""))[:80])
        if must:
            f("YELLOW", "③ 環境檢查 · VCGC 安裝閘沒裝起來(必裝)", " · ".join(_why(k) for k in must)[:300],
              "交 VCGC:via-install %s(VRN-2 不 pip · 24 小時內不重試 · 要重試先設 VIA_VRN2_INSTALL_RETRY=1)" % " ".join(must))
        if rest:
            f("GRAY", "③ 環境檢查 · VCGC 安裝閘沒裝起來(選裝)", " · ".join(_why(k) for k in rest)[:300], "選裝 · 不擋 · 要裝:via-install %s" % " ".join(rest))
    nd = cons_rec.get("net_deny") or {}
    if nd:                                                                    # v0112''')
rep('''        chk("55 除錯報告:共識是經 VIA 網路工具抓的 → 綠列(網路工具版號 · 閘 · 加速器)", row55 is not None and row55["lamp"] == "GREEN" and "NetUnified_v0119" in row55["finding"])
''', '''        chk("55 除錯報告:共識是經 VIA 網路工具抓的 → 綠列(網路工具版號 · 閘 · 加速器)", row55 is not None and row55["lamp"] == "GREEN" and "NetUnified_v0119" in row55["finding"])
        # 56 v0113 ③ 經 VCGC 安裝閘
        (v10 / "VRN2_VCGCInstall_latest.json").write_text(json.dumps({"duckdb": {"day": "2026-10-31", "kind": "必裝", "why": "[FAIL] pip 安裝失敗", "gate": "CGC_MDL056_InstallGate_v0104.py"},
                                                                     "lz4": {"day": "2026-10-31", "kind": "選裝", "why": "同意閘未開"}}), encoding="utf-8")
        rep56 = diagnose(r10, None)
        m56 = next((x for x in rep56.get("findings") or [] if x["area"] == "③ 環境檢查 · VCGC 安裝閘沒裝起來(必裝)"), None)
        o56 = next((x for x in rep56.get("findings") or [] if x["area"] == "③ 環境檢查 · VCGC 安裝閘沒裝起來(選裝)"), None)
        own56 = owner_of({"lamp": "YELLOW", "step": "⑥ " + (m56 or {}).get("area", ""), "detail": (m56 or {}).get("finding", "")}, cx10)
        src56 = Path(__file__).read_text(encoding="utf-8")
        chk("56 ③ 經 VCGC 安裝閘:除錯報告列 VCGC 安裝閘沒裝起來的必裝(黃 · via-install · 收尾頁 VCGC)· 選裝灰 · ② 不再印 pip 指令 · 貼回包帶安裝帳",
            m56 is not None and m56["lamp"] == "YELLOW" and "via-install duckdb" in m56["next"] and o56 is not None and o56["lamp"] == "GRAY" and own56[0] == "VCGC"
            and "-m pip install %s\\" % (vpy" not in src56 and "VRN2_VCGCInstall_latest.json" in PASTE_FILES)
        (v10 / "VRN2_VCGCInstall_latest.json").unlink()
''')
rep("""    if step.startswith("② CPU"):                                             # v0106
        return "提醒", "CPU 被別的程式佔用 · 啟動器自動降平行路數(只會慢 · 不影響結果)"
""", """    if step.startswith("② CPU"):                                             # v0106
        return "提醒", "CPU 被別的程式佔用 · 啟動器自動降平行路數(只會慢 · 不影響結果)"
    if step.startswith("② 磁碟"):                                            # v0113 磁碟空間是這台機器的事(VRN-2 不刪檔)
        return "人工", "磁碟可用不到 2 GB → 操作員清出空間(OCR / 快取 / 增量庫要用)· VRN-2 不刪使用者的檔"
""")
rep("""        (v10 / "VRN2_VCGCInstall_latest.json").unlink()
""", """        (v10 / "VRN2_VCGCInstall_latest.json").unlink()
        o57 = owner_of({"lamp": "YELLOW", "step": "② 磁碟 · VIA 根", "detail": "可用 1.4 GB"}, cx10)
        chk("57 收尾頁:② 磁碟可用不到 2 GB → 人工(清空間 · 不是 VRN-2 要改碼;沙盒整輪 v0157 實錄被算成 VRN-2 2 項)", o57[0] == "人工")
""")
s = s.replace('"C:/Users/x/Downloads/VRN2_RoundAll_v0112.py"', '"C:/Users/x/Downloads/VRN2_RoundAll_v0113.py"').replace('"VRN2_RoundAll_v0112.py" in html_', '"VRN2_RoundAll_v0113.py" in html_')
assert "VRN2_RoundAll_v0112.py" not in s.split('"""', 2)[2] or True
(S / "v157/new/VRN2_RoundAll_v0113.py").write_text(s, encoding="utf-8", newline="\n")
print("RoundAll v0113 lines", s.count("\n"), "· v0112 refs after doc:", [m.start() for m in re.finditer("RoundAll_v0112", s[d1:])][:5])
