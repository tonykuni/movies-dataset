# VRN-2 · PowerShell 7 一行處理全部 · VRN2_HandleAll_v0105(2026-10-31 · 套件 v0157 · RoundAll v0113)

v0105 = v0104 + 套件 **v0157**:操作員 2026-10-31「預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝」。

| 項目 | 現在 |
|---|---|
| ③ 環境檢查 | 管理器 envcheck **只檢查**(不再用這個 Python 直接 pip · 舊的補裝還會加 `numpy<2` 約束,會把 numpy 降版) |
| 缺的套件 | 一個一個交 **VCGC 安裝閘** `supportive modules\registry\CGC_MDL056_InstallGate` 最高版號(倉裡 v0104 · 跟 VCGC EnvGovernance 取同一支):裝前 / 裝後衝突快照 · Lib Registry · 匯入煙測 · SuperAccel 安裝道(要 `VIA_NET_CONSENT=YES`)→ 裝完再檢查一次 |
| 裝不起來 | 24 小時內不重試(`VIA_Reports\vrn2\VRN2_VCGCInstall_latest.json`)· 除錯報告列「③ 環境檢查 · VCGC 安裝閘沒裝起來」:必裝 = 黃(收尾頁 VCGC · 附 `via-install` 指令)· 選裝 = 灰 |
| 不要裝 | 整輪加 `$env:VRN2_ROUNDALL_ARGS = '--launcher-args "--no-install"'`:只檢查 |
| 舊行為 | 只有操作員明說:`--pip-install` 或 `$env:VIA_VRN2_PIP_INSTALL = '1'` |
| 一支 Python | `VRN2_RoundAll_v0113.py`(SHA-256 `@RA12@`)· 套件 `VRN2_Closeout_v0157.zip`(SHA-256 `@WANT12@` · runtime v0156 原樣) |

③b OCR 隔離環境沒有改:它在自己的 venv 裡 pip(不是主 Python);VCGC 安裝閘只裝進呼叫它的那個 Python,裝不進別的 venv。

## PowerShell 7 貼這一行(@TLEN@ 字元 · 4 行內)

```powershell
@TINY@
```

第一行應是 `[GREEN] boot: Handle-All v0105 SHA-256 OK`(開機檔 SHA-256 `@BT12@` · Handle-All 那一行 `@HA12@`)。

## 同意閘(操作員決定 · VRN-2 只讀 · 不代設)

桌機 04:13 那輪 ③b 印的是 `VIA_NET_CONSENT=YES · VIA_SCRAPE_CONSENT=(未設)` → 閘二沒開 → ⑥f 不經網路工具重抓 · 收尾頁多一項「人工」。
要經網路工具抓共識:在同一個視窗先貼下面這行,再貼最上面那一行。

```powershell
$env:VIA_NET_CONSENT = 'YES'; $env:VIA_SCRAPE_CONSENT = 'YES'
```

## 這次桌機貼下去會怎樣

上一輪收據 `VRN2_Closeout_v0153.json`、輸出冊在 → auto 選 **repair**(不跑啟動器 · ③ 這輪不會跑):

- 閘照舊(閘二沒開)→ 跟 04:13 一樣 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2**。
- 先設好兩道閘 → ⑥f 經 VIA 網路工具重抓 → 預期 **BLOCKED · VRN-2 0 · VCGC 1 · 人工 2 · 資料源 2**。

整輪(`$env:VRN2_MODE = 'full'`)才會跑到 ③:缺的套件經 VCGC 安裝閘;安裝閘要 `VIA_NET_CONSENT=YES`(桌機有)。

## 開機行(@BTLEN@ 字元)

```powershell
@BOOT@
```

## cmd 視窗

```bat
@CMD@
```

## Handle-All 那一行(開機行從 GitHub 取這段、核對 SHA-256 才執行 · 不用貼它)

<!-- handle-all line -->
```powershell
@LINE@
```

## 可讀版 · Handle-All

```powershell
@SRC@
```

## 可讀版 · 開機行

```powershell
@BTSRC@
```
