"""v0157 整包重建(冪等):pkg157 → 套件 VRN2_Closeout_v0157.zip → VRN2_RoundAll_v0113.py(填套件雜湊)→ Handle-All v0105 → 開機行 + 開機檔 + 最短一行 + cmd 一行
→ md · 發行清單。vrn2_release_v0156 及更早的發行夾不動。"""
import base64, hashlib, json, re, sys, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad")
W = S / "v157"; out, rel, new = W / "pkg157", W / "release157", W / "new"
rel.mkdir(exist_ok=True)
sys.path.insert(0, str(W / "ps7"))
from join_ps import join  # noqa: E402

REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
r156 = json.loads((REPO / "vrn2_release_v0156/VRN2_Release_v0156.json").read_text(encoding="utf-8"))
rt = json.loads((out / "VRN2_Runtime_v0156.json").read_text(encoding="utf-8"))
assert rt["zip_sha256"] == r156["runtime"]["zip_sha256"] == hashlib.sha256((out / "VRN2_Runtime_v0156.zip").read_bytes()).hexdigest()   # runtime v0156 原樣
pnames = ["ActivateVRN-2_v0136.py", "ActivateVRN-2_v0157.py", "VRN2_Runtime_v0156.zip", "VRN2_Runtime_v0156.json", "VIA_ExecutionBridge_v0103.py", "VIA_RunWithTools_v0103.py", "VRN2_VerbatimVerifier_v0104.py", "VRN2_VerbatimVerifier_v0105.py", "VRN2_OCRBridge_v0101.py"]
files = {n: (out / n).read_bytes() for n in pnames}
files["README.txt"] = ("VRN2_Closeout_v0157 — VRN-2 closeout package (2026-10-31 · step 3 installs through VCGC)\n\n"
  "Entry: python ActivateVRN-2_v0157.py [--source <folder>] [--no-install] [--no-open] [--pip-install]\n"
  "One-file runner (outside the package): VRN2_RoundAll_v0113.py · PowerShell 7 'handle all': VRN2_HandleAll_v0105.md (same release folder; tiny paste line inside).\n"
  "Runtime: VRN2_Runtime_v0156.zip unchanged (190 members of v0154 + Fusion engine v0122 + ConsensusJoin v0104).\n\n"
  "New in v0157 (operator 2026-10-31: '預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝'):\n"
  " - step 3 runs the manager's envcheck check-only: no pip into this Python (the manager's old --install used numpy>=1.24,<2.0 as a constraint).\n"
  " - each missing package goes through VCGC's install gate supportive modules/registry/CGC_MDL056_InstallGate (highest version): pip check\n"
  "   before / after, VIA_Lib_Registry entry, import smoke, SuperAccel install lane (needs VIA_NET_CONSENT=YES); then envcheck runs again.\n"
  " - a package the gate could not install is not retried for 24 h (VIA_Reports/vrn2/VRN2_VCGCInstall_latest.json; VIA_VRN2_INSTALL_RETRY=1 retries).\n"
  " - --no-install / --plan: check only. --pip-install or VIA_VRN2_PIP_INSTALL=1: the old in-place pip (operator's explicit choice only).\n"
  "Verification: see VRN2_Verification_v0157.md. Hashes: PACKAGE_SHA256.json.\n").encode("utf-8")
files["VALIDATION_RESULT.json"] = json.dumps({"status": "see VRN2_Verification_v0157.md"}, ensure_ascii=False).encode("utf-8")
manifest = {"system": "VRN-2", "version": "v0157", "files": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest()} for n in sorted(files)]}
files["PACKAGE_SHA256.json"] = json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8")
zpr = rel / "VRN2_Closeout_v0157.zip"
with zipfile.ZipFile(zpr, "w", zipfile.ZIP_DEFLATED) as z:
    for n in sorted(files):
        zi = zipfile.ZipInfo("VRN2_Closeout_v0157/" + n, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16; z.writestr(zi, files[n])
want = hashlib.sha256(zpr.read_bytes()).hexdigest()
ra = re.sub(r'PACKAGE_SHA256 = "(@PACKAGE_SHA256@|[0-9a-f]{64})"', 'PACKAGE_SHA256 = "%s"' % want, (new / "VRN2_RoundAll_v0113.py").read_text(encoding="utf-8"), count=1)
assert want in ra and 'PACKAGE = "VRN2_Closeout_v0157"' in ra and 'RELEASE_REL = "VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0157"' in ra and 'RUNTIME_ZIP = "VRN2_Runtime_v0156.zip"' in ra
(rel / "VRN2_RoundAll_v0113.py").write_text(ra, encoding="utf-8", newline="\n")
ra_sha = hashlib.sha256(ra.encode("utf-8")).hexdigest()
ps7 = (S / "v151/ps7/line_ps7_tpl.txt").read_text(encoding="utf-8").strip("\n").replace("vrn2_release_v0151", "vrn2_release_v0157").replace("@F@", "VRN2_RoundAll_v0113.py").replace("@H@", ra_sha)
assert ("$H = '%s'" % ra_sha) in ps7
(rel / "oneline_roundall_ps7.txt").write_text(ps7 + "\n", encoding="utf-8")
ha_src = (W / "ps7/handleall_src.ps1").read_text(encoding="utf-8").replace("@H@", ra_sha)
assert ha_src.count(ra_sha) == 1 and "vrn2_release_v0157" in ha_src and "VRN2_RoundAll_v0113.py" in ha_src and "exit" not in ha_src.replace("Exception", "")
ha_line = join(ha_src); ha_sha = hashlib.sha256(ha_line.encode("utf-8")).hexdigest()
(rel / "handleall_src.ps1").write_text(ha_src, encoding="utf-8", newline="\n"); (rel / "handleall_line.txt").write_text(ha_line + "\n", encoding="utf-8", newline="\n")
bt_src = (W / "ps7/boot_src.ps1").read_text(encoding="utf-8").replace("@HA@", ha_sha)
bt_line = join(bt_src); bt_sha = hashlib.sha256(bt_line.encode("ascii")).hexdigest()
assert all(ord(c) < 128 for c in bt_line) and len(bt_line) < 1800 and ha_sha in bt_line
(rel / "boot_src.ps1").write_text(bt_src, encoding="utf-8", newline="\n"); (rel / "boot_line.txt").write_text(bt_line + "\n", encoding="utf-8", newline="\n")
(rel / "VRN2_HandleAll_v0105_boot.txt").write_text(bt_line + "\n", encoding="ascii", newline="\n")
cmd_line = "pwsh -NoProfile -ExecutionPolicy Bypass -EncodedCommand " + base64.b64encode(bt_line.encode("utf-16-le")).decode("ascii"); assert len(cmd_line) < 8191
(rel / "boot_cmd.txt").write_text(cmd_line + "\n", encoding="utf-8")
tiny = ('$r="$HOME\\OneDrive\\Documents\\movies-dataset";git -C $r fetch -q origin claude/optimistic-goodall-yhalc5;'
        '$c=(git -C $r show "FETCH_HEAD:VeritasIntelligenceAnalytics/docs/handoff/ai/vrn2_release_v0157/VRN2_HandleAll_v0105_boot.txt")-join"`n";'
        "if((Get-FileHash -InputStream ([IO.MemoryStream]::new([byte[]][char[]]$c))).Hash-eq'%s'){iex $c}else{'[RED] boot SHA-256 mismatch - not run'}") % bt_sha
assert all(ord(c) < 128 for c in tiny) and len(tiny) < 500
(rel / "tiny_line.txt").write_text(tiny + "\n", encoding="ascii", newline="\n")
print("package", want[:12], "· roundall", ra_sha[:12], "· handle-all", len(ha_line), ha_sha[:12], "· boot", len(bt_line), bt_sha[:12], "· tiny", len(tiny), "· cmd", len(cmd_line))
md = (W / "ha_md_tpl.md").read_text(encoding="utf-8")
for k, v in (("@TINY@", tiny), ("@TLEN@", str(len(tiny))), ("@BT12@", bt_sha[:12]), ("@HA12@", ha_sha[:12]), ("@RA12@", ra_sha[:12]), ("@WANT12@", want[:12]), ("@BOOT@", bt_line),
             ("@BTLEN@", "{:,}".format(len(bt_line))), ("@CMD@", cmd_line), ("@LINE@", ha_line), ("@SRC@", ha_src.rstrip("\n")), ("@BTSRC@", bt_src.rstrip("\n"))):
    md = md.replace(k, v)
assert not re.search(r"@[A-Z0-9]+@", md)
got = re.findall(r"(?s)<!-- handle-all line -->\n```powershell\n(.*?)\n```", md)
assert got == [ha_line] and base64.b64decode(cmd_line.split()[-1]).decode("utf-16-le") == bt_line
(rel / "VRN2_HandleAll_v0105.md").write_text(md, encoding="utf-8", newline="\n")
ra_md = (W / "ra_md_tpl.md").read_text(encoding="utf-8").replace("@RA12@", ra_sha[:12]).replace("@WANT12@", want[:12]).replace("@PS7@", ps7)
assert not re.search(r"@[A-Z0-9]+@", ra_md)
(rel / "VRN2_RoundAll_v0113.md").write_text(ra_md, encoding="utf-8", newline="\n")
relj = {"system": "VRN-2", "independent": True, "release": "ActivateVRN-2 v0157 (step 3 check-only · missing packages through VCGC's install gate) + VRN2_RoundAll_v0113 + VRN2_HandleAll_v0105", "date": "2026-10-31",
        "trigger": "操作員 2026-10-31:「預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝」(桌機 04:13 Handle-All v0104 repair:同意閘 VIA_SCRAPE_CONSENT 未設 → BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2)",
        "base_package": {"name": "VRN2_Closeout_v0156 (launcher v0156 · runtime v0156)", "retained": "runtime v0156 zip byte-identical (same sha256); ActivateVRN-2_v0136.py base unchanged"},
        "supersedes": "v0156 package for the closeout entry; VRN2_RoundAll v0112 → v0113; VRN2_HandleAll v0104 → v0105",
        "install_route": {"step3": "manager envcheck check-only (this entry drops the base's --install; the manager's in-place pip used numpy>=1.24,<2.0)",
                          "gate": "supportive modules/registry/CGC_MDL056_InstallGate_v#### highest (v0104 in the repo · same pick as VCGC EnvGovernance) · one package per call · pip check before / after · VIA_Lib_Registry · import smoke · SuperAccel install lane behind VIA_NET_CONSENT",
                          "ledger": "VIA_Reports/vrn2/VRN2_VCGCInstall_latest.json · gate failures not retried for 24 h · VIA_VRN2_INSTALL_RETRY=1 retries",
                          "opt_out": "--no-install / --plan: check only, no gate call", "legacy": "--pip-install or VIA_VRN2_PIP_INSTALL=1: old in-place pip (operator's explicit choice only)",
                          "not_changed": "step 3b OCR isolated venv (VRN2 OCR bridge) still builds its own venv with pip inside that venv (not this Python); VCGC's gate installs into the calling Python only"},
        "fixes": {"launcher_v0157": "receipt VRN2_Closeout_v0157.json · base.run wrapper intercepts the manager envcheck call (env_step) · selftest block v0157 (check-only · gate newest · re-check · 24 h ledger · --no-install · no gate · legacy)",
                  "RoundAll_v0113": "package v0157 · step 2 hint names the VCGC gate (no pip command) · debug rows '③ 環境檢查 · VCGC 安裝閘沒裝起來' (must = YELLOW / VCGC · optional = GRAY) · paste-back carries VRN2_VCGCInstall_latest.json + VRN2_Env_latest.json · close-out: ② 磁碟 under 2 GB → human (was VRN-2 by default) · selftest 57",
                  "HandleAll_v0105": "v0104 pointed at RoundAll v0113 (vrn2_release_v0157)"},
        "not_fixed_here": r156["not_fixed_here"],
        "components": [{"path": n, "sha256": hashlib.sha256(files[n]).hexdigest(), "bytes": len(files[n])} for n in sorted(files)],
        "runtime": {k: rt[k] for k in ("version", "zip_sha256", "based_on", "retained_members", "new_members")} | {"files": "see VRN2_Runtime_v0156.json inside the package", "changed": False},
        "roundall_previous": [{"name": "VRN2_RoundAll_v0112.py", "sha256": r156["roundall"]["sha256"], "status": "superseded 2026-10-31 (package v0156 · step 3 pip in place); file kept in vrn2_release_v0156"}],
        "roundall": {"name": "VRN2_RoundAll_v0113.py", "sha256": ra_sha, "pinned_package_sha256": want, "guide": "VRN2_RoundAll_v0113.md"},
        "handleall": {"name": "VRN2_HandleAll_v0105.md", "line_sha256": ha_sha, "line_chars": len(ha_line), "boot_file": "VRN2_HandleAll_v0105_boot.txt", "boot_line_sha256": bt_sha, "boot_line_chars": len(bt_line),
                      "tiny_line_chars": len(tiny), "cmd_line_chars": len(cmd_line)},
        "tested_in": "Linux container · python 3.13 venv_vrn2 · pwsh 7.4.6 · VCGC InstallGate v0104 copied into the sandbox VIA tree (gate closed → honest FAIL · no install)", "results": {"status": "see VRN2_Verification_v0157.md"},
        "package": {"name": zpr.name, "sha256": want, "bytes": zpr.stat().st_size, "layout": "VRN2_Closeout_v0157/<files> (no .ps1)"},
        "launcher": {"name": "ActivateVRN-2_v0157.py", "sha256": hashlib.sha256(files["ActivateVRN-2_v0157.py"]).hexdigest()},
        "test_tools_zip": "vrn2_test_tools_v0157.zip", "logs_zip": "logs_v0157.zip"}
(rel / "VRN2_Release_v0157.json").write_text(json.dumps(relj, ensure_ascii=False, indent=1), encoding="utf-8")
for k, v in (("zip_sha.txt", want), ("ra_sha.txt", ra_sha), ("ha_sha.txt", ha_sha), ("bt_sha.txt", bt_sha)):
    (rel / k).write_text(v)
print("built", sorted(p.name for p in rel.iterdir()))
