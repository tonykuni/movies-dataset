# VRN-2 一支 Python · VRN2_RoundAll_v0113.py(套件 v0157 · ③ 改經 VCGC 安裝)

`VRN2_RoundAll_v0113.py`(只用 Python 標準庫 · SHA-256 `@RA12@`)= v0112 + 套件 `vrn2_release_v0157/VRN2_Closeout_v0157.zip`(SHA-256 `@WANT12@`,本檔內已釘死):

| 改了什麼 | 說明 |
|---|---|
| 套件 v0157 | 啟動器 v0157(③ 只檢查 · 缺的一個一個交 VCGC 安裝閘 `CGC_MDL056_InstallGate` 最高版號 · 裝完再檢查 · 裝不起來 24 小時不重試)· runtime v0156 原樣 |
| ② 提示 | 必裝缺 → 「啟動器 v0157 ③ 只檢查 · 缺的經 VCGC 安裝閘裝 · 仍缺 → via-install」(不再印 pip 指令) |
| 除錯報告 | 「③ 環境檢查 · VCGC 安裝閘沒裝起來」:必裝 = 黃(收尾頁 VCGC)· 選裝 = 灰 |
| 貼回包 | 多帶 `VRN2_VCGCInstall_latest.json` 與 `VRN2_Env_latest.json` |

自測 57 項(v0112 的 55 項 + 56 · 57)。**最省事:`VRN2_HandleAll_v0105.md` 最上面那一行**。前版 v0112 的說明見 `vrn2_release_v0156/VRN2_RoundAll_v0112.md`。

## 在 PowerShell 7 視窗直接貼(約 2,300 字元)

```powershell
@PS7@
```

## 已經有這個檔時

```bat
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0113.py" --only package,fix,report,closeout,pasteback
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0113.py"
python "%USERPROFILE%\Downloads\VRN2_RoundAll_v0113.py" --launcher-args "--no-install"
```

第 1 行 = 只修 + 收尾頁 · 第 2 行 = 整輪(③ 缺的經 VCGC 安裝閘)· 第 3 行 = 整輪但 ③ 只檢查、不裝。PowerShell 把 `%USERPROFILE%` 換成 `$env:USERPROFILE`。
