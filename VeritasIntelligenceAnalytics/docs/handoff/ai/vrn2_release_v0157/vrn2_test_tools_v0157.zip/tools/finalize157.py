"""v0157 收尾:測試結果 → 發行清單 · 驗證紀錄 v0157 · 交接 v0158(從 v0157 抄 · 只增)· 放進倉 vrn2_release_v0157 · logs / 工具 zip。"""
import json, re, shutil, zipfile
from pathlib import Path
S = Path("/tmp/claude-0/-home-user/a5893bdc-578f-5cd1-ac75-9575fa695b26/scratchpad"); W = S / "v157"; rel = W / "release157"
REPO = Path("/home/user/movies-dataset/VeritasIntelligenceAnalytics/docs/handoff/ai")
def lines(p): return Path(p).read_text(encoding="utf-8", errors="replace").splitlines()
def short(x):
    x = re.sub(r"/tmp/claude-0/[^ ·)(/]+/[0-9a-f-]{36}/scratchpad/(venv_vrn2|pwsh)", r"<scratch>/\1", x)
    return re.sub(r"/tmp/claude-0/[^ ·)(]*?/(t157a|v157|v156|lst)/", r"<\1>/", x)
def pick(n, extra=""):
    pat = r"boot|③b VIA|④ 自動選模式|⑤ 自動修計畫|===== 收尾|^  \[(VRN-2|VCGC|人工|資料源)\] \d|Handle-All 結束" + extra
    return [short(l)[:240] for l in lines(W / ("tiny_%s.log" % n)) if re.search(pat, l)]
R = json.loads((rel / "VRN2_Release_v0157.json").read_text(encoding="utf-8"))
st_ra = [l for l in lines(W / "rall113_selftest.log") if re.search(r"^\[PASS\] 5[67] |^\[FAIL\]|--selftest · ", l)]
st_l = [l[:220] for l in lines(W / "launcher157_selftest.log") if re.search(r"^\[PASS\] v015[67]|^\[FAIL\]", l)]
rc = lines(W / "tiny157.rc")
integ = [short(l)[:260] for l in lines(W / "integ157.log") if re.search(r"VCGC 安裝閘|補裝失敗|^\[(PASS|FAIL)\]", l)]
full3 = [short(l)[:240] for l in lines(W / "tiny_full.log") if re.search(r"③ 環境檢查|VCGC 安裝閘|補裝失敗|略過 .*VCGC|pip install", l)][:14]
R["results"] = {"roundall_selftest": st_ra, "launcher_selftest": st_l, "pwsh_parse": "pwsh 7.4.6 剖析 0 錯 · Handle-All 一行 = 可讀版 · 開機行 = 可讀版 · 最短一行 0 錯",
                "e2e_rc": rc, "e2e": {n: pick(n) for n in ("report", "auto", "full", "tamper")}, "full_step3": full3, "integration_real_gate": integ}
(rel / "VRN2_Release_v0157.json").write_text(json.dumps(R, ensure_ascii=False, indent=1), encoding="utf-8")
E = R["results"]["e2e"]
md = """# VRN-2 v0157 驗證紀錄(2026-10-31 · ③ 預設不 pip · 缺的經 VCGC 安裝閘 · 套件 v0157 · RoundAll v0113 · Handle-All v0105)

## 1. 要求與桌機狀態

操作員 2026-10-31:「預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝」。同時貼回桌機 04:13 Handle-All v0104 repair:③b `VIA_NET_CONSENT=YES · VIA_SCRAPE_CONSENT=(未設)`
→ 閘二沒開 → ⑥f 不重抓 → **BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2**(跟 v0156 預期的「閘關」一樣)。

## 2. 根因(容器裡看到的)

管理器 `envcheck --install`(VRN_SystemManager v0231 起)用**這個 Python 直接 pip**,而且加 `-c constraints.txt`(`numpy>=1.24,<2.0`)。
v0156 沙盒整輪時它補裝了幾個套件,numpy 被降到 1.26.4、pyarrow 讀不起來。

## 3. 做了什麼

| 檔 | 版本 | SHA-256 | 說明 |
|---|---|---|---|
| 啟動器 | v0157 | `%s` | 攔下底座 ③ 的 envcheck:拿掉 `--install`(只檢查)→ 缺的一個一個交 VCGC `CGC_MDL056_InstallGate` 最高版號 → 裝完再檢查 · 24 小時不重試 · `--no-install` / `--plan` 不呼叫 · 找不到閘交 VCGC · 舊行為只有 `--pip-install` / `VIA_VRN2_PIP_INSTALL=1` |
| RoundAll | v0113 | `%s` | ② 提示改經 VCGC 安裝閘 · 除錯報告「③ 環境檢查 · VCGC 安裝閘沒裝起來」(必裝黃 / 選裝灰)· 貼回包帶安裝帳 |
| Handle-All | v0105 | 一行 `%s` | 指向 RoundAll v0113 |
| 套件 | VRN2_Closeout_v0157.zip | `%s` | runtime v0156 原樣(同一個 zip) |

③b OCR 隔離環境沒改:它在自己的 venv 裡 pip(不是主 Python);VCGC 安裝閘只裝進呼叫它的那個 Python。

## 4. 自測

```text
%s
%s
%s
e2e 結束碼:%s
```

## 5. ③ 經 VCGC 安裝閘

沙盒整輪(VCGC 安裝閘 v0104 放進沙盒 VIA · 同意閘不設):沙盒的 Python 不缺套件 → ③ 只檢查就綠,沒呼叫安裝閘。

```text
%s
```

整合測(`integ157.py`:v0157 的 `env_step` + **真的** VCGC 安裝閘 v0104 · envcheck 輸出用假的「缺 必裝 1 個」· 同意閘不設):

```text
%s
```

## 6. 最短一行 e2e(沙盒 = 桌機 v0153 狀態 · pwsh 7.4.6)

```text
%s
```

## 7. 桌機預期

貼 `VRN2_HandleAll_v0105.md` 最上面那行 → auto → repair(不跑啟動器 · ③ 這輪不跑)→ 閘照舊 = BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2;
兩道閘都設 → 人工 2。整輪才跑 ③:缺的經 VCGC 安裝閘(桌機有 `VIA_NET_CONSENT=YES`,安裝閘的 SuperAccel 安裝道會放行)。
""" % (R["launcher"]["sha256"][:12], R["roundall"]["sha256"][:12], R["handleall"]["line_sha256"][:12], R["package"]["sha256"][:12],
       "\n".join(st_ra), "\n".join(st_l), R["results"]["pwsh_parse"], " · ".join(rc), "\n".join(full3) or "(沒有 ③ 列)", "\n".join(integ),
       "\n".join("[%s] " % n + l for n in ("report", "auto", "full", "tamper") for l in E[n]))
(rel / "VRN2_Verification_v0157.md").write_text(md, encoding="utf-8", newline="\n")
src = (REPO / "VRN2_Handover_v0157.md").read_text(encoding="utf-8")
def once(a, b):
    global src
    assert src.count(a) == 1, (src.count(a), a[:80]); src = src.replace(a, b)
L = src.split("\n"); assert L[0].startswith("# VRN-2 交接報告 · ActivateVRN-2 v0156 + VRN2_RoundAll_v0112 + VRN2_HandleAll_v0104 · 2026-10-31(")
L[0] = ("# VRN-2 交接報告 · ActivateVRN-2 v0157 + VRN2_RoundAll_v0113 + VRN2_HandleAll_v0105 · 2026-10-31(③ 預設只檢查 · 缺的經 VCGC 安裝閘 CGC_MDL056_InstallGate 最高版號;"
        "管理器 envcheck 的本環境 pip + numpy<2 約束不再用;runtime v0156 原樣;桌機 04:13 v0104 repair = BLOCKED · 人工 3(閘二 VIA_SCRAPE_CONSENT 未設))")
src = "\n".join(L)
H = R["handleall"]
once("> **本輪(v0156)**",
     "> **本輪(v0157)**:操作員「預設關掉 ③ 的 pip 補裝，改經 VCGC 安裝」→ **啟動器 v0157** 攔下 ③ 的 envcheck:只檢查 → 缺的一個一個交 VCGC 安裝閘(最高版號 · 倉裡 v0104)→ 再檢查 · "
     "裝不起來 24 小時不重試(`VIA_Reports\\vrn2\\VRN2_VCGCInstall_latest.json`)· `--no-install` 只檢查 · 舊的本環境 pip 只有 `--pip-install` / `VIA_VRN2_PIP_INSTALL=1`;"
     "**RoundAll v0113**(② 提示 · 除錯列 · 貼回包)· **Handle-All v0105**(最短一行 %d 字元 · `vrn2_release_v0157/VRN2_HandleAll_v0105_boot.txt`)· runtime v0156 原樣。"
     "桌機 04:13 v0104 repair:③b 閘二 `VIA_SCRAPE_CONSENT` 未設 → BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2(預期內)。\n"
     "> **本輪(v0156)**" % H["tiny_line_chars"])
once("| **VRN2_HandleAll_v0104.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0104** |",
     "| **VRN2_HandleAll_v0105.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0105** | `vrn2_release_v0157` | 一行版 `%s` · 開機檔 `%s` | **新**(RoundAll v0113 · 最短一行 %d 字元)|\n"
     "| **VRN2_RoundAll_v0113.py**(發行夾 · 一支入口 · 不在套件內)| **v0113** | `vrn2_release_v0157` | `%s` | **新**(套件 v0157 · ③ 經 VCGC 安裝閘的除錯列 / 收尾頁 · ② 磁碟 → 人工 · 自測 57 項)|\n"
     "| ActivateVRN-2_v0157.py(套件 · 底座 v0136 · runtime v0156)| **v0157** | 見發行清單 | `%s` | **新**(③ 只檢查 · 缺的經 VCGC 安裝閘 · 收據 v0157 · 自測多一段 v0157)|\n"
     "| **VRN2_HandleAll_v0104.md**(發行夾 · 最短一行 + 開機行 + 一段碼 · 不是 .ps1)| **v0104** |"
     % (H["line_sha256"][:12], H["boot_line_sha256"][:12], H["tiny_line_chars"], R["roundall"]["sha256"][:12], R["launcher"]["sha256"][:12]))
once("| **VRN2_RoundAll_v0112.py**(發行夾 · 一支入口 · 不在套件內)| **v0112** | `vrn2_release_v0156` | `5f032bc73f2f` | **新**(",
     "| **VRN2_RoundAll_v0112.py**(發行夾 · 一支入口 · 不在套件內)| **v0112** | `vrn2_release_v0156` | `5f032bc73f2f` | 被 v0113 取代(③ 本環境 pip)· (")
once("| 0 | **(v0156)**",
     "| 0 | **(v0157)** 桌機 PowerShell 7 貼 `vrn2_release_v0157/VRN2_HandleAll_v0105.md` **最上面那行(%d 字元)**→ auto → repair → 閘照舊預期 BLOCKED · VRN-2 0 · VCGC 1 · 人工 3 · 資料源 2;"
     "要經網路工具抓共識 → 操作員先設 `$env:VIA_SCRAPE_CONSENT='YES'`(VIA_NET_CONSENT 已是 YES)→ 人工 2;整輪時 ③ 缺的經 VCGC 安裝閘 → 收尾頁 VCGC 列沒裝起來的 | 貼回 |\n"
     "| 0 | **(v0156)**" % H["tiny_line_chars"])
once("**v0156(2026-10-31)**:", "**v0157(2026-10-31)**:③ 預設只檢查 · 缺的經 VCGC 安裝閘(不再本環境 pip + numpy<2 約束)· 啟動器 v0157 · RoundAll v0113 · Handle-All v0105 · runtime v0156 原樣。\n\n**v0156(2026-10-31)**:")
once("## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n", "## 11. 給下一個 AI 的關鍵規則(本輪新增在前)\n\n"
     "- **(v0157)** **VRN-2 不 pip**:缺的套件一律交 VCGC 安裝閘 `CGC_MDL056_InstallGate`(最高版號 · 只呼叫 · 不改它);它只裝進呼叫它的 Python(`--user`)· 要 `VIA_NET_CONSENT=YES`(SuperAccel 安裝道)。沙盒 / 容器測試別讓它真的裝(同意閘不設 = 誠實 FAIL)。\n"
     "- **(v0157)** **沙盒整輪前後比 `pip freeze`**:v0156 的整輪讓管理器 envcheck 改了容器 venv(numpy 降版)而沒人發現;v0157 起 e2e 腳本前後比對。\n\n")
(REPO / "VRN2_Handover_v0158.md").write_text(src, encoding="utf-8", newline="\n")
D = REPO / "vrn2_release_v0157"; D.mkdir(exist_ok=True)
for n in ("VRN2_Closeout_v0157.zip", "VRN2_Release_v0157.json", "VRN2_RoundAll_v0113.py", "VRN2_RoundAll_v0113.md", "VRN2_HandleAll_v0105.md", "VRN2_HandleAll_v0105_boot.txt", "VRN2_Verification_v0157.md"):
    shutil.copy(rel / n, D / n)
SCR = re.compile(rb"/tmp/claude-0/[^ \"'\n)(]*?/(t157a|v157|v156|v155|lst)/")
SCR2 = re.compile(rb"/tmp/claude-0/[^ \"'\n)(/]+/[0-9a-f-]{36}/scratchpad/")
def put(z, name, data):
    zi = zipfile.ZipInfo(name, date_time=(2026, 10, 31, 0, 0, 0)); zi.compress_type = zipfile.ZIP_DEFLATED; z.writestr(zi, SCR2.sub(rb"<scratch>/", SCR.sub(rb"<\1>/", data)))
with zipfile.ZipFile(D / "logs_v0157.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("rall113_selftest.log", "launcher157_selftest.log", "pscheck157.log", "tiny157.rc", "freeze_before.txt", "freeze_after.txt", "integ157.log")] + sorted(W.glob("tiny_*.log")):
        put(z, p.name, p.read_bytes())
with zipfile.ZipFile(D / "vrn2_test_tools_v0157.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for p in [W / n for n in ("mk_launcher157.py", "mk_roundall113.py", "build157.py", "finalize157.py", "e2e157.sh", "integ/integ157.py", "ha_md_tpl.md", "ra_md_tpl.md", "ps7/handleall_src.ps1", "ps7/boot_src.ps1", "ps7/join_ps.py")] + [rel / "tiny_line.txt", rel / "boot_line.txt", rel / "boot_cmd.txt"]:
        put(z, "tools/" + p.name, p.read_bytes())
print("staged", sorted(x.name for x in D.iterdir()), "· handover v0158", src.count("\n"))
